/*
 * nat_defs.h
 *
 * router module common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __NAT_DEFS_H__
#define __NAT_DEFS_H__

/*****************************************************************************
 *
 * include
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "nat_flavor.h"
#include <stdlib.h>
#include <string.h>
#include "netutils.h"
#include "netcommon.h"
#include "netnetwork.h"
#include "nettime.h"
#include "nettransport.h"
#include "transportparser.h"
#include "icmpparser.h"
#include "nat.h"
#include "nat_dbg.h"
#include "ip.h"
#include "icmp.h"
#include "iptable.h"
#include "ecc.h"
#include <arpa/inet.h>

/*****************************************************************************
 *
 * define
 *
 *****************************************************************************/
#define NAT_HASH_INDEX(a)       ((a) & NAT_HASH_MASK)


/***************************************************************************
 *
 * Constants
 *
 **************************************************************************/
#define NAT_HASH_SIZE                   64
#define NAT_HASH_MASK                   (NAT_HASH_SIZE - 1)
#define NAT_NUM_ALLOCATED_PORTS         2048    /* should be a mulitple of 32 */
#define NAT_PORT_BASE                   32768


/*
 * Maximum number of bindings allowed.
 */
#define NAT_CHUNK_MAX_NUM               32
#define NAT_CHUNK_MAX_NUM_LOCAL         4
#define NAT_CHUNK_NUM_BINDINGS          32

/*
 * NAT monitor interval = 4 seconds.
 * Once in 4 seconds all the NAT bindings are checked for
 * timeout.
 */
#define NAT_PROCESS_INTERVAL            4000                    /* units are in ms */

/*
 * NAT bindings will be deleted if they are dormant for
 * more than 30 minutes.
 */
#define NAT_BINDING_TIMEOUT             (30 * 60 * 1000)        /* units are in ms */


/*
 * NAT TCP bindings will be deleted if they are dormant for
 * more than 4 minutes after the reception of close session
 * packets in both directions.
 */
#define NAT_BINDING_TCP_TIMEOUT         (4 * 60 * 1000)         /* units are in ms */
#define NAT_BINDING_LOCAL_TCP_TIMEOUT   (15 * 1000)             /* units are in ms */


/*
 * NAT UDP bindings will be deleted if they are dormant for
 * more than 3 minutes.
 */
#define NAT_BINDING_UDP_TIMEOUT         (3 * 60 * 1000)         /* units are in ms */

/*
 * NAT ICMP bindings will be deleted if they are dormant for
 * more than 1 minute.
 */
#define NAT_BINDING_ICMP_TIMEOUT        (1 * 60 * 1000)         /* units are in ms */


/*
 * NAT binding flags.
 */
/*
 * TCP connection specific flags
 */
#define NAT_TCP_OPEN_INITIATED          (1 << 0x0)
#define NAT_TCP_OPEN_ACKNOWLEDGED       (1 << 0x1)
#define NAT_TCP_CLOSE_RECEIVE           (1 << 0x2)
#define NAT_TCP_CLOSE_SEND              (1 << 0x3)
/*
 * General info flags
 */
#define NAT_WAN_IP_EMPTY                (1 << 0x4)
#define NAT_WAN_PORT_EMPTY              (1 << 0x5)
#define NAT_LAN_IP_EMPTY                (1 << 0x6)
#define NAT_LAN_PORT_EMPTY              (1 << 0x7)


/*
 * Maximum number of ALGs supported.
 */
#define NAT_MAX_NUM_ALG                 5


/*
 * Number of random port binding settings supported.
 */
#define NAT_RANDOM_PORT_BINDING_SIZE    1


/*
 * Maximum number of interfaces (should probably
 * be triggered by flavor.h)
 */
#define NAT_MAXNUM_IF                   10



/*****************************************************************************
 *
 * Enums
 *
 *****************************************************************************/
/*
 * Genric NAT return values, used by most of the function to
 * signal generic events. This should not clash with the error
 * returns of individual functions.
 */
typedef enum {
  NAT_OK,
  NAT_PACKET_UNKNOWN,
  NAT_TO_CPE,
  NAT_DO_NOTHING,
  NAT_OUT_OF_RESOURCE,
} E_NAT_RETURN_VALUE;

/*
 * NatRegisterAlg() return values.
 */
typedef enum {
  NAT_REG_ALG_OK = 0,        /* Registration successful */
  NAT_REG_ALG_FULL = -1,    /* ALG registration table is full */
  NAT_REG_ALG_EXISTS = -2    /* Given port has already been
                   registered. */
} E_NAT_REG_ALG_RETURN_VALS;


/*
 * Direction in which packet is travelling.
 */
typedef enum {
  NAT_DIR_L2W,            /* LAN to WAN */
  NAT_DIR_W2L            /* WAN to LAN */
} E_NAT_DIRECTION;


/*
 * Binding type.
 */
typedef enum {
  NAT_BINDING_LOCAL,
  NAT_BINDING_L2W,
  NAT_BINDING_W2L,
  NAT_BINDING_MAX
} E_NAT_BINDING;



/*****************************************************************************
 *
 * Structures & Typedefs
 *
 *****************************************************************************/
/*
 * NAT binding info
 */
struct NatEntry {
  struct NatEntry *pxLanNext;   /* next entry in the chain */
  struct NatEntry *pxTransNext; /* next entry in the chain */
  DWORD dwLanAddr;              /* LAN Host/Server IP address */
  DWORD dwWanAddr;              /* WAN Host/Server IP address */
  DWORD dwTransAddr;            /* translated IP address */
  union {
    struct {
      WORD wTransPort;          /* keep this as first field */
      WORD wLanPort;
      WORD wWanPort;
      SHORT sLastPayloadModifiedDelta;          /* Last payload size delta */
      DWORD dwLastPayloadModifiedSeqNum;        /* Seq number of last modified packet */
      LONG lUpstreamSeqDelta;                   /* cumulative upstream sequence number change */
    } xTUMapping;               /* TCP/UDP port mappings */

    struct {
      WORD wTransMsgId;         /* keep this as first field */
      WORD wMsgId;
    } xIcmpMapping;             /* ICMP query id. mapping */
  } u;

  OCTET oIfIdx;                 /* interface index - WAN interface */
  OCTET oProtocolId;            /* underlying protocol for the session */
  WORD wFlags;

  DWORD dwLastUsed;
  E_NAT_BINDING eType;

  struct NatChunk* pxNatChunk;
};

typedef struct NatEntry         NAT_ENTRY;

/*
 * NAT chunk info
 */
struct NatChunk {
  DWORD adwBindingStatus[NAT_CHUNK_NUM_BINDINGS >> 5];
  struct NatEntry axNatBindings[NAT_CHUNK_NUM_BINDINGS];
};

typedef struct NatChunk         NAT_CHUNK;


/*
 * Dummy definition to get around interlock
 */
struct NATSTATE;

typedef LONG (*PFN_ALGPROCESS)(struct NATSTATE *pxNat,
                               NETPACKET *pxNetPacket,
                               NETPACKETACCESS *pxNetPacketAccess,
                               H_NETDATA hData,
                               void *pvProtocolHdr,
                               NAT_ENTRY *pxNatEntry,
                               WORD wTransPort,
                               E_NAT_DIRECTION eDirection);




/*
 * NAT ALG info.
 */
typedef struct {
  BOOL bInUse;
  WORD wPort;
  PFN_ALGPROCESS pfnAlgProcess;
} NAT_ALG;


/*
 * NAT Port Forwarding info.
 */
typedef struct {
  BOOL bInUse;
  WORD wFlags;
  WORD wPortBeg;
  union {
    WORD wPortEnd;
    WORD wPortTrans;
  } u;
  DWORD dwIp;
} NAT_PORT_FORWARD;


/*
 * NAT Random Port Binding info.
 */
typedef struct {
  BOOL bInUse;
  WORD wPortBeg;
  WORD wPortEnd;
  WORD wFlags;
} NAT_RANDOM_PORT_BINDING;



/*
 * NAT instance structure
 */
typedef struct NATSTATE {
  /* Basic structure override protection */
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

  PFN_NETMALLOC pfnNetMalloc;
  PFN_NETFREE   pfnNetFree;
  PFN_NETCBK    pfnNetCbk;

  /* Options */
  WORD wOffset;
  WORD wTrailer;

  /* UL module */
  H_NETINSTANCE  hULInst;
  H_NETINTERFACE hULIf;
  PFN_NETRXCBK   pfnRxCbk;

  /* LL module */
  H_NETINSTANCE  hLLInst;
  H_NETINTERFACE hLLIf;
  PFN_NETWRITE   pfnLLWrite;

  OCTET oIfIdxLan;      /* holds the oIfIdx corresponding to the LAN */

  RTOS_MUTEX pxMutex;


  /*
   * NAT Hash table. There are two kinds of hash table.
   * One uses the LAN IP address and the other uses the
   * translation IP address.
   */
  NAT_ENTRY* apxLanHashTable[NAT_HASH_SIZE];
  NAT_ENTRY* apxTransHashTable[NAT_HASH_SIZE];


  /*
   * Status information of each port in the translation
   * range. TCP/UDP connections and ICMP Query Id. share the
   * same space.
   */
  DWORD adwPortStatus[NAT_NUM_ALLOCATED_PORTS/ (8 * sizeof(DWORD))];


  /*
   * NAT DMZ host.
   */
  DWORD dwDmzHost;


  /*
   * ALG information.
   */
  NAT_ALG axAlg[NAT_MAX_NUM_ALG];
  OCTET oNumAlg;

  /*
   * Chunks information.
   */
  OCTET oNumUsedLocalChunks;
  OCTET oNumUsedChunks;
  OCTET oNumAllowedChunks;

  /*
   * NAT chunks table.
   */
  NAT_CHUNK* apxNatChunksLocal[NAT_CHUNK_MAX_NUM_LOCAL];
  NAT_CHUNK* apxNatChunks[NAT_CHUNK_MAX_NUM];


  /*
   * Number of NAT bindings limit
   */
  WORD wNumBindingsMax;


  /*
   * Total number of NAT bindings currently active
   */
  WORD wNumBindingsActive;


  /*
   * Port forwarding table.
   */
  NAT_PORT_FORWARD axPortForwardLan[NAT_PORT_FORWARD_LAN_SIZE];
  NAT_PORT_FORWARD axPortForwardWan2Cpe[NAT_PORT_FORWARD_CPE_SIZE];
  NAT_PORT_FORWARD axPortBlockLan2Cpe[NAT_PORT_BLOCK_CPE_SIZE];


  /*
   * Random port binding table.
   */
  NAT_RANDOM_PORT_BINDING axRandomPortBinding[NAT_RANDOM_PORT_BINDING_SIZE];


  /*
   * MTU setting of an interface.
   */
  WORD awMtu[NAT_MAXNUM_IF];

} NATSTATE;


/*
 * NAT translation helper structure used during checksum adjustment.
 */
typedef struct {
  DWORD dwAddr;
  DWORD dwPort;
} NAT_TRANS_STRUCT;


/***************************************************************************
 *
 * Externs
 *
 **************************************************************************/


/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/
/* in nat_tu.c */
LONG NatHandleTURx(NATSTATE* pxNat,
                   NETPACKET *pxNetPacket,
                   NETPACKETACCESS *pxNetPacketAccess,
                   H_NETDATA hData,
                   void* pvProtocolHdr);

/* in nat_tu.c */
LONG NatHandleTUTx(NATSTATE* pxNat,
                   NETPACKET *pxNetPacket,
                   NETPACKETACCESS *pxNetPacketAccess,
                   H_NETDATA hData,
                   void* pvProtocolHdr);

/* in nat_tu.c */
void NatUpdateTcpFlags(NAT_ENTRY* pxNatEntry,
                       TCPHDR* pxTcpHdr,
                       E_NAT_DIRECTION eDirection);

/* in nat_tu.c */
void NatHandleTcpMss(NATSTATE* pxNat,
                     TCPHDR* pxTcpHdr,
                     H_NETDATA hData);

/* in nat_tu.c */
BOOL NatIsTcpSessionStart(TCPHDR* pxTcpHdr);

/* in nat_icmp.c */
LONG NatHandleIcmpRx(NATSTATE* pxNat,
                     NETPACKET *pxNetPacket,
                     NETPACKETACCESS *pxNetPacketAccess,
                     H_NETDATA hData,
                     void* pvProtocolHdr);

/* in nat_icmp.c */
LONG NatHandleIcmpTx(NATSTATE* pxNat,
                     NETPACKET *pxNetPacket,
                     NETPACKETACCESS *pxNetPacketAccess,
                     H_NETDATA hData,
                     void* pvProtocolHdr);


/* in nat_bind.c */
NAT_ENTRY* NatCreateBindingTU(NATSTATE* pxNat,
                              DWORD dwWANIP, WORD wWANPort,
                              DWORD dwLANIP, WORD wLANPort,
                              DWORD dwTransIP, WORD wTransPort,
                  OCTET oIfIdx,
                              OCTET oProtocol,
                              E_NAT_BINDING eType);

/* in nat_bind.c */
NAT_ENTRY* NatCreateBindingIcmpQuery(NATSTATE* pxNat,
                                     DWORD dwWANIP, DWORD dwLANIP,
                                     DWORD dwTransIP, WORD wTransMsgId,
                     OCTET oIfIdx, WORD wQueryId,
                                     E_NAT_BINDING eType);

/* in nat_bind.c */
void NatDeleteBinding(NATSTATE* pxNat, NAT_ENTRY* pxNatEntry);

/* in nat_utils.c */
WORD NatChecksumAdjust(WORD wChecksum,
                       WORD* pwOldData,
                       DWORD dwOldLength,
                       WORD* pwNewData,
                       DWORD dwNewLength);

/* in nat_utils.c */
NAT_ENTRY* NatFindTUBindingRx(NATSTATE* pxNat,
                              DWORD dwSrcIP, WORD wSrcPort,
                              DWORD dwDstIP, WORD wDstPort,
                              OCTET oProtocol);

/* in nat_utils.c */
NAT_ENTRY* NatFindTUBindingTx(NATSTATE* pxNat,
                              DWORD dwSrcIP, WORD wSrcPort,
                              DWORD dwDstIP, WORD wDstPort,
                              OCTET orotocol);

/* in nat_utils.c */
NAT_ENTRY* NatFindIcmpQueryBindingRx(NATSTATE* pxNat,
                                     DWORD dwSrcIP, DWORD dwDstIP,
                                     WORD wQueryId, OCTET oProtocol);

/* in nat_utils.c */
NAT_ENTRY* NatFindIcmpQueryBindingTx(NATSTATE* pxNat,
                                     DWORD dwSrcIP, DWORD dwDstIP,
                                     WORD wQueryId, OCTET oProtocol);

/* in nat_utils.c */
BOOL NatIsTransPortInRange(WORD dwPort);

/* in nat_utils.c */
DWORD NatHash(DWORD dwAddr, WORD wPort, OCTET oProtocol);

/* in nat_utils.c */
void NatDeleteFromTransHashTable(NATSTATE* pxNat, NAT_ENTRY* pxNatEntry);

/* in nat_utils.c */
void NatDeleteFromLanHashTable(NATSTATE* pxNat, NAT_ENTRY* pxNatEntry);

#ifdef NATDBG_HI
/* in nat_utils.c */
CHAR* NatGetBindingName(E_NAT_BINDING eType);

/* in nat_utils.c */
void NatDisplayBindings(NATSTATE* pxNat);
#endif

/* in nat_alg.c */
LONG NatRegisterAlg(NATSTATE* pxNat, WORD wPort, PFN_ALGPROCESS pfnAlgProcess);
void NatUnregisterAlg(NATSTATE* pxNat, WORD wPort);
WORD NatPortForwardAlg(NATSTATE* pxNat, DWORD dwLANIP, WORD wPort,
                       DWORD dwTransIp, OCTET oIfIdx,
                       OCTET oProtocol);
NAT_ALG* NatFindAlg(NATSTATE* pxNat, WORD wSrcPort, WORD wDstPort);

/* in nat_alg.c */
void NatCalcTUChecksumAlg(void *pvProtocolHdr,
                          DWORD dwSrcAddr,
                          DWORD dwDstAddr,
                          OCTET oProtocol,
                          DWORD dwLength);

/* in nat_portfw.c */
void NatLoadPortForward(void);

/* in nat_portfw.c */
NAT_PORT_FORWARD*
NatIsPortForwardedToLan(NATSTATE* pxNat, WORD wPort, WORD wFlags);

/* in nat_portfw.c */
BOOL NatIsPortForwardedWanToCpe(NATSTATE* pxNat, WORD wPort, OCTET oProtocol);
BOOL NatIsPortBlockedLanToCpe(NATSTATE* pxNat, WORD wPort, OCTET oProtocol);
BOOL NatIsPort2Cpe(NAT_PORT_FORWARD* pxPortTbl, DWORD dwSize, WORD wPort, OCTET oProtocol);

/* in nat_portfw.c */
void NatNullifyForwardingEntry(NATSTATE* pxNat, NAT_PORT_FORWARD* pNATPortForward);
void NatNullifyForwardingEntryLocal(NATSTATE* pxNat, NAT_PORT_FORWARD* pNATPortForward);

#ifdef NATDBG_HI
/* in nat_portfw.c */
void NatDisplayPortForward(NATSTATE* pxNat);
#endif

/* in nat_rport.c */
LONG NatRegisterRandomPortBinding(NATSTATE* pxNat, WORD wPortBeg, WORD wPortEnd, WORD wFlags);
void NatUnregisterRandomPortBinding(NATSTATE* pxNat, WORD wPortBeg, WORD wPortEnd);
BOOL NatIsRandomPortBinding(NATSTATE* pxNat, WORD wPort, OCTET oProtocol);

/* in nat_portfw.c */
LONG NatRegisterPortForwardWanToCpe(NATSTATE* pxNat,
                                    NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe);
LONG NatRegisterPortBlockLanToCpe(NATSTATE* pxNat,
                                  NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe);
LONG NatRegisterPorts2Cpe(NAT_PORT_FORWARD* pxPortTbl,
                          DWORD dwSize,
                          NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe);
void NatUnregisterPortForwardWanToCpe(NATSTATE* pxNat,
                                      NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe);
void NatUnregisterPortBlockLanToCpe(NATSTATE* pxNat,
                                    NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe);
NAT_PORT_FORWARD* NatUnregisterPorts2Cpe(NAT_PORT_FORWARD* pxPortTbl,
                                         DWORD dwSize,
                                         NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe);
LONG NatConfigPortForwardToLan(NATSTATE* pxNat,
                               NATCFG_PORTFWDLAN* pxNatCfgPortFwdLan);
void NatGetPortForwardWanToCpeList(NATSTATE* pxNat,
                                   NATCFG_PORTS2CPE* pxNatPorts2Cpe);

/* in nat_utils.c */
void NatClearBindingTable(NATSTATE* pxNat);

/* in nat_utils.c */
void NatClearIfBindings(NATSTATE* pxNat, OCTET oIfIdx);

/* in nat_metric.c */
void NatSortChunks(NATSTATE* pxNat);

/* in nat_process.c */
void NatTrimChunks(NATSTATE* pxNat, OCTET oTargetNumChunks);

/* in nat_utils.c */
void NatDeleteChunk(NATSTATE* pxNat, NAT_CHUNK* pxNatChunk);

#endif /* #ifndef __NAT_DEFS_H__ */
