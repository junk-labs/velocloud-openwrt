#include "netcfg.h"
#include "setupnet.h"

/*
 * SetupNetRegisterWan2CpePortFwd
 *  On a router device, (de)register WAN ports which are to be
 *  be forwarded up to the CPE
 *  **********************************************************
 *  BY DEFAULT, WAN PORTS ARE NOT ACCESSIBLE VIA THE WAN
 *  **********************************************************
 *
 *  Args:
 *    wPortRangeBegin          WORD port range begin
 *    wPortRangeEnd            WORD port range end
 *    bAllowAccess             BOOL allow access?
 *
 * Return:
 *  SETUPNET_OK                success
 *  SETUPNET_ERROR             error
 */
SetupNetReturn SetupNetRegisterWan2CpePortFwd(WORD wPortRangeBegin,
                                              WORD wPortRangeEnd,
                                              BOOL bAllowAccess)
{
#ifdef NAT
  int iSocket;
  NATCFG_PORTS2CPE xNatCfgPortFwdCpe;
  
  if ((iSocket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  
  xNatCfgPortFwdCpe.wPortBeg = wPortRangeBegin;
  xNatCfgPortFwdCpe.wPortEnd = wPortRangeEnd;
  xNatCfgPortFwdCpe.wFlags = NAT_PORT_FORWARD_PROT_BOTH;
#if 0 
  if (0 > ioctl(iSocket,
                bAllowAccess ? SIOCNATREGFWDWAN2CPE:SIOCNATUNREGFWDWAN2CPE,
                &xNatCfgPortFwdCpe)) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
#endif /* TBD */
  
  close(iSocket);
#endif
  
  return SETUPNET_OK;
}


/*
 * SetupNetRegisterLan2CpePortBlock
 *  On a router device, (de)register LAN ports which are to be
 *  be blocked from reaching the CPE
 *  ***********************************************************
 *  BY DEFAULT, ALL LAN PORTS ARE ALWAYS ACCESSIBLE VIA THE LAN
 *  ************************************************************
 *
 *  Args:
 *    wPortRangeBegin          WORD port range begin
 *    wPortRangeEnd            WORD port range end
 *    bBlock                   BOOL block this port range?
 *
 * Return:
 *  SETUPNET_OK                success
 *  SETUPNET_ERROR             error
 */
SetupNetReturn SetupNetRegisterLan2CpePortBlock(WORD wPortRangeBegin,
                                                WORD wPortRangeEnd,
                                                BOOL bBlock)
{
#ifdef NAT
  int iSocket;
  NATCFG_PORTS2CPE xNatCfgPortFwdCpe;
  
  if ((iSocket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  
  xNatCfgPortFwdCpe.wPortBeg = wPortRangeBegin;
  xNatCfgPortFwdCpe.wPortEnd = wPortRangeEnd;
  xNatCfgPortFwdCpe.wFlags = NAT_PORT_FORWARD_PROT_BOTH;
#if 0 
  if (0 > ioctl(iSocket,
                bBlock ? SIOCNATREGBLKLAN2CPE:SIOCNATUNREGBLKLAN2CPE,
                &xNatCfgPortFwdCpe)) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
#endif /* TBD */
  
  close(iSocket);
#endif
  
  return SETUPNET_OK;
}
