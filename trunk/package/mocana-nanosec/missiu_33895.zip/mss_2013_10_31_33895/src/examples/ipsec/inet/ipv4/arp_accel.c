/*
 * arp_accel.c
 *
 * ARP module implementation
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "arpdefs.h"

/***************************************************************************
* ArpEntryMatch
*
* Procedure keeps logic for checking for ARP entry match in one place
*
*       par:    pxArpEntry       entry to be checked for a match
*               dwAddr           IP address to look for
*               oIfIdx           interface index
*               wVlan            Vlan
*
*       ret:    TRUE if match
****************************************************************************/
BOOL ArpEntryMatch(ARPENTRY *pxArpEntry, DWORD dwAddr,OCTET oIfIdx,
                             WORD wVlan)
{
  if ((pxArpEntry->dwIpAddr == dwAddr) &&
      ((pxArpEntry->oIfIdx == oIfIdx) ||
       (pxArpEntry->oIfIdx == NETIFIDX_ANY) ||
       (oIfIdx == NETIFIDX_ANY) )&&
      (((pxArpEntry->wVlan & NETVLAN_ANY) == (wVlan & NETVLAN_ANY)) ||
       (wVlan == NETVLAN_ANY) || (pxArpEntry->wVlan == NETVLAN_ANY))
      ){
    return(TRUE);
  }
  return(FALSE);
}

/***************************************************************************
* ArpLookup
*
*       This will find an entry in the ARP table by looking at the IP address.
*
*       par:    dwAddr           IP address to look for
*               oIfIdx           interface index
*               wVlan            Vlan
*
*       ret:    ptr tor the arp entry
*       Note:   We allow ourselves to be ARPed to allow loopback to work.
****************************************************************************/
ARPENTRYSTATE *ArpLookup(ARPSTATE *pxArp, DWORD dwAddr,OCTET oIfIdx,
                    WORD wVlan)
{
  ARPENTRYSTATE *pxArpEntryState;
  ARPENTRY *pxArpEntry;
  DWORD dwHash=0;

  ARP_CHECK_STATE(pxArp);

  /* Loop through the table for the desired address. */
#ifdef ARP_CACHE_32
  dwHash = dwAddr & (pxArp->oArpHashSize - 1);
  ARP_DBG_ASSERT(dwHash < pxArp->oArpHashSize);
#else
  dwHash = dwAddr & (pxArp->wArpHashSize - 1);
  ARP_DBG_ASSERT(dwHash < pxArp->wArpHashSize);
#endif
  pxArpEntryState = pxArp->apxArpHashTable[dwHash];

  while(pxArpEntryState != NULL) {
    pxArpEntry = &(pxArpEntryState->xEntry);
    if (ArpEntryMatch(pxArpEntry, dwAddr, oIfIdx, wVlan)) {
      return(pxArpEntryState);
    }
    pxArpEntryState = pxArpEntryState->pxNext;
  }

  return(NULL);
}

/***************************************************************************
*  Find an ARP mapping in the cache. If not found, post a REQUEST.
*
*  param:  pxArpEntry  - Arp Entry to look for. The aoEthAddr will
*                        be filled up
*        bCheckTimeout - include a check for a timed out ARP entry
*
*    ret:  0        - address found = sucessful
*          1        - address not found
****************************************************************************/
INT ArpFind(ARPSTATE *pxArp, ARPENTRY *pxArpEntry, BOOL bCheckTimeout)
{
  ARPENTRYSTATE *pxArpEntryState = NULL;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ARP_DBGP(DBGLVL_REPETITIVE,
           "ArpFind:DstIp=%ld.%ld.%ld.%ld :",
           IPADDRDISPLAY(pxArpEntry->dwIpAddr));*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "ArpFind:DstIp = ", pxArpEntry->dwIpAddr);
    DEBUG_PRINT(DEBUG_MOC_IPV4, " :");
  }
  pxArpEntryState = ArpLookup(pxArp, pxArpEntry->dwIpAddr,
                              pxArpEntry->oIfIdx,pxArpEntry->wVlan);

  if (NULL != pxArpEntryState) {

    MOC_MEMCPY((ubyte *)pxArpEntry->aoEthAddr,
           (ubyte *)pxArpEntryState->xEntry.aoEthAddr,
           ARP_ETHLEN);

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ARP_DBGP(DBGLVL_REPETITIVE,"Found entry in ARP table " MACFORM "\n",
        HWADDRDISPLAY(pxArpEntryState->xEntry.aoEthAddr));*/
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "Found entry in ARP table", pxArpEntryState->xEntry.aoEthAddr[0],
                          ":", pxArpEntryState->xEntry.aoEthAddr[1]);
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ":", pxArpEntryState->xEntry.aoEthAddr[2],
                          ":", pxArpEntryState->xEntry.aoEthAddr[3]);
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ":", pxArpEntryState->xEntry.aoEthAddr[4],
                          ":", pxArpEntryState->xEntry.aoEthAddr[5]);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }

#ifdef ARP_REQ_ON_TIMEOUT
    if (bCheckTimeout)
      return (INT)(pxArpEntryState->eState == ARPENTRY_REACQUIRE);
    else {
      /* flag that ARP entry was last read rather than refreshed */
      if (ARPENTRY_REFRESHED == pxArpEntryState->eState) {
        pxArpEntryState->eState = ARPENTRY_READ;
      }
      return (INT)0;
    }
#else
    return (INT)0;
#endif

  } else {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ARP_DBGP(DBGLVL_REPETITIVE,
        "Did not find entry in ARP table\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Did not find entry in ARP table");
    }
  }

  return (INT)1;
}
