/****************************************************************************
 * if_dl.h
 *  interface datalink definition
 *
 *
 *
 *
 ****************************************************************************/
#ifndef _NET_IF_DL_H_
#define _NET_IF_DL_H_

/*
 * Structure of a Link-Level sockaddr:
 */
struct sockaddr_dl {
  unsigned char	sdl_len;	/* Total length of sockaddr */
  unsigned short	sdl_family;	/* AF_LINK */
  unsigned short	sdl_index;	/* if != 0, system given index for interface */
  unsigned char	sdl_type;	/* interface type */
  unsigned char	sdl_nlen;	/* interface name length, no trailing 0 reqd. */
  unsigned char	sdl_alen;	/* link level address length */
  unsigned char	sdl_slen;	/* link layer selector length */
  char	sdl_data[8];	/* minimum work area, can be larger;
                           contains both if name and ll address */
};

#endif
