/*
 * nat_portfw.c
 *
 * Routines to handle port forwarding.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "nat.h"
#include "nat_defs.h"


/************************************************
 * Static Routines
 ***********************************************/
#ifdef NATDBG_HI
static CHAR* _NatGetPortForwardProtName(WORD wFlags);
#endif

/*****************************************************************************
Function:
        NatRegisterPortForwardWanToCpe()
Description:
        Registers a port forwarding binding from WAN to CPE. The
        given range of ports will be forwarded from WAN to the CPE.
Arguments:
        NATSTATE*                pxNat                  NAT instance handle.
        NATCFG_PORTS2CPE*        pxNatCfgPorts2Cpe      Ports and protocols
                                                        to be forwarded.
Outputs:
        None
Returns:
        LONG                    < 0                     If registration fails.
                                                        Registration will fail
                                                        if the port forwarding
                                                        table is full.
                                0                       If registration succeeds.
Revisions:
*****************************************************************************/
LONG NatRegisterPortForwardWanToCpe(NATSTATE* pxNat, NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe)
{
  return(NatRegisterPorts2Cpe(&pxNat->axPortForwardWan2Cpe[0],
                              NAT_PORT_FORWARD_CPE_SIZE,
                              pxNatCfgPorts2Cpe));
}

/*****************************************************************************
Function:
        NatRegisterPortBlockLanToCpe()
Description:
        Registers a port blocking from LAN to CPE. The
        given range of ports will be blocked from LAN to the CPE.
Arguments:
        NATSTATE*                pxNat                  NAT instance handle.
        NATCFG_PORTS2CPE*        pxNatCfgPorts2Cpe      Ports and protocols
                                                        to be blocked.
Outputs:
        None
Returns:
        LONG                    < 0                     If registration fails.
                                                        Registration will fail
                                                        if the port blocking
                                                        table is full.
                                0                       If registration succeeds.
Revisions:
*****************************************************************************/
LONG NatRegisterPortBlockLanToCpe(NATSTATE* pxNat, NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe)
{
  return(NatRegisterPorts2Cpe(&pxNat->axPortBlockLan2Cpe[0],
                              NAT_PORT_BLOCK_CPE_SIZE,
                              pxNatCfgPorts2Cpe));
}


/*****************************************************************************
Function:
        NatRegisterPorts2Cpe()
Description:
        Registers port blocking or forwarding information.
Arguments:
        NAT_PORT_FORWARD*        pxPortTbl              Table to store
                                                        forwarding/blocking
                                                        information.
        DWORD                    dwSize                 Size of the table.
        NATCFG_PORTS2CPE*        pxNatCfgPorts2Cpe      Ports and protocols
                                                        to be forwarded/blocked.
Outputs:
        None
Returns:
        LONG                    < 0                     If registration fails.
                                                        Registration will fail
                                                        if the port blocking
                                                        table is full.
                                0                       If registration succeeds.
Revisions:
*****************************************************************************/
LONG NatRegisterPorts2Cpe(NAT_PORT_FORWARD* pxPortTbl,
                          DWORD dwSize,
                          NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe)
{
  int i;
  WORD wPortBeg = pxNatCfgPorts2Cpe->wPortBeg;
  WORD wPortEnd = pxNatCfgPorts2Cpe->wPortEnd;
  WORD wFlags = pxNatCfgPorts2Cpe->wFlags;

  /*
   * Look for a matching entry.
   * NOTE: This should never find a matching entry.
   *       Just being paranoid about duplicate entries
   *       taking up space.
   */
  for (i = 0; i < dwSize; i++) {
    if ((pxPortTbl[i].bInUse == TRUE) &&
        (pxPortTbl[i].wPortBeg == wPortBeg) &&
        (pxPortTbl[i].u.wPortEnd == wPortEnd)) {
      break;
    }
  }

  if (i != dwSize) {
    /*
     * Found a match, change the flag (if necessary) and return.
     */
    pxPortTbl[i].wFlags = wFlags;
    return (NETERR_NOERR);
  }


  /*
   * Find a free entry.
   */
  for (i = 0; i < dwSize; i++) {
    if (pxPortTbl[i].bInUse == FALSE) {
      break;
    }
  }

  if (i == dwSize) {
    return (-1);
  }

  pxPortTbl[i].bInUse = TRUE;
  pxPortTbl[i].wPortBeg = wPortBeg;
  pxPortTbl[i].u.wPortEnd = wPortEnd;
  pxPortTbl[i].wFlags = wFlags;
  /* dwIp field is not useful for the CPE case. */

  return (NETERR_NOERR);
}



/*****************************************************************************
Function:
        NatUnregisterPortForwardWanToCpe()
Description:
        Unregisters a port forwarding binding from WAN to CPE. The
        given range of ports should have been previously
        registered using NATRegisterPortForwardWanToCpe().
Arguments:
        NATSTATE*                pxNat                  NAT instance handle.
        NATCFG_PORTS2CPE*        pxNatCfgPorts2Cpe      Ports that were
                                                        registered previously
                                                        for forwarding.
Outputs:
        None
Returns:
        None
Revisions:
*****************************************************************************/
void NatUnregisterPortForwardWanToCpe(NATSTATE* pxNat,
                                      NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe)
{
  NAT_PORT_FORWARD* pxNatPortForward;

  pxNatPortForward = NatUnregisterPorts2Cpe(&pxNat->axPortForwardWan2Cpe[0],
                                            NAT_PORT_FORWARD_CPE_SIZE,
                                            pxNatCfgPorts2Cpe);

  if (pxNatPortForward) {
    NatNullifyForwardingEntryLocal(pxNat, pxNatPortForward);
  }
}


/*****************************************************************************
Function:
        NatUnregisterPortBlockLanToCpe()
Description:
        Unregisters a port blocking binding from LAN to CPE. The
        given range of ports should have been previously
        registered using NATRegisterPortBlockLanToCpe().
Arguments:
        NATSTATE*                pxNat                  NAT instance handle.
        NATCFG_PORTS2CPE*        pxNatCfgPorts2Cpe      Ports that were
                                                        registered previously
                                                        for forwarding.
Outputs:
        None
Returns:
        None
Revisions:
*****************************************************************************/
void NatUnregisterPortBlockLanToCpe(NATSTATE* pxNat,
                                    NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe)
{
  NAT_PORT_FORWARD* pxNatPortForward;

  pxNatPortForward = NatUnregisterPorts2Cpe(&pxNat->axPortBlockLan2Cpe[0],
                                            NAT_PORT_BLOCK_CPE_SIZE,
                                            pxNatCfgPorts2Cpe);

  if (pxNatPortForward) {
    pxNatPortForward->bInUse = FALSE;
  }
}


/*****************************************************************************
Function:
        NatUnregisterPorts2Cpe()
Description:
        Unregisters port forwarding/blocking information.
Arguments:
        NAT_PORT_FORWARD*        pxPortTbl              Table which contains
                                                        forwarding/blocking
                                                        information.
        DWORD                    dwSize                 Size of the table.
        NATCFG_PORTS2CPE*        pxNatCfgPorts2Cpe      Ports that were
                                                        registered previously
                                                        for forwarding/blocking.
Outputs:
        None
Returns:
        None
Revisions:
*****************************************************************************/
NAT_PORT_FORWARD* NatUnregisterPorts2Cpe(NAT_PORT_FORWARD* pxPortTbl,
                             DWORD dwSize,
                                         NATCFG_PORTS2CPE* pxNatCfgPorts2Cpe)
{
  int i;
  WORD wPortBeg = pxNatCfgPorts2Cpe->wPortBeg;
  WORD wPortEnd = pxNatCfgPorts2Cpe->wPortEnd;


  /*
   * Look for a matching entry.
   */
  for (i = 0; i < dwSize; i++) {
    if ((pxPortTbl[i].bInUse == TRUE) &&
        (pxPortTbl[i].wPortBeg == wPortBeg) &&
        (pxPortTbl[i].u.wPortEnd == wPortEnd)) {
      break;
    }
  }

  if (i != dwSize) {
    return(&pxPortTbl[i]);
  }

  return(NULL);
}

/*****************************************************************************
Function:
        NatGetPortForwardWanToCpeList()
Description:
        Get the list of ports which have been registered to be forwarded
        from WAN to the CPE.
Arguments:
        NATSTATE*                pxNat                  NAT instance handle.
Outputs:
        NATCFG_PORTS2CPE*        pxNatPorts2Cpe         Pointer to port
                                                        forwarding table into
                                                        which to copy the list.
Returns:
        None
Revisions:
        05-May-2002                                     Initial
*****************************************************************************/
void NatGetPortForwardWanToCpeList(NATSTATE* pxNat,
                                   NATCFG_PORTS2CPE* pxNatPorts2Cpe)
{
  int i;
  int j = 0;
  NAT_PORT_FORWARD* pxPortForwardTbl;

  /*
   * Copy the list of active port forward entries
   */
  pxPortForwardTbl = &pxNat->axPortForwardWan2Cpe[0];
  for (i = 0; i < NAT_PORT_FORWARD_CPE_SIZE; i++) {
    if (pxPortForwardTbl[i].bInUse == TRUE) {
      pxNatPorts2Cpe[j].wPortBeg = pxPortForwardTbl[i].wPortBeg;
      pxNatPorts2Cpe[j].wPortEnd = pxPortForwardTbl[i].u.wPortEnd;
      pxNatPorts2Cpe[j].wFlags = pxPortForwardTbl[i].wFlags;
      j++;
    }
  }

  return;
}


/*****************************************************************************
Function:
        NatIsPortForwardedToLan()
Description:
        Check if the given port has been forwarded to a LAN host.
Arguments:
        NATSTATE*               pxNat           NAT instance handle.
        WORD                    wPort           Port number to be checked
                                                for forwarding match.
        OCTET                   oProtocol       Protocol used in the
                                                received packet.
                                                Could be one of
                                                IPPROTO_TCP
                                                IPPROTO_UDP
Outputs:
        None
Returns:
        DWORD                   non-zero        Forwarded host IP.
                                zero            Port not forwarded.
Revisions:
        03-Nov-2001                             Initial
*****************************************************************************/
NAT_PORT_FORWARD*
NatIsPortForwardedToLan(NATSTATE* pxNat, WORD wPort, WORD wFlags)
{
  NAT_PORT_FORWARD* pxNatPortFwd = &pxNat->axPortForwardLan[0];
  NAT_PORT_FORWARD* pxNatPortFwdEnd = &pxNat->axPortForwardLan[NAT_PORT_FORWARD_LAN_SIZE];

  while (pxNatPortFwd < pxNatPortFwdEnd) {
    if ((pxNatPortFwd->bInUse == TRUE) &&
        (pxNatPortFwd->wFlags & wFlags)) {
      if (pxNatPortFwd->wFlags & NAT_PORT_FORWARD_DYNAMIC) {
        if (pxNatPortFwd->u.wPortTrans == wPort) {
          return pxNatPortFwd;
        }
      } else if ((pxNatPortFwd->wPortBeg <= wPort) &&
                 (pxNatPortFwd->u.wPortEnd >= wPort)) {
        return pxNatPortFwd;
      }
    }
    pxNatPortFwd++;
  }

  return (0);
}


/*****************************************************************************
Function:
        NatIsPortForwardedWanToCpe()
Description:
        Check if the given port has been forwarded from WAN to the CPE.
Arguments:
        NATSTATE*               pxNat           NAT instance handle.
        WORD                    wPort           Port number to be checked
                                                for forwarding match.
        OCTET                   oProtocol       Protocol used in the
                                                received packet.
                                                Could be one of
                                                IPPROTO_TCP
                                                IPPROTO_UDP
Outputs:
        None
Returns:
        BOOL                    TRUE            Port is forwarded to CPE.
                                FALSE           Port is not forwarded to CPE.
Revisions:
        03-Nov-2001                             Initial
*****************************************************************************/
BOOL NatIsPortForwardedWanToCpe(NATSTATE* pxNat, WORD wPort, OCTET oProtocol)
{
  return(NatIsPort2Cpe(&pxNat->axPortForwardWan2Cpe[0],
                       NAT_PORT_FORWARD_CPE_SIZE,
                       wPort,
                       oProtocol));
}


/*****************************************************************************
Function:
        NatIsPortBlockedLanToCpe()
Description:
        Check if the given port has been blocked from LAN to the CPE.
Arguments:
        NATSTATE*               pxNat           NAT instance handle.
        WORD                    wPort           Port number to be checked
                                                for blocking match.
        OCTET                   oProtocol       Protocol used in the
                                                received packet.
                                                Could be one of
                                                IPPROTO_TCP
                                                IPPROTO_UDP
Outputs:
        None
Returns:
        BOOL                    TRUE            Port is blocked to CPE.
                                FALSE           Port is not blcoked to CPE.
Revisions:
        03-Nov-2001                             Initial
*****************************************************************************/
BOOL NatIsPortBlockedLanToCpe(NATSTATE* pxNat, WORD wPort, OCTET oProtocol)
{
  return(NatIsPort2Cpe(&pxNat->axPortBlockLan2Cpe[0],
                       NAT_PORT_BLOCK_CPE_SIZE,
                       wPort,
                       oProtocol));
}


/*****************************************************************************
Function:
        NatIsPort2Cpe()
Description:
        Check if the given port has been forwarded/blocked.
Arguments:
        NAT_PORT_FORWARD*       pxPortTbl       Table of forwarding/blocking
                                                information.
        DWORD                   dwSize          Size of the table.
        WORD                    wPort           Port number to be checked
                                                for blocking match.
        OCTET                   oProtocol       Protocol used in the
                                                received packet.
                                                Could be one of
                                                IPPROTO_TCP
                                                IPPROTO_UDP
Outputs:
        None
Returns:
        BOOL                    TRUE            Port is forwarded/blocked.
                                FALSE           Port is not forwarded/blocked.
Revisions:
*****************************************************************************/
BOOL NatIsPort2Cpe(NAT_PORT_FORWARD* pxPortTbl, DWORD dwSize, WORD wPort, OCTET oProtocol)
{
  int i;
  WORD wFlags = (oProtocol == IPPROTO_TCP) ?
                (NAT_PORT_FORWARD_PROT_TCP) : (NAT_PORT_FORWARD_PROT_UDP);

  for (i = 0; i < dwSize; i ++) {
    if (pxPortTbl[i].bInUse == FALSE) {
      continue;
    }

    if ((pxPortTbl[i].wPortBeg <= wPort) &&
        (pxPortTbl[i].u.wPortEnd >= wPort) &&
        (pxPortTbl[i].wFlags & wFlags)) {
      return (TRUE);
    }
  }

  return (FALSE);
}


/*****************************************************************************
Function:
        NatNullifyForwardingEntry()
Description:
        Nullifies a forwarding entry. Looks up the NAT
        binding tables for a match and removes any existing
        bindings.
        Should be run in the network thread only.
Arguments:
        NATSTATE*               pxNat                   NAT Instance handle.
        NAT_PORT_FORWARD*       pxNatPortForward        Port Forwarding entry.
Outputs:
        None
Returns:
        None
Revisions:
        09-Nov-2001                                     Initial
*****************************************************************************/
void NatNullifyForwardingEntry(NATSTATE* pxNat,
                               NAT_PORT_FORWARD* pxNatPortForward)
{
  DWORD dwIdx;
  NAT_ENTRY *pxNatEntry, *pxNextNatEntry;
  WORD wFlags;

  if (pxNatPortForward->bInUse == FALSE) {
    return;
  }

  for (dwIdx = 0; dwIdx < NAT_HASH_SIZE; dwIdx ++) {

    if ((pxNatEntry = pxNat->apxLanHashTable[dwIdx]) != NULL) {

      while (pxNatEntry) {

        if (pxNatEntry->eType != NAT_BINDING_W2L) {
          pxNatEntry = pxNatEntry->pxLanNext;
          continue;
        }

        if ((pxNatEntry->oProtocolId == IPPROTO_TCP) ||
            (pxNatEntry->oProtocolId == IPPROTO_UDP)) {

          wFlags = (pxNatEntry->oProtocolId == IPPROTO_TCP) ?
                   (NAT_PORT_FORWARD_PROT_TCP) : (NAT_PORT_FORWARD_PROT_UDP);

          if ((pxNatEntry->u.xTUMapping.wLanPort >= pxNatPortForward->wPortBeg) &&
              (pxNatEntry->u.xTUMapping.wLanPort <= pxNatPortForward->u.wPortEnd) &&
              (pxNatEntry->dwLanAddr == pxNatPortForward->dwIp) &&
              (wFlags & pxNatPortForward->wFlags))  {
            pxNextNatEntry = pxNatEntry->pxLanNext;
            NatDeleteBinding(pxNat, pxNatEntry);
            pxNatEntry = pxNextNatEntry;
            continue;
          }
        }

        pxNatEntry = pxNatEntry->pxLanNext;
      }
    }
  }

  pxNatPortForward->bInUse = FALSE;
}


/*****************************************************************************
Function:
        NatNullifyForwardingEntryLocal()
Description:
        Nullifies a forwarding entry to CPE. Looks up the NAT
        binding tables for a match and removes any existing
        bindings.
        Should be run in the network thread only.
Arguments:
        NATSTATE*               pxNat                   NAT Instance handle.
        NAT_PORT_FORWARD*       pxNatPortForward        Port Forwarding entry.
Outputs:
        None
Returns:
        None
Revisions:
*****************************************************************************/
void NatNullifyForwardingEntryLocal(NATSTATE* pxNat,
                                    NAT_PORT_FORWARD* pxNatPortForward)
{
  DWORD dwIdx;
  NAT_ENTRY *pxNatEntry, *pxNextNatEntry;
  WORD wFlags;

  if (pxNatPortForward->bInUse == FALSE) {
    return;
  }

  for (dwIdx = 0; dwIdx < NAT_HASH_SIZE; dwIdx ++) {

    if ((pxNatEntry = pxNat->apxLanHashTable[dwIdx]) != NULL) {

      while (pxNatEntry) {

        if (pxNatEntry->eType != NAT_BINDING_LOCAL) {
          pxNatEntry = pxNatEntry->pxLanNext;
          continue;
        }

        if ((pxNatEntry->oProtocolId == IPPROTO_TCP) ||
            (pxNatEntry->oProtocolId == IPPROTO_UDP)) {

          wFlags = (pxNatEntry->oProtocolId == IPPROTO_TCP) ?
                   (NAT_PORT_FORWARD_PROT_TCP) : (NAT_PORT_FORWARD_PROT_UDP);

          if ((pxNatEntry->u.xTUMapping.wLanPort >= pxNatPortForward->wPortBeg) &&
              (pxNatEntry->u.xTUMapping.wLanPort <= pxNatPortForward->u.wPortEnd) &&
              (wFlags & pxNatPortForward->wFlags))  {
            pxNextNatEntry = pxNatEntry->pxLanNext;
            NatDeleteBinding(pxNat, pxNatEntry);
            pxNatEntry = pxNextNatEntry;
            continue;
          }
        }

        pxNatEntry = pxNatEntry->pxLanNext;
      }
    }
  }

  pxNatPortForward->bInUse = FALSE;
}


/**********************************************************************************
Function:
        NatConfigPortForwardToLan()
Description:
        Configures a port forward entry.
Arguments:
        NATSTATE*               pxNat                   NAT Instance handle.
        NATCFG_PORTFWDLAN*      pxNatCfgPortFwdLan      Port forwarding
                                                        configuration.
Outputs:
        None
Returns:
        None
Revisions:
        28-Mar-2002                                     Initial
**********************************************************************************/
LONG NatConfigPortForwardToLan(NATSTATE* pxNat,
                               NATCFG_PORTFWDLAN* pxNatCfgPortFwdLan)
{
  NAT_PORT_FORWARD xNatPortForward;
  NAT_PORT_FORWARD* pxNatPortForward = NULL;
  WORD wFlags = pxNatCfgPortFwdLan->wFlags;
  DWORD dwIndex = pxNatCfgPortFwdLan->dwIndex;
  sbyte4 cmpResult;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_NORMAL))
  {
    /*NAT_DBGP(DBGLVL_NORMAL, "NatConfigPortForwardToLan port wPortBeg %d, wPortEnd %d,"
           "wPortTrans %d, flag %d, bNullify %d, dwIndex %ld\n",
           pxNatCfgPortFwdLan->wPortBeg, pxNatCfgPortFwdLan->wPortEnd,
           pxNatCfgPortFwdLan->wPortTrans, wFlags,
           pxNatCfgPortFwdLan->bNullifyEntry, dwIndex);*/
    DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "NatConfigPortForwardToLan port wPortBeg ", pxNatCfgPortFwdLan->wPortBeg,
                        ", wPortEnd : ", pxNatCfgPortFwdLan->wPortEnd);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", wPortTrans : ", pxNatCfgPortFwdLan->wPortTrans);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", wFlags : ", wFlags);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", bNullify : ", pxNatCfgPortFwdLan->bNullifyEntry);
    DEBUG_UINT(DEBUG_MOC_IPV4, ", dwIndex : ", dwIndex);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  if (wFlags & NAT_PORT_FORWARD_DYNAMIC) {
    pxNatPortForward =
      NatIsPortForwardedToLan(pxNat, pxNatCfgPortFwdLan->wPortTrans, wFlags);

    if (pxNatCfgPortFwdLan &&
        !(pxNatCfgPortFwdLan->wFlags & NAT_PORT_FORWARD_DYNAMIC)) {
      return -1;
    }
  } else {
    ASSERT(dwIndex < NAT_PORT_FORWARD_LAN_WEB_SIZE);
    pxNatPortForward = &pxNat->axPortForwardLan[dwIndex];
  }

  /*
   * If this entry has been removed from configuration,
   * just nullify that entry and return.
   */
  if (pxNatCfgPortFwdLan->bNullifyEntry) {
    if (pxNatPortForward == NULL) {
      return -1;
    } else {
      NatNullifyForwardingEntry(pxNat, pxNatPortForward);
      return 0;
    }
  }

  if ((wFlags & NAT_PORT_FORWARD_DYNAMIC) && pxNatPortForward == NULL) {
    /* find available entry */
    for (dwIndex=NAT_PORT_FORWARD_LAN_WEB_SIZE; dwIndex<NAT_PORT_FORWARD_LAN_SIZE; dwIndex++) {
      if (pxNat->axPortForwardLan[dwIndex].bInUse == FALSE) {
        break;
      }
    }
    if (dwIndex >= NAT_PORT_FORWARD_LAN_SIZE) {
      /* All entried are used */
      return -1;
    }
    pxNatPortForward = &pxNat->axPortForwardLan[dwIndex];
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_NORMAL))
  {
    /*NAT_DBGP(DBGLVL_NORMAL, "NatConfigPortForwardToLan new index %ld\n", dwIndex);*/
    DEBUG_PRINT(DEBUG_MOC_IPV4, "NatConfigPortForwardToLan new index : ");
    DEBUG_UINT(DEBUG_MOC_IPV4, dwIndex);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /*
   * Read the new configuration.
   * NOTE: The ports forwarded to the CPE get highest
   *       priority. In case any of the user settings
   *       clash with the ports forwarded to CPE, the
   *       associated LAN node will not get the traffic.
   */
  xNatPortForward.wPortBeg = pxNatCfgPortFwdLan->wPortBeg;
  if (wFlags & NAT_PORT_FORWARD_DYNAMIC) {
    xNatPortForward.u.wPortTrans = pxNatCfgPortFwdLan->wPortTrans;
  } else {
    xNatPortForward.u.wPortEnd = pxNatCfgPortFwdLan->wPortEnd;
  }
  xNatPortForward.wFlags = wFlags;
  {
    /*
     * Get the LAN IP address and use the network part of the
     * address.
     */
    IPTABLEENTRY xIpEntry;

    xIpEntry.dwAddr = 0x0;
    xIpEntry.eAddrType = IPADDRT_ANY;
    xIpEntry.wDefaultVlan = NETVLAN_ANY;
    xIpEntry.oIfIdx = pxNat->oIfIdxLan;

    IpTableMsg(IPTABLEMSG_GETDEFAULT, (H_NETDATA) &xIpEntry);

    ASSERT(xIpEntry.dwAddr);
    xNatPortForward.dwIp =
      (xIpEntry.dwAddr & xIpEntry.u.dwIpNetMask) | pxNatCfgPortFwdLan->dwIp;
  }

  xNatPortForward.bInUse = TRUE;

  MOC_MEMCMP((void*) &xNatPortForward,
             (void*) pxNatPortForward,
             sizeof(NAT_PORT_FORWARD), &cmpResult);
  if (0 != cmpResult) {
    /*
     * If the port forwarding entry is already in use, check
     * all exisiting NAT bindings for a match. If there are
     * matches, the associated bindings should be removed.
     * This gets quite complicated in the case of dynamic
     * port forwarding. eg. the data channel connection of
     * FTP session. Such auxiliary connections are left
     * untouched. They will either terminate properly or
     * time out.
     */
    NatNullifyForwardingEntry(pxNat, pxNatPortForward);
  }

  MOC_MEMCPY((ubyte *) pxNatPortForward,
         (ubyte *) &xNatPortForward,
         sizeof(NAT_PORT_FORWARD));

  return 0;
}


#ifdef NATDBG_HI
/*****************************************************************************
Function:
        NatDisplayPortForward()
Description:
        Displays all the port forwarding tables.
Arguments:
        NATSTATE*       pxNat                   NAT instance handle
Outputs:
        None
Returns:
        None
Revisions:
        03-Nov-2001                             Initial
*****************************************************************************/
void NatDisplayPortForward(NATSTATE* pxNat)
{
  int i;
  NAT_PORT_FORWARD* pxNatPortForward;
  struct in_addr xInAddr;


  /*
   * Ports forwarded from WAN to CPE.
   */
  printf("Ports Forwarded from WAN to CPE:\n");
  printf("%10s\t%8s\t%8s\n",
                "Port Start",
                "Port End",
                "Protocol");
  printf("%10s\t%8s\t%8s\n",
                "----------",
                "--------",
                "--------");
  for (i = 0; i < NAT_PORT_FORWARD_CPE_SIZE; i++) {

    pxNatPortForward = &pxNat->axPortForwardWan2Cpe[i];

    if (pxNatPortForward->bInUse == FALSE) {
      continue;
    }

    printf("%10d\t%8d\t%8s\n",
                pxNatPortForward->wPortBeg,
                pxNatPortForward->u.wPortEnd,
                _NatGetPortForwardProtName(pxNatPortForward->wFlags));
  }



  /*
   * Ports blocked from LAN to CPE.
   */
  printf("Ports Blocked from LAN to CPE:\n");
  printf("%10s\t%8s\t%8s\n",
                "Port Start",
                "Port End",
                "Protocol");
  printf("%10s\t%8s\t%8s\n",
                "----------",
                "--------",
                "--------");
  for (i = 0; i < NAT_PORT_BLOCK_CPE_SIZE; i++) {

    pxNatPortForward = &pxNat->axPortBlockLan2Cpe[i];

    if (pxNatPortForward->bInUse == FALSE) {
      continue;
    }

    printf("%10d\t%8d\t%8s\n",
                pxNatPortForward->wPortBeg,
                pxNatPortForward->u.wPortEnd,
                _NatGetPortForwardProtName(pxNatPortForward->wFlags));
  }


  /*
   * Ports forwarded to LAN.
   */
  printf("Ports Forwarded to LAN:\n");
  printf("%10s\t%8s\t%8s\t%15s\n",
                "Port Start",
                "Port End",
                "Protocol",
                "LAN IP");
  printf("%10s\t%8s\t%8s\t%15s\n",
                "----------",
                "--------",
                "--------",
                "---------------");
  for (i = 0; i < NAT_PORT_FORWARD_LAN_SIZE; i++) {

    pxNatPortForward = &pxNat->axPortForwardLan[i];

    if (pxNatPortForward->bInUse == FALSE) {
      continue;
    }

    xInAddr.s_addr = pxNatPortForward->dwIp;
    printf("%10d\t%8d\t%8s\t%15s\n",
                pxNatPortForward->wPortBeg,
                pxNatPortForward->u.wPortEnd,
                _NatGetPortForwardProtName(pxNatPortForward->wFlags),
                inet_ntoa(xInAddr));
  }
}


/*****************************************************************************
Function:
        _NatGetPortForwardProtName()
Description:
        Returns the protocol support of a port forward binding
        in human readable form.
Arguments:
        WORD            wFlags                  Flags used by the
                                                port forward table
                                                entry.
Outputs:
        None
Returns:
        CHAR*                                   Supported protocol(s)
                                                in readable form.
Revisions:
        03-Nov-2001                             Initial
*****************************************************************************/
static CHAR* _NatGetPortForwardProtName(WORD wFlags)
{
  if ((wFlags & NAT_PORT_FORWARD_PROT_BOTH) == NAT_PORT_FORWARD_PROT_BOTH) {
    return ("BOTH");
  }

  if (wFlags & NAT_PORT_FORWARD_PROT_TCP) {
    return ("TCP");
  }

  if (wFlags & NAT_PORT_FORWARD_PROT_UDP) {
    return ("UDP");
  }

  return ("NONE");
}
#endif
