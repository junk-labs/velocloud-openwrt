/*
 * nat_utils.c
 *
 * Utility routines used/supported by NAT.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "nat.h"
#include "nat_defs.h"


/*****************************************************************************
Function:
        NatChecksumAdjust()
Description:
        Adjusts the checksum by doing only the necessary
        re-calculation.
Arguments:
        WORD            wChecksum       The input checksum
        WORD*           pwOldData       Start of old data which will
                                        be replaced in a packet.
        DWORD           dwOldLength     Size of old data to be
                                        replaced (in bytes).
        WORD*           pwNewData       Start of new data or
                                        replacement data.
        DWORD           dwNewLength     Size of new data (in bytes).
Outputs:
        None
Returns:
        WORD                            Adjusted checksum value.
Revisions:
        12-Oct-2001                     Initial
*****************************************************************************/
WORD NatChecksumAdjust(WORD wChecksum,
                       WORD* pwOldData,
                       DWORD dwOldLength,
                       WORD* pwNewData,
                       DWORD dwNewLength)
{
  LONG lChecksum;

  ASSERT((((DWORD) pwOldData & 0x1) == 0) &&
         (((DWORD) pwNewData & 0x1) == 0));

  lChecksum = ~wChecksum & 0xFFFF;

  while (dwOldLength) {

    if (dwOldLength == 1) {

      lChecksum -= (DWORD) (*pwOldData & 0xFF00);
      dwOldLength --;

    } else {

      lChecksum -= (DWORD) *pwOldData++;
      dwOldLength -= 2;

    }

    if (lChecksum <= 0) {
      lChecksum --;
      lChecksum &= 0xFFFF;
    }

    lChecksum = ((lChecksum >> 16) + (lChecksum & 0xFFFF)) & 0xFFFF;
  }


  while (dwNewLength) {

    if (dwNewLength == 1) {

      lChecksum += (DWORD) (*pwNewData & 0xFF00);
      dwNewLength --;

    } else {

      lChecksum += (DWORD) *pwNewData++;
      dwNewLength -= 2;

    }

    lChecksum = ((lChecksum >> 16) + (lChecksum & 0xFFFF)) & 0xFFFF;
  }

  return((WORD) ~lChecksum);
}


/*****************************************************************************
Function:
        NatFindTUBindingRx()
Description:
        Given the tuple (source Ip, destination Ip, source port,
        destination port), checks if there is an exisiting
        binding. If a binding is found, the corresponding
        session handle is returned, else returns a NULL.
        This function operates on packets received on the
        WAN interface.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        DWORD           dwSrcIp         Source Ip address in the
                                        received packet (WAN IP).
        WORD            wSrcPort        Source port in the
                                        received packet (WAN port).
        DWORD           dwDstIp         Destination Ip address in the
                                        received packet (Translated IP).
        WORD            wDstPort        Destination port in the
                                        received packet (Translated port).
        OCTET           oProtocol       Transport Layer Protocol.
Outputs:
        None
Returns:
        NAT_ENTRY*      non-NULL        Handle of the corresponding
                                        binding.
                        NULL            If no binding found.
Revisions:
        11-Oct-2001                     Initial
*****************************************************************************/
NAT_ENTRY* NatFindTUBindingRx(NATSTATE* pxNat,
                              DWORD dwSrcIp, WORD wSrcPort,
                              DWORD dwDstIp, WORD wDstPort,
                              OCTET oProtocol)
{
  DWORD dwIdx;
  NAT_ENTRY* pxNatEntry;
  BOOL bFound = FALSE;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
  {
    /*NAT_DBGP(DBGLVL_REPETITIVE, "NatFindTUBindingRx():wan=%ld.%ld.%ld.%ld:%d,trans=%ld.%ld.%ld.%ld:%d %s\n",
                        IPADDRDISPLAY(dwSrcIp), wSrcPort,
                        IPADDRDISPLAY(dwDstIp), wDstPort,
                        IpProtoToString(oProtocol));*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "NatFindTUBindingRx(): wan = ", dwSrcIp);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ":", wSrcPort);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", trans = ", dwDstIp);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ":", wDstPort);
    DEBUG_PRINT(DEBUG_MOC_IPV4, ", oProtocol = ");
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, IpProtoToString(oProtocol));
  }

  dwIdx = NAT_HASH_INDEX(dwDstIp ^ wDstPort);

  pxNatEntry = pxNat->apxTransHashTable[dwIdx];

  while (pxNatEntry) {

    if (((dwSrcIp == pxNatEntry->dwWanAddr) || (pxNatEntry->wFlags & NAT_WAN_IP_EMPTY)) &&
        (dwDstIp == pxNatEntry->dwTransAddr) &&
        ((wSrcPort == pxNatEntry->u.xTUMapping.wWanPort) || (pxNatEntry->wFlags & NAT_WAN_PORT_EMPTY)) &&
        (wDstPort == pxNatEntry->u.xTUMapping.wTransPort) &&
        (oProtocol == pxNatEntry->oProtocolId)) {
      bFound = TRUE;

      if ((pxNatEntry->wFlags & NAT_WAN_IP_EMPTY) && (dwSrcIp != 0)) {
        pxNatEntry->dwWanAddr = dwSrcIp;
        pxNatEntry->wFlags &= ~NAT_WAN_IP_EMPTY;
      }

      if ((pxNatEntry->wFlags & NAT_WAN_PORT_EMPTY) && (wSrcPort != 0)) {
        pxNatEntry->u.xTUMapping.wWanPort = wSrcPort;
        pxNatEntry->wFlags &= ~NAT_WAN_PORT_EMPTY;
      }
    }

    if (bFound == TRUE)
      break;

    pxNatEntry = pxNatEntry->pxTransNext;
  }

  NAT_DBG(DBGLVL_REPETITIVE, if (pxNatEntry) {
               printf("NatFindTUBindingRx():  Found Entry:lan=%ld.%ld.%ld.%ld:%d,wan=%ld.%ld.%ld.%ld:%d,trans=%ld.%ld.%ld.%ld:%d %s\n",
                        IPADDRDISPLAY(pxNatEntry->dwLanAddr), pxNatEntry->u.xTUMapping.wLanPort,
                        IPADDRDISPLAY(pxNatEntry->dwWanAddr), pxNatEntry->u.xTUMapping.wWanPort,
                        IPADDRDISPLAY(pxNatEntry->dwTransAddr), pxNatEntry->u.xTUMapping.wTransPort,
                        NatGetBindingName(pxNatEntry->eType));
             } else {
               printf("NatFindTUBindingRx(): No Entry\n");
             });

  return(pxNatEntry);
}


/*****************************************************************************
Function:
        NatFindTUBindingTx()
Description:
        Given the tuple (source Ip, destination Ip, source port,
        destination port), checks if there is an exisiting
        binding. If a binding is found, the corresponding
        session handle is returned, else returns a NULL.
        This function operates on packets to be transmitted on the
        WAN interface.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        DWORD           dwSrcIp         Source Ip address in the
                                        packet to be transmitted
                                        (LAN IP).
        WORD            wSrcPort        Source port in the
                                        packet to be transmitted
                                        (LAN port).
        DWORD           dwDstIp         Destination Ip address in the
                                        packet to be transmitted
                                        (WAN IP).
        WORD            wDstPort        Destination port in the
                                        packet to be transmitted
                                        (WAN port).
        OCTET           oProtocol       Transport Layer Protocol.
Outputs:
        None
Returns:
        NAT_ENTRY*      non-NULL        Handle of the corresponding
                                        binding.
                        NULL            If no binding found.
Revisions:
        11-Oct-2001                     Initial
*****************************************************************************/
NAT_ENTRY* NatFindTUBindingTx(NATSTATE* pxNat,
                              DWORD dwSrcIp, WORD wSrcPort,
                              DWORD dwDstIp, WORD wDstPort,
                              OCTET oProtocol)
{
  DWORD dwIdx;
  NAT_ENTRY* pxNatEntry;
  BOOL bFound = FALSE;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
  {
    /*NAT_DBGP(DBGLVL_REPETITIVE, "NatFindTUBindingTx():lan=%ld.%ld.%ld.%ld:%d,wan=%ld.%ld.%ld.%ld:%d %s\n",
                        IPADDRDISPLAY(dwSrcIp), wSrcPort,
                        IPADDRDISPLAY(dwDstIp), wDstPort,
                        IpProtoToString(oProtocol));*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "NatFindTUBindingTx(): lan = ", dwSrcIp);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ":", wSrcPort);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", wan = ", dwDstIp);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ":", wDstPort);
    DEBUG_PRINT(DEBUG_MOC_IPV4, ", oProtocol = ");
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, IpProtoToString(oProtocol));
  }

  dwIdx = NAT_HASH_INDEX(dwSrcIp ^ wSrcPort);
  ASSERT(dwIdx < NAT_HASH_SIZE);
  pxNatEntry = pxNat->apxLanHashTable[dwIdx];

  while (pxNatEntry) {
    if (((dwSrcIp == pxNatEntry->dwLanAddr) || (pxNatEntry->wFlags & NAT_LAN_IP_EMPTY)) &&
        ((dwDstIp == pxNatEntry->dwWanAddr) || (dwDstIp == 0) || (pxNatEntry->wFlags & NAT_WAN_IP_EMPTY)) &&
        ((wSrcPort == pxNatEntry->u.xTUMapping.wLanPort) || (pxNatEntry->wFlags & NAT_LAN_PORT_EMPTY)) &&
        ((wDstPort == pxNatEntry->u.xTUMapping.wWanPort) || (wDstPort == 0) || (pxNatEntry->wFlags & NAT_WAN_PORT_EMPTY)) &&
        (oProtocol == pxNatEntry->oProtocolId)) {
      bFound = TRUE;

      if ((pxNatEntry->wFlags & NAT_WAN_IP_EMPTY) && (dwDstIp != 0)) {
        pxNatEntry->dwWanAddr = dwDstIp;
        pxNatEntry->wFlags &= ~NAT_WAN_IP_EMPTY;
      }

      if ((pxNatEntry->wFlags & NAT_WAN_PORT_EMPTY) && (wDstPort != 0)) {
        pxNatEntry->u.xTUMapping.wWanPort = wDstPort;
        pxNatEntry->wFlags &= ~NAT_WAN_PORT_EMPTY;
      }

      if ((pxNatEntry->wFlags & NAT_LAN_IP_EMPTY) && (dwSrcIp != 0)) {
        pxNatEntry->dwLanAddr = dwSrcIp;
        pxNatEntry->wFlags &= ~NAT_LAN_IP_EMPTY;
      }

      if ((pxNatEntry->wFlags & NAT_LAN_PORT_EMPTY) && (wSrcPort != 0)) {
        pxNatEntry->u.xTUMapping.wLanPort = wSrcPort;
        pxNatEntry->wFlags &= ~NAT_LAN_PORT_EMPTY;
      }
    }

    if (bFound == TRUE)
      break;

    pxNatEntry = pxNatEntry->pxLanNext;
  }

  NAT_DBG(DBGLVL_REPETITIVE, if (pxNatEntry) {
               printf("NatFindTUBindingTx():  Found Entry:lan=%ld.%ld.%ld.%ld:%d,wan=%ld.%ld.%ld.%ld:%d,trans=%ld.%ld.%ld.%ld:%d %s\n",
                        IPADDRDISPLAY(pxNatEntry->dwLanAddr), pxNatEntry->u.xTUMapping.wLanPort,
                        IPADDRDISPLAY(pxNatEntry->dwWanAddr), pxNatEntry->u.xTUMapping.wWanPort,
                        IPADDRDISPLAY(pxNatEntry->dwTransAddr), pxNatEntry->u.xTUMapping.wTransPort,
                        NatGetBindingName(pxNatEntry->eType));
             } else {
               printf("NatFindTUBindingTx(): No Entry\n");
             });


  return(pxNatEntry);
}


/*****************************************************************************
Function:
        NatFindIcmpQueryBindingRx()
Description:
        Given the tuple (source Ip, destination Ip,
        ICMP Query Identifier), checks if there is an exisiting
        binding. If a binding is found, the corresponding
        session handle is returned, else returns a NULL.
        This function operates on packets received on the
        WAN interface.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        DWORD           dwSrcIp         Source Ip address in the
                                        received packet (WAN IP).
        DWORD           dwDstIp         Destination Ip address in the
                                        received packet (Translated IP).
        WORD            wQeuryId        Query identifier in the ICMP
                                        header (Translated Query Id.).
        OCTET           oProtocol       Transport Layer Protocol.
Outputs:
        None
Returns:
        NAT_ENTRY*      non-NULL        Handle of the corresponding
                                        binding.
                        NULL            If no binding found.
Revisions:
        16-Oct-2001                     Initial
*****************************************************************************/
NAT_ENTRY* NatFindIcmpQueryBindingRx(NATSTATE* pxNat,
                                     DWORD dwSrcIp, DWORD dwDstIp,
                                     WORD wQueryId, OCTET oProtocol)
{
  DWORD dwIdx;
  NAT_ENTRY* pxNatEntry;

  dwIdx =  NAT_HASH_INDEX(dwDstIp);

  pxNatEntry = pxNat->apxTransHashTable[dwIdx];

  while (pxNatEntry) {
    if ((dwSrcIp == pxNatEntry->dwWanAddr) &&
        (dwDstIp == pxNatEntry->dwTransAddr) &&
        (wQueryId == pxNatEntry->u.xIcmpMapping.wTransMsgId) &&
        (oProtocol == pxNatEntry->oProtocolId)) {
      break;
    }

    pxNatEntry = pxNatEntry->pxTransNext;
  }

  NAT_DBG(DBGLVL_REPETITIVE, if (pxNatEntry) {
               printf("NatFindICMPQueryBindingRx():  Found Entry
lan=%ld.%ld.%ld.%ld,wan=%ld.%ld.%ld.%ld,trans=%ld.%ld.%ld.%ld msgid=%d transmsgid=%d\n",
                        IPADDRDISPLAY(pxNatEntry->dwLanAddr),
                        IPADDRDISPLAY(pxNatEntry->dwWanAddr),
                        IPADDRDISPLAY(pxNatEntry->dwTransAddr),
                        pxNatEntry->u.xIcmpMapping.wMsgId,
                        pxNatEntry->u.xIcmpMapping.wTransMsgId);
             } else {
               printf("NatFindICMPQueryBindingRx(): No Entry\n");
             });

  return(pxNatEntry);
}


/*****************************************************************************
Function:
        NatFindIcmpQueryBindingTx()
Description:
        Given the tuple (source Ip, destination Ip,
        ICMP Query Identifier), checks if there is an exisiting
        binding. If a binding is found, the corresponding
        session handle is returned, else returns a NULL.
        This function operates on packets transmitted to the
        WAN interface.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        DWORD           dwSrcIp         Source Ip address in the
                                        packet to be transmitted
                                        (LAN IP).
        DWORD           dwDstIp         Destination Ip address in the
                                        packet to be tansmitted
                                        (WAN IP).
        WORD            wQueryId        Query identifier in the ICMP
                                        header (Original Query Id.).
        OCTET           oProtocol       Transport Layer Protocol.
Outputs:
        None
Returns:
        NAT_ENTRY*      non-NULL        Handle of the corresponding
                                        binding.
                        NULL            If no binding found.
Revisions:
        16-Oct-2001                     Initial
*****************************************************************************/
NAT_ENTRY* NatFindIcmpQueryBindingTx(NATSTATE* pxNat,
                                     DWORD dwSrcIp, DWORD dwDstIp,
                                     WORD wQueryId, OCTET oProtocol)
{
  DWORD dwIdx;
  NAT_ENTRY* pxNatEntry;

  dwIdx = NAT_HASH_INDEX(dwSrcIp);
  ASSERT(dwIdx < NAT_HASH_SIZE);
  pxNatEntry = pxNat->apxLanHashTable[dwIdx];

  while (pxNatEntry) {
    if ((dwSrcIp == pxNatEntry->dwLanAddr) &&
        (dwDstIp == pxNatEntry->dwWanAddr) &&
        (wQueryId == pxNatEntry->u.xIcmpMapping.wMsgId) &&
        (oProtocol == pxNatEntry->oProtocolId)) {
      break;
    }

    pxNatEntry = pxNatEntry->pxLanNext;
  }

  NAT_DBG(DBGLVL_REPETITIVE, if (pxNatEntry) {
               printf("NatFindICMPQueryBindingTx():  Found Entry
lan=%ld.%ld.%ld.%ld,wan=%ld.%ld.%ld.%ld,trans=%ld.%ld.%ld.%ld msgid=%d transmsgid=%d\n",
                        IPADDRDISPLAY(pxNatEntry->dwLanAddr),
                        IPADDRDISPLAY(pxNatEntry->dwWanAddr),
                        IPADDRDISPLAY(pxNatEntry->dwTransAddr),
                        pxNatEntry->u.xIcmpMapping.wMsgId,
                        pxNatEntry->u.xIcmpMapping.wTransMsgId);
             } else {
               printf("NatFindICMPQueryBindingTx(): No Entry\n");
             });

  return(pxNatEntry);
}


/*****************************************************************************
Function:
        NatIsTransPortInRange()
Description:
        Check if the given port is in the range of port
        numbers allocated for NAT.
Arguments:
        WORD            wPort           Port number to be checked.
Outputs:
        None
Returns:
        BOOL            TRUE            If port is in range.
                        FALSE           If port is not in range.
Revisions:
        16-Oct-2001                     Initial
*****************************************************************************/
BOOL NatIsTransPortInRange(WORD wPort)
{
  return (((wPort >= NAT_PORT_BASE) &&
           (wPort < (NAT_PORT_BASE + NAT_NUM_ALLOCATED_PORTS))) ?
          (TRUE) : (FALSE));
}



/*****************************************************************************
Function:
        NatHash()
Description:
        Evaluates the hashing function.
Arguments:
        DWORD           dwAddr          Ip address.
        WORD            wPort           Port number
                                        (not used for ICMP).
        OCTET           oProtocol       Protocol Id.
Outputs:
        None
Returns:
        DWORD                           Index into hash table.
Revisions:
        25-Oct-2001                     Initial
*****************************************************************************/
DWORD NatHash(DWORD dwAddr, WORD wPort, OCTET oProtocol)
{
  switch (oProtocol) {

    case IPPROTO_UDP:
    case IPPROTO_TCP:
      return (NAT_HASH_INDEX(dwAddr ^ wPort));

    case IPPROTO_ICMP:
      return (NAT_HASH_INDEX(dwAddr));

    default:
      ASSERT(0);
  }

  return (0);
}


/*****************************************************************************
Function:
        NatDeleteFromTransHashTable()
Description:
        Deletes the given binding from the hash tables which
        are based on the WAN Ip address of the CPE.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        NAT_ENTRY*      pxNatEntry      NAT binding.
Outputs:
        None
Returns:
        None
Revisions:
        17-Dec-2001                     Split out from NatDeleteBinding().
*****************************************************************************/
void NatDeleteFromTransHashTable(NATSTATE* pxNat, NAT_ENTRY* pxNatEntry)
{
  DWORD dwIdx;
  NAT_ENTRY* pxNatHash;

  dwIdx = NatHash(pxNatEntry->dwTransAddr,
                  pxNatEntry->u.xTUMapping.wTransPort,  /* ignored for ICMP */
                  pxNatEntry->oProtocolId);
  ASSERT(dwIdx < NAT_HASH_SIZE);

  pxNatHash = pxNat->apxTransHashTable[dwIdx];

  if (pxNatHash == pxNatEntry) {

    pxNat->apxTransHashTable[dwIdx] = pxNatEntry->pxTransNext;

  } else {

    while (pxNatHash->pxTransNext) {
      if (pxNatHash->pxTransNext == pxNatEntry)
        break;
      pxNatHash = pxNatHash->pxTransNext;
    }

    ASSERT(pxNatHash->pxTransNext);
    pxNatHash->pxTransNext = pxNatEntry->pxTransNext;
  }
}


/*****************************************************************************
Function:
        NatDeleteFromLanHashTable()
Description:
        Deletes the given binding from the hash tables which
        are based on the Ip address of the LAN host.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        NAT_ENTRY*      pxNatEntry      NAT binding.
Outputs:
        None
Returns:
        None
Revisions:
        17-Dec-2001                     Split out from NatDeleteBinding().
*****************************************************************************/
void NatDeleteFromLanHashTable(NATSTATE* pxNat, NAT_ENTRY* pxNatEntry)
{
  DWORD dwIdx;
  NAT_ENTRY* pxNatHash;

  dwIdx = NatHash(pxNatEntry->dwLanAddr,
                  pxNatEntry->u.xTUMapping.wLanPort,    /* ignored for ICMP */
                  pxNatEntry->oProtocolId);
  ASSERT(dwIdx < NAT_HASH_SIZE);

  pxNatHash = pxNat->apxLanHashTable[dwIdx];

  if (pxNatHash == pxNatEntry) {

    pxNat->apxLanHashTable[dwIdx] = pxNatEntry->pxLanNext;

  } else {

    while (pxNatHash->pxLanNext) {
      if (pxNatHash->pxLanNext == pxNatEntry)
        break;
      pxNatHash = pxNatHash->pxLanNext;
    }

    ASSERT(pxNatHash->pxLanNext);
    pxNatHash->pxLanNext = pxNatEntry->pxLanNext;
  }
}


/*****************************************************************************
Function:
        NatClearBindingTable()
Description:
        Deletes all the bindings.
Arguments:
        NATSTATE*       pxNat           NAT instance handle
Outputs:
        None
Returns:
        None
Revisions:
        07-Apr-2002                     Initial
*****************************************************************************/
void NatClearBindingTable(NATSTATE* pxNat)
{
  DWORD dwIdx;
  NAT_ENTRY *pxNatEntry, *pxNextEntry;

  /*
   * NOTE: All the NAT table activity happens in the network
   *       thread except for the termination. Using a mutex
   *       will have significant impact on the performance.
   *       Will this routine ever be called other than at
   *       end of time?
   */
  for (dwIdx = NAT_HASH_SIZE; dwIdx > 0; dwIdx --) {

    if ((pxNatEntry = pxNat->apxLanHashTable[dwIdx - 1]) != NULL) {

      while (pxNatEntry) {
        pxNextEntry = pxNatEntry->pxLanNext;
        NatDeleteBinding(pxNat, pxNatEntry);
        pxNatEntry = pxNextEntry;
      }

    }
  }

#ifdef NATDBG_HI
  for (dwIdx = NAT_HASH_SIZE; dwIdx > 0; dwIdx --) {
    ASSERT(pxNat->apxTransHashTable[dwIdx - 1] == NULL);
  }
#endif

  return;
}


/*****************************************************************************
Function:
        NatClearIfBindings()
Description:
        Deletes all the bindings pertaining to a certain interface.
        Should be called when an interface is being torn down.
Arguments:
        NATSTATE*       pxNat           NAT instance handle
        OCTET           oIfIdx          Index of interface being torn down.
Outputs:
        None
Returns:
        None
Revisions:
        17-Dec-2001                     Initial
*****************************************************************************/
void NatClearIfBindings(NATSTATE* pxNat, OCTET oIfIdx)
{
  DWORD dwIdx;
  NAT_ENTRY *pxNatEntry, *pxNextEntry;

  /*
   * Delete all bindings which match the given interface index
   * which is being torn down.
   */
  for (dwIdx = NAT_HASH_SIZE; dwIdx > 0; dwIdx --) {
    if ((pxNatEntry = pxNat->apxTransHashTable[dwIdx - 1]) != NULL) {
      while (pxNatEntry) {
        if (pxNatEntry->oIfIdx == oIfIdx) {
          pxNextEntry = pxNatEntry->pxTransNext;
          NatDeleteBinding(pxNat, pxNatEntry);
          pxNatEntry = pxNextEntry;
        } else {
          pxNatEntry = pxNatEntry->pxTransNext;
        }
      }
    }
  }
}


/*****************************************************************************
Function:
        NatDeleteChunk()
Description:
        Deletes all the bindings pertaining to a chunk and cleans up the
        chunk.
Arguments:
        NATSTATE*       pxNat           NAT instance handle
        NAT_CHUNK*      pxNatChunk      NAT chunk handle
Outputs:
        None
Returns:
        None
Revisions:
        23-Aug-2002                     Initial
*****************************************************************************/
void NatDeleteChunk(NATSTATE* pxNat, NAT_CHUNK* pxNatChunk)
{
  LONG lIdx, lPos;

  for (lIdx = (NAT_CHUNK_NUM_BINDINGS >> 5) - 1; lIdx >= 0; lIdx --) {

    for (lPos = (8 * sizeof(DWORD)) - 1; lPos >= 0; lPos --)  {

      if (pxNatChunk->adwBindingStatus[lIdx] & (1 << lPos)) {
        /*
         * active binding, wipe it out
         */
        NatDeleteBinding(pxNat, &pxNatChunk->axNatBindings[(lIdx << 5) + lPos]);
        ASSERT((pxNatChunk->adwBindingStatus[lIdx] & (1 << lPos)) == 0);
      }
    }
  }

  FREE(pxNatChunk);
}


#ifdef NATDBG_HI
/*****************************************************************************
Function:
        NatGetBindingName()
Description:
        Returns the type of NAT binding in human readable form.
Arguments:
        E_NAT_BINDING   eType           Type of binding.
Outputs:
        None
Returns:
        CHAR*                           Type of NAT binding
                                        in text form.
Revisions:
        24-Oct-2001                     Initial
*****************************************************************************/
CHAR* NatGetBindingName(E_NAT_BINDING eType)
{
  switch (eType) {

    case NAT_BINDING_LOCAL:
      return ("LOCAL");

    case NAT_BINDING_W2L:
      return ("W2L");

    case NAT_BINDING_L2W:
      return ("L2W");

    default:
      return ("NAT_BINDING_UNKNOWN");
  }

  return ("NAT_BINDING_UNKNOWN");
}


/*****************************************************************************
Function:
        NatDisplayBindings()
Description:
        Displays all the exisiting bindings.
Arguments:
        NATSTATE*       pxNat           NAT instance handle
Outputs:
        None
Returns:
        None
Revisions:
        25-Oct-2001                     Initial
*****************************************************************************/
void NatDisplayBindings(NATSTATE* pxNat)
{
  LONG lIdx;
  NAT_ENTRY* pxNatEntry;

  printf("Active NAT Bindings\n");

  for (lIdx = NAT_HASH_SIZE - 1; lIdx >= 0; lIdx --) {

    if ((pxNatEntry = pxNat->apxLanHashTable[lIdx]) != NULL) {

      while (pxNatEntry) {

        switch(pxNatEntry->oProtocolId) {

          case IPPROTO_UDP:
          case IPPROTO_TCP:
            printf("%ld.%ld.%ld.%ld:%d  %ld.%ld.%ld.%ld:%d  %ld.%ld.%ld.%ld:%d  %s  %s\n",
                        IPADDRDISPLAY(pxNatEntry->dwLanAddr),
                        pxNatEntry->u.xTUMapping.wLanPort,
                        IPADDRDISPLAY(pxNatEntry->dwWanAddr),
                        pxNatEntry->u.xTUMapping.wWanPort,
                        IPADDRDISPLAY(pxNatEntry->dwTransAddr),
                        pxNatEntry->u.xTUMapping.wTransPort,
                        IpProtoToString(pxNatEntry->oProtocolId),
                        NatGetBindingName(pxNatEntry->eType));

            break;

          case IPPROTO_ICMP:
            printf("%ld.%ld.%ld.%ld  %ld.%ld.%ld.%ld  %ld.%ld.%ld.%ld  %d  %d  %s  %s\n",
                        IPADDRDISPLAY(pxNatEntry->dwLanAddr),
                        IPADDRDISPLAY(pxNatEntry->dwWanAddr),
                        IPADDRDISPLAY(pxNatEntry->dwTransAddr),
                        pxNatEntry->u.xIcmpMapping.wMsgId,
                        pxNatEntry->u.xIcmpMapping.wTransMsgId,
                        IpProtoToString(pxNatEntry->oProtocolId),
                        NatGetBindingName(pxNatEntry->eType));
            break;

          default:
            ASSERT(0);
            break;
        }

        pxNatEntry = pxNatEntry->pxLanNext;
      }
    }
  }
}
#endif
