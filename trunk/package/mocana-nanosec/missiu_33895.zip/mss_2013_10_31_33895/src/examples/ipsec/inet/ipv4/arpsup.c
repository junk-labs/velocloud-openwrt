/*
 * arpsup.c
 *
 * ARP module implementation
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



#include "arpdefs.h"

#ifdef __MOC_CLI__
/*
 * Function converts the type of entry within the table into a meaningful "name"
 * Input Parameters:
 * wArpType : Type within the table.
 * Return:
 * ubyte * : String representation of "Type". Memory for string is not allocated, but is null terminated.
 */
ubyte* _ArpDecipherType(ubyte2 dwArpType);
#endif

/***************************************************************************
*  Delete an ARP mapping entry in the cache.
*
*  par: pxArp            Arp instance struct
*       pxArpEntryPrev   the previous ARPENTRY
*       pxArpEntryDel    the ARPENTRY to delete
*       nArpHashIdx      The hash table index of pxArpEntryDel
*
*  ret: void
****************************************************************************/
void ArpDelete(ARPSTATE *pxArp, ARPENTRYSTATE *pxArpEntryPrev,
               ARPENTRYSTATE *pxArpEntryDel, int nArpHashIdx)
{

  ARP_CHECK_STATE(pxArp);
  ARP_DBG_ASSERT(pxArpEntryPrev != NULL && pxArpEntryDel != NULL);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ARP_DBGP(DBGLVL_REPETITIVE,
           "ArpDelete: entered for *ppLapt 0x%p, pxArpEntryDel 0x%p, idx %d\n",
           pxArpEntryPrev, pxArpEntryDel, nArpHashIdx);*/
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "ArpDelete: entered for *ppLapt 0x", (int) pxArpEntryPrev,
                           ", pxArpEntryDel 0x", (int)pxArpEntryDel);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", idx ", nArpHashIdx);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }
#ifdef ARP_CACHE_32
  ASSERT(nArpHashIdx < pxArp->oArpHashSize);
#else
  ASSERT(nArpHashIdx < pxArp->wArpHashSize);
#endif
  if (pxArp->apxArpHashTable[nArpHashIdx] == pxArpEntryDel) {
    pxArp->apxArpHashTable[nArpHashIdx] = pxArpEntryDel->pxNext;
  }
  else {
    pxArpEntryPrev->pxNext = pxArpEntryDel->pxNext;
  }

#ifdef ARP_CACHE_32
  /* Clear entry from pArpTable */
  MOC_MEMSET(((ubyte *) pxArpEntryDel), 0x00, sizeof(ARPENTRYSTATE));

  /* Add this ARPENTRY to the free list */
  pxArpEntryDel->pxNext = pxArp->pxFirstFreeArpEntry;
  pxArp->pxFirstFreeArpEntry = pxArpEntryDel;
#else
  MOC_FREE((void **)&pxArpEntryDel); /*Ajit: We might have to check this up*/
#endif
  ARP_DBG_VAR(
    dbg_dwArpNumCurrentEntries--;
  );
  return;
}

/***************************************************************************
*  update the entries in the arp table
*
*  par: void
*
*  ret: void
****************************************************************************/
void ArpRefreshTable(ARPSTATE *pxArp)
{
  ARPENTRYSTATE *pxArpEntry;
  ARPENTRYSTATE **ppxArpEntry;
  INT i = 0;
  DWORD dwTime;

  ARP_CHECK_STATE(pxArp);
#ifdef ARP_CACHE_32
  ASSERT(pxArp->oArpHashSize > (OCTET)0 && pxArp->apxArpHashTable != NULL);
#else
  ASSERT(pxArp->wArpHashSize > (OCTET)0 && pxArp->apxArpHashTable != NULL);
#endif

  /*dwTime = (DWORD)NetGlobalTimerGet();*/
  dwTime = (DWORD)NetGetMsecTime();

  ARP_CHECKPOINT(dbg_dwArpRefreshLine);
#ifdef ARP_CACHE_32
  for (i = 0; i < pxArp->oArpHashSize; i++) {
#else
  for (i = 0; i < pxArp->wArpHashSize; i++) {
#endif
    ppxArpEntry = &(pxArp->apxArpHashTable[i]);
    ARP_DBG_ASSERT(ppxArpEntry != NULL);
    while ((pxArpEntry = *ppxArpEntry) != NULL) {
      if (dwTime - pxArpEntry->dwLastUsed > ARPTIME_MAXAGE) {
#ifdef ARP_REQ_ON_TIMEOUT
        /* try to reacquire ARP resolution before deleting from table*/
        if (ARPENTRY_REACQUIRE != pxArpEntry->eState) {
          IPTABLEENTRY xIpEntry;

          xIpEntry.oIfIdx = pxArpEntry->xEntry.oIfIdx;
          xIpEntry.wDefaultVlan = pxArpEntry->xEntry.wVlan;
          xIpEntry.dwAddr = pxArpEntry->xEntry.dwIpAddr;

          /* check ARP entry has been read/used since last refreshed */
          if ((ARPENTRY_READ == pxArpEntry->eState) &&
              (IPADDRT_MYSUBNET == (OCTET) IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry))) {
            ARPREQUEST xArpRequest;
            pxArpEntry->eState = ARPENTRY_REACQUIRE;
            xArpRequest.xEntry.oIfIdx = pxArpEntry->xEntry.oIfIdx;
            xArpRequest.xEntry.wVlan = pxArpEntry->xEntry.wVlan;
            xArpRequest.xEntry.dwIpAddr = pxArpEntry->xEntry.dwIpAddr;
            /* addresses from table can only be on local subnet */
            xArpRequest.dwGatewayAddr = 0;
            xArpRequest.eAddrType = 0;

            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
            {
              /*ARP_DBGP(DBGLVL_REPETITIVE,
                     "ArpRefreshTable: timed out so re-resolve %ld.%ld.%ld.%ld\n",
                     IPADDRDISPLAY(pxArpEntry->xEntry.dwIpAddr));*/
              DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "ArpRefreshTable: timed out so re-resolve ",
                                        pxArpEntry->xEntry.dwIpAddr);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
            }

            ArpInstanceMsg((H_NETINSTANCE)pxArp,ARPMSG_REACQUIRE,(H_NETDATA)&xArpRequest);
            ppxArpEntry = &pxArpEntry->pxNext;
          } else {
            if(pxArpEntry->xEntry.eArpFlag != E_ARPLOCAL) { /*Ajit: Code change, chck introduced before clean up of Arp entry*/
                if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_ERROR))
                {
                  /*ARP_DBGP(DBGLVL_ERROR_RARE,
                         "ArpRefreshTable: del entry for ip = %ld.%ld.%ld.%ld : at time : %u\n",
                         IPADDRDISPLAY(pxArpEntry->xEntry.dwIpAddr),
                         (dwTime - pxArpEntry->dwLastUsed)); Moved from else to if part*/
                  DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "ArpRefreshTable: del entry for ip = ",
                                            pxArpEntry->xEntry.dwIpAddr);
                  DEBUG_PRINT(DEBUG_MOC_IPV4, " : at time : ");
                  DEBUG_UINT(DEBUG_MOC_IPV4, (dwTime - pxArpEntry->dwLastUsed));
                  DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
                }
                ArpDelete(pxArp, (ARPENTRYSTATE *)ppxArpEntry, pxArpEntry, i);
                if (pxArpEntry == *ppxArpEntry) {
                    ppxArpEntry = &pxArpEntry->pxNext;
                }
            } else {
              /*Indicates that the entry that we are looking at is Local, so increment the timer*/
              pxArpEntry->dwLastUsed = dwTime;
              ppxArpEntry = &pxArpEntry->pxNext; /*Ajit: Code change, "else" part brought in for moving the pointer to the next entry*/
            }
          }
        } else {
          ppxArpEntry = &pxArpEntry->pxNext;
        }
      } else {
        ppxArpEntry = &pxArpEntry->pxNext;
      }
#else
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_ERROR))
        {
          /*ARP_DBGP(DBGLVL_ERROR_RARE,
                 "ArpRefreshTable: del entry for ip = %ld.%ld.%ld.%ld\n",
                 IPADDRDISPLAY(pxArpEntry->xEntry.dwIpAddr));*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "ArpRefreshTable: del entry for ip = ",
                                    pxArpEntry->xEntry.dwIpAddr);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }

        ArpDelete(pxArp, (ARPENTRYSTATE *)ppxArpEntry, pxArpEntry, i);
        if (pxArpEntry == *ppxArpEntry)
          ppxArpEntry = &pxArpEntry->pxNext;
      }
      else
        ppxArpEntry = &pxArpEntry->pxNext;
#endif
    }
  } /*end of "for" loop, for looping through the entries within hash table*/
  ARP_CHECKPOINT(dbg_dwArpRefreshLine);
}

#ifdef ARP_REQ_ON_TIMEOUT
/***************************************************************************
* ArpDeleteIfExist
*
*  delete an entry from the arp table if it exists
*
*  param:  pxArpEntry  - Arp Entry to be deleted if exists.
*
*  ret: void
****************************************************************************/
void ArpDeleteIfExist(ARPSTATE *pxArp, ARPENTRY *pxArpEntry)
{
  ARPENTRYSTATE *pxArpEntryState;
  ARPENTRYSTATE **ppxArpEntryState;
  DWORD dwHash;

  ARP_CHECK_STATE(pxArp);

  /* Loop through the table for the desired address. */
#ifdef ARP_CACHE_32
  dwHash = pxArpEntry->dwIpAddr & (pxArp->oArpHashSize - 1);
#else
  dwHash = pxArpEntry->dwIpAddr & (pxArp->wArpHashSize - 1);
#endif

  ppxArpEntryState = &(pxArp->apxArpHashTable[dwHash]);
  ARP_DBG_ASSERT(ppxArpEntryState != NULL);

  while ((pxArpEntryState = *ppxArpEntryState) != NULL) {
    if (ArpEntryMatch(&(pxArpEntryState->xEntry),
                      pxArpEntry->dwIpAddr,
                      pxArpEntry->oIfIdx,
                      pxArpEntry->wVlan)) {
      /* ARP entry found now delete */
      ArpDelete(pxArp, (ARPENTRYSTATE *)ppxArpEntryState, pxArpEntryState, dwHash);
      if (pxArpEntryState == *ppxArpEntryState)
        ppxArpEntryState = &pxArpEntryState->pxNext;
      break;
    }
    else
      ppxArpEntryState = &pxArpEntryState->pxNext;
  }
}
#endif

/***************************************************************************
*  Create an ARP entry.  The caller should check for duplicates!
*
*  par: dwIpAddr   IP address
*       aoEthAddr  MAC addr
*       oIfIdx     interface index
*       wVlan      coresponding Vlan
*
*  ret: ARPENTRYSSTATE *created
****************************************************************************/
/*Ajit:Code Changed, change within the definition of the func.*/
ARPENTRYSTATE *ArpCreate(ARPSTATE *pxArp, DWORD dwIpAddr, OCTET *aoEthAddr,
                          OCTET oIfIdx, WORD wVlan, ARPENTRYFLAG eArpFlag)
{
  DWORD dwHash, dwMin = 0xFFFFFFFF;
  ARPENTRYSTATE *pxFreeArpEntry = NULL,
    **ppxArpEntry, *pxArpEntry, *pxPrevFreeArpEntry = NULL;
  INT i, nHashIdx = -1;
  MSTATUS msMallocRet = 0;

  ARP_CHECK_STATE(pxArp);

#ifdef ARP_CACHE_32
  pxFreeArpEntry = pxArp->pxFirstFreeArpEntry;
  if (NULL != pxFreeArpEntry) {
    pxArp->pxFirstFreeArpEntry = pxArp->pxFirstFreeArpEntry->pxNext;
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ARP_DBGP(DBGLVL_REPETITIVE,
             "ArpCreate: Table Not full next first free entry 0x%p\n",
             pxArp->pxFirstFreeArpEntry);*/
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "ArpCreate: Table Not full next first free entry 0x",
                             (ubyte4)pxArp->pxFirstFreeArpEntry);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
  } else  {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ARP_DBGP(DBGLVL_REPETITIVE,
             "ArpCreate: Table full next first free entry 0x%p\n",
             pxArp->pxFirstFreeArpEntry);*/
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "ArpCreate: Table full next first free entry 0x",
                             (ubyte4)pxArp->pxFirstFreeArpEntry);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
    /* The Table is full, Use LRU to delete least recently used entry */
    /* Find Least recently used entry */
    for (i=0; i<pxArp->oArpHashSize; i++) {
      ppxArpEntry = &(pxArp->apxArpHashTable[i]);
      while ((pxArpEntry = *ppxArpEntry) != NULL) {
        if (pxArpEntry->dwLastUsed < dwMin) {
          dwMin = pxArpEntry->dwLastUsed;
          pxFreeArpEntry = pxArpEntry;
          pxPrevFreeArpEntry = (ARPENTRYSTATE *) ppxArpEntry;
          nHashIdx = i;
        }
        ppxArpEntry = &pxArpEntry->pxNext;
      }
    }
    /* Free that entry, verify success */
    ArpDelete(pxArp, (ARPENTRYSTATE *)pxPrevFreeArpEntry,
              pxFreeArpEntry, nHashIdx);
    if (!pxArp->pxFirstFreeArpEntry)
      return NULL;
    pxArp->pxFirstFreeArpEntry = NULL;
  }
  dwHash = dwIpAddr & (pxArp->oArpHashSize - 1);
#else
   /*Allocate memory for ARPENTRYSTATE*/
  msMallocRet = MOC_MALLOC((void**)&pxFreeArpEntry, sizeof(ARPENTRYSTATE));
  if(OK == msMallocRet) {
    MOC_MEMSET((ubyte*)pxFreeArpEntry, 0, sizeof(ARPENTRYSTATE));
  } else {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ARP_DBGP(DBGLVL_REPETITIVE,
             "ArpCreate: Unable to create memory for ArpStateEntry, MOC_MALLOC returned error: %d \n",
             msMallocRet);*/
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "ArpCreate: Unable to create memory for ArpStateEntry, MOC_MALLOC returned error: ",
                          msMallocRet);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
    return NULL;
  }
  dwHash = dwIpAddr & (pxArp->wArpHashSize - 1);
#endif

  /* Fill in the allocated ARP cache entry. */
  pxFreeArpEntry->xEntry.dwIpAddr = dwIpAddr;
  MOC_MEMCPY((ubyte *)pxFreeArpEntry->xEntry.aoEthAddr,
        (ubyte *) aoEthAddr, ARP_ETHLEN);
  pxFreeArpEntry->xEntry.oIfIdx = oIfIdx;
  pxFreeArpEntry->xEntry.wVlan = wVlan;
  /*pxFreeArpEntry->dwLastUsed = (DWORD)NetGlobalTimerGet();*/
  pxFreeArpEntry->dwLastUsed = (DWORD)NetGetMsecTime();
  pxFreeArpEntry->xEntry.eArpFlag = eArpFlag; /*Ajit: Code changed*/
#ifdef ARP_REQ_ON_TIMEOUT
  pxFreeArpEntry->eState = ARPENTRY_REFRESHED;
#endif
  pxFreeArpEntry->pxNext = pxArp->apxArpHashTable[dwHash];
  pxArp->apxArpHashTable[dwHash] = pxFreeArpEntry;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ARP_DBGP(DBGLVL_REPETITIVE,
           "ArpCreate: Adding entry at 0x%p for dwHash %lu, dwAddr:%ld.%ld.%ld.%ld, arpFlag:%d \n",
           pxFreeArpEntry, dwHash, IPADDRDISPLAY(dwIpAddr), eArpFlag);*/
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "ArpCreate: Adding entry at 0x", (int)pxFreeArpEntry);
    DEBUG_PRINT(DEBUG_MOC_IPV4, "for dwHash ");
    DEBUG_UINT(DEBUG_MOC_IPV4, dwHash);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", dwAddr :", dwIpAddr);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", arpFlag : ", eArpFlag);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_NORMAL))
  {
    /*ARP_DBGP(DBGLVL_NORMAL,
           "ArpCreate: Creating entry %ld.%ld.%ld.%ld Eth.= %02x:%02x:%02x:%02x:%02x:%02x\n",
           IPADDRDISPLAY(dwIpAddr),
           HWADDRDISPLAY(aoEthAddr));*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "ArpCreate: Creating entry ", dwIpAddr);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, " Eth.= ", aoEthAddr[0],
                           ":", aoEthAddr[1]);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", aoEthAddr[2],
                           ":", aoEthAddr[3]);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", aoEthAddr[4],
                           ":", aoEthAddr[5]);
  }

  /* Print out the ARP table every time a new address is added -
   * only if the debug level is DBGLVL_REPETITIVE */
  ARP_DBG(DBGLVL_REPETITIVE, dbg_dwArpPrintTable = 1);

  ARP_DBG_VAR(
    dbg_dwArpNumCurrentEntries++;
    if ( dbg_dwArpNumCurrentEntries > dbg_dwArpMaxEntries)
      dbg_dwArpMaxEntries = dbg_dwArpNumCurrentEntries;
  );

  return pxFreeArpEntry; /* successful */
}


/***************************************************************************
*  Add an entry to the ARP cache.  Check for dupes!
*
*  par: pxArp        Arp state pointer
*       pxArpEntry   Arp entry to add
*
*  ret: void
****************************************************************************/
void ArpAdd(ARPSTATE *pxArp,ARPENTRY *pxArpEntry)
{
  ARPENTRYSTATE *pxArpEntryState;

  ARP_CHECK_STATE(pxArp);

  /* This is probably a good check... */
  if (pxArpEntry->dwIpAddr == 0) {
    return;
  }

  /* First see if the address is already in the table. */
  pxArpEntryState = ArpLookup(pxArp, pxArpEntry->dwIpAddr,
                              pxArpEntry->oIfIdx,pxArpEntry->wVlan);
  if (NULL  != pxArpEntryState) {
    /*pxArpEntryState->dwLastUsed = (DWORD)NetGlobalTimerGet();*/
    pxArpEntryState->dwLastUsed = (DWORD)NetGetMsecTime();

    MOC_MEMCPY((ubyte *)pxArpEntryState->xEntry.aoEthAddr,
        (ubyte *)pxArpEntry->aoEthAddr, ARP_ETHLEN);

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ARP_DBGP(DBGLVL_REPETITIVE, "ArpAdd: Entry already in table\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "ArpAdd: Entry already in table ");
    }

    return;
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ARP_DBGP(DBGLVL_REPETITIVE, "ArpAdd: Create a new entry\n");*/
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "ArpAdd: Create a new entry");
  }

  ArpCreate(pxArp, pxArpEntry->dwIpAddr, pxArpEntry->aoEthAddr,
            pxArpEntry->oIfIdx,pxArpEntry->wVlan, pxArpEntry->eArpFlag); /*Ajit: Code changed*/

  return;
}


#ifdef ARPDBG_HI
/***************************************************************************
*  void dbgArpPrintTable(ARPSTATE *pxArp)
*
*  Debug function to print out the arp table
*
*  par: void
*
*  ret: void
****************************************************************************/
void dbgArpPrintTable(ARPSTATE *pxArp)
{
/*
  OCTET oIdx; Ajit: Changing its data type
*/
  INT oIdx = 0;
  DWORD dwTime;
#ifndef ARP_CACHE_32
  ARPENTRYSTATE *pxArpEntry = NULL;
  ARPENTRYSTATE **ppxArpEntry = NULL;
#endif

  ARP_CHECK_STATE(pxArp);

  /*dwTime = (DWORD)NetGlobalTimerGet();*/
  dwTime = (DWORD)NetGetMsecTime();
  printf("\nArpTable[] - timeout age: %lu(ms)\n", (DWORD)ARPTIME_MAXAGE);
  printf("Entry  IP                         Mac                oIfIdx Age(ms)\n");
#ifdef ARP_CACHE_32
  for (oIdx = 0; oIdx < pxArp->oArpTableSize; oIdx++) {
    if (pxArp->pxArpTable[oIdx].xEntry.dwIpAddr) {
      printf("[%03d]: %03ld.%03ld.%03ld.%03ld (%lx) %02x:%02x:%02x:%02x:%02x:%02x  %01d   %lu\n",
             oIdx,
             IPADDRDISPLAY(pxArp->pxArpTable[oIdx].xEntry.dwIpAddr),
             pxArp->pxArpTable[oIdx].xEntry.dwIpAddr,
             HWADDRDISPLAY(pxArp->pxArpTable[oIdx].xEntry.aoEthAddr),
             pxArp->pxArpTable[oIdx].xEntry.oIfIdx,
             dwTime - pxArp->pxArpTable[oIdx].dwLastUsed);
    } else {
      break;
    }
  }
#else
/*Ajit: Traverse through the hash table and print the values out*/
  for(oIdx = 0; oIdx < pxArp->wArpHashSize; oIdx++) {
    ppxArpEntry = &(pxArp->apxArpHashTable[oIdx]);
    ARP_DBG_ASSERT(ppxArpEntry != NULL);
    while (((pxArpEntry = *ppxArpEntry) != NULL)) {
       printf("[%03d]: %03ld.%03ld.%03ld.%03ld (%lx) %02x:%02x:%02x:%02x:%02x:%02x  %01d   %lu\n",
              oIdx,
              IPADDRDISPLAY(pxArpEntry->xEntry.dwIpAddr),
              pxArpEntry->xEntry.dwIpAddr,
              HWADDRDISPLAY(pxArpEntry->xEntry.aoEthAddr),
              pxArpEntry->xEntry.oIfIdx,
              dwTime - pxArpEntry->dwLastUsed);
       ppxArpEntry = &pxArpEntry->pxNext;
    }
  }
#endif
}

/***************************************************************************
*  void dbgArpPrintHash(ARPSTATE *pxArp)
*
*  Debug function to print out the arp table
*
*  par: void
*
*  ret: void
****************************************************************************/
void dbgArpPrintHash(ARPSTATE *pxArp)
{
  OCTET oIdx;
  ARPENTRYSTATE *pxArpEntry;
  ARPENTRYSTATE **ppxArpEntry;

  ARP_CHECK_STATE(pxArp);

  printf("\napxArpHashTable[]\nIdx    apxArpHashTable[Idx]\n");
#ifdef ARP_CACHE_32
  for (oIdx = 0; oIdx < pxArp->oArpHashSize; oIdx++) {
#else
  for (oIdx = 0; oIdx < pxArp->wArpHashSize; oIdx++) {
#endif
    ppxArpEntry = &(pxArp->apxArpHashTable[oIdx]);
    ASSERT(ppxArpEntry != NULL);
    printf("[%03d]: ", oIdx);
    while ((pxArpEntry = *ppxArpEntry) != NULL) {
      printf("0x%p ", pxArpEntry);
      ppxArpEntry = &pxArpEntry->pxNext;
    }
    printf("\n");
  } /*end of "for" loop, for looping through the hash table.*/
}

#endif /* #ifdef ARPDBG_HI */

#ifdef __MOC_CLI__
/*
 * ArpPrintTableforCli
 */
ubyte4 ArpPrintTableforCli(ARPSTATE *pxArpState, ubyte *poCliBuff)
{
  ubyte4 dwBytesWritten = 0;
  ubyte *poOrig = poCliBuff;
  ubyte2 oIdx;
#ifndef ARP_CACHE_32
  ARPENTRYSTATE *pxArpEntry = NULL;
  ARPENTRYSTATE **ppxArpEntry = NULL;
#endif

  if(poCliBuff)
  {
    poCliBuff += sprintf(poCliBuff, "ArpTable: \n%s - %s - %s - %s\n",
                                    "MocIfNum",
                                    "MocIpAddr",
                                    "MocHwIfAddr",
                                    "Type"
                       );
#ifdef ARP_CACHE_32
    for (oIdx = 0; oIdx < pxArpState->oArpTableSize; oIdx++)
    {
      if (pxArpState->pxArpTable[oIdx].xEntry.dwIpAddr)
      {
        poCliBuff += sprintf(poCliBuff, "%01d - %03ld.%03ld.%03ld.%03ld - %02x:%02x:%02x:%02x:%02x:%02x - %s\n",
                             pxArpState->pxArpTable[oIdx].xEntry.oIfIdx,
                             IPADDRDISPLAY(pxArpState->pxArpTable[oIdx].xEntry.dwIpAddr),
                             HWADDRDISPLAY(pxArpState->pxArpTable[oIdx].xEntry.aoEthAddr),
                             _ArpDecipherType(pxArpState->pxArpTable[oIdx].xEntry.eArpFlag)
                            );
        poCliBuff += dwBytesWritten;
      }
      else
        break;
    }
#else
    for(oIdx = 0; oIdx < pxArpState->wArpHashSize; oIdx++)
    {
      ppxArpEntry = &(pxArpState->apxArpHashTable[oIdx]);
      ARP_DBG_ASSERT(ppxArpEntry != NULL);
      while (((pxArpEntry = *ppxArpEntry) != NULL))
      {
        poCliBuff += sprintf(poCliBuff, "%01d - %03ld.%03ld.%03ld.%03ld - %02x:%02x:%02x:%02x:%02x:%02x - %s\n",
                             pxArpEntry->xEntry.oIfIdx,
                             IPADDRDISPLAY(pxArpEntry->xEntry.dwIpAddr),
                             HWADDRDISPLAY(pxArpEntry->xEntry.aoEthAddr),
                             _ArpDecipherType(pxArpEntry->xEntry.eArpFlag)
                            );
        ppxArpEntry = &pxArpEntry->pxNext;
      }
    }
#endif
    return (poCliBuff - poOrig);
  }
  else
    return 0;
}

/*
 * _ArpDecipherType
 */
ubyte* _ArpDecipherType(ubyte2 dwArpType)
{
  ubyte *poType = NULL;
  switch(dwArpType)
  {
    case E_ARPBROADCAST:
      poType = "ARP_BROADCAST";
      break;
    case E_ARPLOCAL:
      poType = "ARP_LOCAL";
      break;
    case E_ARPDYNAMIC:
      poType = "ARP_DYNAMIC";
      break;
    case E_ARPSTATIC:
      poType = "ARP_STATIC";
      break;
    default:
      poType = "ERROR";
      break;
  }
  return poType;
}
#endif
