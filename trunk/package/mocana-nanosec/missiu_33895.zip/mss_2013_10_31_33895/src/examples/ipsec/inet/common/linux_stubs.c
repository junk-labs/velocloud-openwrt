
#include <stdio.h>
#include <pthread.h>

typedef void *(*FuncPtr)(void *);

void 
*malloc(unsigned int size)
{
}

void 
free (void *ptr)
{
}

int 
printf(const char *format,...)
{
}

int 
sprintf(const char *format,...)
{
}


/*
int 
sscanf(const char *str, const char *format, ...)
{
}

int 
snprintf(char *str, unsigned int size, const char *format, ...)
{
}

int 
puts(const char *s)
{
}


int
putchar(int c)
{
} */

int 
clock_gettime(int id, struct timespec *tp)
{
}

int nanosleep(const struct timespec *req, struct timespec *rem)
{
}

unsigned int 
htonl(unsigned int hostlong)
{
}

unsigned int 
ntohl(unsigned int netlong)
{
}

unsigned short
ntohs(unsigned short netshort)
{
}

unsigned short
htons(unsigned short hostshort)
{
}

int 
pthread_mutexattr_settype(pthread_mutexattr_t *attr, int kind)
{
}


int 
pthread_mutexattr_init(pthread_mutexattr_t *attr)
{
}

int 
pthread_mutexattr_destroy(pthread_mutexattr_t *attr)
{
}

char *strchr(const char *s, int c)
{
}

char *strdup(const char *s)
{
}

char *
strcat(char *dest, const char *src)
{
}

int rand (void)
{
}

int 
pthread_attr_init(pthread_attr_t *attr)
{
}

int  
pthread_mutex_init(pthread_mutex_t  *mutex,  const  pthread_mutexattr_t *mutexattr)
{
}

int 
pthread_join(pthread_t th, void **thread_return)
{
}

int
pthread_cond_init(pthread_cond_t *cond, const pthread_condattr_t *cond_attr)
{
}
 
int
pthread_cond_signal(pthread_cond_t *cond)
{
}
 
int 
pthread_cond_broadcast(pthread_cond_t *cond)
{
}
 
int
pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex)
{
}
 
int
pthread_cond_timedwait(pthread_cond_t   *cond,    pthread_mutex_t *mutex, const struct timespec *abstime)
{
}

int 
pthread_cond_destroy(pthread_cond_t *cond)
{
}

