


#include "NNstyle.h"
#include "tcp_flavor.h"
#include "dllist.h"
#include "../include/in.h"
#include "../include/socket.h"
#include "ecc.h"
#include "macros.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"
#include "iptable.h"
#include "nettransport.h"
#include "netnetwork.h"
#include "netsnmp.h"
#include "tcp.h"
#include "tcpdefs.h"
#include "tcp_dbg.h"
#include "snmp_tcpip_data.h"
#include "snmp_tcpip_rtn.h"

/***************************************************************************
*    called from by SNMP Agent to retrieve an entire TCP Connection Entry table
*
*    par:    DWORD *pxTcpEntry - area of memory for placing the Address Entry table
*
*    ret:    DWORD - nos bytes in pValue
****************************************************************************/
DWORD TcpipSnmpGetTcpEntryTable(void **ppvData, DWORD *pdwNosStructs, DWORD *pdwStructSize)
{
  extern TCPSTATE **ppxTcpInstanceList;
  extern OCTET oTcpInstances;
  struct TCPCONN_TABLE_ENTRY  *pxTcpEntry;
  TCPSTATE *pxTcp;
  TCPCONN *pxConn;
  OCTET oCurTcpInst;
  DWORD dwConnectionCnt = 0;

  ASSERT(ppvData != NULL);
  ASSERT(pdwNosStructs != NULL);
  ASSERT(pdwStructSize != NULL);

  /* Find the dimension of the array, and the size of each element */
  *pdwStructSize = sizeof(struct TCPCONN_TABLE_ENTRY);
  *pdwNosStructs = 0;
  for (oCurTcpInst = 0; oCurTcpInst < oTcpInstances; oCurTcpInst++) {
    pxTcp = ppxTcpInstanceList[oCurTcpInst];
    TCP_CHECK_STATE(pxTcp);
    DLLIST_head(&pxTcp->dllConns);
    while ((pxConn = (TCPCONN *) DLLIST_read(&pxTcp->dllConns)) != NULL) {
      (*pdwNosStructs)++;
      DLLIST_next(&pxTcp->dllConns);
    }
  }

  /* Allocate memory for the array (freed by snmp agent) */
  *ppvData = MALLOC((*pdwNosStructs) * (*pdwStructSize));
  ASSERT(*ppvData != NULL);

  /* Fill the array */

  for (oCurTcpInst = 0; oCurTcpInst < oTcpInstances; oCurTcpInst++) {
    pxTcp = ppxTcpInstanceList[oCurTcpInst];
    pxTcpEntry = (struct TCPCONN_TABLE_ENTRY *)(*ppvData);
    DLLIST_head(&pxTcp->dllConns);
    /* ensure connection copies don't exceed malloc'd space */
    while ( ((pxConn = (TCPCONN *) DLLIST_read(&pxTcp->dllConns)) != NULL) &&
            (*pdwNosStructs > dwConnectionCnt) ) {
      TRANSPORT2NETWORKID *pxConnNetId = &(pxConn->xId.xNetId);
      dwConnectionCnt++;
      if(pxConn->eState == TCPCONN_STATE_ESTABLISHED)
       pxTcpEntry->wState = TCPStateEstablished;
      else if(pxConn->eState == TCPCONN_STATE_LISTEN)
        pxTcpEntry->wState = TCPStateListen;
      else if(pxConn->eState == TCPCONN_STATE_CLOSED)
        pxTcpEntry->wState = TCPStateClosed;
      else if(pxConn->eState == TCPCONN_STATE_CLOSING)
        pxTcpEntry->wState = TCPStateClosing;
      else if(pxConn->eState == TCPCONN_STATE_SYNSENT)
        pxTcpEntry->wState = TCPStateSynSent; 
      else if(pxConn->eState == TCPCONN_STATE_SYNRCVD)
        pxTcpEntry->wState = TCPStateSynReceived;  
      else if(pxConn->eState == TCPCONN_STATE_FIN_WAIT_1)
        pxTcpEntry->wState = TCPStateFinWait1;  
      else if(pxConn->eState == TCPCONN_STATE_FIN_WAIT_2)
        pxTcpEntry->wState = TCPStateFinWait2;   
      else if(pxConn->eState == TCPCONN_STATE_CLOSE_WAIT)
        pxTcpEntry->wState = TCPStateCloseWait;  
      else if(pxConn->eState == TCPCONN_STATE_LAST_ACK)
        pxTcpEntry->wState = TCPStateLastAck;  
      else if(pxConn->eState == TCPCONN_STATE_TIME_WAIT)
        pxTcpEntry->wState = TCPStateTimeWait;                                                              
      else
        pxTcpEntry->wState = 0;  
        
      pxTcpEntry->dwLocalIP = pxConnNetId->dwSrcIpAddr;
      pxTcpEntry->wLocalPort = pxConn->xId.wSrcPort;
      pxTcpEntry->dwRemoteIP = pxConnNetId->dwDstIpAddr;
      pxTcpEntry->wRemotePort = pxConn->xId.wDstPort;

      pxTcpEntry++;
      DLLIST_next(&pxTcp->dllConns);
    }
  }

  /* if prove to be less connections than predicted initially reduce count reported */
  *pdwNosStructs = dwConnectionCnt;

  return TCPIPSNMPGETDATAOK;
}

extern void _TcpCloseQueued(TCPSTATE *pxTcp, TCPCONN *pxConn);
extern void _TcpDrop(TCPSTATE *pxTcp, TCPCONN *pxConn, DWORD ss, DWORD rs);
extern void _TcpConnClose(TCPSTATE *pxTcp, TCPCONN *pxConn);

/***************************************************************************
*	Deletes the relevant TCB
*
*	par:	local_IP
*		local_port
*		remote_IP
*		remote_port
*
*	ret:	0 on Fail	1 on success
*
*		(fails if no matching connection found)
*
*		Called by tcpConnTableSet() in SNMP access library
*
****************************************************************************/
int DeleteTCB(DWORD dwLocalIP, WORD wLocalPort, DWORD dwRemoteIP, WORD wRemotePort)
{
  extern TCPSTATE **ppxTcpInstanceList;
  extern OCTET oTcpInstances;
  TCPSTATE *pxTcp;
  TCPCONN *pxConn;
  OCTET oCurTcpInst;

  for (oCurTcpInst = 0; oCurTcpInst < oTcpInstances; oCurTcpInst++) {
    pxTcp = ppxTcpInstanceList[oCurTcpInst];
    TCP_CHECK_STATE(pxTcp);

    DLLIST_head(&pxTcp->dllConns);
    while ((pxConn = (TCPCONN *) DLLIST_read(&pxTcp->dllConns)) != NULL) {
      TRANSPORT2NETWORKID *pxConnNetId = &(pxConn->xId.xNetId);

      if ((pxConnNetId->dwDstIpAddr == dwRemoteIP) &&
             (pxConn->xId.wSrcPort == wLocalPort) &&
             (pxConn->xId.wDstPort == wRemotePort) &&
             (pxConnNetId->dwSrcIpAddr == dwLocalIP)

      ) {
        /* use Ioctl to close connection */
        TcpInstanceULInterfaceIoctl((H_NETINSTANCE) pxTcp,
                                    (H_NETINTERFACE) pxConn,
                                    NETINTERFACEIOCTL_CLOSE,
                                    0);
        return 1;
      }
      DLLIST_next(&pxTcp->dllConns);
    }
  }

  return 0;
}
