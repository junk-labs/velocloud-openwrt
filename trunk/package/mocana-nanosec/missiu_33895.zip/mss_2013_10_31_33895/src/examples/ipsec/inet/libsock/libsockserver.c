
#include "NNstyle.h"
#include "sys/socket.h"
#include "netinet/in.h"
#include "arpa/inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "../common/moc_ip.h"

#include "../utils/mocinclude.h"
#include "sys/netselect.h"
#include "libsock.h"
#include "libsockserver.h"
#include "../utils/modules.h"
#include "../utils/ipc.h"

extern int 
mn_accept_func(int sockfd, struct sockaddr *cliaddr, socklen_t *addrlen,
		mn_sock_accept_cb_t pfCb, void *pvCbArg, void * ipc_req);

extern sbyte4  
mn_connect_func(int sockfd, const struct sockaddr *pSockAddrServer, 
         socklen_t addrlen, mn_sock_connect_cb_t cb, void *cbarg,void *ipc_req);

extern ubyte4 
mn_recvfrom_func(int lSockfd, void *pvBuff, ubyte4 nbytes, int Flags,
         struct sockaddr *pxSockAddrFrom, socklen_t *addrlen,
	 mn_sock_recv_cb_t pfCb, void *pvCbArg, /* async stuff */
         void **ppvBuff, void **ppFreeArg,ubyte *ipc_req);

extern int 
mn_select_func(int iMaxFdP1, fd_set *pxFdSetRead, fd_set *pxFdSetWrite,
           fd_set *pxFdSetExcept,  struct timeval *pxTvTimeOut, ubyte * ipc_req);
void SOCKSERVER_receiveMsg(_ipc_msg_t *ipc_req);
static sbyte4 SOCKSERVER_socketMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockmsg);
static sbyte4 SOCKSERVER_bindMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockmsg);
static sbyte4 SOCKSERVER_listenMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockmsg);
static sbyte4 SOCKSERVER_sendMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockmsg);
static sbyte4 SOCKSERVER_sendtoMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockmsg);
static sbyte4 SOCKSERVER_connectMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockmsg);
static sbyte4 SOCKSERVER_acceptMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockmsg);
static sbyte4 SOCKSERVER_recvMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockmsg);
static sbyte4 SOCKSERVER_selectMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockmsg);
static sbyte4 SOCKSERVER_shutdownMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg);

/*---------------------------------------------------------------------------*/

extern MSTATUS
SOCKSERVER_init()
{
    MSTATUS status = OK;

    status = IPC_registerModule (LIBSOCKSERVER_MOD_ID, SOCKSERVER_receiveMsg );

    return status;
}
/*---------------------------------------------------------------------------*/

void
SOCKSERVER_receiveMsg(_ipc_msg_t *ipc_req)
{
    MSTATUS status = OK;
    sockMsg_t  *sockMsg = NULL;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 

    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        IPC_free(ipc_req);  
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_req) < sizeof(sockMsg_t))
    {
        IPC_free(ipc_req);  
        goto exit;
    }

    switch( sockMsg->libsockcmd )
    {
        case MN_SOCKET:
        {
            status = SOCKSERVER_socketMsg(ipc_req, sockMsg);
            break;
        }
        case MN_BIND:
        {
            status = SOCKSERVER_bindMsg(ipc_req, sockMsg);
            break;
        }
        case MN_LISTEN:
        {
            status = SOCKSERVER_listenMsg(ipc_req, sockMsg);
            break;
        }
        case MN_SEND:
        {
            status = SOCKSERVER_sendMsg(ipc_req, sockMsg);
            break;
        }
        case MN_SENDTO:
        {
            status = SOCKSERVER_sendtoMsg(ipc_req, sockMsg);
            break;
        }
        case MN_CONNECT:
        {
            status = SOCKSERVER_connectMsg(ipc_req, sockMsg);
            break;
        }
        case MN_ACCEPT:
        {
            status = SOCKSERVER_acceptMsg(ipc_req, sockMsg);
            break;
        }
        case MN_RECV:
        case MN_RECVFROM:
        {
            status = SOCKSERVER_recvMsg(ipc_req, sockMsg);
            break;
        }
        case MN_SELECT:
        {
            status = SOCKSERVER_selectMsg(ipc_req, sockMsg);
            break;
        }
        case MN_SHUTDOWN:
        {
            status = SOCKSERVER_shutdownMsg(ipc_req, sockMsg);
            break;
        }
    }


exit:
    return;
}

/*---------------------------------------------------------------------------*/
static sbyte4 
SOCKSERVER_socketMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    MSTATUS     status = OK;

    status = IPC_alloc(sizeof(sockMsg_t),&ipc_reply);

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }
    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;

    fd = mn_socket(sockMsg->msg.socketcmd.family, 
                   sockMsg->msg.socketcmd.type ,
                   sockMsg->msg.socketcmd.protocol );

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_SOCKET_REPLY;
    sockMsg->errno      = OK;
    sockMsg->msg.socketcmdreply.sockfd = fd; 

    status = IPC_reply(ipc_req,ipc_reply);

exit:
    return status; 
}

/*---------------------------------------------------------------------------*/

static sbyte4 
SOCKSERVER_bindMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    MSTATUS     status = OK;

    status = IPC_alloc(sizeof(sockMsg_t),&ipc_reply);

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;
    status = mn_bind(sockMsg->msg.bindcmd.sockfd, 
                 &sockMsg->msg.bindcmd.sockAddr ,
                  sockMsg->msg.bindcmd.szSockAddr );

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_BIND_REPLY;
    sockMsg->errno      = status;

    printf("SockMsg CMD is %d ErroNo is %d\n",sockMsg->libsockcmd,sockMsg->errno);
    status = IPC_reply(ipc_req,ipc_reply);

exit:
    return status; 
}

/*---------------------------------------------------------------------------*/
static sbyte4 
SOCKSERVER_listenMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    MSTATUS     status = OK;

    status = IPC_alloc(sizeof(sockMsg_t),&ipc_reply);

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;
    status = mn_listen(sockMsg->msg.listencmd.sockfd, 
                  sockMsg->msg.listencmd.backlog );

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_LISTEN_REPLY;
    sockMsg->errno      = status;
    printf("SockMsg CMD is %d ErroNo is %d\n",sockMsg->libsockcmd,sockMsg->errno);

    status = IPC_reply(ipc_req,ipc_reply);

exit:
    return status; 
}

/*---------------------------------------------------------------------------*/

static sbyte4 
SOCKSERVER_sendMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    MSTATUS     status = OK;

    status = IPC_alloc(sizeof(sockMsg_t),&ipc_reply);

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;

    status = mn_send(sockMsg->msg.sendcmd.sockfd, 
                     (ubyte *)sockMsg->msg.sendcmd.buff,
                     sockMsg->msg.sendcmd.bufSize,
                     sockMsg->msg.sendcmd.flags);

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_SEND_REPLY;
    sockMsg->errno      = status;
    printf("SockMsg CMD is %d ErroNo is %d\n",sockMsg->libsockcmd,sockMsg->errno);
    status = IPC_reply(ipc_req,ipc_reply);
    if (OK > status)
        ipc_req = NULL;

exit:
    if (OK > status) 
    {
        if (ipc_req)
            IPC_free(ipc_req);
    }
    return status; 
}

/*---------------------------------------------------------------------------*/

static sbyte4 
SOCKSERVER_sendtoMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    MSTATUS     status = OK;

    status = IPC_alloc(sizeof(sockMsg_t),&ipc_reply);

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;

    status = mn_sendto(sockMsg->msg.sendtocmd.sockfd, 
                     (ubyte *)sockMsg->msg.sendtocmd.buff,
                     sockMsg->msg.sendtocmd.bufSize,
                     sockMsg->msg.sendtocmd.flags,
                     &sockMsg->msg.sendtocmd.sockAddr ,
                     sockMsg->msg.sendtocmd.szSockAddr );


    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_SEND_REPLY;
    sockMsg->errno      = status;
    printf("SockMsg CMD is %d ErroNo is %d\n",sockMsg->libsockcmd,sockMsg->errno);
    status = IPC_reply(ipc_req,ipc_reply);
    if (OK > status)
        ipc_req = NULL;

exit:
    if (OK > status) 
    {
        if (ipc_req)
            IPC_free(ipc_req);
    }
    return status; 
}

/*---------------------------------------------------------------------------*/

static sbyte4 
SOCKSERVER_connectMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    MSTATUS     status = OK;

    status = mn_connect_func(sockMsg->msg.connectcmd.sockfd, 
                        (struct sockaddr *)&sockMsg->msg.connectcmd.sockAddr ,
                        sockMsg->msg.connectcmd.szSockAddr,
                        NULL, NULL,ipc_req ); /* Async Callback Stuff */

exit:
    return status; 
}

/*---------------------------------------------------------------------------*/

extern sbyte4 
SOCKSERVER_connectReply(ubyte *ipc_req, sbyte4 replyStat)
{

    _ipc_msg_t* ipc_reply = NULL;
    sockMsg_t *sockMsg = NULL;
    MSTATUS     status = OK;

    status = IPC_alloc(sizeof(sockMsg_t),&ipc_reply);

    if (!ipc_reply)
    {
        IPC_free((_ipc_msg_t *)ipc_req);
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_CONNECT_REPLY;
    sockMsg->errno      = replyStat;

    status = IPC_reply((_ipc_msg_t *)ipc_req,ipc_reply);

exit:
    return status; 
}

/*---------------------------------------------------------------------------*/

static sbyte4 
SOCKSERVER_getsockoptMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    sockMsg_t *sockMsgReply;
    MSTATUS     status = OK;

    status = IPC_alloc(sizeof(sockMsg_t)+sockMsg->msg.getsockoptcmd.optlen,&ipc_reply);

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    sockMsgReply = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)+sockMsg->msg.getsockoptcmd.optlen) ;

    status = mn_getsockopt(sockMsg->msg.getsockoptcmd.sockfd, 
                     sockMsg->msg.getsockoptcmd.level,
                     sockMsg->msg.getsockoptcmd.optname,
                     sockMsgReply->msg.getsockoptcmd.buff,
                     &sockMsg->msg.getsockoptcmd.optlen);

    sockMsgReply->msg.getsockoptcmd.optlen = sockMsg->msg.getsockoptcmd.optlen;
    sockMsgReply->libsockcmd = MN_GETSOCKOPT_REPLY;
    sockMsgReply->errno      = status;
    printf("SockMsg CMD is %d ErroNo is %d\n",sockMsgReply->libsockcmd,sockMsgReply->errno);
    status = IPC_reply(ipc_req,ipc_reply);
    if (OK > status)
        ipc_req = NULL;

exit:
    if (OK > status) 
    {
        if (ipc_req)
            IPC_free(ipc_req);
    }
    return status; 
}

/*---------------------------------------------------------------------------*/

static sbyte4 
SOCKSERVER_acceptMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    MSTATUS     status = OK;

    status = mn_accept_func(sockMsg->msg.acceptcmd.sockfd, 
                            NULL,
                            0,
                            NULL, NULL,ipc_req ); /* Async Callback Stuff */

exit:
    return status; 
}

/*---------------------------------------------------------------------------*/

extern sbyte4 
SOCKSERVER_acceptReply(ubyte *ipc_req, sbyte4 childFd, struct sockaddr *sockAddr, socklen_t addrLen)
{
    _ipc_msg_t* ipc_reply = NULL;
    sockMsg_t *sockMsg = NULL;
    MSTATUS     status = OK;

    status = IPC_alloc(sizeof(sockMsg_t),&ipc_reply);

    if (!ipc_reply)
    {
        IPC_free((_ipc_msg_t *)ipc_req);
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_ACCEPT_REPLY;
    sockMsg->errno      = OK;
    sockMsg->msg.acceptreplycmd.childfd = childFd;
    sockMsg->msg.acceptreplycmd.addrLen = addrLen;
    MOC_MEMCPY((ubyte *)&sockMsg->msg.acceptreplycmd.sockAddr ,(ubyte *)sockAddr,addrLen);

    status = IPC_reply((_ipc_msg_t *)ipc_req,ipc_reply);

exit:
    return status; 

}

/*---------------------------------------------------------------------------*/

static sbyte4 
SOCKSERVER_recvMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    ubyte  buff ;
    ubyte *pZBuf;
    ubyte *pZBufArg;
    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    sockMsg_t * sockMsgRep = NULL;
    MSTATUS     status = OK;

    status = IPC_alloc(sizeof(sockMsg_t),&ipc_reply);

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;

    if (MN_RECV == sockMsg->libsockcmd)
    {
        status = mn_recvfrom_func(sockMsg->msg.recvcmd.sockfd, 
                         (ubyte *)&buff, /* We never MEMCPY into this */
                         sockMsg->msg.recvcmd.bufSize,
                         sockMsg->msg.recvcmd.flags,
                         NULL,
                         NULL,
                         NULL,NULL,(void **)&pZBuf,(void **)&pZBufArg,(ubyte *)ipc_req);
    }
    else
    {
        status = mn_recvfrom_func(sockMsg->msg.recvcmd.sockfd, 
                         (ubyte *)&buff, /* We never MEMCPY into this */
                         sockMsg->msg.recvfromcmd.bufSize,
                         sockMsg->msg.recvfromcmd.flags,
                         &sockMsg->msg.recvfromcmd.sockAddr ,
                         &sockMsg->msg.recvfromcmd.szSockAddr,
                         NULL,NULL,(void **)&pZBuf,(void **)&pZBufArg,(ubyte *)ipc_req);
    }

    if (OK != status)
    {
        sockMsgRep = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

        if (MN_RECV == sockMsg->libsockcmd)
            sockMsgRep->libsockcmd = MN_RECV_REPLY;
        else
            sockMsgRep->libsockcmd = MN_RECVFROM_REPLY;
        sockMsg->errno      = status;
        printf("SockMsg CMD is %d ErroNo is %d\n",sockMsgRep->libsockcmd,sockMsgRep->errno);
        status = IPC_reply(ipc_req,ipc_reply);
        if (OK > status)
            ipc_req = NULL;
        
    }
    else
    {
        IPC_free(ipc_reply);
    }

exit:
    if (OK > status) 
    {
        if (ipc_req)
            IPC_free(ipc_req);
    }
    return status; 
}

/*---------------------------------------------------------------------------*/
extern sbyte4 
SOCKSERVER_recvReply(ubyte *ipc_req, sbyte4 sockfd, ubyte * buff, sbyte4 bufSize,struct sockaddr *sockAddr, socklen_t addrLen)
{
    _ipc_msg_t* ipc_reply = NULL;
    MSTATUS rStatus  = OK;
    sockMsg_t *sockMsg = NULL;
    sockMsg_t *sockMsgReq = NULL;
    MSTATUS     status = OK;

    if (0 >= bufSize)
    {
        rStatus = bufSize;
        bufSize = 0 ;
    }
    
    status = IPC_alloc(sizeof(sockMsg_t) + bufSize,&ipc_reply);

    if (!ipc_reply)
    {
        IPC_free((_ipc_msg_t *)ipc_req);
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t) + bufSize) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    sockMsgReq = (sockMsg_t *)_IPC_PAYLOAD((_ipc_msg_t *)ipc_req); 

    if (sockMsgReq->libsockcmd == MN_RECV)
    {
        sockMsg->libsockcmd = MN_RECV_REPLY;
        sockMsg->msg.recvcmd.sockfd = sockfd;
        sockMsg->msg.recvcmd.bufSize = bufSize;
        if (bufSize)
            MOC_MEMCPY((ubyte *)&sockMsg->msg.recvcmd.buff ,(ubyte *)buff,bufSize);
    }
    if (sockMsgReq->libsockcmd == MN_RECVFROM)
    {
        sockMsg->libsockcmd = MN_RECVFROM_REPLY;
        sockMsg->msg.recvfromcmd.sockfd = sockfd;
        sockMsg->msg.recvfromcmd.szSockAddr = addrLen;
        sockMsg->msg.recvfromcmd.bufSize = bufSize;
        if (bufSize)
        {
            MOC_MEMCPY((ubyte *)&sockMsg->msg.recvfromcmd.sockAddr ,(ubyte *)sockAddr,addrLen);
            MOC_MEMCPY((ubyte *)&sockMsg->msg.recvfromcmd.buff ,(ubyte *)buff,bufSize);
        }
    }

    sockMsg->errno      = rStatus;

    status = IPC_reply((_ipc_msg_t *)ipc_req,ipc_reply);

exit:
    return status; 

}
/*---------------------------------------------------------------------------*/

static sbyte4 
SOCKSERVER_selectMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    ubyte  buff ;
    _ipc_msg_t* ipc_reply = ipc_req;
    sockMsg_t * sockMsgRep = NULL;
    MSTATUS     status = OK;

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;

     status = mn_select_func(sockMsg->msg.selectcmd.maxSet, 
                         sockMsg->msg.selectcmd.setMask & READ_SET_SET?
                         (fd_set *)&sockMsg->msg.selectcmd.read_set:NULL,
                         sockMsg->msg.selectcmd.setMask & WRITE_SET_SET?
                         (fd_set *)&sockMsg->msg.selectcmd.write_set:NULL,
                         sockMsg->msg.selectcmd.setMask & EXCEPT_SET_SET?
                         (fd_set *)&sockMsg->msg.selectcmd.except_set:NULL,
                         sockMsg->msg.selectcmd.setMask & TIMEVAL_SET?
                         (struct timeval *)&sockMsg->msg.selectcmd.timeVal:NULL,
                         (ubyte *)ipc_req);

    if ((OK > status) && (ERR_LIBSOCK_SELECT_TIMEOUT != status)) /* Replied with Error */
    {
        sockMsgRep = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

        sockMsgRep->libsockcmd = MN_SELECT_REPLY;
        sockMsg->errno      = status;
        printf("SockMsg CMD is %d ErroNo is %d\n",sockMsgRep->libsockcmd,sockMsgRep->errno);
        status = IPC_reply(ipc_req,ipc_reply);
        
    }
    else if (status > OK ) /* Select Replied Immediately We need to reply Back */
    {
        sockMsgRep = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

        sockMsgRep->libsockcmd = MN_SELECT_REPLY;
        sockMsg->errno      = OK;
        sockMsg->msg.selectreplycmd.numSet = status;
        printf("SockMsg CMD is %d ErroNo is %d\n",sockMsgRep->libsockcmd,sockMsgRep->errno);
        status = IPC_reply(ipc_req,ipc_reply);
    }
    else if ((ERR_LIBSOCK_SELECT_TIMEOUT == status)) /* Replied with immediate Timeout  and numset = 0*/
    {
        sockMsgRep = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

        sockMsgRep->libsockcmd = MN_SELECT_REPLY;
        sockMsg->errno      = OK;
        sockMsg->msg.selectreplycmd.numSet = 0;
        printf("SockMsg CMD is %d ErroNo is %d\n",sockMsgRep->libsockcmd,sockMsgRep->errno);
        status = IPC_reply(ipc_req,ipc_reply);

    }
    else /* The Select Is Blocking */
    {
                
    }

exit:
    if (OK > status) 
    {

    }
    return status; 
}

/*---------------------------------------------------------------------------*/

extern sbyte4 
SOCKSERVER_selectReply(ubyte *ipc_req, int numSet)
{
    _ipc_msg_t* ipc_reply = (_ipc_msg_t *)ipc_req;
    MSTATUS rStatus  = OK;
    sockMsg_t *sockMsg = NULL;
    MSTATUS     status = OK;

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    sockMsg->libsockcmd = MN_SELECT_REPLY;
    sockMsg->msg.selectreplycmd.numSet = numSet;

    sockMsg->errno      = OK;

    status = IPC_reply((_ipc_msg_t *)ipc_req,ipc_reply);

exit:
    return status; 

}

/*---------------------------------------------------------------------------*/

extern sbyte4 
SOCKSERVER_plainReply(ubyte *ipc_req)
{
    _ipc_msg_t* ipc_reply = (_ipc_msg_t *)ipc_req;
    MSTATUS rStatus  = OK;
    sockMsg_t *sockMsg = NULL;
    MSTATUS     status = OK;

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    sockMsg->libsockcmd = MN_PLAIN_REPLY;

    sockMsg->errno      = -1;

    status = IPC_reply((_ipc_msg_t *)ipc_req,ipc_reply);

exit:
    return status; 

}

/*---------------------------------------------------------------------------*/

static sbyte4 
SOCKSERVER_shutdownMsg(_ipc_msg_t *ipc_req, sockMsg_t *sockMsg)
{

    _ipc_msg_t* ipc_reply = ipc_req;
    MSTATUS     status = OK;

    _IPC_MSG_SET_TOTAL_LEN(ipc_reply,sizeof(sockMsg_t)) ;
    status = mn_shutdown(sockMsg->msg.shutdowncmd.sockfd, 
                         sockMsg->msg.shutdowncmd.howto);

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_SHUTDOWN_REPLY;
    sockMsg->errno      = status;

    printf("SockMsg CMD is %d ErroNo is %d\n",sockMsg->libsockcmd,sockMsg->errno);
    status = IPC_reply(ipc_req,ipc_reply);

exit:
    return status; 
}

/*---------------------------------------------------------------------------*/
