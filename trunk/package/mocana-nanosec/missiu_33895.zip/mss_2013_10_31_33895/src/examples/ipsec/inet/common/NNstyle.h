/*
 * NNstyle.h
 *
 * General defines and prototypes
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __NNSTYLE_H__
#define __NNSTYLE_H__

#include "../../common/moptions.h"
#include "../../common/mdefs.h"
#include "../../common/mtypes.h"
#include "../../common/merrors.h"
#include "../../common/mrtos.h"
#include "../../common/mstdlib.h"
#include "../../common/debug_console.h"
#include "../../common/mem_pool.h"
#include "../include/mn_errno.h"


MOC_EXTERN int mn_errno;
/*
 * Constants
 */

typedef ubyte OCTET;
typedef sbyte CHAR;
typedef ubyte2 WORD;
typedef sbyte2 SHORT;
typedef ubyte4 DWORD;
typedef sbyte4  LONG;
#if 0
typedef OCTET BOOL;
#else
typedef sbyte4 BOOL; /* Changed for vxWorks */
#endif


#define O_RDONLY             00
#define O_WRONLY             01
#define O_RDWR               02


#ifndef FALSE
#  define FALSE      0
#endif
#ifndef TRUE
#  define TRUE      (!FALSE)
#endif

#define TRI_TRUE     31
#define TRI_UNKNOWN  32
#define TRI_FALSE    33

#define OK           0
#define FAIL        (-1)
#define CONTINUE     1

#define DONE         1
#define NOT_DONE     0

#ifndef NULL
#define    NULL        ((void *)0)
#endif

/*
 * Typedefs
 *
 * - integers
 *
 *                 8-bit   16-bit  32-bit  64-bit
 *      unsigned   OCTET   WORD    DWORD   QWORD
 *      signed     CHAR    SHORT   LONG    LLONG
 *
 * - misc (floats, enums, ...)
 */

#if 0

#if (defined(OCTET) || defined(WORD) || defined(DWORD) || defined(QWORD) || \
     defined(CHAR) || defined(SHORT) || defined(LONG) || defined(LLONG))
#  error "Some integer types previously declared"
#endif

/* 8-bit integers */
#if (UCHAR_MAX == 0xFFU)
   typedef unsigned char OCTET;
   typedef char CHAR;
#else
#  error "Unsupported OCTET/CHAR size"
#endif

/* 16-bit integers */
#if (UINT_MAX == 0xFFFFU)
   typedef unsigned int WORD;
   typedef int SHORT;
#elif (USHRT_MAX == 0xFFFFU)
   typedef unsigned short WORD;
   typedef short SHORT;
#else
#  error "Unsupported WORD/SHORT size"
#endif

/* 32-bit integers */
#if (ULONG_MAX == 0xFFFFFFFFUL)
   typedef unsigned long DWORD;
   typedef long LONG;
#elif (UINT_MAX == 0xFFFFFFFFUL)
   typedef unsigned int DWORD;
   typedef int LONG;
#else
#  error "Unsupported DWORD/LONG size"
#endif

/* 64-bit integers */
#ifndef NCHECK_ULLONG
#if (ULLONG_MAX == 0xFFFFFFFFFFFFFFFFULL)
   typedef unsigned long long QWORD;
   typedef long long LLONG;
#else
/* don't complain if there is no long long */
#endif
#endif
#endif

/* convenience integer types */
typedef OCTET BYTE;
typedef SHORT INT;

#if 0

/* floating point */
typedef float FLOAT;
typedef double DOUBLE;
/* special pointer types */
typedef DWORD DRAM_P;
typedef DWORD SRAM_P;
typedef DWORD DM_P;
typedef DWORD DP_P;
typedef DWORD UCODE_P;
typedef DWORD VP_P;

/* others */
typedef enum {
  E_TRI_TRUE = TRI_TRUE,
  E_TRI_FALSE = TRI_FALSE,
  E_TRI_UNKNOWN = TRI_UNKNOWN
} E_TRI;
#endif

/*
 * Syslog
 */

#define SYSLOG syslog

/*
 * Debugging
 */

#include "dbg.h"

#ifndef __SELECT_OPT_ON__
#define MN_OPEN_MAX    25000
#else
#define MN_OPEN_MAX    12500
#endif


typedef struct ioctl_arg_list_s {
    LONG    lFd;
    LONG    lFamily;
    LONG    lType;
    LONG    lProtocol;
    DWORD   hIf;
    LONG    lFlag;
    LONG    oIfIdx;
    LONG    oIfNum;
    void    *pxRtEntry;
    void    *ifreq;
    void    *ifconf;
    void    *pxDhcpCustomOpt;
    void    *ppdllDhcpCustomOpts;
    DWORD   hNetData;
    DWORD   dwIndex;
    DWORD   bNullifyEntry;
    DWORD   *pdwNumRoutes;
    DWORD   dwBufSize;
    DWORD   *pdwOutSize;
    DWORD   dwGWIP;
    void    *pRtData;
    void    *pxSpData;
    void    *pxSaData;
    void    *pxSp;
    void    *pfnNetIfCbk;
    void    *pfnDhcpErrorCbk;
    void    *pfnLinkStatusCbk;

} mnIoctlArgList_t;

#endif  /* __NNSTYLE_H__ */
