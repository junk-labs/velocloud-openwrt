/* Linuxthreads - a simple clone()-based implementation of Posix        */
/* threads for Linux.                                                   */
/* Copyright (C) 1996 Xavier Leroy (Xavier.Leroy@inria.fr)              */
/*                                                                      */
/* This program is free software; you can redistribute it and/or        */
/* modify it under the terms of the GNU Library General Public License  */
/* as published by the Free Software Foundation; either version 2       */
/* of the License, or (at your option) any later version.               */
/*                                                                      */
/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU Library General Public License for more details.                 */

#ifndef _MSS_PTHREAD_H
#define _MSS_PTHREAD_H	1

#if defined (__LINUX_RTOS__) || defined (__CYGWIN_RTOS__)

#include "netpthreadtypes.h"
#include "netinitspin.h"


/* Initializers.  */

#define PTHREAD_MUTEX_INITIALIZER \
  {0, 0, 0, PTHREAD_MUTEX_TIMED_NP, __LOCK_INITIALIZER}
#ifdef __USE_GNU
# define PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP \
  {0, 0, 0, PTHREAD_MUTEX_RECURSIVE_NP, __LOCK_INITIALIZER}
# define PTHREAD_ERRORCHECK_MUTEX_INITIALIZER_NP \
  {0, 0, 0, PTHREAD_MUTEX_ERRORCHECK_NP, __LOCK_INITIALIZER}
# define PTHREAD_ADAPTIVE_MUTEX_INITIALIZER_NP \
  {0, 0, 0, PTHREAD_MUTEX_ADAPTIVE_NP, __LOCK_INITIALIZER}
#endif

#define PTHREAD_COND_INITIALIZER {__LOCK_INITIALIZER, 0, "", 0}

#ifdef __USE_UNIX98
# define PTHREAD_RWLOCK_INITIALIZER \
  { __LOCK_INITIALIZER, 0, NULL, NULL, NULL,				      \
    PTHREAD_RWLOCK_DEFAULT_NP, PTHREAD_PROCESS_PRIVATE }
#endif
#ifdef __USE_GNU
# define PTHREAD_RWLOCK_WRITER_NONRECURSIVE_INITIALIZER_NP \
  { __LOCK_INITIALIZER, 0, NULL, NULL, NULL,				      \
    PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP, PTHREAD_PROCESS_PRIVATE }
#endif

/* Values for attributes.  */

enum
{
  PTHREAD_CREATE_JOINABLE,
#define PTHREAD_CREATE_JOINABLE	PTHREAD_CREATE_JOINABLE
  PTHREAD_CREATE_DETACHED
#define PTHREAD_CREATE_DETACHED	PTHREAD_CREATE_DETACHED
};

enum
{
  PTHREAD_INHERIT_SCHED,
#define PTHREAD_INHERIT_SCHED	PTHREAD_INHERIT_SCHED
  PTHREAD_EXPLICIT_SCHED
#define PTHREAD_EXPLICIT_SCHED	PTHREAD_EXPLICIT_SCHED
};

enum
{
  PTHREAD_SCOPE_SYSTEM,
#define PTHREAD_SCOPE_SYSTEM	PTHREAD_SCOPE_SYSTEM
  PTHREAD_SCOPE_PROCESS
#define PTHREAD_SCOPE_PROCESS	PTHREAD_SCOPE_PROCESS
};

enum
{
  PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_ADAPTIVE_NP
#ifdef __USE_UNIX98
  ,
  PTHREAD_MUTEX_NORMAL = PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE = PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK = PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_DEFAULT = PTHREAD_MUTEX_NORMAL
#endif
#ifdef __USE_GNU
  /* For compatibility.  */
  , PTHREAD_MUTEX_FAST_NP = PTHREAD_MUTEX_ADAPTIVE_NP
#endif
};

enum
{
  PTHREAD_PROCESS_PRIVATE,
#define PTHREAD_PROCESS_PRIVATE	PTHREAD_PROCESS_PRIVATE
  PTHREAD_PROCESS_SHARED
#define PTHREAD_PROCESS_SHARED	PTHREAD_PROCESS_SHARED
};

#ifdef __USE_UNIX98
enum
{
  PTHREAD_RWLOCK_PREFER_READER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP,
  PTHREAD_RWLOCK_DEFAULT_NP = PTHREAD_RWLOCK_PREFER_WRITER_NP
};
#endif	/* Unix98 */

#define PTHREAD_ONCE_INIT 0

/* Special constants */

#ifdef __USE_XOPEN2K
/* -1 is distinct from 0 and all errno constants */
# define PTHREAD_BARRIER_SERIAL_THREAD -1
#endif

/* Cleanup buffers */

struct _pthread_cleanup_buffer
{
  void (*__routine) (void *);		  /* Function to call.  */
  void *__arg;				  /* Its argument.  */
  int __canceltype;			  /* Saved cancellation type. */
  struct _pthread_cleanup_buffer *__prev; /* Chaining of cleanup functions.  */
};

/* Cancellation */

enum
{
  PTHREAD_CANCEL_ENABLE,
#define PTHREAD_CANCEL_ENABLE	PTHREAD_CANCEL_ENABLE
  PTHREAD_CANCEL_DISABLE
#define PTHREAD_CANCEL_DISABLE	PTHREAD_CANCEL_DISABLE
};
enum
{
  PTHREAD_CANCEL_DEFERRED,
#define PTHREAD_CANCEL_DEFERRED	PTHREAD_CANCEL_DEFERRED
  PTHREAD_CANCEL_ASYNCHRONOUS
#define PTHREAD_CANCEL_ASYNCHRONOUS	PTHREAD_CANCEL_ASYNCHRONOUS
};
#define PTHREAD_CANCELED ((void *) -1)


/* Function for handling threads.  */

/* Create a thread with given attributes ATTR (or default attributes
   if ATTR is NULL), and call function START_ROUTINE with given
   arguments ARG.  */
MOC_EXTERN int pthread_create (pthread_t * __threadp,
			   pthread_attr_t * __attr,
			   void *(*__start_routine) (void *),
			   void * __arg) ;

/* Obtain the identifier of the current thread.  */
MOC_EXTERN pthread_t pthread_self (void) ;

/* Compare two thread identifiers.  */
MOC_EXTERN int pthread_equal (pthread_t __thread1, pthread_t __thread2) ;

/* Terminate calling thread.  */
MOC_EXTERN void pthread_exit (void *__retval);

/* Make calling thread wait for termination of the thread TH.  The
   exit status of the thread is stored in *THREAD_RETURN, if THREAD_RETURN
   is not NULL.  */
MOC_EXTERN int pthread_join (pthread_t __th, void **__thread_return) ;

/* Indicate that the thread TH is never to be joined with PTHREAD_JOIN.
   The resources of TH will therefore be freed immediately when it
   terminates, instead of waiting for another thread to perform PTHREAD_JOIN
   on it.  */
MOC_EXTERN int pthread_detach (pthread_t __th) ;


/* Functions for handling attributes.  */

/* Initialize thread attribute *ATTR with default attributes
   (detachstate is PTHREAD_JOINABLE, scheduling policy is SCHED_OTHER,
    no user-provided stack).  */
MOC_EXTERN int pthread_attr_init (pthread_attr_t *__attr) ;

/* Destroy thread attribute *ATTR.  */
MOC_EXTERN int pthread_attr_destroy (pthread_attr_t *__attr) ;

/* Add information about the minimum stack size needed for the thread
   to be started.  This size must never be less than PTHREAD_STACK_SIZE
   and must also not exceed the system limits.  */
MOC_EXTERN int pthread_attr_setstacksize (pthread_attr_t *__attr,
				      ubyte4 __stacksize) ;

/* Return the currently used minimal stack size.  */
MOC_EXTERN int pthread_attr_getstacksize (pthread_attr_t * __attr, ubyte4 * __stacksize)
     ;

#ifdef __USE_GNU
/* Get thread attributes corresponding to the already running thread TH.  */
MOC_EXTERN int pthread_getattr_np (pthread_t __th, pthread_attr_t *__attr) ;
#endif

#ifdef __USE_GNU
/* Yield the processor to another thread or process.
   This function is similar to the POSIX `sched_yield' function but
   might be differently implemented in the case of a m-on-n thread
   implementation.  */
MOC_EXTERN int pthread_yield (void) ;
#endif

/* Functions for mutex handling.  */

/* Initialize MUTEX using attributes in *MUTEX_ATTR, or use the
   default values if later is NULL.  */
MOC_EXTERN int pthread_mutex_init (pthread_mutex_t * __mutex,
			       pthread_mutexattr_t *
			       __mutex_attr) ;

/* Destroy MUTEX.  */
MOC_EXTERN int pthread_mutex_destroy (pthread_mutex_t *__mutex) ;

/* Try to lock MUTEX.  */
MOC_EXTERN int pthread_mutex_trylock (pthread_mutex_t *__mutex) ;

/* Wait until lock for MUTEX becomes available and lock it.  */
MOC_EXTERN int pthread_mutex_lock (pthread_mutex_t *__mutex);

/* Unlock MUTEX.  */
MOC_EXTERN int pthread_mutex_unlock (pthread_mutex_t *__mutex) ;


/* Functions for handling mutex attributes.  */

/* Initialize mutex attribute object ATTR with default attributes
   (kind is PTHREAD_MUTEX_TIMED_NP).  */
MOC_EXTERN int pthread_mutexattr_init (pthread_mutexattr_t *__attr) ;

/* Destroy mutex attribute object ATTR.  */
MOC_EXTERN int pthread_mutexattr_destroy (pthread_mutexattr_t *__attr) ;

/* Get the process-shared flag of the mutex attribute ATTR.  */
MOC_EXTERN int pthread_mutexattr_getpshared (pthread_mutexattr_t *
					 __attr,
					 int *__pshared);

/* Set the process-shared flag of the mutex attribute ATTR.  */
MOC_EXTERN int pthread_mutexattr_setpshared (pthread_mutexattr_t *__attr,
					 int __pshared) ;

#ifdef __USE_UNIX98
/* Set the mutex kind attribute in *ATTR to KIND (either PTHREAD_MUTEX_NORMAL,
   PTHREAD_MUTEX_RECURSIVE, PTHREAD_MUTEX_ERRORCHECK, or
   PTHREAD_MUTEX_DEFAULT).  */
MOC_EXTERN int pthread_mutexattr_settype (pthread_mutexattr_t *__attr, int __kind)
     ;

/* Return in *KIND the mutex kind attribute in *ATTR.  */
MOC_EXTERN int pthread_mutexattr_gettype (pthread_mutexattr_t *
				      __attr, int * __kind) ;
#endif


/* Functions for handling conditional variables.  */

/* Initialize condition variable COND using attributes ATTR, or use
   the default values if later is NULL.  */
MOC_EXTERN int pthread_cond_init (pthread_cond_t *__cond,
			      pthread_condattr_t *
			      __cond_attr) ;

/* Destroy condition variable COND.  */
MOC_EXTERN int pthread_cond_destroy (pthread_cond_t *__cond) ;

/* Wake up one thread waiting for condition variable COND.  */
MOC_EXTERN int pthread_cond_signal (pthread_cond_t *__cond) ;

/* Wake up all threads waiting for condition variables COND.  */
MOC_EXTERN int pthread_cond_broadcast (pthread_cond_t *__cond) ;

/* Wait for condition variable COND to be signaled or broadcast.
   MUTEX is assumed to be locked before.  */
MOC_EXTERN int pthread_cond_wait (pthread_cond_t * __cond,
			      pthread_mutex_t * __mutex) ;

/* Wait for condition variable COND to be signaled or broadcast until
   ABSTIME.  MUTEX is assumed to be locked before.  ABSTIME is an
   absolute time specification; zero is the beginning of the epoch
   (00:00:00 GMT, January 1, 1970).  */
MOC_EXTERN int pthread_cond_timedwait (pthread_cond_t * __cond,
				   pthread_mutex_t * __mutex,
				   struct timespec *
				   __abstime) ;

/* Functions for handling condition variable attributes.  */

/* Initialize condition variable attribute ATTR.  */
MOC_EXTERN int pthread_condattr_init (pthread_condattr_t *__attr) ;

/* Destroy condition variable attribute ATTR.  */
MOC_EXTERN int pthread_condattr_destroy (pthread_condattr_t *__attr) ;

/* Functions for handling thread-specific data.  */


#elif defined (__VXWORKS_RTOS__)



/* defines */

#define _POSIX_THREADS				1
#define _POSIX_THREAD_PRIORITY_SCHEDULING	1
#define _POSIX_THREAD_ATTR_STACKSIZE		1
#define _POSIX_THREAD_ATTR_STACKADDR		1

#ifdef _POSIX_THREAD_PROCESS_SHARED
#define PTHREAD_PROCESS_PRIVATE	0
#define PTHREAD_PROCESS_SHARED	1
#endif /* _POSIX_THREAD_PROCESS_SHARED */

#ifdef _POSIX_THREAD_ATTR_STACKSIZE
#define PTHREAD_STACK_MIN		4096	/* suggested minimum */
#endif

#define	PTHREAD_INHERIT_SCHED		0	/* implementation default */
#define	PTHREAD_EXPLICIT_SCHED		1
#define PTHREAD_SCOPE_PROCESS		2
#define PTHREAD_SCOPE_SYSTEM		3	/* implementation default */


#define PTHREAD_ONCE_INIT		{0}

#define PTHREAD_INITIALIZED		1	/* object can be used */
#define PTHREAD_DESTROYED		-1	/* object status */
#define PTHREAD_MUTEX_INITIALIZER	{NULL, TRUE, 0, 0, 0, 0, \
    {PTHREAD_INITIALIZED, PTHREAD_PRIO_INHERIT, 0}}
#define PTHREAD_COND_INITIALIZER	{NULL, TRUE, 0, 0, NULL}

#define	PTHREAD_CREATE_DETACHED		0
#define	PTHREAD_CREATE_JOINABLE		1	/*.4a and implementation default */

#define PTHREAD_CANCEL_ENABLE		0
#define PTHREAD_CANCEL_DISABLE		1

#define PTHREAD_CANCEL_ASYNCHRONOUS	0
#define PTHREAD_CANCEL_DEFERRED		1

#define PTHREAD_CANCELED		((void *)-1)

#define _POSIX_THREAD_THREAD_MAX	0	/* unlimited, not checked */
#define _POSIX_THREAD_KEYS_MAX		256     
#define _POSIX_THREAD_DESTRUCTOR_ITERATIONS  4

/* to make some function returns more readable
 */
#define _RETURN_PTHREAD_SUCCESS		0

#define SIGCANCEL SIGCNCL

/* Internal definitions */

#define VALID			0x01
#define STACK_PASSED_IN		0x02
#define JOINABLE		0x04
#define JOINER_WAITING		0x08
#define TASK_EXITED		0x10

/* typedefs */

typedef unsigned long pthread_t;

typedef struct {
	int	threadAttrStatus;		/* status flag		*/
	unsigned long	threadAttrStacksize;		/* stack size		*/	
	void	*threadAttrStackaddr;		/* stack address	*/
	int	threadAttrDetachstate;		/* detach state		*/
	int	threadAttrContentionscope;	/* contention scope	*/
	int	threadAttrInheritsched;		/* inherit scheduler	*/
	int	threadAttrSchedpolicy;		/* scheduling policy	*/
	char 	*threadAttrName;	/* task name - VxWorks extension */
/*        struct sched_param	threadAttrSchedparam; */
						/* sched param struct	*/
	} pthread_attr_t;


typedef struct {
	int	condAttrStatus;			/* status flag		*/
#ifdef _POSIX_THREAD_PROCESS_SHARED
	int	condAttrPshared;		/* process-shared attr	*/
#endif	/* _POSIX_THREAD_PROCESS_SHARED */
	} pthread_condattr_t;


typedef struct {
	int	mutexAttrStatus;		/* status flag		*/
#ifdef _POSIX_THREAD_PROCESS_SHARED
	int	mutexAttrPshared;		/* process-shared attr	*/
#endif	/* _POSIX_THREAD_PROCESS_SHARED */
	int	mutexAttrProtocol;		/* inherit or protect	*/
	int	mutexAttrPrioceiling;		/* priority ceiling	*/
						/* (protect only)	*/
	} pthread_mutexattr_t;


/* values for mutexAttrProtocol */

#define PTHREAD_PRIO_NONE       0
#define PTHREAD_PRIO_INHERIT	1
#define PTHREAD_PRIO_PROTECT	2

typedef struct {
	int			mutexSemId;
        int                     mutexValid;
        int                     mutexInitted;
        int                     mutexIniting;
	int			mutexCondRefCount;
	int			mutexSavPriority;
	pthread_mutexattr_t	mutexAttr;
	} pthread_mutex_t;

typedef struct {
	int			condSemId;
        int                     condValid;
        int                     condInitted;
        int                     condIniting;
	int			condRefCount;
	pthread_mutex_t         *condMutex;
#ifdef _POSIX_THREAD_PROCESS_SHARED
	pthread_condattr_t	condAttr;
#endif	/* _POSIX_THREAD_PROCESS_SHARED */
	} pthread_cond_t;

typedef unsigned long	pthread_key_t;

#if 0
typedef struct {
	int	onceInitialized;
	int	onceMutex;	/* shdbe sizeof thing that vxTas acts on */
	} pthread_once_t;

/* internal typedefs */

typedef struct cleanup
    {
 
    struct cleanup *next;
    void(*routine)(void *);
    void *arg;
 
    } cleanupHandler;
 
typedef struct
    {
    const void **       privateData;
    int                 privateDataCount;
    int                 taskId;
    unsigned long       flags;
    int                 exitJoinSemId;
    int                 mutexSemId;
    int                 cancelSemId;
    int                 priority;
    int                 cancelstate;
    int                 canceltype;
    int                 cancelrequest;
    void *              exitStatus;
    cleanupHandler *    handlerBase;
    pthread_cond_t *    cvcond;
    } internalPthread;


/*
 * Section 3 Process Primitives	
 */

int pthread_sigmask(int how, const sigset_t *set, sigset_t *oset);
int pthread_kill(pthread_t thread, int sig);

#endif
/*
 * Section 11.3 Mutexes
 */

int pthread_mutexattr_init(pthread_mutexattr_t *attr);
int pthread_mutexattr_destroy(pthread_mutexattr_t *attr);

int pthread_mutex_init(pthread_mutex_t *mutex, const pthread_mutexattr_t *attr);
int pthread_mutex_destroy(pthread_mutex_t *mutex);

int pthread_mutex_lock(pthread_mutex_t *mutex);
int pthread_mutex_trylock(pthread_mutex_t *mutex);
int pthread_mutex_unlock(pthread_mutex_t *mutex);

/*
 * Section 11.4 Condition variables
 */

int pthread_condattr_init(pthread_condattr_t *attr);
int pthread_condattr_destroy(pthread_condattr_t *attr);

int pthread_cond_init(pthread_cond_t *cond, pthread_condattr_t *attr);
int pthread_cond_destroy(pthread_cond_t *cond);

int pthread_cond_signal(pthread_cond_t *cond);
int pthread_cond_broadcast(pthread_cond_t *cond);

int pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex);
int pthread_cond_timedwait(pthread_cond_t *cond, pthread_mutex_t *mutex,
			   const struct timespec *abstime);


/*
 * Section 16 Thread management
 */

int pthread_attr_init(pthread_attr_t *attr);
int pthread_attr_destroy(pthread_attr_t *attr);
#ifdef _POSIX_THREAD_ATTR_STACKSIZE
int pthread_attr_setstacksize(pthread_attr_t *attr, unsigned int stacksize);
int pthread_attr_getstacksize(const pthread_attr_t *attr, unsigned int *stacksize);
#endif	/* _POSIX_THREAD_ATTR_STACKSIZE */
#ifdef _POSIX_THREAD_ATTR_STACKADDR
int pthread_attr_setstackaddr(pthread_attr_t *attr, void *stackaddr);
int pthread_attr_getstackaddr(const pthread_attr_t *attr, void **stackaddr);
#endif	/* _POSIX_THREAD_ATTR_STACKADDR */
int pthread_attr_setdetachstate(pthread_attr_t *attr, int detachstate);
int pthread_attr_getdetachstate(const pthread_attr_t *attr, int *detachstate);

void pthread_exit(void *value_ptr);

int pthread_create (pthread_t *pThread,
		    const pthread_attr_t *pAttr,
		    void * (*start_routine)(void *),
		    void *arg);

int pthread_join(pthread_t thread, void **status);

int pthread_detach(pthread_t thread);

pthread_t pthread_self(void);

int pthread_equal(pthread_t t1, pthread_t t2);

/* int pthread_once(pthread_once_t *once_control, void (*init_routine)(void)); */

/*
 * Section 17 Thread-specific data
 */

int pthread_key_create(pthread_key_t *key, void (*destructor)(void *));

int pthread_setspecific(pthread_key_t key, const void *value);
void *pthread_getspecific(pthread_key_t key);

int pthread_key_delete(pthread_key_t key);

/*
 * Section 18 Thread cancellation
 */

int pthread_cancel(pthread_t thread);
int pthread_setcancelstate(int state, int *oldstate);
int pthread_setcanceltype(int type, int *oldtype);
void pthread_testcancel(void);
void pthread_cleanup_push(void (*routine)(void *), void *arg);
void pthread_cleanup_pop(int execute);

#if 0
/* VxWorks support routines */

MOC_EXTERN void pthreadLibInit();


/* Kernel support routine prototypes */

MOC_EXTERN STATUS	_pthreadLibInit(FUNCPTR deleteUserTaskEntry);

MOC_EXTERN int	_pthreadCreate (pthread_t *pThread,
		                const pthread_attr_t *pAttr,
		                void * (*wrapperFunc)(void *),
		                void * (*start_routine)(void *),
		                void *arg,
				int priNumMode);

MOC_EXTERN int	_pthreadSetCancelType (int type, int * oldtype);

MOC_EXTERN int	_pthreadSemOwnerGet (int	semId);
#endif

#endif
#endif	/* pthread.h */
