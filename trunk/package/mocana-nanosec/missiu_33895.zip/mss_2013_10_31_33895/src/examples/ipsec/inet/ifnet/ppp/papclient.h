/*
 * papclient.h
 *
 * PAP client API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PAPCLIENT_H_
#define _PAPCLIENT_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * PAP options
 */
#define PAPCLIENTOPTION_ID \
 (NETOPTION_MODULESPECIFICBEGIN )    /* User name. data is PAPCLIENTCONF *.
                                        Must be a null terminated string.
                                        length must include the `0`*/
#define PAPCLIENTOPTION_PASSWD \
 (NETOPTION_MODULESPECIFICBEGIN + 1) /* Secret. data is PAPCLIENTCONF *.
                                        Must be a null terminated string.*/
#define PAPCLIENTOPTION_IFIDX \
 (NETOPTION_MODULESPECIFICBEGIN + 2) /* physical interface. data is OCTET */
#define PAPCLIENTOPTION_VLAN \
 (NETOPTION_MODULESPECIFICBEGIN + 3) /* Vlan. Data is WORD*/

/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/

typedef struct {
  OCTET *poConf;
  WORD wConfLength;
} PAPCLIENTCONF;

/*****************************************************************************
 *
 * Function Prototypes
 *
 *****************************************************************************/

/*
 * PapClientInitialize
 *  Initialize the PAP library
 *
 *  Args:
 *
 *  Return:
 *    >=0
 */
LONG PapClientInitialize(void);

/*
 * PapClientTerminate
 *  Terminate the PapClient library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG PapClientTerminate(void);

/*
 * PapClientInstanceCreate
 *  Create a PAP instance
 *
 *  Args:
 *
 *  Return:
 *   instance handle
 */
H_NETINSTANCE PapClientInstanceCreate(void);

/*
 * PapClientInstanceDestroy
 *  Destroy a pap instance
 *
 *  Args:
 *   hPapClient              PapClient instance handle
 *
 *  Return:
 *   >=0
 */
LONG PapClientInstanceDestroy(H_NETINSTANCE hPapClient);


/*
 * PapClientInstanceSet
 *   Set PAP options
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceSet(H_NETINSTANCE hPapClient,OCTET oOption,
                      H_NETDATA hData);

/*
 * PapClientInstanceQuery
 *   Query PAP options
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     oOptio          Option code
 *     phData          data handle
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceQuery(H_NETINSTANCE hPapClient,OCTET oOption,H_NETDATA * phData);

/*
 * PapClientInstanceMsg
 *   PAP msg function
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceMsg(H_NETINSTANCE hPapClient,OCTET oMsg,H_NETDATA hData);

/*
 * PapClientInstanceLLInterfaceCreate
 *   Create PAP LL interface
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE PapClientInstanceLLInterfaceCreate(H_NETINSTANCE hPapClient);

/*
 * PapClientInstanceLLInterfaceDestroy
 *   Destroy PAP LL interface
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceLLInterfaceDestroy(H_NETINSTANCE hPapClient, H_NETINTERFACE hIf);

/*
 * PapClientInstanceLLInterfaceIoctl
 *   PAP LL interface ioctl function
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceLLInterfaceIoctl(H_NETINSTANCE hPapClient, H_NETINTERFACE hIf,
                                    OCTET oIoctl,H_NETDATA hData);

/*
 * PapClientInstanceRcv
 *   PAP instance rcv
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            NETIFID *
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceRcv(H_NETINSTANCE hPapClient, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData);

/*
 * PapClientInstanceProcess
 *   PAP processing function
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG PapClientInstanceProcess(H_NETINSTANCE hPapClient);


#endif /* #ifndef _PAPCLIENT_H_ */
