
/*
 * ndic_api.h
 *
 * Network device interface and configuration API. This APIs are used by
 * the target system to create, attach and configure network devices to
 * Mocana IP Stack.
 *
 *
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _NDIC_API_H_
#define _NDIC_API_H_

#define MN_DEVICE_NAMESIZE            32
#define MAX_AGGREGATION_PHY_INSTANCES 32
#define MN_MAX_HWADDR                  6
#define MAX_READ_BUFFER_SIZE        8192
#if defined (__RTOS_VXWORKS__) && defined(__ENABLE_MOCANA_ZEROCOPY__)
#define MN_ETHDRIVER_OFFSET           32
#else
#define MN_ETHDRIVER_OFFSET           2
#endif

typedef enum enum_deviceConfigType{
    MN_DEVICE_IPADDR = 0,
    MN_DEVICE_NETMASK,
    MN_DEVICE_GWADDR,
    MN_DEVICE_BRDADDR,
    MN_DEVICE_MEMPOOL,
    MN_DEVICE_ALL
}ENUM_MN_DEVICE_CONFIG;


/*
 * Set of callback functions provided by each device during device
 * registration.
 */
typedef struct MnDeviceCbacks_s {
    DWORD (*funcPtr_MnDeviceInit)();
    DWORD (*funcPtr_MnDeviceWrite) (int, char *, int);
    DWORD (*funcPtr_MnDeviceInstanceInit) ();
    DWORD (*funcPtr_MnDeviceInstanceStart) ();
    DWORD (*funcPtr_MnDeviceInstanceReset) ();
    DWORD (*funcPtr_MnDeviceInstanceIoctl) ();
    DWORD (*funcPtr_MnDeviceInstanceClose) ();
} MnDeviceCbacks_t;


typedef struct MnDevice_s {
    WORD     MnDeviceType;
    OCTET    MnDeviceName[MN_DEVICE_NAMESIZE];
    MnDeviceCbacks_t MnDeviceCallbackFns;
    DLLIST   MnDeviceInstanceList;
} MnDevice_t;


typedef struct MnDeviceInstanceConf_s {
    WORD     MnDeviceType;
    MnDevice_t    *MnDeviceInfo;
    WORD     MnDeviceDriverCookie;
    WORD     MnDeviceInstanceUnitNum;
    OCTET    MnDeviceInstanceName[MN_DEVICE_NAMESIZE];
    OCTET    MnDeviceInstanceHWAddr[MN_MAX_HWADDR];
    WORD     MnDeviceInstanceHWAddrLen;
    WORD     MnDeviceInstanceMtu;
    WORD     MnDeviceInstanceIndex;
#define      MN_DEV_INSTANCE_PHYSICAL 0x1
#define      MN_DEV_INSTANCE_LOGICAL  0x2
    WORD     MnDeviceInstanceFlags;
    LONG     MnDeviceInstanceIPAddr;
    LONG     MnDeviceInstanceIPMask;
    LONG     MnDeviceInstanceDfltGateway;
    WORD     MnLogicalInstanceIndex;
    WORD     MnNumPhysicalInstances;
    WORD     MnPhysicalAggInstanances[MAX_AGGREGATION_PHY_INSTANCES];
} MnDeviceInstanceConf_t;


typedef struct MnDeviceInstanceEvent_s {
    WORD    MnDeviceInstanceIndex;
#define     MN_DEV_INSTANCE_EVENT_IFUP      IFF_UP
#define     MN_DEV_INSTANCE_EVENT_IFDOWN    IFF_DOWN
    LONG    MnDeviceInstanceEventFlags;
} MnDeviceInstanceEvent_t;

typedef struct MnDeviceInstanceInfo_s {
    WORD     MnDeviceType;
    WORD     MnDeviceInstanceUnitNum;
    OCTET    MnDeviceInstanceName[MN_DEVICE_NAMESIZE];
    OCTET    MnDeviceInstanceHWAddr[MN_MAX_HWADDR];
    WORD     MnDeviceInstanceHWAddrLen;
    WORD     MnDeviceInstanceMtu;
    WORD     MnDeviceInstanceLogicalFlag;
    LONG     MnDeviceInstanceIPAddr;
    LONG     MnDeviceInstanceIPMask;
    LONG     MnDeviceInstanceDfltGateway;
    LONG     MnDeviceInstanceBrdAddr;
} MnDeviceInstanceInfo_t;

MSTATUS
MN_NDI_registerDevice (WORD device_type, OCTET *device_name, MnDeviceCbacks_t *
MnDeviceCallbacks);

ubyte4 MN_NDI_attachDeviceInstance (WORD device_type, WORD unit_num,
        MnDeviceInstanceInfo_t *MnDeviceInstanceInfo);
MSTATUS MN_NDI_attachToIP(MnDeviceInstanceConf_t *pDeviceInstanceConf);
MSTATUS MN_NDI_deviceSetLogical (WORD deviceInstanceIndex);
WORD MN_NDI_deviceAddPhytoLogical (WORD phyDeviceInstanceIndex,
            WORD logicalDeviceInstanceIndex);
WORD MN_NDI_deviceDelPhyFromLogical (WORD phyDeviceInstanceIndex,
        WORD logicalDeviceInstanceIndex);

WORD MN_NDI_setDeviceInstanceIPAddr(WORD deviceInstanceIndex, LONG ip_addr,
        LONG net_mask);
WORD MN_NDI_openDeviceInstance(WORD deviceInstanceIndex);
MSTATUS MN_NDI_setDeviceInstanceParams (OCTET oIfIdx, DWORD dwSocketIoctl,
            struct ifreq *pxIfReq);
MSTATUS MN_NDI_deviceInstanceParams(OCTET oIfIdx, DWORD dwSocketIoctl,
            struct ifreq * pxIfReq);

MSTATUS MN_NDI_postDeviceInstanceEvent(OCTET oIfIdx, LONG devEventFlags);
void * MN_NDI_allocFrameBuffer(ubyte4 *MnframeSize);

WORD MN_NDI_deviceRemovePhyFromLogical (WORD phyDeviceInstanceIndex,
        WORD logicalDeviceInstanceIndex);

WORD MN_NDI_deviceSetConfig(WORD deviceInstanceIndex,
            MnDeviceInstanceInfo_t *pDeviceInstanceInfo, ENUM_MN_DEVICE_CONFIG configType);

WORD MN_NDI_deviceGetConfig(WORD deviceInstanceIndex,
            MnDeviceInstanceInfo_t *pDeviceInstanceInfo, ENUM_MN_DEVICE_CONFIG configType);

MSTATUS MN_NDI_freeFrameBuffer(DWORD *MnFrameBuffer);
MOC_EXTERN MSTATUS MN_freeNetPacketOnly(ubyte *pMblk);

#endif

