/*
 * websubstcfg.c
 *
 * Functions to substitute network configuration parameters into web pages
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "netcfg.h"
#include "setupnet.h"
#if JJ
#include "httpapi.h"
#endif
#include "net/if_dl.h"

/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/
const VAR_IOCTL pxIfVarIoctlTableGet[] = {
  {"IPADDRESS_A",        SIOCGIFIADDR},
  {"DHCP_A",             SIOCGIFIFLAGDHCP},  /* maps to SIOCGIFIFLAG */
  {"IPNETMASK_A",        SIOCGIFINETMASK},
  {"IPDNS_A",            SIOCGIFIDNS},
  {"IPGATEWAY_A",        SIOCGIFIGWADDR},
  {"DNSDOMAINNAME_A",    SIOCGIFIDN},
  {"DNSHOSTNAME_A",      SIOCGIFIHN},
  {"CONNSTATUS",         SIOCGIFIFLAG},
  {"MAC",                SIOCGIFIDLADDR},

#ifdef NET_BR
  {"BRIDGEPORTSTATE",    SIOCGIFIBRIFSTATE},
#endif

  {NULL,                 0}  /* End marker */
};


/****************************************************************************
 *
 * Local private functions
 *
 ****************************************************************************/
static void _NetGetParameter(OCTET oIfIdx,
                             DWORD dwSocketIoctl,
                             char *pchParamValue)
{
  int iSock;
  LONG lReturn = 0;
  struct ifreq xIfReq;
  struct ifconf xIfConf;

  /* Open a socket */
  if ((iSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return;
  }

  xIfReq.ifr_name[0] = oIfIdx;

  /* Configure parameter */
  switch(dwSocketIoctl) {

  /*
   * Network Configuration (IP Address, Subnet Mask, Gateway,
   *                        DNS, MAC, Domain Name, Hostname)
   */
  case SIOCGIFIADDR:
  case SIOCGIFINETMASK:
  case SIOCGIFIDNS:
  case SIOCGIFIGWADDR:
    {
      DWORD dwAddress = 0;
      lReturn = ioctl(iSock, dwSocketIoctl, &(xIfReq));
      if (lReturn >= 0) {
        dwAddress = ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr;
      }
      sprintf(pchParamValue,"%ld.%ld.%ld.%ld",
              (dwAddress>>24)&0xff,(dwAddress>>16)&0xff,
              (dwAddress>>8)&0xff,(dwAddress)&0xff);
    }
    break;

  case SIOCGIFIDLADDR:
    {
      OCTET *pMac = NULL;
      xIfReq.ifr_addr.sa_len = sizeof(struct sockaddr_dl);
      lReturn = ioctl(iSock, dwSocketIoctl, &(xIfReq));
      if (lReturn >= 0) {
        pMac = (OCTET *)((struct sockaddr_dl *)&(xIfReq.ifr_addr))->sdl_data;
        sprintf(pchParamValue,"%02x:%02x:%02x:%02x:%02x:%02x",
                pMac[0],pMac[1],pMac[2],pMac[3],pMac[4],pMac[5]);
      }
    }
    break;

  case SIOCGIFIDN:
  case SIOCGIFIHN:
    {
      char cTmp[50];
      xIfConf.ifc_buf = cTmp;
      xIfConf.ifc_len = 50;
      lReturn = ioctl(iSock, dwSocketIoctl, oIfIdx, &(xIfConf));
      if (lReturn >= 0) {
        strncpy(pchParamValue, cTmp, xIfConf.ifc_len);
        pchParamValue[xIfConf.ifc_len] = 0;
      }
    }
    break;

  /*
   * Interface Link/Connection status & flags
   */
  case SIOCGIFIFLAG:
  case SIOCGIFIFLAGDHCP:
    lReturn = ioctl(iSock, SIOCGIFIFLAG, &(xIfReq));

    if (dwSocketIoctl == SIOCGIFIFLAG) {
      if (lReturn >= 0) {
        if (xIfReq.ifr_flags & IFF_UP) {
          if (xIfReq.ifr_flags & IFF_IPUP) {
            if (xIfReq.ifr_flags & IFF_PP) sprintf(pchParamValue,"Connected");
            else sprintf(pchParamValue,"Up");
          }
          else {
            if (xIfReq.ifr_flags & IFF_PP) sprintf(pchParamValue,"Connecting...");
            else if (xIfReq.ifr_flags & IFF_DYNAMIC) sprintf(pchParamValue,"Acquiring IP...");
            else sprintf(pchParamValue,"Down");
          }
        }
        else {
          if (xIfReq.ifr_flags & IFF_PP) sprintf(pchParamValue,"Disconnected");
          else sprintf(pchParamValue,"Down");
        }
      } else {
        sprintf(pchParamValue,"Down");
      }
    } else {
      if (xIfReq.ifr_flags & IFF_DYNAMIC) sprintf(pchParamValue,"Dynamic");
      else sprintf(pchParamValue,"Static");
    }
    break;

#ifdef NET_BR
  /*
   * Ethernet Bridge State
   */
  case SIOCGIFIBRIFSTATE:
    lReturn = ioctl(iSock, dwSocketIoctl, &(xIfReq));
    if (lReturn >= 0) {
      if (xIfReq.ifr_value == BRIF_LISTENING)
        sprintf(pchParamValue,"Listening...");
      else if (xIfReq.ifr_value == BRIF_LEARNING)
        sprintf(pchParamValue,"Learning...");
      else if (xIfReq.ifr_value == BRIF_FORWARDING)
        sprintf(pchParamValue,"Forwarding");
      else if (xIfReq.ifr_value == BRIF_BLOCKING)
        sprintf(pchParamValue,"Blocking");
      else sprintf(pchParamValue,"Disabled");
    } else {
      sprintf(pchParamValue,"Disabled");
    }
    break;
#endif

  }

  SETUPNET_DBGP(REPETITIVE,
                "_NetGetParameter:oIfIdx=%d,iotcl=%ld,value=%s\n",
                oIfIdx,
                dwSocketIoctl,
                pchParamValue);

  close(iSock);

  return;
}


/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/
#if JJ
int SetupNetWebSubstCallback(H_WEBDATA hWebdata)
{
  SubstParam *sp = (SubstParam *)hWebdata;
  int j = 0;

#ifdef NET_MULTIF
  int iSock = -1;
  static OCTET oIfNum = 0xFF;

  /*
   * The number of interfaces should not change, therefore we needn't
   * do this every time we get a substitution callback!
   */
  if (oIfNum == 0xFF) {

    /* Open a socket */
    if ((iSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
      ASSERT(0);
      return -1;
    }

    /* Get the number of interfaces */
    ioctl(iSock, SIOCGIFNUM, &oIfNum);
    ASSERT(oIfNum > 0 && oIfNum != 0xFF);

    close(iSock);
  }
#else
  OCTET oIfNum = 1;
#endif


  /*
   * Interface configuration/status information
   */
  while (pxIfVarIoctlTableGet[j].pcVarName != NULL) {
    OCTET oIfIdx;

    for (oIfIdx=0; oIfIdx<oIfNum; oIfIdx++) {
      char cTmpString[30];

      sprintf(cTmpString,"IF%d%s", oIfIdx, pxIfVarIoctlTableGet[j].pcVarName);
      if (!strcmp(sp->pchParamName, cTmpString)) {
        _NetGetParameter(oIfIdx,
                         pxIfVarIoctlTableGet[j].dwIoctlCode,
                         sp->chParamValue);
        return 1;
      }
    }

    j++;
  }

#ifdef NET_DSL
  if (!strcmp(sp->pchParamName, "VCCNUM")) {
    sprintf(sp->chParamValue,"%d",oIfNum-1);
  }
#endif

#ifdef NET_MULTIF
  if (!strcmp(sp->pchParamName, "LANSUBNET")) {
    char chIP[20];
    DWORD dwLANIP = 0;
    _NetGetParameter(0, SIOCGIFIADDR, chIP);
    dwLANIP = inet_addr(chIP);
    sprintf(sp->chParamValue,"%ld.%ld.%ld.",
            dwLANIP>>24, (dwLANIP>>16)&0xFF, (dwLANIP>>8)&0xFF);
  }
#endif


#ifdef NAT
  /*
   * NAT Port Forwarding Configuration
   *   Displays list of ports being forwarded to (reserved by) the CPE
   */
  {
    static struct nat_ports2cpe* pxCpePortTable = NULL;
    int k;

    if (!strcmp(sp->pchParamName, "CPEPORTMIN1")) {
      pxCpePortTable = calloc(NAT_PORT_FORWARD_CPE_SIZE, sizeof(NATCFG_PORTS2CPE));

      /* Open a socket */
      if ((iSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        ASSERT(0);
        return -1;
      }

      /* Grab the reserved CPE port list */
      ioctl(iSock, SIOCNATGETFWDWAN2CPE, pxCpePortTable);

      close(iSock);
    }

    for (k=0; k<NAT_PORT_FORWARD_CPE_SIZE; k++) {
      char cTmp[16];

      sprintf(cTmp, "CPEPORTMIN%d", k+1);
      if (!strcmp(sp->pchParamName, cTmp)) {
        ASSERT(pxCpePortTable != NULL);
        sprintf(sp->chParamValue, "%d", pxCpePortTable[k].wPortBeg);
      }
      sprintf(cTmp, "CPEPORTMAX%d", k+1);
      if (!strcmp(sp->pchParamName, cTmp)) {
        ASSERT(pxCpePortTable != NULL);
        sprintf(sp->chParamValue, "%d", pxCpePortTable[k].wPortEnd);
      }
    }

    if (!strcmp(sp->pchParamName, "CPEPORTMAX6")) {
      FREE(pxCpePortTable);
      pxCpePortTable = NULL;
    }
  }
#endif /*#ifdef NAT*/


#ifdef ROUTER
  /*
   * Routing table
   *   IMPORTANT! Memory will be allocated upon receiving the "STARTROUTETABLE"
   *              tag, and the routing table will be loaded.
   *              The memory will be released upon receiving the "ENDROUTETABLE"
   *              tag.
   */
  {
    static struct rtentry* pxRouteTable = NULL;
    static DWORD dwRoutesReceived = 0;
    static DWORD dwRouteEntry = 0;

    if (!strcmp(sp->pchParamName, "STARTROUTETABLE") && pxRouteTable == NULL) {
      DWORD dwRouteNum = 0;
      LONG lReturn = 0;

      /* Reset entry pointer */
      dwRouteEntry = 0;

      /* Open a socket */
      if ((iSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        ASSERT(0);
        return -1;
      }

      /* How big is the routing table? */
      lReturn = ioctl(iSock, SIOCRTABLEGETNUMRT, &dwRouteNum);
      if (lReturn >= 0 && dwRouteNum > 0) {

        /* Allocate memory for routing table */
        pxRouteTable = calloc(dwRouteNum, sizeof(struct rtentry));
        ASSERT(pxRouteTable);

        /* Grab the table */
        lReturn = ioctl(iSock, SIOCRTABLEGETALLRT, dwRouteNum, pxRouteTable,
                        &dwRoutesReceived);

        if (lReturn < 0 || dwRoutesReceived == 0) {
          FREE(pxRouteTable);
          pxRouteTable = 0;
          dwRoutesReceived = 0;
        }
      }

      close(iSock);
    }

    else if (!strcmp(sp->pchParamName, "ENDROUTETABLE")) {
      if (pxRouteTable != NULL) {
        FREE(pxRouteTable);
        pxRouteTable = NULL;
        dwRoutesReceived = 0;
      }
    }

    else if (!strcmp(sp->pchParamName, "LOADROUTE") && pxRouteTable != NULL) {
      /* Advance the route entry pointer */
      if (++dwRouteEntry > dwRoutesReceived) {
        FREE(pxRouteTable);
        pxRouteTable = NULL;
        dwRoutesReceived = 0;
      }
    }

    else if (!strcmp(sp->pchParamName, "DESTIPROUTE") &&
             dwRoutesReceived && pxRouteTable != NULL) {
      DWORD dwAddr = ((struct sockaddr_in *)&(pxRouteTable[dwRouteEntry - 1].rt_dst))->sin_addr.s_addr;
      sprintf(sp->chParamValue, "%ld.%ld.%ld.%ld",
              (dwAddr>>24)&0xff,(dwAddr>>16)&0xff,
              (dwAddr>>8)&0xff,(dwAddr)&0xff);
    } else if (!strcmp(sp->pchParamName, "SUBMASKROUTE") &&
               dwRoutesReceived && pxRouteTable != NULL) {
      DWORD dwAddr = ((struct sockaddr_in *)&(pxRouteTable[dwRouteEntry - 1].rt_genmask))->sin_addr.s_addr;
      sprintf(sp->chParamValue, "%ld.%ld.%ld.%ld",
              (dwAddr>>24)&0xff,(dwAddr>>16)&0xff,
              (dwAddr>>8)&0xff,(dwAddr)&0xff);
    } else if (!strcmp(sp->pchParamName, "GATEWAYROUTE") &&
               dwRoutesReceived && pxRouteTable != NULL) {
      DWORD dwAddr = ((struct sockaddr_in *)&(pxRouteTable[dwRouteEntry - 1].rt_gateway))->sin_addr.s_addr;
      sprintf(sp->chParamValue, "%ld.%ld.%ld.%ld",
              (dwAddr>>24)&0xff,(dwAddr>>16)&0xff,
              (dwAddr>>8)&0xff,(dwAddr)&0xff);
    } else if (!strcmp(sp->pchParamName, "METRICROUTE") &&
               dwRoutesReceived && pxRouteTable != NULL) {
      DWORD dwMetric = pxRouteTable[dwRouteEntry - 1].rt_metric;
      sprintf(sp->chParamValue, "%lu", dwMetric);
    } else if (!strcmp(sp->pchParamName, "SIFROUTE") &&
               dwRoutesReceived && pxRouteTable != NULL) {
      DWORD dwIf = pxRouteTable[dwRouteEntry - 1].rt_ifindex;
      sprintf(sp->chParamValue, "IF%ld", dwIf);
    } else if (!strcmp(sp->pchParamName, "TYPEROUTE") &&
               dwRoutesReceived && pxRouteTable != NULL) {
      DWORD dwFlags = pxRouteTable[dwRouteEntry - 1].rt_flags;
      sprintf(sp->chParamValue, "%s%s", ((dwFlags & RTF_STATIC) ? "S" : "R"),
              (dwFlags & RTF_DEFAULT) ? "D" : " ");
    }
  }
#endif

  return 1;
}

#endif /* JJ */
