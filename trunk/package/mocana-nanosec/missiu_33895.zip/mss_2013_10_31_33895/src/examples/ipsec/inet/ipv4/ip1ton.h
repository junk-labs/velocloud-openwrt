/*
 * ip1ton.h
 *
 * Ip1toN module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IP1TON_H_
#define _IP1TON_H_

/*****************************************************************************
 *
 * Define
 *
 *****************************************************************************/
#define IP1TONLLINTERFACEIOCTL_SETIFIDX \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN)    /* Set the if index coresponding
                                                to the Ll interface. Data is
                                                OCTET (interface number) */

/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/
/*
 * Ip1toNInitialize
 *  Initialize the Ip1toN library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG Ip1toNInitialize(void);

/*
 * Ip1toNTerminate
 *  Terminate the Ip1toN library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG Ip1toNTerminate(void);


/*
 * Ip1toNInstanceCreate
 *  Creates a Ip1toN Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE Ip1toNInstanceCreate(void);

/*
 * Ip1toNInstanceDestroy
 *  Destroy a Ip1toN Instance
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip1toNInstanceDestroy(H_NETINSTANCE hIp1toN);

/*
 * Ip1toNInstanceSet
 *  Set a Ip1toN Instance Option
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip1toNInstanceSet(H_NETINSTANCE hIp1toN,
                       OCTET oOption,
                       H_NETDATA hData);

/*
 * Ip1toNInstanceQuery
 *  Query a Ip1toN Instance Option
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip1toNInstanceQuery(H_NETINSTANCE hIp1toN,
                         OCTET oOption,
                         H_NETDATA *phData);

/*
 * Ip1toNInstanceMsg
 *  Send a msg to a Ip1toN instance
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip1toNInstanceMsg(H_NETINSTANCE hIp1toN,
                       OCTET oMsg,
                       H_NETDATA hData);

/*
 * Ip1toNInstanceULInterfaceCreate
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hIp1toN                       Ip1toNinstance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE Ip1toNInstanceULInterfaceCreate(H_NETINSTANCE hIp1toN);

/*
 * Ip1toNInstanceULInterfaceDestroy
 *  Destroy a Ip1toN UL interface
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG Ip1toNInstanceULInterfaceDestroy(H_NETINSTANCE hIp1toN,
                                      H_NETINTERFACE hInterface);

/*
 * Ip1toNInstanceULInterfaceIoctl
 *
 *  Args:
 *   hIp1toN                      Ip1toN instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG Ip1toNInstanceULInterfaceIoctl(H_NETINSTANCE hIp1toN,
                                    H_NETINTERFACE hULInterface,
                                    OCTET oIoctl,
                                    H_NETDATA hData);

/*
 * Ip1toNInstanceWrite
 *  Ip1toN Instance Write function. Follows PFN_NETWORKWRITE
 *  typedef.
 *
 *  Args:
 *   hIp1toN                    Ip1toN Instance handle
 *   hIf                        Interface handle
 *   pxPacket                   Packet pointer
 *   wOffset                    Ip PDU offset
 *   hData                      pointer to a NETWORKID structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG Ip1toNInstanceWrite(H_NETINSTANCE hIp1toN,
                         H_NETINTERFACE hIf,
                         NETPACKET *pxPacket,
                         NETPACKETACCESS *pxPktAccess,
                         H_NETDATA hData);

/*
 * Ip1toNInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIp1toN                Ip1toN instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */

H_NETINTERFACE Ip1toNInstanceLLInterfaceCreate(H_NETINSTANCE hIp1toN);

/*
 * Ip1toNInstanceLLInterfaceDestroy
 *  Destroy a Ip1toN LL interface
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG Ip1toNInstanceLLInterfaceDestroy(H_NETINSTANCE hIp1toN,
                                      H_NETINTERFACE hInterface);

/*
 * Ip1toNInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hIp1toN                      Ip fragmentation instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG Ip1toNInstanceLLInterfaceIoctl(H_NETINSTANCE hIp1toN,
                                    H_NETINTERFACE hLLInterface,
                                    OCTET oIoctl,
                                    H_NETDATA hData);


/*
 * Ip1toNInstanceRcv
 *  Ip fragmentation Instance Rcv function
 *   Ip fragmentation Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIp1toN                    Ip1toN Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    wOffset                    Ip PDU offset.
 *    hData                      unused
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG Ip1toNInstanceRcv(H_NETINSTANCE hIp1toN,
                       H_NETINTERFACE hIf,
                       NETPACKET *pxPacket,
                       NETPACKETACCESS *pxPktAccess,
                       H_NETDATA hData);

#endif /* #ifndef _IP1TON_H_ */







