/*
 * csum16.c
 *
 * Implements 16bit checksum which is unaligned packet friendly.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/* #define TESTCSUM16 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "ecccommon.h"

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * Checksum16
 *  Calculate a checksum (for IP, UDP, TCP etc.)
 *  NOTE: Allows packets on odd or even boundaries to be dealt with
 *        Also deals with odd length packets
 *
 *  Args:
 *   poData                     Ptr. to data to calc. checksum on
 *   wLen                       Length of the data in bytes
 *
 *  Return:
 *   16bit Checksum
 */
WORD
Checksum16(OCTET *poData, WORD wLen)
{
  DWORD dwSum = 0;

  /* check for an unaligned length - form a 16 bit word of
   * that octet with padding zeros on the right side
   */
  if (wLen & 1) {
    /* add the high byte (of the last octet) padded with zeros on the right */
    dwSum += ntohs((*(poData+wLen-1)<<8));
  }
  wLen>>=1; /* divide by 2 to get number of WORDs */

  /* for potential unaligned start of packet we need the following */
  if ((DWORD)poData & 1L) { /* odd address */
    /* mechanism here still does WORD reads for efficiency
     * at the cost of an extra shift & mask
     */
#if 1
    OCTET oMsb;
    WORD *pwData;
    WORD wData;
    oMsb = *poData;
    pwData = (WORD*)(poData+1);
    while(wLen--) {
      wData = *pwData++;
      dwSum += (oMsb<<8) | (wData>>8);
      oMsb  = wData & 0x00ff; /* grab LSB for next checksum MSB */
    }
#else
    /* alternative implementation possibly better if 'memory reads'
     * are more efficient
     */
    while(wLen--) {
      dwSum  += (*poData)<<8 | *(poData+1);
      poData += 2;
    }
#endif
  } else {
    WORD *pwData = (WORD*)poData;
    while(wLen--) {
      dwSum += *pwData++;
    }
  }

  /* 1s complement sum
   * Calculate using possible carry
   */
  dwSum = (dwSum >> 16) + (dwSum & 0xffff);
  dwSum += dwSum >> 16; /* add possible carry */

  /* Invert for result */
  return ((WORD)~dwSum);
}


#ifdef TESTCSUM16


#include <stdlib.h>
#include <stdio.h>

#include "hardware.h"
/*
 * ChecksumBuild
 *  Build the cheksum out of the 'DWORD dwSum' of a packet
 *
 *  Args:
 *   dwSum                      Sum of the WORDs
 *
 *  Return:
 *   Checksum
 */
static WORD _ChecksumBuild(DWORD dwSum)
{
  DWORD dwSumTotal = 0;

  dwSumTotal = dwSum;
  dwSum >>= 16;
  dwSum += dwSumTotal & 0xffff;
  /*add a possible carry*/
  dwSum += (dwSum>>16);

  return (WORD)((~dwSum) & 0xffff);
}


/*
 * IpChecksumFast
 *  Calculate a checksum (for IP etc.)
 *
 *  Args:
 *   pwBuf                      Ptr. to data to calc. checksum on
 *   wLen                       Length of the data in bytes
 *
 *  Return:
 *   Checksum
 */
WORD IpChecksumFast(WORD *pwBuf, WORD wLen)
{
  DWORD dwSum = 0;

  /* check for an unaligned octet */
  /* the unaligned octet must be the last data byte - form a 16 bit word of
   * that octet with padding zeros on the right side
   */
  if (wLen % 2) {
    wLen /= 2; /* to access 16 bit words */
    /*add the high byte (of the last octet) padded with zeros on the right*/
    dwSum += ((*(pwBuf+wLen)) & 0xff00);
  } else {
    wLen /= 2; /* to access 16 bit words */
  }

  while(wLen > 0) {
    dwSum += *pwBuf++;
    wLen--;
  }

    /* 1s complement sum
     * Calculate using possible carry
     */
    dwSum = (dwSum >> 16) + (dwSum & 0xffff);
    dwSum += dwSum >> 16; /* add possible carry */

    /* Invert for result */
    return ((WORD)~dwSum);

  return (_ChecksumBuild(dwSum));
}

void
testcsum16(void)
{
  WORD wReferenceCSum, wCSum, wLen, i;
  OCTET *poReferenceBuf, *poTestBuf;
  DWORD dwTime1, dwTime2;
  wLen = 52; /* even buffer length test */
  poReferenceBuf = (OCTET*)MALLOC(wLen);
  poTestBuf = (OCTET*)MALLOC(wLen+1); /* cope w/odd start test too */
  poTestBuf++; /* now odd address */

  for(i=0;i<wLen;i++) {
    poReferenceBuf[i] = (OCTET)(0x20+i*(3/2)); /* some weird pattern */
  }
  MOC_MEMCPY((ubyte *)poTestBuf,(ubyte *) poReferenceBuf, wLen);

  for(i=0; i<2; i++) { /* even len then odd len tests */
    dwTime1 = HW_GET_TIMER(0);
    /* old reference from network1 */
    wReferenceCSum = IpChecksumFast((WORD*)poReferenceBuf, wLen);
    dwTime2 = HW_GET_TIMER(0);
    printf("%s length pkt tests - reference CRC = %u\n", i==0 ? "Even" : "Odd",
           wReferenceCSum);
    printf("REFERENCE TIME: StartTime:%lu; EndTime:%lu; ElapsedTime = %lu\n",
           dwTime1, dwTime2, dwTime2>dwTime1 ? dwTime2-dwTime1 : 0xffffffff - (dwTime1-dwTime2));
    /* test 1: csum w/even len & even start of pkt */
    dwTime1 = HW_GET_TIMER(0);
    wCSum = Checksum16(poReferenceBuf, wLen);
    dwTime2 = HW_GET_TIMER(0);
    printf("Test %d: pData:%p; wLen:%u; CRC=%u; %s\n",i*2+1, poReferenceBuf, wLen,
           wCSum, wCSum==wReferenceCSum ? "SUCCESS" : "FAIL");
    printf("OUR TIME: StartTime:%lu; EndTime:%lu; ElapsedTime = %lu\n",
           dwTime1, dwTime2, dwTime2>dwTime1 ? dwTime2-dwTime1 : 0xffffffff - (dwTime1-dwTime2));

    dwTime1 = HW_GET_TIMER(0);
    wCSum = Checksum16(poTestBuf, wLen);
    dwTime2 = HW_GET_TIMER(0);
    printf("Test %d: pData:%p; wLen:%u; CRC=%u; %s\n",i*2+2, poTestBuf, wLen,
           wCSum, wCSum==wReferenceCSum ? "SUCCESS" : "FAIL");
    printf("OUR TIME: StartTime:%lu; EndTime:%lu; ElapsedTime = %lu\n",
           dwTime1, dwTime2, dwTime2>dwTime1 ? dwTime2-dwTime1 : 0xffffffff - (dwTime1-dwTime2));

    wLen--; /* make it odd for test #2 */
  }
  FREE(poReferenceBuf);
  FREE(--poTestBuf);
}
#endif
