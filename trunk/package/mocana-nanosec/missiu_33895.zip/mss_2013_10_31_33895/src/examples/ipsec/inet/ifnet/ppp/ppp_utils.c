/*
 * ppp_utils.c
 *
 * PPP utils function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "pppdefs.h"

/*
 * LcpOptionLength
 *  Calculate the length of the option field
 *
 *  Args:
 *   eOption        Option Type
 *   hData          option value handle
 *
 *  Return:
 *   option field length
 */
OCTET LcpOptionLength(E_PPPLCPOPTION eOption,H_NETDATA hData)
{
  ASSERT(eOption < PPPLCPOPTION_ENUMMAX);
  return aoLcpOptionToLength[eOption];
}

/*
 * PppInstanceLcpOptionSetValue
 *  Set the value field of an option
 *
 *  Args:
 *   pxState              PPP state
 *   eOption              Option
 *   hData                option value handle
 *   poField              pointer to the value field. It is assumed
 *                        to be of correct length
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG PppInstanceLcpOptionSetValue(PPPSTATE *pxState,
                                  E_PPPLCPOPTION eOption,
                                  H_NETDATA hData,OCTET *poField)
{
  ASSERT((pxState != NULL) &&
         (poField != NULL));

  switch(eOption) {
  case PPPLCPOPTION_MRU:
    PPPLCPOPTIONSET_MRU(poField,(DWORD)hData);
    break;
  case PPPLCPOPTION_AP:
  case PPPLCPOPTION_LQP:
    {
      WORD wProtIdx = (WORD)hData;
      ASSERT(wProtIdx <= pxState->wUlTableSize);
      PPPLCPOPTIONSET_PROT(poField,pxState->pxUlTable[wProtIdx].wProtocolId);
    }
  break;

  case PPPLCPOPTION_MN:
    PPPLCPOPTIONSET_MN(poField,pxState->dwCurrentMN);
    break;

  case PPPLCPOPTION_PFC:
  case PPPLCPOPTION_ACFC:
    /* No Value */
    break;
  default:
    ASSERT(0);
  }

  return NETERR_NOERR;
}

/*
 * LcpSetFieldFromOriginal
 *  Append a field copied from the provided original. Does
 *  the realloc, and updates the field length
 *
 *  Args:
 *   ppoField               Field to append to
 *   pwFieldLength          *ppoField length
 *   poOrig                 Original field
 *   wOrigLength            Original Length
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG LcpSetFieldFromOriginal(OCTET **ppoField,WORD *pwFieldLength,
                             OCTET *poOrig,WORD wOrigLength)
{
  ASSERT((ppoField != NULL) &&
         (poOrig != NULL));

  *ppoField = (OCTET *)
    realloc(*ppoField,(*pwFieldLength + wOrigLength)*sizeof(OCTET));
  memcpy(*ppoField + *pwFieldLength,poOrig, wOrigLength);
  *pwFieldLength += wOrigLength;

  return NETERR_NOERR;
}

/*
 * PppInstanceLcpSetOptionField
 *  Append Option field from given value handle. Does the reallocation
 *  and updates the option field length
 *
 *  Args:
 *   pxState                  PPP state
 *   ppoField                 Field
 *   pwFieldLength            *ppoField length
 *   eOption                  option
 *   hData                    option value handle
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG PppInstanceLcpSetOptionField(PPPSTATE *pxState,
                                  OCTET **ppoField,WORD *pwFieldLength,
                                  E_PPPLCPOPTION eOption,H_NETDATA hData)
{
  OCTET oAddedLength;
  OCTET *poPointer;
  oAddedLength = LcpOptionLength(eOption,hData);

  *ppoField = (OCTET *)
    realloc(*ppoField,(*pwFieldLength + oAddedLength)*sizeof(OCTET));
  ASSERT(*ppoField != NULL);

  poPointer = *ppoField + *pwFieldLength;
  *pwFieldLength += oAddedLength;

  PPPLCPOPTIONSET_TYPE(poPointer,eOption);
  PPPLCPOPTIONSET_LENGTH(poPointer,oAddedLength);
  if (oAddedLength > PPPLCP_HLEN) {
    /* If there is value to be set */
    PppInstanceLcpOptionSetValue(pxState,
                                 eOption,hData,poPointer);
  }

  return NETERR_NOERR;
}

/*
 * PppInstanceRemoteMruCheck
 *  Check that the proposed remote Mru is acceptable
 *
 *  Args:
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *   ppoRej                Rejected field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         rejected
 *   pwRejLength           value-return argument: length of *ppoRej
 *   ppoNak                Nak Field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         Naked
 *   pwNakLength           value-return argument: length of *ppoRej
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceRemoteMruCheck(PPPSTATE *pxState,H_NETDATA *phData,
                               OCTET *poData,OCTET oDataLength,
                               OCTET **ppoRej,WORD *pwRejLength,
                               OCTET **ppoNak,WORD *pwNakLength)
{
  WORD wMru = (WORD)(*phData), wCurrentMru;
  LONG lReturn = NETERR_NOERR;

  if (poData != NULL) {
    wMru = PPPLCPOPTIONGET_MRU(poData);  /* Remote MRU value */
    *phData = (H_NETDATA)wMru;
  }

  wCurrentMru = (WORD)pxState->ahLcpRemoteOption[PPPLCPOPTION_MRU];

  PPP_DBGP(REPETITIVE, "PppInstanceRemoteMruCheck: Maximum-Receive-Unit = %d, wCurrentMru %d\n", wMru, wCurrentMru);
  /* If greater than default size (1500) reject because we can only send
   * smaller packets - actually we strictly don't need to do this per RFC1548 sec. 6.1 */
  if (wMru > PPPDEFAULT_MRU) {
    PppInstanceLcpSetOptionField(pxState,ppoNak,
                                 pwNakLength,
                                 PPPLCPOPTION_MRU,
                                 (H_NETDATA)wCurrentMru);
    *phData = (H_NETDATA)wCurrentMru;
    lReturn = NETERR_UNKNOWN;
  }
  if (wMru < wCurrentMru) {
  /* The remote value is less than ours, we should adjust our wMtu value
   * accordingly. */
    if (pxState->pfnNetCbk(pxState->hNetCbk,PPPCBK_CHANGEMTU,(H_NETDATA)wMru) < 0)
      lReturn = NETERR_UNKNOWN;
    *phData = (H_NETDATA)wMru;
  }

  return lReturn;
}

/*
 * PppInstanceLocalMruCheck
 *  Check that the proposed Local Mru is acceptable
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceLocalMruCheck(PPPSTATE *pxState,H_NETDATA *phData,
                              OCTET *poData,OCTET oDataLength)
{
  WORD wMru = (WORD)(*phData), wCurrentMru;
  LONG lReturn = NETERR_NOERR;

  if (poData != NULL) {
    wMru = PPPLCPOPTIONGET_MRU(poData);
    *phData = (H_NETDATA)wMru;
  }

  wCurrentMru = (WORD)pxState->ahLcpLocalOption[PPPLCPOPTION_MRU];

  PPP_DBGP(REPETITIVE, "PppInstanceLocalMruCheck: Maximum-Receive-Unit = %d, wCurrentMru %d\n", wMru, wCurrentMru);
  if (wCurrentMru < wMru) {
    /* the asked for Mru is bigger than ours: no ! */
    *phData = (H_NETDATA)wCurrentMru;
    lReturn = NETERR_UNKNOWN;
  }

  return lReturn;
}

/*
 * PppInstanceRemoteLinkProtCheck
 *  Check that the proposed remote Mru is acceptable
 *
 *  Args:
 *   pxState               PPP State
 *   oLinkType             Link Protocol Type
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *   ppoRej                Rejected field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         rejected
 *   pwRejLength           value-return argument: length of *ppoRej
 *   ppoNak                Nak Field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         Naked
 *   pwNakLength           value-return argument: length of *ppoRej
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceRemoteLinkProtCheck(PPPSTATE *pxState,OCTET oLinkType,
                                    H_NETDATA *phData,
                                    OCTET *poData,OCTET oDataLength,
                                    OCTET **ppoRej,WORD *pwRejLength,
                                    OCTET **ppoNak,WORD *pwNakLength)
{
  LONG lReturn = NETERR_NOERR;
  OCTET oProtNum;
  WORD wProtIdx = (WORD)(*phData);
  OCTET oOption;

  if (oLinkType == PPPLINKPROTTYPE_AP) {
    oProtNum = pxState->oApNum;
    oOption = PPPLCPOPTION_AP;
  }
  else {
    oProtNum = pxState->oLqpNum;
    oOption = PPPLCPOPTION_LQP;
  }

  if (oProtNum == 0) {
    /* not supported: reject if any is proposed*/
    *phData = (H_NETDATA)PPPPROTIDX_NONE;
    if (poData != NULL) {
      LcpSetFieldFromOriginal(ppoRej,pwRejLength,poData,oDataLength);

      lReturn = NETERR_UNKNOWN;
    }
    else if (wProtIdx != PPPPROTIDX_NONE) {
      PppInstanceLcpSetOptionField(pxState,ppoRej,
                                   pwRejLength,oOption,
                                   (H_NETDATA)wProtIdx);
      lReturn = NETERR_UNKNOWN;
    }
  }
  else if (poData != NULL) {
    WORD wProtId = PPPLCPOPTIONGET_PROT(poData);

    wProtIdx = (WORD)
      PppInstanceFindUlIdxFromProtocolId(pxState,wProtId);
    *phData = (H_NETDATA)wProtIdx;

    if (wProtIdx == PPPPROTIDX_NONE) {
      /* Ap is supported, but not that specific protocol: nak */
      /* Modify the packet to indicate which auth protocol we prefer */
      /* TODO: This should be handled by a function elsewhere */
      oDataLength = 5;
      poData[0] = PPPLCPOPTIONCODE_AP;
      poData[1] = oDataLength;
      poData[2] = (PPPID_CHAP >> 8);
      poData[3] = (PPPID_CHAP & 0xFF);
      poData[4] = 0x05;     /* MD5 */

      /* Nak the original ReqConf message */
      LcpSetFieldFromOriginal(ppoNak,pwNakLength,poData,oDataLength);
      lReturn = NETERR_UNKNOWN;
    }
    else {
      /* Supported: check that its configuration is supported */
      if (oLinkType == PPPLINKPROTTYPE_AP) {
        PPPOPTIONFIELD xApConf;
        xApConf.wProtocolId = wProtId;
        xApConf.wFieldLength = PPPLCPOPTION_GETPROTDATALENGTH(oDataLength);
        if (xApConf.wFieldLength > 0) {
          xApConf.poField = PPPLCPOPTIONGET_PROTDATAPOINTER(poData);
        }
        if (pxState->pfnNetCbk(pxState->hNetCbk,PPPCBK_AUTHENTICATECONF,
                               (H_NETDATA) &xApConf) < 0) {
          LcpSetFieldFromOriginal(ppoNak,pwNakLength,poData,oDataLength);
          lReturn = NETERR_UNKNOWN;
        }
      }
    }
  }

  return lReturn;
}


/*
 * PppInstanceLocalLinkProtCheck
 *  Check that the proposed Local Link Protocol is acceptable
 *   pxState               PPP State
 *   oLinkType             Link Protocol Type
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceLocalLinkProtCheck(PPPSTATE *pxState,OCTET oLinkType,
                                   H_NETDATA *phData,OCTET *poData,
                                   OCTET oDataLength)
{
  LONG lReturn = NETERR_NOERR;
  OCTET oProtNum;
  WORD wProtIdx = (WORD)(*phData);
  OCTET oOption;

  if (oLinkType == PPPLINKPROTTYPE_AP) {
    oProtNum = pxState->oApNum;
    oOption = PPPLCPOPTION_AP - PPPLCPOPTION_MRU;
  }
  else {
    oProtNum = pxState->oLqpNum;
    oOption = PPPLCPOPTION_LQP - PPPLCPOPTION_MRU;
  }

  if (oProtNum == 0) {
    /* not supported: reject */
    if (poData != NULL) {
      lReturn = NETERR_UNKNOWN;
    }
    else if (wProtIdx != PPPPROTIDX_NONE) {
      lReturn = NETERR_UNKNOWN;
    }
  }
  else {
    if (poData != NULL) {
      wProtIdx = (WORD)
        PppInstanceFindUlIdxFromProtocolId(pxState,
                                           PPPLCPOPTIONGET_PROT(poData));
    }

    if (wProtIdx !=
        pxState->ahLcpLocalOption[PPPLCPOPTION_AP - PPPLCPOPTION_MRU]) {
      /* Ap is supported, but it is not the one we want */
      lReturn = NETERR_UNKNOWN;
    }
  }

  *phData = pxState->ahLcpLocalOption[PPPLCPOPTION_AP - PPPLCPOPTION_MRU];

  return lReturn;
}

/*
 * PppInstanceRemoteApCheck
 *  Check that the proposed remote AP is acceptable
 *
 *  Args:
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *   ppoRej                Rejected field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         rejected
 *   pwRejLength           value-return argument: length of *ppoRej
 *   ppoNak                Nak Field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         Naked
 *   pwNakLength           value-return argument: length of *ppoRej
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceRemoteApCheck(PPPSTATE *pxState,H_NETDATA *phData,
                              OCTET *poData,OCTET oDataLength,
                              OCTET **ppoRej,WORD *pwRejLength,
                              OCTET **ppoNak,WORD *pwNakLength)
{
  return (PppInstanceRemoteLinkProtCheck(pxState,PPPLINKPROTTYPE_AP,
                                         phData,poData,oDataLength,ppoRej,
                                         pwRejLength,ppoNak,pwNakLength));

}

/*
 * PppInstanceLocalApCheck
 *  Check that the proposed Local AP is acceptable
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceLocalApCheck(PPPSTATE *pxState,H_NETDATA *phData,
                             OCTET *poData,OCTET oDataLength)
{
  return (PppInstanceLocalLinkProtCheck(pxState,PPPLINKPROTTYPE_AP,
                                        phData,poData,oDataLength));
}


/*
 * PppInstanceRemoteLqpCheck
 *  Check that the proposed remote LQP is acceptable
 *
 *  Args:
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *   ppoRej                Rejected field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         rejected
 *   pwRejLength           value-return argument: length of *ppoRej
 *   ppoNak                Nak Field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         Naked
 *   pwNakLength           value-return argument: length of *ppoRej
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceRemoteLqpCheck(PPPSTATE *pxState,H_NETDATA *phData,
                               OCTET *poData,OCTET oDataLength,
                               OCTET **ppoRej,WORD *pwRejLength,
                               OCTET **ppoNak,WORD *pwNakLength)
{
  return (PppInstanceRemoteLinkProtCheck(pxState,PPPLINKPROTTYPE_LQP,
                                         phData,poData,oDataLength,ppoRej,
                                         pwRejLength,ppoNak,pwNakLength));
}

/*
 * PppInstanceLocalLqpCheck
 *  Check that the proposed Local LQP is acceptable
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceLocalLqpCheck(PPPSTATE *pxState,H_NETDATA *phData,
                             OCTET *poData,OCTET oDataLength)
{
  return (PppInstanceLocalLinkProtCheck(pxState,PPPLINKPROTTYPE_LQP,
                                        phData,poData,oDataLength));
}

/*
 * PppInstanceRemoteMnCheck
 *  Check that the proposed remote Magic Number is acceptable
 *
 *  Args:
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *   ppoRej                Rejected field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         rejected
 *   pwRejLength           value-return argument: length of *ppoRej
 *   ppoNak                Nak Field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         Naked
 *   pwNakLength           value-return argument: length of *ppoRej
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceRemoteMnCheck(PPPSTATE *pxState,H_NETDATA *phData,
                              OCTET *poData,OCTET oDataLength,
                              OCTET **ppoRej,WORD *pwRejLength,
                              OCTET **ppoNak,WORD *pwNakLength)
{
  DWORD dwMN = (WORD)(*phData);
  LONG lReturn = NETERR_NOERR;

  if (poData != NULL) {
    dwMN = PPPLCPOPTIONGET_MN(poData);
  }

  /* if we receive a remote MN, we need to support it locally */
  if (dwMN == pxState->dwCurrentMN) {
    pxState->dwCurrentMN = rand();
    PppInstanceLcpSetOptionField(pxState,ppoNak,pwNakLength,
                                 PPPLCPOPTION_MN - PPPLCPOPTION_MRU,
                                 (H_NETDATA)pxState->dwCurrentMN);
    lReturn = NETERR_UNKNOWN;

  }
  *phData = pxState->dwCurrentMN;

  return lReturn;
}

/*
 * PppInstanceLocalMnCheck
 *  Check that the proposed Local Magic Number is acceptable
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceLocalMnCheck(PPPSTATE *pxState,H_NETDATA *phData,
                             OCTET *poData,OCTET oDataLength)
{
  DWORD dwMN = (WORD)(*phData);
  LONG lReturn = NETERR_NOERR;

  if (poData != NULL) {
    dwMN = PPPLCPOPTIONGET_MN(poData);
  }

  /* if we receive a remote MN, we need to support it locally */
  if (dwMN == pxState->dwCurrentMN) {
    pxState->dwCurrentMN = rand();
    lReturn = NETERR_UNKNOWN;
  }

  *phData = pxState->dwCurrentMN;

  return lReturn;
}

/*
 * PppInstanceRemoteAcfcCheck
 *  Check that the proposed remote Acfc is acceptable
 *
 *  Args:
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *   ppoRej                Rejected field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         rejected
 *   pwRejLength           value-return argument: length of *ppoRej
 *   ppoNak                Nak Field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         Naked
 *   pwNakLength           value-return argument: length of *ppoRej
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceRemoteAcfcCheck(PPPSTATE *pxState,H_NETDATA *phData,
                                OCTET *poData,OCTET oDataLength,
                                OCTET **ppoRej,WORD *pwRejLength,
                                OCTET **ppoNak,WORD *pwNakLength)
{

  if ((poData != NULL) || (TRUE == (*phData))) {
    /* Always reject Acfc, as it is not supported yet */
    PppInstanceLcpSetOptionField(pxState,ppoRej,pwRejLength,
                                 PPPLCPOPTION_ACFC,(H_NETDATA)FALSE);

    *phData = (H_NETDATA)FALSE;
    return NETERR_UNKNOWN;
  }

  return NETERR_NOERR;
}


/*
 * PppInstanceLocalAcfcCheck
 *  Check that the proposed Local Acfc is acceptable
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceLocalAcfcCheck(PPPSTATE *pxState,H_NETDATA *phData,
                               OCTET *poData,OCTET oDataLength)
{

  if (*phData == (H_NETDATA) TRUE) {
    *phData = (H_NETDATA)FALSE;
    return NETERR_UNKNOWN;
  }

  return NETERR_NOERR;
}


/*
 * PppInstanceRemotePfcCheck
 *  Check that the proposed remote Pfc is acceptable
 *
 *  Args:
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *   ppoRej                Rejected field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         rejected
 *   pwRejLength           value-return argument: length of *ppoRej
 *   ppoNak                Nak Field. Will be appropriately filled
 *                         reallocated and filled up if the option is
 *                         Naked
 *   pwNakLength           value-return argument: length of *ppoRej
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceRemotePfcCheck(PPPSTATE *pxState,H_NETDATA *phData,
                               OCTET *poData,OCTET oDataLength,
                               OCTET **ppoRej,WORD *pwRejLength,
                               OCTET **ppoNak,WORD *pwNakLength)
{
  /* Always reject Pfc, as it is not supported yet */
  if ((poData != NULL) || (TRUE == (*phData))) {
    PppInstanceLcpSetOptionField(pxState,ppoRej,pwRejLength,
                                 PPPLCPOPTION_ACFC,(H_NETDATA)FALSE);

    *phData = (H_NETDATA)FALSE;

    return NETERR_UNKNOWN;
  }

  return NETERR_NOERR;
}

/*
 * PppInstanceLocalPfcCheck
 *  Check that the proposed Local PFC is acceptable
 *   pxState               PPP State
 *   phData                value-return data handle. It is used
 *                         as an input iff poData is NULL, and always filled
 *                         with the wanted value as a return.
 *   poData                inline value
 *   oDataLength           poData length
 *
 *  Return:
 *   >=0 if acceptable, < 0 if not
 */
LONG PppInstanceLocalPfcCheck(PPPSTATE *pxState,H_NETDATA *phData,
                              OCTET *poData,OCTET oDataLength)
{
  /* Always reject Pfc, as it is not supported yet */
  if (*phData == (H_NETDATA) TRUE) {
    *phData = (H_NETDATA)FALSE;

    return NETERR_UNKNOWN;
  }

  return NETERR_NOERR;
}

/*
 * LcpOptionGetType
 *  Get the option type from the option field
 *
 *  Args:
 *   poPayload               pointer to the option field
 *
 *  Return:
 *   Option type or NETERR_NOERR (illegal type)
 */
SHORT LcpOptionGetType(OCTET *poPayload)
{
  OCTET oCode = *(poPayload + PPPLCPOPTIONOFFSET_TYPE);

  PPP_DBGP(REPETITIVE,"LcpOptionGetType:oCode = %d\n",oCode);

  if (oCode > PPPLCPOPTIONCODE_MAX) {
    return NETERR_UNKNOWN;
  }

  return (SHORT)aoLcpCodeToOption[oCode];
}

/*
 * PppInstanceLcpConfReq
 *  Handle a Configure Request
 *
 *  Args:
 *   pxState                  PPP state
 *   pxOptions                option field structure pointer
 *
 *  Return:
 *   < 0 indicates Nak/Rej. >=0 Ack
 */
LONG PppInstanceLcpConfReq(PPPSTATE *pxState,PPPCPOPTIONFIELDS *pxOptions)
{
  OCTET *poLast;
  OCTET *poPointer;
  BOOL abDefined[PPPLCPOPTION_ENUMMAX];
  OCTET o;
  LONG lReturn = NETERR_NOERR;

  ASSERT((pxState != NULL) &&
         (pxOptions != NULL) &&
         (pxOptions->poReq != NULL));

  poLast = pxOptions->poReq + pxOptions->wReqLength;
  poPointer = pxOptions->poReq;

  ASSERT((pxOptions->poRej == NULL) &&
         (pxOptions->wRejLength == 0) &&
         (pxOptions->poNak == NULL) &&
         (pxOptions->wNakLength == 0));

  bzero(abDefined,PPPLCPOPTION_ENUMMAX);

  while(poPointer < poLast) {
    OCTET oLength;
    SHORT sType;

    sType = PPPLCPOPTIONGET_TYPE(poPointer);
    oLength = PPPLCPOPTIONGET_LENGTH(poPointer);

    if(oLength == 0){
      ASSERT(0);
      return -1;
    }

    PPP_DBGP(REPETITIVE,"PppInstanceLcpConfReq:sType = %d, oLength = %d\n",sType,oLength);

    if (sType != NETERR_UNKNOWN) {
      H_NETDATA hData;
      if((sType < 0) || (sType >= PPPLCPOPTION_ENUMMAX)){
        return -1;
      };
      abDefined[sType] = TRUE;

      if (apfnPppInstanceLcpCheckRemoteOption[sType]
          (pxState,&hData,poPointer,oLength,
           &(pxOptions->poRej), &(pxOptions->wRejLength),
           &(pxOptions->poNak), &(pxOptions->wNakLength)) >= 0) {
        /* Accepted the option: set the remote  */
        pxState->ahLcpRemoteOption[sType] = hData;
      }
    } else {
      LcpSetFieldFromOriginal(&pxOptions->poRej,&pxOptions->wRejLength,poPointer,oLength);
    }
    poPointer += oLength;
  }

  /* Check the undefined options */
  for (o=0; o < PPPLCPOPTION_ENUMMAX; o++) {
    if (abDefined[o] != TRUE) {
      H_NETDATA hData = ahLcpOptionDefault[o];
      if (apfnPppInstanceLcpCheckRemoteOption[o]
          (pxState,&hData,NULL,0,&(pxOptions->poRej), &(pxOptions->wRejLength),
           &(pxOptions->poNak), &(pxOptions->wNakLength)) >= 0) {
        /* Accepted the option: set the remote */
        pxState->ahLcpRemoteOption[o] = hData;
      }
    }
  }

  if ((pxOptions->poRej != NULL) || (pxOptions->poNak != NULL)) {
    lReturn = NETERR_UNKNOWN;
  }

  return lReturn;
}


/*
 * PppInstanceLcpConfNak
 *  Handle a Configure Nak
 *
 *  Args:
 *   pxState                  PPP state
 *   pxOptions                option field structure pointer
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG PppInstanceLcpConfNak(PPPSTATE *pxState,PPPCPOPTIONFIELDS *pxOptions)
{
  OCTET *poLast;
  OCTET *poPointer;
  OCTET oLength;

  ASSERT((pxState != NULL) &&
         (pxOptions != NULL) &&
         (pxOptions->poNak != NULL));

  poLast = pxOptions->poNak + pxOptions->wNakLength;
  poPointer = pxOptions->poNak;

  while(poPointer < poLast) {
    SHORT sType = PPPLCPOPTIONGET_TYPE(poPointer);
    H_NETDATA hData;

    if((sType < 0) || (sType >= PPPLCPOPTION_ENUMMAX)){
      return -1;
    };

    oLength = PPPLCPOPTIONGET_LENGTH(poPointer);

    if (apfnPppInstanceLcpCheckLocalOption[sType]
        (pxState,&hData,poPointer,oLength) >= 0) {
      pxState->ahLcpLocalOption[sType] = hData;
    }
    poPointer +=oLength;
  }

  return NETERR_NOERR;
}

/*
 * PppInstanceLcpConfRej
 *  Handle a Configure Rej
 *
 *  Args:
 *   pxState                  PPP state
 *   pxOptions                option field structure pointer
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG PppInstanceLcpConfRej(PPPSTATE *pxState,PPPCPOPTIONFIELDS *pxOptions)
{
  OCTET *poLast;
  OCTET *poPointer;
  OCTET oLength;

  ASSERT((pxState != NULL) &&
         (pxOptions != NULL) &&
         (pxOptions->poRej != NULL));

  poLast = pxOptions->poRej + pxOptions->wRejLength;
  poPointer = pxOptions->poRej;

  while(poPointer < poLast) {
    SHORT sType = PPPLCPOPTIONGET_TYPE(poPointer);
    H_NETDATA hValue;

    if((sType < 0) || (sType >= PPPLCPOPTION_ENUMMAX)){
      return -1;
    };

    oLength = PPPLCPOPTIONGET_LENGTH(poPointer);

    if ((sType == PPPLCPOPTION_PFC) || (sType == PPPLCPOPTION_PFC)) {
      /* Binary options */
      hValue = (H_NETDATA)FALSE;
    }
    else if ((sType == PPPLCPOPTION_AP) || (sType == PPPLCPOPTION_LQP)) {
      hValue = (H_NETDATA)PPPPROTIDX_NONE;
    }

    if (apfnPppInstanceLcpCheckLocalOption[sType]
        (pxState,&hValue,NULL,0) >= 0) {
      pxState->ahLcpLocalOption[sType] = hValue;
    }
    poPointer += oLength;
  }

  return NETERR_NOERR;
}

/*
 * PppInstanceLcpOptionCode
 *  Code a Conf Req
 *
 *  Args:
 *   pxState                      PPP state
 *   pxOptions                    options structure. Only poReq, wReLength
 *                                members are modified
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG PppInstanceLcpOptionCode(PPPSTATE *pxState,PPPCPOPTIONFIELDS *pxOptions)
{
  OCTET o;

  ASSERT((pxState != NULL) &&
         (pxOptions != NULL) &&
         (pxOptions->poReq == NULL));

  for (o = 0; o < PPPLCPOPTION_ENUMMAX; o++) {
    H_NETDATA hValue;
    /* Only add the field is the wanted choice is different from
       the default. As specified in RFC 1661 */
    if ((hValue = pxState->ahLcpLocalOption[o])!= ahLcpOptionDefault[o]) {

      PppInstanceLcpSetOptionField(pxState,&(pxOptions->poReq),
                                   &(pxOptions->wReqLength),o,hValue);

    }
  }

  return NETERR_NOERR;
}

/*
 * PppInstanceLcpUnknown
 *  Handles LCP specific commands (ECHO_XXX). Always call
 *  DELUSER on the passed-in payload.
 *
 *  Args:
 *   pxState                     PPP packet
 *   pxPacket                    unknown code packet
 *
 *  Return:
 *   >=0 if the packet has been dealt with. <0 if not.
 */
LONG PppInstanceLcpUnknownCode(PPPSTATE *pxState,PPPCPPACKET *pxPacket)
{
  LONG lReturn = NETERR_NOERR;
  OCTET oCommand;
  OCTET oIdentifier;
  OCTET wLength;
  OCTET *poPacket;

  PPP_CHECK_STATE(pxState);
  NETPACKET_CHECK(pxPacket->pxPacket);

  poPacket = pxPacket->pxPacket->pxPayload->poPayload +
    pxPacket->pxAccess->wOffset;

  oCommand = PPPLCPGET_COMMAND(poPacket);
  oIdentifier = PPPLCPGET_ID(poPacket);
  wLength = PPPLCPGET_LENGTH(poPacket);

  /* The only LCP specific Command is ECHOREQUEST/REPLY */
  if (oCommand == PPPLCPCOMMAND_ECHOREQUEST) {
    if (pxState->ePhase >= PPPPHASE_ESTABLISH) {
      /* It is only valid in the network phase */
      WORD wSize;
      OCTET *poPayload;
      OCTET *poPointer;
      NETPACKETACCESS xAccess;
      NETPACKET xNetPacket;

      xAccess.wOffset = pxPacket->pxAccess->wOffset; /* Contains the
                                                       PPP protocol field */

      /* Add the tunnel mode stuff for safety */
      if (pxState->oTunnelMode == PPPTUNNELMODE_PPTP) {
        xAccess.wOffset += PPPPPTP_HDRLEN;
      }
      else {
        xAccess.wOffset += PPPDEFAULT_HDRLEN;
      }

      xAccess.wLength = PPPLCPCOMMANDLENGTH_ECHOREPLY;
      wSize = xAccess.wOffset + PPPLCPCOMMANDLENGTH_ECHOREPLY +
        pxState->wTrailer;

      poPayload = (OCTET *)malloc(wSize);
      ASSERT(poPayload != NULL);

      poPointer = poPayload + xAccess.wOffset;

      PPPLCPSET_COMMAND(poPointer,PPPLCPCOMMAND_ECHOREPLY);
      PPPLCPSET_ID(poPointer,oIdentifier);
      PPPLCPSET_LENGTH(poPointer,PPPLCPCOMMANDLENGTH_ECHOREPLY);

      PPPLCPOPTIONSET_MN(PPPLCPGET_DATAPOINTER(poPointer),
                         pxState->dwCurrentMN);

      NETPAYLOAD_CREATE(&(xNetPacket.pxPayload),
                        NetFree,pxState->pxMutex,
                        poPayload,wSize);
      xNetPacket.hMarker = (H_NETDATA)NULL;

      PppInstanceWrite((H_NETINSTANCE)pxState,(H_NETINTERFACE)PPPID_LCP,
                       &xNetPacket,&xAccess,pxPacket->hData);

    }
  }

  else if (oCommand == PPPLCPCOMMAND_ECHOREPLY) {
  /* Handle the reception of an Echo Reply:
   * Increment the counter - to prevent it from hitting zero
   * which would cause disconnection */

    pxState->dwEchoCount++;
  }

  else {
    /* Unknown command */
    lReturn = NETERR_UNKNOWN;
  }

  /* Free the packet */
  NETPAYLOAD_DELUSER(pxPacket->pxPacket->pxPayload);

  return lReturn;
}


/*
 * PppInstanceOptionResetDefault
 *  Reset the PPP protocol option to default
 *
 *  Args:
 *   pxState               instance
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG PppInstanceOptionResetDefault(PPPSTATE *pxState)
{
  PPP_CHECK_STATE(pxState);

  memcpy(pxState->ahLcpLocalOption,ahLcpOptionDefault,
         PPPLCPOPTION_ENUMMAX * sizeof(H_NETDATA));
  memcpy(pxState->ahLcpRemoteOption,ahLcpOptionDefault,
         PPPLCPOPTION_ENUMMAX * sizeof(H_NETDATA));

  return NETERR_NOERR;
}


/*
 * PppInstanceLcpCbk
 *  Cbk given to PPP CP
 *
 *  Args:
 *   hPpp               PPP state handle
 *   oCbk               Cbk code
 *   hData              Cbk data handle
 *
 *  Return
 *   <0 if problem (Cbk dependant)
 */
LONG PppInstanceLcpCbk(H_NETINSTANCE hPpp, OCTET oCbk, H_NETDATA hData)
{
  LONG lReturn = NETERR_NOERR;
  PPPSTATE *pxState = (PPPSTATE *)hPpp;

  PPP_CHECK_STATE(pxState);
  ASSERT(pxState->pfnNetCbk != NULL);

  PPP_DBGP(REPETITIVE,"PppInstanceLcpCbk:hPpp=%d,oCbk=%s,hData=%d\n",
           (int)hPpp,
           ((oCbk >= NETCBK_MODULESPECIFICBEGIN) ?
           apoPppCpCbkString[oCbk - NETCBK_MODULESPECIFICBEGIN]:
           apoNetCbkString[oCbk]),
           (int)hData);

  switch(oCbk) {
  case NETCBK_TLU:
    /* LCP is up */
    {
      WORD wApIdx = (WORD)pxState->ahLcpRemoteOption[PPPLCPOPTION_AP];

      if (wApIdx != PPPPROTIDX_NONE) {
        /* Authenticating is needed */
        pxState->ePhase = PPPPHASE_AUTHENTICATE;
        pxState->pfnNetCbk(pxState->hNetCbk,PPPCBK_AUTHENTICATE,
                           (WORD)pxState->pxUlTable[wApIdx].wProtocolId);

      }
      else {
        /* go straight to NETWORK phase */
        pxState->ePhase = PPPPHASE_NETWORK;
        pxState->pfnNetCbk(pxState->hNetCbk,NETCBK_TLU,(H_NETDATA)0);

      }
    }
    break;

  case NETCBK_TLD:
    pxState->ePhase = PPPPHASE_DEAD;
    pxState->pfnNetCbk(pxState->hNetCbk,NETCBK_TLD,hData);
    break;

  case PPPCPCBK_RXCONFREQ: /* Received a Conf Req */
    {
      PPPCPOPTIONFIELDS *pxOptions = ( PPPCPOPTIONFIELDS *)hData;

      lReturn = PppInstanceLcpConfReq(pxState,pxOptions);
      ASSERT(pxOptions != NULL);

    }
  break;

  case PPPCPCBK_RXCONFNAK:
    {
      PPPCPOPTIONFIELDS *pxOptions = ( PPPCPOPTIONFIELDS *)hData;

      lReturn = PppInstanceLcpConfNak(pxState,pxOptions);
    }
  break;

  case PPPCPCBK_RXCONFREJ:
    {
      PPPCPOPTIONFIELDS *pxOptions = ( PPPCPOPTIONFIELDS *)hData;

      lReturn = PppInstanceLcpConfRej(pxState,pxOptions);
    }
  break;

  case PPPCPCBK_OPTIONCODE:
    {
      PPPCPOPTIONFIELDS *pxOptions = (PPPCPOPTIONFIELDS *)hData;

      lReturn = PppInstanceLcpOptionCode(pxState,pxOptions);
    }
  break;


  case PPPCPCBK_RXUNKNOWNCODE:
  {
    PPPCPPACKET *pxPacket = (PPPCPPACKET *)hData;

    lReturn = PppInstanceLcpUnknownCode(pxState,pxPacket);
  }
  break;



  default:
    /* Transmit the messages up */
    pxState->pfnNetCbk(pxState->hNetCbk,oCbk,hData);

  }

  return lReturn;
}
