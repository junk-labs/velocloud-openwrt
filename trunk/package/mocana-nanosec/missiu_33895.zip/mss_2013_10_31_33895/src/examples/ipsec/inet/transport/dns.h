/*
 * dns.h
 *
 * Defines and data structures for domain name server routines
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __DNS_H__
#define __DNS_H__

#undef TRACE_ALWAYS



/****************************************************************************
 *
 * Definitions
 *
 ****************************************************************************/

/* miscellaneous constants */
#define MAGIC_VALUE  0x211221
#define SRVNAME_SIZE      256
#define MAX_RECORDS         8
#define DNS_PORT           53
#define IP_ADDR_LEN         4
#define DNS_MAX_REPLY_LEN 512
#define DNS_MAX_REFERRALS  10  /* return HOST_NOT_FOUND if limit reached */
#define DNS_MAX_NAME_LEN 80 /* TEMP - should use common define w/main code for this */


/* TYPES and QTYPES */
#define DNSTYPE_A       1 /* a host address                              */
#define DNSTYPE_NS      2 /* an authoritative name server                */
#define DNSTYPE_MD      3 /* a mail destination (obsolete - use MX)      */
#define DNSTYPE_MF      4 /* a mail forwarder (obsolete - use MX)        */
#define DNSTYPE_CNAME   5 /* the canonical name for an alias             */
#define DNSTYPE_SOA     6 /* marks the start of a zone of authority      */
#define DNSTYPE_MB      7 /* a mailbox domain name (EXPERIMENTAL)        */
#define DNSTYPE_MG      8 /* a mail group member (EXPERIMENTAL)          */
#define DNSTYPE_MR      9 /* a mail rename domain name (EXPERIMENTAL)    */
#define DNSTYPE_NULL   10 /* a null RR (EXPERIMENTAL)                    */
#define DNSTYPE_WKS    11 /* a well known service description            */
#define DNSTYPE_PTR    12 /* a domain name pointer                       */
#define DNSTYPE_HINFO  13 /* host information                            */
#define DNSTYPE_MINFO  14 /* mailbox or mail list information            */
#define DNSTYPE_MX     15 /* mail exchange                               */
#define DNSTYPE_TXT    16 /* text strings                                */
#define DNSTYPE_SRV    33 /* SRV strings                                */
#define DNSTYPE_AXFR  252 /* request for a transfer of an entire zone    */
#define DNSTYPE_MAILB 253 /* request mailbox-related records (MB,MG,MR)  */
#define DNSTYPE_MAILA 254 /* request mail agent RRs (obsolete - see MX)  */
#define DNSTYPE_STAR  255 /* request for all records                     */

/* CLASS and QCLASS values */
#define DNSCLASS_IN     1 /* the Internet                                */
#define DNSCLASS_CS     2 /* the CSNET class (Obsolete)                  */
#define DNSCLASS_CH     3 /* the CHAOS class                             */
#define DNSCLASS_HS     4 /* Hesiod [Dyer 87]                            */
#define DNSCLASS_STAR 255 /* any class                                   */


typedef enum DNS_PARSE_REPLY_TYPE {
  DNS_PARSE_QUESTION,
  DNS_PARSE_ANSWER,
  DNS_PARSE_REFERRAL,
  DNS_PARSE_NOT_FOUND,
  DNS_PARSE_ERROR
} DNS_PARSE_REPLY_TYPE;

typedef enum DNS_LOOKUP_TYPE {
  DNS_LOOKUP_NAME = DNSTYPE_A ,
  DNS_LOOKUP_ADDR = DNSTYPE_PTR,
  DNS_LOOKUP_SRV  = DNSTYPE_SRV,
  DNS_LOOKUP_TXT  = DNSTYPE_TXT
} ENUM_DNS_LOOKUP;


/****************************************************************************
 *
 * Data structures
 *
 ****************************************************************************/

/* structure for linked list of hostents (1 per pid ) */
typedef struct hostent_list {
  WORD                wPId;
  WORD                wSpare;               /* pad to DWORD */
  struct hostent      xHostEnt;
  struct hostent_list *pxNext;
} HOSTENT_LIST;

typedef struct {                            /*This is only used in an SRV lookup */
  unsigned short wPriority;
  unsigned short wWeight;
  unsigned short wPort;
} DNS_SRV;

typedef struct DnsQuerySet {
  OCTET           szService[24];    /*Service requested */
  OCTET           oListRecs[MAX_RECORDS+2];    /*List of good records for Service requested */
  WORD            wType;            /*Query type e.g. TXT or SRV */
#ifndef NDEBUG
  DWORD           dwMagicCookie;    /*Debug */
#endif
  struct hostent  *pxHostEnt;       /*Ptr to struct returned by DNS lookup */
} DNS_QUERY_SET;

/* Description of database entry for a single host  */
typedef struct {
  WORD wId;                    /* assigned to match queries with responses */
  WORD wMisc;                  /* bit field-see bitmask definitions below  */
#define QR_MASK        0x8000  /* 0 = query, 1 = response                  */
#define OPCODE_MASK    0x7800  /* 0-2 see below, 3-15 reserved             */
# define OPCODE_QUERY       0  /* standard query                           */
# define OPCODE_IQUERY 0x0800  /* inverse query                            */
# define OPCODE_STATUS 0x1000  /* server status                            */
#define AA_MASK        0x0400  /* Authoritative answer - valid in response */
#define TC_MASK        0x0200  /* msg truncated due to length > permitted  */
#define RD_MASK        0x0100  /* Recursion Desired                        */
#define RA_MASK        0x0080  /* Recursion Avail.-set by NS if supported  */
#define Z_MASK         0x0070  /* reserved - must be zero                  */
#define RCODE_MASK     0x000F  /* Response code 1-5 below, 6-15 reserved   */
# define RCODE_NO_ERR       0  /* No error condition                       */
# define RCODE_FRMT_ERR     1  /* Format error-NS couldn't interpret query */
# define RCODE_SRVR_FAIL    2  /* Server failure - due to problem with NS  */
# define RCODE_NAME_ERR     3  /* Name Error - domain name does not exist  */
# define RCODE_NOT_IMPL     4  /* Not Implemented-query type not supported */
# define RCODE_REFUSED      5  /* NS refuses operation for policy reasons  */
  WORD wQdCount;               /* # of entries in question section         */
  WORD wAnCount;               /* # of resource records in answer section  */
  WORD wNsCount;               /* # of NS RRs in authority records section */
  WORD wArCount;               /* # of RRs in additional records section   */
} DNS_HEADER;

typedef struct {
  OCTET *szDomainName;         /* pointer to domain name                   */
  WORD  wQType;                /* query type - usually A                   */
  WORD  wQClass;               /* query class - usually IN                 */
} DNS_QUESTION;

/* Resource Record (RR) format used for
 * answer, authority, and additional sections
 */
typedef struct {
  OCTET *szDomainName;        /* domain name to which this RR pertains    */
  WORD  wType;                /* specifies meaning of data in RDATA field */
  WORD  wClass;               /* specifies class of data in RDATA field   */
  DWORD dwTtl;                /* seconds to cache RR (0 = don't cache)    */
  WORD  wRdLength;            /* length of RDATA field in octets          */
  WORD  wPad;                 /* for DWORD alignment                      */
  OCTET *poRdata;             /* format described by type and class...
                               *  for type = A and class = IN, rdata is
                               *  4 octet ARPA Internet address
                               */
} DNS_RR;

typedef struct {
  DNS_HEADER   xDnsHeader;
  DNS_QUESTION xDnsQuestion;
  DNS_RR       xRRAnswer;
} DNS_MSG;

typedef struct {
  char         *szHostname;
  DWORD        dwIpAddr;
} DNS_PARSE_REPLY;


typedef enum DNS_ERROR  {
  EDNSINVALIDREPLY = 1,
  EDNSNOSRVRESP,
  EDNSILLEGALNAME,
  EDNSHOSTNOTFOUND,
  EDNSPARSEFAILED,
  EDNSSERVERNOTSET
} DNS_ERROR;


/****************************************************************************
 *
 * State/Control info for DNS
 *
 ****************************************************************************/

#define DNSINITSTATE_NONE 0
#define DNSINITSTATE_OK   1
#define DNSINITSTATE_FAIL 0xFF

typedef struct StructDnsControl {
  char            szHost[256];
  struct in_addr  xIpAddr;
  DNS_SET         xDnsParms;                /* 1000ms interval,
                                               10 retries of 30ms */
  HOSTENT_LIST    *pxHostEntList;
  char            *szDomainName;
  DWORD           dwGotTruncated;
  DWORD           dwDomainNameServerIP;
#if defined(DNS_INDIRECT)
  DWORD           dwDnsRefServer;
#endif
  WORD            wDnsNextId;               /* Next ID to use */
  OCTET           oIfIdx;                   /* Network Interface this relates
                                               to */
  OCTET           oDnsRecurse;              /* Should we ask DNS server to
                                               recurse? */
#if defined(DNS_INDIRECT)
  OCTET           oDnsUseRefServer;         /* Use Referral Server */
#endif
} STRUCTDNSCONTROL;


typedef struct {
  OCTET           oInitState;         /* DNSINITSTATE_XXX */
  STRUCTDNSCONTROL  *pxDnsControl;
  OCTET               oDnsNum;
} DNSSTATE;


MOC_EXTERN DNSSTATE       xDNSState;
/****************************************************************************
 *
 * Some DNS prototypes used by functions not in dns.c for codesize reasons
 *
 ****************************************************************************/

/*
 * DnsWaitForInit
 *  Make thread sleep while DNS not initialized.
 *
 *  Args:
 *   None
 *
 *  Return:
 *   NETERR_UNKNOWN|NETERR_NOERR
 */
int
DnsWaitForInit(void);

/*
 * DnsFreeHostEntMembers
 *  Free all the members of a hostent structure if allocated
 *
 *  Args:
 *   pxHostEnt            Ptr to a hostent structure
 *
 *  Return:
 *   None
 */
void
DnsFreeHostEntMembers(struct hostent * pxHostEnt);


/*
 * DnsGetHostByEither
 *  Performs gethostbyeither on 1 interface
 *
 *  Args:
 *   pxDnsControlLocal      DNS core structure corresponding to the interface
 *   szName                 Domain name from gethostbyname() or gethostbyaddr()
 *   eQueryType             Type of DNS query to perform
 *
 *  Return:
 *   Ptr to struct hostent * to be returned to client
 */
struct hostent *
DnsGetHostByEither(STRUCTDNSCONTROL   *pxDnsControlLocal,
                   OCTET              *szName,
                   ENUM_DNS_LOOKUP    eQueryType);

/*
 * gethostbyeither
 *  Common code shared by gethostbyname & gethostbyaddr
 *
 *  Args:
 *   szName                 from gethostbyname() or gethostbyaddr()
 *   eQueryType             Type of query to perform
 *
 *  Return:
 *   Ptr to host entry pxHostEnt to be returned to client
 */
struct hostent *
gethostbyeither(OCTET           *szName,
                ENUM_DNS_LOOKUP eQueryType);


#endif /*EOF */



