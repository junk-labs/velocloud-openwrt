/*
 * socket_utils.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "sockdefs.h"


#ifndef NDEBUG
/* Retrieve being used for all packets, and in NDEBUG
   being reduced to a sole line, it's better as a macro then. */
/*
 * SocketRetrieve
 *  Retrieve the SOCKET * coresponding to a socket
 *  file descriptor
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   iSockFd            socket file descriptor
 *
 *  Return:
 *   SOCKET *           if found, NULL otherwise
 */

SOCKET* SocketRetrieve(int iSockfd)
{
  SOCKET *pxSocket;

  if( (iSockfd & DEVICE_NMBR_MASK) >= MAX_FD){
    return NULL;
  }

  pxSocket = xSocketRep.apxSockets[(iSockfd & 0xFFFFFF) & DEVICE_NMBR_MASK];

  DEBUG({
    if(pxSocket != NULL) {
      SOCKET_CHECK_STATE(pxSocket);
    }
  });

  return pxSocket;
}
#endif

/*
 * SocketRegister
 *  Register a SOCKET * with its socket file descriptor
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   iSockFd             socket file descriptor
 *   pxSocket            coresponding SOCKET *
 *
 *  Return:
 *   >=0 if success
 */
LONG SocketRegister(int iSockFd,SOCKET* pxSocket)
{
#ifndef NDEBUG
  if( ((iSockFd & DEVICE_NMBR_MASK) > MAX_FD) || (pxSocket == NULL) ){
    ASSERT(0);
    return NETERR_UNKNOWN;
  };
#endif

  pxSocket->dwSocketId = xSocketRep.dwSocketCounter++;
  xSocketRep.apxSockets[iSockFd & DEVICE_NMBR_MASK] = pxSocket;
  return 0;
}

/*
 * SocketUnregister
 *  Unregister a socket fd (=>makes it unused)
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   iSockFd             socket file descriptor
 *
 *  Return:
 *   >=0 if success
 */
LONG SocketUnregister(int iSockFd)
{
#ifndef NDEBUG
  if( (iSockFd & DEVICE_NMBR_MASK) > MAX_FD){
    ASSERT(0);
    return NETERR_UNKNOWN;
  }
#endif
  xSocketRep.apxSockets[iSockFd & DEVICE_NMBR_MASK] = 0;
  return 0;
}
