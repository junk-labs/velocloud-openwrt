/*
 * pppconf.c
 *
 * Gathers ppp configuration code
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "netmain_flavor.h"
#include "stdlib.h"
#include "string.h"
#include "pthread.h"
#include "sys/socket.h"
#include "netcommon.h"
#include "netconfig.h"
#include "linkconf.h"
#include "pppoecommon.h"
#include "pppoeclient.h"
#include "ppp.h"
#include "ipcp.h"
#include "cryptcommon.h"
#include "md5.h"
#include "chapclient.h"
#ifdef EAP_TLS
#include "eaptlsclient.h"
#endif
#include "papclient.h"
#include "netdefs.h"
#include "netif.h"
#include "ppplibs.h"
#include "netmain.h"
#include "ethernet.h"
#include "net/if_types.h"

/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/
/*
 * PppConfSetup
 *  Specific setup for straight PPPoE interfaces
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   NETLINKLEG
 */
LONG PppConfSetup(NETIFCONF *pxIfConf,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;
  H_NETINSTANCE hPpp,hIpcp,hChapClient,hPapClient;
#ifdef EAP_TLS
  H_NETINSTANCE hEapTlsClient;
#endif
  NETCONFINSTANCE *pxPppInst;
  CHAPCLIENTENCRYPTIONSTATE xEncryption;

  NETMAIN_DBGP(NORMAL,"PppConfSetup:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  pxNetConf = NETGETNETCONF_PPP(pxIfState);

  pxNetConf->eState = NETCONFSTATE_INIT;
  pxNetConf->ppxLibTemplate = (NETCONFLIBRARYTEMPLATE**)apxPppLibTemplate;
  pxNetConf->dwLibNum = PPPLIBIDX_MAX;

  /* Setup all instances */
  NetConfSetup(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_SETUP);

  LibConfSetOffsetAndTrailer(pxNetConf,NETRXOFFSET,NETRXTRAILER);

  pxPppInst = NETGETCONFINST_PPP(pxIfState);
  hPpp = NETGETINST_PPP(pxIfState);
  hIpcp = NETGETINST_IPCP(pxIfState);
  hPapClient = NETGETINST_PAP(pxIfState);
  hChapClient = NETGETINST_CHAP(pxIfState);
#ifdef EAP_TLS
  hEapTlsClient = NETGETINST_EAPTLS(pxIfState);
#endif

  pxIfState->hTopLinkInst        = hPpp;
  pxIfState->hTopLinkIf          = pxPppInst->phULIf[PPPULIFIDX_IP];
  pxIfState->pfnTopLinkWrite     = PppInstanceWrite;
  pxIfState->pfnTopLinkUlIfIoctl = PppInstanceULInterfaceIoctl;

  /* Ipcp Specific Settings */
  IpcpInstanceSet(hIpcp,NETOPTION_NETCBKHINST,
                  (H_NETDATA)oIfIdx);
  IpcpInstanceSet(hIpcp,IPCPOPTION_PRIMARYDNS,
                  (H_NETDATA)pxIfConf->pxIPAlias[0].dwDNSIPAddr);

  /* ChapClient specific settings */
  ChapClientInstanceSet(hChapClient,NETOPTION_NETCBKHINST,
                        (H_NETDATA)oIfIdx);

  xEncryption.oId = CHAPCLIENTOPTIONENCRYPTIONID_MD5;
  xEncryption.pfnCryptInit = MD5Init;
  xEncryption.pfnCryptUpdate =  MD5Update;
  xEncryption.pfnCryptFinish = MD5Final;

  ChapClientInstanceSet(hChapClient,CHAPCLIENTOPTION_ENCRYPTION,(H_NETDATA)&xEncryption);

  /* Pap specific settings */
  PapClientInstanceSet(hPapClient,NETOPTION_NETCBKHINST,(H_NETDATA)oIfIdx);
  PapClientInstanceSet(hPapClient,PAPCLIENTOPTION_IFIDX,(H_NETDATA)oIfIdx);
  PapClientInstanceSet(hPapClient,PAPCLIENTOPTION_VLAN,(H_NETDATA)(pxIfConf->wVlan));

#ifdef EAP_TLS
  /* EapTlsClient specific settings */
  EapTlsClientInstanceSet(hEapTlsClient,NETOPTION_NETCBKHINST,
                        (H_NETDATA)oIfIdx);
#endif
  /* Ppp Specific settings */
  PppInstanceSet(hPpp,NETOPTION_NETCBKHINST,(H_NETDATA)oIfIdx);
  PppInstanceSet(hPpp,PPPOPTION_REMOTEAP,(H_NETDATA)PPPID_CHAP);
  PppInstanceSet(hPpp,PPPOPTION_REMOTEAP,(H_NETDATA)PPPID_PAP);
#ifdef EAP_TLS
  PppInstanceSet(hPpp,PPPOPTION_REMOTEAP,(H_NETDATA)PPPID_EAPTLS);
#endif

  PppInstanceSet(hPpp,PPPOPTION_IFIDX,(H_NETDATA)oIfIdx);
  PppInstanceSet(hPpp,PPPOPTION_VLAN,(H_NETDATA)(pxIfConf->wVlan));
  PppInstanceSet(hPpp,PPPOPTION_LOCALMRU,(H_NETDATA)(pxIfConf->wMtu));
  PppInstanceSet(hPpp,PPPOPTION_REMOTEMRU,(H_NETDATA)(pxIfConf->wMtu));

  return NETERR_NOERR;
}


/*
 * PppConfOpen
 *  Specific openings for straight PPPoE interfaces
 *
 *  Args:
 *   pxIfConf           interface conf structure
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG PppConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;
  H_NETINSTANCE hPppInst;
  H_NETINSTANCE hChapClient,hPapClient,hIpcp;
#ifdef EAP_TLS
  H_NETINSTANCE hEapTlsClient;
#endif

  NETMAIN_DBGP(NORMAL,"PppConfOpen:pxIfConf=0x%p,oIfIdx=%d\n",
               pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_PPP(pxIfState);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_SETUP);

  hPapClient = NETGETINST_PAP(pxIfState);
  hChapClient = NETGETINST_CHAP(pxIfState);
  hIpcp = NETGETINST_IPCP(pxIfState);
#ifdef EAP_TLS
  hEapTlsClient = NETGETINST_EAPTLS(pxIfState);
#endif

  /* Username & password to be set here as they can change
   * dynamically from web pages etc.
   */
  if (pxIfConf->xPppConf.pcPppUsername != NULL) {
    /*TODO: PAPCLIENTCONF and CHAPCLIENTCONF must be the equal*/
    PAPCLIENTCONF xClientConf;
    xClientConf.poConf = pxIfConf->xPppConf.pcPppUsername;
    xClientConf.wConfLength = strlen(pxIfConf->xPppConf.pcPppUsername);

    PapClientInstanceSet(hPapClient,PAPCLIENTOPTION_ID,
                         (H_NETDATA)&xClientConf);
    ChapClientInstanceSet(hChapClient,CHAPCLIENTOPTION_NAME,
                          (H_NETDATA)&xClientConf);
#ifdef EAP_TLS
    EapTlsClientInstanceSet(hChapClient,EAPTLSCLIENTOPTION_NAME,
                          (H_NETDATA)&xClientConf);
#endif

  }
  if (pxIfConf->xPppConf.pcPppPassword != NULL) {
    PAPCLIENTCONF xClientConf;
    xClientConf.poConf = pxIfConf->xPppConf.pcPppPassword;
    xClientConf.wConfLength = strlen(pxIfConf->xPppConf.pcPppPassword);

    PapClientInstanceSet(hPapClient,PAPCLIENTOPTION_PASSWD,
                         (H_NETDATA)&xClientConf);
    ChapClientInstanceSet(hChapClient,CHAPCLIENTOPTION_SECRET,
                          (H_NETDATA)&xClientConf);
#ifdef EAP_TLS
    EapTlsClientInstanceSet(hChapClient,EAPTLSCLIENTOPTION_SECRET,
                          (H_NETDATA)&xClientConf);
#endif
  }

  hPppInst = NETGETINST_PPP(pxIfState);
  PppInstanceSet(hPppInst, PPPOPTION_IDLETO,
                 (H_NETDATA)(pxIfConf->xPppConf.dwPppIdleTO));

  PppInstanceSet(hPppInst, PPPOPTION_ECHOTO,
                 (H_NETDATA)(pxIfConf->xPppConf.dwPppEchoTO));

  PppInstanceSet(hPppInst, PPPOPTION_ECHOCOUNT,
                 (H_NETDATA)(pxIfConf->xPppConf.dwPppEchoCount));

  /* Update PPP VLAN settings */
  PppInstanceSet(hPppInst,PPPOPTION_VLAN,
                 (H_NETDATA)(pxIfConf->wVlan));
  PapClientInstanceSet(hPapClient,PAPCLIENTOPTION_VLAN,
                       (H_NETDATA)(pxIfConf->wVlan));

  /* Update Ipcp Specific Settings (reset IP and DNS) */
  IpcpInstanceSet(hIpcp,IPCPOPTION_LOCALIPADDR,(H_NETDATA)0);
  IpcpInstanceSet(hIpcp,IPCPOPTION_PRIMARYDNS,
                  (H_NETDATA)pxIfConf->pxIPAlias[0].dwDNSIPAddr);

  NetConfOpen(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_OPENED);

  if(pxIfConf->oType == IFT_PPP){
    PppInstanceMsg(hPppInst,NETMSG_LOWERLAYERUP,(H_NETDATA)0);
  }

  return NETERR_NOERR;
}

/*
 * PppConfProcess
 *  straight PPPoE link processing
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG PppConfProcess(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_PPP(pxIfState);
  NETMAIN_ASSERT(pxNetConf->eState != NETCONFSTATE_INIT);

  NetConfProcess(pxNetConf);

  return NETERR_NOERR;
}

/*
 * PppConfClose
 *  PPPoE specific if close
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return 0
 */
LONG PppConfClose(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;

  NETMAIN_DBGP(NORMAL,"PppConfClose:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_PPP(pxIfState);
  NETMAIN_ASSERT(pxNetConf != NULL);

  if(pxNetConf->eState != NETCONFSTATE_OPENED){
    return -1;
  }

  NetConfClose(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_CLOSED);

  return NETERR_NOERR;
}

/*
 * PppConfDestroy
 *  PPP specific if destroy
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG PppConfDestroy(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;

  NETMAIN_DBGP(NORMAL,"PppConfDestroy:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_PPP(pxIfState);
  NETMAIN_ASSERT((pxNetConf != NULL) && (pxNetConf->eState == NETCONFSTATE_CLOSED));

  /* Setup all instances */
  NetConfTearDown(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_INIT);

  return 0;
}

