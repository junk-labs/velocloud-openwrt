/*
 * eaptlsclient.c
 *
 * EAPTLS ( EAP Transport Layer Security) client
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "eaptls_defs.h"

/*****************************************************************************
 *
 * global
 *
 *****************************************************************************/

EAPTLS_DBG_VAR(DWORD g_dwEapTlsDebugLevel = 3);

#ifdef EAPTLSDBG_HI
char* acEapTlsTypeToString[] = {
             "EAPTLSPACKETTYPE_CHALLENGE",
             "EAPTLSPACKETTYPE_RESPONSE",
             "EAPTLSPACKETTYPE_SUCCESS",
             "EAPTLSPACKETTYPE_FAILURE"
};
#endif /*#ifdef EAPTLSDBG_HI*/

/*****************************************************************************
 *
 * Local Function
 *
 *****************************************************************************/

/*
 * EapTlsClientInstanceCreateRspMsg
 *   Create a EapTlsClient Rsp
 *
 *   Args:
 *   hEapTlsClient               instance handle
 *   pxPacket            packet
 *   pxAccess            access
 */
LONG EapTlsClientInstanceCreateRspMsg(H_NETINSTANCE hEapTlsClient,
                                    void * data, DWORD len)
{
  EAPTLSCLIENTSTATE *pxEapTlsClient = (EAPTLSCLIENTSTATE *)hEapTlsClient;
  WORD wSize;
  OCTET *poPayload,*poEapTlsClientPDU;
  NETPACKET xPacket;
  NETPACKETACCESS xAccess;
  NETPACKET *pxPacket = &xPacket;
  NETPACKETACCESS *pxAccess = &xAccess;

  ASSERT(pxEapTlsClient != NULL);
  ASSERT(pxPacket != NULL);
  ASSERT(pxAccess != NULL);

  pxAccess->wOffset = pxEapTlsClient->wOffset;
  /* Len = EAP Hdr + TLS Hdr + Data */
  pxAccess->wLength = EAPTLS_HLEN + 1 +len;

  wSize = pxAccess->wOffset + pxAccess->wLength + pxEapTlsClient->wTrailer;

  poPayload = (OCTET *)pxEapTlsClient->pfnNetMalloc(wSize*sizeof(OCTET));
  ASSERT(poPayload != NULL);

  poEapTlsClientPDU = poPayload + pxAccess->wOffset;

  /* Copy The Data, if any */
  if (len != 0) {
    ASSERT(data != NULL);
    memcpy(EAPTLSGET_DATAPOINTER(poEapTlsClientPDU) + 1  ,
           data,len);
    /* Should Free the data Here  JJ */
  }

  NETPAYLOAD_CREATE(&(pxPacket->pxPayload),
                    pxEapTlsClient->pfnNetFree,pxEapTlsClient->pxNetMutex,
                    poPayload,
                    wSize);

  pxPacket->hMarker = (H_NETDATA)NULL;

  pxEapTlsClient->pfnLlWrite(pxEapTlsClient->hLl,pxEapTlsClient->hLlIf,
                             &xPacket,&xAccess,
                             (H_NETDATA)&(pxEapTlsClient->xNetIfId));

      /* Start Up the Timer */
  pxEapTlsClient->dwTimer = NetGlobalTimerGet() + EAPTLSCLIENTDEFAULT_TIMER;

  return NETERR_NOERR;
}

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * EapTlsClientInitialize
 *  Initialize the EAPTLS library
 *
 *  Args:
 *
 *  Return:
 *    >=0
 */
LONG EapTlsClientInitialize(void)
{
  return NETERR_NOERR;
}

/*
 * EapTlsClientTerminate
 *  Terminate the EapTlsClient library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG EapTlsClientTerminate(void)
{
  return NETERR_NOERR;
}

/*
 * EapTlsClientInstanceCreate
 *  Create a EAPTLS instance
 *
 *  Args:
 *
 *  Return:
 *   instance handle
 */
H_NETINSTANCE EapTlsClientInstanceCreate(void)
{
  int iRv = 0;
  EAPTLSCLIENTSTATE *pxEapTlsClient;

  pxEapTlsClient = (EAPTLSCLIENTSTATE *)calloc(1,sizeof(EAPTLSCLIENTSTATE));
  ASSERT(pxEapTlsClient != NULL);
  EAPTLS_SET_COOKIE(pxEapTlsClient);
  iRv = EAPTLS_init(pxEapTlsClient);
  ASSERT (iRv == 0);
  iRv = EAPTLS_initSession(pxEapTlsClient);
  ASSERT (iRv == 0);

  return (H_NETINSTANCE)pxEapTlsClient;
}

/*
 * EapTlsClientInstanceDestroy
 *  Destroy a eaptls instance
 *
 *  Args:
 *   hEapTlsClient              EapTlsClient instance handle
 *
 *  Return:
 *   >=0
 */
LONG EapTlsClientInstanceDestroy(H_NETINSTANCE hEapTlsClient)
{
  EAPTLSCLIENTSTATE *pxEapTlsClient = (EAPTLSCLIENTSTATE *)hEapTlsClient;

  EAPTLS_CHECK_STATE(pxEapTlsClient);

  if (pxEapTlsClient->poSecret != NULL) {
    free(pxEapTlsClient->poSecret);
  }

  if (pxEapTlsClient->poName != NULL) {
    free(pxEapTlsClient->poName);
  }

  if (pxEapTlsClient->poCurrentChallenge != NULL) {
    free(pxEapTlsClient->poCurrentChallenge);
  }

  EAP_sessionDelete(pxEapTlsClient->eapSessionHdl,
                    pxEapTlsClient->instanceId);
  EAP_deleteInstance(pxEapTlsClient->instanceId);
  EAPTLS_UNSET_COOKIE(pxEapTlsClient);
  free(pxEapTlsClient);

  return NETERR_NOERR;
}

/*
 * EapTlsClientInstanceSet
 *   Set EAPTLS options
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceSet(H_NETINSTANCE hEapTlsClient,OCTET oOption,
                      H_NETDATA hData)
{
  EAPTLSCLIENTSTATE *pxEapTlsClient = (EAPTLSCLIENTSTATE *)hEapTlsClient;
  EAPTLS_CHECK_STATE(pxEapTlsClient);

  switch(oOption) {
  case NETOPTION_FREE:
    pxEapTlsClient->pfnNetFree = (PFN_NETFREE)hData;

  case NETOPTION_MALLOC:
    pxEapTlsClient->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    pxEapTlsClient->pxNetMutex = (pthread_mutex_t *)hData;
    break;

 case NETOPTION_NETCBK:
    pxEapTlsClient->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case NETOPTION_NETCBKHINST:
    pxEapTlsClient->hNetCbk = (H_NETINSTANCE)hData;
    break;

  case NETOPTION_OFFSET:
    pxEapTlsClient->wOffset = (WORD)( (DWORD)hData & 0xFFFF);
    break;

  case NETOPTION_TRAILER:
    pxEapTlsClient->wTrailer = (WORD)( (DWORD)hData & 0xFFFF);
    break;

  case EAPTLSCLIENTOPTION_ENCRYPTION:
    memcpy(&(pxEapTlsClient->xEncryption),(void *)hData,sizeof(EAPTLSCLIENTENCRYPTIONSTATE));
    break;

  case EAPTLSCLIENTOPTION_NAME:
    {
      EAPTLSCLIENTCONF *pxConf = (EAPTLSCLIENTCONF *)hData;

      if (pxEapTlsClient->poName != NULL) {
        free(pxEapTlsClient->poName);
      }
      pxEapTlsClient->poName = (OCTET *)malloc((pxConf->wConfLength + 1)*sizeof(OCTET));
      ASSERT(pxEapTlsClient->poName != NULL);
      memcpy(pxEapTlsClient->poName,pxConf->poConf,(pxConf->wConfLength + 1));
      pxEapTlsClient->oNameLength = (OCTET)(pxConf->wConfLength);
    }
  break;

  case EAPTLSCLIENTOPTION_SECRET:
    {
      EAPTLSCLIENTCONF *pxConf = (EAPTLSCLIENTCONF *)hData;
      if (pxEapTlsClient->poSecret != NULL) {
        free(pxEapTlsClient->poSecret);
      }
      pxEapTlsClient->poSecret = (OCTET *)malloc((pxConf->wConfLength + 1)*sizeof(OCTET));
      ASSERT(pxEapTlsClient->poSecret != NULL);
      memcpy(pxEapTlsClient->poSecret,pxConf->poConf,(pxConf->wConfLength + 1));
      pxEapTlsClient->dwSecretLength = pxConf->wConfLength;
    }
  break;

  }

  return NETERR_NOERR;
}

/*
 * EapTlsClientInstanceMsg
 *   EAPTLSCLIENT msg function
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceMsg(H_NETINSTANCE hEapTlsClient,OCTET oMsg,H_NETDATA hData)
{
  EAPTLSCLIENTSTATE *pxEapTlsClient = (EAPTLSCLIENTSTATE *)hEapTlsClient;
  LONG lReturn = NETERR_NOERR;
  EAPTLS_CHECK_STATE(pxEapTlsClient);

  switch(oMsg) {

  case NETMSG_CLOSE:

   EAP_sessionDisable(pxEapTlsClient->eapSessionHdl,
                    pxEapTlsClient->instanceId);
   pxEapTlsClient->eState = EAPTLSCLIENTSTATE_DOWN;
   break;

  case NETMSG_OPEN:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    /* Nothing to do here */
    break;

  case EAPTLSCLIENTMSG_CONFREQ:
    /* Encryption configuration */
    {
      EAPTLSCLIENTCONF *pxConf = (EAPTLSCLIENTCONF *)hData;
      ASSERT(pxConf->poConf != NULL);
      if (*(pxConf->poConf) != pxEapTlsClient->xEncryption.oId) {
        EAPTLS_DBGP(ERROR,"EapTlsClientInstanceMsg:configuration fails\n");
        *pxConf->poConf = pxEapTlsClient->xEncryption.oId;
        lReturn = NETERR_UNKNOWN;
      }
    }
    break;
  }

  return lReturn;
}

/*
 * EapTlsClientInstanceLLInterfaceCreate
 *   Create EAPTLS LL interface
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE EapTlsClientInstanceLLInterfaceCreate(H_NETINSTANCE hEapTlsClient)
{
  return (H_NETINTERFACE)1;
}

/*
 * EapTlsClientInstanceLLInterfaceDestroy
 *   Destroy EAPTLS LL interface
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceLLInterfaceDestroy(H_NETINSTANCE hEapTlsClient, H_NETINTERFACE hIf)
{
  ASSERT((H_NETINTERFACE)1 == hIf);

  return NETERR_NOERR;
}

/*
 * EapTlsClientInstanceLLInterfaceIoctl
 *   EAPTLS LL interface ioctl function
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceLLInterfaceIoctl(H_NETINSTANCE hEapTlsClient, H_NETINTERFACE hIf,
                                    OCTET oIoctl,H_NETDATA hData)
{
  EAPTLSCLIENTSTATE *pxEapTlsClient = (EAPTLSCLIENTSTATE *)hEapTlsClient;
  EAPTLS_CHECK_STATE(pxEapTlsClient);

  switch(oIoctl) {

  case NETINTERFACEIOCTL_SETHINST:
    pxEapTlsClient->hLl = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxEapTlsClient->pfnLlWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxEapTlsClient->hLlIf = (H_NETINTERFACE)hData;
    break;


  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    break;

  default:
    ASSERT(0);

  }

  return NETERR_NOERR;
}

/*
 * EapTlsClientInstanceRcv
 *   EAPTLS instance rcv
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            NETIFID *
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceRcv(H_NETINSTANCE hEapTlsClient, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  OCTET *poData;
  E_EAPTLSPACKETTYPE eType;
  EAPTLSCLIENTSTATE *pxEapTlsClient = (EAPTLSCLIENTSTATE *)hEapTlsClient;
  LONG lReturn = pxAccess->wLength;
  OCTET oId;
  WORD wLength;

  EAPTLS_CHECK_STATE(pxEapTlsClient);
  ASSERT(pxAccess != NULL);
  NETPACKET_CHECK(pxPacket);
  poData = pxPacket->pxPayload->poPayload + pxAccess->wOffset;
  wLength = EAPTLSGET_LENGTH(poData);
  memcpy(&(pxEapTlsClient->xNetIfId),(void *)hData,sizeof(NETIFID));

  EAPTLS_DBGP(REPETITIVE,"EapTlsClientInstanceRcv:hEapTlsClient=%d,%s\n",
                        (int)hEapTlsClient,acEapTlsTypeToString[eType - 1]);
    /* call llreceive fn */
  lReturn = EAP_llReceivePacket(pxEapTlsClient->eapSessionHdl, pxEapTlsClient->instanceId,
                        (OCTET *)(poData),
                        wLength, NULL);
  /* Free the data */
  NETPAYLOAD_DELUSER(pxPacket->pxPayload);


  return lReturn;
}

/*
 * EapTlsClientInstanceProcess
 *   EAPTLS processing function
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG EapTlsClientInstanceProcess(H_NETINSTANCE hEapTlsClient)
{
  EAPTLSCLIENTSTATE *pxEapTlsClient = (EAPTLSCLIENTSTATE *)hEapTlsClient;
  LONG lReturn = 0x7FFFFFFF;
  EAPTLS_CHECK_STATE(pxEapTlsClient);

  if (pxEapTlsClient->eState == EAPTLSCLIENTSTATE_DOWN) {
      DWORD dwTime;
      dwTime = NetGlobalTimerGet();
      if (dwTime > pxEapTlsClient->dwTimer) {
        /* Timer has expired, Call the EAP Check Timer Routine */
        EAP_checkTimers();
        /* Start Up the Timer */
        pxEapTlsClient->dwTimer = NetGlobalTimerGet() + EAPTLSCLIENTDEFAULT_TIMER;
        lReturn = EAPTLSCLIENTDEFAULT_TIMER;

    }
  }

  return lReturn;
}













