
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcfg.h"
#include "setupnet.h"
#include "configapi.h"
/*#include "flavor.h" */

/*
 * SetupNetCheckBridgeOnly
 *  Check if the device is acting as a bridge only
 *
 *  Args:
 *   pbBridge             BOOL to be filled in
 *                        (TRUE = Bridge only, FALSE = Router)
 *   iIfAvoidIdx          Interface number to avoid checking
 *                        Negative number to mean no avoidance.
 *
 *  Return:
 *   SetupNetReturn
 */
SetupNetReturn SetupNetCheckBridgeOnly(BOOL *pbBridge, int iIfAvoidIdx)
{
#ifdef ROUTER
  OCTET oIfNum, oEnabled = 0;
  int i;
  
  SetupNetGetIfNum(&oIfNum);
  
  for (i=1;i<oIfNum;i++) {
    CHAR acTmpString[30];
    CHAR chParamValue[20];
    
    sprintf(acTmpString, "IF%dENABLED", i);
    if ((iIfAvoidIdx != i) &&
        (ConfigGetParam(acTmpString, chParamValue, 
                        CONFIG_MAXPARAMLENGTH) == CONFIG_OK) && 
        (strcmp(chParamValue,"YES") == 0)) {
      LONG lReturn = 0;
      
      oEnabled++;
      
      sprintf(acTmpString, "IF%dNETCONF", i);
      lReturn = ConfigGetParam(acTmpString, chParamValue, 
                               CONFIG_MAXPARAMLENGTH);
      
      if (lReturn != CONFIG_OK || 
          (lReturn == CONFIG_OK && !strcmp(chParamValue,"ROUTED"))) {
        /* We have at least one active routed leg */
        *pbBridge = FALSE;
        return SETUPNET_OK;
      }
    }
  }
  
  if (oEnabled == 0) {
    *pbBridge = FALSE;
  } else {
    *pbBridge = TRUE;
  }
#endif  
  return SETUPNET_OK;  
}
