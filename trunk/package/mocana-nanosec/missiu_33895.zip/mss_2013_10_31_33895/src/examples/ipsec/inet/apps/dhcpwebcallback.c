/*
 * dhcpwebcallback.c
 *
 * Web post/substitution callback functions to handle DHCP server configuration variables
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include <NNstyle.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <strings.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/time.h>
#include <netdb.h>
#include <stdio.h>

#include "dhcpapi.h"
#include "dhcpserv.h"
#include "configapi.h"
#include "setupnet.h"

/**************************************************************************
 * DHCPServerWebSubstCallBack
 *   To substitute non-config file variables into html files
 **************************************************************************/
#if JJ
int DHCPServerWebSubstCallBack(SubstParam* sp)
{
  static DWORD  dwIP = 0;
  static char*  pcName = NULL;
  static OCTET* poCID = NULL;
  static OCTET  oCIDLen = 0;
  static BOOL   bDHCPTableDone = 0;
  LONG   lReturn = 0;
  int    i;

  if (!strcmp(sp->pchParamName,"STARTDHCPTABLE")) {
    /* Initialize the table (lock the server) */
    DHCPServerInitBindingTableQuery();
    bDHCPTableDone = 0;
  }
  else if (!strcmp(sp->pchParamName,"ENDDHCPTABLE")) {
    /* Unlock the server */
    DHCPServerEndBindingTableQuery();
    bDHCPTableDone = 1;
  }
  else if (!strcmp(sp->pchParamName,"LOADCLIENT")) {
    lReturn = DHCPServerGetNextBinding(&dwIP, &pcName,
                                       &poCID, &oCIDLen);
    if (lReturn == -1) bDHCPTableDone = 1;
  }
  else if (!strcmp(sp->pchParamName,"DHCPCLIENTNAME")) {
    if (!bDHCPTableDone && pcName != NULL) {
      strcpy(sp->chParamValue,pcName);
    }
  }
  else if (!strcmp(sp->pchParamName,"DHCPCLIENTIP")) {
    if (!bDHCPTableDone) {
      sprintf(sp->chParamValue,"%ld.%ld.%ld.%ld",
              (dwIP>>24)&0xff,(dwIP>>16)&0xff,(dwIP>>8)&0xff,(dwIP)&0xff);
    }
  }
  else if (!strcmp(sp->pchParamName,"DHCPCLIENTCID")) {
    if (!bDHCPTableDone && poCID!=NULL && oCIDLen>0) {
      for (i=0;i<oCIDLen;i++) {
        sprintf((sp->chParamValue + (2*i)),"%02X",poCID[i]);
      }
    }
  }
  else if (!strcmp(sp->pchParamName,"BRIDGEONLY")) {
    BOOL bBridgeOnly = FALSE;
    SetupNetCheckBridgeOnly(&bBridgeOnly,-1);
    if (bBridgeOnly) {
      strcpy(sp->chParamValue,"Y");
    }
  }

  return 1;
}

#endif /*JJ */
/**************************************************************************
 * DHCPServerWebPostCallBack
 *   To intercept and act on certain DHCP web config settings
 **************************************************************************/
#if JJ
int DHCPServerWebPostCallBack(PostParam* pp)
{
  int i;
  BOOL bBridgeOnly = FALSE;

  for (i=0;i<pp->iNumParams;i++) {

    /* Check if it's a request to clear the DHCP Server binding table */
    if (strcmp(pp->stParams[i].pchParamName,"CLEARDHCPTABLE")==0) {
      printf("Request to clear DHCPServer binding table\n");
      DHCPServerClearBindingTable();
      return 1;
    }

    /* Check if DHCP server needs to be enabled/disabled */
    else if (strcmp(pp->stParams[i].pchParamName,"DHCPSERV")==0) {
      /* We know it's the DHCP server web page */
      DHCPServerStop();

      /* Restart (reconfigure) if enabled */
      SetupNetCheckBridgeOnly(&bBridgeOnly,-1);
      if (!bBridgeOnly &&
          strcmp(pp->stParams[i].pchParamValue,"ENABLED") == 0) {
        DHCPServerStart();
      }

      /*
       * This assumes all other DHCP config parameters appear on
       * the same web page!
       */
      return 1;
    }

    /* Check if static assignment table has been updated */
    else if (strncmp(pp->stParams[i].pchParamName,"DHCPSTATIC",10)==0) {
      DHCPServerUpdateStaticAssignments();
    }
  }

  /* In case someone changes interfaces to bridged only */
  SetupNetCheckBridgeOnly(&bBridgeOnly,-1);
  if (bBridgeOnly) {
    DHCPServerStop();     /* OK to call if already stopped */
  } else {
    DHCPServerStart();    /* OK to call if already started */
  }

  return 1;
}

#endif

/**************************************************************************/
/*********************** END OF FILE **************************************/
/**************************************************************************/
