#ifndef __NET_SEGMENT_H_
#define __NET_SEGMENT_H_

/* FOR NOW --- possibly belongs in TCP/IP stack */

/* In Bytes */
typedef enum {
    INET_TXBUFFER_POOL_50=0,
    INET_TXBUFFER_POOL_250,
    INET_TXBUFFER_POOL_600,
    INET_TXBUFFER_POOL_1100,
    INET_TXBUFFER_POOL_1600,
    INET_TXMAX_BUFFER_POOL /* Has to match whats defined in netmain.h*/
} E_INET_TXBUFFER_POOLS;

typedef struct segmentStructure
{
    ubyte*                      pSegment;
    ubyte4                      lengthOfSegment;
    ubyte*                      pFreeArg;
    struct segmentStructure*    pNextSegment;

} segmentStructure;

typedef void (*mn_sock_release_segment_cb_t)(void *buff,void *pcbArg);

typedef struct txSegmentStructure
{
    ubyte*                      pSegment;
    ubyte4                      lengthOfSegment; /* Current Payload Length */
    ubyte4                      maxLengthOfSegment;/* Max Length */
    ubyte4                      offset;/* Used by IP Stack to free this */
    E_INET_TXBUFFER_POOLS       poolType;/* Size of Pool */
    mn_sock_release_segment_cb_t pfCb; /* Callback to the app */
    void                        *pvCbArg;/* Callback to the app */
    struct txSegmentStructure*  pNextSegment;

} txSegmentStructure;

MSTATUS MN_sock_get_sendSegment(E_INET_TXBUFFER_POOLS poolType,
                        ubyte4 numSegments ,
                        ubyte **ppSegment,/* Pointer to tcSegmentStructure*/
	                mn_sock_release_segment_cb_t pfCb, void *pvCbArg) ;
MSTATUS MN_sock_put_sendSegment(ubyte *ppSegment);
#endif /*__NET_SEGMENT_H_*/
