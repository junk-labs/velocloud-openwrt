/*
 * netdb.h
 *
 * Definitions for the network database API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef netdb_h
#define netdb_h

/***************************************************************************/
/*                             D E F I N E S                               */
/***************************************************************************/
#define HOST_NOT_FOUND  1 /* Authoritative answer, host not found */
#define TRY_AGAIN       2 /* Non-Authoritive host not found, or SERVERFAIL */
#define NO_RECOVERY     3 /* Non recoverable errors, FORMERR, REFUSED, NOTIMP */
#define NO_DATA         4 /* Valid name, no data record of requested type */
#define NO_ADDRESS      NO_DATA        /* no address, look for MX record */

#define DNSSRV              1
#define DNSTXT              2

/***************************************************************************/
/*                  D A T A    S T R U C T U R E S                         */
/***************************************************************************/
/* Description of database entry for a single host  */
struct hostent {
  char *h_name;                 /* Official name of host                 */
  char **h_aliases;             /* Alias list                            */
  int h_addrtype;               /* Host address type                     */
  int h_length;                 /* Length of address                     */
  char **h_addr_list;           /* List of addresses from name server    */
#define    h_addr    h_addr_list[0]  /* Address, for backward compatibility   */
};

typedef struct DnsSrvRecord {    /* Result of Service Lookup              */
  WORD wType;            /* e.g. DNSTXT or DNSSRV                 */
  WORD wPriority;        /* Priority                              */
  WORD wWeight;            /* Weight, not filled if TXT lookup      */
  INT  nPort;            /* Port Number, unused for TXT lookup    */
  OCTET szServStringID[248];    /* Format is different for TXT and SRV
                                   for TXT::<SerID>@<callagent.domain.com>:<Portnum>
                                   for SRV:: <callagent.domain.com> */
} DNS_SRV_RECORD;

/***************************************************************************/
/*                       M A C R O S                                       */
/***************************************************************************/

/***************************************************************************/
/*           F U N C T I O N    P R O T O T Y P E S                        */
/***************************************************************************/

/*
 * gethostname
 *  Get the name of the current host which MUST have
 *  been previously set in NetConf with NetSetParms().
 *
 *  Args:
 *   name                      pointer,where to copy result
 *   namelen                   max size of hostname to be copied
 *
 *  Return:
 *   0 if OK
 *   -1 on error
 */
int gethostname(char *name, ubyte4 namelen);

/*
 * gethostbyname
 *  standard API DNS resolver function - see man
 *  page for complete description
 *
 *  Args:
 *   name                      pointer to name to resolve
 *
 *  Return:
 *   struct hostent * (see netdb.h or man page)
 */
struct hostent * gethostbyname(char *name);

/*
 * gethostbyaddr
 *  Standard API DNS resolver function - see man
 *  page for complete description
 *
 * Args:
 *  addr                       ptr to address to resolve (DWORD cast to char *)
 *  len                        length of addr.  MUST be 4.
 *  type                        must be AF_INET
 *
 * Return:
 *  struct hostent * (see netdb.h or man page)
 */
struct hostent * gethostbyaddr(char *addr, int len, int type);

/*
 * DnsOpenQuery
 *  Open a DNS query
 *
 *  Args:
 *   service_name               pointer to name to resolve
 *   wType                      query type (SRV,TXT)
 *   pwCount                    Number of valid returned record
 *
 * Return value:
 *   OCTET *                    Query Handle
 */
OCTET *DnsOpenQuery(const OCTET* service_name, WORD wType, WORD *pwCount);

/*
 * DnsReadQuery
 *  Read up a DNS query (must be opened)
 *
 *  Args:
 *   hporesult                  Query handle
 *   strDnsRec                  Records to be filled up
 *   wCount                     Number of records to read
 *
 * Return value:
 */
void DnsReadQuery(OCTET* hporesult, DNS_SRV_RECORD *strDnsRec , WORD wCount);


/*
 * DnsCloseQuery
 *  Close a DNS query
 *
 *  Args:
 *   hporesult                  Query handle
 *
 *  Return:
 */
void DnsCloseQuery(OCTET* hporesult);

#endif












