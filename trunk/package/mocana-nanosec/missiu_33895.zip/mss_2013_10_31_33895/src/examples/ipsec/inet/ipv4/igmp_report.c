/*
 * igmp_report.c
 *
 * IGMP module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "igmp_defs.h"

/*********************************************************************
 * IgmpReport
 *
 *********************************************************************/
void IgmpSendReport(IGMPSTATE *pxIgmp,
                    IPMCASTREQ *pxIpMreq,
                    OCTET oType)
{
  DWORD dwDstAddr = 0;
  /* Note option array must be a multiple of 4 bytes long to maintain IP
   * alignment */
  OCTET aoIpOption[4]={0x94,0x4,0,0}; /* Router Alert option */

  /*Do not send report for the all host group (224.0.0.1)*/
  if(pxIpMreq->dwMulticastAddr == (DWORD)inet_addr(MULTICAST_ALLHOSTS_GROUP)){
    return;
  }

  if (oType == IGMP_V2_MEMBERSHIP_REPORT) {
    dwDstAddr = pxIpMreq->dwMulticastAddr;
  } else if (oType == IGMP_LEAVE_MEMBERSHIP) {
    dwDstAddr = (DWORD)inet_addr(MULTICAST_ALLROUTER_GROUP);
  } else {
    ASSERT(0);
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_DETAIL))
  {
    /*IGMP_DBGP(XREPETITIVE,"IgmpReport:oType:%s,dwGroupAddr:%ld.%ld.%ld.%ld,\n",
            IgmpTypeToString(oType),
            IPADDRDISPLAY(pxIpMreq->dwMulticastAddr));*/
    DEBUG_PRINT2(DEBUG_MOC_IPV4, "IgmpReport:oType :", IgmpTypeToString(oType));
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", dwGroupAddr : ", pxIpMreq->dwMulticastAddr);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  (LONG)IgmpSendPacket(pxIgmp,
                       pxIpMreq,
                       dwDstAddr,
                       oType,
                       0,/*oMaxRespTime*/
                       1,/*oTtl*/
                       aoIpOption,
                       (OCTET)sizeof(aoIpOption));
}
