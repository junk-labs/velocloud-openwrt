/*
 * ip2eth.c
 *
 * IP to Ethernet module (using ARP)
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "ip2eth_defs.h"

/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/

IP2ETH_DBG_VAR(DWORD g_dwIp2EthDebugLevel = REPETITIVE);

#ifndef NDEBUG
  DWORD dbg_dwIp2EthArpResolved = 0;
  DWORD dbg_dwIp2EthArpFailure = 0;
#endif /*#ifndef NDEBUG*/


/*****************************************************************************
 *
 * Local function
 *
 *****************************************************************************/

/*
 * Ip2EthFreePendingPacket
 *  Frees up an ARPPENDING *, including the payload
 *
 *  Args:
 *   px             pointer to the ARPPENDING *
 *
 *  Return:
 */
void Ip2EthFreePendingPacket(void *px)
{
  ARPPENDING *pxPending = (ARPPENDING *)px;

  IP2ETH_ASSERT(pxPending != NULL);

  NETPAYLOAD_DELUSER(pxPending->xNetPacket.pxPayload);

  FREE(pxPending);
}

/*****************************************************************************
 *
 * API  functions
 *
 *****************************************************************************/

/*
 * Ip2EthInitialize
 *  Initialize the Ip2Eth Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG Ip2EthInitialize(void)
{
  /* Initialise the debug to Error */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_IP2ETH, INET_DBG_LEVEL_ERROR);
  return (LONG)NETERR_NOERR;
}

/*
 * Ip2EthTerminate
 *  Terminate the Ip2Eth Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG Ip2EthTerminate(void)
{
  return (LONG)NETERR_NOERR;
}

/*
 * Ip2EthInstanceCreate
 *  Creates a Ip2Eth Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETWORKINSTANCE          Handle to the instance
 */

H_NETINSTANCE Ip2EthInstanceCreate(void)
{
  IP2ETHSTATE *pxIp2Eth;

  /*Allocate memory for the instance*/
  pxIp2Eth = (IP2ETHSTATE *)MALLOC(sizeof(IP2ETHSTATE));
  ASSERT(pxIp2Eth != NULL);
  MOC_MEMSET((ubyte *)pxIp2Eth, 0, sizeof(IP2ETHSTATE));

  /*Initialize the pending packet dll*/
  init_DLLIST(&pxIp2Eth->dllPendingArp);

  /*Set the magic cookie*/
  IP2ETH_SET_COOKIE(pxIp2Eth);

  return (H_NETINSTANCE)pxIp2Eth;
}

/*
 * Ip2EthInstanceDestroy
 *  Destroy a Ip2Eth Instance
 *
 *  Args:
 *   hIp2Eth                       Ip2Eth instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip2EthInstanceDestroy(H_NETINSTANCE hIp2Eth)
{
  LONG lRv = NETERR_NOERR;
  IP2ETHSTATE *pxIp2Eth;

  pxIp2Eth = (IP2ETHSTATE *)hIp2Eth;
  IP2ETH_CHECK_STATE(pxIp2Eth);

  /*Clear the pending packet dll*/
  clear_DLLIST(&pxIp2Eth->dllPendingArp,Ip2EthFreePendingPacket);

  /*Unset the magic cookie*/
  IP2ETH_UNSET_COOKIE(pxIp2Eth);

  FREE(pxIp2Eth);

  return lRv;
}

/*
 * Ip2EthInstanceSet
 *  Set a Ip2Eth Instance Option
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip2EthInstanceSet(H_NETINSTANCE hIp2Eth,OCTET oOption,
                       H_NETDATA hData)
{
  IP2ETHSTATE *pxIp2Eth;
  LONG lRv = NETERR_NOERR;

  pxIp2Eth = (IP2ETHSTATE *)hIp2Eth;
  IP2ETH_CHECK_STATE(pxIp2Eth);

  switch(oOption){

  case NETOPTION_FREE:
    pxIp2Eth->pfnNetFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_MALLOC:
    pxIp2Eth->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    pxIp2Eth->pxMutex = (RTOS_MUTEX)hData;
    break;

  case IP2ETHOPTION_SETARPINSTANCE:
    /*Set the arp instance*/
    pxIp2Eth->hArp = (H_NETINSTANCE)hData;
    break;

#ifndef NDEBUG
  case NETOPTION_NETCBK:
  case NETOPTION_NETCBKHINST:
  case NETOPTION_OFFSET:
  case NETOPTION_TRAILER:
    break;
  default:
    IP2ETH_ASSERT(0);
     return (LONG)NETERR_UNKNOWN;
#endif
  }

  return lRv;
}

/*
 * Ip2EthInstanceMsg
 *  Send a msg to a Ip2Eth instance
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *   oMsg                       Msg. See netcommon.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip2EthInstanceMsg(H_NETINSTANCE hIp2Eth,
                       OCTET oMsg,
                       H_NETDATA hData)
{
  IP2ETHSTATE *pxIp2Eth = (IP2ETHSTATE *)hIp2Eth;

  IP2ETH_CHECK_STATE(pxIp2Eth);
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP2ETH, INET_DBG_LEVEL_NORMAL))
  {
    /*IP2ETH_DBGP(NORMAL, "Ip2EthInstanceMsg: oMsg: %x\n", oMsg);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "Ip2EthInstanceMsg: oMsg: ", oMsg);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oMsg) {
    case IP2ETHMSG_ARPRESOLVED:
    {
      ARPPENDING *pxPendingArp;
      ARPREQUEST *pxArpRequest;

      pxArpRequest = (ARPREQUEST*)hData;
      ASSERT(pxArpRequest != NULL);

      DLLIST_head(&pxIp2Eth->dllPendingArp);

      while( (pxPendingArp =
              (ARPPENDING*)DLLIST_read(&pxIp2Eth->dllPendingArp)) != NULL){
        if(pxPendingArp->dwDstIpAddr == pxArpRequest->xEntry.dwIpAddr){
          ETHID xEthId;

          DEBUG(dbg_dwIp2EthArpResolved++);

          xEthId.oIfIdx   = pxPendingArp->xNetIfId.oIfIdx;
          xEthId.wVlan = pxPendingArp->xNetIfId.wVlan;

          (void*)MOC_MEMCPY((ubyte *)xEthId.aoAddr,
                        (ubyte *)pxArpRequest->xEntry.aoEthAddr,
                        ETHADDRESS_LEN);

          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP2ETH, INET_DBG_LEVEL_NORMAL))
          {
            /*IP2ETH_DBGP(NORMAL,
                      "Ip2EthMsg: IP2ETHMSG_ARPRESOLVED %ld.%ld.%ld.%ld has %02x:%02x:%02x:%02x:%02x:%02x\n",
                      IPADDRDISPLAY(pxArpRequest->xEntry.dwIpAddr),
                      HWADDRDISPLAY(pxArpRequest->xEntry.aoEthAddr));*/
            DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "Ip2EthMsg: IP2ETHMSG_ARPRESOLVED", pxArpRequest->xEntry.dwIpAddr);
            DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, " has ", pxArpRequest->xEntry.aoEthAddr[0],
                                   ":", pxArpRequest->xEntry.aoEthAddr[1]);
            DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", pxArpRequest->xEntry.aoEthAddr[2],
                                   ":", pxArpRequest->xEntry.aoEthAddr[3]);
            DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", pxArpRequest->xEntry.aoEthAddr[4],
                                   ":", pxArpRequest->xEntry.aoEthAddr[5]);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);

          }

          /*write to the LL If*/

          pxPendingArp = (ARPPENDING*)DLLIST_remove(&pxIp2Eth->dllPendingArp);

          pxIp2Eth->pfnLLWrite(pxIp2Eth->hEthInst,
                               pxIp2Eth->hEthIf,
                               &pxPendingArp->xNetPacket,
                               &pxPendingArp->xNetPacketAccess,
                               (H_NETDATA)&xEthId);
          FREE(pxPendingArp);

        }
        else {/*if(pxPendingArp->dwDstIpAddr == pxArpRequest->dwIpAddr)*/
          DLLIST_next(&pxIp2Eth->dllPendingArp);
        }
      }
    }
    break;

    case IP2ETHMSG_ARPFAILED:
    {
      ARPPENDING *pxPendingArp;
      ARPREQUEST *pxArpRequest;

      IP2ETH_ASSERT(hData != 0);
      pxArpRequest = (ARPREQUEST*)hData;

      DLLIST_head(&pxIp2Eth->dllPendingArp);

      while( (pxPendingArp = (ARPPENDING*)DLLIST_read(&pxIp2Eth->dllPendingArp)) != NULL){
        if(pxPendingArp->dwDstIpAddr == pxArpRequest->xEntry.dwIpAddr){

          DEBUG(dbg_dwIp2EthArpFailure++);
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP2ETH, INET_DBG_LEVEL_ERROR))
          {
            /*IP2ETH_DBGP(ERROR,
                      "Ip2EthMsg: IP2ETHMSG_ARPFAILED Unable to get the HW addr of %ld.%ld.%ld.%ld\n",
                      IPADDRDISPLAY(pxArpRequest->xEntry.dwIpAddr));*/
            DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "Ip2EthMsg: IP2ETHMSG_ARPFAILED Unable to get the HW addr of ",
                                      pxArpRequest->xEntry.dwIpAddr);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
          }
          pxPendingArp = (ARPPENDING*)DLLIST_remove(&pxIp2Eth->dllPendingArp);
          Ip2EthFreePendingPacket((void*)pxPendingArp);
        }
        else {/*if(pxPendingArp->dwDstIpAddr == pxArpRequest->dwIpAddr)*/
          DLLIST_next(&pxIp2Eth->dllPendingArp);
        }
      }

    }
    break;

#ifndef NDEBUG
  case NETMSG_OPEN :
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    break;

  default:
    IP2ETH_ASSERT(0);
#endif
  }

  return NETERR_NOERR;
}


/*
 * Ip2EthInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer : IP.
 *  Only 1 interface can be created
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *
 *  Return:
 *   H_NETWORKINTERFACE         Interface handle
 */
H_NETINTERFACE Ip2EthInstanceULInterfaceCreate(H_NETINSTANCE hIp2Eth)
{
  /* There is only one onterface */
  IP2ETH_CHECK_STATE((IP2ETHSTATE*) hIp2Eth);

  return (H_NETINTERFACE)1;
}

/*
 * Ip2EthInstanceULInterfaceDestroy
 *  Destroy a ETH UL interface
 *
 *  Args:
 *   hIp2Eth                    ETH instance
 *   hULIf                Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG Ip2EthInstanceULInterfaceDestroy(H_NETINSTANCE hIp2Eth,
                                      H_NETINTERFACE hULIf)
{
  IP2ETH_ASSERT(hULIf == 1);
  return (LONG)NETERR_NOERR;
}

/*
 * Ip2EthInstanceULInterfaceIoctl
 *  Ip2Eth UL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h
 *
 *  Args:
 *   hIp2Eth                      Ip2Eth instance handle
 *   hULIf                Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG Ip2EthInstanceULInterfaceIoctl(H_NETINSTANCE hIp2Eth,
                                    H_NETINTERFACE hULIf,
                                    OCTET oIoctl,
                                    H_NETDATA hData)
{
  IP2ETHSTATE *pxIp2Eth;
  LONG lRv = NETERR_NOERR;

  pxIp2Eth = (IP2ETHSTATE *)hIp2Eth;
  IP2ETH_CHECK_STATE(pxIp2Eth);

  IP2ETH_ASSERT(hULIf == (H_NETINTERFACE)1);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_SETHINST:
    pxIp2Eth->hIpInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIp2Eth->hIpIf = (H_NETINTERFACE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIp2Eth->pfnRxCbk = (PFN_NETRXCBK)hData;
    break;

#ifndef NDEBUG
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    break;
  default:
    lRv = NETERR_UNKNOWN;
    IP2ETH_ASSERT(0);
#endif

  }
  return lRv;
}



/*
 * Ip2EthInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer (ethernet) Only one
 *  interface is supported
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE Ip2EthInstanceLLInterfaceCreate(H_NETINSTANCE hIp2Eth)
{
  IP2ETH_CHECK_STATE((IP2ETHSTATE*) hIp2Eth);

  return (H_NETINTERFACE)1;
}

/*
 * Ip2EthInstanceLLInterfaceDestroy
 *  Destroy a Ip2Eth LL interface
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *   hLLIf                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG Ip2EthInstanceLLInterfaceDestroy(H_NETINSTANCE hIp2Eth,
                                      H_NETINTERFACE hLLIf)
{
  IP2ETH_ASSERT(hLLIf == 1);
  return NETERR_NOERR;
}


/*
 * Ip2EthInstanceLLInterfaceIoctl
 *  Ip2Eth LL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h
 *
 *  Args:
 *   hIp2Eth                      Ip2Eth instance handle
 *   hULIf                        Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   NETERR_NOERR if successfull
 */
LONG Ip2EthInstanceLLInterfaceIoctl(H_NETINSTANCE hIp2Eth,
                                    H_NETINTERFACE hLLIf,
                                    OCTET oIoctl,
                                    H_NETDATA hData)
{
  LONG lRv = NETERR_NOERR;
  IP2ETHSTATE *pxIp2Eth = (IP2ETHSTATE*)hIp2Eth;

  IP2ETH_CHECK_STATE(pxIp2Eth);

  switch(oIoctl) {

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIp2Eth->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxIp2Eth->hEthInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIp2Eth->hEthIf = (H_NETINTERFACE)hData;
    break;

#ifndef NDEBUG
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    break;
  default:
    lRv = NETERR_UNKNOWN;
    IP2ETH_ASSERT(0);
#endif
  }

  return lRv;
}




