typedef enum libsockcmd 
{
    MN_SOCKET = 0,
    MN_BIND ,
    MN_LISTEN ,
    MN_CLOSE ,
    MN_IOCTL ,
    MN_SEND ,
    MN_SENDTO ,
    MN_READ ,
    MN_RECV ,
    MN_RECVFROM ,
    MN_ACCEPT ,
    MN_SELECT ,
    MN_CONNECT ,
    MN_GETHOSTBYNAME ,
    MN_GETPEERBYNAME ,
    MN_GETSOCKNAME ,

} libSockCmd;

typedef struct socketcmd
{
    ubyte4 family;
    ubyte4 type;
    ubyte4 protocol;
} socketCmd;

typedef struct socketcmdreply
{
    sbyte4 sockfd;
} socketCmdReply;

typedef struct listencmd
{
    ubyte4 sockfd;
    ubyte4 backlog;
} listenCmd;

typedef struct bindcmd
{
    ubyte4 sockfd;
    struct sockaddr_in  sockAddr;
    ubyte4 szSockAddr;
} bindCmd;

/* Message Sent between Lib sock Client and Server */

typedef struct sockmsg
{
    libSockCmd libsockcmd;
    MSTATUS    errno;
    union
    {
        socketCmd socketcmd;
        socketCmdReply socketcmdreply;
        listenCmd listencmd;
        bindCmd   bindcmd;
    } msg;

} sockMsg;


/*---------------------------------------------------------------------------*/

extern sbyte4 
socket(ubyte4 family, ubyte4 type, ubyte4 protocol)
{


    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    socketCmd  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    ipc_req = _ipc_alloc(sizeof(sockMsg));

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_SOCKET;
    sockMsg->msg.socketcmd.family = family;
    sockMsg->msg.socketcmd.type = type;
    sockMsg->msg.socketcmd.protocol = protocol;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        goto exit;
    }
    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    /* Verify that the sockMsg packet is socket Reply */;
    if (MN_SOCKET_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    fd = sockMsg->msg.socketcmdreply.sockfd; 

exit:
     
    if (ipc_req)
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    if (OK > status)
        return status; 
    else
        return fd; 
}

/*---------------------------------------------------------------------------*/

extern sbyte4 
bind(sbyte4 sockfd, struct sockaddr *sockAddr,ubyte4 sockAddrLen)
{
    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    socketCmd  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!sockAddr) || (!sockAddrLen))
    {
        ipc_status = status =  ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    ipc_req = _ipc_alloc(sizeof(sockMsg));

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_BIND;
    sockMsg->msg.bindcmd.sockfd = sockfd;
    MOC_MEMCPY((ubyte*)&sockMsg->msg.bindcmd.sockAddr,(ubyte*)sockAddr,sockAddrLen);
    sockMsg->msg.bindcmd.szSockAddr = sockAddrLen;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        goto exit;
    }
    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    /* Verify that the sockMsg packet is socket Reply */;
    if (MN_BIND_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 
}

/*---------------------------------------------------------------------------*/
extern sbyte4 
listen(sbyte4 sockfd, ubyte4 backlog)
{
    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    socketCmd  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!backlog))
    {
        status = ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    ipc_req = _ipc_alloc(sizeof(sockMsg));

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_LISTEN;
    sockMsg->msg.listencmd.sockfd = sockfd;
    sockMsg->msg.listencmd.backlog = backlog;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        goto exit;
    }
    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    /* Verify that the sockMsg packet is socket Reply */;
    if (MN_LISTEN_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;

exit:
     
    if (ipc_req)
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 
}

/*---------------------------------------------------------------------------*/

void
SOCKSERVER_receiveMsg(_ipc_msg_t *ipc_req)
{
    MSTATUS status = OK;
    socketCmd  *sockMsg = NULL;

    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_req); 

    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        IPC_free(ipc_req);  
        goto exit;
    }

    if(IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(sockMsg))
    {
        IPC_free(ipc_req);  
        goto exit;
    }

    switch( sockMsg->libsockcmd )
    {
        case MN_SOCKET:
        {
            status = SOCKSERVER_socketMsg(ipc_req, sockmsg);
            break;
        }
        case MN_BIND:
        {
            status = SOCKSERVER_bindMsg(ipc_req, sockmsg);
            break;
        }
        case MN_LISTEN:
        {
            status = SOCKSERVER_listenMsg(ipc_req, sockmsg);
            break;
        }
    }


exit:
    return;
}

/*---------------------------------------------------------------------------*/
extern sbyte4 
SOCKSERVER_socketMsg(_ipc_msg_t *ipc_req, sockMsg *sockmsg)
{

    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    MSTATUS     status = OK;

    ipc_reply = _ipc_alloc(sizeof(sockMsg));

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    fd = mn_socket(sockMsg->msg.socketcmd.family, 
                   sockMsg->msg.socketcmd.type ,
                   sockMsg->msg.socketcmd.protocol );

    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_SOCKET_REPLY;
    sockMsg->errno      = OK;
    sockMsg->msg.socketcmdreply.sockfd = fd; 

    status = IPC_reply(ipc_req,ipc_reply);

exit:
    return status; 
}

/*---------------------------------------------------------------------------*/
extern sbyte4 
SOCKSERVER_bindMsg(_ipc_msg_t *ipc_req, sockMsg *sockmsg)
{

    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    MSTATUS     status = OK;

    ipc_reply = _ipc_alloc(sizeof(sockMsg));

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = mn_bind(sockMsg->msg.bindcmd.sockfd, 
                 &sockMsg->msg.bindcmd.sockAddr ,
                  sockMsg->msg.bindcmd.szSockAddr );

    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_LISTEN_REPLY;
    sockMsg->errno      = status;

    status = IPC_reply(ipc_req,ipc_reply);

exit:
    return status; 
}

/*---------------------------------------------------------------------------*/
extern sbyte4 
SOCKSERVER_listenMsg(_ipc_msg_t *ipc_req, sockMsg *sockmsg)
{

    _ipc_msg_t* ipc_reply = NULL;
    sbyte4      fd = -1;
    MSTATUS     status = OK;

    ipc_reply = _ipc_alloc(sizeof(sockMsg));

    if (!ipc_reply)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = mn_listen(sockMsg->msg.bindcmd.sockfd, 
                  sockMsg->msg.listencmd.backlog );

    sockMsg = (sockMsg *)IPC_PAYLOAD(ipc_reply); 

    sockMsg->libsockcmd = MN_LISTEN_REPLY;
    sockMsg->errno      = status;

    status = IPC_reply(ipc_req,ipc_reply);

exit:
    return status; 
}
