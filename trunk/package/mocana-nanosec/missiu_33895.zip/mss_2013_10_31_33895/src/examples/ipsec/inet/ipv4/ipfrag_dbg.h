/*
 * ipfrag_dbg.h
 *
 * IP fragmentation module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IPFRAG_DBG_H_
#define _IPFRAG_DBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef IPFRAGDBG_HI
   #define IPFRAGDBG_HI
  #endif
 #endif

#else
 #ifdef IPFRAGDBG_HI
  #undef IPFRAGDBG_HI
 #endif
#endif

#include "netdbg.h"

#define IPFRAG_MAGIC_COOKIE 0x69700000 /*"ipfr" = 0x6976672*/

/*#ifdef IPFRAGDBG_HI*/
#if defined(IPFRAGDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define IPFRAG_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == IPFRAG_MAGIC_COOKIE));

  #define IPFRAG_SET_COOKIE(x) (x)->dwMagicCookie = IPFRAG_MAGIC_COOKIE
  #define IPFRAG_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define IPFRAG_DBGP(level, fmt, args...) do { \
    if (level <= g_dwIpFragDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define IPFRAG_DBG(level, x) do {  \
    if (level <= g_dwIpFragDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define IPFRAG_DBG_VAR(x)  x

#else
  #define IPFRAG_CHECK_STATE(x)
  #define IPFRAG_SET_COOKIE(x)
  #define IPFRAG_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define IPFRAG_DBGP
#else
  #define IPFRAG_DBGP(level, fmt, args...)
#endif
  #define IPFRAG_DBG(level, x)
  #define IPFRAG_DBG_VAR(x)
#endif

IPFRAG_DBG_VAR(MOC_EXTERN DWORD g_dwIpFragDebugLevel);

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _IPFRAG_DBG_H_ */
