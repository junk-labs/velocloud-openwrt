/*
 * netcfg.h
 *
 * Internal header file for network configuration functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __NETCFG__
#define __NETCFG__

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "setup_flavor.h"
#include "../include/ioctl.h"
#include "../include/socket.h"
#include "../include/in.h"
#include "../include/if.h"
#include "../include/if_types.h"
#include "nettime.h"
#include "../include/netselect.h"
#include "../include/sockio.h"
#include "netcommon.h"
#include "netutils.h"
#include "netdb.h"
#include "sockapi.h"
#include "setupnet_dbg.h"

#ifdef NET_MULTIF
  #include "natcfgapi.h"
  #include "../include/route.h"
#endif

#ifdef ROUTER
/* RS commented out
  #include "ripapi.h"
*/
#endif

#ifdef IPSEC
  #include "hmac_md5.h"
  #include "hmac_sha1.h"
  #include "des.h"
#if 0
  /* IPSEC is not configed by us */
  #include "ipsec_api.h"
#endif
#endif /* IPSEC */

/****************************************************************************
 *
 * Defines
 *
 ****************************************************************************/
#define SIOCSIFIVLANPRI  0x1
#define SIOCSIFIVLANTAG  0x2
#define SIOCGIFIFLAGDHCP 0x3
#define MAX_POLICY     (8)

/****************************************************************************
 *
 * Typedefs
 *
 ****************************************************************************/
typedef struct var_ioctl {
  char *pcVarName;
  DWORD dwIoctlCode;
} VAR_IOCTL;


/****************************************************************************
 *
 * Internal function protos
 *
 ****************************************************************************/
WORD _ComputeVlanValue(OCTET oIfIdx);
void _ConvertToMac(OCTET *poMac, char *pchMacString);
LONG _SetNetIfParameter(int   iSock,
                        OCTET oIfIdx,
                        DWORD dwSocketIoctl,
                        char  *pchParamValue);


#endif
