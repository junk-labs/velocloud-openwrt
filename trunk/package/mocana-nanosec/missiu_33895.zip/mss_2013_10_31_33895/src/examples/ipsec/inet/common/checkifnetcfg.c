
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcfg.h"
#include "setupnet.h"
#include "configapi.h"
/* #include "flavor.h" */

/*
 * SetupNetCheckIfNetCfg
 *  Check if the device is acting as a bridge or router or both
 *
 *  Args:
 *   poBridge             Number of Bridged legs to be filled in
 *   poRouter             Number of Routed legs to be filled in
 *   iIfAvoidIdx          Interface number to avoid checking
 *                        Negative number to mean no avoidance.
 *
 *  Return:
 *   SetupNetReturn
 */
SetupNetReturn SetupNetCheckIfNetCfg(OCTET *poBridge, OCTET *poRouter, 
                                     int iIfAvoidIdx)
{
#ifdef ROUTER
  OCTET oIfNum;
  int i;
  OCTET oBridge,oRouter;

  oBridge=oRouter=0;
  SetupNetGetIfNum(&oIfNum);
  
  for (i=1;i<oIfNum;i++) {
    CHAR acTmpString[30];
    CHAR chParamValue[20];
    
    sprintf(acTmpString, "IF%dENABLED", i);
    if ((iIfAvoidIdx != i) &&
        (ConfigGetParam(acTmpString, chParamValue, 
                        CONFIG_MAXPARAMLENGTH) == CONFIG_OK) && 
        (strcmp(chParamValue,"YES") == 0)) {
      LONG lReturn = 0;
      
      sprintf(acTmpString, "IF%dNETCONF", i);
      lReturn = ConfigGetParam(acTmpString, chParamValue, 
                               CONFIG_MAXPARAMLENGTH);
      
      if (lReturn == CONFIG_OK) {
        if (!strcmp(chParamValue,"ROUTED")) {
          /* We have at least one active routed leg */
          oRouter ++;
        } else if (!strcmp(chParamValue,"BRIDGED")) {
          oBridge++;
        }
      }
    }
  }
  *poBridge = oBridge;
  *poRouter = oRouter;
  
#endif  
  return SETUPNET_OK;  
}
