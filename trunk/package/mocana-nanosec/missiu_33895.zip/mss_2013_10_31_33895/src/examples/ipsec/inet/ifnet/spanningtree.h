/*
 * spanningtree.h
 *
 * Header file for the spanning tree algorithm and protocol
 * Mainly code taken from ANSI/IEEE Std 802.1D, 1998 Edition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef __SPANNINGTREE_H_
#define __SPANNINGTREE_H_

/***************************************************************************
* DEFINED CONSTANTS
**************************************************************************/
/* Note: spanning tree times are in 1/256 of a second */
#define STP_PROCESS_TIME (125) /* e.g. 125ms/5ms (32 * 1/256 == 125ms) */
#define STP_INCREMENT (32)  /* (STP_PROCESS_TIME)/(1/256) */
/* Used to decrease the frequency of calling the spanning tree
process function */

#define Zero  0
#define One   1

#define False 0
#define True  1

/** port states. **/
#define Disabled   0                                      /* (8.4.5) */
#define Listening  1                                      /* (8.4.2) */
#define Learning   2                                      /* (8.4.3) */
#define Forwarding 3                                      /* (8.4.4) */
#define Blocking   4                                      /* (8.4.1) */

/** BPDU type constants **/
#define Config_bpdu_type 0
#define Tcn_bpdu_type    128

/** pseudo-implementation constants. **/

#define All_ports ETHBR_MAXNUM_IF+1
/* ports start at 1, arrays in C start at 0 */

#define Default_path_cost 10
/* arbitrary */

#define Message_age_increment 1
/* minimum increment possible to avoid underestimating age, allows
for BPDU transmission time */

#define No_port 0
/* reserved value for Bridge's root port parameter indicating no
root port, used when Bridge is the root */

/***************************************************************************
* TYPEDEFS, STRUCTURES, AND UNION DECLARATIONS
**************************************************************************/

/** basic types. **/

typedef int Int;      /* to align with convention used here for use of
                         case. Types and defined constants have their
                         initial letters capitalized. */
typedef Int Boolean;  /* : (True, False) */
typedef Int State;    /* : (Disabled, Listening, Learning,
                            Forwarding, Blocking) */

typedef struct {
  DWORD dwHi;        /* high order 32 bits */
  DWORD dwLo;        /* low order 32 bits */
} IDWORD;

/* is id1 == id2 ?*/
#define ISEQ_IDWORD(id1, id2) (                                 \
    ((id1).dwLo == (id2).dwLo) && ((id1).dwHi == (id2).dwHi)    \
    )

/* is id1 < id2 ?*/
#define ISLT_IDWORD(id1, id2) (                                 \
    ((id1).dwHi < (id2).dwHi) ||                                \
    ( ((id1).dwHi == (id2).dwHi) && ((id1).dwLo < (id2).dwLo) ) \
    )

/** BPDU encoding types defined in Clause 9, �Encoding of Bridge Protocol
Data Units� are: **/
typedef OCTET               Protocol_version;             /* (9.2.2) */
typedef OCTET               Bpdu_type;                    /* (9.2.3) */
typedef OCTET               Flag;                         /* (9.2.4) */
typedef IDWORD              Identifier;                   /* (9.2.5) */
typedef DWORD               Cost;                         /* (9.2.6) */
typedef WORD                Port_id;                      /* (9.2.7) */
typedef WORD                Time;                         /* (9.2.8) */


/** Configuration BPDU Parameters (8.5.1) **/

typedef struct
{
  Bpdu_type   type;
  Identifier  root_id;                                    /* (8.5.1.1) */
  Cost        root_path_cost;                             /* (8.5.1.2) */
  Identifier  bridge_id;                                  /* (8.5.1.3) */
  Port_id     port_id;                                    /* (8.5.1.4) */
  Time        message_age;                                /* (8.5.1.5) */
  Time        max_age;                                    /* (8.5.1.6) */
  Time        hello_time;                                 /* (8.5.1.7) */
  Time        forward_delay;                              /* (8.5.1.8) */
  Flag        topology_change_acknowledgment;             /* (8.5.1.9) */
  Flag        topology_change;                            /* (8.5.1.10)*/
} Config_bpdu;

/** Topology Change Notification BPDU Parameters (8.5.2) **/

typedef struct
{
  Bpdu_type   type;
} Tcn_bpdu;

/** Bridge Parameters (8.5.3) **/

typedef struct
{
  Identifier  designated_root;                            /* (8.5.3.1) */
  Cost        root_path_cost;                             /* (8.5.3.2) */
  Int         root_port;                                  /* (8.5.3.3) */
  Time        max_age;                                    /* (8.5.3.4) */
  Time        hello_time;                                 /* (8.5.3.5) */
  Time        forward_delay;                              /* (8.5.3.6) */
  Identifier  bridge_id;                                  /* (8.5.3.7) */
  Time        bridge_max_age;                             /* (8.5.3.8) */
  Time        bridge_hello_time;                          /* (8.5.3.9) */
  Time        bridge_forward_delay;                       /* (8.5.3.10)*/
  Boolean     topology_change_detected;                   /* (8.5.3.11)*/
  Boolean     topology_change;                            /* (8.5.3.12)*/
  Time        topology_change_time;                       /* (8.5.3.13)*/
  Time        hold_time;                                  /* (8.5.3.14)*/
} Bridge_data;


/** Port Parameters (8.5.5) **/

typedef struct
{
  State       state;                                      /* (8.5.5.2) */
  Port_id     port_id;                                    /* (8.5.5.1) */
  Int         path_cost;                                  /* (8.5.5.3) */
  Identifier  designated_root;                            /* (8.5.5.4) */
  Int         designated_cost;                            /* (8.5.5.5) */
  Identifier  designated_bridge;                          /* (8.5.5.6) */
  Port_id     designated_port;                            /* (8.5.5.7) */
  Boolean     topology_change_acknowledge;                /* (8.5.5.8) */
  Boolean     config_pending;                             /* (8.5.5.9) */

  Boolean     change_detection_enabled;                   /* (8.5.5.10) */
} Port_data;

/** types to support timers for this pseudo-implementation. **/

typedef struct
{
  Boolean     active;   /* timer in use. */
  Time        value;    /* current value of timer, counting up. */
} Timer;


/*
 *
 */
MOC_EXTERN OCTET aoSpanningTreeAddr[ETHADDRESS_LEN];

MOC_EXTERN Port_data port_info[All_ports];                    /* (8.5.5) */
#define ST_PORT_STATE(x) (port_info[(x)+1].state)

MOC_EXTERN Bridge_data  bridge_info;                                /* (8.5.3) */
#define ST_TOPOLOGY_CHANGE (bridge_info.topology_change == True)
/* Macro to convert from spanning tree time (1/256s) to units of 1ms */
#define ST_FORWARD_DELAY   ((bridge_info.forward_delay*1000)/256)

/* Spanning tree protocol mutex */
MOC_EXTERN pthread_mutex_t xMutex_STP;

LONG SpanningTreeCreate(H_NETINSTANCE hEth);
LONG SpanningTreeDestroy(void);
LONG SpanningTreeInit(ETHSTATE *pxEth);
LONG SpanningTreeStart(void);
LONG SpanningTreeStop(void);
void SpanningTreeTerminate(void);
LONG SpanningTreeRcv(OCTET oPortNo, OCTET *poPacket);
void SpanningTreeWrite(OCTET oPortNo, NETPACKET *pxPacket, NETPACKETACCESS *pxAccess);
void SpanningTreeProcess(void);
void SpanningTreeSetPathCost(OCTET oPortNo, DWORD dwBitRate);


#endif /*__SPANNINGTREE_H_ */
