/*
 * ip2eth_dbg.h
 *
 * Ip to Ethernet module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __IP2ETH_DBG_H__
#define    __IP2ETH_DBG_H__

/*****************************************************************************
 *
 * defines and macros
 *
 *****************************************************************************/

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef IP2ETHDBG_HI
   #define IP2ETHDBG_HI
  #endif
 #endif

#else
 #ifdef IP2ETHDBG_HI
  #undef IP2ETHDBG_HI
 #endif
#endif

#include "netdbg.h"

#define IP2ETH_MAGIC_COOKIE 0x69703265 /*"ip2e" = 0x69703265*/

/*#ifdef IP2ETHDBG_HI*/
#if defined(IP2ETHDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define IP2ETH_CHECK_STATE(x) \
            ASSERT((x != NULL) && ((x)->dwMagicCookie == IP2ETH_MAGIC_COOKIE));
  #define IP2ETH_SET_COOKIE(x) (x)->dwMagicCookie = IP2ETH_MAGIC_COOKIE
  #define IP2ETH_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define IP2ETH_DBGP(level, fmt, args...)    do {    \
    if (level <= g_dwIp2EthDebugLevel) {        \
      printf(fmt, ##args);                \
    }                            \
  } while (0)

  #define IP2ETH_DBG(level, x)    do {        \
    if (level <= g_dwIp2EthDebugLevel) {        \
      x;                        \
    }                            \
  } while (0)

  #define IP2ETH_DBG_VAR(x)        x

  #define IP2ETH_CHECKPOINT(x)          (x = __LINE__)

  #define IP2ETH_ASSERT(x) ASSERT(x)
#else
  #define IP2ETH_CHECK_STATE(x)
  #define IP2ETH_SET_COOKIE(x)
  #define IP2ETH_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define IP2ETH_DBGP
#else
  #define IP2ETH_DBGP(level, fmt, args...)
#endif
  #define IP2ETH_DBG(level, x)
  #define IP2ETH_DBG_VAR(x)
  #define IP2ETH_CHECKPOINT(x)
  #define IP2ETH_ASSERT(x)
#endif

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3


/*****************************************************************************
 *
 * extern
 *
 *****************************************************************************/

IP2ETH_DBG_VAR(MOC_EXTERN DWORD g_dwIp2EthDebugLevel);

#endif  /* __IP2ETH_DBG_H__ */
