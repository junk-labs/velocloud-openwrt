/*
 * ipfrag_rcv.c
 *
 * Ip frag Rx function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/

#include "ipfrag_defs.h"

/*****************************************************************************
 *
 * debug
 *
 *****************************************************************************/
#ifndef NDEBUG
DWORD dbg_dwIpFragRxFragDgramCount = 0;
DWORD dbg_dwIpFragReassemblyCompleteCount = 0;
DWORD dbg_dwIpFragMaxNumDgramCnt = 0;
#endif

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Local Function
 *
 *****************************************************************************/

static void _IpFragReassembleAndSendUp(IPFRAGSTATE *pxIpFrag,
                                              FRAG_DATAGRAM *pxDgram,
                                              NETWORKID *pxNetworkId)
{
  FRAG_PACKET *pxFragPacket;
  OCTET *poDgramPayload,*poDgramIpPaylaod;
  WORD wDgramPayloadLength;
  NETPACKETACCESS xNetPacketAccess;
  H_NETINTERFACE  hULIf;
  H_NETINSTANCE hULInst;
  PFN_NETRXCBK pfnRxCbk;
  LONG lRv;

  ASSERT(pxDgram != NULL);
  pxNetworkId->wDatagramId = 0;
  pxNetworkId->wFragOffset = 0;
  pxNetworkId->wTotalLen = pxDgram->wDgramLength + pxNetworkId->oIpHdrLen;

  /*set the datagram payload Length*/
  wDgramPayloadLength = pxIpFrag->wOffset+
                        sizeof(IPHDR)+
                        pxDgram->wDgramLength+
                        pxIpFrag->wTrailer;

  /*allocate the datagram payload to be reassembled*/
  poDgramPayload = NetMalloc(wDgramPayloadLength);
  ASSERT(poDgramPayload);

  /*set the NETPACKETACCESS structure*/
  xNetPacketAccess.wOffset = pxIpFrag->wOffset;
  xNetPacketAccess.wLength = sizeof(IPHDR)+ pxDgram->wDgramLength;


  /*TODO which mutex to use*/
  NETPAYLOAD_CREATE(&pxDgram->xNetPacket.pxPayload,
                    NetFree,
                    pxIpFrag->pxMutex,
                    poDgramPayload,
                    wDgramPayloadLength);
  if(NULL == pxDgram->xNetPacket.pxPayload)
  {
      lRv = NETERR_MEM;
      DEBUG_ERROR(DEBUG_MOC_IPV4, "Error:_IpFragReassembleAndSendUp - NETPAYLOAD_CREATE failed : %d",lRv);
      NetFree(poDgramPayload);
      return;
  }

  /*set the ip payload*/
  poDgramIpPaylaod = (OCTET*)poDgramPayload + pxIpFrag->wOffset + sizeof(IPHDR);

  DLLIST_head(&pxDgram->dllPacket);

  while ((pxFragPacket = DLLIST_remove(&pxDgram->dllPacket)) != NULL) {
    NETPAYLOAD_CHECK(pxFragPacket->pxNetPayload);
    /*copy data from the fragpacket netpayload to the datagram ip payload*/
    #if 0
    printf("frag offset = %d,frag length = %d, payload offset = %d\n",
           pxFragPacket->wFragOffset,
           pxFragPacket->wFragLength,
           pxFragPacket->wOffset);
    #endif
    ASSERT( (pxFragPacket->wFragOffset + pxFragPacket->wFragLength) <= pxDgram->wDgramLength);

    MOC_MEMCPY((ubyte *)(poDgramIpPaylaod + pxFragPacket->wFragOffset),
                  (ubyte *)(pxFragPacket->pxNetPayload->poPayload + pxFragPacket->wOffset),
                  (ubyte4)(pxFragPacket->wFragLength));
    NETPAYLOAD_DELUSER(pxFragPacket->pxNetPayload);
#ifdef __IPFRAG_USE_MEMPOOL__
    MEM_POOL_putPoolObject(&pxIpFrag->fragPacketPool, (void **)(&pxFragPacket));
#else
    FREE(pxFragPacket);
#endif
  }

  clear_DLLIST(&pxDgram->dllPacket,NULL);

  /* Send up the datagram now */
  hULIf = pxIpFrag->hULIf;
  hULInst = pxIpFrag->hULInst;
  pfnRxCbk = pxIpFrag->pfnRxCbk;
  ASSERT(pfnRxCbk != NULL);

  /*send the packet to the UL*/
  lRv = pfnRxCbk(hULInst,hULIf,&pxDgram->xNetPacket,&xNetPacketAccess,(H_NETDATA)pxNetworkId);

}





/*
 * IpFragInsertPacketInDgram
 *  Datagram main management function: inserts the packet
 *  in the datagram. If the datagram is complete, send it up
 *  And clear it.
 *
 *  Args:
 *   pxDgram               Datagram structure pointer
 *   poPacket              packet pointer
 *   dwLength              poPacket length
 *   dwOffset              Ip offset in poPacket
 *   pxVlan                Vlan structure pointer
 *
 */

static void _IpFragInsertPacketInDgram(IPFRAGSTATE *pxIpFrag,
                                              FRAG_DATAGRAM *pxDgram,
                                              NETPACKET *pxNetPacket,
                                              NETPACKETACCESS *pxNetPacketAccess,
                                              NETWORKID *pxNetworkId,
                                              WORD wFragOffset)
{
  FRAG_PACKET *pxFragPacket;
  NETPAYLOAD *pxNetPayload;
  OCTET *poPayload;
  WORD wFragLength; /* In byte */
  WORD wFragEnd;  /* In byte */
  WORD wFragOffsetInBytes;
#ifdef __IPFRAG_USE_MEMPOOL__
  MSTATUS mstatus;
#endif

  ASSERT(pxDgram != NULL);
  NETPACKET_CHECK(pxNetPacket);
  pxNetPayload = pxNetPacket->pxPayload;
  poPayload = pxNetPayload->poPayload;

  wFragOffsetInBytes = (wFragOffset & IPFRAGMASK_OFFSET) << 3;
  wFragLength = pxNetworkId->wTotalLen - (WORD)(pxNetworkId->oIpHdrLen);
  wFragEnd = wFragOffsetInBytes + wFragLength;

  /*Update the accumulated size*/
  pxDgram->wAccLength += wFragLength;
  /*update the datagram timer*/
  pxDgram->dwTimer = NetGetMsecTime();

  if ((wFragOffsetInBytes > pxIpFrag->wMD) ||
      (wFragEnd > pxIpFrag->wMD) ||
      (pxDgram->wAccLength > pxIpFrag->wMD) ||
      (DLLIST_count_inline(&pxDgram->dllPacket) >= IPFRAG_MAX_NUM_PACKETS) ){

    (void*)DLLIST_remove(&pxIpFrag->dllPending);
    IpFragFreeDgram((void*)pxDgram);
    SNMP(xTcpipData.ipReasmFails ++;)
    NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
    return;
  }

  /* Is the packet received got the More Fragment bit set to FALSE ?*/
  if ( (wFragOffset & (WORD)IPFRAGMASK_MF) == (WORD)0x0000){
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IPFRAG_DBGP(REPETITIVE,
                "IpFragInsertPacketInDgram: pxDgram = 0x%p,rcvd MF bit set to false => dgram length = %d\n",
                pxDgram,
                wFragEnd);*/
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "IpFragInsertPacketInDgram: pxDgram = 0x", (int)pxDgram);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ",rcvd MF bit set to false => dgram length = ", wFragEnd);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
    pxDgram->wDgramLength = wFragEnd;
  }

  /*Insert the frag packet in the datagram*/
#ifdef __IPFRAG_USE_MEMPOOL__
  if( OK > (mstatus = MEM_POOL_getPoolObject(&pxIpFrag->fragPacketPool, (void **)&pxFragPacket)))
  {
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: IpFragRcv: unable to allocate buffer");
    return ;
  }
  MOC_MEMSET((ubyte *)pxFragPacket, 0, sizeof(FRAG_PACKET));
  pxFragPacket->pxIpFragState = pxIpFrag;
#else
  pxFragPacket = (FRAG_PACKET*)MALLOC(sizeof(FRAG_PACKET));
#endif

  pxFragPacket->wFragOffset = wFragOffsetInBytes;
  pxFragPacket->wFragLength = wFragLength;
  pxFragPacket->wOffset = pxNetPacketAccess->wOffset + pxNetworkId->oIpHdrLen;

  pxFragPacket->pxNetPayload = pxNetPayload;

  (void*)DLLIST_append(&pxDgram->dllPacket,(void*)pxFragPacket);

  /*Is the datagram completed ?*/
  if( (pxDgram->wDgramLength != 0) && (pxDgram->wAccLength >= pxDgram->wDgramLength) ){
  /* We 've got all the datagram: reassemble and send Up */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IPFRAG_DBGP(REPETITIVE,
                "IpFragInsertPacketInDgram: pxDgram = 0x%p, datagram completed, send it up\n",
                pxDgram);*/
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "IpFragInsertPacketInDgram: pxDgram = 0x", (int)pxDgram);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, ", datagram completed, send it up");
    }
    _IpFragReassembleAndSendUp(pxIpFrag,pxDgram,pxNetworkId);
    (void*)DLLIST_remove(&pxIpFrag->dllPending);
#ifdef __IPFRAG_USE_MEMPOOL__
    MEM_POOL_putPoolObject(&pxIpFrag->fragDatagramPool, (void **)(&pxDgram));
#else
    FREE(pxDgram);
#endif
    DEBUG(dbg_dwIpFragReassemblyCompleteCount ++);
    SNMP(xTcpipData.ipReasmOKs ++;)
  }

  return ;
}

/*****************************************************************************
 *
 * API function
 *
 *****************************************************************************/
/*
 * IpFragInstanceRcv
 *  Ip fragmentation Instance Rcv function
 *   Ip fragmentation Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIpFrag                    Instance Handle
 *    hLLIf                      Interface handle
 *    pxNetPacket                   packet
 *    wOffset                    IP PDU offset.
 *    hData                      cast to NETWORKID
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG IpFragInstanceRcv(H_NETINSTANCE    hIpFrag,
                       H_NETINTERFACE   hLLIf,
                       NETPACKET        *pxNetPacket,
                       NETPACKETACCESS  *pxPktAccess,
                       H_NETDATA        hData)
{
  IPFRAGSTATE     *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
  NETPAYLOAD      *pxPayload;
  OCTET           *poPayload;
  WORD            wOffset;
  WORD            wFragOffset;
  LONG            lRxedLen;
  NETWORKID       *pxNetworkId = (NETWORKID*)hData;
  FRAG_DATAGRAM   *pxDgram;

  IPFRAG_CHECK_STATE(pxIpFrag);
  NETPACKET_CHECK(pxNetPacket);
  ASSERT(pxPktAccess);

  pxPayload = pxNetPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  wOffset = pxPktAccess->wOffset;
  lRxedLen = (LONG)pxPktAccess->wLength;

  wFragOffset = pxNetworkId->wFragOffset;

  /*Check if the LL Interface is valid*/
  ASSERT(( (int)hLLIf == 1));

  ASSERT( (wOffset % sizeof(int)) == 0);

  /*Only reassemble packet that are for us*/
  /*is the packet fragmented ?*/
  if ((wFragOffset & (WORD)(IPFRAGMASK_MF | IPFRAGMASK_OFFSET)) == 0) {
    /* Unfragmented datagram : goes through */
    H_NETINTERFACE  hULIf = pxIpFrag->hULIf;
    H_NETINSTANCE hULInst = pxIpFrag->hULInst;
    PFN_NETRXCBK pfnRxCbk = pxIpFrag->pfnRxCbk;
    ASSERT(pfnRxCbk != NULL);

    /*send the packet to the UL*/
    return pfnRxCbk(hULInst,hULIf,pxNetPacket,pxPktAccess,(H_NETDATA)pxNetworkId);
  }

  /*the packet is fragmented*/
  DEBUG(dbg_dwIpFragRxFragDgramCount ++;);
  SNMP(xTcpipData.ipReasmReqds ++;) /* Needs reassembly */

  /*IPFRAG_DBGP(REPETITIVE,"IpFragRcv: %ld pending datagrams\n",DLLIST_count_inline(&pxIpFrag->dllPending)); */

  /* A. Do we have the coresponding datagram */
  DLLIST_head(&pxIpFrag->dllPending);
  while( (pxDgram = DLLIST_read(&pxIpFrag->dllPending)) != NULL){
    if ((pxDgram->wId == pxNetworkId->wDatagramId) &&
       (pxDgram->dwSrcIP == pxNetworkId->dwSrcAddr) &&
       (pxDgram->oProtId == pxNetworkId->oProtocol) &&
       (pxDgram->dwDstIP == pxNetworkId->dwDstAddr)) {
       break;
    }
    DLLIST_next(&pxIpFrag->dllPending);
  }

  if ( pxDgram == NULL) {
    /* We don't have a  datagram in the pending list*/
    if ( DLLIST_count_inline(&pxIpFrag->dllPending) <= IPFRAG_MAX_NUM_DGRAMS ) {
#ifdef __IPFRAG_USE_MEMPOOL__
       MSTATUS mstatus;
       if( OK > (mstatus = MEM_POOL_getPoolObject(&pxIpFrag->fragDatagramPool, (void **)&pxDgram)))
       {
         DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: IpFragRcv: unable to allocate buffer");
         return -1;
       }
#else
       pxDgram = (FRAG_DATAGRAM*)MALLOC(sizeof(FRAG_DATAGRAM));
#endif
       ASSERT(pxDgram != NULL);
       MOC_MEMSET((ubyte *)pxDgram, 0, sizeof(FRAG_DATAGRAM));

       /*initialize the datagram*/
#ifdef __IPFRAG_USE_MEMPOOL__
       pxDgram->pxIpFragState = pxIpFrag;
#endif
       pxDgram->hLLIf = hLLIf;
       pxDgram->dwDstIP = pxNetworkId->dwDstAddr;
       pxDgram->dwSrcIP = pxNetworkId->dwSrcAddr;
       pxDgram->wId = pxNetworkId->wDatagramId;
       pxDgram->oProtId = pxNetworkId->oProtocol;
       pxDgram->dwTimer = NetGetMsecTime();

       MOC_MEMCPY((ubyte *)&pxDgram->xNetPacket,
                     (ubyte *)pxNetPacket,
                     sizeof(NETPACKET));

       MOC_MEMCPY((ubyte *)&pxDgram->xNetworkId,
                     (ubyte *)pxNetworkId,
                     sizeof(NETWORKID));

       /*append the datagram into the pending list*/
       (void*)DLLIST_append(&pxIpFrag->dllPending,(void*)pxDgram);

       if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_REPETITIVE))
       {
         /*IPFRAG_DBGP(REPETITIVE,
                   "IpFragRcv:rcv first dgram, pxDgram=0x%p, Id=%d, Src=%ld.%ld.%ld.%ld, Dst=%ld.%ld.%ld.%ld, prot=%s\n",
                   pxDgram,pxDgram->wId,
                   IPADDRDISPLAY(pxDgram->dwSrcIP),
                   IPADDRDISPLAY(pxDgram->dwDstIP),
                   IpProtoToString(pxDgram->oProtId));*/
         DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "IpFragRcv:rcv first dgram, pxDgram= 0x", (int)pxDgram);
         DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", Id= ", pxDgram->wId);
         DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Src= ", pxDgram->dwSrcIP);
         DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Dst= ", pxDgram->dwDstIP);
         DEBUG_PRINT(DEBUG_MOC_IPV4, ", prot= ");
         DEBUG_PRINTNL(DEBUG_MOC_IPV4, IpProtoToString(pxDgram->oProtId));
       }


    } else {
      /*all free datagrams have been taken*/
      DEBUG(dbg_dwIpFragMaxNumDgramCnt ++;);
      SNMP(xTcpipData.ipReasmFails ++;);
      NETPAYLOAD_DELUSER(pxPayload);
      return -1;

    }
  } else {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IPFRAG_DBGP(REPETITIVE,
                "IpFragRcv:rcv another datagram, pxDgram=0x%p, Id=%d, Src=%ld.%ld.%ld.%ld, Dst=%ld.%ld.%ld.%ld,prot=%s\n",
                pxDgram,pxDgram->wId,
                IPADDRDISPLAY(pxDgram->dwSrcIP),
                IPADDRDISPLAY(pxDgram->dwDstIP),
                IpProtoToString(pxDgram->oProtId));*/
         DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "IpFragRcv:rcv another dgram, pxDgram= 0x", (int)pxDgram);
         DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", Id= ", pxDgram->wId);
         DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Src= ", pxDgram->dwSrcIP);
         DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Dst= ", pxDgram->dwDstIP);
         DEBUG_PRINT(DEBUG_MOC_IPV4, ", prot= ");
         DEBUG_PRINTNL(DEBUG_MOC_IPV4, IpProtoToString(pxDgram->oProtId));
    }
  }

  /* The Dgram is there, either new or old */
  _IpFragInsertPacketInDgram(pxIpFrag,
                             pxDgram,
                             pxNetPacket,
                             pxPktAccess,
                             pxNetworkId,
                             wFragOffset);
  /*IPFRAG_DBGP(REPETITIVE,"IpFragRcv: %ld pending datagrams after insert\n",DLLIST_count_inline(&pxIpFrag->dllPending)); */

  return lRxedLen;
}





