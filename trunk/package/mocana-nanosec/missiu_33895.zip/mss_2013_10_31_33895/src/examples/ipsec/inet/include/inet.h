/*
 * inet.h
 *
 * Definitions for the Socket API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef inet_h
#define inet_h

/***************************************************************************/
/*                             D E F I N E S                               */
/***************************************************************************/

/***************************************************************************/
/*                  D A T A    S T R U C T U R E S                         */
/***************************************************************************/

/***************************************************************************/
/*                       M A C R O S                                       */
/***************************************************************************/

/***************************************************************************/
/*           F U N C T I O N    P R O T O T Y P E S                        */
/***************************************************************************/

/*
 * inet_pton
 *  Convert IP address from representation ASCII dot separated format
 *  to binary format
 *
 *  Arg:
 *   lFamily                      protocol family: AF_INET, AF_INET6 (IPV6)
 *   strptr                       string address
 *   addrptr                      pointer to fill up with the address
 *
 *  Return:
 *   1 - success,
 *   0 - bad address format
 *   -1 unknown protocol family
 */
int inet_pton(int lFamily, const char *strptr, void * addrptr);

/*
 * inet_ntop
 *  convert binary IP address to representation (ASCCI dot separated)
 *  frmat.
 *
 *  Arg:
 *   lFamily                      AF_INET or AF_INET6 (IPV6)
 *   addrptr                      address in binary format
 *   strptr                       buffer for conversion result
 *   len                          buffer size
 *
 *  Return:
 *   pointer to result if OK. NULL if not
 */
const char *inet_ntop(int lFamily,const void *addrptr,char *strptr,ubyte4 len);

/*
 * inet_addr
 *  Convert IP address in ASCII dot notation to DWORD
 *  NOTE:
 *   inet_aton is preferred over inet_addr  UNP Steven v1 p71
 *
 *  Arg:
 *   strptr                       IP address to convert
 *
 *  Return:
 *   IPv4 address as DWORD (in_addr_t)
 */
in_addr_t inet_addr(const char *strptr);

/*
 * inet_ntoa
 *  Convert IP address to ASCII dot notation
 *      !!! FUNCTION IS NOTE RE ENTRANT !!!
 *
 * Arg:
 *  inaddr                        IP address to convert
 *
 * Return:
 *  pointer to ASCII string
 */
char *inet_ntoa(struct in_addr inaddr);

int inet_aton(const char *strptr, struct in_addr *addrptr);
#endif

