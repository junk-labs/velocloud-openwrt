#ifndef _MN_IFCONFIG_H_
#define _MN_IFCONFIG_H_

#define MN_IFF_DOWN      0x0 /* Link is down */
#define MN_IFF_UP        0x1 /* Link is up */

typedef enum enum_ifConfigType{
    MN_IF_IPADDR = 0,
    MN_IF_NETMASK,
    MN_IF_GWADDR,
    MN_IF_BRDADDR,
    MN_IF_STATE,
}ENUM_MN_IF_CONFIG;

#endif

MOC_EXTERN MSTATUS mn_ifconfig(struct ifreq *pIfReq, int configrFlags);

