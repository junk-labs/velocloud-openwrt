#ifndef __FLAVOR_H__
#define __FLAVOR_H__

/* Map the build flavor into more meaningful constants internal
 * to the library.  The constant _FLAVOR_myflavor where myflavor is
 * the build flavor will be defined by the build environment.
 *
 * Be sure to check that a valid build flavor is defined.
 *
 * This file should be included by all source files.
*/

#if defined(_FLAVOR_gn)
  #define ETHERNET
  #define IFNUMMAX NUM_IFS
  #define NET_MULTIF
  #define MHX
/* original 
  #define NET_EP1U
  #define ETHERNET
  #define IFNUMMAX 1
*/
#elif defined (_FLAVOR_ep0u) || defined (_FLAVOR_ep0) || defined (_FLAVOR_dslep0)
  #define ETHERNET
  #define NET_EP0U
  #define NET_ETHONLY
  #define IFNUMMAX 1
#elif defined (_FLAVOR_ep0d)
  #define ETHERNET
  #define NET_EP0D
  #define NET_ETHONLY
  #define IFNUMMAX 1
#elif defined (_FLAVOR_ep1u) || defined (_FLAVOR_ep1)
  #define ETHERNET
  #define PPP
  #define NET_EP1U
  #define IPSEC
  #define IFNUMMAX 1
#elif defined (_FLAVOR_ep1d)
  #define ETHERNET
  #define PPP
  #define NET_EP1D
  #define IPSEC
  #define IFNUMMAX 1
#elif defined (_FLAVOR_br)
  #define MHX
  #define ETHERNET
  #define NET_BR
  #define NET_MULTIF
  #define IPSEC
  #define IFNUMMAX 2
#elif defined (_FLAVOR_rt)
  #define MHX
  #define ETHERNET
  #define PPP
  #define IPFRAG
  #define NAT
  #define ROUTER
  #define NET_BR
  #define NET_RT
  #define NET_MULTIF
  #define IPSEC
  #define IFNUMMAX 2
#elif defined (_FLAVOR_dslrt)
  #define ETHERNET
  #define PPP
  #define IPOA
  #define IPFRAG
  #define NAT
  #define ROUTER
  #define NET_BR
  #define NET_RT
  #define NET_DSL
  #define NET_MULTIF
  #define IPSEC
  #define IFNUMMAX 9
#elif defined (_FLAVOR_dslvrt)
  #define ETHERNET
  #define PPP
  #define IPOA
  #define IPFRAG
  #define NAT
  #define ROUTER
  #define NET_BR
  #define NET_RT
  #define NET_DSL
  #define NET_MULTIF
  #define IPSEC
  #define IFNUMMAX 3
#else
  #error "unknown build flavor"
#endif


#endif 
