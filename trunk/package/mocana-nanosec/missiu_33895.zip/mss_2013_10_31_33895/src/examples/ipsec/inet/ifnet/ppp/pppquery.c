/*
 * pppquery.c
 *
 * PPP query
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "pppdefs.h"

/***************************************************************************
 *
 * API functions
 *
 ***************************************************************************/


/*
 * PppInstanceQuery
 *  Set an instance option
 *
 *  Args:
 *   hPpp                  Handle of the instance to destroy
 *   oOption               option code
 *   phData                 data handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceQuery(H_NETINSTANCE hPpp,OCTET oOption,H_NETDATA *phData)
{
  /* March-2002. Empty for now */
  return NETERR_NOERR;
}

