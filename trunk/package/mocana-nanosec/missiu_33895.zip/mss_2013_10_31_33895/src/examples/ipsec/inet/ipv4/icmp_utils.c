/*
 * icmp_utils.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "icmp_defs.h"

/*****************************************************************************
 *
 * Global variables
 *
 *****************************************************************************/


/*****************************************************************************
 *
 * IcmpSendPacket
 *
 *****************************************************************************/

LONG IcmpSendPacket(ICMP_STATE *pxIcmp,
                    OCTET oType,
                    OCTET oCode,
                    ICMPMSGDATA *pxIcmpMsgData)
{
  LONG lRv = NETERR_NOERR;
  NETPACKET xNetPacket,*pxOrigNetPacket;
  NETPACKETACCESS xNetPacketAccess,*pxOrigNetPacketAccess;
  NETPAYLOAD *pxOrigPayload;
  OCTET *poOrigPayload,*poPayloadToSend;
  WORD wNetPacketLength;
  WORD wIcmpPacketLength;
  ICMP_HDR *pxIcmpPkt;
  NETWORKID xNetworkId;
  WORD wOffset;
  WORD wLength;
#ifdef IPSEC
  void* pxSP=NULL;              /* pointer for Security Policy data structure */
  int nHdrLen=0;
  int nTrailLen=0;
#endif /* IPSEC */

  ASSERT(pxIcmpMsgData != NULL);

  SNMP(xTcpipData.icmpOutMsgs++);

  pxOrigNetPacket       = pxIcmpMsgData->pxNetPacket;
  pxOrigNetPacketAccess = pxIcmpMsgData->pxNetPacketAccess;

  NETPACKET_CHECK(pxOrigNetPacket);
  ASSERT(pxOrigNetPacketAccess != NULL);

  pxOrigPayload = pxOrigNetPacket->pxPayload;
  poOrigPayload = pxOrigPayload->poPayload;

  SNMP(switch(oType){
         case ICMPTYP_DEST_UNREACH:  xTcpipData.icmpOutDestUnreachs++; break;
         case ICMPTYP_TIME_EXCEEDED: xTcpipData.icmpOutTimeExcds++; break;
         case ICMPTYP_REDIRECT:      xTcpipData.icmpOutRedirects++; break;
         case ICMPTYP_ECHO:          xTcpipData.icmpOutEchos++; break;
         case ICMPTYP_ECHOREPLY:      xTcpipData.icmpOutEchoReps++; break;
         default:
           ASSERT(0);
       });
  if((oType == ICMPTYP_DEST_UNREACH)  ||
     (oType == ICMPTYP_TIME_EXCEEDED) ||
     (oType == ICMPTYP_PARAMETERPROB) ||
     (oType == ICMPTYP_SOURCE_QUENCH) ||
     (oType == ICMPTYP_REDIRECT)) {
    ASSERT(pxOrigNetPacketAccess->wOffset > (IPDEFAULT_HDRSIZE));
    wOffset = pxOrigNetPacketAccess->wOffset - (IPDEFAULT_HDRSIZE + ICMP_NULL_PAYLOAD_LENGTH);
    wLength = IPDEFAULT_HDRSIZE + ICMP_NULL_PAYLOAD_LENGTH + ICMP_PAYLOAD_LENGTH;
    MOC_MEMSET((ubyte *)(poOrigPayload + wOffset),
                  0x00,ICMP_NULL_PAYLOAD_LENGTH);
    wIcmpPacketLength = ICMP_SHORTHEADERLENGTH + wLength;
  }
  else if((oType == ICMPTYP_ECHOREPLY) ||
          (oType == ICMPTYP_ECHO)      ||
          (oType == ICMPTYP_TIMESTAMPREPLY))
  {
    wOffset = pxOrigNetPacketAccess->wOffset + ICMP_SHORTHEADERLENGTH;
    wLength = pxOrigNetPacketAccess->wLength;
    wIcmpPacketLength = wLength;
  }
  else {
    ASSERT(0);
    return -1;
  }

  if(wLength > ICMP_ECHOREPLY_MAXSIZE){
    NETPAYLOAD_DELUSER(pxOrigNetPacket->pxPayload);
    return -1;
  }
  /*Fill the NETWORKID structure*/
  /* (void*)MOC_MEMSET((ubyte *)&xNetworkId,0x00,sizeof(NETWORKID)); */ /*Atul - commenting for perf */

  xNetworkId.oTtL         = 0xFF;
  xNetworkId.dwDstAddr    = pxIcmpMsgData->dwDstAddr;
  xNetworkId.dwSrcAddr    = pxIcmpMsgData->dwSrcAddr;
  xNetworkId.oIfIdx       = pxIcmpMsgData->oIfIdx;
  xNetworkId.oProtocol    = IPPROTO_ICMP;
  xNetworkId.wVlan        = pxIcmpMsgData->wVlan;
  xNetworkId.oIpOptionLen = 0;
  xNetworkId.oToS         = 0;

  /*payload creation and allocation */

  xNetworkId.wTotalLen = IPDEFAULT_HDRSIZE + wIcmpPacketLength;

  wNetPacketLength = (WORD)(pxIcmp->wOffset +
                            wIcmpPacketLength +
                            pxIcmp->wTrailer);

#ifdef IPSEC
  /* check security policy */
  if ((pxSP = IPSecGetSP(xNetworkId.dwDstAddr, 0,
                         xNetworkId.dwSrcAddr, 0,
                         IPPROTO_ICMP, 0))) {
    /* allocate header space for AH or ESP */
    nHdrLen = IPSecGetHdrLen(pxSP);
    /* allocate more space for ESP trailer and ESP-Auth */
    nTrailLen = IPSecGetTrailLen(pxSP,wIcmpPacketLength);
    /* update packet length */
    wNetPacketLength += (nHdrLen + nTrailLen);
    /* store IPSec data into NETWORKID */
    xNetworkId.dwSecurityPolicy = (DWORD)pxSP;
    xNetworkId.wIpSecHdrLength = (WORD)nHdrLen;
    xNetworkId.wIpSecTrailLength = (WORD)nTrailLen;
  }
#endif /* IPSEC */

  /*payload memory allocation */
#ifdef __INET_USE_PAYLOAD_MEMPOOL__
  lRv = NetAllocPayload(&poPayloadToSend,wNetPacketLength);
  if (OK > lRv) {
      NETPAYLOAD_DELUSER(pxOrigPayload);
      return lRv;
  }
#else
  poPayloadToSend = (OCTET*) MALLOC(wNetPacketLength);
#endif
  ASSERT(poPayloadToSend != NULL);

  NETPAYLOAD_CREATE((&(xNetPacket.pxPayload)),
                    NetFree,
                    pxIcmp->pxMutex,
                    poPayloadToSend,
                    (wNetPacketLength)
                    );

  if(NULL == xNetPacket.pxPayload)
  {
      lRv = NETERR_MEM;
      DEBUG_ERROR(DEBUG_MOC_IPV4, "Error:IcmpSendPacket - NETPAYLOAD_CREATE failed : %d",lRv);
      NetFree(poPayloadToSend);
      return lRv;
  }

#ifdef IPSEC
  /*check the int alignment */
  ASSERT(((pxIcmp->wOffset + nHdrLen) % sizeof(int)) == 0);

  /*Fill the NETPACKETACCESS structure*/
  xNetPacketAccess.wOffset = pxIcmp->wOffset + nHdrLen;
#else /* #ifdef IPSEC */
  /*check the int alignment */
  ASSERT((pxIcmp->wOffset % sizeof(int)) == 0);

  /*Fill the NETPACKETACCESS structure*/
  xNetPacketAccess.wOffset = pxIcmp->wOffset;
#endif /* #ifdef IPSEC #else */
  xNetPacketAccess.wLength = wIcmpPacketLength;

  /*Set the Icmp packet pointer*/
  pxIcmpPkt = (ICMP_HDR*)(poPayloadToSend + xNetPacketAccess.wOffset);

  /*Fill the packet*/
  pxIcmpPkt->oType = oType;
  pxIcmpPkt->oCode = oCode;

  NETPAYLOAD_LOCK(pxOrigPayload);

  /*copy the received icmp payload to the packet*/
  (void*)MOC_MEMCPY((ubyte *)((OCTET*)pxIcmpPkt + ICMP_SHORTHEADERLENGTH),
                (ubyte *)(poOrigPayload + wOffset),
                (ubyte4)wLength);

  NETPAYLOAD_UNLOCK(pxOrigPayload);
  NETPAYLOAD_DELUSER(pxOrigPayload);

  /*MTU reporting for ICMP_FRAG_NEEDED message*/
  if (oCode == ICMP_FRAG_NEEDED) {
    ASSERT(oType == ICMPTYP_DEST_UNREACH);
    pxIcmpPkt->u.xIhPmtu.wIpmVoid = 0x0;
    pxIcmpPkt->u.xIhPmtu.wIpmNextMtu = pxIcmpMsgData->wMtu;
  }

  pxIcmpPkt->wChecksum = 0;
  pxIcmpPkt->wChecksum = Checksum16((OCTET*)pxIcmpPkt,wIcmpPacketLength);

  /*send the packet*/
  ASSERT(pxIcmp->pfnLLWrite != NULL);

  lRv = pxIcmp->pfnLLWrite(pxIcmp->hLLInst,
                           pxIcmp->hLLIf,
                           &xNetPacket,
                           &xNetPacketAccess,
                           (H_NETDATA)&xNetworkId);

  return lRv;
}

