/*
 * sstat.h
 *
 * macros to keep simple stats:
 *     # samples, min value, max value, total
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __SSTAT_H__
#define __SSTAT_H__



/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

#include "NNstyle.h"


/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/

/* a is src, b is dest */
#define ASSIGN_DDW_TO_DDW(a, b) { \
  (b).dwHi = (a).dwHi; \
  (b).dwLo = (a).dwLo; \
}

/* a = b - c.  a, b, and c are 64-bit numbers */
#define SUB_DDWS(a, b, c) { \
  (a).dwLo = (b).dwLo - (c).dwLo; \
  if ((c).dwLo > (b).dwLo) \
    (b).dwHi--; \
  (a).dwHi = (b).dwHi - (c).dwHi; \
}

/* a = b - c.  a is a 32-bit number. b and c are 64-bit numbers
 * ASSUMES b > c by 2^32 - 1 or less
 */
#define SUB_DDWS_TO_DW(a, b, c) (a) = (b).dwLo - (c).dwLo;

#define ADD_DW2DD(dw, dd) do {                        \
      register DWORD dwDw2DdAddend = (dd).dwLo;            \
      register DWORD dwDw2DdSum = (dw);                \
      dwDw2DdSum += dwDw2DdAddend;                    \
      if (dwDw2DdSum < dwDw2DdAddend)                \
        (dd).dwHi++;                        \
      (dd).dwLo = dwDw2DdSum;                    \
    } while (0)

#define SSTAT_RECORD(x, v) do {                        \
      if (((v) < (x).dwMin) || (0 == (x).dwCnt))            \
        (x).dwMin = (v);                        \
      if ((v) > (x).dwMax)                        \
        (x).dwMax = (v);                        \
      (x).dwCnt++;                            \
      ADD_DW2DD((v), (x).ddTotal);                    \
    } while (0)

#define SSTAT_REPORT(x) do {                        \
  printf("\n" #x " at 0x%08lX:\n", (long unsigned) &x);            \
  printf("#instances = 0x%08lX\n", (x).dwCnt);                \
  printf("instance min = 0x%08lX, max = 0x%08lX\n", (x).dwMin, (x).dwMax); \
  printf("total = 0x%08lX 0x%08lX\n", (x).ddTotal.dwHi, (x).ddTotal.dwLo); \
} while (0)

#define SSTAT_CLEAR(x) do {                        \
  (x).dwCnt = 0;                            \
  (x).dwMax = 0;                            \
  (x).dwMin = 0;                            \
  (x).ddTotal.dwHi = 0;                            \
  (x).ddTotal.dwLo = 0;                            \
} while (0)


/********************************************************************
 *
 * Typedefs
 *
 ********************************************************************/

typedef struct {
  DWORD dwHi;        /* high order 32 bits */
  DWORD dwLo;        /* low order 32 bits */
} DDWORD;


typedef struct {
  DWORD dwCnt;            /* # times */
  DWORD dwMin;            /* minimum value */
  DWORD dwMax;            /* maximum value */
  DDWORD ddTotal;        /* total */
} SSTAT;


/********************************************************************
 *
 * Functional API
 *
 ********************************************************************/

/* none */


#endif    /* __SSTAT_H__ */
