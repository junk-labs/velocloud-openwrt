#if defined(_AUDACITY)

#include <stdio.h>
#include "NNstyle.h"
#include "profile.h"
#include "macros.h"

PROFILE_BIN *pProfileBinRoot  = NULL; 
DWORD bProfileEnabled = FALSE;               

void ProfileRecord(FILE *pStream)
{
  PROFILE_BIN *pBin = pProfileBinRoot;                        

  while (pBin != NULL) {
    if (pBin->dwTotalTime) {
      fprintf(pStream, "%s %ld %ld %ld %ld\n", pBin->pName, pBin->dwNumCalls,
	      pBin->dwTotalTime, pBin->dwMinTime, pBin->dwMaxTime);

      pBin->dwNumCalls = 0;
      pBin->dwTotalTime = 0;
      pBin->dwMaxTime = 0;
      pBin->dwMinTime = 0xFFFFFFFF;
    }

    pBin = pBin->pNext;
  }

  fprintf(pStream, "__END_TIME_SLICE__\n");
  fflush(pStream);
}
#endif
