/*
 * pppconf.h
 *
 * PPP  link configuration common API.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPPCONF_H_
#define _PPPCONF_H_

/****************************************************************************
 *
 * defines
 *
 ****************************************************************************/


/****************************************************************************
 *
 * API
 *
 ****************************************************************************/

/*
 * PppConfSetup
 *  Specific setup for straight Ppp interfaces
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   NETLINKLEG
 */
LONG PppConfSetup(NETIFCONF *pxIfConf,OCTET oIfIdx);

/*
 * PppConfOpen
 *  Specific openings for straight Ppp interfaces
 *
 *  Args:
 *   pxIfConf           interface conf structure
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG PppConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx);

/*
 * PppConfProcess
 *  straight Ppp link processing
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG PppConfProcess(NETIFCONF *pxIfConf, OCTET oIfIdx);

/*
 * PppConfClose
 *  Ppp specific if close
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return 0
 */
LONG PppConfClose(NETIFCONF *pxIfConf, OCTET oIfIdx);

/*
 * PppConfDestroy
 *  Ppp specific if destroy
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG PppConfDestroy(NETIFCONF *pxIfConf, OCTET oIfIdx);


/*
 * NetAdminChapClientCbk
 *  Network wrapper Chap Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminChapClientCbk(H_NETINSTANCE hInst,
                           OCTET oCbk,
                           H_NETDATA hData);

#ifdef EAP_TLS
/*
 * NetAdminEapTlsClientCbk
 *  Network wrapper EapTls Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminEapTlsClientCbk(H_NETINSTANCE hInst,
                           OCTET oCbk,
                           H_NETDATA hData);

#endif /* EAP_TLS */

/*
 * NetAdminPapClientCbk
 *  Network wrapper Pap Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminPapClientCbk(H_NETINSTANCE hInst,
                           OCTET oCbk,
                           H_NETDATA hData);

/*
 * NetAdminPppCbk
 *  Network wrapper Ppp Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminPppCbk(H_NETINSTANCE hInst,
                    OCTET oCbk,
                    H_NETDATA hData);

/*
 * NetAdminIpcpCbk
 *  Network wrapper Ipcp Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminIpcpCbk(H_NETINSTANCE hInst,
                    OCTET oCbk,
                    H_NETDATA hData);


#endif /* #ifndef _PPPCONF_H_ */
