/*
 * nat_metric.c
 *
 * Routines to calculate NAT chunk metric.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/
#include "nat.h"
#include "nat_defs.h"


/***********************************************************
 *
 * Static Routines
 *
 **********************************************************/
static DWORD _NatFindChunkMetric(NAT_CHUNK* pxNatChunk);


/*****************************************************************************
Function:
        NatSortChunks()
Description:
    Sorts the NAT chunks.
Arguments:
        NATSTATE*       pxNat                   NAT instance handle.
Outputs:
        None.
Returns:
        None.
Revisions:
        27-Aug-2002                     Initial
*****************************************************************************/
void NatSortChunks(NATSTATE* pxNat)
{
  int i, j;
  DWORD adwMetric[NAT_CHUNK_MAX_NUM];
  NAT_CHUNK* pxNatChunkTemp;
  DWORD dwTemp;

  /*
   * TODO: This routine is very inefficient. Needs the following.
   *       1. Ways for faster calculation of the metric.
   *       2. Faster sorting.
   *       3. Faster updating chunk index in the bindings.
   */
  for (i = NAT_CHUNK_MAX_NUM - 1; i >= 0; i--) {
    adwMetric[i] = _NatFindChunkMetric(pxNat->apxNatChunks[i]);
  }

  for (i = 0; i < (NAT_CHUNK_MAX_NUM - 1); i++) {
    for (j = (i + 1); j < NAT_CHUNK_MAX_NUM; j++) {
      if (adwMetric[i] > adwMetric[j]) {
        dwTemp = adwMetric[i];
        adwMetric[i] = adwMetric[j];
        adwMetric[j] = dwTemp;

        pxNatChunkTemp = pxNat->apxNatChunks[i];
        pxNat->apxNatChunks[i] = pxNat->apxNatChunks[j];
        pxNat->apxNatChunks[j] = pxNatChunkTemp;
      }
    }
  }
}


/*****************************************************************************
Function:
        _NatFindChunkMetric()
Description:
        Calculates the chunk metric.
        The metric should be high for chunks with fewer older entries.
        The current metric is average age weighted by chunk occupancy.
        This ensures that for a given age, the chunk with fewer entries
        has a higher metric.
           chunk metric = avg. age / buffer occupancy
Arguments:
        NAT_CHUNK*      pxNatChunk      Handle to the NAT chunk.
Outputs:
        None.
Returns:
        DWORD                           Chunk Metric
Revisions:
        27-Aug-2002                     Initial
*****************************************************************************/
static DWORD _NatFindChunkMetric(NAT_CHUNK* pxNatChunk)
{
  LONG lIdx, lMask;
  DWORD dwBindings = 0;
  DWORD dwAge = 0;
  DWORD dwCurrTime = NetGlobalTimerGet();

  if (pxNatChunk == NULL)
    return (0xFFFFFFFF);

  for (lIdx = (NAT_CHUNK_NUM_BINDINGS >> 5) - 1; lIdx >= 0; lIdx --) {
    DWORD dwStatus = pxNatChunk->adwBindingStatus[lIdx];

    for (lMask = 31; lMask >= 0; lMask --) {
      if (dwStatus & (1 << lMask)) {
        dwBindings ++;
        dwAge += pxNatChunk->axNatBindings[(lIdx << 5) + lMask].dwLastUsed;
      }
    }
  }

  if (dwBindings == 0)
    return (0);

  dwAge = (dwCurrTime * dwBindings) - dwAge;

  /*
   * Buffer occupancy is calculated as
   * (NAT_CHUNK_NUM_BINDINGS << 8) / #_of_active_bindings_in_chunk
   * to get 8 bits of fractional precision.
   */
  return ((dwAge * (NAT_CHUNK_NUM_BINDINGS << 8)) / (dwBindings * dwBindings));
}
