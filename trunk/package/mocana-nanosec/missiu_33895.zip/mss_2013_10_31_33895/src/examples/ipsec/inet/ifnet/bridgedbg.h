/*
 * bridgedbg.h
 *
 * Ethernet module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _BRIDGE_DBG_H_
#define _BRIDGE_DBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef BRIDGEDBG_HI
   #define BRIDGEDBG_HI
  #endif
 #endif

#else
 #ifdef BRIDGEDBG_HI
  #undef BRIDGEDBG_HI
 #endif
#endif

#include "netdbg.h"

#define ETH_MAGIC_COOKIE 0x65746800 /*"eth" = 0x69746800*/

/*#ifdef BRIDGEDBG_HI*/
#if defined(BRIDGEDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define ETH_DBG_ASSERT(x) ASSERT(x)
  #define ETH_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == ETH_MAGIC_COOKIE));

  #define ETH_SET_COOKIE(x) (x)->dwMagicCookie = ETH_MAGIC_COOKIE
  #define ETH_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define ETH_DBGP(level, fmt, args...) do { \
    if (level <= g_dwEthDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define ETH_DBG(level, x) do {  \
    if (level <= g_dwEthDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define ETH_DBG_VAR(x)  x

  #define ETH_CHECKPOINT(x) (x = __LINE__)

#else
  #define ETH_DBG_ASSERT(x)
  #define ETH_CHECK_STATE(x)
  #define ETH_SET_COOKIE(x)
  #define ETH_UNSET_COOKIE(x)
  #define ETH_DBGP(level, fmt, args...)
  #define ETH_DBG(level, x)
  #define ETH_DBG_VAR(x)
  #define ETH_CHECKPOINT(x)
#endif

ETH_DBG_VAR(MOC_EXTERN DWORD g_dwEthDebugLevel);

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3
#define XREPETITIVE 4

#endif /* #ifndef _BRIDGE_DBG_H_ */
