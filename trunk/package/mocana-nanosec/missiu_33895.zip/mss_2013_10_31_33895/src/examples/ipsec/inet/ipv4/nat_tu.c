/*
 * nat_tu.c
 *
 * Does the necessary address translation on TCP/UDP packets,
 * in both Tx and Rx directions.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "nat.h"
#include "nat_defs.h"


/*****************************************************************************
Function:
        NatHandleTURx()
Description:
        Checks if the packet is intended for the CPE. If yes,
        the data is untouched and passed up the stack.
        If not, this module performs the necessary address
        translation. If a binding cannot be found, the packet
        is rejected.
Arguments:
        NATSTATE*               pxNat                   NAT instance handle
        NETPACKET*              pxNetPacket             Packet pointer
        NETPACKETACCESS*        pxNetPacketAccess       Packet info
        H_NETDATA               hData                   NETWORKID*
        void*                   pvProtocolHdr           Pointer to the
                                                        protocol header
                                                        (UDP/TCP)
Outputs:
        None.
Returns:
        LONG                    NAT_TO_CPE              traffic from WAN to CPE.
                                NAT_OK                  means address
                                                        translation is
                                                        successful.
                                NAT_PACKET_UNKNOWN      means that the
                                                        CPE received a
                                                        packet with no
                                                        binding, should be
                                                        thrown away.
                                NAT_DO_NOTHING          The ALGs could have
                                                        freed the packet.
                                                        Instruct the calling
                                                        routine to do nothing
                                                        further with this
                                                        packet.
Revisions:
        11-Oct-2001                                     Initial
        25-Mar-2002                                     API change.
*****************************************************************************/
LONG NatHandleTURx(NATSTATE             *pxNat,
                   NETPACKET            *pxNetPacket,
                   NETPACKETACCESS      *pxNetPacketAccess,
                   H_NETDATA            hData,
                   void                 *pvProtocolHdr)
{
  NETWORKID *pxNetworkId = (NETWORKID*) hData;
  DWORD dwSrcIp = pxNetworkId->dwSrcAddr;
  DWORD dwDstIp = pxNetworkId->dwDstAddr;
  OCTET oProtocolId = pxNetworkId->oProtocol;
  WORD wSrcPort = TRANSPORT_GET_SRC_PORT(pvProtocolHdr);
  WORD wDstPort = TRANSPORT_GET_DST_PORT(pvProtocolHdr);
  NAT_ENTRY *pxNatEntry;
  NAT_TRANS_STRUCT xOrig, xMod;
  WORD wChecksum;
  DWORD dwTransIp;


  /*
   * Perform some size checks.
   */
  {
    WORD wHeaderSize;

    wHeaderSize = (oProtocolId == IPPROTO_TCP) ? (sizeof(TCPHDR)) : (sizeof(UDPHDR));

    if (pxNetPacket->pxPayload->wSize < (pxNetPacketAccess->wOffset +
                                         pxNetworkId->oIpHdrLen +
                                         wHeaderSize)) {
      return (NAT_PACKET_UNKNOWN);
    }
  }


  /*
   * Search for a binding.
   */
  pxNatEntry = NatFindTUBindingRx(pxNat,
                                  dwSrcIp, wSrcPort,
                                  dwDstIp, wDstPort,
                                  oProtocolId);

  if (pxNatEntry == NULL) {

    /*
     * Get the translation address.
     */
    {
      IPTABLEENTRY xIpEntry;

      xIpEntry.dwAddr = 0x0;
      xIpEntry.eAddrType = IPADDRT_ANY;
      xIpEntry.wDefaultVlan = NETVLAN_ANY;
      xIpEntry.oIfIdx = pxNetworkId->oIfIdx;

      IpTableMsg(IPTABLEMSG_GETDEFAULT, (H_NETDATA) &xIpEntry);
      dwTransIp = xIpEntry.dwAddr;
    }


    /*
     * TODO:
     * What if this is a packet which belonged to a L2W binding,
     * but the binding was dropped because of the timeout or
     * some other heuristic?
     */

    /*****************************************************************
     * Unidentified incoming traffic. Test for the following.
     *   1. Is the packet meant for a well-known port in the CPE?
     *      e.g. SNMP. If yes, send it to the CPE.
     *
     *   2. If it is not to a port recognized by the CPE, look
     *      for port forwarding matches. There could be servers
     *      running on the LAN. To advertise these servers to the
     *      WAN, certain ports have to be forwarded.
     *      Check for any such forwarding match and do the
     *      necessary IP destination address translation.
     *      No port translation required.
     *
     *   3. DMZ host is a host outside the firewall for all
     *      intents and purposes. If the above two conditions are
     *      not met, forward it to the DMZ host if one is
     *      configured. In this case also, only IP address has to
     *      be translated. No port translation required.
     ****************************************************************/
    if (NatIsPortForwardedWanToCpe(pxNat, wDstPort, oProtocolId)) {
      /*
       *  Create a local binding.
       */
      pxNatEntry = NatCreateBindingTU(pxNat,
                                      dwSrcIp, wSrcPort,
                                      dwDstIp, wDstPort,
                                      dwTransIp, wDstPort,
                      pxNetworkId->oIfIdx,
                                      oProtocolId,
                                      NAT_BINDING_LOCAL);
    } else {
      /*
       * Create a WAN 2 LAN initiated connection binding to
       * forwarded host.
       */
      BOOL bRandomPortBinding = NatIsRandomPortBinding(pxNat, wDstPort, oProtocolId);
      WORD wFlags = (oProtocolId == IPPROTO_TCP)?
        (NAT_PORT_FORWARD_PROT_TCP):(NAT_PORT_FORWARD_PROT_UDP);
      NAT_PORT_FORWARD* pxNatPortFwd = NatIsPortForwardedToLan(pxNat, wDstPort, wFlags);

      if (pxNatPortFwd) {
        WORD wLanPort;
        WORD wTransPort;

        if (pxNatPortFwd->wFlags & NAT_PORT_FORWARD_DYNAMIC) {
          wLanPort = pxNatPortFwd->wPortBeg;
          wTransPort = wDstPort;
        } else if (bRandomPortBinding == TRUE) {
          wLanPort = 0;
      wTransPort = 0;
        } else {
          wLanPort = wDstPort;
          wTransPort = wDstPort;
        }
        pxNatEntry = NatCreateBindingTU(pxNat,
                                        dwSrcIp, wSrcPort,
                                        pxNatPortFwd->dwIp, wLanPort,
                                        dwTransIp, wTransPort,
                    pxNetworkId->oIfIdx,
                                        oProtocolId,
                                        NAT_BINDING_W2L);
      } else {
        if (pxNat->dwDmzHost) {
          /*
           * Create a WAN 2 LAN initiated connection binding to
           * DMZ host.
           */
          pxNatEntry = NatCreateBindingTU(pxNat,
                                          dwSrcIp, wSrcPort,
                                          pxNat->dwDmzHost, (bRandomPortBinding == TRUE) ? (0) : (wDstPort),
                                          dwTransIp, wDstPort,
                      pxNetworkId->oIfIdx,
                                          oProtocolId,
                                          NAT_BINDING_W2L);
        }
      }
    }
  }


  if (pxNatEntry == NULL) {
    /*
     * The destination IP address matched  that of the
     * CPE, but the packet cannot be routed properly.
     * This could happen due to any one of the following
     * reasons.
     *   1. NAT has released the binding because of the
     *      underlying session exceeding the timeout constraint
     *      of NAT.
     *   2. CPE could be target of a stray packet. Filter out
     *      the unwelcome packet.
     *   3. The system ran out of resources when trying to
     *      create a W2L or LOCAL type of binding above
     *      (i.e) the packet could have been forwarded to
     *      a LAN host/CPE thru' port forwarding or
     *      tunneled to a DMZ host.
     */
    return (NAT_PACKET_UNKNOWN);
  }



  /*
   * Protocol specific handling.
   */
  if (oProtocolId == IPPROTO_TCP) {
    NatUpdateTcpFlags(pxNatEntry, (TCPHDR*) pvProtocolHdr, NAT_DIR_W2L);

    NatHandleTcpMss(pxNat, (TCPHDR*) pvProtocolHdr, hData);
  }

  /*
   * Reinitialize timer.
   */
  pxNatEntry->dwLastUsed = NetGlobalTimerGet();

  switch (pxNatEntry->eType) {

    /*************************
     * Local Binding
     ************************/
    case NAT_BINDING_LOCAL:
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "NatHandleTURx(): Found Local Binding\n");*/
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "NatHandleTURx(): Found Local Binding");
      }
      return (NAT_TO_CPE);


    /*************************
     * LAN to WAN Binding
     ************************/
    case NAT_BINDING_L2W:
      if (NatIsTransPortInRange(wDstPort) == FALSE) {
        return(NAT_PACKET_UNKNOWN);
      }

      xOrig.dwPort = wDstPort;
      xMod.dwPort = pxNatEntry->u.xTUMapping.wLanPort;

      TRANSPORT_SET_DST_PORT(pvProtocolHdr, pxNatEntry->u.xTUMapping.wLanPort);
      break;


    /*************************
     * WAN to LAN Binding
     ************************/
    case NAT_BINDING_W2L:
      /*
       * Only the destination address in the IP header changes
       * in this case. The instances of dynamic port forwarding
       * are faked to look like L2W bindings.
       *
       * Port substitution is needed for some dynamically forwarded
       * entries (like uPnP).
       */
      xOrig.dwPort = wDstPort;
      xMod.dwPort = pxNatEntry->u.xTUMapping.wLanPort;

      TRANSPORT_SET_DST_PORT(pvProtocolHdr, pxNatEntry->u.xTUMapping.wLanPort);
      break;


    /*************************
     * default
     ************************/
    default:
      return(NAT_PACKET_UNKNOWN);
  }


  /*
   * Only W2L and L2W bindings get this far.
   */


  /**************************************************************
   * Check for any registered ALGs.
   * If any ALG is registered, invoke the ALG processing function.
   * If the ALG modifies a packet, recompute the transport
   * header checksum completely. Otherwise, checksum adjustment
   * will be used.
   *************************************************************/
  {
    NAT_ALG* pxNatAlg;
    LONG lReturn;

    if ((pxNatAlg = NatFindAlg(pxNat, wSrcPort, wDstPort)) != NULL) {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "NatHandleTURx(): Found ALG  srcP = %d  dstP = %d\n",
          wSrcPort, wDstPort);*/
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "NatHandleTURx(): Found ALG  srcP = ", wSrcPort,
                            ", dstP = ", wDstPort);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }

      lReturn = (pxNatAlg->pfnAlgProcess)(pxNat,
                                          pxNetPacket,
                                          pxNetPacketAccess,
                                          hData,
                                          pvProtocolHdr,
                                          pxNatEntry,
                      TRANSPORT_GET_DST_PORT(pvProtocolHdr),
                                          NAT_DIR_W2L);


      if (lReturn < 0) {

        return (NAT_PACKET_UNKNOWN);

      } else {

        /*
         * Recompute header offsets, as packet may have been realloc'ed
         */
        pvProtocolHdr = (void*) (pxNetPacket->pxPayload->poPayload +
                                 pxNetPacketAccess->wOffset +
                                 pxNetworkId->oIpHdrLen);

        if (lReturn > 0) {
          /*
           * Do a complete checksum recalculation.
           */
          pxNetworkId->dwDstAddr = pxNatEntry->dwLanAddr;

          NatCalcTUChecksumAlg(pvProtocolHdr,
                               pxNetworkId->dwSrcAddr,
                               pxNetworkId->dwDstAddr,
                               pxNetworkId->oProtocol,
                               (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen));
          return (NAT_OK);

        }
      }
    }
  }


  /*
   * Transport layer checksum modification.
   * This is required only if the ALG handler has not
   * modified the packet.
   */
  xOrig.dwAddr = dwDstIp;
  xMod.dwAddr = pxNatEntry->dwLanAddr;

  wChecksum = (oProtocolId == IPPROTO_TCP) ?
              (TCP_GET_CHECKSUM((TCPHDR*) pvProtocolHdr)) :
              (UDP_GET_CHECKSUM((UDPHDR*) pvProtocolHdr));


  if ((oProtocolId != IPPROTO_UDP) || (wChecksum != 0)) {
    /*
     * UDP checksum 0 means checksum is not used.
     */
    wChecksum = NatChecksumAdjust(wChecksum,
                                  (WORD*) &xOrig,
                                  sizeof(xOrig),
                                  (WORD*) &xMod,
                                  sizeof(xMod));

    (oProtocolId == IPPROTO_TCP) ?
    (TCP_SET_CHECKSUM((TCPHDR*) pvProtocolHdr, wChecksum)) :
    (UDP_SET_CHECKSUM((UDPHDR*) pvProtocolHdr, wChecksum));
  }


  /*
   * IP header changes.
   * NOTE: This information will be used to contruct the IP header
   *       and checksum will be calculated in the Ip1toN layer.
   *       So, there is no need to change the IP header in the
   *       packet right here.
   */
  pxNetworkId->dwDstAddr = pxNatEntry->dwLanAddr;


  return(NAT_OK);
}



/*****************************************************************************
Function:
        NatHandleTUTx()
Description:
        Looks for a session binding using the parameters in the
        given packet. If none found, create a binding. Perform
        the necessary address translation.
Arguments:
        NATSTATE*               pxNat                   NAT instance handle.
        NETPACKET*              pxNetPacket             Packet pointer
        NETPACKETACCESS*        pxNetPacketAccess       Packet info
        H_NETDATA               hData                   NETWORKID*
        void*                   pvProtocolHdr           Pointer to the
                                                        protocol header
                                                        (UDP/TCP)
Outputs:
        None.
Returns:
        LONG                    NAT_OUT_OF_RESOURCE     means that the
                                                        NAT module could not
                                                        create a binding
                                                        either due to port
                                                        shortage or due
                                                        running out of memory.
                                NAT_PACKET_UNKNOWN      Unrecognized packet.
                                NAT_OK                  means address
                                                        translation is
                                                        successful.
                                NAT_DO_NOTHING          The ALGs could have
                                                        freed the packet.
                                                        Instruct the calling
                                                        routine to do nothing
                                                        further with this
                                                        packet.
Revisions:
        12-Oct-2001                                     Initial
        25-Mar-2002                                     API change
*****************************************************************************/
LONG NatHandleTUTx(NATSTATE* pxNat,
                   NETPACKET *pxNetPacket,
                   NETPACKETACCESS *pxNetPacketAccess,
                   H_NETDATA hData,
                   void* pvProtocolHdr)
{
  NETWORKID *pxNetworkId = (NETWORKID*) hData;
  DWORD dwSrcIp = pxNetworkId->dwSrcAddr;
  DWORD dwDstIp = pxNetworkId->dwDstAddr;
  OCTET oProtocolId = pxNetworkId->oProtocol;
  WORD wSrcPort = TRANSPORT_GET_SRC_PORT(pvProtocolHdr);
  WORD wDstPort = TRANSPORT_GET_DST_PORT(pvProtocolHdr);
  NAT_ENTRY *pxNatEntry;
  NAT_TRANS_STRUCT xOrig, xMod;
  WORD wChecksum;
  DWORD dwTransIp;


  /*
   * Perform some size checks.
   */
  {
    WORD wHeaderSize;

    wHeaderSize = (oProtocolId == IPPROTO_TCP) ? (sizeof(TCPHDR)) : (sizeof(UDPHDR));

    if (pxNetPacket->pxPayload->wSize < (pxNetPacketAccess->wOffset + wHeaderSize)) {
      return (NAT_PACKET_UNKNOWN);
    }
  }



  /*
   * Search for a binding.
   */
  pxNatEntry = NatFindTUBindingTx(pxNat,
                                  dwSrcIp, wSrcPort,
                                  dwDstIp, wDstPort,
                                  oProtocolId);





  /*
   * TODO:
   *  What if this is a packet from a DMZ or port forwarded host
   *  which is a reply to a session initiated by the WAN, but
   *  the previously created binding was dropped due to NAT
   *  heuristics?
   *
   *  Or a local binding getting dropped?
   */

  if (pxNatEntry == NULL) {

    if ((oProtocolId == IPPROTO_UDP) ||
        (NatIsTcpSessionStart((TCPHDR*) pvProtocolHdr) == TRUE)) {

      E_NAT_BINDING eType = NAT_BINDING_L2W;
      BOOL bRandomPortBinding = NatIsRandomPortBinding(pxNat, wDstPort, oProtocolId);
      IPTABLEENTRY xIpEntry;

      /*
       * Get the translation address.
       */
      xIpEntry.dwAddr = 0x0;
      xIpEntry.eAddrType = IPADDRT_ANY;
      xIpEntry.wDefaultVlan = NETVLAN_ANY;
      xIpEntry.oIfIdx = pxNetworkId->oIfIdx;

      if ((IpTableMsg(IPTABLEMSG_GETDEFAULT, (H_NETDATA) &xIpEntry) < 0) ||
          (xIpEntry.dwAddr == 0x0)) {
        /*
         * If the translation address look up fails, still return NAT_OK.
         * This will allow packets to be sent down without translation.
         * This feature is required for PPP auto-wakeup to work.
         */
        return (NAT_OK);
      };

      dwTransIp = xIpEntry.dwAddr;


      /*
       * Determine source address type.
       */
      xIpEntry.dwAddr = dwSrcIp;
      xIpEntry.wDefaultVlan = NETVLAN_ANY;
      xIpEntry.oIfIdx = NETIFIDX_ANY;

      if (IPADDRT_MYADDR == IpTableMsg(IPTABLEMSG_GETTYPE, (H_NETDATA) &xIpEntry)) {
        eType = NAT_BINDING_LOCAL;
      }

      pxNatEntry = NatCreateBindingTU(pxNat,
                                      dwDstIp, (bRandomPortBinding == TRUE) ? (0) : (wDstPort),
                                      dwSrcIp, wSrcPort,
                                      dwTransIp, wSrcPort,
                      pxNetworkId->oIfIdx,
                                      oProtocolId,
                                      eType);
    }
  }


  if (pxNatEntry == NULL) {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
    {
      /*NAT_DBGP(DBGLVL_REPETITIVE, "NatHandleTUTx(): Out of resources\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "NatHandleTUTx(): Out of resources ");
    }
    return(NAT_OUT_OF_RESOURCE);
  }


  /*
   * Protocol specific handling.
   */
  if (oProtocolId == IPPROTO_TCP) {
    NatUpdateTcpFlags(pxNatEntry, (TCPHDR*) pvProtocolHdr, NAT_DIR_L2W);

    NatHandleTcpMss(pxNat, (TCPHDR*) pvProtocolHdr, hData);
  }

  /*
   * Reinitialize timer.
   */
  pxNatEntry->dwLastUsed = NetGlobalTimerGet();


  switch (pxNatEntry->eType) {

    /*************************
     * Local Binding
     ************************/
    case NAT_BINDING_LOCAL:
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "NatHandleTUTx(): Found Local Binding\n");*/
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "NatHandleTUTx(): Found Local Binding ");
      }
      return(NAT_OK);


    /*************************
     * LAN to WAN Binding
     ************************/
    case NAT_BINDING_L2W:
      xOrig.dwPort = (DWORD) wSrcPort;
      xMod.dwPort = (DWORD) pxNatEntry->u.xTUMapping.wTransPort;

      TRANSPORT_SET_SRC_PORT(pvProtocolHdr, pxNatEntry->u.xTUMapping.wTransPort);
      break;


    /*************************
     * WAN to LAN Binding
     ************************/
    case NAT_BINDING_W2L:
      /*
       * Only the source address in the IP header changes
       * in this case. The instances of dynamic port forwarding
       * are faked to look like L2W bindings.
       *
       *
       * Port substitution is needed for some dynamically forwarded
       * entries (like uPnP).
       */
      xOrig.dwPort = (DWORD) wSrcPort;
      xMod.dwPort = (DWORD) pxNatEntry->u.xTUMapping.wTransPort;

      TRANSPORT_SET_SRC_PORT(pvProtocolHdr, pxNatEntry->u.xTUMapping.wTransPort);
      break;


    /***************
     * default
     **************/
    default:
      return(NAT_PACKET_UNKNOWN);       /* Just to make sure that
                                           the calling routine tosses
                                           the packet. */

  }


  /**************************************************************
   * Check for any registered ALGs.
   * If any ALG is registered, invoke the ALG processing function.
   * If the ALG modifies a packet, recompute the transport
   * header checksum completely. Otherwise, checksum adjustment
   * will be used.
   *************************************************************/
  {
    NAT_ALG* pxNatAlg;
    LONG lReturn;

    if ((pxNatAlg = NatFindAlg(pxNat, wSrcPort, wDstPort)) != NULL) {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "NatHandleTUTx(): Found ALG  srcP = %d  dstP = %d\n",
          wSrcPort, wDstPort);*/
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "NatHandleTUTx(): Found ALG  srcP = ", wSrcPort,
                            ", dstP = ", wDstPort);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }

      lReturn = (pxNatAlg->pfnAlgProcess)(pxNat,
                                          pxNetPacket,
                                          pxNetPacketAccess,
                                          hData,
                                          pvProtocolHdr,
                                          pxNatEntry,
                                          wSrcPort,
                                          NAT_DIR_L2W);

      if (lReturn < 0) {

        return (NAT_PACKET_UNKNOWN);

      } else {

        /*
         * Recompute header offsets, as packet may have been realloc'ed
         */
        pvProtocolHdr = (void*) (pxNetPacket->pxPayload->poPayload +
                                 pxNetPacketAccess->wOffset);

        if (lReturn > 0) {
          /*
           * Do a complete checksum recalculation.
           */
          pxNetworkId->dwSrcAddr = pxNatEntry->dwTransAddr;

          NatCalcTUChecksumAlg(pvProtocolHdr,
                               pxNetworkId->dwSrcAddr,
                               pxNetworkId->dwDstAddr,
                               pxNetworkId->oProtocol,
                               (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen));

          return (NAT_OK);

        }
      }
    }
  }


  /*
   * Transport layer checksum modification.
   */
  xOrig.dwAddr = pxNetworkId->dwSrcAddr;
  xMod.dwAddr = pxNatEntry->dwTransAddr;

  wChecksum = (oProtocolId == IPPROTO_TCP) ?
              (TCP_GET_CHECKSUM((TCPHDR*) pvProtocolHdr)) :
              (UDP_GET_CHECKSUM((UDPHDR*) pvProtocolHdr));


  if ((oProtocolId != IPPROTO_UDP) || (wChecksum != 0)) {
    /*
     * UDP checksum 0 means checksum is not used.
     */
    wChecksum = NatChecksumAdjust(wChecksum,
                                  (WORD*) &xOrig,
                                  sizeof(xOrig),
                                  (WORD*) &xMod,
                                  sizeof(xMod));

    (oProtocolId == IPPROTO_TCP) ?
    (TCP_SET_CHECKSUM((TCPHDR*) pvProtocolHdr, wChecksum)) :
    (UDP_SET_CHECKSUM((UDPHDR*) pvProtocolHdr, wChecksum));
  }


  /*
   * IP header changes.
   * NOTE: This information will be used to contruct the IP header
   *       and checksum will be calculated in the Ip1toN layer.
   *       So, there is no need to change the IP header in the
   *       packet right here.
   */
  pxNetworkId->dwSrcAddr = pxNatEntry->dwTransAddr;

  return(NAT_OK);
}


/*****************************************************************************
Function:
        NatUpdateTcpFlags()
Description:
        Looks into a TCP packet for session specific information
        and updates some internal flags. This information is
        later used to release bindings.
Arguments:
        NAT_ENTRY*      pxNatEntry              Associated NAT binding.
        TCPHDR*         pxTcpHdr                TCP header in the packet.
        E_NAT_DIRECTION eDirection              Direction of tranfer.
                                                (to WAN or from WAN)
Outputs:
        None.
Returns:
        None.
Revisions:
        17-Oct-2001                             Initial
*****************************************************************************/
void NatUpdateTcpFlags(NAT_ENTRY* pxNatEntry,
                       TCPHDR* pxTcpHdr,
                       E_NAT_DIRECTION eDirection)
{
  WORD wNatFlags = pxNatEntry->wFlags;

  if (TCP_FLAGS_IS_RST(pxTcpHdr)) {
    wNatFlags |= (NAT_TCP_CLOSE_RECEIVE | NAT_TCP_CLOSE_SEND);
  } else {
    /*
     * IMPORTANT: This routine just looks at the FIN flags
     *            in both direction. The binding could be
     *            purged after waiting for some time once
     *            both sides have sent the FIN packet.
     *            Ideally, the acknowledgement of FIN packets
     *            in both direction should be used to
     *            signal end of a connection. But, this
     *            will require some more state information
     *            about TCP packets (like sequence number).
     */
    if (TCP_FLAGS_IS_FIN(pxTcpHdr)) {
      /*
       * The close connection in both direction should be
       * seen before a binding can be torn down. Here,
       * a notion of NAT_DIR_W2L and NAT_DIR_L2W is used to
       * track the two directions. W2L denotes WAN to LAN
       * traffic and L2W denotes LAN to WAN traffic.
       * In the flags, RECEIVE and SEND are used with
       * repsect to the WAN.
       */
      if (eDirection == NAT_DIR_W2L) {
        wNatFlags |= NAT_TCP_CLOSE_RECEIVE;
      } else {
        wNatFlags |= NAT_TCP_CLOSE_SEND;
      }
    } else {
      if (TCP_FLAGS_IS_SYN(pxTcpHdr) && (!TCP_FLAGS_IS_ACK(pxTcpHdr))) {
        wNatFlags |= NAT_TCP_OPEN_INITIATED;
        /*
         * Clear the session close flags. This is useful when
         * the NAT module has not deleted a binding but
         * the two nodes could have started reusing the
         * port for a new TCP session.
         */
        wNatFlags &= ~(NAT_TCP_CLOSE_RECEIVE | NAT_TCP_CLOSE_SEND);
      } else {
        if (TCP_FLAGS_IS_SYN(pxTcpHdr) && (TCP_FLAGS_IS_ACK(pxTcpHdr))) {
          wNatFlags |= NAT_TCP_OPEN_ACKNOWLEDGED;
          wNatFlags &= ~(NAT_TCP_CLOSE_RECEIVE | NAT_TCP_CLOSE_SEND);
        }
      }
    }
  }

  pxNatEntry->wFlags = wNatFlags;
}


/*****************************************************************************
Function:
        NatIsTcpSessionStart()
Description:
        Checks the TCP flags to see if the current packet
        starts a session.
Arguments:
        TCPHDR*         pxTcpHdr        TCP header in the packet.
Outputs:
        None.
Returns:
        BOOL            TRUE            If the current packet
                                        starts a session.
                        FALSE           Otherwise.
Revisions:
        09-Nov-2001                     Initial
*****************************************************************************/
BOOL NatIsTcpSessionStart(TCPHDR* pxTcpHdr)
{
  if (TCP_FLAGS_IS_SYN(pxTcpHdr) && (!TCP_FLAGS_IS_ACK(pxTcpHdr))) {
    return (TRUE);
  }

  return (FALSE);
}


/*****************************************************************************
Function:
        NatHandleTcpMss()
Description:
        Change MSS of a TCP session if necessary.
Arguments:
        NATSTATE*       pxNat                   NAT instance handle.
        TCPHDR*         pxTcpHdr                TCP header in the packet.
        H_NETDATA       hData                   NETWORKID*
Outputs:
        None.
Returns:
        None.
Revisions:
        27-Jan-2003                             Initial
*****************************************************************************/
void NatHandleTcpMss(NATSTATE* pxNat,
                     TCPHDR* pxTcpHdr,
                     H_NETDATA hData)
{
  OCTET oTcpHdrLen;
  NETWORKID* pxNetworkId = (NETWORKID*) hData;
  OCTET oIfIdx = pxNetworkId->oIfIdx;
  OCTET *poTcpOptions = NULL, *poTcpOptionsEnd = NULL;
  WORD wMss, wMssMax;
  BOOL bFound = FALSE;

  if (TCP_FLAGS_IS_SYN(pxTcpHdr)) {

    oTcpHdrLen = pxTcpHdr->oTcpHdrLen >> 2;
    if (oTcpHdrLen > sizeof(TCPHDR)) {

      poTcpOptions = (OCTET*) (pxTcpHdr + 1);
      poTcpOptionsEnd = ((OCTET*) pxTcpHdr + oTcpHdrLen);

      while ((bFound == FALSE) && (poTcpOptions < poTcpOptionsEnd)) {

        switch (*poTcpOptions) {

          case 0: /* End of Options - RFC 793 */
          case 1: /* NOP - RFC 793 */
            poTcpOptions ++;
            break;

          case 2: /* MSS - RFC 793 */
            poTcpOptions ++;
            bFound = TRUE;
            break;

#if 0
          case 3: /* Window scale - RFC 1323 */
            poTcpOptions ++;
            ASSERT(*poTcpOptions == 3);
            poTcpOptions += (*poTcpOptions - 1);
            break;

          case 4: /* SACK permitted - RFC 2018 */
            poTcpOptions ++;
            ASSERT(*poTcpOptions == 2);
            poTcpOptions += (*poTcpOptions - 1);
            break;

          case 8: /* Time Stamp - RFC 1323 */
            poTcpOptions ++;
            ASSERT(*poTcpOptions == 10);
            poTcpOptions += (*poTcpOptions - 1);
            break;

          case 11: /* CC - RFC 1644 */
          case 12: /* CCnew - RFC 1644 */
          case 13: /* CCecho - RFC 1644 */
            poTcpOptions ++;
            ASSERT(*poTcpOptions == 6);
            poTcpOptions += (*poTcpOptions - 1);
            break;

          default:
            ASSERT(0);
#else
          default:
            poTcpOptions ++;
            poTcpOptions += (*poTcpOptions - 1);
            break;
#endif

        }
      }

      if ((bFound == FALSE) || (poTcpOptions >= poTcpOptionsEnd))  {
        return;
      }

      ASSERT(*poTcpOptions == 4);        /* length should be 4 for MSS option */
      poTcpOptions++;

      wMss = (*poTcpOptions << 8) | (*(poTcpOptions + 1));
      wMssMax = pxNat->awMtu[oIfIdx] - sizeof(IPHDR) - sizeof(TCPHDR);

      if (wMss > wMssMax) {
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_NORMAL))
        {
          /*NAT_DBGP(DBGLVL_NORMAL, "NatHandleTcpMss(): changing MSS, srcIP=%ld.%ld.%ld.%ld  dstIP=%ld.%ld.%ld.%ld  oldMSS=%d  newMSS=%d\n",
                        IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
                        IPADDRDISPLAY(pxNetworkId->dwDstAddr),
                        wMss,
                        wMssMax);*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "NatHandleTcpMss(): changing MSS, srcIP = ", pxNetworkId->dwSrcAddr);
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", dstIP = ", pxNetworkId->dwDstAddr);
          DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ", oldMSS = ", wMss,", newMSS = ", wMssMax);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }

        *poTcpOptions = wMssMax >> 8;
        *(poTcpOptions + 1) = wMssMax & 0xff;

        NatCalcTUChecksumAlg(pxTcpHdr,
                             pxNetworkId->dwSrcAddr,
                             pxNetworkId->dwDstAddr,
                             pxNetworkId->oProtocol,
                             (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen));
      }
    }
  }
}
