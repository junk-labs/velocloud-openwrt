#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

DLLIST_ITEM *DLLIST_prepend_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem)
{
  dllitem->prev = NULL;
  dllist->cur = dllitem;
  if (dllist->head) {
    dllitem->next = dllist->head;
    dllist->head->prev = dllitem;
  } else {
    dllitem->next = NULL;
    dllist->tail = dllitem;
  }
  dllist->head = dllitem;
  dllist->count++;
  return(dllitem);
}

