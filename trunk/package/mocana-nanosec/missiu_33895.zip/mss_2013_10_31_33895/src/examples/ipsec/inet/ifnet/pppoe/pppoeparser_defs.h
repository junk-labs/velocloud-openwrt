/*
 * pppoeparser_defs.h
 *
 * PPPoE parser definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "stdlib.h"
#include "strings.h"
#include "pthread.h"
#include "sys/socket.h"
#include "netinet/in.h"
#include "netcommon.h"
#include "pppoecommon.h"
#include "pppoeparser.h"


/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * Decoding/Encoding Macros
 */
/* Get the code */
#define PPPOEHDROFFSET_CODE         1
#define PPPOEHDRGET_CODE(poPacket)                  \
  (*( ((OCTET *)poPacket) + PPPOEHDROFFSET_CODE))
#define PPPOEHDRSET_CODE(poPacket,oCode)             \
  (*( ((OCTET *)poPacket) + PPPOEHDROFFSET_CODE) = (OCTET)oCode)

/* Get the version */
#define PPPOEHDROFFSET_VERTYPE      0
#define PPPOEHDRGET_VERTYPE(poPacket)               \
  (*( ((OCTET *)poPacket) + PPPOEHDROFFSET_VERTYPE))
#define PPPOEHDRSET_VERTYPE(poPacket,oVerType)      \
  (*( ((OCTET *)poPacket) + PPPOEHDROFFSET_VERTYPE) = oVerType)

/* Get the session id */
#define PPPOEHDROFFSET_SESSIONID    2
#define PPPOEHDRGET_SESSIONID(poPacket)             \
  ntohs( ((*( ((OCTET *)poPacket) + PPPOEHDROFFSET_SESSIONID)) << 8) + \
        (*( ((OCTET *)poPacket) + PPPOEHDROFFSET_SESSIONID + 1)))
#define PPPOEHDRSET_SESSIONID(poPacket,wSessionId)  \
  do {                                              \
    WORD wnSessionId = htons(wSessionId);            \
    *( ((OCTET *)poPacket) +                        \
      PPPOEHDROFFSET_SESSIONID) =                   \
       (wnSessionId >> 8) & 0xFF;                   \
    *( ((OCTET *)poPacket) +                        \
      PPPOEHDROFFSET_SESSIONID + 1) =               \
       (wnSessionId) & 0xFF;                        \
   } while(0)

/* Get the length */
#define PPPOEHDROFFSET_LENGTH       4
#define PPPOEHDRGET_LENGTH(poPacket)                   \
  ntohs( ((*( ((OCTET *)poPacket) + PPPOEHDROFFSET_LENGTH)) << 8) + \
        (*( ((OCTET *)poPacket) + PPPOEHDROFFSET_LENGTH + 1)))
#define PPPOEHDRSET_LENGTH(poPacket,wLength)        \
  do {                                              \
    WORD wnLength = htons(wLength);                  \
    *( ((OCTET *)poPacket) +                        \
      PPPOEHDROFFSET_LENGTH) =                      \
       (wnLength >> 8) & 0xFF;                      \
    *( ((OCTET *)poPacket) +                        \
      PPPOEHDROFFSET_LENGTH + 1) =                  \
       (wnLength) & 0xFF;                           \
   } while(0)

/* Get the payload pointer */
#define PPPOEHDROFFSET_PAYLOAD      PPPOE_HDRLEN
#define PPPOEHDRGET_PAYLOADPOINTER(poPacket)        \
  (((OCTET *)poPacket) + PPPOEHDROFFSET_PAYLOAD)


/*
 * Tag types
 */
#define PPPOETAGTYPE_SERVICENAME            0x0101
#define PPPOETAGTYPE_ACNAME                 0x0102
#define PPPOETAGTYPE_HOSTUNIQ               0x0103
#define PPPOETAGTYPE_ACCOOKIE               0x0104
#define PPPOETAGTYPE_VENDORSPECIFIC         0x0105
#define PPPOETAGTYPE_RELAYSESSIONID         0x0110

#define PPPOETAGTYPE_ERROR_MIN              0x0200
#define PPPOETAGTYPE_SERVICENAMEERROR       0x0201
#define PPPOETAGTYPE_ACSYSTEMERROR          0x0202
#define PPPOETAGTYPE_GENERICERROR           0x0203
#define PPPOETAGTYPE_ENDOFLIST              0x0000


/*
 * Tag parsing macros
 */
/* Tag header length */
#define PPPOETAG_HDRLEN          4
/* Type */
#define PPPOETAGOFFSET_TYPE      0
#define PPPOETAGGET_TYPE(poTag)             \
  ntohs( ((*( ((OCTET *)poTag) + PPPOETAGOFFSET_TYPE)) << 8) + \
        (*( ((OCTET *)poTag) + PPPOETAGOFFSET_TYPE + 1)))
#define PPPOETAGSET_TYPE(poTag,wType)            \
  do {                                              \
    WORD wnType = htons(wType);                      \
    *( ((OCTET *)poTag) +                        \
      PPPOETAGOFFSET_TYPE) =                        \
       (wnType >> 8) & 0xFF;                        \
    *( ((OCTET *)poTag) +                        \
      PPPOETAGOFFSET_TYPE + 1) =                    \
       (wnType) & 0xFF;                             \
   } while(0)


/* Tag length */
#define PPPOETAGOFFSET_LENGTH    2
#define PPPOETAGGET_LENGTH(poTag)             \
  ntohs( ((*( ((OCTET *)poTag) + PPPOETAGOFFSET_LENGTH)) << 8) + \
        (*( ((OCTET *)poTag) + PPPOETAGOFFSET_LENGTH + 1)))
#define PPPOETAGSET_LENGTH(poTag,wLength)        \
  do {                                              \
    WORD wnLength = htons(wLength);                  \
    *( ((OCTET *)poTag) +                        \
      PPPOETAGOFFSET_LENGTH) =                        \
       (wnLength >> 8) & 0xFF;                      \
    *( ((OCTET *)poTag) +                        \
      PPPOETAGOFFSET_LENGTH + 1) =                    \
       (wnLength) & 0xFF;                           \
   } while(0)


/* Tag value pointer */
#define PPPOETAGOFFSET_VALUE     PPPOETAG_HDRLEN
#define PPPOETAGGET_VALUEPOINTER(poTag)        \
  (((OCTET *)poTag) + PPPOETAGOFFSET_VALUE)
