/*
 * routercfgapi.h
 *
 * Router IP filtering configuration structures for use with socket ioctl calls
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __ROUTERCFGAPI_H__
#define __ROUTERCFGAPI_H__

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * Flags used in the IP filtering entries.
 */
#define    IP_FILTERING_PROT_TCP    (1 << 0x0)
#define    IP_FILTERING_PROT_UDP    (1 << 0x1)
#define    IP_FILTERING_PROT_BOTH    (IP_FILTERING_PROT_TCP | IP_FILTERING_PROT_UDP)

/*
 * Number of IP filtering entries supported.
 */
#define IP_FILTERING_TABLE_SIZE         30


/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/
/* IP Filtering configuration */
typedef struct {
  DWORD dwIndex;        /* entry index */
  BOOL  bNullifyEntry;  /* should be set to nullify an entry */
  WORD  wFlags;         /* identifies which protocol(s) will be filtered */
  DWORD dwIp;           /* LAN IP address which should be filtered */
} ROUTERCFG_IPFILTERING;

#endif    /* __ROUTERCFGAPI_H__ */
