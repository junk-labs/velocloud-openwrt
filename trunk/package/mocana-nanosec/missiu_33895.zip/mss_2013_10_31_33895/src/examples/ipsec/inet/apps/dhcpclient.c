/*
 * dhcpclient.c
 *
 * DHCP client implementation
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "../include/ioctl.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/in.h"
#include "../include/if_dl.h"
#include "../include/if.h"
#include "../include/netselect.h"
#include "../include/sockio.h"
#include "../include/inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "netdbg.h"
#include "nettime.h"
#include "netdb.h"
#include "sockapi.h"
#include "dhcp.h"
#include "dhcpclient.h"


/****************************************************************************
 *
 * Debug
 *
 ****************************************************************************/
#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3
#ifndef NDEBUG
#define CHECKPOINT(A)  (A = __LINE__)

#define DHCP_DEBUG(level,x)  do {  \
    if (level <= g_dwDHCPDebugLevel) {  \
      x;      \
    }       \
  } while (0)
#if  0
#define DHCP_DBGP(level,fmt,args...)  do { \
  if (level <= g_dwDHCPDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)
#else
#if defined (__VXWORKS_RTOS__)
#define DHCP_DBGP
#else
#define DHCP_DBGP(level,fmt,args...)
#endif
#endif /*__ENABLE_MOCANA_DEBUG_CONSOLE__*/

/*#ifdef NETDBG_HI*/
#if defined(NETDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)
#define DHCP_DEBUGHI(level,x) do {  \
    if (level <= g_dwDHCPDebugLevel) {  \
      x;      \
    }       \
  } while (0)

#define DHCP_DBGHIP(level,fmt,args...)  do { \
  if (level <= g_dwDHCPDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

#else
#define DHCP_DEBUGHI(level,x)
#if defined (__VXWORKS_RTOS__)
#define DHCP_DBGHIP
#else
#define DHCP_DBGHIP(level,fmt,args...)
#endif
#endif

#ifndef IPADDRDISPLAY
#define IPADDRDISPLAY(a) ((a >> 24) & 0xff), ((a >> 16) & 0xff), ((a >> 8) & 0xff), (a & 0xff)
#endif

DWORD g_dwDHCPDebugLevel = NORMAL;

#else
#define CHECKPOINT(A)
#define DHCP_DEBUG(level,x)
#define DHCP_DEBUGHI(level,x)
#if defined (__VXWORKS_RTOS__)
#define DHCP_DBGP
#else
#define DHCP_DBGP(level,fmt,args...)
#endif
#define DHCP_DBGHIP
#endif



/****************************************************************************
 *
 * Local function declaration
 *
 ****************************************************************************/
LONG DHCPClientInstanceStop(DHCPCLIENT *pxDhcpClient);
LONG DHCPClientInstanceStart(DHCPCLIENT *pxDhcpClient, OCTET oIfIdx);
LONG DHCPClientInstanceRxPacket(DHCPCLIENT *pxDhcpClient);
LONG DHCPClientInstanceTxPacket(DHCPCLIENT *pxDhcpClient);
LONG DHCPSetOption(DHCP_PACKET *pDhcpPacket,
                   OCTET oOption,
                   OCTET *poOptionValue,
                   OCTET oOptionLength);
LONG DHCPCheckPacketValid(DHCPCLIENT *pxDhcpClient);
LONG DHCPClientInstanceProcessPacket(DHCPCLIENT *pxDhcpClient) ;
LONG DHCPClientInstanceBind(DHCPCLIENT *pxDhcpClient);
LONG DHCPGetOption(DHCP_PACKET *pDhcpPacket,
                   OCTET oOption,
                   OCTET *poOptionValue,
                   OCTET **ppoOptionAddress,
                   BOOL bCopy);

#ifdef DHCP_CUSTOM_OPTIONS
BOOL DHCPCheckForCustomOption(OCTET oOption, DHCPCLIENT *pxDhcpClient);
void DHCPFillCustomOptions(DHCPCLIENT *pxDhcpClient);
LONG DHCPCheckForCustomResponses(DHCPCLIENT *pxDhcpClient);
#endif /*DHCP_CUSTOM_OPTIONS */

/****************************************************************************
 *
 * Implementation
 *
 ****************************************************************************/

/*
 * DHCPClientInstanceCreate
 *  Creates a DHCP Client instance
 *
 *  Args:
 *   None
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE DHCPClientInstanceCreate(void)
{
  DHCPCLIENT *pxDhcpClient;

  pxDhcpClient = (DHCPCLIENT *)MALLOC(sizeof(DHCPCLIENT));
  MOC_MEMSET((ubyte *)pxDhcpClient, 0, sizeof(DHCPCLIENT));
  pxDhcpClient->lDhcpSock = -1;
  pxDhcpClient->dwXID = rand();
  pxDhcpClient->oState = DHCPCLIENT_CREATED;

  DHCP_DBGHIP(NORMAL,
              "DHCPClient: Client %lx created\n",
              (DWORD)pxDhcpClient);

  return (H_NETINSTANCE)pxDhcpClient;
}


/*
 * DHCPClientInstanceDestroy
 *  Destroys a DHCP Client instance
 *
 *  Args:
 *   hDhcpClient            Handle to the instance
 *
 *  Return:
 *   0
 */
LONG DHCPClientInstanceDestroy(H_NETINSTANCE hDhcpClient)
{
  DHCPCLIENT *pxDhcpClient = (DHCPCLIENT *)hDhcpClient;

  ASSERT(pxDhcpClient != NULL);

  if (pxDhcpClient != NULL) {
    DHCPClientInstanceStop(pxDhcpClient);    /* Gracefully close down the client */
    FREE(pxDhcpClient);
  }

  DHCP_DBGHIP(NORMAL,
              "DHCPClient: Client %lx destroyed\n",
              (DWORD)pxDhcpClient);

  return 0;
}


/*
 * DHCPClientInstanceMsg
 *  Send a message to a DHCP Client
 *
 *  Args:
 *   hDhcpClient            Handle to the instance
 *   oMsg                   Msg code. See netcommon.h for definition
 *   hData                  Option data
 *
 *  Return:
 *   >=0   Success
 *   <=-1  Failure
 */
LONG DHCPClientInstanceMsg(H_NETINSTANCE hDhcpClient,
                           OCTET oMsg,
                           H_NETDATA hData)
{
  LONG lReturn = NETERR_NOERR;
  DHCPCLIENT *pxDhcpClient = (DHCPCLIENT *)hDhcpClient;

  ASSERT(pxDhcpClient != NULL);

  switch(oMsg) {

  case DHCPCLIENTMSG_ENABLE:
    lReturn = DHCPClientInstanceStart(pxDhcpClient, (OCTET)hData);
    break;

  case DHCPCLIENTMSG_DISABLE:
    lReturn = DHCPClientInstanceStop(pxDhcpClient);
    break;

  default:
    lReturn = NETERR_BADVALUE;
    ASSERT(0);
  }

  return lReturn;
}


/*
 * DHCPClientInstanceStart
 *  Start a DHCP Client instance on a specific interface
 *
 *  Args:
 *   pxDhcpClient           DHCP Client instance
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   >=0   Success
 *   <=-1  Failure
 */
LONG DHCPClientInstanceStart(DHCPCLIENT *pxDhcpClient, OCTET oIfIdx)
{
  ASSERT(pxDhcpClient != NULL);

  if (pxDhcpClient->lDhcpSock != -1) {
    return NETERR_BADVALUE;
  }
  DHCP_DBGP(NORMAL,
            "DHCPClient: Starting client %lx on interface %d\n",
            (DWORD)pxDhcpClient,
            oIfIdx);

  /*
   * Open socket
   */
  if ((pxDhcpClient->lDhcpSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    DHCP_DBGHIP(ERROR, "DHCPClient: can't open socket, mn_errno=%d\n", mn_errno);
    ASSERT(0);
    return NETERR_UNKNOWN;
  }

  /*
   * Bind socket to interface
   */
  if (ioctl(pxDhcpClient->lDhcpSock, MO_SIOCIFIBIND, oIfIdx) < 0) {
    DHCP_DBGHIP(ERROR, "DHCPClient: MO_SIOCIFIBIND error, mn_errno=%d\n", mn_errno);
    close(pxDhcpClient->lDhcpSock);
    pxDhcpClient->lDhcpSock = -1;
    ASSERT(0);
    return NETERR_UNKNOWN;
  }

  /*
   * Bind socket address and port
   */
  {
    struct sockaddr_in cli_addr;

    bzero((char *) &cli_addr, sizeof(cli_addr));
    cli_addr.sin_family = AF_INET;
    cli_addr.sin_addr.s_addr = INADDR_ANY;
    cli_addr.sin_port = htons(DHCPCLIENTPORT);

    if (bind(pxDhcpClient->lDhcpSock,
             (struct sockaddr *)&cli_addr, sizeof(cli_addr)) < 0) {
      DHCP_DBGHIP(ERROR, "DHCPClient: bind error, mn_errno=%d\n", mn_errno);
      close(pxDhcpClient->lDhcpSock);
      pxDhcpClient->lDhcpSock = -1;
      ASSERT(0);
      return NETERR_UNKNOWN;
    }
  }

  /*
   * Configure socket (non-blocking)
   */
  if (ioctl(pxDhcpClient->lDhcpSock, FIONBIO, 1) < 0) {
    DHCP_DBGHIP(ERROR,
                "DHCPClient: FIONBIO error, mn_errno=%d\n",
                mn_errno);
    close(pxDhcpClient->lDhcpSock);
    pxDhcpClient->lDhcpSock = -1;
    ASSERT(0);
    return NETERR_UNKNOWN;
  }

  pxDhcpClient->oIfIdx = oIfIdx;

  /* Get the HW address of the interface */
  {
    struct ifreq xIfReq;
    bzero(&xIfReq, sizeof(struct ifreq));
    xIfReq.ifr_name[0] = oIfIdx;
    xIfReq.ifr_addr.sa_len = sizeof(struct sockaddr_dl);

    ioctl(pxDhcpClient->lDhcpSock, MO_SIOCGIFIDLADDR, &xIfReq);

    MOC_MEMCPY((ubyte *)pxDhcpClient->poHardwareAddress,
           (ubyte *)((struct sockaddr_dl *)&(xIfReq.ifr_addr))->sdl_data,
           6);
  }

  /* Get the Client ID of the interface */
  {
    struct ifconf xIfConf;
    char acCID[MAX_CID_LEN];

    bzero(&xIfConf, sizeof(struct ifconf));

    xIfConf.ifc_buf = &acCID[0];
    xIfConf.ifc_len = MAX_CID_LEN;

    ioctl(pxDhcpClient->lDhcpSock, MO_SIOCGIFICLIENTID,
          pxDhcpClient->oIfIdx, &xIfConf);

    ASSERT(xIfConf.ifc_len <= MAX_CID_LEN);

    if (pxDhcpClient->pcCustomClientId != NULL) {
      FREE(pxDhcpClient->pcCustomClientId);
      pxDhcpClient->pcCustomClientId = NULL;
    }

    if (xIfConf.ifc_len > 0) {
      pxDhcpClient->pcCustomClientId = MALLOC((xIfConf.ifc_len + 1)*
                          sizeof(char));
      MOC_MEMSET((ubyte *)pxDhcpClient->pcCustomClientId, 0,
                (xIfConf.ifc_len + 1)*sizeof(char));
      MOC_STRCBCPY(pxDhcpClient->pcCustomClientId, (MAX_CID_LEN+1),
            xIfConf.ifc_buf);
    }
  }

#ifdef DHCP_CUSTOM_OPTIONS

  /* Get pointer to DLL of custom options for the interface */
  ioctl(pxDhcpClient->lDhcpSock, MO_SIOCGIFIDHCPCUSTOMOPT,
        pxDhcpClient->oIfIdx, &pxDhcpClient->pdllCustomOptions);

#endif /*DHCP_CUSTOM_OPTIONS */

  pxDhcpClient->oState = DHCPCLIENT_INIT_STAGE;

  return NETERR_NOERR;
}


/*
 * DHCPClientInstanceStop
 *  Stops a DHCP Client instance from running
 *
 *  Args:
 *   pxDhcpClient           DHCP Client instance
 *
 *  Return:
 *   >=0   Success
 *   <=-1  Failure
 */
LONG DHCPClientInstanceStop(DHCPCLIENT *pxDhcpClient)
{
  ASSERT(pxDhcpClient != NULL);

  if (pxDhcpClient->lDhcpSock != -1) {
    close(pxDhcpClient->lDhcpSock);
    pxDhcpClient->lDhcpSock = -1;
  }

  if (pxDhcpClient->pcCustomClientId != NULL){
    FREE(pxDhcpClient->pcCustomClientId);
    pxDhcpClient->pcCustomClientId = NULL;
  }

  if (pxDhcpClient->pDhcpPacket != NULL) {
    FREE(pxDhcpClient->pDhcpPacket);
    pxDhcpClient->pDhcpPacket = NULL;
  }

  pxDhcpClient->oState = DHCPCLIENT_CREATED;

  DHCP_DBGP(NORMAL,
            "DHCPClient: Client %lx on interface %d stopped\n",
            (DWORD)pxDhcpClient,
            pxDhcpClient->oIfIdx);

  return NETERR_NOERR;
}


/*
 * DHCPClientInstanceProcess
 *  DHCP Client instance processing function
 *  (can be called infrequently - e.g. every 500ms)
 *
 *  Args:
 *   hDhcpClient             Handle on the instance
 *
 *  Return:
 *   DHCP_OK              - no error
 *   DHCP_TIMEOUT         - timeout has occurred
 *   DHCP_LEASE_EXPIRED   - the lease has expired
 *   DHCP_NACK_ERROR      - we received a NACK
 */
LONG DHCPClientInstanceProcess(H_NETINSTANCE hDhcpClient)
{
  DHCPCLIENT *pxDhcpClient = (DHCPCLIENT *)hDhcpClient;
  DWORD dwCurrTime = 0;
  LONG lReturn = DHCP_OK;

  ASSERT(pxDhcpClient != NULL);

  /* Get the current time */
  dwCurrTime = NetGetMsecTime()/1000;

  switch (pxDhcpClient->oState) {

  case DHCPCLIENT_CREATED:
    /* Do nothing, wait to be (re)started */
    break;

  case DHCPCLIENT_INIT_STAGE:
    pxDhcpClient->dwXID++;
    pxDhcpClient->dwDhcpServerIP = 0;
    pxDhcpClient->dwOfferedIP = 0;
    pxDhcpClient->dwLeaseDuration = 0;
    pxDhcpClient->dwT1Timer = 0;
    pxDhcpClient->dwT2Timer = 0;
    pxDhcpClient->dwLeaseStartTime = 0;
    pxDhcpClient->oState = DHCPCLIENT_DISCOVER_STAGE;

    /* Wait between 1 and 4s before sending first DISCOVER */
    pxDhcpClient->dwTransmitTime = dwCurrTime + RAND(1,4);
    pxDhcpClient->oRTXCount = 0;
    break;

  case DHCPCLIENT_BOUND_STAGE:
    /* Check for expiration of T1 timer */
    if ((dwCurrTime - pxDhcpClient->dwLeaseStartTime) >= pxDhcpClient->dwT1Timer) {
      pxDhcpClient->dwXID++;
      pxDhcpClient->oState = DHCPCLIENT_RENEWING_STAGE;
      pxDhcpClient->dwTransmitTime = dwCurrTime;
      pxDhcpClient->oRTXCount = 0;

      DHCP_DBGP(NORMAL,
                "DHCPClient: Client %lx T1 expired -> RENEWING\n",
                (DWORD)pxDhcpClient);
    }
    break;

  case DHCPCLIENT_RENEWING_STAGE:
    /* Check for expiration of T2 timer */
    if ((dwCurrTime - pxDhcpClient->dwLeaseStartTime) >= pxDhcpClient->dwT2Timer) {
      pxDhcpClient->dwXID++;
      pxDhcpClient->oState = DHCPCLIENT_REBINDING_STAGE;
      pxDhcpClient->dwTransmitTime = dwCurrTime;
      pxDhcpClient->oRTXCount = 0;

      DHCP_DBGP(NORMAL,
                "DHCPClient: Client %lx T2 expired -> REBINDING\n",
                (DWORD)pxDhcpClient);
    }
    break;

  case DHCPCLIENT_REBINDING_STAGE:
    /* Check for expiration of lease */
    if ((dwCurrTime - pxDhcpClient->dwLeaseStartTime) >= pxDhcpClient->dwLeaseDuration) {

      /* Lease has expired!!!
       *   Notify the network stack that the lease has expired
       */

      DHCP_DBGP(NORMAL,
                "DHCPClient: Client %lx lease expired!!\n",
                (DWORD)pxDhcpClient);

      if (pxDhcpClient->dwLeaseDuration != 0) {
        pxDhcpClient->dwLeaseDuration = 0;
        return DHCP_LEASE_EXPIRED;
      }
    }
    break;

  case DHCPCLIENT_DISCOVER_STAGE:
  case DHCPCLIENT_REQUEST_STAGE:
    if (pxDhcpClient->oState == DHCPCLIENT_DISCOVER_STAGE &&
        pxDhcpClient->oRTXCount == 5) {
      pxDhcpClient->oRTXCount++;
      return DHCP_TIMEOUT;
    }
    break;

  default:
    ASSERT(0);
  }

  /*
   * Only service socket if in RX/TX state
   */
  if (pxDhcpClient->oState == DHCPCLIENT_DISCOVER_STAGE ||
      pxDhcpClient->oState == DHCPCLIENT_REQUEST_STAGE ||
      pxDhcpClient->oState == DHCPCLIENT_RENEWING_STAGE ||
      pxDhcpClient->oState == DHCPCLIENT_REBINDING_STAGE) {

    /* Check for rx'ed packets */
    lReturn = DHCPClientInstanceRxPacket(pxDhcpClient);
    if (0 > lReturn)
      return DHCP_NACK_ERROR;

#ifdef DHCP_CUSTOM_OPTIONS
    else if (lReturn == 1)
      lReturn = DHCP_OPT_CHK_COMPLETE;
#endif /*DHCP_CUSTOM_OPTIONS */

    /* (re)transmit packet if necessary */
    if (dwCurrTime >= pxDhcpClient->dwTransmitTime) {
      DHCPClientInstanceTxPacket(pxDhcpClient);
    }
  }

  return lReturn;
}


/*
 * DHCPClientInstanceTxPacket
 *  Construct and transmit a DHCP BOOTREQUEST (client->server) message
 *
 *  Args:
 *   pxDhcpClient           DHCP Client instance
 *
 *  Return:
 *   >=0   Success
 *   <=-1  Failure
 */
LONG DHCPClientInstanceTxPacket(DHCPCLIENT *pxDhcpClient)
{
  DHCP_PACKET *pDhcpPacket;
  DWORD ipaddr;

  ASSERT(pxDhcpClient != NULL &&
         pxDhcpClient->lDhcpSock >= 0);

  /*
   * Create the packet
   */
  pxDhcpClient->pDhcpPacket = MALLOC(DHCP_PACKET_SIZE);
  MOC_MEMSET((ubyte *)pxDhcpClient->pDhcpPacket, 0, DHCP_PACKET_SIZE);
  pDhcpPacket = pxDhcpClient->pDhcpPacket;

  pDhcpPacket->XID      = pxDhcpClient->dwXID;
  pDhcpPacket->OP       = BOOTREPQUEST;
  pDhcpPacket->HTYPE    = EHERNET_HTYPE;
  pDhcpPacket->HLEN     = EHERNET_HTYPE_LEN;

  /* MAC/Hardware address */
  MOC_MEMCPY((ubyte *)pDhcpPacket->CHADDR, (ubyte *)pxDhcpClient->poHardwareAddress, 6);

  if (pxDhcpClient->oState == DHCPCLIENT_RENEWING_STAGE ||
      pxDhcpClient->oState == DHCPCLIENT_REBINDING_STAGE) {
    ipaddr = htonl(pxDhcpClient->dwOfferedIP);
    MOC_MEMCPY((ubyte *)&pDhcpPacket->CIADDR, (ubyte *)&ipaddr, 4);
  } else {
#if 0
    pDhcpPacket->FLAGS[0] = 0x80;    /* Broadcast reply */
#else
    pDhcpPacket->FLAGS[0] = 0x00;    /* Unicast reply is more compatible */
#endif
  }

  /*
   * Set DHCP options
   *    o Magic cookie
   *    o DHCP message type
   *    o Client Identifier
   *    o Lease time requested
   *    o Server IP (if REQUEST)
   *    o IP address requested (if REQUEST)
   *    o Requested items (subnet, default route, DNS, host name, domain name)
   */

  { /* Magic cookie and last option tag */
    const OCTET oCookie[] = {99,130,83,99,255};
    MOC_MEMCPY((ubyte *)pDhcpPacket->OPTIONS,(ubyte *) oCookie, 5);
  }

  { /* Message type */
    OCTET oMsgType = DHCPDISCOVER;
    if (pxDhcpClient->oState != DHCPCLIENT_DISCOVER_STAGE) oMsgType = DHCPREQUEST;
    DHCPSetOption(pDhcpPacket, OP_DHCP_MESSAGE_TYPE, &oMsgType, 1);
  }

  /* Client Identifier */
  if (pxDhcpClient->pcCustomClientId != NULL) {
    OCTET oCID[MAX_CID_LEN+1];
    int iCIDLen = strlen(pxDhcpClient->pcCustomClientId);

    oCID[0] = 0;    /* set "type" field to zero - RFC 2132 */
    MOC_MEMCPY((ubyte *)&oCID[1],(ubyte *) pxDhcpClient->pcCustomClientId, iCIDLen);
    DHCPSetOption(pDhcpPacket, OP_CLIENT_IDENTIFIER, oCID, (iCIDLen + 1));
  }
  else {
    OCTET *poMAC = pxDhcpClient->poHardwareAddress;
    OCTET oCID[8];

    oCID[0] =1;
    oCID[1] =poMAC[0];
    oCID[2] =poMAC[1];
    oCID[3] =poMAC[2];
    oCID[4] =poMAC[3];
    oCID[5] =poMAC[4];
    oCID[6] =poMAC[5];
    oCID[7] =pxDhcpClient->oIfIdx;

    DHCPSetOption(pDhcpPacket, OP_CLIENT_IDENTIFIER, oCID, 8);
  }

  { /* Lease time requested (infinite!) */
    DWORD dwLease = 0xFFFFFF;
    DHCPSetOption(pDhcpPacket, OP_LEASE, (OCTET *)&dwLease, 4);
  }

  /* Requested IP address and Server Id (if REQUEST only) */
  if (pxDhcpClient->oState == DHCPCLIENT_REQUEST_STAGE) {
    ipaddr = htonl(pxDhcpClient->dwOfferedIP);
    DHCPSetOption(pDhcpPacket, OP_REQUEST_IP_ADDRESS,
                  (char *)&ipaddr, 4);
    ipaddr = htonl(pxDhcpClient->dwDhcpServerIP);
    DHCPSetOption(pDhcpPacket, OP_SERVER_IDENTIFIER,
                  (char *)&ipaddr, 4);
  }

#ifdef DHCP_CUSTOM_OPTIONS

  /* Check if custom PARAMETER_REQUEST_LIST option has been registered
     that overloads the Mocana default */
  if (!DHCPCheckForCustomOption(OP_PARAMETER_REQUEST_LIST,
                                pxDhcpClient)) {
#endif /*DHCP_CUSTOM_OPTIONS */

  { /* Requested items
     *    1 = Subnet Mask, 3 = Default router, 6 = DNS server
     *    12 = Host Name, 15 = Domain Name
     */
    const OCTET oRequestedItems[]={1,3,6,12,15};
    DHCPSetOption(pDhcpPacket, OP_PARAMETER_REQUEST_LIST,
                  (OCTET *)&oRequestedItems,
                  sizeof(oRequestedItems));
  }

#ifdef DHCP_CUSTOM_OPTIONS

  } /* end if PARAMETER_REQUEST_LIST overload */
  DHCPFillCustomOptions(pxDhcpClient);

#endif /*DHCP_CUSTOM_OPTIONS */

  /*
   * Send the packet
   */
  {
    struct sockaddr_in server_addr;
    bzero((char *)&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(DHCPSERVERPORT);

    /* Only unicast if in RENEWING state */
    if (pxDhcpClient->oState == DHCPCLIENT_RENEWING_STAGE) {
      server_addr.sin_addr.s_addr = htonl(pxDhcpClient->dwDhcpServerIP);
    } else {
      server_addr.sin_addr.s_addr = 0xFFFFFFFF;
    }

    DHCP_DBGHIP(NORMAL,
                "DHCPClient: Client %lx sending %s packet to %ld.%ld.%ld.%ld, XID=%lu\n",
                (DWORD)pxDhcpClient,
                pxDhcpClient->oState != DHCPCLIENT_DISCOVER_STAGE?
                "REQUEST":"DISCOVER",
                IPADDRDISPLAY((DWORD)server_addr.sin_addr.s_addr),
                pxDhcpClient->dwXID);

#if 0
    if (sendto(pxDhcpClient->lDhcpSock,
               pxDhcpClient->pDhcpPacket,
               sizeof(DHCP_PACKET),
               0,
               (struct sockaddr *)&server_addr,
               sizeof(server_addr)) <= 0) {
      DHCP_DBGHIP(ERROR, "DHCPClient: sendto failed, mn_errno=%d\n", mn_errno);
      ASSERT(0);
    }
#else
    if (mn_sendto(pxDhcpClient->lDhcpSock,
               pxDhcpClient->pDhcpPacket,
               sizeof(DHCP_PACKET),
               0,
               (struct sockaddr *)&server_addr,
               sizeof(server_addr)) <= 0) {
      DHCP_DBGHIP(ERROR, "DHCPClient: sendto failed, mn_errno=%d\n", mn_errno);
      ASSERT(0);
    }
#endif
  }

  FREE(pxDhcpClient->pDhcpPacket);
  pxDhcpClient->pDhcpPacket = NULL;

  /*
   * Compute time to next retransmission
   */
  {
#define min(A,B)  ((A)>(B)?(B):(A))
    DWORD dwCurrTime = NetGetMsecTime()/1000;

    pxDhcpClient->oRTXCount++;

    switch (pxDhcpClient->oState) {
    case DHCPCLIENT_DISCOVER_STAGE:
    case DHCPCLIENT_REQUEST_STAGE:
#if defined (__VXWORKS_RTOS__)
#else
      /* Exponentially growing (max of 60s) */
      pxDhcpClient->dwTransmitTime = dwCurrTime +
        min(60, (2 * pxDhcpClient->oRTXCount) + RAND(-1,1));
#endif
      break;

    case DHCPCLIENT_RENEWING_STAGE:
      /* min(60, 0.5*(time remaining until T2 expires)) */
      pxDhcpClient->dwTransmitTime = dwCurrTime +
        min(60, (pxDhcpClient->dwLeaseStartTime + pxDhcpClient->dwT2Timer - dwCurrTime)/2);
      break;

    case DHCPCLIENT_REBINDING_STAGE:
      /* min(60, 0.5*(remaining lease time)) */
      pxDhcpClient->dwTransmitTime = dwCurrTime +
        min(60, (pxDhcpClient->dwLeaseStartTime + pxDhcpClient->dwLeaseDuration - dwCurrTime)/2);
      break;
    }
  }

  return 0;
}


/*
 * DHCPClientInstanceRxPacket
 *  Check socket and receive any DHCP BOOTREPLY (server->client) messages
 *
 *  Args:
 *   pxDhcpClient           DHCP Client instance
 *
 *  Return:
 *   >=0   Success
 *   <=-1  Failure
 */
LONG DHCPClientInstanceRxPacket(DHCPCLIENT *pxDhcpClient)
{
  LONG lReturn = 0;

  ASSERT(pxDhcpClient != NULL &&
         pxDhcpClient->lDhcpSock >= 0);

  if (pxDhcpClient->lDhcpSock >= 0) {
    LONG lLen = 1;

    pxDhcpClient->pDhcpPacket = MALLOC(DHCP_PACKET_SIZE);
    MOC_MEMSET((ubyte *)pxDhcpClient->pDhcpPacket, 0, DHCP_PACKET_SIZE);

    while (lLen >= 1 && pxDhcpClient->pDhcpPacket != NULL) {
      lLen = recvfrom(pxDhcpClient->lDhcpSock,
                      (char *)pxDhcpClient->pDhcpPacket,
                      DHCP_PACKET_SIZE,
                      0, 0, 0, NULL, NULL);
      if (lLen > 0) {
        /*
         * Check the DHCP packet is valid and is for us
         */
        if (DHCPCheckPacketValid(pxDhcpClient) == 0) {
          OCTET oBufftmp[8];

          /* Flush residual packets */
          while (recvfrom(pxDhcpClient->lDhcpSock,
                          (char *)oBufftmp,
                          8, 0, 0, 0, NULL, NULL) >= 1);

          lReturn = DHCPClientInstanceProcessPacket(pxDhcpClient);

          break;
        }
      }
    }

    FREE(pxDhcpClient->pDhcpPacket);
    pxDhcpClient->pDhcpPacket = NULL;
  }

  return lReturn;
}


/*
 * DHCPClientInstanceProcessPacket
 *  Process a received BOOTREPLY message
 *
 *  Args:
 *   pxDhcpClient           DHCP Client instance
 *
 *  Return:
 *   (1    Success + custom response check done)
 *   >=0   Success
 *   <=-1  Failure
 */
LONG DHCPClientInstanceProcessPacket(DHCPCLIENT *pxDhcpClient)
{
  OCTET oMsgType;
  DWORD dwDhcpServerIP = 0;
  LONG lReturn = 0;

  ASSERT(pxDhcpClient != NULL &&
         pxDhcpClient->pDhcpPacket != NULL);

  /* Get Message Type */
  DHCPGetOption(pxDhcpClient->pDhcpPacket, OP_DHCP_MESSAGE_TYPE,
                (OCTET *)&oMsgType, NULL, TRUE);

  /* Get DHCP Server IP */
  DHCPGetOption(pxDhcpClient->pDhcpPacket, OP_SERVER_IDENTIFIER,
                (OCTET *)&dwDhcpServerIP, NULL, TRUE);

  switch (pxDhcpClient->oState) {

  case DHCPCLIENT_DISCOVER_STAGE:
    /*
     * Expect OFFER messages only
     */
    if (oMsgType == DHCPOFFER) {
      DWORD dwLeaseDuration;

      /* Get Lease duration */
      DHCPGetOption(pxDhcpClient->pDhcpPacket, OP_LEASE,
                    (OCTET *)&dwLeaseDuration, NULL, TRUE);

      /* Offered IP address (mandatory) */
      if (pxDhcpClient->pDhcpPacket->YIADDR == 0) {
        return -1;
      }

      DHCP_DBGHIP(NORMAL,
                  "DHCPClient: Client %lx received OFFER from %ld.%ld.%ld.%ld, XID=%lu\n",
                  (DWORD)pxDhcpClient,
                  IPADDRDISPLAY(dwDhcpServerIP),
                  pxDhcpClient->pDhcpPacket->XID);

      pxDhcpClient->dwDhcpServerIP = htonl(dwDhcpServerIP);
      pxDhcpClient->dwLeaseDuration =htonl(dwLeaseDuration);
      pxDhcpClient->dwOfferedIP = htonl(pxDhcpClient->pDhcpPacket->YIADDR);

      /* Everything in OFFER looks good! Move to REQUEST state */
      pxDhcpClient->dwXID++;
      pxDhcpClient->oState = DHCPCLIENT_REQUEST_STAGE;
      pxDhcpClient->oRTXCount = 0;
      pxDhcpClient->dwTransmitTime = NetGetMsecTime()/1000;

#ifdef DHCP_CUSTOM_OPTIONS
      lReturn = DHCPCheckForCustomResponses(pxDhcpClient);
#endif /*DHCP_CUSTOM_OPTIONS */

    }
    break;

  case DHCPCLIENT_REQUEST_STAGE:
  case DHCPCLIENT_RENEWING_STAGE:
  case DHCPCLIENT_REBINDING_STAGE:
    /*
     * Expect ACK or NACK messages only
     */
    if (oMsgType == DHCPACK) {

      DHCP_DBGHIP(NORMAL,
                  "DHCPClient: Client %lx received ACK from %ld.%ld.%ld.%ld, XID=%lu\n",
                  (DWORD)pxDhcpClient,
                  IPADDRDISPLAY(dwDhcpServerIP),
                  pxDhcpClient->pDhcpPacket->XID);

      /* Start LEASE, RENEW and REBIND timers */
      pxDhcpClient->dwLeaseStartTime = NetGetMsecTime()/1000;

      pxDhcpClient->dwT1Timer = (pxDhcpClient->dwLeaseDuration / 2) +
        RAND(0,20); /* 0.5 + '20s fuzz' */
      pxDhcpClient->dwT2Timer = (pxDhcpClient->dwLeaseDuration * 7 / 8) +
        RAND(0,20); /* 0.875 + '20s fuzz' */

      if (pxDhcpClient->dwT2Timer < pxDhcpClient->dwT1Timer) {
        /* DWORD wrap around - recompute */
        pxDhcpClient->dwT2Timer = pxDhcpClient->dwT1Timer +
          (pxDhcpClient->dwT1Timer / 2) +
          (pxDhcpClient->dwT1Timer / 4) +
          RAND(0,20); /* 0.875 + '20s fuzz' */;
      }

      ASSERT(pxDhcpClient->dwT2Timer >= pxDhcpClient->dwT1Timer);

      /* Bind! */
      DHCPClientInstanceBind(pxDhcpClient);

#ifdef DHCP_CUSTOM_OPTIONS
      lReturn = DHCPCheckForCustomResponses(pxDhcpClient);
#endif /*DHCP_CUSTOM_OPTIONS */

      /* Move to BOUND state */
      pxDhcpClient->oState = DHCPCLIENT_BOUND_STAGE;

      DHCP_DBGHIP(NORMAL,
                  "DHCPClient: Client %lx bound -> BOUND\n",
                  (DWORD)pxDhcpClient);
    }

    else if (oMsgType == DHCPNAK) {
      DHCP_DBGHIP(NORMAL,
                  "DHCPClient: Client %lx received NACK from %ld.%ld.%ld.%ld, XID=%lu\n",
                  (DWORD)pxDhcpClient,
                  IPADDRDISPLAY(dwDhcpServerIP),
                  pxDhcpClient->pDhcpPacket->XID);

      return -1;
    }

    break;
  }

  return lReturn;
}


/*
 * DHCPCheckPacketValid
 *  Check the validity of a received BOOTREPLY message
 *
 *  Args:
 *   pxDhcpClient           DHCP Client instance
 *
 *  Return:
 *   >=0   Packet good
 *   <=-1  Packet bad (or not for us)
 */
LONG DHCPCheckPacketValid(DHCPCLIENT *pxDhcpClient)
{
  DHCP_PACKET *pDhcpPacket;

  ASSERT(pxDhcpClient != NULL &&
         pxDhcpClient->pDhcpPacket != NULL);

  pDhcpPacket = pxDhcpClient->pDhcpPacket;

  /* Check it is a Reply, that the XID & MAC address match, and Cookie is valid */
  if (pDhcpPacket->OP != BOOTREPLY ||
      pDhcpPacket->XID != pxDhcpClient->dwXID ||
      memcmp(pDhcpPacket->CHADDR, pxDhcpClient->poHardwareAddress, 6) != 0 ||

      /* Check the Cookie */
      pDhcpPacket->OPTIONS[0] != 99 || pDhcpPacket->OPTIONS[1] != 130 ||
      pDhcpPacket->OPTIONS[2] != 83 || pDhcpPacket->OPTIONS[3] != 99) {

    DHCP_DBGHIP(NORMAL,
                "DHCPCheckPacketValid: packet validity check failed\n");
    return -1;
  }

  return 0;
}


/*
 * DHCPSetOption
 *  Set an option in the DHCP OPTIONS field of an outgoing packet
 *
 *  Args:
 *   pDhcpPacket            Pointer to packet structure
 *   oOption                Option code to set
 *   poOptionValue          Pointer to option value to set
 *   oOptionLength          Length of option value
 *
 *  Return:
 *   >=0   Success
 *   <=-1  Failed
 */
LONG DHCPSetOption(DHCP_PACKET *pDhcpPacket,
                   OCTET oOption,
                   OCTET *poOptionValue,
                   OCTET oOptionLength)
{
  OCTET *poOptions = (OCTET *)(pDhcpPacket->OPTIONS + 4);
  int i = 0;

  /* Look for end of options tag (255) and check enough space for option */
  while (poOptions[i] != 255) {
    i+=(poOptions[i+1] + 2);
    if ((i + oOptionLength + 3) > (312 - 4)) return -1;
  }

  /* Found the last position */
  poOptions[i] = oOption;
  poOptions[i+1] = oOptionLength;
  MOC_MEMCPY((ubyte *)&poOptions[i+2],(ubyte *) poOptionValue, oOptionLength);
  /* Move last option tag */
  poOptions[i + oOptionLength + 2] = 255;

  return 0;
}


/*
 * DHCPGetOption
 *  Get an option from the DHCP OPTIONS field of a received packet
 *
 *  Args:
 *   pDhcpPacket            Pointer to packet structure
 *   oOption                Option code to retrieve
 *   poOptionValue          Pointer to location for option value
 *   ppoOptionAddress       Pointer to option location in the packet
 *   bCopy                  Whether or not to copy the option value
 *                          into poOptionValue, or to just return
 *                          the option location in ppoOptionAddress
 *
 *  Return:
 *   Length of received option value
 *   <=0  Failed
 */
LONG DHCPGetOption(DHCP_PACKET *pDhcpPacket,
                   OCTET oOption,
                   OCTET *poOptionValue,
                   OCTET **ppoOptionAddress,
                   BOOL bCopy)
{
  OCTET *poOptions = (OCTET *)(pDhcpPacket->OPTIONS + 4);
  int i = 0;

  if (!bCopy && ppoOptionAddress == NULL) {
    ASSERT(0);
    return -1;
  }

  while (i < (312 - 4)) {
    OCTET oCurrentOption = poOptions[i];
    OCTET oCurrentOptionLength = poOptions[i+1];
    OCTET *poCurrentOptionValue = &(poOptions[i+2]);

    if (oCurrentOption == 255) break;     /* last option */
    if (oCurrentOption == 0) {
      i++;
      continue;
    }

    if (oCurrentOption == oOption) {
      /* Found it */
      if (bCopy) {
        MOC_MEMCPY((ubyte *)poOptionValue,(ubyte *) poCurrentOptionValue, oCurrentOptionLength);
      } else {
        ASSERT(ppoOptionAddress != NULL);
        *ppoOptionAddress = poCurrentOptionValue;
      }
      return oCurrentOptionLength;
    }

    /* Skip to next option */
    i += (oCurrentOptionLength + 2);
  }

  /* option not found */
  if (bCopy) {
    *poOptionValue = 0;
  }

  if (!bCopy) {
    *ppoOptionAddress = NULL;
  }

  return -1;
}


/*
 * DHCPClientInstanceBind
 *  Bind an interface with DHCP received network information
 *
 *  Args:
 *   pxDhcpClient           DHCP Client instance
 *
 *  Return:
 *   >=0   Success
 *   <=-1  Failed
 */
LONG DHCPClientInstanceBind(DHCPCLIENT *pxDhcpClient)
{
  DWORD dwParameter;
  OCTET oParmLen;
  OCTET *poParm;

  ASSERT(pxDhcpClient != NULL &&
         pxDhcpClient->pDhcpPacket != NULL);
  ASSERT(pxDhcpClient->dwOfferedIP != 0);

  /*
   * Extract pertinent fields and configure the interface
   */
  if (pxDhcpClient->lDhcpSock >= 0) {

    struct ifreq xIfReq;
    struct ifconf xIfConf;

    DHCP_DBGP(NORMAL,
              "DHCPClient: Client %lx binding information\n",
              (DWORD)pxDhcpClient);

    xIfReq.ifr_name[0] = pxDhcpClient->oIfIdx;

    /* Display lease information */
    DHCP_DBGP(NORMAL,"  IP Address : %ld.%ld.%ld.%ld\n  Lease duration  : %ldh:%ldm:%lds (%lus)\n  Renewal timeout : %ldh:%ldm:%lds (%lus)\n",
              IPADDRDISPLAY(pxDhcpClient->dwOfferedIP),
              (pxDhcpClient->dwLeaseDuration)/3600,
              (pxDhcpClient->dwLeaseDuration/60)%60,
              (pxDhcpClient->dwLeaseDuration)%60,
              pxDhcpClient->dwLeaseDuration,
              (pxDhcpClient->dwT1Timer)/3600,
              (pxDhcpClient->dwT1Timer/60)%60,
              (pxDhcpClient->dwT1Timer)%60,
              pxDhcpClient->dwT1Timer);

    /* Set the DNS server address */
    if (-1 != DHCPGetOption(pxDhcpClient->pDhcpPacket, OP_DNS_SERVER, (OCTET *)&dwParameter, NULL, TRUE)) {
      dwParameter = htonl(dwParameter);

      DHCP_DBGP(NORMAL,"  DNS server : %ld.%ld.%ld.%ld\n",
              IPADDRDISPLAY(dwParameter));
      ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr = htonl(dwParameter);
      ioctl(pxDhcpClient->lDhcpSock, MO_SIOCSIFIDNS, &xIfReq);
    }

    /* Set the host name */
    oParmLen = (OCTET)DHCPGetOption(pxDhcpClient->pDhcpPacket, OP_HOST_NAME,
                                    NULL, &poParm, FALSE);
    if (oParmLen && poParm != NULL) {
      xIfConf.ifc_len = oParmLen;
      xIfConf.ifc_buf = poParm;
#if defined (__VXWORKS_RTOS__)
#else
      DEBUG({
        char poHost[oParmLen+1];

        MOC_STRCBCPY(poHost,oParmLen, poParm);
        poHost[oParmLen]=0;
        DHCP_DBGP(NORMAL,"  Host name  : %s\n",poHost);
      });
#endif
      ioctl(pxDhcpClient->lDhcpSock, MO_SIOCSIFIHN, pxDhcpClient->oIfIdx, &xIfConf);
    }


    /* Set the domain name */
    oParmLen = (OCTET)DHCPGetOption(pxDhcpClient->pDhcpPacket, OP_DOMAIN_NAME,
                                    NULL, &poParm, FALSE);
    if (oParmLen != 0 && poParm != NULL) {
      xIfConf.ifc_len = oParmLen;
      xIfConf.ifc_buf = poParm;
#if defined (__VXWORKS_RTOS__)
#else
      DEBUG({
        char poDomain[oParmLen+1];

        MOC_STRCBCPY(poDomain, oParmLen, poParm);
        poDomain[oParmLen]=0;
        DHCP_DBGP(NORMAL,"  Domain name: %s\n",poDomain);
      });
#endif
      ioctl(pxDhcpClient->lDhcpSock, MO_SIOCSIFIDN, pxDhcpClient->oIfIdx, &xIfConf);
    }

    /* Set the default route (gateway) */
    if (-1 != DHCPGetOption(pxDhcpClient->pDhcpPacket, OP_GATEWAY, (OCTET *)&dwParameter, NULL, TRUE)) {
      dwParameter = htonl(dwParameter);
      DHCP_DBGP(NORMAL,"  Gateway IP : %ld.%ld.%ld.%ld\n",
              IPADDRDISPLAY(dwParameter));
      ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr = htonl(dwParameter);
      ioctl(pxDhcpClient->lDhcpSock, MO_SIOCSIFIGWADDR, &xIfReq);
    }

    /* Set the IP address to bring the interface up */
    ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr = (pxDhcpClient->dwOfferedIP);
    ioctl(pxDhcpClient->lDhcpSock, MO_SIOCSIFIADDR, &(xIfReq));

    /* Set the subnet mask */
    if (-1 != DHCPGetOption(pxDhcpClient->pDhcpPacket, OP_SUBNET_MASK, (OCTET *)&dwParameter, NULL, TRUE)) {
      dwParameter = htonl(dwParameter);
      DHCP_DBGP(NORMAL,"  Subnet Mask: %ld.%ld.%ld.%ld\n",
              IPADDRDISPLAY(dwParameter));
      ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr = htonl(dwParameter);
      ioctl(pxDhcpClient->lDhcpSock, MO_SIOCSIFINETMASK, &xIfReq);
    }
  }

  else {
    return -1;
  }

  return 0;
}

#ifdef DHCP_CUSTOM_OPTIONS

/*
 * DHCPFillCustomOptions
 *  Add any extra/custom dhcp options to outgoing packet
 *
 *  Args:
 *   pxDhcpClient           DHCP Client instance
 *
 *  Return:
 *   None
 */
void DHCPFillCustomOptions(DHCPCLIENT *pxDhcpClient)
{
  DHCP_CUSTOM_OPTION* pxCustomOption = NULL;
  DLLIST *pdllCustomOptions = pxDhcpClient->pdllCustomOptions;
  OCTET oPktType;

  oPktType = DHCP_CPT_DISCOVERY;
  if (pxDhcpClient->oState != DHCPCLIENT_DISCOVER_STAGE) oPktType = DHCP_CPT_REQUEST;

  /* check if there are custom options */
  if (pdllCustomOptions) {

    DLLIST_head(pdllCustomOptions);

    /* search custom option DLL for custom options and add to outgoing packet */
    while ((pxCustomOption = (DHCP_CUSTOM_OPTION *)DLLIST_read(pdllCustomOptions)) != NULL) {
      /* check DHCP packet type */
      if (pxCustomOption->oPktType & oPktType) {
        DHCP_DBGP(NORMAL, "DHCPClient: [%d] Custom option to send: %d\n",
                  pxDhcpClient->oIfIdx,
                  pxCustomOption->oCustomOption);
        DHCPSetOption(pxDhcpClient->pDhcpPacket,
                      pxCustomOption->oCustomOption,
                      pxCustomOption->poCustomOptionBuf,
                      pxCustomOption->oBufSize);
      }
      DLLIST_next(pdllCustomOptions);
    }
  }
}

/*
 * DHCPCheckForCustomOption
 *  Check response pkt for registered custom option responses
 *
 *  Args:
 *   pxDhcpClient           DHCP client instance
 *
 *  Return:
 *   1   check for custom option responses done
 *   0   check for custom option responses not done
 */
LONG DHCPCheckForCustomResponses(DHCPCLIENT *pxDhcpClient)
{
  DHCP_CUSTOM_OPTION* pxCustomOption = NULL;
  DLLIST *pdllCustomOptions = pxDhcpClient->pdllCustomOptions;
  OCTET aoCustomResponse[MAX_CUSTOM_RESPONSE_LEN];
  LONG lResponseLength = 0;
  OCTET oPktType;
  LONG lReturn = 0;

  oPktType = DHCP_CPT_DISCOVERY;
  if (pxDhcpClient->oState != DHCPCLIENT_DISCOVER_STAGE) oPktType = DHCP_CPT_REQUEST;

  /* check first if there are any DHCP options */
  if (pdllCustomOptions) {
    lReturn = 1;  /* a check for custom options has been done */
    DLLIST_head(pdllCustomOptions);

    /* search custom option DLL for custom options */
    while ((pxCustomOption = (DHCP_CUSTOM_OPTION *)DLLIST_read(pdllCustomOptions)) != NULL) {
      /* check for DHCP packet type */
      if ((pxCustomOption->oPktType & (oPktType | DHCP_CPT_REPORT_ONLY))) {
        /* is this response for this custom option ? */
        DHCP_DBGP(NORMAL,"DHCPClient: [%d] Check response for custom option %d\n",
                  pxDhcpClient->oIfIdx,
                  pxCustomOption->oCustomOption);
        lResponseLength = DHCPGetOption(pxDhcpClient->pDhcpPacket,
                                        pxCustomOption->oCustomOption,
                                        aoCustomResponse,
                                        NULL, TRUE);
        if (lResponseLength>0) {
          ASSERT (lResponseLength <= MAX_CUSTOM_RESPONSE_LEN);
          DHCP_DBGP(NORMAL,"DHCPClient: [%d] Custom response found: %d\n",
                    pxDhcpClient->oIfIdx,
                    pxCustomOption->oCustomOption);
          /* call registed callback function */
          if (pxCustomOption->pfnCB)
            (pxCustomOption->pfnCB)(pxCustomOption->oCustomOption,aoCustomResponse,(OCTET)lResponseLength);
        }
      }
      DLLIST_next(pdllCustomOptions);
    }
  }
  return lReturn;
}

/*
 * DHCPCheckForCustomOption
 *  Check DLL for presence of a particular custom option only
 *
 *  Args:
 *   oOption                DHCP option to search for in list
 *   pxDhcpClient           DHCP client instance
 *
 *  Return:
 *   TRUE if option found in list
 */
BOOL DHCPCheckForCustomOption(OCTET oOption, DHCPCLIENT *pxDhcpClient)
{
  DHCP_CUSTOM_OPTION* pxCustomOption = NULL;
  DLLIST *pdllCustomOptions = pxDhcpClient->pdllCustomOptions;

  /* check if there are custom options */
  if (pdllCustomOptions) {

    DLLIST_head(pdllCustomOptions);

    /* search custom option DLL for specific custom options */
    while ((pxCustomOption = (DHCP_CUSTOM_OPTION *)DLLIST_read(pdllCustomOptions)) != NULL) {
      /* check for specific option */
      if (pxCustomOption->oCustomOption == oOption) {
        DHCP_DBGP(NORMAL, "DHCPClient: [%d] Custom option check, found option: %d\n",
                  pxDhcpClient->oIfIdx,
                  pxCustomOption->oCustomOption);
        return TRUE;
      }
      DLLIST_next(pdllCustomOptions);
    }
  }
  return FALSE;
}

#endif /*DHCP_CUSTOM_OPTIONS */
