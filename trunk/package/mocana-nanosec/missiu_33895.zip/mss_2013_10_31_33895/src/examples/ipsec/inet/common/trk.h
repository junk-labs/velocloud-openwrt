/*
 * trk.h
 *
 * tracking constants and prototypes
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __TRK_H
#define __TRK_H


#include "trkdef.h"

#define TRKF_CALL    TRUE
#define TRKF_PARMS    TRUE
#define TRKF_TIME    TRUE

#define TRKS_ENTER    TRUE
#define TRKS_LEAVE    TRUE
#define TRKS_TIME    TRUE


/*
 * handles
 */
typedef OCTET H_TRK_USER;        /* registered user handle         */


/*
 * kinds of tracking storage
 */
typedef enum {
  TRK_STORAGE_MBUF,            /* a malloc'd circular buffer        */
  TRK_STORAGE_FILE,            /* a named file (not yet supported)  */
  TRK_STORAGE_STRM,            /* a VCPXI stream (not yet supported)*/

  TRK_STORAGE_ENUMMAX            /* *** must be last in enum ***      */
} E_TRK_STORAGE;



/*
 * Tracking Events, uses eventmgr.h
 *
 * event data is READ-ONLY and only valid until the event callback function
 * returns
 */
typedef enum {
  TRK_EVENT_SKIP_DONE,        /* requested # TAGs skipped, now recording   */

  TRK_EVENT_WRAP,        /* circular buffer has wrapped             */

  TRK_EVENT_RESET,        /* tracking has been reset             */

  TRK_EVENT_STARTSTOP,        /* tracking started or stopped on a track set*/
                /* event data: mask of current state (DWORD) */
                /*             0x01=>main on, 0x02=>alt on   */

  TRK_EVENT_ENUMMAX        /* *** must be LAST in enum ***             */
} E_TRK_EVENT;


/*
 * error codes
 */
typedef enum {
  TRK_ERR_OVERFLOW,        /* tracking buffer overflow, data not saved  */
                /*  in tracking buffer (AB version)         */
  TRK_ERR_MULTPILE_INIT,    /* init called more than once             */
  TRK_ERR_MEM,            /* malloc failed                 */
  TRK_ERR_DUPL_USER,        /* a duplicate Trk User has registered         */
  TRK_ERR_USER_HANDLE,        /* User not registered, or out-of-range         */
  TRK_ERR_USER,            /* User Handle exceeds TRK_USER_NBITS         */
  TRK_ERR_TAGID,        /* tag id exceeds TRK_TID_NBITS             */
  TRK_ERR_LEN,            /* length exceeds TRK_LEN_NBITS             */
  TRK_ERR_EVENT_INVALID,    /* invalid event                 */
  TRK_ERR_EVENT_MEM,        /* no memory                     */
  TRK_ERR_ENUMMAX        /* *** last in enum ***                 */

} E_ERR_TRK;

#ifndef _STOSW
/* st20cc can't handle this - thinks TRK_ERR_ENUMMAX is an undefined macro */
#if (TRK_ERR_ENUMMAX >= 32)
#  error "too many errors, need another error object"
#endif
#endif




#ifdef TRK_ON

#include "NNstyle.h"
#include <stdlib.h>
#include <stdarg.h>





/**************************************************************************
 *
 *   TYPEDEFS
 *
 *************************************************************************/

typedef WORD TRK_TAGID;
#if (TRK_TID_NBITS > 16)
#error "TAGID must be large enough to hold TRK_TID_NBITS bits"
#endif

#if defined(_VCPEX) || defined(_AUDACITY)
#define TRK_TIME vcp[riface_timer]
#else
#define TRK_TIME 0
#endif


/**************************************************************************
 *
 *   FUNCTIONAL API
 *
 * NOTE: some of these are actually macros!
 *
 *************************************************************************/


/*
 * setup and control
 */
#define TrkInitialize(eTrkStorage, vaParm) Trk0Initialize(eTrkStorage, vaParm);
#define TrkTerminate() Trk0Terminate()
#define TrkRegisterUser(eTrkUser) Trk0RegisterUser(eTrkUser)
#define TrkUnregisterUser(hTrk) Trk0UnregisterUser(hTrk)

#define TrkSetSkip(dwSkip) Trk0SetSkip(dwSkip)
#define TrkQuerySkip() Trk0QuerySkip()
#define TrkSetWrapTo(dwWrapTo) Trk0SetWrapTo(dwWrapTo)
#define TrkQueryWrapTo() Trk0QueryWrapTo()
#define TrkReset() Trk0Reset()
#define TrkSuspend(eAltOrMain) Trk0Suspend(eAltOrMain)
#define TrkResume(eAltOrMain) Trk0Resume(eAltOrMain)
#define TrkQueryActive() Trk0QueryActive()




/*
 *  General Tracking
 */

#define TrkTag(u, i, l) Trk0Tag(TRK_MAIN, (DWORD) (u),(DWORD) (i),(DWORD) (l))
#define Trk(dw)        Trk0(TRK_MAIN, (DWORD) (dw))
#define TrkMem(po,l)    Trk0Mem(TRK_MAIN, (OCTET *) (po), (int) (l))
#define TrkMemW(po,l, poT, poB)                              \
            Trk0MemW(TRK_MAIN, (OCTET *) (po), (int) (l),          \
                     (OCTET *) (poT), (OCTET *) (poB))

#define Trk2Tag(u, i, l) Trk0Tag(TRK_ALT, (DWORD) (u),(DWORD) (i),(DWORD) (l))
#define Trk2(dw)     Trk0(TRK_ALT, (DWORD) (dw))
#define Trk2Mem(po,l)     Trk0Mem(TRK_ALT, (OCTET *) (po), (int) (l))
#define Trk2MemW(po,l, poT, poB)                          \
             Trk0MemW(TRK_ALT, (OCTET *) (po), (int) (l),          \
                  (OCTET *) (poT), (OCTET *) (poB))

#define TrkFastTag(u, i, l)                              \
             TrkFast((TRK_MARK << TRK_MARK_SHIFT) |              \
                 ((u) << TRK_USER_SHIFT) |              \
                 ((i) << TRK_TID_SHIFT) |              \
                 (l))

#ifdef TRK_SUPPRESS
#include "vcpdefs.h"
#define TRK_SUPPRESS_SHORT do {                        \
      PUT_VCP_REG(riface_irqsupress, 0x0000000A);            \
      WAIT2;                            \
    } while (0)
#define TRK_SUPPRESS_LONG do {                        \
      PUT_VCP_REG(riface_irqsupress, 0x00000000);            \
      WAIT2;                            \
    } while (0)
#else
#define TRK_SUPPRESS_SHORT
#define TRK_SUPPRESS_LONG
#endif

#define TrkFast(dw)                                      \
        do {                                  \
          register PTRKVARS pT = pTrkVars;                  \
          register DWORD **ppdwNext;                      \
          ppdwNext = &(pT->pdwNext);                      \
          TRK_SUPPRESS_LONG;                          \
          (*ppdwNext) += 1;            /* pre increment */   \
          TRK_SUPPRESS_LONG;                          \
          if ((*ppdwNext) >= pT->pdwBot) {    /* check for wrap */  \
            pT->pdwNext = pT->pdwWrapTo;                  \
          } else {                              \
            pT->pdwNext = *ppdwNext;                      \
          }                                  \
          *((*ppdwNext) - 1) = (DWORD) (dw);    /* un-increment */    \
        } while (0)



/*
 * Function Tracking Calls
 *
 * (currently on main track only)
 */

#define TrkfDefs(hTk, bFa, bFp, bFt)                          \
           H_TRK_USER hTrkfUserLocal = (hTk);                      \
           int bTrkfLocal = (bFa);                          \
      int bTrkfParmsLocal = (bFp);                          \
      int bTrkfTimeLocal = (bFt);                          \

#define TrkfCall(tagid) do {                              \
      if (bTrkfLocal) {                              \
        TrkTag(hTrkfUserLocal, (tagid), -1);                  \
        if (bTrkfTimeLocal) {                          \
          Trk(TRK_TIME);                              \
        }                                      \
      }                                      \
    } while (0)

#define TrkfParm(parm) do {                              \
      if (bTrkfLocal && bTrkfParmsLocal)                      \
        Trk(parm);                                  \
    } while (0)

#define TrkfParmMem(addr, len) do {                          \
      if (bTrkfLocal && bTrkfParmsLocal)                      \
        TrkMem(addr, len);                              \
    } while (0)

#define TrkfReturn(tagid) do {                              \
      if (bTrkfLocal) {                              \
        TrkTag(hTrkfUserLocal, (tagid), -1);                  \
        if (bTrkfTimeLocal) {                          \
          Trk(vcp[riface_timer]);                          \
        }                                      \
      }                                      \
    } while (0)

#define TrkfReturnValue(tagid, value) do {                      \
      TrkfReturn(tagid);                              \
      if (bTrkfLocal && bTrkfParmsLocal) {                      \
        Trk(value);                                  \
      }                                      \
    } while (0)

#define TrkfReturnAddr(tagid, addr, len) do {                      \
      TrkfReturn(tagid);                              \
      if (bTrkfLocal && bTrkfParmsLocal) {                      \
        Trk(addr);                                  \
        TrkMem((addr), (len));                          \
      }                                      \
    } while (0)





/*
 *  FSM State Transition Tracking Calls
 *
 *  (currently on main track only)
 */


#define TrksDefs(hTk, fsmid, et, lt, bSe, bSl, bSt)                  \
           H_TRK_USER hTrksUserLocal##fsmid = (hTk);                  \
           TRK_TAGID xTrkfLocalEnterTag##fsmid = (et);                  \
           TRK_TAGID xTrkfLocalLeaveTag##fsmid = (lt);                  \
      int bTrksEnterLocal##fsmid = (bSe);                      \
      int bTrksLeaveLocal##fsmid = (bSl);                      \
      int bTrksTimeLocal##fsmid = (bSt);                      \


#define TrksEnter(fsmid, state) do {                          \
      if (bTrksEnterLocal##fsmid) {                          \
        if (bTrksTimeLocal##fsmid) {                      \
          TrkTag(hTrksUserLocal##fsmid, xTrkfLocalEnterTag##fsmid, 2);    \
          Trk(state);                              \
          Trk(TRK_TIME);                              \
        } else {                                  \
          TrkTag(hTrksUserLocal##fsmid, xTrkfLocalEnterTag##fsmid, 1);    \
          Trk(state);                              \
        }                                      \
      }                                      \
    } while (0)


#define TrksLeave(fsmid) do {                              \
      if (bTrksLeaveLocal##fsmid) {                          \
        if (bTrksTimeLocal##fsmid) {                      \
          TrkTag(hTrksUserLocal##fsmid, xTrkfLocalLeaveTag##fsmid, 1);    \
          Trk(TRK_TIME);                              \
        } else {                                  \
          TrkTag(hTrksUserLocal##fsmid, xTrkfLocalLeaveTag##fsmid, 0);    \
        }                                      \
      }                                      \
    } while (0)








/**************************************************************************
 *
 *   more TYPEDEFS, GLOBALS and PROTOTYPES
 *
 * WARNING: these are for use by Trk*() macros ONLY!
 *
 *************************************************************************/

MOC_EXTERN PTRKVARS pTrkVars;

MOC_EXTERN void Trk0Initialize(E_TRK_STORAGE, ...);
MOC_EXTERN void Trk0Terminate(void);
MOC_EXTERN H_TRK_USER Trk0RegisterUser(E_TRK_USER);
MOC_EXTERN void Trk0UnregisterUser(H_TRK_USER);

MOC_EXTERN void Trk0SetSkip(DWORD dwSkip);
MOC_EXTERN DWORD Trk0QuerySkip(void);
MOC_EXTERN void Trk0SetWrapTo(DWORD);
MOC_EXTERN DWORD Trk0QueryWrapTo(void);
MOC_EXTERN void Trk0Reset(void);
MOC_EXTERN void Trk0Suspend(E_TRK_ALT_OR_MAIN eAltOrMain);
MOC_EXTERN void Trk0Resume(E_TRK_ALT_OR_MAIN eAltOrMain);
MOC_EXTERN E_TRK_ALT_OR_MAIN Trk0QueryActive(void);

MOC_EXTERN void Trk0(DWORD, DWORD);
MOC_EXTERN void Trk0Tag(DWORD, DWORD, DWORD, DWORD);
MOC_EXTERN void Trk0Mem(DWORD, OCTET *, int);
MOC_EXTERN void Trk0MemW(DWORD, OCTET *, int, OCTET *, OCTET *);







#else /* TRK_ON is not defined */
/****************
 *
 * tracking off
 *
 ***************/
#define TrkInitialize(e, t)
#define TrkTerminate()
#define TrkRegisterUser(E_TRK_USER) ((H_TRK_USER) 0)
#define TrkUnregisterUser(u)

#define TrkSetSkip(dwSkip)
#define TrkQuerySkip() (0)
#define TrkSetWrapTo(dwWrapTo)
#define TrkQueryWrapTo() (0)
#define TrkReset()
#define TrkSuspend(eAltOrMain)
#define TrkResume(eAltOrMain)
#define TrkQueryActive() (0)

#define TrkTag(u, i, l)
#define Trk(dw)
#define TrkMem(po,l)
#define TrkMemW(po,l, poT, poB)

#define Trk2Tag(u, i, l)
#define Trk2(dw)
#define Trk2Mem(po,l)
#define Trk2MemW(po,l, poT, poB)

#define TrkFastTag(u, i, l)
#define TrkFast(dw)

#define TrkfDefs(hTk, bFa, bFp, bFt)
#define TrkfCall(tagid)
#define TrkfParm(parm)
#define TrkfParmMem(addr, len)
#define TrkfReturn(tagid)
#define TrkfReturnValue(tagid, value)
#define TrkfReturnAddr(tagid, addr, len)

#define TrksDefs(hTk, fsmid, et, lt, bSe, bSl, bSt)
#define TrksEnter(fsmid, state)
#define TrksLeave(fsmid)


#endif

#endif
