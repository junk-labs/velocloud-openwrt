/*
 * ethquery.c
 *
 * Ethernet instance query function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "eth_flavor.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "netdefs.h"
#include "ethernet.h"
#include "ethdbg.h"
#include "ethdefs.h"
#include "netsnmp.h"

/*****************************************************************************
 *
 * Implemetation
 *
 *****************************************************************************/

/*
 * EthInstanceQuery
 *  Query a ETH Instance Option
 *
 *  Args:
 *   hEth                       ETH instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceQuery(H_NETINSTANCE hEth,OCTET oOption,
                      H_NETDATA *phData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  LONG lReturn = NETERR_NOERR;

  ETH_CHECK_STATE(pxEth);
  ETH_DBGP(REPETITIVE, "EthInstanceQuery: Option: %x\n", oOption);

  switch(oOption) {
  case ETHOPTION_MACADDR:
    {
      ETHID *pxEthId = (ETHID*)phData;
      ASSERT(pxEthId->oIfIdx <= ETH_MAXNUM_IF);
      MOC_MEMCPY((ubyte *)pxEthId->aoAddr,
            (ubyte *) pxEth->aaoIfEthAddr[pxEthId->oIfIdx],
            ETHADDRESS_LEN);
    }
    break;

#ifndef NDEBUG
  case NETOPTION_MALLOC:
  case NETOPTION_FREE:
  case NETOPTION_PAYLOADMUTEX:
  case NETOPTION_OFFSET:
  case NETOPTION_TRAILER:
  case NETOPTION_NETCBK:
  case ETHOPTION_IFTOLLMAP:
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ETH_ASSERT(0);
#endif
  }

  return lReturn;
}
