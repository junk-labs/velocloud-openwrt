/*
 * snmp_tcpip_data.h
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __SNMP_TCPIP_DATA_H__
#define __SNMP_TCPIP_DATA_H__

/* interface numbering (for use in mib2's if and ifX mibs) */
/* numbers should be consecutive, starting from zero. */
#define NUM_INTERFACES         2 /* number of physical interfaces */
#define ETH_SNMP_IF_NUM        0 /* number for ethernet interface */
#define ETH2_SNMP_IF_NUM       1 /* number for ethernet interface */
#define ATM_SNMP_IF_NUM        1
#define NO_INTERFACE           0xffffffff

#define SNMP_IFDESC_LEN        30
#define NET_ADDR_LEN           6

/* Return values */
#define TCPIPSNMPGETDATAERROR  0
#define TCPIPSNMPGETDATAOK     1
/* SNMPv1+ */
#define NO_ERROR              0
#define TOO_BIG               1
#define NO_SUCH_NAME          2
#define BAD_VALUE             3
#define READ_ONLY             4
#define GEN_ERROR             5

#define LINKUPDOWNTRAPS_ENABLED         1
#define LINKUPDOWNTRAPS_DISABLED        2

#define IP_FORWARDING     1
#define IP_NOT_FORWARDING 2


/* See rfc1573 for full spec. */
typedef struct rfc1213_data {
  DWORD  sysUpTime;

  struct IF_NUM {
    OCTET  ifDescr[SNMP_IFDESC_LEN];
     /* A textual string containing information about the
     interface.  This string should include the name of the
     manufacturer, the product name and the version of the
     interface hardware/software. */

    DWORD  ifType;
     /* The type of interface.  Additional values for ifType
     are assigned by the Internet Assigned Numbers
     Authority (IANA), through updating the syntax of the
     IANAifType textual convention. */

    DWORD  ifMtu;
     /* The size of the largest packet which can be
     sent/received on the interface, specified in octets.
     For interfaces that are used for transmitting network
     datagrams, this is the size of the largest network
     datagram that can be sent on the interface. */

    DWORD  ifSpeed;
     /* An estimate of the interface's current bandwidth in
     bits per second.  For interfaces which do not vary in
     bandwidth or for those where no accurate estimation
     can be made, this object should contain the nominal
     bandwidth.  If the bandwidth of the interface is
     greater than the maximum value reportable by this
     object then this object should report its maximum
     value (4,294,967,295) and ifHighSpeed must be used to
     report the interace's speed.  For a sub-layer which
     has no concept of bandwidth, this object should be
     zero. */

    OCTET  ifPhysAddress[NET_ADDR_LEN];
     /* The interface's address at its protocol sub-layer.
     For example, for an 802.x interface, this object
     normally contains a MAC address.  The interface's
     media-specific MIB must define the bit and byte
     ordering and the format of the value of this object.
     For interfaces which do not have such an address
     (e.g., a serial line), this object should contain an
     octet string of zero length. */

    DWORD  ifAdminStatus;
     /* The desired state of the interface.  The testing(3)
     state indicates that no operational packets can be
     passed.  When a managed system initializes, all
     interfaces start with ifAdminStatus in the down(2)
     state.  As a result of either explicit management
     action or per configuration information retained by
     the managed system, ifAdminStatus is then changed to
     either the up(1) or testing(3) states (or remains in
     the down(2) state). */

    DWORD  ifOperStatus;
     /* The current operational state of the interface.  The
     testing(3) state indicates that no operational packets
     can be passed.  If ifAdminStatus is down(2) then
     ifOperStatus should be down(2).  If ifAdminStatus is
     changed to up(1) then ifOperStatus should change to
     up(1) if the interface is ready to transmit and
     receive network traffic; it should change to
     dormant(5) if the interface is waiting for external
     actions (such as a serial line waiting for an incoming
     connection); it should remain in the down(2) state if
     and only if there is a fault that prevents it from
     going to the up(1) state; it should remain in the
     notPresent(6) state if the interface has missing
     (typically, hardware) components. */

    DWORD  ifLastChange;
     /* The value of sysUpTime at the time the interface
     entered its current operational state.  If the current
     state was entered prior to the last re-initialization
     of the local network management subsystem, then this
     object contains a zero value. */

    DWORD  ifInFrames;
    DWORD  ifInOctets;
     /* The total number of octets received on the interface,
     including framing characters.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifInUcastPkts;
     /* The number of packets, delivered by this sub-layer to
     a higher (sub-)layer, which were not addressed to a
     multicast or broadcast address at this sub-layer.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifInNUcastPkts;
     /* The number of packets, delivered by this sub-layer to
     a higher (sub-)layer, which were addressed to a
     multicast or broadcast address at this sub-layer.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifInDiscards;
     /* The number of packets, delivered by this sub-layer to
     a higher (sub-)layer, which were addressed to a
     multicast or broadcast address at this sub-layer.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifInErrors;
     /* For packet-oriented interfaces, the number of inbound
     packets that contained errors preventing them from
     being deliverable to a higher-layer protocol.  For
     character-oriented or fixed-length interfaces, the
     number of inbound transmission units that contained
     errors preventing them from being deliverable to a
     higher-layer protocol.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifInUnknownProtos;
     /* For packet-oriented interfaces, the number of packets
     received via the interface which were discarded
     because of an unknown or unsupported protocol.  For
     character-oriented or fixed-length interfaces that
     support protocol multiplexing the number of
     transmission units received via the interface which
     were discarded because of an unknown or unsupported
     protocol.  For any interface that does not support
     protocol multiplexing, this counter will always be 0.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifOutFrames;
    DWORD  ifOutOctets;
     /* The total number of octets transmitted out of the
     interface, including framing characters.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifOutUcastPkts;
     /* The total number of packets that higher-level
     protocols requested be transmitted, and which were not
     addressed to a multicast or broadcast address at this
     sub-layer, including those that were discarded or not
     sent.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifOutNUcastPkts;
     /* The total number of packets that higher-level
     protocols requested be transmitted, and which were
     addressed to a multicast or broadcast address at this
     sub-layer, including those that were discarded or not
     sent.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime.
     This object is deprecated in favour of
     ifOutMulticastPkts and ifOutBroadcastPkts. */

    DWORD  ifOutDiscards;
     /* The number of outbound packets which were chosen to
     be discarded even though no errors had been detected
     to prevent their being transmitted.  One possible
     reason for discarding such a packet could be to free
     up buffer space.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifOutErrors;
     /* For packet-oriented interfaces, the number of
     outbound packets that could not be transmitted because
     of errors.  For character-oriented or fixed-length
     interfaces, the number of outbound transmission units
     that could not be transmitted because of errors.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  ifOutQLen;
     /* The length of the output packet queue (in packets). */

    DWORD  ifSpecific[15];
     /* A reference to MIB definitions specific to the
     particular media being used to realize the interface.
     It is recommended that this value point to an instance
     of a MIB object in the media-specific MIB, i.e., that
     this object have the semantics associated with the
     InstancePointer textual convention defined in RFC
     1903.  In fact, it is recommended that the media-
     specific MIB specify what value ifSpecific should/can
     take for values of ifType.  If no MIB definitions
     specific to the particular media are available, the
     value should be set to the OBJECT IDENTIFIER  0 0 . */

    OCTET  oifName[64];
     /* The textual name of the interface.  The value of this
     object should be the name of the interface as assigned
     by the local device and should be suitable for use in
     commands entered at the device's `console'.  This
     might be a text name, such as `le0' or a simple port
     number, such as `1', depending on the interface naming
     syntax of the device.  If several entries in the
     ifTable together represent a single interface as named
     by the device, then each will have the same value of
     ifName.  Note that for an agent which responds to SNMP
     queries concerning an interface on some other
     (proxied) device, then the value of ifName for such an
     interface is the proxied device's local name for it.
     If there is no local name, or this object is otherwise
     not applicable, then this object contains a zero-
     length string. */

    DWORD  dwifInMulticastPkts;
     /* The number of packets, delivered by this sub-layer to
     a higher (sub-)layer, which were addressed to a
     multicast address at this sub-layer.  For a MAC layer
     protocol, this includes both Group and Functional
     addresses.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  dwifInBroadcastPkts;
     /* The number of packets, delivered by this sub-layer to
     a higher (sub-)layer, which were addressed to a
     broadcast address at this sub-layer.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  dwifOutMulticastPkts;
     /* The total number of packets that higher-level
     protocols requested be transmitted, and which were
     addressed to a multicast address at this sub-layer,
     including those that were discarded or not sent.  For
     a MAC layer protocol, this includes both Group and
     Functional addresses.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  dwifOutBroadcastPkts;
     /* The total number of packets that higher-level
     protocols requested be transmitted, and which were
     addressed to a broadcast address at this sub-layer,
     including those that were discarded or not sent.
     Discontinuities in the value of this counter can occur
     at re-initialization of the management system, and at
     other times as indicated by the value of
     ifCounterDiscontinuityTime. */

    DWORD  dwifLinkUpDownTrapEnable;
     /* Indicates whether linkUp/linkDown traps should be
     generated for this interface.
     By default, this object should have the value
     enabled(1) for interfaces which do not operate on
     'top' of any other interface (as defined in the
     ifStackTable), and disabled(2) otherwise. */

    DWORD  dwifHighSpeed;
     /* An estimate of the interface's current bandwidth in
     units of 1,000,000 bits per second.  If this object
     reports a value of `n' then the speed of the interface
     is somewhere in the range of `n-500,000' to
     `n+499,999'.  For interfaces which do not vary in
     bandwidth or for those where no accurate estimation
     can be made, this object should contain the nominal
     bandwidth.  For a sub-layer which has no concept of
     bandwidth, this object should be zero. */

    DWORD  dwifPromiscuousMode;
     /* This object has a value of false(2) if this interface
     only accepts packets/frames that are addressed to this
     station.  This object has a value of true(1) when the
     station accepts all packets/frames transmitted on the
     media.  The value true(1) is only legal on certain
     types of media.  If legal, setting this object to a
     value of true(1) may require the interface to be reset
     before becoming effective.
     The value of ifPromiscuousMode does not affect the
     reception of broadcast and multicast packets/frames by
     the interface. */

    DWORD  dwifConnectorPresent;
     /* This object has the value 'true(1)' if the interface
     sublayer has a physical connector and the value
     'false(2)' otherwise. */

  } ifNum[NUM_INTERFACES];


  DWORD  ipForwarding;
   /* The indication of whether this entity is acting
      as an IP gateway in respect to the forwarding of
      datagrams received by, but not addressed to, this
      entity.  IP gateways forward datagrams.  IP hosts
      do not (except those source-routed via the host).
      Note that for some managed nodes, this object may
      take on only a subset of the values possible.
      Accordingly, it is appropriate for an agent to
      return a `badValue' response if a management
      station attempts to change this object to an
      inappropriate value. */

  DWORD  ipDefaultTTL;
   /* The default value inserted into the Time-To-Live
      field of the IP header of datagrams originated at
      this entity, whenever a TTL value is not supplied
      by the transport layer protocol */

  DWORD  ipInReceives;
   /* The total number of input datagrams received from
      interfaces, including those received in error. */

  DWORD  ipInHdrErrors;
   /* The number of input datagrams discarded due to
      errors in their IP headers, including bad
      checksums, version number mismatch, other format
      errors, time-to-live exceeded, errors discovered
      in processing their IP options, etc. */

  DWORD  ipInAddrErrors;
   /* The number of input datagrams discarded because
      the IP address in their IP header's destination
      field was not a valid address to be received at
      this entity.  This count includes invalid
      addresses (e.g., 0.0.0.0) and addresses of
      unsupported Classes (e.g., Class E).  For entities
      which are not IP Gateways and therefore do not
      forward datagrams, this counter includes datagrams
      discarded because the destination address was not
      a local address. */

  DWORD  ipForwDatagrams;
  /* The number of input datagrams for which this
     entity was not their final IP destination, as a
     result of which an attempt was made to find a
     route to forward them to that final destination.
     In entities which do not act as IP Gateways, this
     counter will include only those packets which were
     Source-Routed via this entity, and the Source-
     Route option processing was successful. */

  DWORD  ipInUnknownProtos;
   /* The number of locally-addressed datagrams
      received successfully but discarded because of an
      unknown or unsupported protocol. */

  DWORD  ipInDiscards;
   /* The number of input IP datagrams for which no
      problems were encountered to prevent their
      continued processing, but which were discarded
      (e.g., for lack of buffer space).  Note that this
      counter does not include any datagrams discarded
      while awaiting re-assembly. */

  DWORD  ipInDelivers;
   /* The total number of input datagrams successfully
      delivered to IP user-protocols (including ICMP). */

  DWORD  ipOutRequests;
   /* The total number of IP datagrams which local IP
      user-protocols (including ICMP) supplied to IP in
      requests for transmission.  Note that this counter
      does not include any datagrams counted in
      ipForwDatagrams. */

  DWORD  ipOutDiscards;
   /* The number of output IP datagrams for which no
      problem was encountered to prevent their
      transmission to their destination, but which were
      discarded (e.g., for lack of buffer space).  Note
      that this counter would include datagrams counted
      in ipForwDatagrams if any such packets met this
      (discretionary) discard criterion. */

  DWORD  ipOutNoroutes;
   /* The number of IP datagrams discarded because no
      route could be found to transmit them to their
      destination.  Note that this counter includes any
      packets counted in ipForwDatagrams which meet this
      `no-route' criterion.  Note that this includes any
      datagarms which a host cannot route because all of
      its default gateways are down. */

  DWORD  ipRoutingDiscards;
   /* The number of routing entries which were chosen
      to be discarded even though they are valid.  One
      possible reason for discarding such an entry could
      be to free-up buffer space for other routing
      entries. */

  DWORD  icmpInMsgs;
   /* The total number of ICMP messages which the
      entity received.  Note that this counter includes
      all those counted by icmpInErrors. */

  DWORD  icmpInErrors;
   /* The number of ICMP messages which the entity
      received but determined as having ICMP-specific
      errors (bad ICMP checksums, bad length, etc.). */

  DWORD  icmpInDestUnreachs;
   /* The number of ICMP Destination Unreachable
      messages received. */

  DWORD  icmpInTimeExcds;
   /* The number of ICMP Time Exceeded messages
      received. */

  DWORD  icmpInParmProbs;
   /* The number of ICMP Parameter Problem messages
      received. */

  DWORD  icmpInSrcQuenchs;
   /* The number of ICMP Source Quench messages
      received. */

  DWORD  icmpInRedirects;
   /* The number of ICMP Redirect messages received. */

  DWORD  icmpInEchos;
   /* The number of ICMP Echo (request) messages
      received. */

  DWORD  icmpInEchoReps;
   /* The number of ICMP Echo Reply messages received. */

  DWORD  icmpInTimestamps;
   /* The number of ICMP Timestamp (request) messages
      received. */

  DWORD  icmpInTimestampReps;
   /* The number of ICMP Timestamp Reply messages
      received. */

  DWORD  icmpInAddrMasks;
   /* The number of ICMP Address Mask Request messages
      received. */

  DWORD  icmpInAddrMaskReps;
   /* The number of ICMP Address Mask Reply messages
      received. */

  DWORD  icmpOutMsgs;
   /* The total number of ICMP messages which this
      entity attempted to send.  Note that this counter
      includes all those counted by icmpOutErrors. */

  DWORD  icmpOutErrors;
   /* The number of ICMP messages which this entity did
      not send due to problems discovered within ICMP
      such as a lack of buffers.  This value should not
      include errors discovered outside the ICMP layer
      such as the inability of IP to route the resultant
      datagram.  In some implementations there may be no
      types of error which contribute to this counter's
      value. */

  DWORD  icmpOutDestUnreachs;
   /* The number of ICMP Destination Unreachable
      messages sent. */

  DWORD  icmpOutTimeExcds;
   /* The number of ICMP Time Exceeded messages sent. */

  DWORD  icmpOutParmProbs;
   /* The number of ICMP Parameter Problem messages
      sent. */

  DWORD  icmpOutSrcQuenchs;
   /* The number of ICMP Source Quench messages sent. */

  DWORD  icmpOutRedirects;
   /* The number of ICMP Redirect messages sent.  For a
      host, this object will always be zero, since hosts
      do not send redirects. */

  DWORD  icmpOutEchos;
   /* The number of ICMP Echo (request) messages sent. */

  DWORD  icmpOutEchoReps;
   /* The number of ICMP Echo Reply messages sent. */

  DWORD  icmpOutTimestamps;
   /* The number of ICMP Timestamp (request) messages
      sent. */

  DWORD  icmpOutTimestampReps;
   /* The number of ICMP Timestamp Reply messages
      sent. */

  DWORD  icmpOutAddrMasks;
   /* The number of ICMP Address Mask Request messages
      sent. */

  DWORD  icmpOutAddrMaskReps;
   /* The number of ICMP Address Mask Reply messages
      sent. */
  DWORD  tcpRtoAlgorithm;
   /* The algorithm used to determine the timeout value
      used for retransmitting unacknowledged octets. */

  DWORD  tcpRtoMin;
   /* The minimum value permitted by a TCP
      implementation for the retransmission timeout,
      measured in milliseconds.  More refined semantics
      for objects of this type depend upon the algorithm
      used to determine the retransmission timeout.  In
      particular, when the timeout algorithm is rsre(3),
      an object of this type has the semantics of the
      LBOUND quantity described in RFC 793. */

  DWORD  tcpRtoMax;
   /* The maximum value permitted by a TCP
      implementation for the retransmission timeout,
      measured in milliseconds.  More refined semantics
      for objects of this type depend upon the algorithm
      used to determine the retransmission timeout.  In
      particular, when the timeout algorithm is rsre(3),
      an object of this type has the semantics of the
      UBOUND quantity described in RFC 793. */

  DWORD  tcpMaxConn;
  /*  The limit on the total number of TCP connections
      the entity can support.  In entities where the
      maximum number of connections is dynamic, this
      object should contain the value -1. */

  DWORD  tcpActiveOpens;
   /* The number of times TCP connections have made a
      direct transition to the SYN-SENT state from the
      CLOSED state. */

  DWORD  tcpPassiveOpens;
   /* The number of times TCP connections have made a
      direct transition to the SYN-RCVD state from the
      LISTEN state. */

  DWORD  tcpAttemptFails;
   /* The number of times TCP connections have made a
      direct transition to the CLOSED state from either
      the SYN-SENT state or the SYN-RCVD state, plus the
      number of times TCP connections have made a direct
      transition to the LISTEN state from the SYN-RCVD
      state. */

  DWORD  tcpEstabResets;
   /* The number of times TCP connections have made a
      direct transition to the CLOSED state from either
      the ESTABLISHED state or the CLOSE-WAIT state. */

  DWORD  tcpCurrEstab;
   /* The number of TCP connections for which the
      current state is either ESTABLISHED or CLOSE-
      WAIT. */

  DWORD  tcpInSegs;
   /* The total number of segments received, including
      those received in error.  This count includes
      segments received on currently established
      connections. */

  DWORD  tcpOutSegs;
   /* The total number of segments sent, including
      those on current connections but excluding those
      containing only retransmitted octets. */

  DWORD  tcpRetransSegs;
   /* The total number of segments retransmitted - that
      is, the number of TCP segments transmitted
      containing one or more previously transmitted
      octets. */

  DWORD  tcpInErrs;
   /* The total number of segments received in error
      (e.g., bad TCP checksums). */

  DWORD  tcpOutRsts;
   /* The number of TCP segments sent containing the
      RST flag. */

  DWORD  udpInDatagrams;
   /* The total number of UDP datagrams delivered to
      UDP users. */

  DWORD  udpNoPorts;
   /* The total number of received UDP datagrams for
      which there was no application at the destination
      port. */

  DWORD  udpInErrors;
   /* The number of received UDP datagrams that could
      not be delivered for reasons other than the lack
      of an application at the destination port. */

  DWORD  udpOutDatagrams;
   /* This object has the value 'true(1)' if the interface
      sublayer has a physical connector and the value
      'false(2)' otherwise. */

  DWORD  ipFragCreates;
    /*The number of IP datagram fragments that have
      been generated as a result of fragmentation at
      this entity*/

  DWORD  ipFragFails;
    /*The number of IP datagrams that have been
      discarded because they needed to be fragmented at
      this entity but could not be, e.g., because their
      Don't Fragment flag was set*/
  DWORD  ipFragOKs;
    /*The number of IP datagrams that have been
      successfully fragmented at this entity*/

  DWORD  ipReasmFails;
    /*The number of failures detected by the IP re-
      assembly algorithm (for whatever reason: timed
      out, errors, etc).  Note that this is not
      necessarily a count of discarded IP fragments
      since some algorithms (notably the algorithm in
      RFC 815) can lose track of the number of fragments
      by combining them as they are received.*/

  DWORD  ipReasmTimeout;
   /*The maximum number of seconds which received
     fragments are held while they are awaiting
     reassembly at this entity*/

  DWORD  ipReasmReqds;
   /*The number of IP fragments received which needed
     to be reassembled at this entity*/

  DWORD  ipReasmOKs;
    /*The number of IP datagrams successfully re-
      assembled.*/

} SNMP_TCPIP_DATA;

MOC_EXTERN SNMP_TCPIP_DATA xTcpipData;

#define NET_ADDR_LEN 6
#define SNMP_IFDESC_LEN        30

/* CONF_ defines*/
/* SNMPv2 additions */
#define CONF_sysORLastChange             0x00010008
#define CONF_sysORIndex                  0x00010009
#define CONF_sysORID                     0x0001000a
#define CONF_sysORDescr                  0x0001000b
#define CONF_sysORUpTime                 0x0001000c

/* SNMPv1/2 */
#define CONF_sysDesc                     0x00010100
#define CONF_sysUpTime                   0x00010101
#define CONF_sysContact                  0x00010102
#define CONF_sysName                     0x00010103
#define CONF_sysLocation                 0x00010104
#define CONF_sysServices                 0x00010105
#define SPECIAL_sysObjectId              0x00010106
#define CONF_ifDescr                     0x00020211
#define CONF_ifOperStatus                0x00020212
#define CONF_ifLastChange                0x00020213
#define CONF_ifSpecific                  0x00020214
#define CONF_ifNumber                    0x00020215
#define CONF_ifIndex                     0x00020216
#define CONF_ifPhysAddress               0x00020203
#define CONF_ifAdminStatus               0x00020204
#define CONF_ifInOctets                  0x00020205
#define CONF_ifInUcastPkts               0x00020206
#define CONF_ifInNUcastPkts              0x00020207
#define CONF_ifInDiscards                0x00020208
#define CONF_ifInErrors                  0x00020209
#define CONF_ifInUnknownProtos           0x0002020a
#define CONF_ifOutOctets                 0x0002020b
#define CONF_ifOutUcastPkts              0x0002020c
#define CONF_ifOutNUcastPkts             0x0002020d
#define CONF_ifOutDiscards               0x0002020e
#define CONF_ifOutErrors                 0x0002020f
#define CONF_ifOutQLen                   0x00020210
#define CONF_ifType                      0x00020200
#define CONF_ifMtu                       0x00020201
#define CONF_ifSpeed                     0x00020202
#define CONF_atIfIndex                   0x00020300
#define CONF_atPhysAddress               0x00020301
#define CONF_atNetAddress                0x00020302
#define CONF_ipForwarding                0x00020400
#define CONF_ipDefaultTTL                0x00020401
#define CONF_ipInReceives                0x00020402
#define CONF_ipInHdrErrors               0x00020403
#define CONF_ipInAddrErrors              0x00020404
#define CONF_ipInUnknownProtos           0x00020405
#define CONF_ipInDiscards                0x00020406
#define CONF_ipInDelivers                0x00020407
#define CONF_ipOutRequests               0x00020408
#define CONF_ipOutDiscards               0x00020409
#define CONF_ipOutNoroutes               0x0002040a
#define CONF_ipForwDatagrams             0x00020413
#define CONF_ipReasmTimeout              0x0002040c
#define CONF_ipReasmReqds                0x0002040d
#define CONF_ipReasmOKs                  0x0002040e
#define CONF_ipReasmFails                0x0002040f
#define CONF_ipFragOKs                   0x00020410
#define CONF_ipFragFails                 0x00020411
#define CONF_ipFragCreates               0x00020412
#define CONF_ipAdEntAddr                 0x00020500
#define CONF_ipAdEntIfIndex              0x00020501
#define CONF_ipAdEntNetMask              0x00020502
#define CONF_ipAdEntBcastAddr            0x00020503
#define CONF_ipRouteDest                 0x00020600
#define CONF_ipRouteIfIndex              0x00020601
#define CONF_ipRouteNetHop               0x00020602
#define CONF_ipRouteType                 0x00020603
#define CONF_ipRouteAge                  0x00020604
#define CONF_ipRouteMask                 0x00020605
#define CONF_ipNetToMediaPhysAddress     0x00020700
#define CONF_ipNetToMediaNetAddress      0x00020701
#define CONF_ipNetToMediaType            0x00020702
#define CONF_ipRoutingDiscards           0x0002040b
#define CONF_icmpInMsgs                  0x00020800
#define CONF_icmpInErrors                0x00020801
#define CONF_icmpInDestUnreachs          0x00020802
#define CONF_icmpInTimeExcds             0x00020803
#define CONF_icmpInParmProbs             0x00020804
#define CONF_icmpInSrcQuenchs            0x00020805
#define CONF_icmpInRedirects             0x00020806
#define CONF_icmpInEchos                 0x00020807
#define CONF_icmpInEchoReps              0x00020808
#define CONF_icmpInTimestamps            0x00020809
#define CONF_icmpInTimestampReps         0x0002080a
#define CONF_icmpInAddrMasks             0x0002080b
#define CONF_icmpInAddrMaskReps          0x0002080c
#define CONF_icmpOutMsgs                 0x0002080d
#define CONF_icmpOutErrors               0x0002080e
#define CONF_icmpOutDestUnreachs         0x0002080f
#define CONF_icmpOutTimeExcds            0x00020810
#define CONF_icmpOutParmProbs            0x00020811
#define CONF_icmpOutSrcQuenchs           0x00020812
#define CONF_icmpOutRedirects            0x00020813
#define CONF_icmpOutEchos                0x00020814
#define CONF_icmpOutEchoReps             0x00020815
#define CONF_icmpOutTimestamps           0x00020816
#define CONF_icmpOutTimestampReps        0x00020817
#define CONF_icmpOutAddrMasks            0x00020818
#define CONF_icmpOutAddrMaskReps         0x00020819
#define CONF_tcpActiveOpens              0x00020900
#define CONF_tcpPassiveOpens             0x00020901
#define CONF_tcpAttemptFails             0x00020902
#define CONF_tcpEstabResets              0x00020903
#define CONF_tcpCurrEstab                0x00020904
#define CONF_tcpInSegs                   0x00020905
#define CONF_tcpOutSegs                  0x00020906
#define CONF_tcpRetransSegs              0x00020907
#define CONF_tcpRtoAlgorithm             0x0002090d
#define CONF_tcpRtoMin                   0x0002090e
#define CONF_tcpRtoMax                   0x0002090a
#define CONF_tcpMaxConn                  0x0002090b
#define CONF_tcpConnState                0x00020a00
#define CONF_tcpConnLocalAddress         0x00020a01
#define CONF_tcpConnLocalPort            0x00020a02
#define CONF_tcpConnRemAddress           0x00020a03
#define CONF_tcpConnRemPort              0x00020a04
#define CONF_tcpInErrs                   0x00020908
#define CONF_tcpOutRsts                  0x00020909
#define CONF_udpInDatagrams              0x00020b00
#define CONF_udpNoPorts                  0x00020b01
#define CONF_udpInErrors                 0x00020b02
#define CONF_udpOutDatagrams             0x00020b03
#define CONF_udpLocalAddress             0x00020c00
#define CONF_udpLocalPort                0x00020c01

/* SNMPv2 extensions to interfaces group. */
#define CONF_ifName                      0x0002ff00
#define CONF_ifInMulticastPkts           0x0002ff01
#define CONF_ifInBroadcastPkts           0x0002ff02
#define CONF_ifOutMulticastPkts          0x0002ff03
#define CONF_ifOutBroadcastPkts          0x0002ff04
#define CONF_ifLinkUpDownTrapEnable      0x0002ff05
#define CONF_ifHighSpeed                 0x0002ff06
#define CONF_ifPromiscuousMode           0x0002ff07
#define CONF_ifConnectorPresent          0x0002ff08
#define CONF_ifStackHigherLayer          0x0002ff09
#define CONF_ifStackLowerLayer           0x0002ff0a
#define CONF_ifStackStatus               0x0002ff0b
#define CONF_ifRcvAddressAddress         0x0002ff0c
#define CONF_ifRcvAddressStatus          0x0002ff0d
#define CONF_ifRcvAddressType            0x0002ff0e
#define CONF_AUGMENTifIndex              0x0002ff0f
#define CONF_OUTSIDEifIndex              0x0002ff10

#define TCPIPSNMPGETDATAERROR 0
#define TCPIPSNMPGETDATAOK     1

/* This structure defines the returning ARP table. */
struct ARP_TABLE_ENTRY {
  DWORD    dwIfNos;
  OCTET    oMacAddr[NET_ADDR_LEN];
  DWORD    dwIP;
};

/* This structure defines the ipAdEntTable. */
struct ADD_ENT_TABLE_ENTRY {
  DWORD    dwIP;
  DWORD    dwIfIndex;
  DWORD    dwNetMask;
  DWORD    dwBcastAdd;
  DWORD    dwReasmMaxSize;
};

/* This structure defines the udpEntryTable. */
struct UDP_TABLE_ENTRY {
    DWORD dwIP;
    DWORD dwPort;
};

/* This structure defines the tcpConnEntryTable. */
struct TCPCONN_TABLE_ENTRY {
  DWORD    wState;
  DWORD    dwLocalIP;
  DWORD    wLocalPort;
  DWORD    dwRemoteIP;
  DWORD    wRemotePort;
};

/* This structure defines the ipNetToMediaEntryTable. */
struct NETTOMEDIA_TABLE_ENTRY {
    DWORD dwIfIndex;
    OCTET oMacAddr[NET_ADDR_LEN];
    DWORD dwIP;
    DWORD dwType;
};

struct IF_TABLE_ENTRY {
    DWORD dwIfIndex;
    OCTET oIfDescr[SNMP_IFDESC_LEN];
    DWORD dwIfType;
    DWORD dwIfMtu;
    DWORD dwIfSpeed;
    OCTET oIfPhysAddress[NET_ADDR_LEN];
    DWORD dwIfAdminStatus;
    DWORD dwIfOperStatus;
    DWORD dwIfLastChange;
    DWORD dwIfInOctets;
    DWORD dwIfInUcastPkts;
    DWORD dwIfInNUcastPkts;
    DWORD dwIfInDiscards;
    DWORD dwIfInErrors;
    DWORD dwIfInUnknownProtos;
    DWORD dwIfOutOctets;
    DWORD dwIfOutUcastPkts;
    DWORD dwIfOutNUcastPkts;
    DWORD dwIfOutDiscards;
    DWORD dwIfOutErrors;
    DWORD dwIfOutQLen;
    DWORD dwIfSpecific[15];
};

struct IFX_TABLE_ENTRY {
  OCTET oifName[64];
  DWORD dwifInMulticastPkts;
  DWORD dwifInBroadcastPkts;
  DWORD dwifOutMulticastPkts;
  DWORD dwifOutBroadcastPkts;
  /* HC objects not implemented. */
  DWORD dwifHCInOctets[2];
  DWORD dwifHCInUcastPkts[2];
  DWORD dwifHCInMulticastPkts[2];
  DWORD dwifHCInBroadcastPkts[2];
  DWORD dwifHCOutOctets[2];
  DWORD dwifHCOutUcastPkts[2];
  DWORD dwifHCOutMulticastPkts[2];
  DWORD dwifHCOutBroadcastPkts[2];
  DWORD dwifLinkUpDownTrapEnable;
  DWORD dwifHighSpeed;
  DWORD dwifPromiscuousMode;
  DWORD dwifConnectorPresent;
  /* dwifIndex is the same as in IF_TABLE_ENTRY */
  DWORD dwifIndex;
};

struct IP_ROUTE_TABLE_ENTRY {
  DWORD dwipRouteDest;
  DWORD dwipRouteIfIndex;
  DWORD dwipRouteMetric1;
  DWORD dwipRouteMetric2;
  DWORD dwipRouteMetric3;
  DWORD dwipRouteMetric4;
  DWORD dwipRouteNextHop;
  DWORD dwipRouteType;
  DWORD dwipRouteProto;
  DWORD dwipRouteAge;
  DWORD dwipRouteMask;
  DWORD dwipRouteMetric5;
  DWORD dwipRouteInfo[16];
};


#endif

