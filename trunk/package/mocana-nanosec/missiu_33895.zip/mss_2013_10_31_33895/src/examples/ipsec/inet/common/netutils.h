/*
 * netutils.h
 *
 * Network utilities API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETUTILS_H_
#define _NETUTILS_H_


/*****************************************************************************
 *
 * Macros
 *
 *****************************************************************************/
/*
 * Useful macro to return a uniform random integer between x and y
 */
#define RAND(x,y)          (((LONG)rand() % (y-x+1)) + x)

/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/

/* Multicast structure used for wrapper->network/transport
   layer configuration */
typedef struct {
  DWORD dwMulticastAddr;
  DWORD dwMulticastIf;
  OCTET oPhyIf;                         /* Physical interface reference */
  /* NOTE: Generic 0xff (any) is not valid for multicast case as oPhyIf */
} IPMCASTREQ;



/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * NetMalloc
 *  Network Malloc function.
 *  Encapsulates the stdlib malloc
 *
 *  Args:
 *   size                 size to allocate (in byte)
 *
 *  Return:
 *   void *               pointer to the allocated memory
 */
void *NetMalloc(ubyte4 size);

/*
 * NetFree
 *  Network Free function
 *  Encapsulates the stdlib free
 *
 *  Args:
 *   px                   pointer to free
 *
 *  Return:
 */
void NetFree(void *px);

/*
 * IpAddrGetMask
 *  Get the default network mask for a given address.
 *
 *  Args:
 *   dwIpAddr                   IP address
 *
 *  Return:
 *   Type of address (IN_CLASSX_NET)
 */
DWORD IpAddrGetMask(DWORD dwIpAddr);

/*
 * IpAddrGetType
 *  Identify type of address, based on its form:
 *  can only find out global broadcast, loopback
 *  multicast, and unknown
 *
 *  Args:
 *   dwIpAddr                   IP address
 *
 *  Return:
 *   Type of address (IPADDR_BROADCAST, IPADDR_MULTICAST, IPADDR_LOOPBACK,
 *   IPADDR_UNKNOWN)
 */
INT IpAddrGetType(DWORD dwIpAddr);


/*
 * IpBuildMCastEthAddr
 *  Build a multicast ethernet address from a multicast ip adress
 *
 *  Args:
 *   aoHwAddr : multicast ethernet address to be filled
 *   dwIpAddr : multicast IP address
 *
 */

void IpBuildMCastEthAddr(OCTET aoHwAddr[], DWORD dwIpAddr);

#endif /* _NETUTILS_H_ */
