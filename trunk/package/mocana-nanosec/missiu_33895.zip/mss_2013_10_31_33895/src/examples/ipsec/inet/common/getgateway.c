
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcfg.h"
#include "setupnet.h"

/*
 * SetupNetGetIfGateway
 *  Get the default gateway of an interface
 *
 *  Args:
 *   oIfIdx              Interface index
 *   pdwIPGateway        IP address to be filled up
 *
 *  Return
 *   SetupNetReturn
 */
SetupNetReturn SetupNetGetIfGateway(OCTET oIfIdx,
                                    DWORD* pdwIPGateway)
{
  int iSocket;
  struct ifreq xIfReq;
  mnIoctlArgList_t mnIoctlArgList;      
  
  xIfReq.ifr_name[0] = oIfIdx;
  
  if ((iSocket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  mnIoctlArgList.ifreq = (void *)&xIfReq;
  if (0 > ioctl(iSocket,MO_SIOCGIFIGWADDR,&mnIoctlArgList)) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  close(iSocket);
  
  *pdwIPGateway = ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr;
  
  return SETUPNET_OK;
}
