/*
 * chapclient.h
 *
 * CHAP (Challenge Handshake Authentification Protocol) client API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _CHAPCLIENT_H_
#define _CHAPCLIENT_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * CHAP options
 */
#define CHAPCLIENTOPTIONENCRYPTIONID_MD5   5

#define CHAPCLIENTOPTION_ENCRYPTION \
 (NETOPTION_MODULESPECIFICBEGIN)    /* Encryption algorithm supported.
                                       Each calls add a new one. data
                                       is CHAPCLIENTENCRYPTIONSTATE * */
#define CHAPCLIENTOPTION_NAME \
 (NETOPTION_MODULESPECIFICBEGIN + 1) /* User name. data is CHAPCLIENTCONF *.
                                        Must be a null terminated string.
                                        length must include the `0`*/
#define CHAPCLIENTOPTION_SECRET \
 (NETOPTION_MODULESPECIFICBEGIN + 2) /* Secret. data is CHAPCLIENTCONF *.
                                        Must be a null terminated string.
                                        length must include the `0`*/
#define CHAPCLIENTOPTIONMAX 3

/*
 * CHAPCLIENT specific message
 */
#define CHAPCLIENTMSG_CONFREQ \
 (NETMSG_MODULESPECIFICBEGIN)      /* Config Request. data is CHAPCLIENTCONF * */

#define CHAPCLIENTMSGMAX 1

/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/
typedef struct {
  OCTET oId;
  PFN_CRYPT_INIT pfnCryptInit;
  PFN_CRYPT_UPDATE pfnCryptUpdate;
  PFN_CRYPT_FINISH pfnCryptFinish;
} CHAPCLIENTENCRYPTIONSTATE;

typedef struct {
  OCTET *poConf;
  WORD wConfLength;
} CHAPCLIENTCONF;

/*****************************************************************************
 *
 * Function Prototypes
 *
 *****************************************************************************/

/*
 * ChapClientInitialize
 *  Initialize the CHAP library
 *
 *  Args:
 *
 *  Return:
 *    >=0
 */
LONG ChapClientInitialize(void);

/*
 * ChapClientTerminate
 *  Terminate the ChapClient library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG ChapClientTerminate(void);

/*
 * ChapClientInstanceCreate
 *  Create a CHAP instance
 *
 *  Args:
 *
 *  Return:
 *   instance handle
 */
H_NETINSTANCE ChapClientInstanceCreate(void);

/*
 * ChapClientInstanceDestroy
 *  Destroy a chap instance
 *
 *  Args:
 *   hChapClient              ChapClient instance handle
 *
 *  Return:
 *   >=0
 */
LONG ChapClientInstanceDestroy(H_NETINSTANCE hChapClient);


/*
 * ChapClientInstanceSet
 *   Set CHAP options
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceSet(H_NETINSTANCE hChapClient,OCTET oOption,
                      H_NETDATA hData);

/*
 * ChapClientInstanceQuery
 *   Query CHAP options
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     oOptio          Option code
 *     phData          data handle
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceQuery(H_NETINSTANCE hChapClient,OCTET oOption,H_NETDATA * phData);

/*
 * ChapClientInstanceMsg
 *   CHAP msg function
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceMsg(H_NETINSTANCE hChapClient,OCTET oMsg,H_NETDATA hData);

/*
 * ChapClientInstanceLLInterfaceCreate
 *   Create CHAP LL interface
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE ChapClientInstanceLLInterfaceCreate(H_NETINSTANCE hChapClient);

/*
 * ChapClientInstanceLLInterfaceDestroy
 *   Destroy CHAP LL interface
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceLLInterfaceDestroy(H_NETINSTANCE hChapClient, H_NETINTERFACE hIf);

/*
 * ChapClientInstanceLLInterfaceIoctl
 *   CHAP LL interface ioctl function
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceLLInterfaceIoctl(H_NETINSTANCE hChapClient, H_NETINTERFACE hIf,
                                    OCTET oIoctl,H_NETDATA hData);

/*
 * ChapClientInstanceRcv
 *   CHAP instance rcv
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            NETIFID *
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceRcv(H_NETINSTANCE hChapClient, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData);

/*
 * ChapClientInstanceProcess
 *   CHAP processing function
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG ChapClientInstanceProcess(H_NETINSTANCE hChapClient);


#endif /* #ifndef _CHAPCLIENT_H_ */
