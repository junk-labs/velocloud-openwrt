/*
 * netterminate.c
 *
 * Network stack terminate function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include <mqueue.h>
#include "netdb.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/if_types.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "nettime.h"
#include "iptable.h"
#include "netconfig.h"
#include "sockapi.h"
#include "nettransport.h"
#include "tcp.h"
#include "udp.h"
#include "netnetwork.h"
#include "ip.h"
#include "ip2eth.h"
#include "ethernet.h"
#include "arp.h"
#include "icmp.h"
#include "igmp.h"
#include "ip1ton.h"
#include "netmain.h"
#include "linkconf.h"
#include "netif.h"
#include "snmp_tcpip_data.h"
#include "routing_table.h"
#include "dnsapi.h"
#include "ping.h"
#ifdef NET_DSL
#include "aal5devapi.h"
#endif /*#ifdef NET_DSL*/
#include "netif_limiter.h"


/****************************************************************************
 *
 * Local functions
 *
 ****************************************************************************/

/*
 * FreeNetDrvBuffer
 *  Free a NET_DRV_BUFFER structure pointer.
 *
 */
void FreeNetDrvBuffer(void *pxBuf)
{
  NET_DRV_BUFFER *pxDrvBuf = (NET_DRV_BUFFER *)pxBuf;

  NETMAIN_ASSERT(pxDrvBuf != NULL);

  if (pxDrvBuf->poData != NULL) {
    FREE(pxDrvBuf->poData);
  }

  FREE(pxDrvBuf);

  return;
}


/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * NetTerminate
 *  Terminates the network stack
 *
 *  Args:
 *
 *  Return:
 *   TRUE - success,
 *   FALSE - error
 */
LONG  NetTerminate(void)
{
  NETWRAPPER *pxNetWrapper;
  NETWRAPPERSTATE *pxState;
  NETIFLIMITER *pxNetIfLimiter;
  LONG lRv = 0;
  RTOS_MUTEX netWrapperMutex = NULL;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
  /* Kill the  thread */
  pxState = (NETWRAPPERSTATE *)pxNetWrapper->hState;
  NETMAIN_ASSERT(pxState != NULL);
  pxState->obDone = TRUE;

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  if (pthread_join(pxState->xThread,NULL) != 0) {
    lRv = -1;
    NETMAIN_ASSERT(0);
  }

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

    /* Terminates the sockets, must happen before  NetIfTearDown */
  SocketLibraryTerminate();

  /* Free up the interfaces ressources */
#ifdef NET_MULTIF
  {
    OCTET o;

    for (o=0;o<pxNetWrapper->oIfNumber;o++) {
      NetIfTearDown(&xNetWrapper,o);
    }
  }
#else
  NetIfTearDown(&xNetWrapper,0);
#endif

  /* Free Up the main trunk modules, etc. */
  NetConfTearDown(&pxNetWrapper->xNetConf); /* Will do the close too */

  /* routing table, must occurs after NetConfTearDown */
  RoutingTableTerminate();

  IpTableTerminate();

#ifdef _ENABLE_DNS_
  DnsTerm();
#endif /* _ENABLE_DNS_ */

  pxNetIfLimiter = NETGETLIMITER(pxNetWrapper);
  NetIfLimiterTerminate(pxNetIfLimiter);

  /* Free up the internal state structure */
  clear_DLLIST(&(pxState->dllTxBuf),NULL);
  clear_DLLIST(&(pxState->dllRxBuf),FreeNetDrvBuffer);

  if (pxState->xndbTxPacket.poData != NULL) {
    FREE(pxState->xndbTxPacket.poData);
  }

  FREE(pxState);

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
  /* Destroy the mutex */
  netWrapperMutex = (RTOS_MUTEX )&pxNetWrapper->xMutex;
  RTOS_recursiveMutexFree(&netWrapperMutex);


#ifdef NET_DSL
  lRv = Aal5DevTerm();
  NETMAIN_ASSERT(lRv == 0);
#endif /*#ifdef NET_DSL*/

  return lRv;
}
