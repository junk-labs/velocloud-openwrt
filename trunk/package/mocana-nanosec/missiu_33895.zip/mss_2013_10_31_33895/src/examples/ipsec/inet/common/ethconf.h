/*
 * ethconf.h
 *
 * straight ethernet link configuration common API.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

 /****************************************************************************
 * ethconf.h
 *  straight ethernet link configuration common API.
 *  A "straight ethernet" link is:
 *
 *  _______________________________________________________
 *  | Ip2Eth           |     ARP         |     RARP       |
 *  |__________________|_________________|________________|
 *  |                          Eth                        |
 *  |_____________________________________________________|
 *
 *  Added to this basic components will be the bridge, as an option
 *  Arp and Rarp are plugged in by default, and do not need to
 *  be configured, but for the offset.
 *
 ****************************************************************************/
#ifndef _ETHCONF_H_
#define _ETHCONF_H_

/****************************************************************************
 *
 * defines
 *
 ****************************************************************************/


/****************************************************************************
 *
 * API
 *
 ****************************************************************************/

/*
 * EthConfSetup
 *  Specific setup for straight ethernet interfaces
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   NETLINKLEG
 */
LONG EthConfSetup(NETIFCONF *pxIfConf,OCTET oIfIdx);

/*
 * EthConfOpen
 *  Specific openings for straight ethernet interfaces
 *
 *  Args:
 *   pxIfConf           interface conf structure
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG EthConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx);

/*
 * EthConfProcess
 *  straight ethernet link processing
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG EthConfProcess(NETIFCONF *pxIfConf, OCTET oIfIdx);

/*
 * EthConfClose
 *  Ethernet specific if close
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return 0
 */
LONG EthConfClose(NETIFCONF *pxIfConf, OCTET oIfIdx);

/*
 * EthConfDestroy
 *  Ethernet specific if destroy
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG EthConfDestroy(NETIFCONF *pxIfConf, OCTET oIfIdx);

#endif /* #ifndef _ETHCONF_H_ */
