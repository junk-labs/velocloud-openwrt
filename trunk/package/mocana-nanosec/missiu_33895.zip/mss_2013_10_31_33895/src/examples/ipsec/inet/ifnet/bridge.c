/*
 * bridge.c
 *
 * Implementation of the bridge module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include <NNstyle.h>
#include "ethbridge_flavor.h"
#include <stdlib.h>
#include <string.h>
#include "sys/socket.h" /* NNOS ntohx, htonx defs */
#include <netinet/in.h> /* Linux ntohx, htonx defs */
#include <pthread.h>
#include <dllist.h>
#include "netcommon.h"
#include "netutils.h"
#include "netdefs.h"
#include "nettime.h"
#include "ethernet.h"
#include "bridgedbg.h"
#include "bridgedefs.h"
#include "netsnmp.h"
#include "snmp_tcpip_data.h"
#include "spanningtree.h"
#include "macfilter.h"
#include "limiter.h"
#include "meter.h"

/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/

/* Debug level can be  ERROR, NORMAL, REPETITIVE, XREPETITIVE */
ETH_DBG_VAR(DWORD g_dwEthDebugLevel = NORMAL);


/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/


/*****************************************************************************
 *
 * Local Function prototypes
 *
 *****************************************************************************/


static void _SpanningTreeReInit(ETHSTATE *pxEth);

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * EthInitialize
 *  Initialize the ETH Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG EthInitialize(void)
{
  /* Nothing to do */

  return 0;
}

/*
 * EthTerminate
 *  Terminate the ETH Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG EthTerminate(void)
{
  /* Nothing to do */

  return 0;
}


/*
 * EthInstanceCreate
 *  Creates a ETH Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE EthInstanceCreate(void)
{
  ETHSTATE *pxEth;
  INT iDx;

  pxEth = (ETHSTATE *)MALLOC(sizeof(ETHSTATE));
  if(pxEth == NULL){
    ASSERT(0);
    return (H_NETINSTANCE)NULL;
  }
  MOC_MEMSET((ubyte *)pxEth, 0, sizeof(ETHSTATE));

/* calloc takes care of these:
  pxEth->oSpecificVlanNumber = 0;
  pxEth->oNumBridgePorts = 0;
  pxEth->obSpanningEnabled = FALSE;
  pxEth->obAdmitOnlyVlan = FALSE;
  pxEth->obForwardPPPoEOnly = FALSE;
  pxEth->oLanIdx = 0;
*/

  ETH_SET_COOKIE(pxEth);

  if ((LONG)0 != MacFilterCreate()) {
    ASSERT(0);
    FREE(pxEth);
    return (H_NETINSTANCE)NULL;
  }

  if ((LONG)0 != SpanningTreeCreate((H_NETINSTANCE)pxEth)) {
    ASSERT(0);
    FREE(pxEth);
    return (H_NETINSTANCE)NULL;
  }

  for (iDx = 0; iDx < ETHBR_MAXNUM_IF; iDx ++) {
    pxEth->aeInitialPortState[iDx] = BLOCKING;
  }

  return (H_NETINSTANCE)pxEth;
}
/*
 * EthInstanceDestroy
 *  Destroy a ETH Instance
 *
 *  Args:
 *   hEth                       ETH instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceDestroy(H_NETINSTANCE hEth)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  ETH_LL *pxLl;
  ETH_UL *pxUl;
  INT iDx;

  ETH_CHECK_STATE(pxEth);

  if ((LONG)0 != SpanningTreeDestroy()) {
    ASSERT(0);
    return (LONG)NETERR_MEM;
  }

  MacFilterDestroy();

  /* Destroy all the remaining LL interfaces */
  for (iDx = 0; iDx < ETHBR_MAXNUM_IF; iDx ++) {
    pxLl = pxEth->apxIfToLlMap[iDx];
    if (pxLl != NULL) {
      FREE(pxLl);
    }
  }

  /* Destroy all the remaining UL interfaces */
  for (iDx = 0; iDx < ETH_MAXULIF; iDx ++) {
    pxUl = pxEth->apxUl[iDx];
    if (pxUl != NULL) {
      FREE(pxUl);
    }
  }

  if (pxEth->pwSpecificVlan != NULL) {
    FREE(pxEth->pwSpecificVlan);
  }

  ETH_UNSET_COOKIE(pxEth);
  FREE(pxEth);

  return 0;
}


/*
 * EthInstanceSet
 *  Set a ETH Instance Option
 *
 *  Args:
 *   hEth                       ETH instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceSet(H_NETINSTANCE hEth,OCTET oOption,
                    H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  LONG lReturn = NETERR_NOERR;

  ETH_CHECK_STATE(pxEth);

  ETH_DBGP(NORMAL,"EthInstanceSet:hEth=%d,oOption=%s,hData=%d\n",
           (int)hEth,
           ((oOption >= NETOPTION_MODULESPECIFICBEGIN) ?
           apoEthOptionString[oOption - NETOPTION_MODULESPECIFICBEGIN]:
           apoNetOptionString[oOption]),
           (int)hData);

  switch(oOption) {

  case NETOPTION_MALLOC:
    ASSERT((void*)hData != NULL);
    pxEth->pfnMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_FREE:
    ASSERT((void*)hData != NULL);
    pxEth->pfnFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    ASSERT((void*)hData != NULL);
    pxEth->pxMutex = (pthread_mutex_t*)hData;
    break;

  case NETOPTION_OFFSET:
    pxEth->wOffset = (WORD)hData;
    break;

  case NETOPTION_TRAILER:
    pxEth->wTrailer = (WORD)hData;
    break;

  case ETHOPTION_MACADDR:
    {
      ETHID *pxEthId = (ETHID*)hData;
      ASSERT(pxEthId->oIfIdx < ETHBR_MAXNUM_IF);

      MOC_MEMCPY((ubyte *)pxEth->aaoIfEthAddr[pxEthId->oIfIdx],
             (ubyte *)pxEthId->aoAddr, ETHADDRESS_LEN);
    }
    break;

  case ETHOPTION_IFTOLLMAP:
    {
      ETHIFTOLL *pIfToLl = (ETHIFTOLL *)hData;

      ASSERT(pIfToLl->oIfIdx < (OCTET) ETHBR_MAXNUM_IF);
      ASSERT(pIfToLl->hLlIf != (H_NETINTERFACE)NULL);

      ASSERT(pxEth->apxIfToLlMap[pIfToLl->oIfIdx] == NULL);
      pxEth->apxIfToLlMap[pIfToLl->oIfIdx] = (ETH_LL *)pIfToLl->hLlIf;
      /* Save the oIfIdx in the LL interface */
      pxEth->apxIfToLlMap[pIfToLl->oIfIdx]->oIfIdx = pIfToLl->oIfIdx;
    }
    break;

#ifndef NDEBUG
  case NETOPTION_NETCBK:
    break;
  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
#endif
  }

  return lReturn;
}


/*
 * EthInstanceMsg
 *  Send a msg to a ETH instance
 *
 *  Args:
 *   hEth                       ETH instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceMsg(H_NETINSTANCE hEth,OCTET oMsg,
                    H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  LONG lReturn = NETERR_NOERR;
  OCTET oIdx;

  ETH_CHECK_STATE(pxEth);

  ETH_DBGP(REPETITIVE,"EthInstanceMsg:hEth=%d,oMsg=%s,hData=%d\n",
           (int)hEth,
           ((oMsg >= NETMSG_MODULESPECIFICBEGIN) ?
           apoEthMsgString[oMsg - NETMSG_MODULESPECIFICBEGIN]:
           apoEthMsgString[oMsg]),
           (int)hData);

  switch(oMsg) {
  case ETHMSG_LOCALLOOPBACK:
    pxEth->obLocalLoopback = (OCTET)hData;
    break;

  case ETHMSG_SETLLDEFAULTVLAN:
    {
      ETHID *pxEthId = (ETHID *)hData;
      ETH_LL *pxLl;

      ASSERT(pxEthId->oIfIdx < (OCTET) ETHBR_MAXNUM_IF);

      pxLl = pxEth->apxIfToLlMap[pxEthId->oIfIdx];
      ASSERT(pxLl);
      pxLl->wDefaultVlan = pxEthId->wVlan;
      ETH_DBGP(NORMAL,"ETHMSG_SETLLDEFAULTVLAN: oIfIdx=%d wVlan=0x%04x\n",
               pxEthId->oIfIdx, pxEthId->wVlan);
    }
    break;

  case ETHMSG_ADDSPECIFICVLAN:
    /* Find an empty slot and save the Vlan in it */
    for (oIdx = 0; oIdx < pxEth->oSpecificVlanNumber; oIdx++) {
      if (pxEth->pwSpecificVlan[oIdx] == NETVLAN_DEFAULT ||
          pxEth->pwSpecificVlan[oIdx] == (WORD)hData) {
        pxEth->pwSpecificVlan[oIdx] = (WORD)hData;
        break;
      }
    }
    /* If no slot found - realloc and save Vlan in new slot */
    if (oIdx >= pxEth->oSpecificVlanNumber) {
      {
          WORD *pwTempSpecificVlan = NULL;

      pwTempSpecificVlan = (WORD *)MALLOC((pxEth->oSpecificVlanNumber+1)* sizeof(WORD));
      ASSERT(pwTempSpecificVlan);
      MOC_MEMCPY((ubyte *)pwTempSpecificVlan, (ubyte *)(pxEth->pwSpecificVlan),
            pxEth->oSpecificVlanNumber * sizeof(WORD));

      pxEth->pwSpecificVlan = (WORD *)pwTempSpecificVlan;
      pxEth->oSpecificVlanNumber++;

      }
      if (pxEth->pwSpecificVlan) {
        pxEth->pwSpecificVlan[pxEth->oSpecificVlanNumber-1] = (WORD)hData;
      } else {
        lReturn = NETERR_MEM;
      }
    }
    break;

  case ETHMSG_REMOVESPECIFICVLAN:
    ASSERT(pxEth->pwSpecificVlan);
    /* Find the Vlan and set to empty */
    for (oIdx = 0; oIdx < pxEth->oSpecificVlanNumber; oIdx++) {
      if (pxEth->pwSpecificVlan[oIdx] == (WORD)hData) {
        pxEth->pwSpecificVlan[oIdx] = NETVLAN_DEFAULT;
        break;
      }
    }
    /* If not found - return error */
    if (oIdx >= pxEth->oSpecificVlanNumber) {
      lReturn = NETERR_BADVALUE;
    }
    break;

  case ETHMSG_ENABLEBRIDGE:
  case ETHMSG_DISABLEBRIDGE:
    {
      OCTET oIfIdx = (OCTET)hData;
      ETH_LL *pxLl;

      ASSERT(oIfIdx < (OCTET) ETHBR_MAXNUM_IF);

      pxLl = pxEth->apxIfToLlMap[oIfIdx];
      ASSERT(pxLl);

      if (oMsg == ETHMSG_ENABLEBRIDGE && pxLl->obBridged != TRUE) {
        pxLl->obBridged = TRUE;
        _SpanningTreeReInit(pxEth);
      }
      else if (oMsg == ETHMSG_DISABLEBRIDGE && pxLl->obBridged == TRUE) {
        pxLl->obBridged = FALSE;
        _SpanningTreeReInit(pxEth);
      }
    }
    break;

  case ETHMSG_SETLANIF:
    ASSERT((OCTET)hData < (OCTET) ETHBR_MAXNUM_IF);
    pxEth->oLanIdx = (OCTET)hData;
    break;

  case ETHMSG_SETIFBITRATE:
    {
      ETHIFBITRATE *pxEthBitRate = (ETHIFBITRATE *)hData;
      ETH_LL *pxLl;

      ASSERT(pxEthBitRate->oIfIdx < (OCTET) ETHBR_MAXNUM_IF);

      pxLl = pxEth->apxIfToLlMap[pxEthBitRate->oIfIdx];
      ASSERT(pxLl);

      /* Limit the bitrate between 1Kbit/s and 100Mbit/s */
      if (pxEthBitRate->dwBitRate < 1 || pxEthBitRate->dwBitRate > 100000) {
        lReturn = NETERR_BADVALUE;
        break;
      }
      /* If the bitrate has changed
       * update it and, update the limits */
      if (pxLl->dwBitRate != pxEthBitRate->dwBitRate) {
        pxLl->dwBitRate = pxEthBitRate->dwBitRate;
        pxLl->dwBcastLimit = (10 * (DWORD)(pxLl->oBcastPercent) * pxLl->dwBitRate) >> 3;
        pxLl->dwMcastLimit = (10 * (DWORD)(pxLl->oMcastPercent) * pxLl->dwBitRate) >> 3;
        if (pxLl->obOpen == TRUE && pxLl->obBridged == TRUE &&
            pxEth->obSpanningEnabled) {
          SpanningTreeSetPathCost(pxLl->oPortNo, pxEthBitRate->dwBitRate);
        }
      }
    }
    break;

  case ETHMSG_SETIFBCASTLIMIT:
  case ETHMSG_SETIFMCASTLIMIT:
    {
      ETHIFLIMIT *pxEthLimit = (ETHIFLIMIT *)hData;
      ETH_LL *pxLl;

      ASSERT(pxEthLimit->oIfIdx < (OCTET) ETHBR_MAXNUM_IF);

      pxLl = pxEth->apxIfToLlMap[pxEthLimit->oIfIdx];
      ASSERT(pxLl);

      if (pxEthLimit->oPercent < 1 || pxEthLimit->oPercent > 100) {
        ETH_DBGP(ERROR,"ETHMSG_SETIFXCASTLIMIT: The value of %d%% is outside the range:1-100%%\n",
                 pxEthLimit->oPercent);
        lReturn = NETERR_BADVALUE;
        break;
      }

      /* Convert the percentage into Bytes/s */
      /* Limit Bytes/s = (10 * (Limit %) * (connection rate kbit/s)) / 8 */
      if (oMsg == ETHMSG_SETIFBCASTLIMIT) {
        pxLl->oBcastPercent = pxEthLimit->oPercent;
        pxLl->dwBcastLimit = (10 * (DWORD)(pxEthLimit->oPercent) * pxLl->dwBitRate) >> 3;
        ETH_DBGP(NORMAL,"ETHMSG_SETIFBCASTLIMIT: oIfIdx=%d dwBcastLimit=%ld Bytes/sec\n",
               pxEthLimit->oIfIdx, pxLl->dwBcastLimit);
      } else {
        pxLl->oMcastPercent = pxEthLimit->oPercent;
        pxLl->dwMcastLimit = (10 * (DWORD)(pxEthLimit->oPercent) * pxLl->dwBitRate) >> 3;
        ETH_DBGP(NORMAL,"ETHMSG_SETIFMCASTLIMIT: oIfIdx=%d dwMcastLimit=%ld Bytes/sec\n",
               pxEthLimit->oIfIdx, pxLl->dwMcastLimit);
      }
    }
    break;

  case ETHMSG_GETIFSTATE:
    {
      ETHIFSTATE *pxState = (ETHIFSTATE *)hData;
      ETH_LL *pxLl;

      ASSERT(pxState->oIfIdx < (OCTET) ETHBR_MAXNUM_IF);

      pxLl = pxEth->apxIfToLlMap[pxState->oIfIdx];
      if (pxLl == NULL){
        lReturn = NETERR_BADVALUE;
      } else if (pxLl->obBridged == TRUE) {
        pxState->eState = (E_ETHIFSTAT)ST_PORT_STATE(pxLl->oPortNo);
      } else {
        lReturn = NETERR_BADVALUE;
      }
      ETH_DBGP(REPETITIVE,"ETHMSG_GETIFSTATE: oIfIdx=%d, State=%d, Error=%ld\n",
               pxState->oIfIdx, pxState->eState, lReturn);
    }
    break;

  case ETHMSG_FORWARDPPPOEONLY:
      pxEth->obForwardPPPoEOnly = (OCTET)hData;
    break;

  case ETHMSG_SETINITIALIFSTATE:
    {
      ETHIFSTATE *pxState = (ETHIFSTATE *)hData;

      ASSERT(pxState->oIfIdx < (OCTET) ETHBR_MAXNUM_IF);

      pxEth->aeInitialPortState[pxState->oIfIdx] = pxState->eState;

      ETH_DBGP(REPETITIVE,"ETHMSG_SETINITIALIFSTATE: oIfIdx=%d, State=%s\n",
               pxState->oIfIdx, apoStpPortStateString[pxState->eState]);
    }
    break;

#ifndef NDEBUG
  case NETMSG_OPEN :
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    break;

  default:
    ASSERT(0);
#endif
  }

  return lReturn;
}

/*
 * EthInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer : IP,ARP,RARAP,PPPOE,PPPOE-SESSION, etc
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hEth                       ETH instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE EthInstanceULInterfaceCreate(H_NETINSTANCE hEth)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  INT iDx;

  ETH_CHECK_STATE(pxEth);

  for(iDx = 0; iDx < ETH_MAXULIF; iDx++){
    if(pxEth->apxUl[iDx] == NULL){
      break;
    }
  }

  ASSERT(iDx < ETH_MAXULIF);

  pxEth->apxUl[iDx] = (ETH_UL*)MALLOC(sizeof(ETH_UL));
  MOC_MEMSET((ubyte *)(pxEth->apxUl[iDx]), 0, sizeof(ETH_UL));
  pxEth->oUlNumber++;
  ASSERT(pxEth->oUlNumber <= ETH_MAXULIF);
  pxEth->apxUl[iDx]->oIfIdx = NETIFIDX_ANY;
  ETH_DBGP(NORMAL,"EthULIfCreate:hEth=%d,hLlIf=%d\n",(int)hEth,iDx);

  return (H_NETINTERFACE) (iDx);
}

/*
 * EthInstanceULInterfaceDestroy
 *  Destroy a ETH UL interface
 *
 *  Args:
 *   hEth                       ETH instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG EthInstanceULInterfaceDestroy(H_NETINSTANCE hEth,
                                   H_NETINTERFACE hInterface)
{
  ETHSTATE  *pxEth = (ETHSTATE *)hEth;
  ETH_UL *pxUl;
  INT iDx = (int)hInterface;
  ETH_CHECK_STATE(pxEth);

  ASSERT((pxEth->oUlNumber > 0) &&
         (iDx < ETH_MAXULIF) &&
         (iDx >= 0));

  ETH_DBGP(NORMAL,"EthULIfDestroy:hEth=%d,hLlIf=%d\n",(int)hEth,(int)iDx);

  pxEth->oUlNumber--;

  pxUl = pxEth->apxUl[iDx];
  ASSERT(pxUl != NULL);
  FREE(pxUl);
  pxEth->apxUl[iDx] = NULL;

  return 0;
}

/*
 * EthInstanceULInterfaceIoctl
 *  Eth UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and ip.h
 *  for precisions
 *
 *  Args:
 *   hEth                         ETH instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG EthInstanceULInterfaceIoctl(H_NETINSTANCE hEth,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  ETHSTATE  *pxEth = (ETHSTATE *)hEth;
  ETH_UL *pxUl;
  LONG lReturn = NETERR_NOERR;
  INT iDx = (int)hULInterface;

  ETH_CHECK_STATE(pxEth);
  ASSERT( (iDx >= 0) &&
          (iDx < ETH_MAXULIF) &&
          (oIoctl < ETHULINTERFACEIOCTL_MAX));

  ETH_DBGP(NORMAL,"EthULIoctl:hEth=%d,hULIf=%d,oIoctl=%s,hData=%d\n",
           (int)hEth,iDx,
           apoNetIoctlString[oIoctl],
           (int)hData);

  pxUl = pxEth->apxUl[iDx];
  ASSERT(pxUl != NULL);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_SETHINST:
    pxUl->hUlInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    ASSERT((void*)hData != NULL);
    pxUl->pfnRxCbk = (PFN_NETRXCBK)hData;;
    break;

  case NETINTERFACEIOCTL_SETROUTINGID:
    pxUl->wRoutingId = (WORD)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxUl->hUlIf = (H_NETINTERFACE)hData;
    break;

  case ETHULINTERFACEIOCTL_SETIFIDX:
    pxUl->oIfIdx = (H_NETINTERFACE)hData;
    ASSERT(pxUl->oIfIdx < ETHBR_MAXNUM_IF);
    break;

#ifndef NDEBUG
  case NETINTERFACEIOCTL_OPEN:
      ASSERT(pxUl->wRoutingId != 0);
      ASSERT(pxUl->pfnRxCbk != NULL);
      break;
  case NETINTERFACEIOCTL_CLOSE:
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
#endif
  }

  return lReturn;
}



/*
 * EthInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hEth                       ETH instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE EthInstanceLLInterfaceCreate(H_NETINSTANCE hEth)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  ETH_LL *pxLl;

  ETH_CHECK_STATE(pxEth);

  ASSERT(pxEth->oLlNumber < ETHBR_MAXNUM_IF);

  /* Allocate the memory */
  pxLl = (ETH_LL *)MALLOC(sizeof(ETH_LL));
  MOC_MEMSET((ubyte *)pxLl, 0, sizeof(ETH_LL));
  ASSERT(pxLl != NULL);

  /*
   * Set defaults for this LL instance
   */

  /* Enable VLAN filtering by default */
  pxLl->obIngressFilter = FALSE;

  pxLl->wDefaultVlan = NETVLAN_DEFAULT;


  /* Set up limit defaults */
  pxLl->dwBitRate = ETH_DEFAULTIFBITRATE;
  pxLl->oBcastPercent = ETH_DEFAULTIFBCASTPERCENTLIMIT;
  pxLl->oMcastPercent = ETH_DEFAULTIFMCASTPERCENTLIMIT;
  pxLl->dwBcastLimit =
    (10 * (DWORD)ETH_DEFAULTIFBCASTPERCENTLIMIT * ETH_DEFAULTIFBITRATE) >> 3;
  pxLl->dwMcastLimit =
    (10 * (DWORD)ETH_DEFAULTIFMCASTPERCENTLIMIT * ETH_DEFAULTIFBITRATE) >> 3;

  pxEth->oLlNumber ++;

  ETH_DBGP(NORMAL,"EthLLIfCreate:hEth=%d,hLlIf=0x%p\n",(int)hEth,pxLl);

  return (H_NETINTERFACE) pxLl;
}

/*
 * EthInstanceLLInterfaceDestroy
 *  Destroy a ETH LL interface
 *
 *  Args:
 *   hEth                       ETH instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG EthInstanceLLInterfaceDestroy(H_NETINSTANCE hEth,
                                   H_NETINTERFACE hInterface)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  ETH_LL *pxLl = (ETH_LL *)hInterface;

  ETH_CHECK_STATE(pxEth);

  ASSERT((pxLl != NULL) &&
         (pxLl->oIfIdx < ETHBR_MAXNUM_IF) &&
         (pxEth->apxIfToLlMap[pxLl->oIfIdx] == pxLl) &&
         (pxLl->obOpen == FALSE) &&
         (pxEth->oLlNumber > 0));

  ETH_DBGP(NORMAL,"EthLLIfDestroy:hEth=%d,hLlIf=%d\n",(int)hEth,(int)hInterface);

  pxEth->oLlNumber--;

  /* Clear the mapping to this LL */
  pxEth->apxIfToLlMap[pxLl->oIfIdx] = NULL;

  /* Free the LL mem */
  FREE(pxLl);

  return NETERR_NOERR;
}

/*
 * EthInstanceLLInterfaceIoctl
 *  ETH LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and netransport.h
 *  for precisions
 *
 *  Args:
 *   hEth                         Eth instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG EthInstanceLLInterfaceIoctl(H_NETINSTANCE hEth,
                                H_NETINTERFACE hLlInterface,
                                OCTET oIoctl,
                                H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  ETH_LL *pxLl = (ETH_LL *)hLlInterface;
  LONG lReturn = NETERR_NOERR;

  ETH_CHECK_STATE(pxEth);
  ASSERT(pxLl != NULL);

  ETH_DBGP(NORMAL,"EthLLIoctl:hEth=%d,hLlIf=%d,oIoctl=%s,hData=%d\n",
           (int)hEth,(int)hLlInterface,
           apoNetIoctlString[oIoctl],
           (int)hData);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
    ASSERT(pxLl->pfnLlWrite != NULL);
    pxLl->obOpen = TRUE;
    if (pxLl->obBridged == TRUE) {
      _SpanningTreeReInit(pxEth);
    }
    break;

  case NETINTERFACEIOCTL_CLOSE:
    pxLl->obOpen = FALSE;
    if (pxLl->obBridged == TRUE) {
      pxLl->obBridged = FALSE;
      _SpanningTreeReInit(pxEth);
    }
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxLl->hLlInst = (H_NETINSTANCE) hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    ASSERT((void*)hData != NULL);
    pxLl->pfnLlWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxLl->hLlIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}


/*
 * EthInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hEth                        Eth Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG EthInstanceProcess(H_NETINSTANCE hEth)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  DWORD dwTime;
  DWORD dwMinimumWaitTime = ETHTIME_MAXPROCESS;
  DWORD dwTempTime;

  ETH_CHECK_STATE(pxEth);

  /* Get the current time */
  dwTime = (DWORD)NetGetMsecTime();
  /*
   * Call the mac filter process fn.
   */
  {
    static DWORD dwMacFilterProcessTime = 0;

    dwRefreshMacTicks = dwTime;  /* Update the time for MAC filter */

    if (pxEth->obSpanningEnabled == TRUE) {
      if ((dwTime - dwMacFilterProcessTime) >= MAC_FILTER_PROCESS_TIME) {
        dwMacFilterProcessTime = dwTime;
        if (ST_TOPOLOGY_CHANGE) {
          MacFilterRefresh((DWORD)ST_FORWARD_DELAY);
        } else {
          MacFilterRefresh((DWORD)MAC_FILTER_TIMEOUT_DEFAULT);
        }
      }
      dwTempTime = (dwTime - dwMacFilterProcessTime);
      if (dwMinimumWaitTime > (MAC_FILTER_PROCESS_TIME - dwTempTime)) {
        dwMinimumWaitTime = (MAC_FILTER_PROCESS_TIME - dwTempTime);
      }
    }
  }


  /*
   * Call the spanning tree process fn.
   * Only if we are in bridged mode
   */
  {
    static DWORD dwStpProcessTime = 0;

    if (pxEth->obSpanningEnabled == TRUE) {
      if ((dwTime - dwStpProcessTime) >= STP_PROCESS_TIME) {
        dwStpProcessTime = dwTime;
        SpanningTreeProcess();

#ifdef BRIDGEDBG_HI
        {
          static OCTET aoOldState[ETHBR_MAXNUM_IF];
          ETH_LL *pxNewLl = NULL;
          OCTET oIdx;

          /* Loop through all the LL interfaces */
          for (oIdx = 0; oIdx < (OCTET)ETHBR_MAXNUM_IF; oIdx ++) {

            pxNewLl = pxEth->apxIfToLlMap[oIdx];

            /* Check if the state has changed for LL interfaces that have
             * bridging enabled */
            if (pxNewLl != NULL && pxNewLl->obOpen == TRUE &&
                pxNewLl->obBridged == TRUE &&
                ST_PORT_STATE(pxNewLl->oPortNo) != aoOldState[oIdx] ) {

              ETH_DBGP(NORMAL,
                      "Bridge port %d state changed from %s to %s\n",
                      pxNewLl->oPortNo,
                      apoStpPortStateString[aoOldState[oIdx]],
                      apoStpPortStateString[ST_PORT_STATE(pxNewLl->oPortNo)]);

              aoOldState[oIdx] = ST_PORT_STATE(pxNewLl->oPortNo);
            }
          }
        }
#endif
      }
      dwTempTime = (dwTime - dwStpProcessTime);
      if (dwMinimumWaitTime > (STP_PROCESS_TIME - dwTempTime)) {
        dwMinimumWaitTime = (STP_PROCESS_TIME - dwTempTime);
      }
    }
  }

  /*
   * Call the limiter process fn.
   */
  {
    static DWORD dwEthLimiterProcessTime = 0;
    ETH_LL *pxNewLl = NULL;
    OCTET oIdx;

    if ((dwTime - dwEthLimiterProcessTime) >= ETH_LIMITER_PROCESS_TIME) {
      dwEthLimiterProcessTime = dwTime;
      for(oIdx = 0; oIdx < (OCTET)ETHBR_MAXNUM_IF; oIdx++) {
        pxNewLl = pxEth->apxIfToLlMap[oIdx];
        if (pxNewLl == NULL || pxNewLl->obOpen == FALSE ) {
          continue;
        }

#ifdef BRIDGEDBG_HI
        if (ETH_LIMIT_BCAST_CHECK(pxNewLl)){
          ETH_DBGP(REPETITIVE,
                   "B cast limit hit. oIfIdx %d\n",
                   pxNewLl->oIfIdx);
        }
        if (ETH_LIMIT_MCAST_CHECK(pxNewLl)){
          ETH_DBGP(REPETITIVE,
                   "M cast limit hit. oIfIdx %d\n",
                   pxNewLl->oIfIdx);
        }
#endif
        /* Reset the byte counters */
        pxNewLl->dwBcastByteCount = 0;
        pxNewLl->dwMcastByteCount = 0;
      }
    }
    dwTempTime = (dwTime - dwEthLimiterProcessTime);
    if (dwMinimumWaitTime > (ETH_LIMITER_PROCESS_TIME - dwTempTime)) {
      dwMinimumWaitTime = (ETH_LIMITER_PROCESS_TIME - dwTempTime);
    }
  }

  ASSERT(dwMinimumWaitTime <= ETHTIME_MAXPROCESS);
  if (dwMinimumWaitTime < ETHTIME_MINPROCESS) {
    dwMinimumWaitTime = ETHTIME_MINPROCESS;
  }

  return (LONG)dwMinimumWaitTime;
}


/*****************************************************************************
 *
 * Local Function Implementation
 *
 *****************************************************************************/

/***************************************************************************
* void _LearningProcess(pxLl, poSrcAddr, WORD wVlan);
*  Implement the bridge learning process.
*
*  par: pxLl      - LL interface
*       poSrcAddr - Mac source address
*       wVlan     - vlan id
*
*  ret: void
****************************************************************************/
void _LearningProcess(ETH_LL *pxLl, OCTET *poSrcAddr, WORD wVlan)
{
  /* Check if the spanning tree allows us to learn on this port */
  if (ST_PORT_STATE(pxLl->oPortNo) == Learning ||
       ST_PORT_STATE(pxLl->oPortNo) == Forwarding)
  {
    /* *poSrcAddr is first byte of the source address */
    if (!(*poSrcAddr & 1)) {  /* unicast addr. must be even */

      ETH_DBGP(REPETITIVE,
           "_LearningProcess: oIfIdx: %d, Src addr: %02x:%02x:%02x:%02x:%02x:%02x\n",
           pxLl->oIfIdx,
           HWADDRDISPLAY(poSrcAddr));

      MacFilterAdd(poSrcAddr, pxLl->oIfIdx);
    }
  }
}

/***************************************************************************
* LONG _ForwardingProcess(ETHSTATE *pxEth
*                         ETH_LL *pxLl,
*                         NETPACKET *pxPacket,
*                         NETPACKETACCESS *pxAccess,
*                         WORD wVlan)
*  Implement the bridge forwarding process.
*
*  par: pxLl           - LL interface
*       pxPacket       - NETPACKET *
*       pxAccess       - NETPACKETACCESS *
*       wVlan          - Vlan tag
*
*  ret: LONG - Success == 0, Fail == -1
****************************************************************************/
LONG _ForwardingProcess(ETHSTATE *pxEth,
                        ETH_LL *pxLl,
                        NETPACKET *pxPacket,
                        NETPACKETACCESS *pxAccess,
                        WORD wVlan)
{
  OCTET oIdx;
  ETH_LL *pxNewLl;
  OCTET *poEthHdr;

  ASSERT(pxLl != NULL);

  poEthHdr = pxPacket->pxPayload->poPayload + pxAccess->wOffset;

  ETH_DBGP(REPETITIVE,
           "_ForwardingProcess:oIfIdx=%d,Dst=%02x:%02x:%02x:%02x:%02x:%02x,\n",
           pxLl->oIfIdx,
           HWADDRDISPLAY(poEthHdr));

  /*
   * Do nothing if the port the packet was rx'd on is not forwarding
   */
  if (ST_PORT_STATE(pxLl->oPortNo) != Forwarding) {
    return -1;
  }

  /*
   * Determine whether packet is broadcast, multicast or unicast.
   */
  if ((0x01 & poEthHdr[0]) != 0) { /* Test for both Multicast and Broadcast */

    ETH_DBG_ASSERT(pxLl->obBridged == TRUE);
    /*
     * If this packet has been RXed on the LAN -
     * try to forward it to all the bridged WAN LLs
     */
    if (pxLl->oIfIdx == pxEth->oLanIdx) {
      /* Loop through all the LL interfaces */
      for (oIdx = 0; oIdx < (OCTET)ETHBR_MAXNUM_IF; oIdx ++) {

        pxNewLl = pxEth->apxIfToLlMap[oIdx];
        /* Skip the LAN port */
        if (pxNewLl == NULL || pxNewLl->obOpen == FALSE ||
            pxNewLl->oIfIdx == pxEth->oLanIdx) {
          continue;
        }
        /* Forward the packet to LL interfaces that have
         * bridging enabled and are in the forwarding state */
        if (pxNewLl->obBridged == TRUE &&
            ST_PORT_STATE(pxNewLl->oPortNo) == Forwarding ) {

          _EgressProcess(pxEth, pxNewLl, pxPacket, pxAccess, wVlan);
        }
      }
    } else {
      /*
       * The packet has been RXed on a WAN LL -
       * broadcast and multicasts received on a WAN LL are
       * only sent to the LAN - NOT other WAN's
       */

      /* Get the LAN LL */
      pxNewLl = pxEth->apxIfToLlMap[pxEth->oLanIdx];
      ASSERT(pxNewLl);

      /* Forward the packet if LAN LL is part of the bridge
       * and in the forwarding state */
      if (pxNewLl->obOpen == TRUE && pxNewLl->obBridged == TRUE &&
          ST_PORT_STATE(pxNewLl->oPortNo) == Forwarding) {

        _EgressProcess(pxEth, pxNewLl, pxPacket, pxAccess, wVlan);
      }
    }
  } else {
    MACFILTERENTRY *pxFilterEntry;
    /*
     * Must be a Unicast packet
     */

    /* Apply the MAC filtering */
    pxFilterEntry = MacFilterLookup(poEthHdr);
    if (NULL  == pxFilterEntry) {
      /* The address was not found */
      return -1;
    }

    /* Get the LL */
    ETH_DBG_ASSERT(pxFilterEntry->oIfIdx < (OCTET) ETHBR_MAXNUM_IF);
    pxNewLl = pxEth->apxIfToLlMap[pxFilterEntry->oIfIdx];
    ASSERT(pxNewLl);
    /*
     * Forward the packet if its destination port is different
     * from its source port
     * AND the dest port is in the forwading state
     */
    if (pxNewLl->obOpen == TRUE && pxNewLl->obBridged == TRUE &&
        pxLl->oPortNo != pxNewLl->oPortNo &&
        ST_PORT_STATE(pxNewLl->oPortNo) == Forwarding) {

      _EgressProcess(pxEth, pxNewLl, pxPacket, pxAccess, wVlan);
    }
  }
  return 0;
}


/***************************************************************************
* void _EgressProcess(ETHSTATE *pxEth,
*                     ETH_LL *pxLl,
*                     NETPACKET *pxPacket,
*                     NETPACKETACCESS *pxAccess,
*                     WORD wVlan)
*  Implement the bridge egress process.
*
*  par: pxLl        - LL interface *
*       pxPacket    - NETPACKET *
*       pxAccess    - NETPACKETACCESS *
*
*  ret: void
****************************************************************************/
void _EgressProcess(ETHSTATE *pxEth,
                    ETH_LL *pxLl,
                    NETPACKET *pxPacket,
                    NETPACKETACCESS *pxAccess,
                    WORD wVlan)
{
  NETPACKETACCESS xAccess;
  NETPACKET xPacket;
  NETPACKET *pxNewPkt;
  OCTET *poPayload;
  WORD wTemp;
  OCTET *poEthHdr;

  /************************************************************
   *
   * Available bandwidth check
   *
   ************************************************************/
  {
    METERREQUEST xMeterReq;
    xMeterReq.oIfIdx = pxLl->oIfIdx;
    xMeterReq.wSize = pxAccess->wLength + LINK_SIZE_MIN;
    xMeterReq.oPriority = pxAccess->oPriority;
    if (MeterMsg(METERMSG_REQBANDWIDTH, (H_METERDATA)&xMeterReq) < METER_NOERR) {
      return;
    }
    xAccess.oPriority = xMeterReq.oPriority;
  }

  poEthHdr = pxPacket->pxPayload->poPayload + pxAccess->wOffset;

  if (wVlan == NETVLAN_DEFAULT && pxLl->wDefaultVlan != NETVLAN_DEFAULT) {
    /* Non-VLAN to VLAN */
    poPayload = (OCTET*) pxEth->pfnMalloc(pxPacket->pxPayload->wSize);
    ASSERT(poPayload);

    NETPAYLOAD_CREATE((&(xPacket.pxPayload)),
                      pxEth->pfnFree,
                      pxEth->pxMutex,
                      poPayload,
                      pxPacket->pxPayload->wSize
                      );

    poPayload += pxAccess->wOffset - ETHVLAN_LEN;

    /* Copy in the dest and src addresses */
    MOC_MEMCPY((ubyte *)poPayload, (ubyte *)poEthHdr, (size_t)ETHADDRESS_LEN*2);
    poPayload += ETHADDRESS_LEN*2;

    /* Copy in the default VLAN of this LL interface */
    wTemp = htons((WORD)ETHVLAN_TYPE);
    MOC_MEMCPY((ubyte *)poPayload,(ubyte *) &wTemp, (size_t)ETHTYPE_LEN);
    wTemp = htons(pxLl->wDefaultVlan);
    MOC_MEMCPY((ubyte *)(poPayload + ETHTYPE_LEN),
        (ubyte *) &wTemp, sizeof(WORD));
    poPayload += ETHVLAN_LEN;

    /* Copy in the rest of the packet */
    MOC_MEMCPY((ubyte *)poPayload,
                  (ubyte *)(poEthHdr + ETHADDRESS_LEN*2),
                  pxAccess->wLength - (ETHADDRESS_LEN*2));

    pxNewPkt = &xPacket;
    xAccess.wOffset = pxAccess->wOffset - ETHVLAN_LEN;
    xAccess.wLength = pxAccess->wLength + ETHVLAN_LEN;
  } else if (wVlan != NETVLAN_DEFAULT && pxLl->wDefaultVlan == NETVLAN_DEFAULT) {
    /* VLAN to Non-VLAN */
    poPayload = (OCTET*) pxEth->pfnMalloc(pxPacket->pxPayload->wSize);
    ASSERT(poPayload);

    NETPAYLOAD_CREATE((&(xPacket.pxPayload)),
                      pxEth->pfnFree,
                      pxEth->pxMutex,
                      poPayload,
                      pxPacket->pxPayload->wSize
                      );

    poPayload += pxAccess->wOffset;

    /* Copy in the dest and src addresses */
    MOC_MEMCPY((ubyte *)poPayload,(ubyte *) poEthHdr, (size_t)ETHADDRESS_LEN*2);

    /* Copy in the rest of the packet */
    MOC_MEMCPY((ubyte *)(poPayload + ETHADDRESS_LEN*2),
                  (ubyte *)(poEthHdr + ETHADDRESS_LEN*2 + ETHVLAN_LEN),
                  pxAccess->wLength - (ETHADDRESS_LEN*2 + ETHVLAN_LEN));

    pxNewPkt = &xPacket;
    xAccess.wOffset = pxAccess->wOffset;
    xAccess.wLength = pxAccess->wLength - ETHVLAN_LEN;
  } else {
    /* Both packets are VLAN or both are Non-VLAN */
    /* If the packets are VLAN - replace the packet vlan with
     * the default vlan of the tx port */
    if (pxLl->wDefaultVlan != NETVLAN_DEFAULT) {
      wTemp = htons(pxLl->wDefaultVlan);
      MOC_MEMCPY((ubyte *)(pxPacket->pxPayload->poPayload
                    + pxAccess->wOffset
                    + ETHVLAN_OFFSET), (ubyte *)&wTemp, sizeof(WORD));
    }
    /* Increment the use count of the packet */
    NETPAYLOAD_ADDUSER(pxPacket->pxPayload);
    pxNewPkt = pxPacket;
    xAccess.wOffset = pxAccess->wOffset;
    xAccess.wLength = pxAccess->wLength;
  }

#ifndef CUSTOM_QUEUE
  ETH_DBGP(REPETITIVE,
           "_EgressProcess:oIfIdx=%d, Offset=%d, Length=%d, Priority=%d\n",
           pxLl->oIfIdx,
           xAccess.wOffset,
           xAccess.wLength,
           xAccess.oPriority);
#else
  ETH_DBGP(REPETITIVE,
           "_EgressProcess:oIfIdx=%d, Offset=%d, Length=%d, Priority=%d, Class=%d\n",
           pxLl->oIfIdx,
           xAccess.wOffset,
           xAccess.wLength,
           xAccess.oPriority,
           xAccess.oClass);
#endif

  /* Call the LL write */
  ASSERT(pxLl->pfnLlWrite);
  pxLl->pfnLlWrite(pxLl->hLlInst,
                   pxLl->hLlIf,
                   pxNewPkt,
                   &xAccess,
                   (H_NETDATA)pxLl->oIfIdx);

}



/***************************************************************************
* void _SpanningTreeReInit(ETHSTATE *pxEth)
*  Re-initializes the spanning tree and port numbering.
*
*  par: pxEth     - ETHSTATE *
*
*  ret: void
****************************************************************************/
static void _SpanningTreeReInit(ETHSTATE *pxEth)
{
  ETH_LL *pxLl;
  OCTET oIdx;
  static OCTET oOldNumPorts = 0;
  OCTET oNumPorts = 0;

  /* Re-number the ports */
  for (oIdx = 0; oIdx < (OCTET)ETHBR_MAXNUM_IF; oIdx ++) {
    pxLl = pxEth->apxIfToLlMap[oIdx];
    if (pxLl != NULL && pxLl->obOpen == TRUE && pxLl->obBridged == TRUE) {
      pxLl->oPortNo = oNumPorts++;
    }
  }

  pxEth->oNumBridgePorts = oNumPorts;

  /* If enough ports for a bridge i.e. 2 or more */
  if (pxEth->oNumBridgePorts >= (OCTET)2) {
    if (oOldNumPorts != oNumPorts) {
      /* Re-init the spanning tree */
      if ((LONG)-1 == SpanningTreeInit(pxEth)) {
        ASSERT(0);
      }
      (void)SpanningTreeStart();
      pxEth->obSpanningEnabled = TRUE;
    }
  } else if (pxEth->obSpanningEnabled == TRUE) {
    pxEth->obSpanningEnabled = FALSE;
    (void)SpanningTreeStop();
  }
  oOldNumPorts = oNumPorts;
}


/*****************************************************************************
 *
 * Debug Functions
 *
 *****************************************************************************/
#ifdef BRIDGEDBG_HI
CHAR *EthProtoToString(WORD wProtocol)
{
  switch(wProtocol){
  case ETHID_IP:
    return "IP";

  case ETHID_ARP:
    return "ARP";

  case ETHID_RARP:
    return "RARP";

  case ETHVLAN_TYPE:
    return "VLAN";

  case ETHID_PPPOEDISCOVERY:
    return "PPPoE-Discovery";

  case ETHID_PPPOESESSION:
    return "PPPoE-Session";

  default:
    return "???";
  }
}

const OCTET *apoStpPortStateString[] = {
  "Disabled",
  "Listening",
  "Learning",
  "Forwarding",
  "Blocking"
  };

const OCTET *apoEthOptionString[] = {
  "MACADDR",
  "IFTOLLMAP",
};

const OCTET *apoEthMsgString[] = {
  "LOCALLOOPBACK",
  "SETLLDEFAULTVLAN",
  "ADDSPECIFICVLAN",
  "REMOVESPECIFICVLAN",
  "ENABLEBRIDGE",
  "DISABLEBRIDGE",
  "SETLANIF",
  "SETIFBITRATE",
  "SETIFBCASTLIMIT",
  "SETIFMCASTLIMIT",
  "GETIFSTATE",
  "",


};

#endif
