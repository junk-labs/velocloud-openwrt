/*
** Compute the H.223-M Convolutional coder/decoder.
**
**
** Hossein Sedarat   Dec 98
*/

#include <NNstyle.h>
#include <stdlib.h>
#include <stdio.h>

#include "ecc.h"

#include "weight.h"

#define NUM_STATES 16
#define DATA_DIM   2

#define BLKSZ 32      /* The input vector is broken into blocks of BLKSZ 
						 size of bytes to be apllied Viterbi upon */
#define DEPTH 4       /* Assumption: all surviving paths are merged at
						 DEPTH bytes in the past */
#define BIG 200       /* a big octet that wont saturates when 
						 added to the path metric over 8 bits */

#define MIN(X,Y)  ( (X)<(Y) ? (X) : (Y) )

#include "conv.dat"

/*
  return the HEX value which when added to the data bit stream 
  would result in a zero final state for the convolutional encoder.
*/
OCTET EccConvFinalHex( OCTET *poD, DWORD dwLen )
{
  OCTET oState, oFinalHex;

  oState = 0;
  for (; dwLen>1; dwLen--) {
	oState |= ((*poD) << 4);
	oState = aoConvTableS[oState] | ((*poD) & 0xF0);
	oState = aoConvTableS[oState];
	poD++;
  }
  oState |= ((*poD) << 4);
  oState = aoConvTableS[oState];

  /* find the input that would lead to the zero state */
  oFinalHex = 0;
  while( aoConvTableS[oState | (oFinalHex<<4)] != 0 ) oFinalHex++;

  return oFinalHex;
}

/*
   Generates the redundant bit streams pointed by 'poR[0 .. oNr-1]' 
   for the data bits 'poD' according to the convolutional encoding 
   rule specified by 'aoConvTableR' and 'aoConvTableS'. 'dwLen' is 
   the number of input bytes. The return value is the final state 
   of the convolutional encoder.
*/
OCTET EccConvEncoder( OCTET *poD, OCTET *poR[], DWORD dwLen, OCTET oNr )
{
  int i;
  DWORD dw;
  OCTET oState;

  oState = 0;
  for (dw=0; dw<dwLen; dw++) {
	oState |= (poD[dw] << 4);
	for (i=0; i<oNr; i++) poR[i][dw] = aoConvTableR[i][oState];
	oState = aoConvTableS[oState] | (poD[dw] & 0xF0);
	for (i=0; i<oNr; i++) poR[i][dw] |= aoConvTableR[i][oState] << 4;
	oState = aoConvTableS[oState];
  }
  return oState;
}

/*
  Applies the Viterbi decoding to the data block pointed by adwRcvd
  with size oBlkSz. dwPuncture determines the puncturing rule.
  The decoding is done 4 bits at a time.

  The codeword corresponding to a byte is arranged as:
  adwRcvd = [r3_1,r2_1,r1_1,u_1,  r3_0,r2_0,r1_0,u_0]
  where u is the input byte and ri are the redundant bytes. u_0 
  denotes the least significant hex of byte u, and u_1 is the 
  most significant hex.
  (The least significant hex is the first to transmit)

  aoPathMetric is both input and output. As input it specifies the
  initial path metric for each state and as an output it specifies 
  the final path metric. 
  aoSurvPath[n][j] is the path metric at time n for state j. 
  The return value is the state with minimum path metric.
*/
OCTET Viterbi4Block( DWORD adwRcvd[], DWORD dwPuncture,
					 OCTET aoPathMetric[NUM_STATES], 
					 OCTET aoSurvPath[][NUM_STATES], OCTET oBlkSz )
{
  int n, i, j, k;
  OCTET o, oPM, aoPM[NUM_STATES], oIn=0, oBestState=0;
  WORD w, wR, wP;

  for (n=0; n<oBlkSz; n++) { /* for each byte in the block */
	for (j=0; j<NUM_STATES; j++)  aoSurvPath[n][j] = 0;
	for (i=0; i<8; i+=4) { /* for each hex of the input byte */
	  wR = (adwRcvd[n] >> (i<<2));
	  wP = (dwPuncture >> (i<<2));
	  for (j=0; j<NUM_STATES; j++) {
		oPM = BIG;
		for (k=0; k<16; k++) { /* search for the best possible input vector */
		  w = (awTrellisO[j][k] ^ wR) & wP;
		  o  = WEIGHT16(w) + aoPathMetric[ aoTrellisS[j][k] ];
		  if (o < oPM) {
			oPM = o;
			oIn = k;
		  }
		}
		aoPM[j] = oPM;
		aoSurvPath[n][j] |= (oIn << i);
	  }
	  for (j=0; j<NUM_STATES; j++) aoPathMetric[j] = aoPM[j];
	}
	/* normalize the path metrics */
	oPM = BIG;
	oBestState = 0;
	for (j=0; j<NUM_STATES; j++) 
	  if( oPM > aoPathMetric[j] ) {
		oBestState = j;
		oPM = aoPathMetric[j];
	  }
	for (j=0; j<NUM_STATES; j++) {
	  o = aoPathMetric[j] - oPM; 
	  aoPathMetric[j] = MIN(BIG, o);
	}
  }/* for each byte in the block */

  return oBestState;
}


/*
  Reorganizes the received codeword bytes to the format necessary 
  for the Viterbi decoder. apoIn[0] points to the DATA byte stream 
  and apoIn[i] points to the (i)th REDUNDANT byte stream, where:
      i = 1 .. 'oNr'   'oNr'<=3.
  The number of bytes being processed is 'oNd'. 
  The value of apoIn[0, .., oNr] is changed properly for the next
  call to this routine.
*/
void ReFormat( OCTET *apoIn[], DWORD *pdwOut, OCTET oNd, OCTET oNr)
{
  int i, j;

  for (; oNd>0; oNd--) {
	*pdwOut  = ((*apoIn[0]) & 0x0F);
	*pdwOut |= ((*apoIn[0]) & 0xF0) << 12;
	apoIn[0]++;
	for (i=1, j=4; i<=oNr; i++, j+=4) {
	  *pdwOut |= ((*apoIn[i]) & 0x0F) << j;
	  *pdwOut |= ((*apoIn[i]) & 0xF0) << (j+12);
	  apoIn[i]++;
	}
	pdwOut++;
  }

}

/*
  Traces back the survivng path stored in aoPath from state
  oS and stores the input bits in poBits. Returns the initial
  state that it reaches to.
*/
OCTET BitsFromPath( OCTET aoPath[][NUM_STATES], OCTET *poBits, 
					OCTET oS, OCTET oLen )
{
  int i;
  OCTET oB;

  for (i=oLen-1; i>=0; i--) {
	oB = (aoPath[i][oS] >> 4);
	poBits[i] = (oB << 4);
	oS = aoTrellisS[oS][oB];

	oB = (aoPath[i][oS] & 0x0F);
	poBits[i] |= oB;
	oS = aoTrellisS[oS][oB];
  }
  return oS;
}

/*
  Convolutional decoder. 
  apoRcvd[0] points to the received DATA byte stream and apoRcvd[i]
  points to the (i)th received REDUNDANT byte stream. The length of
  the data is 'dwLen' bytes. 
  The data rate is 8/(8+oRate), for oRate=0 .. 24. 
  poDecBits points to the decoded bits.
  The output is the final state in the surviving path
*/
OCTET EccConvDecoder( OCTET *apoRcvd[], OCTET *poDecBits,
					  OCTET oRate, DWORD dwLen )
{
  int i;
  OCTET aoPathMetric[NUM_STATES], oBS, oS, oLastState, oNr;
  OCTET (*poSP1)[NUM_STATES], (*poSP2)[NUM_STATES], (*poTmp)[NUM_STATES];
  OCTET aoSP1[BLKSZ][NUM_STATES], aoSP2[BLKSZ][NUM_STATES];
  DWORD adwRcvd[BLKSZ];
  static DWORD adwErasPatrn[24] = {
	0x000F001F, 0x001F001F,	0x001F005F,	0x005F005F, 
	0x005F007F, 0x007F007F,	0x007F00FF,	0x00FF00FF, 
	0x00FF01FF, 0x01FF01FF,	0x01FF05FF,	0x05FF05FF, 
	0x05FF07FF, 0x07FF07FF,	0x07FF0FFF,	0x0FFF0FFF, 
	0x0FFF1FFF, 0x1FFF1FFF,	0x1FFF5FFF,	0x5FFF5FFF, 
	0x5FFF7FFF, 0x7FFF7FFF,	0x7FFFFFFF,	0xFFFFFFFF };


  /* nothing to be done for rate 1 */
  if (0 == oRate) return 0;
  oRate--;

  /* initializing the path metric to start with the zeroth state */
  for (i=1; i<NUM_STATES; i++) aoPathMetric[i] = BIG;
  aoPathMetric[0] = 0;

  oNr = (oRate >> 3) + 1;
  poSP1 = aoSP1;
  poSP2 = aoSP2;

  oBS = MIN(dwLen, BLKSZ);
  ReFormat( apoRcvd, adwRcvd, oBS, oNr );
  oLastState = Viterbi4Block( adwRcvd, adwErasPatrn[oRate], 
							  aoPathMetric, poSP2, oBS );
  dwLen -= oBS;
  while( dwLen>0 ) {
	poTmp = poSP1; poSP1 = poSP2; poSP2 = poTmp;
	oBS = MIN(dwLen, BLKSZ);
	ReFormat( apoRcvd, adwRcvd, oBS, oNr );
	oLastState = Viterbi4Block( adwRcvd, adwErasPatrn[oRate], 
								aoPathMetric, poSP2, oBS );
	dwLen -= oBS;

	oS = BitsFromPath( poSP2, poDecBits, 0, DEPTH );
	BitsFromPath( poSP1, poDecBits, oS, BLKSZ );
	poDecBits += BLKSZ;
  }
  oS = BitsFromPath( poSP2, poDecBits, oLastState, oBS );

  return oLastState;
}
