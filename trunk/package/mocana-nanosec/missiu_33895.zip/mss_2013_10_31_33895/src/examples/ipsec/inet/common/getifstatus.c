
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcfg.h"
#include "setupnet.h"

/*
 * SetupNetGetIfStatus
 *  Get the status of an interface
 *
 *  Args:
 *   oIfIdx               Interface index
 *   pdwStat              Stat to be filled up
 *
 *  Return:
 *   SetupNetReturn
 */
SetupNetReturn SetupNetGetIfStatus(OCTET oIfIdx,
                                   DWORD *pdwStat)
{
  int iSocket;
  struct ifreq xIfReq;
  mnIoctlArgList_t mnIoctlArgList;      
  
  xIfReq.ifr_name[0] = oIfIdx;
  
  if ((iSocket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  mnIoctlArgList.ifreq = (void *)&xIfReq;
  if (0 > ioctl(iSocket,MO_SIOCGIFIFLAG,&mnIoctlArgList)) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  close(iSocket);
  
  *pdwStat = xIfReq.ifr_flags;
  
  return SETUPNET_OK;  
}
