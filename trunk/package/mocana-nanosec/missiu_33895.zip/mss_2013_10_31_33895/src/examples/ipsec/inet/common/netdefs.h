/*
 * netdefs.h
 *
 * Network wrapper common definitions. !!! Only used in wrapping libraries !!!
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETDEFS_H_
#define _NETDEFS_H_

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "dllist.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "mqueue.h"
#include "netconfig.h"
#include "../../utils/mocinclude.h"


/****************************************************************************
 *
 * Defines
 *
 ****************************************************************************/
#define NETTOS_PRIORITY_MASK   ((OCTET)0x14)/* min delay | max reliability */
#define NETVLAN_PRIORITY_LIMIT        3     /* 0-3 low, 4-7 high */

#define NETIFLIMITEROPTION_VLAN_ENABLE 0
#define NETIFLIMITEROPTION_VLAN_VALUE  1
#define NETIFLIMITEROPTION_TOS_ENABLE  2
#define NETIFLIMITEROPTION_TOS_MASK    3
#define NETIFLIMITEROPTION_PORT_ENABLE 4
#define NETIFLIMITEROPTION_PORT_ADD    5
#define NETIFLIMITEROPTION_PORT_REMOVE 6

#define LINK_SIZE_MIN 14     /* Minimum Link overhead */

#define NETGETWRAPPER &xNetWrapper
#define NETGETIFCONF(pxWrapper,oIfIdx) &((pxWrapper)->pxIfConf[(oIfIdx)])


/****************************************************************************
 *
 * Typedef
 *
 ****************************************************************************/
typedef enum {
  NETIFSTATUS_INIT = 0,
  NETIFSTATUS_SETUP,
  NETIFSTATUS_OPENED,
} E_IFSTATE_STATUS;

/*
 * Interface state structure
 */
typedef struct {

  E_IFSTATE_STATUS eStatus;

  NETCONF xNetConfLinkTop;
  NETCONF xNetConfLinkMiddle;
  NETCONF xNetConfLinkBottom;

  /*
   * Net hooks
   */
  H_NETINTERFACE hNetIf; /* Bottom Net interface, tied to the leg
                            lib & instance are in NETWRAPPER.
                            The inst is stored in the PPPWRAPPERSTATE
                            structure */
  /*
   * Link hooks
   */
  /* Top (to network) */
  H_NETINSTANCE hTopLinkInst; /* handle of the top link module instance.
                                 is also in pxLib */
  H_NETINTERFACE hTopLinkIf; /* handle to the top link module interface.
                                is also in pxLib */
  PFN_NETWRITE pfnTopLinkWrite; /* Top link write function */
  PFN_NETIOCTL pfnTopLinkUlIfIoctl; /* Top link ioctl function */

  /* Bottom (to driver) */
  H_NETINSTANCE hBottomLinkInst; /* Handle of the bottom link module instance.
                                    is also in pxLib */
  H_NETINSTANCE hBottomLinkIf; /* Handle of the bottom link module interface.
                                  is also in pxLib */
  PFN_NETRXCBK pfnBottomLinkRxCbk; /* Bottom Link function */
  PFN_NETIOCTL pfnBottomLinkLlIfIoctl; /* Bottom link ioctl function */

  H_NETINTERFACE hEthUlIf;
  H_NETINTERFACE hEthLlIf;
  H_NETINTERFACE hEthUlIfPppoE;
  H_NETINTERFACE hEthUlIfSession;

} NETIFSTATE;

typedef enum {
  NETMAINMSG_IFSETUP = 0,
  NETMAINMSG_IFOPEN,
  NETMAINMSG_IFCLOSE,
  NETMAINMSG_IFTEARDOWN,
  NETMAINMSG_IFIPUP,
  NETMAINMSG_IFAGGRADD,
  NETMAINMSG_IFAGGRDEL
} E_NETMAINMSG;

/*
 * NETMAINMSG
 *  netmain msg structure. Used for the netmain
 *  message queue.
 */
typedef struct {
  E_NETMAINMSG eNetMainMsg;
  H_NETDATA hData;
} NETMAINMSG;


/*
 * ATMCONF
 *  Interface ATM configuration
 */
typedef struct {
  OCTET oVpi;             /* Virtual path indicator */
  OCTET oVci;             /* Virtual channel indicator */
  OCTET oMode;            /* Encapsulation mode */
  OCTET oLatency;         /* Latency */
} ATMCONF;


/*
 * PPPCONF
 *  Interface PPP configuration
 */
typedef struct {
  char  *pcPppUsername;   /* Username for PPP authentication */
  char  *pcPppPassword;   /* Password for PPP authentication */
  char  *pcPppoESrv;      /* PPPoE service name */
  char  *pcPppoEAC;       /* PPPoE AC name */
  DWORD dwPppIdleTO;      /* PPP Idle timeout */
  DWORD dwPppEchoTO;      /* PPP Echo timeout */
  DWORD dwPppEchoCount;   /* PPP Echo count */
} PPPCONF;


/*
 * IPCONF
 *  Interface IP alias configuration
 */
typedef struct {
  DWORD dwAddr;
  DWORD dwNetMask;
  DWORD dwBroadcast;
  DWORD dwDNSIPAddr;
  DWORD dwNTPIPAddr;
#define MAX_NAME_LEN 80
  char *pcHostName;
  char *pcDomainName;

  union {
    /* P-P data */
    struct  {
      DWORD dwDstAddr;  /* P-P destination address */
    } xPppData;

    /* MP data */
    struct {
      DWORD dwGateway;  /* Gateway address */
    } xMpData;
  } uLink; /* If type specific data */

} IPCONF;


/*
 * ETHCONF
 *  Interface ETH configuration
 */
typedef struct {
  OCTET obBridge;
  OCTET oBcastLimit;
  OCTET oMcastLimit;
} ETHCONF;

typedef enum {
  ETH,
  ATM,
} E_PHYLINKTYPE;




/*
 * NETIFCONF
 */
typedef struct {
  char acIfName[IF_NAMESIZE]; /* pointer to the string (saves space)
                                 dev/locallink, ... see net/if.h */
  int iFd;                /* Driver Fd */
  OCTET oType;            /* Interface type: see net/if_types.h */

  E_PHYLINKTYPE ePhyLinkType; /*physical link type: ATM or ETH*/

  OCTET oTos;             /* interface default TOS */

#ifdef LINK_AGGREGATION
  WORD  oFlags;           /* Flags. se net/if.h */
#else
  OCTET oFlags;           /* Flags. se net/if.h */
#endif
  WORD xIfEventFlags;     /* Event flag */

  OCTET oL3AddrLength;    /* L3 default
                             address length (L3 address length) */
  OCTET oL3TrailerLength; /* L3 default trailer length */

  PPPCONF xPppConf;       /* PPP cfg if PPP interface */

  ATMCONF xAtmConf;       /* ATM cfg if ATM interface */

  ETHCONF xEthConf;       /* Ethernet/bridge cfg if ETH interface */

#define MAX_HWADDR      6
  OCTET aoHWAddr[MAX_HWADDR];
  OCTET oHWAddrLength;

  WORD  wMtu;             /* Interface Mtu, including all headers */
  WORD  wLtu;             /* Unterface Least Transmit Unit */

  WORD wVlan;             /* VLAN tag. Equivalent to the TAG CONTROL
                             INFORMATION specified in 802.1Q
                             Default value: NETVLAN_DEFAULT (see netcommon.h) */

  IPCONF *pxIPAlias;
  OCTET oIPAliasNumber;

  BOOL bCloseInterface;   /* Indicate that close callback has completed
                             and interface may be closed */

  OCTET oDhcpErrorFlag;            /* DHCP Error flag */
  H_NETINSTANCE hDhcpClient;       /* DHCP Client handle */
  DWORD dwDhcpClientProcessTimer;  /* Process timer for client (process every 500ms) */
  char *pcDhcpClientId;            /* DHCP Client ID */
#ifdef DHCP_CUSTOM_OPTIONS
  DLLIST *pdllDhcpClientCustomOpts;   /* List of custom dhcp options */
#endif /*DHCP_CUSTOM_OPTIONS */

  NETIFSTATE *pxNetIfState;

  pthread_t pth_tThread;  /* Thread for executing callback functions to
                             indicate interface closing/open/timeout events */
  H_NET *pMnDeviceInstance; /* per interface reverse link to device instance */
  DLLIST dllRxBuf;          /* per interface ingress queue */
  DLLIST dllNetPacketRx;
  DLLIST dllTxBuf;
  c_queue_t *pRxCq;
  NET_DRV_BUFFER xndbTxPacket;
#ifdef LINK_AGGREGATION
  /* if logical interface, underlying physical links */
  int iActivePhyLinkIfIdx;
  OCTET oPhyLinks[NUM_IFS];
  /* if physical interface, logical interface it's associated with */
  int iLogicalLinkIfIdx;
#endif

#ifndef __LOCK_OPT_ON__
  /* Per IfConf for transmit and receive Q Lock We need to introduce */
  RTOS_MUTEX xMutex;
#endif

} NETIFCONF;



typedef E_PRIORITY (*PFN_NETPACKET_SORTINGMETHOD)(NETPACKET *pxNetPacket);

/*
 * NetIfLimiter
 */

typedef struct {
  DLLIST dllNetPacketHP;
  DLLIST dllNetPacketLP;
  DLLIST dllPortRange;
  DWORD  dwPacketRx;
  DWORD  dwPacketRxLP;
  DWORD  dwPacketRxHP;
  DWORD  dwPacketRxMax;
  PFN_NETPACKET_SORTINGMETHOD pfnNetPacketSortingMethod;
  BOOL bOnOff;
  BOOL bVlan;
  BOOL bToS;
  BOOL bPortRange;
  OCTET oVlanValue;
  OCTET oToSMask;
  OCTET oNoPacketHPRx;
  BOOL bHit;
} NETIFLIMITER;

/*
 * Port Range
 */
typedef struct {
  WORD wPortMin;
  WORD wPortMax;
} PORT_RANGE;
/*
 * Network Wrapper main structure
 */

typedef struct {
  /* Network configuration.
     Except at initialisation
     all access to this must occur through socket ioctl */
  NETIFCONF *pxIfConf;
  OCTET oIfNumber;
  WORD wNextIfIndex;
  DLLIST dllPfnIfCloseCbk;
  DLLIST dllPfnIfOpenCbk;
  NETIF_DHCPERROR_CBK pfnIfDhcpErrorCbk;
  NETIF_LINKSTATUS_CBK pfnIfLinkStatusCbk;
  DLLIST MnConfigNetDevices;
  DLLIST dllMnDeviceInstanceEvents;

  pthread_mutex_t xMutex; /* =>Synchronize NETWRAPPER access. Used
                             also by the socket code */

  H_NETINSTANCE hState; /* Wrapper state handle. Used for internal management
                           by LIBNETMAIN */
  NETCONF xNetConf;
  NETIFLIMITER xNetIfLimiter;
  DLLIST dllIpMcastReq;

  /* FD map */
  void *pFdMap;

  /* Is the Stack ready */
  OCTET oEReady;
} NETWRAPPER;

typedef struct {
  OCTET oLIfIdx;
  OCTET oPIfIdx;
} NETIFAGGR;

/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/

/*
 * Network wrapper
 */
MOC_EXTERN NETWRAPPER xNetWrapper;

/****************************************************************************
 *
 * functions
 *
 ****************************************************************************/

/*
 * NetNumIfGet()
 *  Gets the number of interfaces in the system.
 *
 *  Args:
 *
 *  Return:
 *   number of interfaces
 */
DWORD NetNumIfGet(void);

/*
 * NetMainMsg
 *  Netmain library message function
 *
 *  Args:
 *   oCode              Msg code
 *   hData              data handle
 *
 *  return:
 *   NETERR_NOERR
 */
LONG NetMainMsg(OCTET oMsgCode,H_NETDATA hData);

LONG NetIfLimiterSet(OCTET oOption,H_NETDATA hData);

#endif /* #ifndef _NETDEFS_H_ */

