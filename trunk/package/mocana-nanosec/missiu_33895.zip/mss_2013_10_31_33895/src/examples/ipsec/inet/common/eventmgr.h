/*
 * eventmgr.h
 *
 * API for the Event Manager
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __EVENTMGR_H
#define __EVENTMGR_H

/************/
/* includes */
/************/

#include "NNstyle.h"


/***********/
/* defines */
/***********/

/************/
/* typedefs */
/************/

/*
 * handles
 */
typedef void *H_EVENT_CLASS;        /* registered event class handle     */
typedef void *H_EVENT_CBK;        /* event callback handle         */


/*
 * event classes
 */
typedef enum {

  EVENTCLASS_ERROR,        /* error events                     */
  EVENTCLASS_SCHEDULER,        /* System Scheduler                 */
  EVENTCLASS_TRK,        /* tracking                     */

  EVENTCLASS_DATA_BUFFER,       /* Databuffering events */

  EVENTCLASS_VPMGR,             /* VP Mgr events */

  EVENTCLASS_VIDENCVP,        /* Video Encode VP process             */
  EVENTCLASS_VIDENCHUFF,    /* Video Encode Huffman process             */
  EVENTCLASS_VIDDECVP,        /* Video Decode VP process             */
  EVENTCLASS_VIDDECHUFF,    /* Video Decode Huffman process             */
  EVENTCLASS_VIDCAPTURE,    /* Video Capture process             */
  EVENTCLASS_VIDDISPLAY,    /* Video Display process             */
  EVENTCLASS_VIDPOOL,        /* Video Pool process                 */

  EVENTCLASS_ENUMMAX        /* *** must be LAST in enum ***             */

} E_EVENTCLASS;

/*
 * match key specification
 */
typedef enum {
  EVENT_MATCH_ANY, /* call callbacks regardless of callback/post hMatchKey   */
  EVENT_MATCH_KEY  /* call callbacks if either callback or post specify         */
           /*  EVENT_MATCH_ANY, or if callback and post hMatchKeys   */
           /*   match                             */
} E_EVENT_MATCHKEY;


/*
 * prototype for callback functions
 *
 * Arguments:
 *    eEventClass    the event class
 *    eEventNum    the event number
 *    pData        pointer to event data
 *    hUser        handle from the Register call
 */
typedef void (*EVENT_CBK)(E_EVENTCLASS eEventClass,
              int eEventNum,
              void *pData,
              void *hUser);


/*
 * event errors
 *
 * NOTE: this can NOT use the Error Mgr because the Error Mgr
 *     is initialized AFTER (and uses) the Event Mgr
 */
typedef enum {

  /* invalid event class    */
  EVENT_ERR_CLASS        = 0x00000001,

  /* class already registered    */
  EVENT_ERR_DUPL        = 0x00000002,

  /* out of memory        */
  EVENT_ERR_MEM            = 0x00000004,

  /* callbacks are still registered when EventUnregisterClass() called    */
  EVENT_ERR_CLASS_ACTIVE    = 0x00000008,

  /* bad event class handle given to EventPost()        */
  EVENT_ERR_POSTHANDLE        = 0x00000010,

  /* bad event number given to EventPost()            */
  EVENT_ERR_POSTNUM        = 0x00000020,

  /* event class not registered        */
  EVENT_ERR_UNREG_CLASS        = 0x00000040,

  /* event number > number of events for the class    */
  EVENT_ERR_NUM            = 0x00000080,

  /* error unregistering callback            */
  EVENT_ERR_UNREG_CBK        = 0x00000100

} E_EVENT_ERR;



/*******/
/* API */
/*******/

void EventInitialize(void);
void EventTerminate(void);

H_EVENT_CLASS EventRegisterClass(E_EVENTCLASS eEventClass, int nNumEvents);
void EventPost(H_EVENT_CLASS hEventClass, int eEventNum, void *pData,
           E_EVENT_MATCHKEY eUseMatchKey, ...);
void EventUnregisterClass(H_EVENT_CLASS hEventClass);

H_EVENT_CBK EventRegisterCallback(E_EVENTCLASS eEventClass, int eEventNum,
                  void *hUser, EVENT_CBK EventCallback,
                  E_EVENT_MATCHKEY eUseMatchKey, ...);
void EventCallbackOnNextOnly(H_EVENT_CBK hEventCallback);
void EventCallbackOnEvery(H_EVENT_CBK hEventCallback);
void EventUnregisterCallback(H_EVENT_CBK hEventCallback);

#if !defined(NDEBUG)
void DbgEventCallback(E_EVENTCLASS eEventClass, int eEventNum,
              void *pData, void *hUser);
#endif



/***********/
/* GLOBALS */
/***********/

MOC_EXTERN DWORD gbl_fEventError;


#endif /* __EVENTMGR_H */
