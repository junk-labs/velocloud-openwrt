/*
 * nat_dbg.h
 *
 * NAT module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NAT_DBG_H_
#define _NAT_DBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef NATDBG_HI
   #define NATDBG_HI
  #endif
 #endif

#else
 #ifdef NATDBG_HI
  #undef NATDBG_HI
 #endif
#endif

#include "netdbg.h"

#define NAT_MAGIC_COOKIE 0x6e617400 /* "nat" = 0x6e617400 */


/*#ifdef NATDBG_HI*/
#if defined(NATDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define NAT_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == NAT_MAGIC_COOKIE));

  #define NAT_SET_COOKIE(x) (x)->dwMagicCookie = NAT_MAGIC_COOKIE
  #define NAT_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define NAT_DBGP(level, fmt, args...) do { \
    if (level <= g_dwNatDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define NAT_DBG(level, x) do {  \
    if (level <= g_dwNatDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define NAT_DBG_VAR(x)  x
#else
  #define NAT_CHECK_STATE(x)
  #define NAT_SET_COOKIE(x)
  #define NAT_UNSET_COOKIE(x)
  #define NAT_DBGP(level, fmt, args...)
  #define NAT_DBG(level, x)
  #define NAT_DBG_VAR(x)
#endif

DEBUG_VAR(MOC_EXTERN DWORD g_dwNatTotalNumBindings;)

NAT_DBG_VAR(MOC_EXTERN DWORD g_dwNatDebugLevel;)

NAT_DBG_VAR(MOC_EXTERN BOOL g_bNatDisplayBindings;)

NAT_DBG_VAR(MOC_EXTERN DWORD g_adwNatNumActiveBindings[];)

NAT_DBG_VAR(MOC_EXTERN BOOL g_bNatDisplayPortForward;)


#define DBGLVL_ERROR_RARE 1
#define DBGLVL_NORMAL     2
#define DBGLVL_REPETITIVE 3

#endif /* #ifndef _NAT_DBG_H_ */
