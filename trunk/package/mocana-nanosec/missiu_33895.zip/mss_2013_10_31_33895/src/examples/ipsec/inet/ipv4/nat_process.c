/*
 * nat_process.c
 *
 * NAT Process function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/
#include "nat.h"
#include "nat_defs.h"


/***********************************************************
 *
 * Static Routines
 *
 **********************************************************/
static BOOL _NatIsBindingStale(NAT_ENTRY* pxNatEntry);
static OCTET _NatCheckChunkStatus(NATSTATE* pxNat, NAT_CHUNK* apxNatChunks[], DWORD dwSize);

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * NatInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hNat                 NAT Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG NatInstanceProcess(H_NETINSTANCE hNat)
{
  LONG lIdx;
  NATSTATE  *pxNat = (NATSTATE*) hNat;
  NAT_ENTRY *pxNatEntry, *pxNatEntryNext;

  NAT_CHECK_STATE((NATSTATE*) hNat);

#ifdef NATDBG_HI
  if (g_bNatDisplayBindings) {
    NatDisplayBindings(pxNat);
    g_bNatDisplayBindings = FALSE;
  }

  if (g_bNatDisplayPortForward) {
    NatDisplayPortForward(pxNat);
    g_bNatDisplayPortForward = FALSE;
  }
#endif


  /***********************************************************
   * Checks all the exsiting NAT bindings for timeout or
   * end of session. If any one of the conditions is
   * met, the binding is deleted.
   **********************************************************/

  for (lIdx = (NAT_HASH_SIZE - 1); lIdx >= 0; lIdx --) {

    if ((pxNatEntry = pxNat->apxLanHashTable[lIdx]) != NULL) {

      while (pxNatEntry) {

        pxNatEntryNext = pxNatEntry->pxLanNext;

        if (_NatIsBindingStale(pxNatEntry)) {
          NatDeleteBinding(pxNat, pxNatEntry);
        }

        pxNatEntry = pxNatEntryNext;

      }
    }
  }


  /*
   * Check for any empty chunks and free them.
   */
  pxNat->oNumUsedLocalChunks -= _NatCheckChunkStatus(pxNat, pxNat->apxNatChunksLocal, NAT_CHUNK_MAX_NUM_LOCAL);
  pxNat->oNumUsedChunks -= _NatCheckChunkStatus(pxNat, pxNat->apxNatChunks, NAT_CHUNK_MAX_NUM);
  return NAT_PROCESS_INTERVAL;
}


/*****************************************************************************
Function:
        NatTrimChunks()
Description:
    Trims the number of NAT chunks to achieve the target.
Arguments:
        NATSTATE*       pxNat                   NAT instance handle.
        OCTET           oTargetNumChunks        Target number of chunks.
Outputs:
        None.
Returns:
        None.
Revisions:
        26-Aug-2002                     Initial
*****************************************************************************/
void NatTrimChunks(NATSTATE* pxNat, OCTET oTargetNumChunks)
{
  if ((pxNat->oNumAllowedChunks != oTargetNumChunks) &&
      (pxNat->oNumUsedChunks > oTargetNumChunks)) {

    DWORD dwDelete = pxNat->oNumUsedChunks - oTargetNumChunks;

    NatSortChunks(pxNat);

    /*
     * Delete the oldest chunks.
     */
    while (dwDelete) {
      ASSERT(pxNat->apxNatChunks[pxNat->oNumUsedChunks - 1] != NULL);
      NatDeleteChunk(pxNat, pxNat->apxNatChunks[pxNat->oNumUsedChunks - 1]);
      pxNat->apxNatChunks[pxNat->oNumUsedChunks - 1] = NULL;
      pxNat->oNumUsedChunks --;
      dwDelete --;
    }
  }

  pxNat->oNumAllowedChunks = oTargetNumChunks;
}


/*
 * _NatIsBindingStale
 *   Checks the status of the given NAT binding. The
 *   bindings can be released under one of the following
 *   conditions.
 *   a. If any binding has been idle for more than
 *      NAT_BINDING_TIMEOUT.
 *   b. For TCP sessions, if the session has been closed
 *      for more than 2 * Maximum Segment Life.
 *   c. For UDP sessions, if the session has been idle for
 *      more than NAT_BINDING_UDP_TIMEOUT.
 *
 *  Args:
 *   pxNATEntry           NAT binding to be examined.
 *
 *  Return:
 *   TRUE                 Binding should be released.
 *   FALSE                Binding should be preserved.
 */
static BOOL _NatIsBindingStale(NAT_ENTRY* pxNatEntry)
{
  DWORD dwIdleTime;

  dwIdleTime =  NetGlobalTimerGet() - pxNatEntry->dwLastUsed;

  /*
   * Any binding older than NAT_BINDING_TIMEOUT is purged.
   */
  if (dwIdleTime > NAT_BINDING_TIMEOUT) {
    return (TRUE);
  }

  switch (pxNatEntry->oProtocolId) {

    case IPPROTO_UDP:
      if (dwIdleTime > NAT_BINDING_UDP_TIMEOUT) {
        return (TRUE);
      }
      break;

    case IPPROTO_TCP:
      if (((pxNatEntry->wFlags & (NAT_TCP_CLOSE_RECEIVE | NAT_TCP_CLOSE_SEND)) ==
            (NAT_TCP_CLOSE_RECEIVE | NAT_TCP_CLOSE_SEND)) &&
          (((dwIdleTime > NAT_BINDING_TCP_TIMEOUT) && (pxNatEntry->eType != NAT_BINDING_LOCAL)) ||
           ((dwIdleTime > NAT_BINDING_LOCAL_TCP_TIMEOUT) && (pxNatEntry->eType == NAT_BINDING_LOCAL)))) {
        /*
         * Check important note about the connection close
         * handling in NatUpdateTcpFlags() (in nat_tu.c)
         */
        return (TRUE);
      }
      break;

    case IPPROTO_ICMP:
      if (dwIdleTime > NAT_BINDING_ICMP_TIMEOUT) {
        return (TRUE);
      }
      break;


    default:
      break;
  }

  return (FALSE);
}


/*****************************************************************************
Function:
        _NatCheckChunkStatus()
Description:
        Tests if a chunk has any active binding and removes it if
        it does not.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        NAT_CHUNK*      apxNatChunks[]  Array of pointers to NAT chunks.
        DWORD           dwSize          Number of chunks.
Outputs:
        None.
Returns:
    OCTET                Number of chunks freed.
Revisions:
        23-Aug-2002                     Initial
*****************************************************************************/
static OCTET _NatCheckChunkStatus(NATSTATE* pxNat, NAT_CHUNK* apxNatChunks[], DWORD dwSize)
{
  LONG lIdx;
  OCTET oNumChunksFreed = 0;

  /*
   * Check for any empty chunks and free them.
   */
  for (lIdx = dwSize - 1; lIdx >= 0; lIdx--) {

    if (apxNatChunks[lIdx] != NULL) {
      LONG lCnt;
      DWORD dwSum = 0;

      for (lCnt = (NAT_CHUNK_NUM_BINDINGS >> 5) - 1; lCnt >= 0; lCnt--) {
        dwSum += apxNatChunks[lIdx]->adwBindingStatus[lCnt];
      }

      if (dwSum == 0) {
        NatDeleteChunk(pxNat, apxNatChunks[lIdx]);
        oNumChunksFreed ++;
        apxNatChunks[lIdx] = NULL;
      }
    }
  }

  return (oNumChunksFreed);
}
