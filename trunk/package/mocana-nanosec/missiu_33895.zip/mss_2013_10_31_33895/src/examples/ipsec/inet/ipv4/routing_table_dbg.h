/*
 * routing_table_dbg.h
 *
 * Routing table module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _ROUTING_TABLE_DBG_H_
#define _ROUTING_TABLE_DBG_H_

#ifndef NDEBUG

  #ifdef NETDBG_HI
    #ifndef ROUTINGTABLEDBG_HI
      #define ROUTINGTABLEDBG_HI
    #endif
  #endif

#else

  #ifdef ROUTINGTABLEDBG_HI
    #undef ROUTINGTABLEDBG_HI
  #endif

#endif

#include "netdbg.h"


/*
 * Constants
 */
#define ROUTINGTABLE_MAGIC_COOKIE 0x726f7461 /*"rota" = 0x726f7461*/


/*
 * Debug macros
 */
/*#ifdef ROUTINGTABLEDBG_HI*/
#if defined(ROUTINGTABLEDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define ROUTINGTABLE_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == ROUTINGTABLE_MAGIC_COOKIE));

  #define ROUTINGTABLE_SET_COOKIE(x) (x)->dwMagicCookie = ROUTINGTABLE_MAGIC_COOKIE
  #define ROUTINGTABLE_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define ROUTINGTABLE_DBGP(level, fmt, args...) do { \
    if (level <= g_dwRoutingTableDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define ROUTINGTABLE_DBG(level, x) do {  \
    if (level <= g_dwRoutingTableDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define ROUTINGTABLE_DBG_VAR(x)  x
#else
  #define ROUTINGTABLE_CHECK_STATE(x)
  #define ROUTINGTABLE_SET_COOKIE(x)
  #define ROUTINGTABLE_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define ROUTINGTABLE_DBGP
#else
  #define ROUTINGTABLE_DBGP(level, fmt, args...)
#endif
  #define ROUTINGTABLE_DBG(level, x)
  #define ROUTINGTABLE_DBG_VAR(x)
#endif

ROUTINGTABLE_DBG_VAR(MOC_EXTERN DWORD g_dwRoutingTableDebugLevel);

/*
 * Debug levels
 */
#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _ROUTING_TABLE_DBG_H_ */
