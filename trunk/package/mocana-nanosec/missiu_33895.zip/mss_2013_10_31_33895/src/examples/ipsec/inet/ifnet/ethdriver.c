 /*
 * Copyright Mocana Corp 2003-2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/


#include "NNstyle.h"
#include "ethdrv_flavor.h"
#include "stdlib.h"
#include "string.h"
#include "sys/socket.h" /* NNOS ntohx, htonx defs */
#include <netinet/in.h> /* Linux ntohx, htonx defs */
#include "dllist.h"
#include "pthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "ethernet.h"
#include "ethdrvdbg.h"
#include "sockapi.h"
#include "netsnmp.h"
#include "snmp_tcpip_data.h"
#include "netutils.h"
#include "nettransport.h"
#include "netnetwork.h"
#include "pthread.h"
#include "netnetwork.h"
#include "netdefs.h"
#include "netmain.h"
#include "ethlink.h"

#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <linux/if_ether.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/ethernet.h>
#include <linux/sockios.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "ethdrive_pvt.h"
/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/

ETHDRV_DBG_VAR(int g_dwEthDrvDebugLevel = 2);

#ifdef ETHERNETDBG_HI
CHAR *EthDrvProtoToString(WORD wProtocol);
#endif

/*****************************************************************************
 *
 * Constants
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

#define MAX_READ_BUFFER_SIZE 8192

/*****************************************************************************
 *
 * Local Functions
 *
 *****************************************************************************/


/*------------------------------------------------------------------*/

#define MACFMT "%02x:%02x:%02x:%02x:%02x:%02x"
#define MACPRINT(x) (x)[0],(x)[1],(x)[2],(x)[3],(x)[4],(x)[5]




/*------------------------------------------------------------------*/

/* Max Number of Intf */
EthDrvCB ethDrvCB[ETHDRV_MAXNUM_IF];

/*------------------------------------------------------------------*/
static int _EthDrv_initSocket (EthDrvCB * ethDrv);
/*------------------------------------------------------------------*/


static LONG
EthDrv_close(INODE *pxInode, struct file *pxFile)
{
    int oIfIdx;
    LONG status = 0;
    int lSockfd = ((int ) pxFile->private_data & ~ETH_DEV_FD_BIT);

#if (ETHDRV_MAXNUM_IF == 2)
    if (lSockfd == ethDrvCB[0].iFd)
         oIfIdx = ethDrvCB[0].index;
    else if (lSockfd == ethDrvCB[1].iFd)
         oIfIdx = ethDrvCB[1].index;
    else
         return -1 ;
#else
    oIfIdx = _EthDrvFns_fd2idx(lSockfd);
    if ( oIfIdx < 0 ) return -1;
#endif

    _EthDrvFns_close(ethDrvCB[oIfIdx].iFd);
    MBITMAP_clearIndex(xNetWrapper.pFdMap, (ethDrvCB[oIfIdx].iFd & !(DEV_FD_MASK)));
    memset(&ethDrvCB[oIfIdx],0,sizeof(EthDrvCB));
    ethDrvCB[oIfIdx].iFd = -1;
    pxFile->private_data = (void * )-1;
    ethDrvCB[oIfIdx].iState = ETH_DRV_STATE_CLOSED;

    return status;

}



static LONG
EthDrv_open(INODE *pxInode, struct file *pxFile)
{
    int oIfIdx;
    LONG status = 0;

#if (ETHDRV_MAXNUM_IF == 2)
    if (!(strncmp(pxInode->private_data,ethDrvCB[0].iName,strlen(ethDrvCB[0].iName))))
         oIfIdx = ethDrvCB[0].index;
    else if (!(strncmp(pxInode->private_data,ethDrvCB[1].iName,strlen(ethDrvCB[1].iName))))
         oIfIdx = ethDrvCB[1].index;
    else
         return -1 ;
#else
    if ( strncmp(pxInode->private_data, ETHERNET_DRIVERNAME0,
            strlen(ETHERNET_DRIVERNAME0) ) &&
         strncmp(pxInode->private_data, ETHERNET_DRIVERNAME1,
            strlen(ETHERNET_DRIVERNAME1) ) )
    return -1;

    oIfIdx = _EthDrvFns_allocidx();
    ASSERT(oIfIdx >= 0);
#endif

    status =  _EthDrv_initSocket(&ethDrvCB[oIfIdx]);


    if (status >=0) {
        pxFile->private_data = (void * )(ethDrvCB[oIfIdx].iFd | ETH_DEV_FD_BIT);
        return ethDrvCB[oIfIdx].iFd | ETH_DEV_FD_BIT;
    }

    return status;
}

static LONG
EthDrv_read(INODE *pxInode, struct file *pxFile, void * buff, size_t dwCnt)
{
    LONG status = OK;
#define MN_ETHDRIVER_OFFSET    2
    static unsigned char *frame = NULL;
    struct ethhdr *eth_hdr;
    NETIFCONF  *pxIfConf;
    NETIFSTATE *pxIfState;
    int oIfIdx;
    NETWRAPPER *pxNetWrapper;
    NETPACKET xPacket;
    NETPACKETACCESS xAccess;
    NETIFID xNetIfId;
    WORD wSize , wTxAvailableSpace ;
    OCTET *poPayload;
    H_NETINTERFACE hIf;
    NET_DRV_BUFFER * xndbTxPacket;
    DLLIST * xdllTx = (DLLIST *)buff;


    if ( frame == NULL )
        frame = MALLOC(MAX_READ_BUFFER_SIZE);

    int ifd = ((int ) pxFile->private_data & ~ETH_DEV_FD_BIT);

#if (ETHDRV_MAXNUM_IF == 2)
    if (ifd == ethDrvCB[0].iFd)
         oIfIdx = ethDrvCB[0].index;
    else if (ifd == ethDrvCB[1].iFd)
         oIfIdx = ethDrvCB[1].index;
    else
         return 0 ;
#else
    oIfIdx = _EthDrvFns_fd2idx(ifd);
    if ( oIfIdx < 0 ) return 0;
#endif

    if ( dwCnt == 0 && _EthDrvFns_select(ifd, 0, 0) == 0 ){
        ETHDRV_DBGP(REPETITIVE, "EthDrv_read(): Nothing to read on intf %d\n",
            oIfIdx);
    return 0;
    }

    xNetIfId.oIfIdx = oIfIdx;
    xNetIfId.wVlan  = 0;

    pxNetWrapper = NETGETWRAPPER;

    pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);

    pxIfState = NETGETIFSTATE(pxIfConf);

    ETHDRV_DBGP(REPETITIVE, "EthDrv_read(): Received Ether Packet on intf %d\n",
                oIfIdx );
    wTxAvailableSpace = _EthDrvFns_read(ifd, frame + MN_ETHDRIVER_OFFSET,
                MAX_READ_BUFFER_SIZE - MN_ETHDRIVER_OFFSET);

    if (wTxAvailableSpace > 0)
    {
        ETHDRV_DBGP(REPETITIVE, "EthDrv_read(): Read %d on intf %d\n",
            wTxAvailableSpace, oIfIdx);
    }
    else
    {
        ETHDRV_DBGP(REPETITIVE, "EthDrv_read(): Error reading on intf %d, %d\n",
            oIfIdx, wTxAvailableSpace);
        return 0 ;
    }

    eth_hdr = (struct ethhdr *)(frame + MN_ETHDRIVER_OFFSET);
    ETHDRV_DBGP(REPETITIVE, "EthDrv_read(): Received Eth Proto 0x%x To  "
    "%x.%x.%x.%x.%x.%x From %x.%x.%x.%x.%x.%x on intf %d\n",
           htons(eth_hdr->h_proto),
           eth_hdr->h_dest[0],       /* destination eth addr */
           eth_hdr->h_dest[1],       /* destination eth addr */
           eth_hdr->h_dest[2],       /* destination eth addr */
           eth_hdr->h_dest[3],       /* destination eth addr */
           eth_hdr->h_dest[4],       /* destination eth addr */
           eth_hdr->h_dest[5],       /* destination eth addr */

           eth_hdr->h_source[0],     /* source ether addr    */
           eth_hdr->h_source[1],     /* source ether addr    */
           eth_hdr->h_source[2],     /* source ether addr    */
           eth_hdr->h_source[3],     /* source ether addr    */
           eth_hdr->h_source[4],     /* source ether addr    */
           eth_hdr->h_source[5],    /* source ether addr    */
       oIfIdx);

    /* call llreceive fn */
    /*memcpy it into a NETBUFFER Struct */
  /* Now Make the packet and send it */
  {

    xndbTxPacket = (NET_DRV_BUFFER *)MALLOC (sizeof(NET_DRV_BUFFER));
    ASSERT(xndbTxPacket != NULL);
    xndbTxPacket->dwLength = wTxAvailableSpace;
    xndbTxPacket->wSize = wTxAvailableSpace;
    xndbTxPacket->wOffset = MN_ETHDRIVER_OFFSET;
    xndbTxPacket->dwLength += MN_ETHDRIVER_OFFSET; /* Adding Offset Length */
    xndbTxPacket->wSize += MN_ETHDRIVER_OFFSET; /* Adding Offset Length */
    xndbTxPacket->pfnFree = NetFree;
#if 0
    xndbTxPacket->poData = (OCTET *) MALLOC(xndbTxPacket->wOffset + (wTxAvailableSpace *sizeof(OCTET)));
    ASSERT(xndbTxPacket->poData != NULL);
      /*copy payload*/
    (void*)memcpy((void*)(xndbTxPacket->poData +xndbTxPacket->wOffset ),
                    pvBuff,wTxAvailableSpace);
#else
    xndbTxPacket->poData = frame;
    frame = NULL; /* prepare for next call */
#endif

    DLLIST_append(xdllTx,xndbTxPacket);
#if 0
  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
    ASSERT(oIfIdx != NETIFIDX_ANY);

    /* Allocate and send the packet */
    xAccess.wOffset = 0;


    wSize = wTxAvailableSpace ;

      /* Make sure it is big enough */
    if (wSize < xNetWrapper.pxIfConf[oIfIdx].wLtu) {
      wSize = xNetWrapper.pxIfConf[oIfIdx].wLtu;
    }

    poPayload = (OCTET *)MALLOC(wSize);
    ASSERT(poPayload != NULL);

    xAccess.wLength = wTxAvailableSpace;

    NETPAYLOAD_CREATE((&(xPacket.pxPayload)),NetFree,(&xNetWrapper.xMutex),
                        (poPayload),(wSize));

      /*copy payload*/
    (void*)memcpy((void*)(poPayload + xAccess.wOffset),
                    pvBuff,wTxAvailableSpace);

#if 0
    pxIfState->pfnBottomLinkRxCbk
      (pxIfState->hBottomLinkInst,pxIfState->hBottomLinkIf,
       &xPacket,&xAccess,(H_NETDATA)xNetIfId);
#endif

    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
  }

exit:
    return wTxAvailableSpace;
}

/*------------------------------------------------------------------*/

static void
EthDrv_select(int fd)
{
    _EthDrvFns_select(fd, 1, 0);
}


/*------------------------------------------------------------------*/



static LONG EthDrv_write(INODE *pxInode, struct file *pxFile, void *buff, size_t nbytes)
{
    LONG status = 0;
    struct ethhdr *eHdr;
    struct sockaddr sa;
    OCTET oIfIdx;
    NET_DRV_BUFFER * xndbTxPacket;
    DLLIST * xdllTx = (DLLIST *)buff;
    NET_DRV_BUFFER * pndbTxPacket = DLLIST_read(xdllTx);
    int lSockfd = ((int ) pxFile->private_data & ~ETH_DEV_FD_BIT);

#if (ETHDRV_MAXNUM_IF == 2)
    if (lSockfd == ethDrvCB[0].iFd)
         oIfIdx = ethDrvCB[0].index;
    else if (lSockfd == ethDrvCB[1].iFd)
         oIfIdx = ethDrvCB[1].index;
    else
         return 0 ;
#else
    oIfIdx = _EthDrvFns_fd2idx(lSockfd);
    if ( oIfIdx < 0 ) return 0;
#endif

#if defined(__RTOS_VXWORKS__) && defined(__ENABLE_MOCANA_ZEROCOPY__)
     pndbTxPacket->wOffset  += ETH_DRIVERHDRSIZE ; /* Currently 2 Bytes .. May need to make it 32 Bytes */
     pndbTxPacket->dwLength -= ETH_DRIVERHDRSIZE;
     printf("EthDrv_Write poPayload %p, Offset %d Length %d \n",pndbTxPacket->poData,pndbTxPacket->wOffset,pndbTxPacket->dwLength);
     status = _EthDrvFns_write(lSockfd, (ubyte *)pndbTxPacket, pndbTxPacket->dwLength);
     status = nbytes; /* We take control of the Buffer from here . The driver will free this buffer Now*/
#else
     status = _EthDrvFns_write(lSockfd, pndbTxPacket->poData+pndbTxPacket->wOffset+2, nbytes - 2);
#endif
     ETHDRV_DBGP(REPETITIVE, "EthDrv_write(): Wrote %d bytes \n",(int)status );

     /*pndbTxPacket->pfnFree (pndbTxPacket->poData); */
exit:
    return status;
}

/*------------------------------------------------------------------*/

static int
_EthDrv_initSocket(EthDrvCB * ethDrv)
{

    LONG status = OK;
    status = _EthDrvFns_open(ethDrv);
exit:
    return status;
}

/*
 * EthDr_ioctl
 *  Handle ioctl requests for socket file descriptors
 *
 *  Arg:
 *   inode                           the inode for the ioctled fd
 *   pxFile                          file structure for ioctled fd.
 *   dwRequest                       ioctl request code
 *   pArgList                        variable argument list
 *
 *  Return:                          0 success, -1 failure
 */
LONG EthDrv_ioctl(INODE* inode, struct file *pxFile, DWORD dwRequest,
                 va_list pArgList)
{
  LONG lReturn = 0;
  LONG lFd;
#if 0
  static int count = 0;
#endif

    int oIfIdx;
    int lSockfd = ((int ) pxFile->private_data & ~ETH_DEV_FD_BIT);

#if (ETHDRV_MAXNUM_IF == 2)
    if (lSockfd == ethDrvCB[0].iFd)
         oIfIdx = ethDrvCB[0].index;
    else if (lSockfd == ethDrvCB[1].iFd)
         oIfIdx = ethDrvCB[1].index;
    else
         return -1 ;
#else
    oIfIdx = _EthDrvFns_fd2idx(lSockfd);
    if ( oIfIdx < 0 ) return -1;
#endif


    switch(dwRequest) {
        case ETHERDRV_LINK_CHECK:
#if 0
            count++;
        if ( (count % 25) == 0 )
                printf("Ethdriver LINK_CHECK count: %u\n", count);
            if ( (count > 1000 && count < 1500) && oIfIdx < 8 )
            lReturn = LINK_100_MBPS;
        else
#endif
            lReturn = LINK_UP |LINK_100_MBPS;
            break;
        default:
            break;

    }
#if 0
 /*
   * lock the mutex for the all function.
   * Despite its length, there is not much processing,
   * and all bits need protection
   */
  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  if ((dwRequest == SIOCOPEN) || (dwRequest == SIOCACCEPT)) {
    LONG lFamily,lType,lProtocol;
    H_NETINTERFACE hIf = (H_NETINTERFACE)0;

    /* Open the socket. Can do without, as that's where the
       file descriptor private data is set */

    lFd =       va_arg(pArgList, LONG);
    lFamily =   va_arg(pArgList, LONG);
    lType =     va_arg(pArgList, LONG);
    lProtocol = va_arg(pArgList, LONG);

    if (dwRequest == SIOCACCEPT) {
      hIf = (H_NETINTERFACE)va_arg(pArgList, LONG);
    }
    pxFile->private_data = (void *)lFd;

    if (SocketCreate(lFd,lFamily,lType,lProtocol,hIf) < 0) {
      ASSERT(0);
      errno = ENOBUFS;
      lReturn = -ENOBUFS;
    }
  }
#endif
  return lReturn;
}

struct file_operations fps;

int
EthDrv_init()
{
/* register the open/close/read write/functions */
    LONG status = 0 ;
    OCTET  major = DEVICE_MAJOR_ETHIF;
    int i;

    fps.open = EthDrv_open;
    fps.close = EthDrv_close;
    fps.read = EthDrv_read;
    fps.write = EthDrv_write;
    fps.ioctl = EthDrv_ioctl;

#if (ETHDRV_MAXNUM_IF == 2)
    ethDrvCB[0].index = 0;
    strncpy(ethDrvCB[0].intfName,IF0INTF_NAME,strlen(IF0INTF_NAME));;
    strncpy(ethDrvCB[0].iName,ETHERNET_DRIVERNAME0,strlen(ETHERNET_DRIVERNAME0));;
    ethDrvCB[0].iState = ETH_DRV_STATE_CLOSED;
    ethDrvCB[0].iFd =  -1;
    status  = register_chrdev( major, ETHERNET_DRIVERNAME0,&fps) ;

#ifdef MHX
    ethDrvCB[1].index = 1;
    /*strncpy(ethDrvCB[1].intfName,IF1INTF_NAME,strlen(IF1INTF_NAME));; */
    strncpy(ethDrvCB[1].intfName,IF0INTF_NAME,strlen(IF0INTF_NAME));;
    strncpy(ethDrvCB[1].iName,ETHERNET_DRIVERNAME1,strlen(ETHERNET_DRIVERNAME1));;
    ethDrvCB[1].iState = ETH_DRV_STATE_CLOSED;
    ethDrvCB[1].iFd =  -1;

    status  = register_chrdev( major, ETHERNET_DRIVERNAME1,&fps) ;
#endif
#else
    for(i=0; i < ETHDRV_MAXNUM_IF; i++){
        ethDrvCB[i].index = i;
        strncpy(ethDrvCB[i].intfName, IF0INTF_NAME, strlen(IF0INTF_NAME));;
        strncpy(ethDrvCB[i].iName, ETHERNET_DRIVERNAME0,
                        strlen(ETHERNET_DRIVERNAME0));
        ethDrvCB[i].iState = ETH_DRV_STATE_CLOSED;
        ethDrvCB[i].iFd =  -1;
    }
    status  = register_chrdev( major, ETHERNET_DRIVERNAME0, &fps) ;
    status  = register_chrdev( major, ETHERNET_DRIVERNAME1, &fps) ;
#endif
    return status;
}
