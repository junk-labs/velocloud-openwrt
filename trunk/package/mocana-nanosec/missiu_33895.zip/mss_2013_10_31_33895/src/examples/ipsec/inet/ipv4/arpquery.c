/*
 * arpquery.c
 *
 * Arp instance query function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "arpdefs.h"

/*****************************************************************************
 *
 * Implemetation
 *
 *****************************************************************************/

/*
 * ArpInstanceQuery
 *  Query a ARP Instance Option
 *
 *  Args:
 *   hArp                       ARP instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG ArpInstanceQuery(H_NETINSTANCE hArp,OCTET oOption,
                      H_NETDATA *phData)
{
  ARPSTATE *pxArp = (ARPSTATE *)hArp;
  LONG lReturn = (LONG)NETERR_NOERR;

  ARP_CHECK_STATE(pxArp);

  switch(oOption) {

  case NETOPTION_MALLOC:
    *phData = (H_NETDATA)pxArp->pfnMalloc;
    break;

  case NETOPTION_FREE:
    *phData = (H_NETDATA)pxArp->pfnFree;
    break;

  case NETOPTION_PAYLOADMUTEX:
    *phData = (H_NETDATA)pxArp->pxMutex;
    break;

  case NETOPTION_OFFSET:
    *phData = (H_NETDATA)pxArp->wOffset;
    break;

  case NETOPTION_TRAILER:
    *phData = (H_NETDATA)pxArp->wTrailer;
    break;

  case NETOPTION_NETCBK:
    *phData = (H_NETDATA)pxArp->pfnNetCbk;
    break;

  case ARPOPTION_CACHESIZE:
#ifdef ARP_CACHE_32
    *((OCTET*)phData) = pxArp->oArpTableSize;
#else
    *((OCTET*)phData) = pxArp->wArpHashSize; /*Looks like need to traverse the table once again.*/
#endif
    break;

  case ARPOPTION_ETHADDRESS:
    {
      ARPETHDATA *pxEthData = (ARPETHDATA*)phData;
      MOC_MEMCPY((ubyte *)pxEthData->aoEthAddr,
            (ubyte *) pxArp->aaoIfEthAddr[pxEthData->oIfIdx], ARP_ETHLEN);
    }
    break;

  default:
    lReturn = (LONG)NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}
