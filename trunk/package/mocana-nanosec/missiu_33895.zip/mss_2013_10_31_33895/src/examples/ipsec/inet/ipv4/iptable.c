/*
 * iptable.c
 *
 * IP table main file
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "iptable_flavor.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "iptable.h"
#include "iptabledefs.h"
#include "iptabledbg.h"
#include "netdbg.h"


/*****************************************************************************
 *
 * global variables
 *
 *****************************************************************************/

IPTABLE_DBG_VAR(DWORD g_dwIpTableDebugLevel = 1);

/*
 * Ip Table
 */
IPTABLESTATE xIpTable;

/*****************************************************************************
 *
 * Local function declaration
 *
 *****************************************************************************/
#ifdef IPTABLE_UNUSED
LONG IpTableRepositoryGetAll(IPTABLEREPOSITORY *pxRepository,
                             IPTABLE *pxTable);
#endif
LONG IpTableRepositorySetAddr(IPTABLEREPOSITORY *pxRepository,
                              IPTABLEENTRY *pxTemplate);
LONG IpTableRepositorySetNetMask(IPTABLEREPOSITORY *pxRepository,
                                 IPTABLEENTRY *pxTemplate);
LONG IpTableRepositorySetVlan(IPTABLEREPOSITORY *pxRepository,
                              IPTABLEENTRY *pxTemplate);
LONG IpTableRepositorySetIfIdx(IPTABLEREPOSITORY *pxRepository,
                               IPTABLEENTRY *pxTemplate);
LONG IpTableRepositoryAddEntry(IPTABLEREPOSITORY *pxRepository,
                               IPTABLEENTRY *pxEntry);
LONG IpTableRepositoryDelEntry(IPTABLEREPOSITORY *pxRepository,
                               IPTABLEENTRY *pxTemplate);


void _IpTablePrintIpTableEntry(IPTABLEENTRY *pxIpTableEntry);
void _IpTablePrintIpTableRepository(IPTABLEREPOSITORY *pxIpTableRepository);


/*****************************************************************************
 *
 * Local function
 *
 *****************************************************************************/

#ifdef IPTABLE_UNUSED
/*
 * IpTableRepositoryGetAll
 *  Fill up the table with all entries matching the template
 *
 *  Args:
 *   pxRepository              repository pointer
 *   pxTable                   Table to fill
 *
 *  Return:
 *   >=0
 */
LONG IpTableRepositoryGetAll(IPTABLEREPOSITORY *pxRepository,
                             IPTABLE *pxTable)
{
  IPTABLEENTRY *pxEntry, *pxEntryEnd;

  pxEntry = pxRepository->pxEntryTable;
  pxEntryEnd = pxEntry + pxRepository->dwTableSize;

  pxTable->xRepository.dwTableSize = 0;

  while (pxEntry < pxEntryEnd) {
    if (IpTableMatch(pxEntry,&(pxTable->xTemplate))) {
      IpTableRepositoryAddEntry(&(pxTable->xRepository),pxEntry);
    }
    pxEntry ++;
  }

  return 0;
}
#endif /* #ifdef IPTABLE_UNUSED */

/*
 * IpTableRepositorySetAddr
 *  Set the addr for all matching entries. The address
 *  is the one provided in the template; The other fields
 *  (except netmask) are used for matching.
 *  If no match is found, will create an entry
 *
 *  Args:
 *   pxRepository              repository pointer
 *   pxTemplate                template
 *
 *  Return:
 *   >=0
 */
LONG IpTableRepositorySetAddr(IPTABLEREPOSITORY *pxRepository,
                              IPTABLEENTRY *pxTemplate)
{
  LONG lMatchCount = 0;
  IPTABLEENTRY *pxEntry,*pxEntryEnd;
  OCTET oType;


  ASSERT(pxTemplate != NULL);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPTABLE, INET_DBG_LEVEL_NORMAL))
  {
    /*IPTABLE_DBGP(NORMAL,"IpTableRepositorySetAddr:dwAddr=%ld.%ld.%ld.%ld\n",
      IPADDRDISPLAY(pxTemplate->dwAddr));*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IpTableRepositorySetAddr:dwAddr = ", pxTemplate->dwAddr);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /* Set template address type to ANY */
  oType = pxTemplate->eAddrType;
  pxTemplate->eAddrType = IPADDRT_ANY;

  pxEntry = pxRepository->pxEntryTable;
  pxEntryEnd = pxEntry + pxRepository->dwTableSize;

  while (pxEntry < pxEntryEnd) {
    if (IpTableMatch(pxEntry,pxTemplate)) {
      lMatchCount ++;
      pxEntry->dwAddr = pxTemplate->dwAddr;
      pxEntry->eAddrType = oType;
    }
    pxEntry ++;
  }

  pxTemplate->eAddrType = oType;

  if (lMatchCount == 0) {
    IpTableRepositoryAddEntry(pxRepository,pxTemplate);
  }

  return lMatchCount;
}

/*
 * IpTableRepositorySetNetMask
 *  Set the netmask for all matching entries. The netmask
 *  is the one provided in the template; The other fields
 *  are used for matching
 *
 *  Args:
 *   pxRepository              repository pointer
 *   pxTemplate                template
 *
 *  Return:
 *   >=0
 */
LONG IpTableRepositorySetNetMask(IPTABLEREPOSITORY *pxRepository,
                                 IPTABLEENTRY *pxTemplate)
{
  LONG lMatchCount = 0;
  IPTABLEENTRY *pxEntry, *pxEntryEnd;

  ASSERT(pxTemplate != NULL);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPTABLE, INET_DBG_LEVEL_NORMAL))
  {
    /*IPTABLE_DBGP(NORMAL,"IpTableRepositorySetNetMask:dwAddr=%ld.%ld.%ld.%ld\n",
      IPADDRDISPLAY(pxTemplate->u.dwIpNetMask));*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IpTableRepositorySetNetMask:dwAddr = ",
                              pxTemplate->u.dwIpNetMask);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  pxEntry = pxRepository->pxEntryTable;
  pxEntryEnd = pxEntry + pxRepository->dwTableSize;

  while (pxEntry < pxEntryEnd) {
    if (IpTableMatch(pxEntry,pxTemplate)) {
      lMatchCount ++;
      pxEntry->u.dwIpNetMask = pxTemplate->u.dwIpNetMask;
    }
    pxEntry ++;
  }

  if (lMatchCount == 0) {
    IpTableRepositoryAddEntry(pxRepository,pxTemplate);
  }

  return lMatchCount;
}

/*
 * IpTableRepositorySetVlan
 *  Set the default vlan for all matching entries. The Vlan
 *  is the one provided in the template; The other fields
 *  (except netmask) are used for matching
 *
 *  Args:
 *   pxRepository              repository pointer
 *   pxTemplate                template
 *
 *  Return:
 *   >=0
 */
LONG IpTableRepositorySetVlan(IPTABLEREPOSITORY *pxRepository,
                              IPTABLEENTRY *pxTemplate)
{
  IPTABLEENTRY *pxEntry, *pxEntryEnd;
  WORD wVlan;
  LONG lMatchCount = 0;

  ASSERT(pxTemplate != NULL);
  wVlan = pxTemplate->wDefaultVlan;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPTABLE, INET_DBG_LEVEL_NORMAL))
  {
    /*IPTABLE_DBGP(NORMAL,"IpTableRepositorySetVlan = %d\n",wVlan);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpTableRepositorySetVlan = ", wVlan);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /* Set the Template Vlan to "any" */
  pxTemplate->wDefaultVlan = NETVLAN_ANY;

  pxEntry = pxRepository->pxEntryTable;
  pxEntryEnd = pxEntry + pxRepository->dwTableSize;

  while (pxEntry < pxEntryEnd) {
    if (IpTableMatch(pxEntry,pxTemplate)) {
      lMatchCount ++;
      pxEntry->wDefaultVlan = wVlan;
    }
    pxEntry ++;
  }

  if (lMatchCount == 0) {
    IpTableRepositoryAddEntry(pxRepository,pxTemplate);
  }

  /* Reset the template Vlan value */
  pxTemplate->wDefaultVlan = wVlan;

  return lMatchCount;
}

/*
 * IpTableRepositoryIfIdx
 *  Set the interface idx for all matching entries. The idx
 *  is the one provided in the template; The other fields
 *  (except netmask) are used for matching
 *
 *  Args:
 *   pxRepository              repository pointer
 *   pxTemplate                template
 *
 *  Return:
 *   >=0
 */
LONG IpTableRepositorySetIfIdx(IPTABLEREPOSITORY *pxRepository,
                               IPTABLEENTRY *pxTemplate)
{
  IPTABLEENTRY *pxEntry, *pxEntryEnd;
  OCTET oIfIdx;
  LONG lMatchCount = 0;

  ASSERT(pxTemplate != NULL);
  oIfIdx = pxTemplate->oIfIdx;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPTABLE, INET_DBG_LEVEL_NORMAL))
  {
    /*IPTABLE_DBGP(NORMAL,"IpTableRepositorySetIfIdx = %d\n",oIfIdx);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpTableRepositorySetIfIdx = ", oIfIdx);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /* Set the Template IfIdx to "any" */
  pxTemplate->oIfIdx = NETIFIDX_ANY;

  pxEntry = pxRepository->pxEntryTable;
  pxEntryEnd = pxEntry + pxRepository->dwTableSize;

  while (pxEntry < pxEntryEnd) {
    if (IpTableMatch(pxEntry,pxTemplate)) {
      lMatchCount ++;
      pxEntry->oIfIdx = oIfIdx;
    }
    pxEntry ++;
  }

  if (lMatchCount == 0) {
    IpTableRepositoryAddEntry(pxRepository,pxTemplate);
  }

  /* Reset the template IfIdx value */
  pxTemplate->oIfIdx = oIfIdx;

  return lMatchCount;
}

/*
 * IpTableRepositoryAddEntry
 *  Add an entry
 *
 *  Args:
 *   pxRepository              repository pointer
 *   pxEntry                   entry
 *
 *  Return:
 *   >=0
 */
LONG IpTableRepositoryAddEntry(IPTABLEREPOSITORY *pxRepository,
                               IPTABLEENTRY *pxEntry)
{
  /* Just add the entry: do not check if it exists
     already */

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPTABLE, INET_DBG_LEVEL_NORMAL))
  {
    /*IPTABLE_DBGP(NORMAL,"IpTableRepositoryAddEntry\n");*/
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IpTableRepositoryAddEntry");
  }

  {
      IPTABLEENTRY *pxTempEntryTable;

      pxTempEntryTable = (IPTABLEENTRY *)MALLOC(
                (pxRepository->dwTableSize+1)*sizeof(IPTABLEENTRY));

      ASSERT(pxTempEntryTable);
      MOC_MEMCPY((ubyte *)pxTempEntryTable,
            (ubyte *)(pxRepository->pxEntryTable),
            pxRepository->dwTableSize*sizeof(IPTABLEENTRY));
      FREE(pxRepository->pxEntryTable);
      pxRepository->pxEntryTable = pxTempEntryTable;
      pxRepository->dwTableSize++;
  }

  MOC_MEMCPY((ubyte *)
         (pxRepository->pxEntryTable + (pxRepository->dwTableSize -1)),
         (ubyte *)pxEntry,sizeof(IPTABLEENTRY));

  IPTABLE_DBG(NORMAL,_IpTablePrintIpTableEntry(pxEntry));

  return 0;
}

/*
 * IpTableRepositoryDelEntry
 *  Delete an entry
 *
 *  Args:
 *   pxRepository              repository pointer
 *   pxEntry                   entry
 *
 *  Return:
 *   >=0
 */
LONG IpTableRepositoryDelEntry(IPTABLEREPOSITORY *pxRepository,
                               IPTABLEENTRY *pxTemplate)
{
  DWORD dw;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPTABLE, INET_DBG_LEVEL_NORMAL))
  {
    /*IPTABLE_DBGP(NORMAL,"IpTableRepositoryDelEntry\n");*/
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IpTableRepositoryDelEntry");
  }

  for (dw=0;dw < pxRepository->dwTableSize; dw ++) {
    IPTABLEENTRY *pxEntry = pxRepository->pxEntryTable + dw;
    if (IpTableMatch(pxEntry,pxTemplate)) {
      MOC_MEMMOVE((ubyte *)pxEntry,(ubyte *)(pxEntry +1),
              ((--pxRepository->dwTableSize) - dw) * sizeof(IPTABLEENTRY));
    }
  }

  {
      IPTABLEENTRY *pxTempEntryTable;

      pxTempEntryTable = (IPTABLEENTRY *)MALLOC(
                (pxRepository->dwTableSize)*sizeof(IPTABLEENTRY));

      ASSERT(pxTempEntryTable);
      MOC_MEMCPY((ubyte *)pxTempEntryTable,
            (ubyte *)(pxRepository->pxEntryTable),
            pxRepository->dwTableSize*sizeof(IPTABLEENTRY));
      FREE(pxRepository->pxEntryTable);
      pxRepository->pxEntryTable = pxTempEntryTable;
  }

  IPTABLE_DBG(NORMAL,_IpTablePrintIpTableEntry(pxTemplate));

  return 0;

}


/*****************************************************************************
 *
 * API function
 *
 *****************************************************************************/


/*
 * IpTableInitialize
 *  Initializes the ip tables
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpTableInitialize(void)
{
  /* Initialise the DEBUG symbol to ERROR */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_IPTABLE, INET_DBG_LEVEL_ERROR);

  MOC_MEMSET((ubyte *)&(xIpTable),0x00,sizeof(IPTABLESTATE));

  return 0;
}

/*
 * IpTableTerminate
 *  Terminates the ip tables
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpTableTerminate(void)
{

  if (xIpTable.xIpRepository.pxEntryTable != NULL) {
    FREE(xIpTable.xIpRepository.pxEntryTable);
  }
#ifdef IPTABLE_MCAST
  if (xIpTable.xMcastRepository.pxEntryTable != NULL) {
    FREE(xIpTable.xMcastRepository.pxEntryTable);
  }
#endif
#ifdef IPTABLE_PPP
  if (xIpTable.xPppRepository.pxEntryTable != NULL) {
    FREE(xIpTable.xPppRepository.pxEntryTable);
  }
#endif

  DEBUG({
    MOC_MEMSET((ubyte *)&(xIpTable),0x00,sizeof(IPTABLESTATE));
  });

  return 0;
}

/*
 * IpTableMsg
 *  Initializes the ip tables
 *
 *  Args:
 *   oMsg              Msg code. See defines above
 *   hData             Data handle. specifics defined for each messages
 *                     (see message definition above)
 *
 *  Return:
 *   < 0 == errors. For specific code, see message definition
 */
LONG IpTableMsg(OCTET oMsg,H_NETDATA hData)
{
  LONG lReturn = NETERR_NOERR;
  IPTABLEENTRY *pxEntry = (IPTABLEENTRY *)hData;

  ASSERT(pxEntry != NULL);

  switch(oMsg) {
  case IPTABLEMSG_ADDENTRY:
    {
      IPTABLEREPOSITORY *pxIpTableRepository = NULL;

      switch (pxEntry->eAddrType) {

        case IPADDRT_MYADDR:
          pxIpTableRepository = &xIpTable.xIpRepository;
          pxEntry->u.dwIpNetMask = IpAddrGetMask(pxEntry->dwAddr);
          break;

#ifdef IPTABLE_PPP
        case IPADDRT_PPPPEER:
          pxIpTableRepository = &xIpTable.xPppRepository;
          pxEntry->u.dwIpNetMask = 0xFFFFFFFF;
          break;
#endif

#ifdef IPTABLE_MCAST
        case IPADDRT_MULTICAST:
        case IPADDRT_MULTICASTJOINED:
        case IPADDRT_MULTICASTJOINEDPROXY:
        case IPADDRT_MULTICASTJOINEDSOCKPROXY:
          {
            IPTABLEENTRY* pxDefault;

            pxIpTableRepository = &xIpTable.xMcastRepository;
            if ((pxDefault = IpTableRepositoryFindDefault(pxIpTableRepository, pxEntry)) != NULL) {
              /* The entry already exists ... */
              pxDefault->u.xMcast.wMcastUserCount ++;
              if (pxDefault->eAddrType != pxEntry->eAddrType) {
                pxDefault->eAddrType = IPADDRT_MULTICASTJOINEDSOCKPROXY;
                pxDefault->oIfIdx = NETIFIDX_ANY;
              }
              pxIpTableRepository = NULL;
            } else {
              pxEntry->u.xMcast.wMcastUserCount = 1;
            }
          }
          break;
#endif /* IPTABLE_MCAST */

        default:
          ASSERT(0);
          lReturn = NETERR_UNKNOWN;
          break;
      }

      if (pxIpTableRepository) {
        IpTableRepositoryAddEntry(pxIpTableRepository, pxEntry);
      }
    }
    break;

  case IPTABLEMSG_DELENTRY:
    {
      IPTABLEREPOSITORY *pxIpTableRepository = NULL;

      switch (pxEntry->eAddrType) {

        case IPADDRT_MYADDR:
          pxIpTableRepository = &xIpTable.xIpRepository;
          break;

#ifdef IPTABLE_PPP
        case IPADDRT_PPPPEER:
          pxIpTableRepository = &xIpTable.xPppRepository;
          break;
#endif

#ifdef IPTABLE_MCAST
        case IPADDRT_MULTICAST:
        case IPADDRT_MULTICASTJOINED:
        case IPADDRT_MULTICASTJOINEDPROXY:
        case IPADDRT_MULTICASTJOINEDSOCKPROXY:
          {
            IPTABLEENTRY *pxDefault;

            pxIpTableRepository = &xIpTable.xMcastRepository;
            if ((pxDefault = IpTableRepositoryFindDefault(pxIpTableRepository, pxEntry)) != NULL) {
              /* The entry already exists ... */
              pxDefault->u.xMcast.wMcastUserCount --;

              if (pxDefault->u.xMcast.wMcastUserCount != 0) {
                pxIpTableRepository = NULL;

                if (pxDefault->eAddrType == IPADDRT_MULTICASTJOINEDSOCKPROXY) {
                  if (pxEntry->eAddrType == IPADDRT_MULTICASTJOINED) {
                    pxDefault->eAddrType = IPADDRT_MULTICASTJOINEDPROXY;
                  } else {
                    pxDefault->eAddrType = IPADDRT_MULTICASTJOINED;
                  }
                }
              }
            }
          }
          break;
#endif /* #ifdef IPTABLE_MCAST */

        default:
          ASSERT(0);
          lReturn = NETERR_UNKNOWN;
          break;
      }

      if (pxIpTableRepository) {
        IpTableRepositoryDelEntry(pxIpTableRepository, pxEntry);
      }
    }
    break;

  case IPTABLEMSG_SETNETMASK:
    lReturn = IpTableRepositorySetNetMask(&(xIpTable.xIpRepository),pxEntry);
    break;

  case IPTABLEMSG_SETVLAN:
    lReturn = IpTableRepositorySetVlan(&(xIpTable.xIpRepository),pxEntry);
    break;

#ifdef IPTABLE_UNUSED
  case IPTABLEMSG_SETIF:
    lReturn = IpTableRepositorySetIfIdx(&(xIpTable.xIpRepository),pxEntry);
    break;
#endif

  case IPTABLEMSG_SETADDR:
    {
      IPTABLEREPOSITORY* pxIpTableRepository = NULL;

      switch (pxEntry->eAddrType) {

        case IPADDRT_MYADDR:
          pxEntry->u.dwIpNetMask = IpAddrGetMask(pxEntry->dwAddr);
          pxIpTableRepository = &xIpTable.xIpRepository;
          break;
#ifdef IPTABLE_PPP
        case IPADDRT_PPPPEER:
          pxEntry->u.dwIpNetMask = 0xFFFFFFFF;
          pxIpTableRepository = &xIpTable.xPppRepository;
          break;
#endif
        default:
          ASSERT(0);
          lReturn = NETERR_UNKNOWN;
          break;
      }

      lReturn = IpTableRepositorySetAddr(pxIpTableRepository, pxEntry);
    }
    break;

  case IPTABLEMSG_GETDEFAULT:
    {
      IPTABLEENTRY *pxDefault;

      pxDefault = IpTableRepositoryFindDefault(&(xIpTable.xIpRepository),
                                               pxEntry);

      if (pxDefault != NULL) {
        MOC_MEMCPY((ubyte *)pxEntry,(ubyte *)pxDefault,sizeof(IPTABLEENTRY));
      }
      else {
        lReturn = NETERR_UNKNOWN;
      }
    }
    break;

#ifdef IPTABLE_UNUSED /* currently unused */
  case IPTABLEMSG_GETALL:
    IpTableRepositoryGetAll(&(xIpTable.xIpRepository),(IPTABLE *)hData);
    break;
#endif

  case IPTABLEMSG_GETTYPE:
    pxEntry->eAddrType = IPADDRT_UNKNOWN; /* Sets the type to
                                             unknown to force look-up */
    pxEntry->eAddrType = lReturn = IpTableGetAddrType(pxEntry);
    break;

  case IPTABLEMSG_GETIFIDX:
#ifndef IPTABLE_SINGLEIF
    lReturn = IpTableGetIfIdx(pxEntry);
#else
    /* Return ANY if not matched or 0 otherwise */
    lReturn = 0L; /* interface 0 is only option, but could be ANY */
#endif
    break;
  default:
    ASSERT(0);
    lReturn = -1;
    break;
  }

  return lReturn;
}


void _IpTablePrintIpTableEntry(IPTABLEENTRY *pxIpTableEntry)
{
  printf("oIfIdx=%d,dwAddr=%ld.%ld.%ld.%ld,dwNetIpMask=%ld.%ld.%ld.%ld,eAddrType=%d,wDefaultVlan=%d\n",
         pxIpTableEntry->oIfIdx,
         IPADDRDISPLAY(pxIpTableEntry->dwAddr),
         IPADDRDISPLAY(pxIpTableEntry->u.dwIpNetMask),
         pxIpTableEntry->eAddrType,
         pxIpTableEntry->wDefaultVlan);
}

void _IpTablePrintIpTableRepository(IPTABLEREPOSITORY *pxIpTableRepository)
{
#ifndef IPTABLE_SINGLEIF
  DWORD dwIdx;
  DWORD dwTableSize;
  IPTABLEENTRY *pxIpTableEntry;
#endif

  if(pxIpTableRepository == NULL){
    return;
  }

#ifndef IPTABLE_SINGLEIF
  dwTableSize = pxIpTableRepository->dwTableSize;

  for(dwIdx = 0;dwIdx < dwTableSize; dwIdx++){
    pxIpTableEntry = &pxIpTableRepository->pxEntryTable[dwIdx];
    ASSERT(pxIpTableEntry != NULL);
    _IpTablePrintIpTableEntry(pxIpTableEntry);
  }
#else
  /* Should be single entry only */
  _IpTablePrintIpTableEntry(&pxIpTableRepository->pxEntryTable[0]);
#endif
}

void IpTablePrint()
{
  IPTABLEREPOSITORY *pxIpTableRepository;

  printf("**** IpTablePrint ****\n");

  printf("xIpRepository\n");
  pxIpTableRepository = &xIpTable.xIpRepository;

  _IpTablePrintIpTableRepository(pxIpTableRepository);

#ifdef IPTABLE_MCAST
  printf("xMcastRepository\n");
  pxIpTableRepository = &xIpTable.xMcastRepository;
  _IpTablePrintIpTableRepository(pxIpTableRepository);
#endif
}


CHAR* IpAddressTypeToString(E_ADDRTYPE eAddrType)
{
  switch(eAddrType){
  case IPADDRT_UNKNOWN:
    return "UNKNOWN";
  case IPADDRT_LOOPBACK:
    return "LOOPBACK";
  case IPADDRT_BROADCAST:
    return "BROADCAST";
  case IPADDRT_MULTICAST:
    return "MULTICAST";
  case IPADDRT_MYADDR:
    return "MYADDR";
  case IPADDRT_MYSUBNET:
    return "MYSUBNET";
  case IPADDRT_OUTSIDE:
    return "OUTSIDE";
  case IPADDRT_INVBCAST:
    return "INVBCAST";
  case IPADDRT_MULTICASTJOINED:
    return "MULTICASTJOINED";
  case IPADDRT_MULTICASTJOINEDPROXY:
    return "MULTICASTJOINEDPROXY";
  case IPADDRT_MULTICASTJOINEDSOCKPROXY:
    return "MULTICASTJOINEDSOCKPROXY";
  case IPADDRT_PPPPEER:
    return "PPPPEER";
  case IPADDRT_ANY:
    return "ANY";
  default:
    return "???";
  }

  return "";
}


