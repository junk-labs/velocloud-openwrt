/*
 * if_types.h
 *
 * interface public types
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _NET_IF_TYPES_H_
#define _NET_IF_TYPES_H_

#define    IFT_OTHER    0x1        /* none of the following */
#define    IFT_ETHER    0x6        /* Ethernet CSMACD */
#define    IFT_PPP        0x17        /* RFC 1331 */
#define    IFT_LOOP    0x18        /* loopback */
#define    IFT_ATM        0x25        /* ATM cells */
#define    IFT_AAL5    0x31        /* AAL5 over ATM */

#define IFT_PPPOE       0x3A
#define IFT_NULL        0x3B            /* unencapsulated IP */
#define IFT_DUMMY       0x3C

#endif
