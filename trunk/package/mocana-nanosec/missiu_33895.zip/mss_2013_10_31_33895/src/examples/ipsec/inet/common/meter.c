/*
 * meter.c
 *
 * meter module main file
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "meter_flavor.h"
#include "meterdefs.h"
#include "meter.h"
#include "meterdbg.h"


/*****************************************************************************
 *
 * global variables
 *
 *****************************************************************************/

METER_DBG_VAR(DWORD g_dwMeterDebugLevel = ERROR);
METER_DBG_VAR(DWORD g_adwMeterReqs[METER_MAXNUM_IF]);
METER_DBG_VAR(DWORD g_adwMeterReqsRefused[METER_MAXNUM_IF]);
METER_DBG_VAR(DWORD g_dwMeterReservedTooFew = 0);
METER_DBG_VAR(DWORD g_dwMeterMedToLowPriPkts = 0);
METER_DBG_VAR(DWORD g_dwMeterMedToHighPriPkts = 0);

/*
 * Meter state
 */
METERSTATE xMeter;

/*****************************************************************************
 *
 * Local function declaration
 *
 *****************************************************************************/

#ifndef NDEBUG
/* Debug function prototypes */
#endif
/*****************************************************************************
 *
 * Local function
 *
 *****************************************************************************/
/* None */

/*****************************************************************************
 *
 * API function
 *
 *****************************************************************************/

/*
 * MeterInitialize
 *  Initializes the meter
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG MeterInitialize(void)
{
  MOC_MEMSET((ubyte *)&(xMeter),0x00,sizeof(METERSTATE));

  METER_DBG_VAR(
    MOC_MEMSET((ubyte *)&g_adwMeterReqs,0x00,sizeof(g_adwMeterReqs));
    MOC_MEMSET((ubyte *)&g_adwMeterReqsRefused,0x00,sizeof(g_adwMeterReqsRefused));
  )

  return 0;
}

/*
 * MeterTerminate
 *  Terminates the meter
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG MeterTerminate(void)
{

  DEBUG({
    MOC_MEMSET((ubyte *)&(xMeter),0x00,sizeof(METERSTATE));
  });

  return 0;
}

#define METER_PRIHIGH 0xFF
#define METER_PRIMED  0x7F
#define METER_PRILOW  0x0
BOOL
_MeterReqBandwidth(METERREQUEST *pxMeterReq)
{
  OCTET oGroupIdx;
  GRPSTATE *pxGroup;

  BOOL bSend = TRUE;
#if 0
  BOOL bSend = FALSE;

  oGroupIdx = xMeter.axIf[pxMeterReq->oIfIdx].oGroupIdx;
  pxGroup = &xMeter.axGroup[oGroupIdx];

  /* Alter medium priority evaluation based on high packet transmission
   * so far this window
   */
  if (METER_PRIHIGH == pxMeterReq->oPriority) {
    /* reset to max as high received */
    if ((pxGroup->xWindow.dwBytesPassedHigh + pxMeterReq->wSize) >
        pxGroup->dwBytesPerWindowReservedHigh) {
      pxGroup->dwBytesPerWindowReservedHigh =
        pxGroup->dwBytesPerWindowReservedHighDefault;
    }
#if 0
/* No medium priority for now  */
  }
  if (METER_PRIMED == pxMeterReq->oPriority) {
    /* check no high pri traffic before changing pri to high or low
     * NOTE: This slightly more strict check on which get converted
     *       to high vs. the one for low pri pkts to send, is to give
     *       a late starting genuine high pri. pkt a chance to be
     *       transmitted.
    */
    if ((pxGroup->dwBytesPerWindowReservedHigh == 0) &&
        ((pxGroup->xWindow.dwBytesPassedTotal + pxMeterReq->wSize) <
          pxGroup->dwBytesPerWindowMaxTotal) ) {
      pxMeterReq->oPriority = METER_PRIHIGH;
      METER_DBG_VAR(g_dwMeterMedToHighPriPkts++);
    } else {
      pxMeterReq->oPriority = METER_PRILOW;
      /* increase this one as it won't hit PRIHIGH code below */
      pxGroup->xWindow.dwBytesReqForHigh += pxMeterReq->wSize;
      METER_DBG_VAR(g_dwMeterMedToLowPriPkts++);
    }
  }
  if (METER_PRIHIGH == pxMeterReq->oPriority) {
#endif
    /* send it anyway although it may get binned in worst case */
    bSend = TRUE;

    /* increase high priority stats */
    pxGroup->xWindow.dwBytesPassedHigh += pxMeterReq->wSize;
    pxGroup->xWindow.dwBytesReqForHigh += pxMeterReq->wSize;
  } else { /* METER_PRILOW */
    /* Add if not taking any of the high priority space */
    if ((pxGroup->xWindow.dwBytesPassedTotal) <
        (pxGroup->dwBytesPerWindowMaxTotal -
         (pxGroup->dwBytesPerWindowReservedHigh -
          pxGroup->xWindow.dwBytesPassedHigh) ) ) {
      bSend = TRUE;
    }
  } /* end pri checking */

  /* Increase common stats if sending */
  if (bSend) {
    pxGroup->xWindow.dwBytesPassedTotal += pxMeterReq->wSize;
  }

#endif
  return bSend;
}

/*
 * MeterMsg
 *  Message function for the meter
 *
 *  Args:
 *   oMsg              Msg code. See defines above
 *   hData             Data handle. specifics defined for each messages
 *                     (see message definition above)
 *
 *  Return:
 *   < 0 == errors. For specific code, see message definition
 */
LONG MeterMsg(OCTET oMsg, H_METERDATA hData)
{
  LONG lReturn = METER_NOERR;

  ASSERT(NULL != ((void*)hData));

  switch(oMsg) {

  case METERMSG_REQBANDWIDTH:
    {
      METERREQUEST *pxMeterReq = (METERREQUEST *)hData;
      ASSERT(pxMeterReq->oIfIdx < (OCTET) METER_MAXNUM_IF);

      METER_DBG_VAR(g_adwMeterReqs[pxMeterReq->oIfIdx]++);
#ifdef NMETERLIMIT /* remove effectiveness of metering module */
      if (pxMeterReq->oPriority < 0xFF) {
        pxMeterReq->oPriority = 0;
      }
#else
      if (FALSE == _MeterReqBandwidth(pxMeterReq)) {
        lReturn = METER_NOBANDWIDTH;
        METER_DBG_VAR(g_adwMeterReqsRefused[pxMeterReq->oIfIdx]++);
      }
#endif
    }
    break;

  case METERMSG_SETTIMESLOT: /* in msecs. MAX of 1sec presumed*/
    ASSERT(((DWORD)hData)< 1000L);
    xMeter.dwTimeSlot = (DWORD)hData;
    /* METER_DBGP(NORMAL,"MeterMsg: Timeslot set to %lu msecs\n",
                                xMeter.dwTimeSlot);*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_METER, INET_DBG_LEVEL_NORMAL))
    {
        DEBUG_PRINT(DEBUG_MOC_IPV4, "MeterMsg: Timeslot set to ");
        DEBUG_UINT(DEBUG_MOC_IPV4,xMeter.dwTimeSlot);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," msecs");
    }

    break;

  case METERMSG_SETBITRATE: /* kbit/s NOTE: 1000 not 1024 */
    {
      METERBITRATE *pxMeterBitRate = (METERBITRATE *)hData;
      OCTET oGroupIdx;

      ASSERT(pxMeterBitRate->oGroupIdx < (OCTET) METER_MAXNUM_GROUP);
      ASSERT(xMeter.dwTimeSlot!=0); /* MUST have timeslot already set first */
      oGroupIdx = pxMeterBitRate->oGroupIdx;
      xMeter.axGroup[oGroupIdx].dwBitRate = pxMeterBitRate->dwBitRate;
      /* kbit/s => bytes/window conversion
       *  - multiply by 125 for bytes/s (* 1000 for bits/s / 8 for bytes)
       *  - divide down for timeslot (1000msecs - provisioned msec window)
       */
      xMeter.axGroup[oGroupIdx].dwBytesPerWindowMaxTotal =
        ( ((pxMeterBitRate->dwBitRate * 125) / 1000) * (xMeter.dwTimeSlot));
      /* to start with, reserve a third for high pri  */
      xMeter.axGroup[oGroupIdx].dwBytesPerWindowReservedHigh = 0;
      /* Set initial high reservation value to 1/3rd of bandwidth */
      xMeter.axGroup[oGroupIdx].dwBytesPerWindowReservedHighDefault =
        xMeter.axGroup[oGroupIdx].dwBytesPerWindowMaxTotal/3;
      /* Set minimum threshold when there has been high priority activity */
      xMeter.axGroup[oGroupIdx].dwBytesPerWindowReservedMinimum =
        xMeter.axGroup[oGroupIdx].dwBytesPerWindowMaxTotal/10;
/*        xMeter.axGroup[oGroupIdx].dwBytesPerWindowMaxTotal/3; */

      /* METER_DBGP(NORMAL,"MeterMsg: Bitrate for meter group idx %d set to "
                "%lu kbit/s\n",
                        oGroupIdx, pxMeterBitRate->dwBitRate);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_METER, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,
                   "MeterMsg: Bitrate for meter group idx ", oGroupIdx);
          DEBUG_UINT(DEBUG_MOC_IPV4,pxMeterBitRate->dwBitRate);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4," kbit/s");
      }

      /* METER_DBGP(NORMAL,"MeterMsg: => per window max bytes = %lu; "
                         "rsrvd bytes (high pri) = %lu\n",
                        xMeter.axGroup[oGroupIdx].dwBytesPerWindowMaxTotal,
                        xMeter.axGroup[oGroupIdx].dwBytesPerWindowReservedHigh); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_METER, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINT(DEBUG_MOC_IPV4,"MeterMsg: => per window max bytes = ");
          DEBUG_UINT(DEBUG_MOC_IPV4,
                   xMeter.axGroup[oGroupIdx].dwBytesPerWindowMaxTotal);
          DEBUG_PRINT(DEBUG_MOC_IPV4,"; rsrvd bytes (high pri) = ");
          DEBUG_UINT(DEBUG_MOC_IPV4,
                   xMeter.axGroup[oGroupIdx].dwBytesPerWindowReservedHigh);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
      }

      /* METER_DBGP(NORMAL,"MeterMsg: => default (initial) high rsvd bytes = %lu; "
                        "minimum high bytes (when h.pri throughput) = %lu\n",
                 xMeter.axGroup[oGroupIdx].dwBytesPerWindowReservedHighDefault,
                 xMeter.axGroup[oGroupIdx].dwBytesPerWindowReservedMinimum); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_METER, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINT(DEBUG_MOC_IPV4,"MeterMsg: => default (initial) high rsvd bytes = ");
          DEBUG_UINT(DEBUG_MOC_IPV4,
                   xMeter.axGroup[oGroupIdx].dwBytesPerWindowReservedHighDefault);
          DEBUG_PRINT(DEBUG_MOC_IPV4,"; minimum high bytes (when h.pri throughput) = ");
          DEBUG_UINT(DEBUG_MOC_IPV4,
                 xMeter.axGroup[oGroupIdx].dwBytesPerWindowReservedMinimum);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
      }

    }
    break;

  case METERMSG_SETNUMBERGROUPS:
      ASSERT((OCTET)hData <= (OCTET) METER_MAXNUM_GROUP);
      xMeter.oNumberGrps = (OCTET)hData;
      /* METER_DBGP(NORMAL,"MeterMsg: No. groups set to %d\n",xMeter.oNumberGrps); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_METER, INET_DBG_LEVEL_NORMAL))
      {
         DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,
                           "MeterMsg: No. groups set to ", xMeter.oNumberGrps);
         DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
      }
    break;

  case METERMSG_SETGROUPMEMBER:
    {
      METERGROUPMEMBER *pxMeterGrpMember = (METERGROUPMEMBER *)hData;
      ASSERT(pxMeterGrpMember->oGroupIdx < (OCTET) METER_MAXNUM_GROUP);
      ASSERT(pxMeterGrpMember->oIfIdx < (OCTET) METER_MAXNUM_IF);
      xMeter.axIf[pxMeterGrpMember->oIfIdx].oGroupIdx =
        pxMeterGrpMember->oGroupIdx;
      /* METER_DBGP(NORMAL,"MeterMsg: Added If idx %d to meter group %d\n",
                  pxMeterGrpMember->oIfIdx, pxMeterGrpMember->oGroupIdx); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_METER, INET_DBG_LEVEL_NORMAL))
      {
         DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,
                          "MeterMsg: Added If idx ",pxMeterGrpMember->oIfIdx,
                              " to meter group ", pxMeterGrpMember->oGroupIdx);
         DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
      }
    }
    break;

#if 0
  case METERMSG_SETGROUPLIMITS:
    {
      METERGROUPLIMITS *pxMeterGrpLimits = (METERGROUPLIMITS *)hData;
      ASSERT(pxMeterGrpLimits->oGroupIdx < (OCTET) METER_MAXNUM_GROUP);

    }
    break;
#endif
  } /* switch */

  return lReturn;
}

/*
 * MeterProcess
 *  Process function for the meter
 *
 *  Args:
 *   void
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG MeterProcess(void)
{
#ifndef NMETERLIMIT /* remove effectiveness of metering module */
  int i;
  GRPSTATE *pxGroup;

  for (i=0; i<xMeter.oNumberGrps; i++) {
    pxGroup = &xMeter.axGroup[i];

    /* Update assessment window stats */
    ++(pxGroup->xAssessWindow.dwWindowNo);
    pxGroup->xAssessWindow.dwWindowNo %= METER_ASSESSWINDOWS;
    if (pxGroup->xAssessWindow.dwBytesPassedHighMax <
        pxGroup->xWindow.dwBytesPassedHigh) {
      pxGroup->xAssessWindow.dwBytesPassedHighMax =
        pxGroup->xWindow.dwBytesPassedHigh;
    }

    /* Assess last group of windows to determine future high limit */
    if (0 == pxGroup->xAssessWindow.dwWindowNo) {
      DWORD dwNewHighLimit;
      if (pxGroup->xAssessWindow.dwBytesPassedHighMax <
          pxGroup->dwBytesPerWindowReservedHigh) {
    if (pxGroup->xAssessWindow.dwBytesPassedHighMax == 0) {
          dwNewHighLimit = 0;
        } else { /* deal with issue like silence supression w/min level */
          /* Add third overhead on to the max received in last few windows */
          dwNewHighLimit = pxGroup->xAssessWindow.dwBytesPassedHighMax+
            (pxGroup->xAssessWindow.dwBytesPassedHighMax/3);
          if (dwNewHighLimit < pxGroup->dwBytesPerWindowReservedMinimum) {
            dwNewHighLimit = pxGroup->dwBytesPerWindowReservedMinimum;
      }
        }
        pxGroup->dwBytesPerWindowReservedHigh = dwNewHighLimit;
      }
      MOC_MEMSET((ubyte *)&(pxGroup->xAssessWindow), 0x00, sizeof(pxGroup->xAssessWindow));
    }
    /* Clear current group window stats */
    MOC_MEMSET((ubyte *)&(pxGroup->xWindow), 0x00, sizeof(pxGroup->xWindow));
  } /* for all bitrate groups */
#endif /* ifndef NMETERLIMIT */
  return (LONG)xMeter.dwTimeSlot;
}



#ifndef NDEBUG
/* Debug functions */

#endif /*#ifndef NDEBUG*/



