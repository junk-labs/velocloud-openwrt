/*
 * meter.h
 *
 * meter library. Measures bandwidth.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _METER_H_
#define _METER_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/
/*
 * Return values
 */
#define METER_NOERR 0
#define METER_NOBANDWIDTH -1

/*
 * METERMSG
 */
#define METERMSG_REQBANDWIDTH    0    /* Requests bandwidth to send data
                                       * Data is METERREQUEST*
                       */

#define METERMSG_SETTIMESLOT     1    /* Sets a timeslot window in millisecs
                       * Data is DWORD
                       */

#define METERMSG_SETBITRATE      2    /* Sets a bitrate in kbit/s
                       * for a group number
                       * Data is METERBITRATE* */

#define METERMSG_SETNUMBERGROUPS 3    /* Set number of independant groups
                       * Data is OCTET
                       */

#define METERMSG_SETGROUPMEMBER  4    /* Links logical interface to group
                       * Data is METERGROUPMEMBER*
                       */
/*****************************************************************************
 *
 * typedef
 *
 *****************************************************************************/
/*
 * Data handle
 */
typedef int H_METERDATA;

/*
 * Request structure
 */
typedef struct {
  WORD wSize;       /* Ultimate size of the packet */
  OCTET oIfIdx;     /* Interface index */
  OCTET oPriority;  /* Requested priority */
} METERREQUEST;

/*
 * METERBITRATE
 *  Used to specify the connection bitrate on an interface.
 */
typedef struct {
  DWORD dwBitRate;                 /* Bitrate in Kbits/s */
  OCTET oGroupIdx;                 /* Group number */
} METERBITRATE;

/*
 * METERGROUPMEMBER
 *  Used to specify the relationship of interfaces and groups.
 */
typedef struct {
  OCTET oGroupIdx;                 /* Bitrate sharing group number */
  OCTET oIfIdx;                    /* Interface index belonging to grp */
} METERGROUPMEMBER;

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * MeterInitialize
 *  Initializes the meter
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG MeterInitialize(void);

/*
 * MeterTerminate
 *  Terminates the meter
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG MeterTerminate(void);

/*
 * MeterMsg
 *  Message function for the meter
 *
 *  Args:
 *   oMsg              Msg code. See defines above
 *   hData             Data handle. specifics defined for each messages
 *                     (see message definition above)
 *
 *  Return:
 *   < 0 == errors. For specific code, see message definition
 */
LONG MeterMsg(OCTET oMsg, H_METERDATA hData);

/*
 * MeterProcess
 *  Process function for the meter
 *
 *  Args:
 *   void
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG MeterProcess(void);

#ifndef NDEBUG
/*
 * Debug routines
 */
#endif

#endif /* _METER_H_ */
