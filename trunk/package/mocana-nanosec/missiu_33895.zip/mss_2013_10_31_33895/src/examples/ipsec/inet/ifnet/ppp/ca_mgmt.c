/*
 * ca_mgmt_example.c
 *
 * Example CA MGMT implementation
 *
 * Copyright Mocana Corp 2004-2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "../common/moptions.h"

#if (defined(__ENABLE_MOCANA_SSL_CLIENT__) || defined(__ENABLE_MOCANA_SSL_SERVER__) || defined(__ENABLE_MOCANA_SSL_ASYNC_CLIENT_API__) || defined(__ENABLE_MOCANA_SSL_ASYNC_SERVER_API__) || defined(__ENABLE_MOCANA_IKE_SERVER__))

#include "../common/mtypes.h"
#include "../common/mocana.h"
#include "../common/mdefs.h"
#include "../common/debug_console.h"
#include "../crypto/ca_mgmt.h"
#include "../crypto/crypto.h"
#if (defined(__ENABLE_MOCANA_SSL_CLIENT__) || defined(__ENABLE_MOCANA_SSL_SERVER__) || defined(__ENABLE_MOCANA_SSL_ASYNC_CLIENT_API__) || defined(__ENABLE_MOCANA_SSL_ASYNC_SERVER_API__))
#include "../ssl/ssl.h"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/*------------------------------------------------------------------*/

#define RSA_EXAMPLE_KEY_SIZE   (1024)

#ifdef __RTOS_VXWORKS__
#define CERTIFICATE_DER_FILE        "NVRAM:/rsa.der"
#define RSA_HOST_KEYS               "NVRAM:/rsakey.dat"
#else
#define CERTIFICATE_DER_FILE        "rsa.der"
#define RSA_HOST_KEYS               "rsakey.dat"
#endif

certDistinguishedName exampleCertificateDescr =
{
    {
        "US", 2,                                /* country */
        "California", 10,                       /* state or providence */
        "Menlo Park", 10,                       /* locality */
        "Mocana Corporation", 18,               /* company name */
        "Engineering", 11,                      /* organizational unit */
        "sslexample.mocana.com", 21,            /* common name */
    },

    "info@mocana.com", 15,                      /* pkcs-9-at-emailAddress */

/* Note: Internet Explorer limits a 30 year lifetime for certificates */

                                                /* time format yymmddhhmmss */
    "030526000126Z",                            /* certificate start date */
    "330524230126Z"                             /* certificate end date */

/* above start example, May 26th, 2003 12:01:26 AM */
/* above end example, May 24th, 2033 11:01:26 PM */

};


/*------------------------------------------------------------------*/

static ubyte vrsnCertificate[] =
{
    0x30, 0x82, 0x02, 0x34, 0x30, 0x82, 0x01, 0xa1, 0x02, 0x10, 0x02, 0xad, 0x66, 0x7e, 0x4e, 0x45,
    0xfe, 0x5e, 0x57, 0x6f, 0x3c, 0x98, 0x19, 0x5e, 0xdd, 0xc0, 0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86,
    0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x02, 0x05, 0x00, 0x30, 0x5f, 0x31, 0x0b, 0x30, 0x09, 0x06,
    0x03, 0x55, 0x04, 0x06, 0x13, 0x02, 0x55, 0x53, 0x31, 0x20, 0x30, 0x1e, 0x06, 0x03, 0x55, 0x04,
    0x0a, 0x13, 0x17, 0x52, 0x53, 0x41, 0x20, 0x44, 0x61, 0x74, 0x61, 0x20, 0x53, 0x65, 0x63, 0x75,
    0x72, 0x69, 0x74, 0x79, 0x2c, 0x20, 0x49, 0x6e, 0x63, 0x2e, 0x31, 0x2e, 0x30, 0x2c, 0x06, 0x03,
    0x55, 0x04, 0x0b, 0x13, 0x25, 0x53, 0x65, 0x63, 0x75, 0x72, 0x65, 0x20, 0x53, 0x65, 0x72, 0x76,
    0x65, 0x72, 0x20, 0x43, 0x65, 0x72, 0x74, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e,
    0x20, 0x41, 0x75, 0x74, 0x68, 0x6f, 0x72, 0x69, 0x74, 0x79, 0x30, 0x1e, 0x17, 0x0d, 0x39, 0x34,
    0x31, 0x31, 0x30, 0x39, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x5a, 0x17, 0x0d, 0x31, 0x30, 0x30,
    0x31, 0x30, 0x37, 0x32, 0x33, 0x35, 0x39, 0x35, 0x39, 0x5a, 0x30, 0x5f, 0x31, 0x0b, 0x30, 0x09,
    0x06, 0x03, 0x55, 0x04, 0x06, 0x13, 0x02, 0x55, 0x53, 0x31, 0x20, 0x30, 0x1e, 0x06, 0x03, 0x55,
    0x04, 0x0a, 0x13, 0x17, 0x52, 0x53, 0x41, 0x20, 0x44, 0x61, 0x74, 0x61, 0x20, 0x53, 0x65, 0x63,
    0x75, 0x72, 0x69, 0x74, 0x79, 0x2c, 0x20, 0x49, 0x6e, 0x63, 0x2e, 0x31, 0x2e, 0x30, 0x2c, 0x06,
    0x03, 0x55, 0x04, 0x0b, 0x13, 0x25, 0x53, 0x65, 0x63, 0x75, 0x72, 0x65, 0x20, 0x53, 0x65, 0x72,
    0x76, 0x65, 0x72, 0x20, 0x43, 0x65, 0x72, 0x74, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f,
    0x6e, 0x20, 0x41, 0x75, 0x74, 0x68, 0x6f, 0x72, 0x69, 0x74, 0x79, 0x30, 0x81, 0x9b, 0x30, 0x0d,
    0x06, 0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00, 0x03, 0x81, 0x89,
    0x00, 0x30, 0x81, 0x85, 0x02, 0x7e, 0x00, 0x92, 0xce, 0x7a, 0xc1, 0xae, 0x83, 0x3e, 0x5a, 0xaa,
    0x89, 0x83, 0x57, 0xac, 0x25, 0x01, 0x76, 0x0c, 0xad, 0xae, 0x8e, 0x2c, 0x37, 0xce, 0xeb, 0x35,
    0x78, 0x64, 0x54, 0x03, 0xe5, 0x84, 0x40, 0x51, 0xc9, 0xbf, 0x8f, 0x08, 0xe2, 0x8a, 0x82, 0x08,
    0xd2, 0x16, 0x86, 0x37, 0x55, 0xe9, 0xb1, 0x21, 0x02, 0xad, 0x76, 0x68, 0x81, 0x9a, 0x05, 0xa2,
    0x4b, 0xc9, 0x4b, 0x25, 0x66, 0x22, 0x56, 0x6c, 0x88, 0x07, 0x8f, 0xf7, 0x81, 0x59, 0x6d, 0x84,
    0x07, 0x65, 0x70, 0x13, 0x71, 0x76, 0x3e, 0x9b, 0x77, 0x4c, 0xe3, 0x50, 0x89, 0x56, 0x98, 0x48,
    0xb9, 0x1d, 0xa7, 0x29, 0x1a, 0x13, 0x2e, 0x4a, 0x11, 0x59, 0x9c, 0x1e, 0x15, 0xd5, 0x49, 0x54,
    0x2c, 0x73, 0x3a, 0x69, 0x82, 0xb1, 0x97, 0x39, 0x9c, 0x6d, 0x70, 0x67, 0x48, 0xe5, 0xdd, 0x2d,
    0xd6, 0xc8, 0x1e, 0x7b, 0x02, 0x03, 0x01, 0x00, 0x01, 0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48,
    0x86, 0xf7, 0x0d, 0x01, 0x01, 0x02, 0x05, 0x00, 0x03, 0x7e, 0x00, 0x65, 0xdd, 0x7e, 0xe1, 0xb2,
    0xec, 0xb0, 0xe2, 0x3a, 0xe0, 0xec, 0x71, 0x46, 0x9a, 0x19, 0x11, 0xb8, 0xd3, 0xc7, 0xa0, 0xb4,
    0x03, 0x40, 0x26, 0x02, 0x3e, 0x09, 0x9c, 0xe1, 0x12, 0xb3, 0xd1, 0x5a, 0xf6, 0x37, 0xa5, 0xb7,
    0x61, 0x03, 0xb6, 0x5b, 0x16, 0x69, 0x3b, 0xc6, 0x44, 0x08, 0x0c, 0x88, 0x53, 0x0c, 0x6b, 0x97,
    0x49, 0xc7, 0x3e, 0x35, 0xdc, 0x6c, 0xb9, 0xbb, 0xaa, 0xdf, 0x5c, 0xbb, 0x3a, 0x2f, 0x93, 0x60,
    0xb6, 0xa9, 0x4b, 0x4d, 0xf2, 0x20, 0xf7, 0xcd, 0x5f, 0x7f, 0x64, 0x7b, 0x8e, 0xdc, 0x00, 0x5c,
    0xd7, 0xfa, 0x77, 0xca, 0x39, 0x16, 0x59, 0x6f, 0x0e, 0xea, 0xd3, 0xb5, 0x83, 0x7f, 0x4d, 0x4d,
    0x42, 0x56, 0x76, 0xb4, 0xc9, 0x5f, 0x04, 0xf8, 0x38, 0xf8, 0xeb, 0xd2, 0x5f, 0x75, 0x5f, 0xcd,
    0x7b, 0xfc, 0xe5, 0x8e, 0x80, 0x7c, 0xfc, 0x50
};


/*------------------------------------------------------------------*/

static sbyte4
findCertificateInStore(sbyte4 connectionInstance, certDistinguishedName *pLookupCertDN,
                       certDescriptor* pReturnCert)
{
#if 0
    /* normally locate certificate in store... */
    certDistinguishedName   issuer;
    sbyte4                     status;

    status = CA_MGMT_extractCertDistinguishedName(pCertificate, certificateLength, 0, &issuer);

    if (0 > status)
        return status;
#endif

    MOC_UNUSED(connectionInstance);
    MOC_UNUSED(pLookupCertDN);

    /* for this example implementation, we only recognize one certificate authority */

    pReturnCert->pCertificate = vrsnCertificate;
    pReturnCert->certLength   = sizeof(vrsnCertificate);
    pReturnCert->cookie       = 0;

    return 0;
}


/*------------------------------------------------------------------*/

static sbyte4
releaseStoreCertificate(sbyte4 connectionInstance, certDescriptor* pFreeCert)
{
    MOC_UNUSED(connectionInstance);

    /* just need to release the certificate, not the key blob */
    if (0 != pFreeCert->pCertificate)
    {
        if (0 != pFreeCert->cookie)
        {
            free(pFreeCert->pCertificate);
        }

        pFreeCert->pCertificate = 0;
    }

    return 0;
}


/*------------------------------------------------------------------*/

static sbyte4
verifyCertificateInStore(sbyte4 connectionInstance,
                         ubyte *pCertificate, ubyte4 certificateLength,
                         sbyte4 isSelfSigned)
{
    /* lookup to verify certificate is in store */
    sbyte4 status = -1;
    MOC_UNUSED(connectionInstance);


    /* every app, should always check a length before a memcmp */
    if ((certificateLength == sizeof(vrsnCertificate)) &&
        (0 == memcmp(pCertificate, vrsnCertificate, certificateLength)) )
    {
        status = 0;             /* we recognize this certificate authority */
    }
    else
    {
        if (1 == isSelfSigned)
            status = 0;         /* do you accept self-signed certificates? if so, return 0 else error */
    }

    return status;
}


/*------------------------------------------------------------------*/

static sbyte4
testHostKeys(certDescriptor *pRetCertificateDescr)
{
    sbyte4             status;

    if (0 > (status = MOCANA_readFile(CERTIFICATE_DER_FILE, &pRetCertificateDescr->pCertificate, &pRetCertificateDescr->certLength)))
        goto exit;

    status = MOCANA_readFile(RSA_HOST_KEYS, &pRetCertificateDescr->pRsaKeyBlob, &pRetCertificateDescr->keyBlobLength);



#if 0
    {
        ubyte* pCertificate;
        ubyte4 certificateLen;

        MOCANA_readFile("C:/MocanaDEV/MocanaDEV/mss/src/test/certificate_authority/mocana_signed.cer", &pRetCertificateDescr->pRsaKeyBlob, &pRetCertificateDescr->keyBlobLength);

        PKCS10_decodeSignedCertificate(pRetCertificateDescr->pRsaKeyBlob, pRetCertificateDescr->keyBlobLength, &pCertificate, &certificateLen);

        MOCANA_writeFile("C:/MocanaDEV/MocanaDEV/mss/src/test/certificate_authority/decoded_mocana_signed.cer", pCertificate, certificateLen);

        MOCANA_readFile("C:/MocanaDEV/MocanaDEV/mss/src/test/certificate_authority/verisign_test_ca.cer", &pRetCertificateDescr->pRsaKeyBlob, &pRetCertificateDescr->keyBlobLength);

        PKCS10_decodeSignedCertificate(pRetCertificateDescr->pRsaKeyBlob, pRetCertificateDescr->keyBlobLength, &pCertificate, &certificateLen);

        MOCANA_writeFile("C:/MocanaDEV/MocanaDEV/mss/src/test/certificate_authority/decoded_verisign_test_ca.cer", pCertificate, certificateLen);
    }
#endif


#if 0
    {
        ubyte* pCsr = NULL;
        ubyte4   csrLen = 0;

        WIN32_sleepMS(2000);

        PKCS10_generateCSR(pRetCertificateDescr->pRsaKeyBlob, pRetCertificateDescr->keyBlobLength, &pCsr, &csrLen, &exampleCertificateDescr);

        while (csrLen)
        {
            if ('\x0d' == *pCsr)
                printf("\n");
            else
                printf("%c", *pCsr);

            pCsr++;
            csrLen--;
        }
    }
#endif

exit:
    return status;
}


/*------------------------------------------------------------------*/

extern sbyte4
CA_MGMT_EXAMPLE_releaseHostKeys(certDescriptor *pCertificateDescr)
{
    MOCANA_freeReadFile(&pCertificateDescr->pCertificate);
    MOCANA_freeReadFile(&pCertificateDescr->pRsaKeyBlob);

    return 0;
}


/*------------------------------------------------------------------*/

extern sbyte4
CA_MGMT_computeHostKeys(certDescriptor *pRetCertificateDescr)
{
    sbyte4   status;

    /* check for pre-existing set of host keys */
    if (0 > (status = testHostKeys(pRetCertificateDescr)))
    {
        DEBUG_PRINTNL(DEBUG_SSL_EXAMPLE, "CA_MGMT_EXAMPLE_computeHostKeys: host keys do not exist, computing new key pair.");

        /* if not, compute new host keys */
        if (0 > (status = CA_MGMT_generateCertificate(pRetCertificateDescr, RSA_EXAMPLE_KEY_SIZE, &exampleCertificateDescr, md5withRSAEncryption)))
            goto exit;

        if (0 > (status = MOCANA_writeFile(CERTIFICATE_DER_FILE, pRetCertificateDescr->pCertificate, pRetCertificateDescr->certLength)))
            goto exit;

        status = MOCANA_writeFile(RSA_HOST_KEYS, pRetCertificateDescr->pRsaKeyBlob, pRetCertificateDescr->keyBlobLength);

        DEBUG_PRINTNL(DEBUG_SSL_EXAMPLE, "CA_MGMT_EXAMPLE_computeHostKeys: host key computation completed.");
    }

exit:
    if (0 > status)
        CA_MGMT_freeCertificate(pRetCertificateDescr);

    return status;
}


/*------------------------------------------------------------------*/

#if 0
static sbyte4
certificateLeafTest(sbyte4 connectionInstance,
                    ubyte *pCertificate, ubyte4 certificateLen)
{
    const  sbyte4 oid[] = { 0x55, 0x1d, 0x25 };
    const  sbyte4 oidCheck[] = { 0x2b, 0x06, 0x01, 0x05, 0x05, 0x07, 0x03, 0x04 };
    sbyte4 isPresent = 0;
    sbyte4 status;

    status = CA_MGMT_rawVerifyOID(pCertificate, certificateLen, oid, sizeof(oid) / sizeof(sbyte4), oidCheck, sizeof(oidCheck) / sizeof(sbyte4), &isPresent);

    if (isPresent)
        printf("certificateLeafTest: Secure Mail certificate OID is present!\n");

    return status;
}
#endif


/*------------------------------------------------------------------*/

#ifdef __ENABLE_MOCANA_SSL_MUTUAL_AUTH_SUPPORT__
static sbyte4
mutualAuthGetCertificate(sbyte4 connectionInstance, certDescriptor *pRetCertDescr,
                         ubyte *pDistNames, ubyte4 distNameLen)
{
    MOC_UNUSED(connectionInstance);
    MOC_UNUSED(pDistNames);
    MOC_UNUSED(distNameLen);

    /* normally, lookup certificate for particular interface */
    /* for this example, we just recycle the host certificate out of the file system */
    return CA_MGMT_EXAMPLE_computeHostKeys(pRetCertDescr);

}
#endif


/*------------------------------------------------------------------*/

#ifdef __ENABLE_MOCANA_SSL_MUTUAL_AUTH_SUPPORT__
static sbyte4
mutualAuthFreeCertificate(sbyte4 connectionInstance, certDescriptor *pFreeCertDescr)
{
    MOC_UNUSED(connectionInstance);

    return CA_MGMT_EXAMPLE_releaseHostKeys(pFreeCertDescr);
}
#endif


/*------------------------------------------------------------------*/

extern void
CA_MGMT_initUpcalls(void)
{
#if (defined(__ENABLE_MOCANA_SSL_CLIENT__) || defined(__ENABLE_MOCANA_SSL_SERVER__))
    SSL_sslSettings()->funcPtrCertificateStoreVerify    = verifyCertificateInStore;
    SSL_sslSettings()->funcPtrCertificateStoreLookup    = findCertificateInStore;
    SSL_sslSettings()->funcPtrCertificateStoreRelease   = releaseStoreCertificate;

#ifdef __ENABLE_MOCANA_SSL_MUTUAL_AUTH_SUPPORT__
    SSL_sslSettings()->funcPtrMutualAuthGetCertificate  = mutualAuthGetCertificate;
    SSL_sslSettings()->funcPtrMutualAuthFreeCertificate = mutualAuthFreeCertificate;
#endif
#endif /* (defined(__ENABLE_MOCANA_SSL_CLIENT__) || defined(__ENABLE_MOCANA_SSL_SERVER__)) */
}

#endif /* (defined(__ENABLE_MOCANA_SSL_CLIENT__) || defined(__ENABLE_MOCANA_SSL_SERVER__) || defined(__ENABLE_MOCANA_SSL_ASYNC_CLIENT_API__) || defined(__ENABLE_MOCANA_SSL_ASYNC_SERVER_API__) || defined(__ENABLE_MOCANA_IKE_SERVER__)) */
