
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcfg.h"
#include "setupnet.h"

/*
 * SetupNetIfGetDomainName
 *  Get the domain name of an interface
 *
 *  Args:
 *   oIfIdx              Interface index
 *   poName              name pointer
 *   oNameLen            poName length
 *
 *  Return
 *   SetupNetReturn
 */
SetupNetReturn SetupNetGetIfDomainName(OCTET oIfIdx,
                                       OCTET *poName,
                                       OCTET oNameLen)
{
  int iSocket;
  struct ifconf xIfConf;
  mnIoctlArgList_t mnIoctlArgList;      
  
  xIfConf.ifc_len = oNameLen;
  xIfConf.ifc_buf = (sbyte *)poName;
  
  if ((iSocket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  mnIoctlArgList.oIfIdx = oIfIdx;
  mnIoctlArgList.ifconf = (void *)&xIfConf;
  if (0 > ioctl(iSocket,MO_SIOCGIFIDN,oIfIdx,&(xIfConf))) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  close(iSocket);
  
  return SETUPNET_OK;  
}
