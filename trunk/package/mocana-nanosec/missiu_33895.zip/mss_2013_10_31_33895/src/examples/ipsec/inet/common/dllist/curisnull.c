#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

LONG DLLIST_cur_is_null(DLLIST *dllist)
{
  return(dllist->cur == NULL);
}

