/*
 * netgetmsectime
 *
 * implements NetGetMsecTime
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "utils_flavor.h"
#include "netutils.h"
#include "nettime.h"


/****************************************************************************
 *
 * statics
 *
 *****************************************************************************/

/*
 * network wide Timer.
 *  Updated every time NetGetMsecTime is called,
 *  and at least once every time the network thread is called.
 */
static DWORD dwGlobalNetworkTime = 0;


/****************************************************************************
 *
 * API
 *
 *****************************************************************************/

/*
 * NetGlobalTimerGet
 *  Gets the value of the network global timer
 *  This timer is updated at least once every time the
 *  network thread is run. Less precise, but faster
 *  than NetGetMsecTime
 *
 *  Args:
 *
 *  return:
 *   global timer value
 */
DWORD NetGlobalTimerGet(void)
{
  return dwGlobalNetworkTime;
}

/*
 * NetGlobalTimerSet
 *  Sets the global timer
 *
 *  Args:
 *   tsNow          Timespec structure
 *
 *  Return:
 *   global timer new value
 */
DWORD NetGlobalTimerSet()
{
#if 0
  dwGlobalNetworkTime = 1000 * ((DWORD)pxtsNow->tv_sec);
  dwGlobalNetworkTime += pxtsNow->tv_nsec /1000000;
  return dwGlobalNetworkTime;
#else
  return (dwGlobalNetworkTime = RTOS_getUpTimeInMS());
#endif
}


/*
 * NetGetMsecTime
 *  returns the current time in msec. Updates
 *  the global timer
 *
 * Args:
 *
 * Return:
 *  time in msec
 */
DWORD NetGetMsecTime(void)
{
#if 0
  struct timespec tsNow;

  (void) clock_gettime(CLOCK_REALTIME, &tsNow);
  return NetGlobalTimerSet();
#else
  return (dwGlobalNetworkTime = RTOS_getUpTimeInMS());
#endif
}

