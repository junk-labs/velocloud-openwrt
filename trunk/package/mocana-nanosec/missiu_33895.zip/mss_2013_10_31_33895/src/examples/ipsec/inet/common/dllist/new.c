#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

extern poolHeaderDescr gDLLIST_pool;
extern unsigned long gDLLIST_poolCount;

DLLIST *new_DLLIST_fl(char *pFile, int nLine)
{
  DLLIST *tmp;
  MSTATUS status =OK;
  /* tmp = (DLLIST *) malloc_fl(sizeof(DLLIST), pFile, nLine); */

  if(OK > (status =
             MEM_POOL_getPoolObject(&gDLLIST_pool, (void **)&tmp)))
  {
      /* Out of mempool */
      return(NULL);
  }

  if (tmp == NULL) {
    return(tmp);
  }
  gDLLIST_poolCount++;
  init_DLLIST(tmp);
  return(tmp);
}

void init_DLLIST(DLLIST *pDLList)
{
  pDLList->count = 0;
  pDLList->cur = NULL;
  pDLList->head = NULL;
  pDLList->tail = NULL;
  pDLList->free = NULL;
}

