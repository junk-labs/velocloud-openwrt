/*
 * igmp.h
 *
 * IGMP module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IGMP_H_
#define _IGMP_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * IGMP specific option
 */

#define IGMPOPTION_SETTOS \
  NETOPTION_MODULESPECIFICBEGIN


/*
 * IGMP specific Msg
 */
#define IGMPMSG_JOIN \
  NETMSG_MODULESPECIFICBEGIN          /* Join a Multicast group.
                                             Data is DWORD (Multicast IP addr).
                                             Can be called several time with
                                             the same address; LEAVE will
                                             have to be called the same
                                             amount of times */
#define IGMPMSG_LEAVE \
  (NETMSG_MODULESPECIFICBEGIN + 1)    /* Leave a Multicast group.
                                             Data is DWORD (Multicast IP addr).
                                             Must be called the number of
                                             times JOIN has been called to
                                             take effect */
#define NETERR_JOIN   \
  NETERR_MODULESPECIFICBEGIN

#define NETERR_LEAVE   \
  NETERR_MODULESPECIFICBEGIN

/*
 * IGMP LL Ioctls
 *  o All are covered in netcommon.h (LIBNETCOMMON)
 *  o the PFN_NETWRITE provided with
 *    NETINTERFACEIOCTL_SETOUTPUTPFN will be given as hDstId
 *    a DWORD, the IP address of the destination.
 */
#define NETINTERFACEIOCTL_SETHLL \
    (NETINTERFACEIOCTL_MODULESPECIFICBEGIN +1)

#define NETINTERFACEIOCTL_SETWRITE \
    (NETINTERFACEIOCTL_MODULESPECIFICBEGIN +2)
/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * IgmpInitialize
 *  Initialize the IGMP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IgmpInitialize(void);

/*
 * IgmpTerminate
 *  Terminate the IGMP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IgmpTerminate(void);

/*
 * IgmpInstanceCreate
 *  Creates a IGMP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IgmpInstanceCreate(void);

/*
 * IgmpInstanceDestroy
 *  Destroy a IGMP Instance
 *
 *  Args:
 *   hIgmp                      instance handle
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IgmpInstanceDestroy(H_NETINSTANCE hIgmp);

/*
 * IgmpInstanceSet
 *  Set a IGMP Instance Option
 *
 *  Args:
 *   hIgmp                      instance handle
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IgmpInstanceSet(H_NETINSTANCE hIgmp,OCTET oOption,
                     H_NETDATA hData);

/*
 * IgmpInstanceQuery
 *  Query a IGMP Instance Option
 *
 *  Args:
 *   hIgmp                      instance handle
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IgmpInstanceQuery(H_NETINSTANCE hIgmp,OCTET oOption,
                       H_NETDATA *phData);

/*
 * IgmpInstanceMsg
 *  Send a msg to a IGMP instance
 *
 *  Args:
 *   hIgmp                      instance handle
 *   oMsg                       Msg. See netcommon.h and igmp.h for definition
 *   hData                      Msg data. See message definition
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IgmpInstanceMsg(H_NETINSTANCE hIgmp,OCTET oMsg,
                     H_NETDATA hData);

/*
 * IgmpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIgmp                      instance handle
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IgmpInstanceLLInterfaceCreate(H_NETINSTANCE hIgmp);

/*
 * IgmpInstanceLLInterfaceDestroy
 *  Destroy a IGMP LL interface
 *
 *  Args:
 *   hIgmp                      IGMP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG IgmpInstanceLLInterfaceDestroy(H_NETINSTANCE hIgmp,
                                    H_NETINTERFACE hInterface);

/*
 * IgmpInstanceLLInterfaceIoctl
 *  IGMP LL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h
 *  for precisions
 *
 *  Args:
 *   hIgmp                        Igmp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IgmpInstanceLLInterfaceIoctl(H_NETINSTANCE hIgmp,
                                  H_NETINTERFACE hLLInterface,
                                  OCTET oIoctl,
                                  H_NETDATA hData);

/*
 * IgmpInstanceRcv
 *  Igmp Instance Rcv function
 *   Igmp Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIgmp                      Ud Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    pxAccess                   access info
 *    hData                      unused(could be used for VLAN)
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG IgmpInstanceRcv(H_NETINSTANCE hIgmp,
                     H_NETINSTANCE hIf,
                     NETPACKET *pxPacket,
                     NETPACKETACCESS *pxAccess,
                     H_NETDATA hData);

/*
 * IgmpInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hIgmp                        Igmp Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG IgmpInstanceProcess(H_NETINSTANCE hIp);


#endif /* #define _IGMP_H_ */



















