/*
 * ppplibs_cbk.c
 *
 * gathers all ppp callbacks
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "netmain_flavor.h"
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "stdio.h"
#include "pthread.h"
#include <mqueue.h>
#include "netdb.h"
#include "sys/socket.h"
#include "sys/sockio.h"
#include "netinet/in.h"
#include "net/if.h"
#include "limits.h"
#include "net/if_types.h"
#include "errno.h"

#include "netcommon.h"
#include "netconfig.h"
#include "nettime.h"
#include "netdefs.h"
#include "netmain.h"
#include "dnsapi.h"
#include "linkconf.h"
#include "netif.h"
#include "ethernet.h"
#include "arp.h"
#include "pppoecommon.h"
#include "pppoeclient.h"
#include "pppoeconf.h"
#include "ppp.h"
#include "ipcp.h"
#include "ethlink.h"
#include "iptable.h"
#include "cryptcommon.h"
#include "md5.h"
#include "chapclient.h"
#include "papclient.h"
#include "ppplibs.h"
#include "routing_table.h"
#ifdef ROUTER
#include "router.h"
#endif

#ifdef NAT
#include "nat.h"
#endif

/*
 * NetAdminAuthCbk
 *  Network wrapper Authentification Callback. Does nothing at this
 *  stage. Follows PFN_NETCBK type
 *
 */
LONG NetAdminAuthCbk(H_NETINSTANCE hInst,
                     OCTET oCbk,
                     H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hPpp;
  OCTET oIfIdx = (int)hInst;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  NETMAIN_ASSERT( oIfIdx < pxNetWrapper->oIfNumber);

  pxIfConf     = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState    = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  hPpp = NETGETINST_PPP(pxIfState);

  switch(oCbk) {
  case NETCBK_TLU:
    PppInstanceMsg(hPpp,PPPMSG_AUTHSUCCESS,hData);
    break;

  case NETCBK_TLD:
  case NETCBK_TLF:
    PppInstanceMsg(hPpp,PPPMSG_AUTHFAILURE,hData);
    NetMainMsg(NETMAINMSG_IFCLOSE,(H_NETDATA)oIfIdx);
    break;

  }

  return NETERR_NOERR;
}

/*
 * NetAdminChapClientCbk
 *  Network wrapper Chap Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminChapClientCbk(H_NETINSTANCE hInst,
                           OCTET oCbk,
                           H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;
  OCTET oIfIdx = (int)hInst;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  NETMAIN_ASSERT( oIfIdx < pxNetWrapper->oIfNumber);

  pxIfConf     = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState    = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  NETMAIN_DBGP(NORMAL,"NetAdminChapClientCbk:hInst=%d,oCbk=%s,hData=%d\n",
               (int)hInst,apoNetCbkString[oCbk],(int)hData);

  if (oCbk == NETCBK_NEEDPROCESSING) {
    NETGETNEXTCALLTIME_CHAP(pxIfState) = NetGlobalTimerGet() + (DWORD)hData;
  }
  else {
    NetAdminAuthCbk(hInst,oCbk,hData);
  }
  return NETERR_NOERR;
}

#ifdef EAP_TLS
/*
 * NetAdminEapTlsClientCbk
 *  Network wrapper EapTls Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminEapTlsClientCbk(H_NETINSTANCE hInst,
                           OCTET oCbk,
                           H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;
  OCTET oIfIdx = (int)hInst;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  NETMAIN_ASSERT( oIfIdx < pxNetWrapper->oIfNumber);

  pxIfConf     = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState    = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  NETMAIN_DBGP(NORMAL,"NetAdminEapTlsClientCbk:hInst=%d,oCbk=%s,hData=%d\n",
               (int)hInst,apoNetCbkString[oCbk],(int)hData);

  if (oCbk == NETCBK_NEEDPROCESSING) {
    NETGETNEXTCALLTIME_EAPTLS(pxIfState) = NetGlobalTimerGet() + (DWORD)hData;
  }
  else {
    NetAdminAuthCbk(hInst,oCbk,hData);
  }
  return NETERR_NOERR;
}

#endif /* EAP_TLS */

/*
 * NetAdminPapClientCbk
 *  Network wrapper Pap Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminPapClientCbk(H_NETINSTANCE hInst,
                           OCTET oCbk,
                           H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;
  OCTET oIfIdx = (int)hInst;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  NETMAIN_ASSERT( oIfIdx < pxNetWrapper->oIfNumber);

  pxIfConf     = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState    = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  NETMAIN_DBGP(NORMAL,"NetAdminPapClientCbk:hInst=%d,oCbk=%s,hData=%d\n",
               (int)hInst,apoNetCbkString[oCbk],(int)hData);

  if (oCbk == NETCBK_NEEDPROCESSING) {
    NETGETNEXTCALLTIME_PAP(pxIfState) = NetGlobalTimerGet() + (DWORD)hData;
  }
  else {
    NetAdminAuthCbk(hInst,oCbk,hData);
  }
  return NETERR_NOERR;
}


/*
 * NetAdminIpcpCbk
 *  Network wrapper Ipcp Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminIpcpCbk(H_NETINSTANCE hInst,
                    OCTET oCbk,
                    H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;
  NETWRAPPERSTATE *pxWrapperState;
  H_NETINSTANCE hIpcp, hPpp, hChapClient, hPapClient;
#ifdef EAP_TLS
  H_NETINSTANCE hEapTlsClient;
#endif
  int iSocketFd;
  OCTET oIfIdx = (OCTET)hInst;
  struct ifreq xIfReq;
  DWORD *pdwAddr;
  int iRv;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  NETMAIN_ASSERT( oIfIdx < pxNetWrapper->oIfNumber);

  pxIfConf     = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState    = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL);

  iSocketFd = pxWrapperState->iSocket;
  NETMAIN_ASSERT(iSocketFd > 0);

  NETMAIN_DBGP(NORMAL,"NetAdminIpcpCbk:hInst=%d,oCbk=%s,hData=%d\n",
               (int)hInst,apoNetCbkString[oCbk],(int)hData);

  hIpcp       = NETGETINST_IPCP(pxIfState);
  hPpp        = NETGETINST_PPP(pxIfState);
  hChapClient = NETGETINST_CHAP(pxIfState);
  hPapClient  = NETGETINST_PAP(pxIfState);
#ifdef EAP_TLS
  hEapTlsClient = NETGETINST_EAPTLS(pxIfState);
#endif
  xIfReq.ifr_name[0] = oIfIdx;
  pdwAddr = (DWORD *)&(((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr);

  switch(oCbk) {
  case NETCBK_NEEDPROCESSING:
    NETGETNEXTCALLTIME_IPCP(pxIfState) = NetGlobalTimerGet() + (DWORD)hData;
    break;

  case NETCBK_TLU:
    /* IPCP is Up */
    /* remote address */
    IpcpInstanceQuery(hIpcp,IPCPOPTION_REMOTEIPADDR,
                    (H_NETDATA *)pdwAddr);
    iRv = ioctl(iSocketFd,SIOCSIFIDSTADDR,&xIfReq);
    NETMAIN_ASSERT(iRv == 0);

    /* Dns */
    IpcpInstanceQuery(hIpcp,IPCPOPTION_PRIMARYDNS,
                      (H_NETDATA *)pdwAddr);
    if (*pdwAddr != IPCPOPTIONDNS_NONE) {
      iRv = ioctl(iSocketFd,SIOCSIFIDNS,&xIfReq);
      NETMAIN_ASSERT(iRv == 0);
    }

    /* Local address. This will also open all services */
    IpcpInstanceQuery(hIpcp,IPCPOPTION_LOCALIPADDR,
                      (H_NETDATA *)pdwAddr);
    iRv = ioctl(iSocketFd,SIOCSIFIADDR,&xIfReq);
    NETMAIN_ASSERT(iRv == 0);
    break;

  case NETCBK_TLF:
    if ((BOOL) hData) {
    /* Finished, possibly due to server not handling conf
     * requests when it believes user is still connected */
      NETMAIN_DBGP(NORMAL,"NetAdminIpCpCbk: Closed by IPCP timeout fail\n");
      NETIF_SETFLAG(pxIfConf->oFlags,IFF_PP_IPCP_FAIL);
      ChapClientInstanceMsg(hChapClient,NETMSG_CLOSE,(H_NETDATA)0);
#ifdef EAP_TLS
      EapTlsClientInstanceMsg(hEapTlsClient,NETMSG_CLOSE,(H_NETDATA)0);
#endif
      PppInstanceMsg(hPpp,NETMSG_CLOSE,(H_NETDATA)0);
      NetMainMsg(NETMAINMSG_IFCLOSE,(H_NETDATA)oIfIdx);
    }
    /* Fall through */
  case NETCBK_TLD:
    /*Signal the router that the link is down*/
#ifdef ROUTER
    {
      H_NETINSTANCE hRouter = NETGETINST_ROUTER;
      ROUTERSETLINKSTATUS xLinkStatus;

      xLinkStatus.oIfIdx = oIfIdx;
      xLinkStatus.bIsLinkUp = FALSE;

      RouterInstanceMsg(hRouter,ROUTERMSG_SETLINKSTATUS,
                        (H_NETDATA)&(xLinkStatus));
    }
#endif
    DnsMsg(DNSMSG_IFDISABLE,oIfIdx);
    break;

  case NETCBK_TLS:
    break;
  }

  return NETERR_NOERR;
}

/*
 * NetAdminPppCbk
 *  Network wrapper Ppp Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminPppCbk(H_NETINSTANCE hInst,
                    OCTET oCbk,
                    H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;
  OCTET oIfIdx = (OCTET)hInst;
  H_NETINSTANCE hIpcp,hPpp,hChapClient,hPapClient;
#ifdef EAP_TLS
  H_NETINSTANCE hEapTlsClient;
#endif

  LONG lReturn = NETERR_NOERR;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  NETMAIN_ASSERT(oIfIdx <= pxNetWrapper->oIfNumber );

  pxIfConf     = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState    = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  NETMAIN_DBG(NORMAL,
              OCTET *poString;
              if(oCbk < NETCBK_MODULESPECIFICBEGIN){
                poString = (OCTET*)apoNetCbkString[oCbk];
              } else {
                poString = (OCTET*)apoPppCbkString[oCbk - NETCBK_MODULESPECIFICBEGIN];
              }
              printf("NetAdminPppCbk:hInst=%d,oCbk=%d,oCbk=%s,hData=%d\n",
                     (int)hInst,
                     oCbk,
                     poString,
                     (int)hData););

  hIpcp       = NETGETINST_IPCP(pxIfState);
  hPpp        = NETGETINST_PPP(pxIfState);
  hChapClient = NETGETINST_CHAP(pxIfState);
  hPapClient  = NETGETINST_PAP(pxIfState);
#ifdef EAP_TLS
      EapTlsClientInstanceMsg(hEapTlsClient,NETMSG_CLOSE,(H_NETDATA)0);
#endif

  switch(oCbk) {
  case NETCBK_TLS:
    break;

  case NETCBK_NEEDPROCESSING:
    NETGETNEXTCALLTIME_PPP(pxIfState) = NetGlobalTimerGet() + (DWORD)hData;
    break;

  case NETCBK_TLU:
    ASSERT(pxIfConf->oFlags & IFF_UP);
    IpcpInstanceMsg(hIpcp,NETMSG_LOWERLAYERUP,hData);
    break;

  case NETCBK_TLD:
    IpcpInstanceMsg(hIpcp,NETMSG_LOWERLAYERDOWN,hData);
    ChapClientInstanceMsg(hChapClient,NETMSG_CLOSE,hData);
#ifdef EAP_TLS
    EapTlsClientInstanceMsg(hEapTlsClient,NETMSG_CLOSE,hData);
#endif
    PppInstanceMsg(hPpp,NETMSG_CLOSE,hData);

    if((BOOL)hData == TRUE){
      NETMAIN_DBGP(NORMAL,"NetAdminPppCbk:closed by peer\n");
      NETIF_SETFLAG(pxIfConf->oFlags,IFF_CLOSED_BY_PEER);
    }

    break;

  case NETCBK_TLF:
    NetMainMsg(NETMAINMSG_IFCLOSE,(H_NETDATA)oIfIdx);
    break;

  case PPPCBK_IDLETO:
    PppInstanceMsg(hPpp,NETMSG_CLOSE,hData);
    break;

  case PPPCBK_TRAFFICDETECTED:
    PppInstanceMsg(hPpp,NETMSG_OPEN,hData);
    break;

  case PPPCBK_AUTHENTICATECONF:
    {
      PPPOPTIONFIELD *pxOption = (PPPOPTIONFIELD *)hData;

      if (pxOption->wProtocolId == PPPID_CHAP) {
        /* If it is CHAP, then check the configuration */
        CHAPCLIENTCONF xConf;
        xConf.poConf = pxOption->poField;
        xConf.wConfLength = pxOption->wFieldLength;
        if (ChapClientInstanceMsg(hChapClient,CHAPCLIENTMSG_CONFREQ,(H_NETDATA)&xConf) < 0) {
          lReturn = NETERR_UNKNOWN;
        }
      }

    }
  break;

  case PPPCBK_AUTHENTICATE:
    ChapClientInstanceMsg(hChapClient,NETMSG_OPEN,hData);
    ChapClientInstanceMsg(hChapClient,NETMSG_LOWERLAYERUP,hData);
    PapClientInstanceMsg(hPapClient,NETMSG_OPEN,hData);
    PapClientInstanceMsg(hPapClient,NETMSG_LOWERLAYERUP,hData);
#ifdef EAP_TLS
    EapTlsClientInstanceMsg(hEapTlsClient,NETMSG_OPEN,hData);
    EapTlsClientInstanceMsg(hEapTlsClient,NETMSG_LOWERLAYERUP,hData);
#endif
    break;

  case PPPCBK_CHANGEMTU:
    {
#ifdef ROUTER
      /*
       * Inform the router about the MTU of the interface
       */
      {
         ROUTERSETIFMTU xRouterSetIfMtu = {oIfIdx, (WORD)hData};
         H_NETINSTANCE hRouterInst = NETGETINST_ROUTER;
         (LONG)RouterInstanceMsg(hRouterInst, ROUTERMSG_SETIFMTU, (H_NETDATA)&xRouterSetIfMtu);
      }
#endif

#ifdef NAT
      /*
       * Inform NAT about the MTU of the interface
       */
      {
         NATSETIFMTU xNatSetIfMtu = {oIfIdx, (WORD)hData};
         H_NETINSTANCE hRouterInst = NETGETINST_NAT;
         (LONG)NatInstanceMsg(hRouterInst, NATMSG_SETIFMTU, (H_NETDATA)&xNatSetIfMtu);
      }
#endif
    }
    break;

  case PPPCBK_ECHOTO:
    PppInstanceMsg(hPpp,NETMSG_CLOSE,hData);
    break;

  default:
    NETMAIN_ASSERT(0);
  }
  return lReturn;

}


