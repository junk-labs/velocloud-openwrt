/*
 * icmp.h
 *
 * ICMP module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ICMP_H_
#define _ICMP_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/
/*
 * ICMP defaults
 */
#define ICMPDEFAULT_OFFSET          0
#define ICMPDEFAULT_PAD             0

/*
 * ICMP message types
 *  given to IcmpInstanceWrite, and used to
 *  identify the message type.
 */
#define ICMPTYP_ECHOREPLY       0  /* Echo Reply                      */
#define ICMPTYP_DEST_UNREACH    3  /* Destination Unreachable         */
#define ICMPTYP_SOURCE_QUENCH   4  /* Source Quench                   */
#define ICMPTYP_REDIRECT        5  /* Redirect (change route)         */
#define ICMPTYP_ECHO            8  /* Echo Request                    */
#define ICMPTYP_TIME_EXCEEDED   11 /* Time Exceeded                   */
#define ICMPTYP_PARAMETERPROB   12 /* Parameter Problem               */
#define ICMPTYP_TIMESTAMP       13 /* Time stamp Request               */
#define ICMPTYP_TIMESTAMPREPLY  14 /* Time stamp Reply                 */
#define ICMPTYP_INFO_REQUEST    15 /* Information Request             */
#define ICMPTYP_INFO_REPLY      16 /* Information Reply               */
#define ICMPTYP_ADDRESS         17 /* Address Mask Request            */
#define ICMPTYP_ADDRESSREPLY    18 /* Address Mask Reply              */

/*
 * Codes used with ICMPTYP_DEST_UNREACH type.
 */
#define ICMP_NET_UNREACH        0        /* Network Unreachable             */
#define ICMP_HOST_UNREACH       1        /* Host Unreachable                */
#define ICMP_PROT_UNREACH       2        /* Protocol Unreachable            */
#define ICMP_PORT_UNREACH       3        /* Port Unreachable                */
#define ICMP_FRAG_NEEDED        4        /* Fragmentation Needed/DF set     */
#define ICMP_SR_FAILED          5        /* Source Route failed             */
#define ICMP_NET_UNKNOWN        6  /* Destination network unknown     */
#define ICMP_HOST_UNKNOWN       7  /* Destination host unknown        */
#define ICMP_HOST_ISOLATED      8  /* Source host isolated (obsolete) */
#define ICMP_NET_ANO            9  /* Dest. network admin. prohibited */
#define ICMP_HOST_ANO           10 /* Dest. host admin. prohibited    */
#define ICMP_NET_UNR_TOS        11 /* Network unreachable for TOS     */
#define ICMP_HOST_UNR_TOS       12 /* Host unreachable for TOS        */
#define ICMP_COMM_ANO           13 /* Communication admin. prohibited */
#define ICMP_HOST_PRE_VIO       14 /* Host precedence violation       */
#define ICMP_PRE_CUTOFF         15 /* Precedence cutoff in effect     */

/*
 * Codes used with ICMPTYP_REDIRECT type.
 */
#define ICMP_REDIR_NET          0 /* Redirect Net                     */
#define ICMP_REDIR_HOST         1 /* Redirect Host                    */
#define ICMP_REDIR_NETTOS       2 /* Redirect Net for TOS             */
#define ICMP_REDIR_HOSTTOS      3 /* Redirect Host for TOS            */

/*
 * Codes used with ICMPTYP_TIME_EXCEEDED type.
 */
#define ICMP_TIME_EXCEEDED_TTL            0 /* TTL count exceeded               */
#define ICMP_TIME_EXCEEDED_FRAGTIME       1 /* Fragment Reass time exceeded     */

#ifdef NEW_ICMP_MSG_ADDED
#define ICMPERR_UNREACH_NET      1
#define ICMPERR_UNREACH_HOST     2
#define ICMPERR_UNREACH_PROTOCOL 3
#define ICMPERR_UNREACH_PORT     4
#define ICMPERR_MSGSIZE          5 /*Fragmentation needed and DF bit set*/
#define ICMPERR_PARAMPROB        6
#define ICMPERR_QUENCH           7
#define ICMPERR_TIMEXCEEDED      8
#endif

/*
 * ICMP UL ioctls
 *  o All are covered in netcommon.h (LIBNETCOMMON)
 */

/*
 * ICMP LL Ioctls
 *  o All are covered in netcommon.h (LIBNETCOMMON)
 *  o the PFN_NETWRITE provided with
 *    NETINTERFACEIOCTL_SETOUTPUTPFN will be given as hIcmpDst a pointer
 *    to a icmp_dst defined in icmp.h
 */
#define ICMPMSG_BEGIN \
          (NETNETWORKMSG_MODULESPECIFICBEGIN)
#define ICMPMSG_SENDFRAGNEEDED \
          (ICMPMSG_BEGIN)     /*used by ip fragmentation
                                par: ICMPMSGDATA   */

#define ICMPMSG_SENDPORTUNREACH \
          (ICMPMSG_BEGIN + 1) /*used in udp
                                par: ICMPMSGDATA */

#define ICMPMSG_SENDNETUNREACH \
          (ICMPMSG_BEGIN + 2) /*used in router
                                par: ICMPMSGDATA   */

#define ICMPMSG_SENDHOSTUNREACH \
          (ICMPMSG_BEGIN + 3) /*used in router
                                par: ICMPMSGDATA   */

#define ICMPMSG_SENDECHO  \
          (ICMPMSG_BEGIN + 4) /*used by the wrapper to send ping request
                                par: ICMPMSGDATA   */

#define ICMPMSG_SENDTIMEEXCEEDEDTTL  \
          (ICMPMSG_BEGIN + 5) /*used by the router
                                par: ICMPMSGDATA   */

#define ICMPMSG_SENDTIMEEXCEEDEDFRAGTIME  \
          (ICMPMSG_BEGIN + 6) /*used by ip fragmentation
                                par: ICMPMSGDATA   */
#define ICMPMSG_SEND_MAX  \
          (ICMPMSG_BEGIN + 6) /* Max send message */

#define ICMPMSG_DONTREPLYTOPING  \
          (ICMPMSG_BEGIN + 7) /*used by the wrapper to disable any ping reply
                                par: DWORD. MS WORD is interface index,
                                LSB is BOOL */
#ifdef NEW_ICMP_MSG_ADDED

#define ICMPMSG_PROTOCOLUNREACHABLE \
          (ICMPMSG_BEGIN + 8) /*used within IP module for sending unreachable protocol*/

#define ICMPMSG_REDIRECTHOST \
          (ICMPMSG_BEGIN + 9) /*For router to send an re-direct*/

#define ICMPMSG_TIMESTAMPREQ \
          (ICMPMSG_BEGIN + 10) /*For Time stamp request */

#define ICMPMSG_MAX  \
          (ICMPMSG_BEGIN + 10)

#else

#define ICMPMSG_MAX  \
          (ICMPMSG_BEGIN + 7)

#endif

/*
 * ICMP call back message
 *  data is ICMPCBKDATA *
 */

#define ICMPCBK_ECHOREPLY  \
          NETCBK_MODULESPECIFICBEGIN

#define ICMPCBK_DESTUNREACHABLE  \
          (NETCBK_MODULESPECIFICBEGIN + 1)

#define ICMPCBK_REDIRECT  \
          (NETCBK_MODULESPECIFICBEGIN + 2)

#ifdef NEW_ICMP_MSG_ADDED

#define ICMPCBK_TIME_EXCEEDED \
          (NETCBK_MODULESPECIFICBEGIN + 3)
#define ICMPCBK_PARAMETER_PROBLEM \
          (NETCBK_MODULESPECIFICBEGIN + 4)
#define ICMPCBK_SOURCE_QUENCH \
          (NETCBK_MODULESPECIFICBEGIN + 5)

#endif

/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/
/*
 * ICMP packet definition
 */
typedef struct{
  OCTET oType;
  OCTET oCode;
  WORD wChecksum;
  union {
    struct {
      WORD wId;
      WORD wSequence;
    } xEcho;

    DWORD dwGateway;

    struct {
      WORD wIpmVoid;
      WORD wIpmNextMtu;
    } xIhPmtu;

  } u;
} ICMP_HDR;


typedef struct {
  NETPACKET *pxNetPacket;
  NETPACKETACCESS *pxNetPacketAccess;
  DWORD dwSrcAddr;
  DWORD dwDstAddr;
  WORD wVlan;
  WORD wMtu;
  OCTET oIfIdx;
#ifdef _RADIX_ROUTING_ON_
  OCTET oProtocol;
#endif
} ICMPMSGDATA;

typedef struct {
  NETPACKET *pxNetPacket;
  NETPACKETACCESS *pxNetPacketAccess;
  NETWORKID *pxNetworkId;
#ifdef NEW_ICMP_MSG_ADDED
  ICMP_HDR *pxIcmpHdr;
#else
  OCTET oCode;
#endif
} ICMPCBKDATA;

#ifdef NEW_ICMP_MSG_ADDED
/*
 * This structure is right now common for TCP & UDP transport layers.
 * It could be later on split to cater to the different transport modules, if they
 * more attributes to be added in
 */
typedef struct{
  NETPACKET *pxNetPacket;
  NETPACKETACCESS *pxNetPacketAccess;
  sbyte oCode;
} TRANSPORTMSGDATA;
#endif

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * IcmpInitialize
 *  Initialize the ICMP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IcmpInitialize(void);

/*
 * IcmpTerminate
 *  Terminate the ICMP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IcmpTerminate(void);

/*
 * IcmpInstanceCreate
 *  Creates a ICMP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IcmpInstanceCreate(void);

/*
 * IcmpInstanceDestroy
 *  Destroy a ICMP Instance
 *
 *  Args:
 *   hIcmp                 ICMP instance
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceDestroy(H_NETINSTANCE hIcmp);

/*
 * IcmpInstanceSet
 *  Set a ICMP Instance Option
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceSet(H_NETINSTANCE hIcmp, OCTET oOption,
                     H_NETDATA hData);

/*
 * IcmpInstanceQuery
 *  Query a ICMP Instance Option
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceQuery(H_NETINSTANCE hIcmp,OCTET oOption,
                       H_NETDATA *phData);

/*
 * IcmpInstanceMsg
 *  Send a msg to a ICMP instance
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *   oMsg                       Msg. See netcommon.h and icmp.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceMsg(H_NETINSTANCE hIcmp,OCTET oMsg,
                     H_NETDATA hData);

/*
 * IcmpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IcmpInstanceLLInterfaceCreate(H_NETINSTANCE hIcmp);

/*
 * IcmpInstanceLLInterfaceDestroy
 *  Destroy a ICMP LL interface
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceLLInterfaceDestroy(H_NETINSTANCE hIcmp,
                                    H_NETINTERFACE hInterface);


/*
 * IcmpInstanceLLInterfaceIoctl
 *  ICMP LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and netransport.h
 *  for precisions
 *
 *  Args:
 *   hIcmp                        Icmp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceLLInterfaceIoctl(H_NETINSTANCE hIcmp,
                                  H_NETINTERFACE hLLInterface,
                                  OCTET oIoctl,
                                  H_NETDATA hData);

/*
 * IcmpInstanceRcv
 *   ICMP Instance Rcv function. Follows PFN_NETWORRXCBK
 *   typedef.
 *
 *   Args:
 *    hIcmp                      Ud Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    pxAccess                   access info
 *    hData                      unused(could be used for VLAN)
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG IcmpInstanceRcv(H_NETINSTANCE hIcmp,
                     H_NETINTERFACE hIf,
                     NETPACKET *pxPacket,
                     NETPACKETACCESS *pxAccess,
                     H_NETDATA hData);



/*
 * IcmpInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hIcmp                       ICMP Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 5 ms)
 */
LONG IcmpInstanceProcess(H_NETINSTANCE hIcmp);

#endif /* #ifndef _ICMP_H_ */
