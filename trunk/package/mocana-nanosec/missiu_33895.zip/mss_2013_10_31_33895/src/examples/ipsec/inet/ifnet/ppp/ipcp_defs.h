/*
 * ipcp_defs.h
 *
 * IPCP definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _IPCP_DEFS_H_
#define _IPCP_DEFS_H_

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"

#include "ipcp_flavor.h"
#include "string.h"
#include "stdlib.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h> /* ntoh macros */
#include <netinet/in.h> /* ntoh macros on Linux/Solaris */
#include <pthread.h>
#include <mqueue.h>
#include <stdio.h>
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"
#include "pppcp.h"
#include "ipcp.h"
#include "ipcp_dbg.h"

/*****************************************************************************
 *
 * Defines & macros
 *
 *****************************************************************************/

/*
 * IPCP protocol parsing
 */
#define IPCPPROTOPTION_HLEN 2

#define IPCPPROTOPTIONOFFSET_TYPE 0
#define IPCPPROTOPTIONGET_TYPE(poPacket)                                \
  ((E_IPCPPROTOPTION) (*(poPacket + IPCPPROTOPTIONOFFSET_TYPE)))
#define IPCPPROTOPTIONSET_TYPE(poPacket,eType)                          \
  (*(poPacket + IPCPPROTOPTIONOFFSET_TYPE) = (OCTET) eType)

#define IPCPPROTOPTIONOFFSET_LENGTH 1
#define IPCPPROTOPTIONGET_LENGTH(poPacket)                              \
  ((OCTET)(*(poPacket + IPCPPROTOPTIONOFFSET_LENGTH)))
#define IPCPPROTOPTIONSET_LENGTH(poPacket,oLength)                      \
  (*(poPacket + IPCPPROTOPTIONOFFSET_LENGTH) = oLength)


#define IPCPPROTOPTIONLENGTH_IPADDRESS 6 /* Includes the option header
                                            field */
#define IPCPPROTOPTIONSET_IPADDRESS(poPacket,dwIpAddr) do {          \
    *((WORD *)(poPacket + IPCPPROTOPTION_HLEN)) =                       \
      htons((WORD)(dwIpAddr >> 16));                              \
    *((WORD *) (poPacket + IPCPPROTOPTION_HLEN + 2)) =                  \
      htons((WORD)(dwIpAddr & 0xFFFF));                             \
  }while(0)
#define IPCPPROTOPTIONGET_IPADDRESS(poPacket)                           \
  ((DWORD) ((ntohs(*(WORD *)(poPacket + IPCPPROTOPTION_HLEN)) << 16) |  \
   (ntohs(*(WORD *)(poPacket + IPCPPROTOPTION_HLEN + 2)) & 0xFFFF)))

#define IPCPPROTOPTIONLENGTH_PRIMARYDNS 6 /* Includes the option header
                                             field */
#define IPCPPROTOPTIONSET_PRIMARYDNS(poPacket,dwDns) do {          \
    *((WORD *)(poPacket + IPCPPROTOPTION_HLEN)) =                       \
      htons((WORD)(dwDns >> 16));                              \
    *((WORD *) (poPacket + IPCPPROTOPTION_HLEN + 2)) =                  \
      htons((WORD)(dwDns & 0xFFFF));                             \
  }while(0)
#define IPCPPROTOPTIONGET_PRIMARYDNS(poPacket)                           \
  ((DWORD) ((ntohs(*(WORD *)(poPacket + IPCPPROTOPTION_HLEN)) << 16) |  \
   (ntohs(*(WORD *)(poPacket + IPCPPROTOPTION_HLEN + 2)) & 0xFFFF)))

#define IPCPPROTOPTIONLENGTH_SCNDARYDNS 6 /* Includes the option header
                                             field */
#define IPCPPROTOPTIONSET_SCNDARYDNS(poPacket,dwDns) do {          \
    *((WORD *)(poPacket + IPCPPROTOPTION_HLEN)) =                       \
      htons((WORD)(dwDns >> 16));                              \
    *((WORD *) (poPacket + IPCPPROTOPTION_HLEN + 2)) =                  \
      htons((WORD)(dwDns & 0xFFFF));                             \
  }while(0)
#define IPCPPROTOPTIONGET_SECNDARYDNS(poPacket)                           \
  ((DWORD) ((ntohs(*(WORD *)(poPacket + IPCPPROTOPTION_HLEN)) << 16) |  \
   (ntohs(*(WORD *)(poPacket + IPCPPROTOPTION_HLEN + 2)) & 0xFFFF)))


/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/

/*
 * IPCP Options Enum
 */
typedef enum {
  /* IPCPPROTOPTION_IP_ADDRESSES = 1 is deprecated */
  /* IPCPPROTOPTION_IPCOMPRESSIONPROTOCOL = 2, Not yet implemented */
  IPCPPROTOPTION_IPADDRESS = 3,
  /* Dns extensions. Are only valid in the _dns flavors. To
     enable DNS negociation, IpcpSetLocalOptionRepository must
     be called with a repository containing the initial value for
     IPCPPROTOPTION_PRIMARYDNS and/or IPCPPROTOPTION_SECONDARYDNS, with a
     value != IPCPPROTNODNS .
     The DNS option are only supported on the local side (this a IPCP
     client) */
  IPCPPROTOPTION_PRIMARYDNS = 129,  /* Only supported in _dns flavor */
  IPCPPROTOPTION_SCNDARYDNS = 131 /* Only supported in _dns flavor. Can't
                                  be used if IPCPPROTOPTION_PRIMARYDNS is
                                  not also used ...*/
} E_IPCPPROTOPTION;

/*
 * IPCP state main structure
 */
typedef struct {
  #ifndef NDEBUG
  DWORD dwMagicCookie;
  #endif

  OCTET oLLNumber;

  H_NETINSTANCE hCp;
  H_NETINTERFACE hCpIf;

  PFN_NETCBK pfnNetCbk;
  H_NETINSTANCE hNetCbk;

  DWORD dwLocalIpAddr;
  DWORD dwRemoteIpAddr;

  DWORD dwPrimaryDnsIpAddr;
  DWORD dwScndaryDnsIpAddr;

} IPCPSTATE;

#endif /* _IPCP_DEFS_H_ */
