/*
 * netstack.h
 *
 * Non standard network API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETSTACK_H_
#define _NETSTACK_H_

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * NetInitialize
 *  This function inits the network stack.
 *
 *  Args:
 *
 *  Return:
 *   TRUE - success,
 *   FALSE - error
 */
LONG  NetInitialize(void);

/*
 * NetTerminate
 *  Terminates the network stack
 *
 *  Args:
 *
 *  Return:
 *   TRUE - success,
 *   FALSE - error
 */
LONG  NetTerminate(void);



/*
 * NetPing
 *  Ping RemoteIP from LocalIP
 *
 * Arg:
 *  dwLocalIP                      Local IP address of the host.
 *                                 If zero, first default IP address entry
 *                                 is used. If that is also zero, error is
 *                                 returned.
 *  dwRemoteIP                     Remote IP address of the remote host which
 *                                 is ping-ed
 *
 * Return :
 *  0 or more: successful connection number
 */
LONG NetPing(DWORD dwLocalIP, DWORD dwRemoteIP);

/*
 * NetPingStat
 *  Check Status on Ping request (from LocalIP to RemoteIP)
 *
 * Args:
 *  dwLocalIP                    Local IP address of the host. If zero,
 *                               first default IP address entry is used.
 *                               If that is also zero, error is returned.
 *  dwRemoteIP                   Remote IP address of the remote host which
 *                               is ping-ed
 *
 * Return:
 *  0 : ping failed
 *  1 : ping success
 */
LONG NetPingStat(DWORD dwLocalIP,DWORD dwRemoteIP);

#endif /* #ifndef _NETSTACK_H_ */
