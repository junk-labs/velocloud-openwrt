/*
 * transportparser.h
 *
 * Transport parser macro definitions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __TRANSPORTPARSER_H__
#define __TRANSPORTPARSER_H__

#include "netcommon.h"
#include "tcp.h"
#include "udp.h"
#include "../include/socket.h"

#define TCP_FLAGS_IS_SYN(x) (((x)->oFlags & TCPCONN_FLAGMASK_SYN) != 0)
#define TCP_FLAGS_IS_ACK(x) (((x)->oFlags & TCPCONN_FLAGMASK_ACK) != 0)
#define TCP_FLAGS_IS_RST(x) (((x)->oFlags & TCPCONN_FLAGMASK_RST) != 0)
#define TCP_FLAGS_IS_FIN(x) (((x)->oFlags & TCPCONN_FLAGMASK_FIN) != 0)

#define TCP_GET_SEQ_NUM(x) (ntohl((x)->dwSequencenumber))
#define TCP_SET_SEQ_NUM(x,y) ((x)->dwSequencenumber = htonl(y))
#define TCP_GET_ACK_NUM(x) (ntohl((x)->dwAcknowledgenumber))
#define TCP_SET_ACK_NUM(x,y) ((x)->dwAcknowledgenumber = htonl(y))

#define TCP_GET_CHECKSUM(x) (ntohs((x)->wChecksum))
#define TCP_SET_CHECKSUM(x,y) ((x)->wChecksum = htons(y))

#define TCP_GET_HEADER_LEN(x) (((x)->oTcpHdrLen>>4)*4)

#define UDP_GET_CHECKSUM(x) (ntohs((x)->wCheck))
#define UDP_SET_CHECKSUM(x,y) ((x)->wCheck = htons(y))

#define TRANSPORT_GET_SRC_PORT(x) (ntohs(((WORD*)(x))[0]))
#define TRANSPORT_SET_SRC_PORT(x,y) (((WORD*)(x))[0] = htons(y))
#define TRANSPORT_GET_DST_PORT(x) (ntohs(((WORD*)(x))[1]))
#define TRANSPORT_SET_DST_PORT(x,y) (((WORD*)(x))[1] = htons(y))

#endif /* #ifndef __TRANSPORTPARSER_H__*/
