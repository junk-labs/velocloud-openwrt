/*
 * nettime.h
 *
 * Network wide timer utilities
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETTIME_H_
#define _NETTIME_H_

#define CLOCK_REALTIME    0

struct timespec
  {
#if 0
    __time_t tv_sec;            /* Seconds.  */
#else
    long int  tv_sec;            /* Seconds.  */
#endif
    long int tv_nsec;           /* Nanoseconds.  */
  };

/*
 * NetGlobalTimerGet
 *  Gets the value of the network global timer
 *  This timer is updated at least once every time the
 *  network thread is run. Less precise, but faster
 *  than NetGetMsecTime
 *
 *  Args:
 *
 *  return:
 *   global timer value in msec
 */
DWORD NetGlobalTimerGet(void);

/*
 * NetGlobalTimerSet
 *  Sets the global timer
 *
 *  Args:
 *   tsNow          Timespec structure
 *
 *  Return:
 *   global timer new value in msec
 */
DWORD NetGlobalTimerSet(void);

/*
 * NetGetMsecTime
 *  returns the current time in msec.
 *  Updates the global timer in the process
 *
 * Args:
 *
 * Return:
 *  time in msec
 */
DWORD NetGetMsecTime(void);


#endif /* #ifndef _NETTIME_H_ */
