#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void del_DLLIST_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem)
{
  dllitem->next = dllist->free;
  dllist->free = dllitem;
}

