/*
 * netif.h
 *
 * interface management declaration
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETIF_H_

/****************************************************************************
 *
 * Defines
 *
 ****************************************************************************/

/*
 * Netif messages
 */
/* Update the IP address
   from the coresponding IfConf */
#define NETIFMSG_UPDATEIPADDR           NETMAINMSG_IFUPDATEIPADDR
/* Update the netmask from
   the coresponding IfConf */
#define NETIFMSG_UPDATENETMASK          NETMAINMSG_IFUPDATENETMASK

#define NETMAINMSGTONETIFMSG(A) A

#define NETIFPROCESS_MAXPACKETREAD  1  /* Limits number of packets which can
                                           be processed in thread run */

#define NETPACKET_ATM_MAXSIZE 1524
#define NETPACKET_ETH_DRVOFF  2 /* 2 byte ofoset for the ethernet driver */
#define NETPACKET_ETH_VLANLEN 4 /* A VLAN tag is 4 bytes */
#define NETPACKET_ETH_MAXSIZE (1514 + NETPACKET_ETH_DRVOFF + \
                               NETPACKET_ETH_VLANLEN)

/****************************************************************************
 *
 * Typedefs
 *
 ****************************************************************************/




/****************************************************************************
 *
 * Function declaration
 *
 ****************************************************************************/

/*
 * NetIfSetup
 *  Sets up an interface. The type must be a valid one
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Wrapper
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   0
 */
LONG NetIfSetup(NETWRAPPER *pxWrapper,OCTET oIfIdx);

/*
 * NetIfOpen
 *  Open an interface. Set it up if it has not been set
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper                Network wrapper pointer
 *   oIfIdx                   Interface index
 *
 *  Return:
 *   >=0 on success
 */
LONG NetIfOpen(NETWRAPPER *pxWrapper,OCTET oIfIdx);

/*
 * NetIfEnableNetworkServices
 *  Enable Network layer services (DNS) on an interface
 *  Must only be called if Phy, Link and Net layers are up
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfEnableNetworkServices(NETWRAPPER *pxWrapper,OCTET oIfIdx);

/*
 * NetIfDisableNetworkServices
 *  Disable Network layer services (DNS) on an interface
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfDisableNetworkServices(NETWRAPPER *pxWrapper,OCTET oIfIdx);

/*
 * NetIfPhyStatusUs
 *  Query the interface Phy upstream status and bitrate
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *    0 == link down, >0 == bitrate (Kbits/sec)
 */
LONG NetIfPhyStatusUs(NETWRAPPER *pxWrapper,OCTET oIfIdx);

/*
 * NetIfPhyDown
 *  Signal the interface that the phy is down
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfPhyDown(NETWRAPPER *pxWrapper,OCTET oIfIdx);

/*
 * NetIfPhyUp
 *  Signal the interface that the phy is up
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfPhyUp(NETWRAPPER *pxWrapper,OCTET oIfIdx);

/*
 * NetIfProcessDrv
 *  Network interface processing: driver & link layer modules.
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Network wrapper
 *   oIfIdx                    interface index
 *
 *  Return:
 *   >= 0 - number of packets read   < 0 - error
 */
LONG NetIfProcessDrv(NETWRAPPER *pxWrapper,OCTET oIfIdx);

/*
 * NetIfProcessLnk
 *  Network interface processing: link layer modules.
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Network wrapper
 *   oIfIdx                 interface index
 *
 *  Return:
 *   0
 */
LONG NetIfProcessLnk(NETWRAPPER *pxWrapper,OCTET oIfIdx);

 /*
 * NetIfDriverWrite
 *  Write function provided to the lowest link module LL
 *
 *  Args:
 *   hLLInst               casted driver file descriptor
 *   hIf                   Unused.
 *   pxPacket              packet structure pointer
 *   pxAccess              access structure pointer
 *   hData                 Unused.
 *
 *  Return:
 *   Length written or NETERR_XXX
 */

LONG NetIfDriverWrite(H_NETINSTANCE hLLInst,
                      H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,
                      NETPACKETACCESS *pxAccess,
                      H_NETDATA hData);

/*
 * NetIfIfIpUp
 *  Things to do when an interface got a valid IP address
 *
 *  Args:
 *   pxWrapper            Wrapper pointer
 *   oIfIdx                  interface index
 *
 *  Return:
 *   0
 */
LONG NetIfIpUp(NETWRAPPER *pxNetWrapper,OCTET oIfIdx);

/*
 * NetIfClose
 *  Closes an interface. Does not free up the ressources
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxNetWrapper            Wrapper pointer
 *   oIfIdx                  interface index
 *
 *  Return:
 *   0
 */
LONG NetIfClose(NETWRAPPER *pxNetWrapper,OCTET oIfIdx);

/*
 * NetIfTearDown
 *  Tears down an interface. Actually frees up the ressources.
 *  Will close the interface if it has not been done.
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxNetWrapper            Wrapper pointer
 *   oIfIdx                  interface index
 *
 *  Return:
 *   0
 *
 */
LONG NetIfTearDown(NETWRAPPER *pxNetWrapper,OCTET oIfIdx);

/*
 * NetIfSignalOpen
 *  Signal that an interface has opened and is up.
 *  If a callback function has been registered,
 *  create a dedicated thread for execution of the callback function
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Wrapper
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   0
 */
LONG NetIfSignalOpen(NETWRAPPER *pxNetWrapper,OCTET oIfIdx);

/*
 * NetIfSignalClose
 *  Signal that an interface is about to close. If a callback
 *  function has been registered, create a dedicated thread
 *  for execution of the callback function
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Wrapper
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   0
 */
LONG NetIfSignalClose(NETWRAPPER *pxNetWrapper,OCTET oIfIdx);

/*
 * NetIfSignalDhcpError
 *  Signal that an interface has experienced a DHCP client error.
 *  Error may be:
 *    - timeout while attempting to acquire an address
 *    - received a NACK while renewing/acquiring
 *    - lease has expired
 *  If a callback function has been registered,
 *  create a dedicated thread for execution of the callback function
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Wrapper
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   0
 */
LONG NetIfSignalDhcpError(NETWRAPPER *pxNetWrapper,OCTET oIfIdx);

/*
 * NetIfIfLogicalUp
 *  Things to do when an interface got a valid IP address
 *
 *  Args:
 *   pxWrapper            Wrapper pointer
 *   oIfIdx                  interface index
 *
 *  Return:
 *   0
 */
LONG NetIfLogicalUp(NETWRAPPER *pxNetWrapper,OCTET oIfIdx);

/*
 * NetIfGetShortValue
 * Returns a short value in HOST order from a character buffer
 *
 *  Args:
 *   buf              Buffer
 *
 *  Return:
 *   short value
 */
ubyte2 NetIfGetShortValue(const ubyte* buf);

#endif /* #ifndef _NETIF_H_ */



