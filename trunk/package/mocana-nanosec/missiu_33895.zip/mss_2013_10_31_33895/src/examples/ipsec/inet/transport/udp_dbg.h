/*
 * udp_dbg.h
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __UDP_DBG_H__
#define __UDP_DBG_H__

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef UDPDBG_HI
   #define UDPDBG_HI
  #endif
 #endif

#else
 #ifdef UDPDBG_HI
  #undef UDPDBG_HI
 #endif
#endif

#include "netdbg.h"


#define UDP_MAGIC_COOKIE 0x75647020 /*"udp " = 0x75647020*/

/*#ifdef UDPDBG_HI*/
#if defined(UDPDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define UDP_CHECK_STATE(x) \
            ASSERT((x) && ((x)->dwMagicCookie == UDP_MAGIC_COOKIE));

  #define UDP_SET_COOKIE(x) (x)->dwMagicCookie = UDP_MAGIC_COOKIE
  #define UDP_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define UDP_DBGP(level, fmt, args...)    do {    \
    if (level <= g_dwUdpDebugLevel) {        \
      printf(fmt, ##args);                \
    }                            \
  } while (0)

  #define UDP_DBG(level, x)    do {        \
    if (level <= g_dwUdpDebugLevel) {        \
      x;                        \
    }                            \
  } while (0)

  #define UDP_DBG_VAR(x)  x

  #define UDEBUG(x) x

  #define UDP_ASSERT_HI(x) ASSERT(x)

#else
  #define UDP_CHECK_STATE(x)
  #define UDP_SET_COOKIE(x)
  #define UDP_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define UDP_DBGP
#else
  #define UDP_DBGP(level, fmt, args...)
#endif
  #define UDP_DBG(level, x)
  #define UDP_DBG_VAR(x)
  #define UDP_ASSERT_HI(x)
#endif

#define SNMP(x)


#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /*#ifndef __UDP_DBG_H__*/
