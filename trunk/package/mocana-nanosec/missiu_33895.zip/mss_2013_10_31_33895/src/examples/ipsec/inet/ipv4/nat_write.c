/*
 * nat_write.c
 *
 * NAT Tx function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/
#include "nat.h"
#include "nat_defs.h"

/*****************************************************************************
 *
 * DEBUG
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * NatInstanceWrite
 *  NAT Instance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hNat                    NAT Instance handle
 *   hIf                     Upper Layer interface handle
 *   pxNetPacket             Packet pointer
 *   pxNetPacketAccess       info about packet
 *   hData                   pointer to a NETWORKID structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG NatInstanceWrite(H_NETINSTANCE    hNatInst,
                      H_NETINTERFACE   hULIf,
                      NETPACKET        *pxNetPacket,
                      NETPACKETACCESS  *pxNetPacketAccess,
                      H_NETDATA        hData)
{
  NATSTATE           *pxNat = (NATSTATE *)hNatInst;
  NETPAYLOAD         *pxPayload = pxNetPacket->pxPayload;
  E_NAT_RETURN_VALUE eNatRv = NAT_PACKET_UNKNOWN;
  void               *pvProtocolHdr = NULL;
  NETWORKID          *pxNetworkId = (NETWORKID*) hData;


  NAT_CHECK_STATE(pxNat);
  NETPACKET_CHECK(pxNetPacket);
  ASSERT((pxNetPacketAccess != NULL) &&
         (pxNetworkId != NULL) &&
         (pxNat->pfnLLWrite != NULL));


  /*************************************************
   *
   * Check if the UL Interface is valid
   *
   ************************************************/
  NETDBG_ASSERT((OCTET)hULIf == 1);


  /*************************************************
   *
   * Just pass the data down if the target interface
   * of the packet is LAN or the traffic is going to
   * be tunnelled in IPSEC.
   *
   ************************************************/
  if ((pxNetworkId->oIfIdx == pxNat->oIfIdxLan) ||
      (pxNetworkId->dwSecurityPolicy != 0x0)) {
    return pxNat->pfnLLWrite(pxNat->hLLInst,
                             pxNat->hLLIf,
                             pxNetPacket,
                             pxNetPacketAccess,
                             hData);
  }


  pvProtocolHdr = (void*) (pxPayload->poPayload +
                           pxNetPacketAccess->wOffset);
  ASSERT(((DWORD) pvProtocolHdr & 0x3) == 0);

  /****************************************************************
   *
   * Perform some minimal checks for data integrity.
   *
   ***************************************************************/
  ASSERT(pxNetPacket->pxPayload->wSize >= (pxNetPacketAccess->wOffset + pxNetPacketAccess->wLength));

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
  {
    /*NAT_DBGP(DBGLVL_REPETITIVE, "NatInstanceWrite(): %ld.%ld.%ld.%ld ==> %ld.%ld.%ld.%ld  %s, length=%d, DstAddrType=%s\n",
                        IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
                        IPADDRDISPLAY(pxNetworkId->dwDstAddr),
                        IpProtoToString(pxNetworkId->oProtocol),
                        pxNetworkId->wTotalLen,
                        IpAddressTypeToString(pxNetworkId->eDstAddrType));*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "NatInstanceWrite(): ", pxNetworkId->dwSrcAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " ==> ", pxNetworkId->dwDstAddr);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, ", oProtocol = ", IpProtoToString(pxNetworkId->oProtocol));
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", length = ", pxNetworkId->wTotalLen);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, ", DstAddrType = ", IpAddressTypeToString(pxNetworkId->eDstAddrType));
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(pxNetworkId->eDstAddrType){
  case IPADDRT_BROADCAST:
  case IPADDRT_MULTICAST:
  case IPADDRT_MULTICASTJOINED:
  case IPADDRT_MULTICASTJOINEDPROXY:
  case IPADDRT_MULTICASTJOINEDSOCKPROXY:
    eNatRv = NAT_OK;
    break;
  case IPADDRT_LOOPBACK:
  case IPADDRT_MYADDR:
  case IPADDRT_PPPPEER:
  case IPADDRT_OUTSIDE:
  case IPADDRT_MYSUBNET:
    switch (pxNetworkId->oProtocol) {
      case IPPROTO_UDP:
      case IPPROTO_TCP:
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "SrcP %d, DstP %d\n",
                 TRANSPORT_GET_SRC_PORT(pvProtocolHdr),
                 TRANSPORT_GET_DST_PORT(pvProtocolHdr));*/
          DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "SrcP = ", TRANSPORT_GET_SRC_PORT(pvProtocolHdr));
          DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "DstP = ", TRANSPORT_GET_DST_PORT(pvProtocolHdr));
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }

        eNatRv = NatHandleTUTx(pxNat,
                               pxNetPacket,
                               pxNetPacketAccess,
                               hData,
                               pvProtocolHdr);
        break;

      case IPPROTO_ICMP:
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "\n");*/
          DEUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }
        eNatRv = NatHandleIcmpTx(pxNat,
                                 pxNetPacket,
                                 pxNetPacketAccess,
                                 hData,
                                 pvProtocolHdr);
        break;

      default:
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "\n");*/
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }
    }
    break;
  case IPADDRT_UNKNOWN:
  case IPADDRT_INVBCAST:
  case IPADDRT_ANY:
  /*Fall thru*/
  default:
    ASSERT(0);
  }

  /***************************************************************************
   * Q: What does NAT do with multicast/broadcast packets here?
   * A: Nothing. The IP router should do proper filtering before handing over
   *    the packets to NAT. Just send them down to the lower layer
   *    untouched.
   *    NOTE: There is no address translation on the broadcast/multicast
   *          packets in the current implementation.
   **************************************************************************/

  NAT_DBG(DBGLVL_REPETITIVE,if(eNatRv != NAT_OK) {printf("NatInstanceWrite():binning packet\n");});

  switch (eNatRv) {

    case NAT_DO_NOTHING:
      return (0);

    case NAT_OUT_OF_RESOURCE:
    case NAT_PACKET_UNKNOWN:
      NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
      return (LONG)-1;

    case NAT_OK:
      /*
       * Hand over the data to link layer.
       * NOTE: Packets originating from the CPE should flow thru'
       *       this path. They will never get freed above.
       */
      return pxNat->pfnLLWrite(pxNat->hLLInst,
                               pxNat->hLLIf,
                               pxNetPacket,
                               pxNetPacketAccess,
                               hData);

    default:
  }

  NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
  return (LONG)-1;
}
