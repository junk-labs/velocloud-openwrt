/*
 * socket_lib.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/



#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"

#ifdef __SOCKET_USE_MEMPOOL__
#ifdef __BACKTRACE_SUPPORTED__
#include <execinfo.h>
#include <stdio.h>
#endif
#endif

#ifdef IPSEC
#include "ipsec.h"
#if 0 /* IPSEC is not configed by us */
#include "ipsec_api.h"
#endif
#endif /* IPSEC */

#ifdef SOCK_RT
  #include "router.h"
  #include "nat.h"
#endif

#ifdef SOCK_BR
  #include "ethernet.h"
#endif

/****************************************************************************
 *
 * Network internal  API functions
 *
 ****************************************************************************/

#ifndef __SELECT_OPT_ON__

static LONG _SockComparePIDFD (const void *pPidfd1, const void *pPidfd2, const void *config)
{
  PIDFDINFO *p1 = (PIDFDINFO *)pPidfd1;
  PIDFDINFO *p2 = (PIDFDINFO *)pPidfd2;

  if (p1->lFd < p2->lFd)
    return -1;
  else if (p1->lFd > p2->lFd)
    return 1;

  return 0;

}

static LONG _SockComparePID (const void *pPid1, const void *pPid2, const void *config)
{
  PIDINFO *p1 = (PIDINFO *)pPid1;
  PIDINFO *p2 = (PIDINFO *)pPid2;

  if (p1->lPid < p2->lPid)
    return -1;
  else if (p1->lPid > p2->lPid)
    return 1;

  return 0;

}

#endif

/*
 * SocketLibraryInitialize
 *  Initialize TCP/IP sockets, open tcp and udp pseudo files and
 *  create the socket device. MUST be called after UDP and TCP
 *  instances have been created.
 *
 *  Args:
 *
 *  Return:
 *   success/failure on creating the socket device
 */
LONG SocketLibraryInitialize()
{
  static struct file_operations fopSock;
  int iRv = 0;
#ifdef __SOCKET_USE_MEMPOOL__
  MSTATUS status = OK;
  void *pTempMemBuffer = NULL;
#endif

  if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, NORMAL))
  {
      DEBUG_PRINTNL(DEBUG_MOC_IPV4,"SocketLibraryInitialize\n");
  }

  fopSock.open  = SocketOpen;
  fopSock.close = SocketClose;
  fopSock.read  = SocketRecv;
  fopSock.write = SocketSend;
  fopSock.ioctl = SocketIoctl;

#if 0
  iRv |= mknod("/dev/socket/tcp", 0, MKDEV(DEVICE_MAJOR_SCK, SOCK_STREAM));
  ASSERT(iRv == 0);
  iRv |= mknod("/dev/socket/udp", 0, MKDEV(DEVICE_MAJOR_SCK, SOCK_DGRAM));
  ASSERT(iRv == 0);

#endif
  iRv |= register_chrdev(DEVICE_MAJOR_SCK, "/dev/socket/tcp", &fopSock);
  iRv |= register_chrdev(DEVICE_MAJOR_SCK, "/dev/socket/udp", &fopSock);
  ASSERT(iRv == 0);

  /* Initialize the Socket repository */
  MOC_MEMSET((ubyte *)&(xSocketRep.apxSockets),
        0x00,sizeof(xSocketRep.apxSockets));
  xSocketRep.axProtocols[UDP_INDEX].pfnCreateConn = SocketUdpCreateConn;
  xSocketRep.axProtocols[UDP_INDEX].pfnConnectConn = SocketUdpConnectConn;
  xSocketRep.axProtocols[UDP_INDEX].pfnWrite = UdpInstanceWrite;
  xSocketRep.axProtocols[UDP_INDEX].pfnRxCbk = UdpInstanceRcv;
  xSocketRep.axProtocols[UDP_INDEX].pfnIoctl = UdpInstanceULInterfaceIoctl;

  xSocketRep.axProtocols[TCP_INDEX].pfnCreateConn = SocketTcpCreateConn;
  xSocketRep.axProtocols[TCP_INDEX].pfnConnectConn = SocketTcpConnectConn;
  xSocketRep.axProtocols[TCP_INDEX].pfnWrite = TcpInstanceWrite;
  xSocketRep.axProtocols[TCP_INDEX].pfnRxCbk = TcpInstanceRcv;
  xSocketRep.axProtocols[TCP_INDEX].pfnIoctl = TcpInstanceULInterfaceIoctl;

#ifndef __SELECT_OPT_ON__
  xSocketRep.pidTree = rbinit(_SockComparePID, NULL, 0);
  if (!xSocketRep.pidTree)
     iRv = -1;
#endif

#ifdef __SOCKET_USE_MEMPOOL__
  /* Creation of mempool for socket pool */
  pTempMemBuffer = MALLOC (sizeof(SOCKET) * SOCKET_CNTL_BLK_MAX);

  if (OK > (status = MEM_POOL_initPool(&xSocketRep.sockConnPool, pTempMemBuffer, sizeof(SOCKET) * SOCKET_CNTL_BLK_MAX, sizeof(SOCKET))))
  {
      DEBUG_ERROR(DEBUG_MOC_IPV4, "SocketLibraryInitialize: unable to create socket mempool : status = %d\n", status);
      return -1;
  }

  /* Creation of mempool for tcp socket pool */
  pTempMemBuffer = MALLOC (sizeof(TCPSOCKET) * TCPSOCKET_CNTL_BLK_MAX);

  if (OK > (status = MEM_POOL_initPool(&xSocketRep.tcpSockConnPool, pTempMemBuffer, sizeof(TCPSOCKET) * TCPSOCKET_CNTL_BLK_MAX, sizeof(TCPSOCKET))))
  {
      DEBUG_ERROR(DEBUG_MOC_IPV4, "SocketLibraryInitialize: unable to create tcp-socket mempool : status = %d\n", status);
      return -1;
  }

  /* Creation of mempool for tcpconnect socket pool */
  pTempMemBuffer = MALLOC (sizeof(TCPCONNECT) * TCPCONNECT_CNTL_BLK_MAX);

  if (OK > (status = MEM_POOL_initPool(&xSocketRep.tcpconnectConnPool, pTempMemBuffer, sizeof(TCPCONNECT) * TCPCONNECT_CNTL_BLK_MAX, sizeof(TCPCONNECT))))
  {
      DEBUG_ERROR(DEBUG_MOC_IPV4, "SocketLibraryInitialize: unable to create tcpconnect socket mempool : status = %d\n", status);
      return -1;
  }

  /* Creation of mempool for udp socket pool */
  pTempMemBuffer = MALLOC (sizeof(UDPSOCKET) * UDPSOCKET_CNTL_BLK_MAX);

  if (OK > (status = MEM_POOL_initPool(&xSocketRep.udpSockConnPool, pTempMemBuffer, sizeof(UDPSOCKET) * UDPSOCKET_CNTL_BLK_MAX, sizeof(UDPSOCKET))))
  {
      DEBUG_ERROR(DEBUG_MOC_IPV4, "SocketLibraryInitialize: unable to create udp-scoket mempool : status = %d\n", status);
      return -1;
  }
#endif

  return((LONG)iRv);
}

/*
 * SocketLibrarySet
 *  Set socket library wide options.
 *
 *  Args:
 *   oOption           Option code. Defined above as SOCKETLIBOPTION_XXX
 *   hData             Data handle. see option code definition for specifics
 *
 *  Return:
 *   >=0
 */
LONG SocketLibrarySet(OCTET oOption,H_NETDATA hData)
{

  switch(oOption) {
  case SOCKETLIBOPTION_HUDP:               /* UDP handle */
    xSocketRep.axProtocols[UDP_INDEX].hInst = (H_NETINSTANCE)hData;
    break;

  case SOCKETLIBOPTION_HTCP:               /* TCP handle */
    xSocketRep.axProtocols[TCP_INDEX].hInst = (H_NETINSTANCE)hData;
    break;

  case SOCKETLIBOPTION_HNETWORK:           /* Network layer entry point
                                              instance handle */
    xSocketRep.hNetwork = (H_NETINSTANCE)hData;
    break;

  case SOCKETLIBOPTION_HICMP:              /* Icmp handle */
    xSocketRep.hIcmp = (H_NETINSTANCE)hData;
    break;

  case SOCKETLIBOPTION_HIGMP:              /* Igmp handle */
    xSocketRep.hIgmp = (H_NETINSTANCE)hData;
    break;

#ifdef SOCK_RT
  case SOCKETLIBOPTION_HROUTER:            /* Router handle */
    xSocketRep.hRouter = (H_NETINSTANCE)hData;
    break;

  case SOCKETLIBOPTION_HNAT:               /* NAT handle */
    xSocketRep.hNat = (H_NETINSTANCE)hData;
    break;
#endif

  case SOCKETLIBOPTION_HETH:               /* Ethernet handle */
    xSocketRep.hEth = (H_NETINSTANCE)hData;
    break;

#ifdef IPSEC
  case SOCKETLIBOPTION_HIPSEC:             /* IPSec handle */
    xSocketRep.hIpsec = (H_NETINSTANCE)hData;
    break;
#endif /* IPSEC */

  default:
    SOCKET_ASSERT(0);

  }

  return 0;
}

/*
 * SocketLibraryMsg
 *  Send a Msg to the socket library
 *
 *  Args:
 *   oMsg               Msg code
 *   hData              Msg data handle
 *
 *  Return:
 *   >=0 for success
 */
LONG SocketLibraryMsg(OCTET oMsg,H_NETDATA hData)
{
  /* Only CLOSEIF is supported today */
  ASSERT(oMsg == SOCKETLIBMSG_CLOSEIF);
  {
    /* shuts all socket on an interface. The user
       will then have to close them */
    OCTET oIfIdx = (OCTET)hData;
    SOCKET *pxSock;
    int i;

    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
    for (i=0;i<MAX_FD;i++) {
      pxSock = RETRIEVE_SOCKET(i);
      if ((pxSock != NULL) &&
          (pxSock->oBoundFlag & SOCKETBOUNDFLAG_IF) &&
          (pxSock->xTransportId.xNetId.oIfIdx == oIfIdx)) {
        SocketShut(pxSock);
      }
    }
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
  }

  return NETERR_NOERR;
}

/*
 * SocketCreate
 *  Creates a Socket, and registers it.
 *  !!! Does not lock the Mutex : must be locked before !!!
 *
 *  Args:
 *   lFd                    socket File descriptor
 *   lFamily                socket family
 *   lType                  socket type
 *   lProtocol              socket protocol
 *   hConn                  TCP/UDP UL interface, if already created
 *                          (0 means not created)
 *
 *  Return:
 *   >=0 if successfull
 */
LONG SocketCreate(LONG lFd,LONG lFamily,LONG lType,LONG lProtocol,
                  H_NETINTERFACE hConn)
{
  SOCKET *pxSock;
#ifndef __SELECT_OPT_ON__
  PIDINFO *pxPid = NULL;
  PIDINFO *pxPidTmp = NULL;
  PIDINFO xPid;
  PIDFDINFO *pxPidFd = NULL;
  PIDFDINFO *pxPidFdTmp = NULL;
#endif
#ifdef __SOCKET_USE_MEMPOOL__
  MSTATUS status = OK;
#endif

#ifndef __SELECT_OPT_ON__
    xPid.lPid = RTOS_currentThreadId();
#if defined (__RECURSIVE_MUTEX__)
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
    pxPid = (PIDINFO *) rbfind(&xPid,xSocketRep.pidTree);
    if (!pxPid)
    {
        pxPid = MALLOC (sizeof(PIDINFO));
        MOC_MEMSET((ubyte *)pxPid, 0, sizeof(PIDINFO));
        if (!pxPid)
        {
#if defined (__RECURSIVE_MUTEX__)
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
          return -1;
        }

        pxPid->fdTree = rbinit (_SockComparePIDFD, NULL, 0);
        if (!pxPid->fdTree)
        {
          FREE(pxPid);
#if defined (__RECURSIVE_MUTEX__)
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
          return -1;
        }
        pxPid->lPid = xPid.lPid;
        pxPidTmp = (PIDINFO *)rbsearch (pxPid, xSocketRep.pidTree);
        if ((!pxPidTmp) || (pxPidTmp != pxPid))
        {
          rbdestroy(pxPid->fdTree);
          FREE (pxPid);
#if defined (__RECURSIVE_MUTEX__)
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
          return -1;
        }
    }

    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, NORMAL))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"SocketCreate TID [", xPid.lPid);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"] Fd[", lFd);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"] \n");
    }
    pxPidFd = MALLOC (sizeof(PIDFDINFO));
    if (!pxPidFd)
    {
#if defined (__RECURSIVE_MUTEX__)
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
      return -1;
    }

    pxPidFd->lFd = lFd;
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"Inserting pxPidFd ", (int)pxPidFd);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," Fd ", pxPidFd->lFd);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," into Pid ", pxPid->lPid);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "\n");
    }
    pxPidFdTmp = (PIDFDINFO *)rbsearch (pxPidFd, pxPid->fdTree);
    if ((!pxPidFdTmp) || (pxPidFdTmp != pxPidFd))
    {
        if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
        {
            DEBUG_PRINTSTR1HEXINT1 (DEBUG_MOC_IPV4, "Error Inserting pxPidFd ",
                (int)pxPidFd);
            DEBUG_PRINTSTR1INT1 (DEBUG_MOC_IPV4, "  Fd ", pxPidFd->lFd);
            DEBUG_PRINTSTR1INT1 (DEBUG_MOC_IPV4, " into Pid  ", pxPid->lPid);
            DEBUG_PRINTNL (DEBUG_MOC_IPV4,"\n");
        }
        FREE (pxPidFd);
#if defined (__RECURSIVE_MUTEX__)
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
      return -1;
    }

#if defined (__RECURSIVE_MUTEX__)
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
#endif

#ifdef __SOCKET_USE_MEMPOOL__
  if(OK > (status = MEM_POOL_getPoolObject(&xSocketRep.sockConnPool, (void **) &pxSock)))
  {
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: SocketCreate: unable to allocate socket");
    return -1;
  }
#else
  pxSock = (SOCKET *)MALLOC(sizeof(SOCKET));
#endif

  ASSERT(pxSock != NULL);
  MOC_MEMSET((ubyte *)pxSock, 0, sizeof(SOCKET));

  SOCKET_SET_COOKIE(pxSock);

#ifndef __SELECT_OPT_ON__
  pxSock->lPid =  xPid.lPid;
#endif

  pxSock->lFd = lFd;
  pxSock->lFamily = lFamily;
  pxSock->lType = lType;
  pxSock->pfRecvCb = NULL;
  pxSock->pfEventCb = NULL;

  ((NETWORKID *) &(pxSock->xTransportId.xNetId))->oTtL = 64;
  /* Set the default VLAN */
  pxSock->xTransportId.xNetId.wVlan = NETVLAN_ANY;
  /* Set the default Interface index */

  /* Initialize the condition variable */
  pthread_cond_init(&(pxSock->xCond), NULL);

  /* Create & Configure the connection */
  pxSock->hLL = hConn; /* Set the hLL */
  {
    H_NETINSTANCE hInst;
    PFN_NETIOCTL pfnIoctl;

    {
      OCTET oProtIdx;
#ifdef __SOCKET_USE_MEMPOOL__
#define MAX_BUF_SIZE 20
      void* buffer[MAX_BUF_SIZE];
      sbyte4 dwPtrs = 0, j = 0;
      sbyte **strings;
      sbyte4 exit_status = -1;
#endif

      oProtIdx = SOCKTYPE2PROTINDEX(lType);
      hInst = xSocketRep.axProtocols[oProtIdx].hInst;
      pfnIoctl = xSocketRep.axProtocols[oProtIdx].pfnIoctl;

      /* Create the connection */
#ifdef __SOCKET_USE_MEMPOOL__
      if(0 > (xSocketRep.axProtocols[oProtIdx].pfnCreateConn(pxSock)))
      {
        if (OK > (status = MEM_POOL_putPoolObject(&xSocketRep.sockConnPool, (void **)(&pxSock))))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "SocketTcpDestroy: unable to release socket  within sockConnPool Status = %d\n", status);
        pxSock = NULL;
#ifdef __BACKTRACE_SUPPORTED__
        dwPtrs = backtrace(buffer, MAX_BUF_SIZE);
        strings = backtrace_symbols(buffer, dwPtrs);
        if(NULL == strings)
        {
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "unable to get stacktrace");
          exit(exit_status);
        }
        for(j = 0; j < dwPtrs; j++) DEBUG_PRINTNL(DEBUG_MOC_IPV4, strings[j]);
        free(strings);
        exit(exit_status);
#else
       return -1;
#endif
      }
#else
      xSocketRep.axProtocols[oProtIdx].pfnCreateConn(pxSock);
#endif
    }

    /* Configure the connection */

    /*
     * Register the socket in the File descriptor array.
     * This also sets the socket id
     */
#ifndef __SELECT_OPT_ON__
#if defined (__RECURSIVE_MUTEX__)
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
#endif
    REGISTER_SOCKET(lFd,pxSock);
#ifndef __SELECT_OPT_ON__
#if defined (__RECURSIVE_MUTEX__)
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
#endif


    pfnIoctl(hInst,pxSock->hLL,NETINTERFACEIOCTL_SETIF,
             (H_NETDATA)pxSock->dwSocketId);

    pfnIoctl(hInst,pxSock->hLL,NETINTERFACEIOCTL_SETHINST,(H_NETDATA)pxSock);

#ifndef __TCP_OPT_ON__
    pfnIoctl(hInst,pxSock->hLL, TCPULINTERFACEIOCTL_SETFD,
             (H_NETDATA)pxSock->lFd);
#endif
  }

  return 0;
}

/*
 * SocketDestroy
 *  Destroy and free a socket. Locks the mutex.
 *
 *  Args:
 *   lFd                       socket file descriptor
 *
 *  Return 0;
 */
LONG SocketDestroy(LONG lFd)
{
  SOCKET *pxSock;
  LONG iReturn = -1;
#ifndef __SELECT_OPT_ON__
  PIDINFO *pxPid;
  PIDINFO xPid;
  PIDFDINFO *pxPidFd;
  PIDFDINFO xPidFd;
  RBLIST *rbList;
#endif
#ifdef __SOCKET_USE_MEMPOOL__
  MSTATUS status = OK;
#endif

#ifndef __SELECT_OPT_ON__
    xPid.lPid = RTOS_currentThreadId();
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, NORMAL))
    {
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "SocketDestroy TID [",xPid.lPid,
        "]  ",lFd);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
    }
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
    pxPid = (PIDINFO *) rbfind(&xPid,xSocketRep.pidTree);
    if (pxPid)
    {
      xPidFd.lFd = lFd;
      pxPidFd = (PIDFDINFO *)rbdelete (&xPidFd, pxPid->fdTree);
      if (pxPidFd)
      {
        FREE (pxPidFd);
      }
    }
    else
    {
        /* SOme other Thread is trying to Delete this Socket  Fine with us */
        if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, NORMAL))
        {
            DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "Foreign Thread  Deleting Fd ",
            lFd, " Pid ", xPid.lPid);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
        }
        rbList = rbopenlist(xSocketRep.pidTree);

        while ((pxPid = (PIDINFO *)rbreadlist(rbList)))
        {
          xPidFd.lFd = lFd;
          pxPidFd = (PIDFDINFO *)rbdelete (&xPidFd, pxPid->fdTree);
          if (pxPidFd)
          {
            FREE (pxPidFd);
            break;
          }

        }
        rbcloselist(rbList);
    }

    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(lFd);

  if (pxSock != NULL) {
    iReturn = 0;

    pxSock->dwSockState |= SS_CANTSENDMORE | SS_CANTRCVMORE;

    /* In case there is a select waiting, signal it */
    SocketWakeSelect(pxSock,SELECT_WR | SELECT_RD);

    if (pxSock->lType == SOCK_DGRAM) {
      mn_errno = SocketUdpDestroy(pxSock);
    }
    else {
      SOCKET_ASSERT(pxSock->lType == SOCK_STREAM);
      mn_errno = SocketTcpDestroy(pxSock);
    }

    SOCKET_UNSET_COOKIE(pxSock);

    UNREGISTER_SOCKET(lFd);

    /* !!! SB must check if this
       send the broadcast before */
    pthread_cond_destroy(&(pxSock->xCond));

#ifdef __SOCKET_USE_MEMPOOL__
  if (OK > (status = MEM_POOL_putPoolObject(&xSocketRep.sockConnPool, (void **)(&pxSock))))
    DEBUG_ERROR(DEBUG_MOC_IPV4, "SocketTcpDestroy: unable to release socket  within sockConnPool Status = %d\n", status);
#else
    FREE(pxSock);
#endif
  }

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return iReturn;
}


/*
 * SocketOpen
 *  Supports open() on fd returned from socket operation (a nop)
 *
 * Arg:
 *  pxInode                       the inode opened
 *  pxFile                        file structure for inode
 *
 * Return:
 *  0 for success
 */
LONG
SocketOpen(INODE *pxInode, struct file *pxFile)
{
    DWORD sockFd;
    LONG iReturn = -1;
    /* allocate an fd from ID map */
    if (OK == MBITMAP_findVacantIndex(xNetWrapper.pFdMap, &sockFd)) {
        iReturn = (LONG)(SCK_DEV_FD_BIT | sockFd);
    }

    return iReturn;
}

/*
 * SocketClose
 *  Supports close() on fd returned from socket operation
 *
 *  Args:
 *   pxInode                           the inode closed
 *   pxFile                            file structure for inode
 *
 *  Return:
 *   result of closesocket
 */
LONG SocketClose(INODE *pxInode, struct file *pxFile)
{
  int iFd = (int)(pxFile->private_data);
  SOCKET* pxSock = RETRIEVE_SOCKET(iFd);

  if (pxSock == NULL) {
      return -1;
  }

  /* SocketDestroy locks up the mutex */
  SocketDestroy(iFd);

  /* release the socket fd to the FD map */
  return(MBITMAP_clearIndex(xNetWrapper.pFdMap, (iFd & ~(DEV_FD_MASK))));
}


/*
 * SocketShut
 *  shuts down a socket to the user.
 *  It is then up to the user to close it
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxSock         socket pointer
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG SocketShut(SOCKET *pxSock)
{

  SOCKET_CHECK_STATE(pxSock);

  if (pxSock->lType == SOCK_STREAM) {
    SocketTcpForceTypeToAbortNBIO(pxSock);
  }

  pxSock->dwSockState |= (SS_CANTRCVMORE | SS_CANTSENDMORE);

  SocketWakeSelect(pxSock,SELECT_WR | SELECT_RD);

  pthread_cond_broadcast(&(pxSock->xCond));

  return 0;
}

/* Move the Socket PID Info from One thread to the other */
LONG SocketRegisterInterest(LONG lFd)
{
    SOCKET *pxSock;
#ifndef __SELECT_OPT_ON__
    PIDINFO *pxPid = NULL;
    PIDINFO *pxPidL = NULL;
    PIDINFO *pxPidTmp = NULL;
    PIDINFO xPid;
    PIDFDINFO *pxPidFd = NULL;
    PIDFDINFO xPidFd ;
    PIDFDINFO *pxPidFdTmp = NULL;

    xPid.lPid = RTOS_currentThreadId();
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
    pxPid = (PIDINFO *) rbfind(&xPid,xSocketRep.pidTree);
    if (!pxPid)
    {
        pxPid = MALLOC (sizeof(PIDINFO));
        MOC_MEMSET((ubyte *)pxPid, 0, sizeof(PIDINFO));
        if (!pxPid)
        {
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
          return -1;
        }

        pxPid->fdTree = rbinit (_SockComparePIDFD, NULL, 0);
        if (!pxPid->fdTree)
        {
          FREE(pxPid);
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
          return -1;
        }
        pxPid->lPid = xPid.lPid;
        pxPidTmp = (PIDINFO *)rbsearch (pxPid, xSocketRep.pidTree);
        if ((!pxPidTmp) || (pxPidTmp != pxPid))
        {
          rbdestroy(pxPid->fdTree);
          FREE (pxPid);
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
          return -1;
        }
    }

    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, NORMAL))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"SocketRegisterInterest TID [",
            xPid.lPid);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"] Fd[", lFd);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"] \n");
    }

    pxSock = RETRIEVE_SOCKET(lFd);
    ASSERT(pxSock != NULL);
    if ( NULL == pxSock)
    {
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return -1;
    }
    /* For the socket We need to move the PIDFDINFO Struct to the
             This threads  PIDINFO */
    xPid.lPid = pxSock->lPid;
    pxPidL = (PIDINFO *)rbfind(&xPid, xSocketRep.pidTree);
    if (!pxPidL)
    {
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return -1;
    }

    xPidFd.lFd = lFd;
    /* Remove  it from the Original PID Tree */
    pxPidFd = (PIDFDINFO *)rbdelete(&xPidFd,pxPidL->fdTree);
    if (!pxPidFd)
    {
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return -1;
    }

    pxPidFdTmp = (PIDFDINFO *)rbsearch (pxPidFd, pxPid->fdTree);
    if ((!pxPidFdTmp) || (pxPidFdTmp != pxPidFd))
    {
      FREE (pxPidFd);
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return -1;
    }

    pxSock->lPid = pxPid->lPid;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
    return 0;
}


LONG TcpShowAllInfo()
{
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
    TcpInstanceInterfaceShow(xSocketRep.axProtocols[TCP_INDEX].hInst);
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
}
