#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

DLLIST_ITEM *DLLIST_insert_after_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem)
{
  DLLIST_ITEM *tmp2;

  if (dllist->cur == NULL) {
    return DLLIST_append_ITEM(dllist, dllitem);
  }

  tmp2 = dllist->cur;
  dllist->cur = dllitem;
  
  dllitem->next = tmp2->next;
  tmp2->next = dllitem;
  dllitem->prev = tmp2;
  if (dllitem->next == NULL) {
    dllist->tail = dllitem;
  } else {
    dllitem->next->prev = dllitem;
  }
  dllist->count++;
  return(dllitem);
}

