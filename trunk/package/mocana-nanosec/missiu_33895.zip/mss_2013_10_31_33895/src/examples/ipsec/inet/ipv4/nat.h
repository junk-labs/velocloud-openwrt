/*
 * nat.h
 *
 * NAT module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NAT_H_
#define _NAT_H_

/*****************************************
 *
 * Includes
 *
 ****************************************/
#include "NNstyle.h"
#include "netcommon.h"
#include "netnetwork.h"
#include "natcfgapi.h"

/*****************************************
 *
 * Defines
 *
 ****************************************/
/* NAT option */


/* NAT specific Msg */
#define NATMSG_SETIFIDXLAN              \
  (NETNETWORKMSG_MODULESPECIFICBEGIN)           /* Sets the interface index
                                                   corresponding to the
                                                   LAN */

#define NATMSG_DOWNIFIDX                \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 1)       /* Indicates that the given
                                                   interface index is being
                                                   down. */

#define NATMSG_REGPORTFWDWANTOCPE       \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 2)      /* Registers a range of ports and
                                                  protocols to be forwarded from WAN
                                                  to the CPE stack.
                                                  data is NATCFG_PORTS2CPE* */
#define NATMSG_UNREGPORTFWDWANTOCPE     \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 3)      /* Unregisters a range of ports which
                                                  were previously registered with
                                                  NATMSG_REGPORTFWDWANTOCPE message.
                                                  data is NATCFG_PORTS2CPE* */
#define NATMSG_CFGPORTFWDLAN            \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 4)      /* Configures a range of ports and
                                                  protocols to be forwarded to a host
                                                  on the LAN. data is NATCFG_PORTFWDLAN* */
#define NATMSG_GETPORTFWDWANTOCPELIST   \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 5)      /* Retrieves the list of ports
                                                  being forwarded to the CPE
                                                  NATCFG_PORTS2CPE* */
#define NATMSG_REGPORTBLKLANTOCPE       \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 6)      /* Registers a range of ports and
                                                  protocols to be blocked from LAN
                                                  to the CPE stack.
                                                  data is NATCFG_PORTFWDCPE* */
#define NATMSG_UNREGPORTBLKLANTOCPE     \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 7)      /* Unregisters a range of ports which
                                                  were previously registered with
                                                  NATMSG_REGPORTBLKLANTOCPE message.
                                                  data is NATCFG_PORTS2CPE* */

#define NATMSG_SETBINDINGSLIMIT     \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 8)      /* Sets the upper bound on number of
                                                  bindings. */

#define NATMSG_SETIFMTU             \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 9)      /* Sets the MTU of an interface */


/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/
typedef struct {
  OCTET oIfIdx;
  WORD wMtu;
} NATSETIFMTU;


/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * NatInitialize
 *  Initialize the NAT library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG NatInitialize(void);

/*
 * NatTerminate
 *  Terminate the NAT library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG NatTerminate(void);


/*
 * NatMsg
 *   Library wide messaging for NAT.
 *
 * Args:
 *  oMsg                    Message type
 *  hData                   message dependent data handle
 *
 * Return:
 *  >= 0                    success
 *  < 0                     error
 */
LONG NatMsg(OCTET oMsg, H_NETDATA hData);

/*
 * NatInstanceCreate
 *  Creates a Nat Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE NatInstanceCreate(void);

/*
 * NatInstanceDestroy
 *  Destroy a NAT Instance
 *
 *  Args:
 *   hNat                   NAT instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG NatInstanceDestroy(H_NETINSTANCE hNat);

/*
 * NatInstanceSet
 *  Set a NAT Instance Option
 *
 *  Args:
 *   hNat                    NAT instance
 *   oOption                 Option
 *   hData                   Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG NatInstanceSet(H_NETINSTANCE hNat,
                    OCTET oOption,
                    H_NETDATA hData);

/*
 * NatInstanceQuery
 *  Query a NAT Instance Option
 *
 *  Args:
 *   hNat                    NAT instance
 *   oOption                 Option
 *   phData                  Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG NatInstanceQuery(H_NETINSTANCE hNat,
                      OCTET oOption,
                      H_NETDATA *phData);

/*
 * NatInstanceMsg
 *  Send a msg to a NAT instance
 *
 *  Args:
 *   hNat                    NAT instance
 *   oMsg                    Msg. See netcommon.h and ip.hfor definition
 *   hData                   Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG NatInstanceMsg(H_NETINSTANCE hNat,
                    OCTET oMsg,
                    H_NETDATA hData);


/*
 * NatInstanceULInterfaceCreate
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hNat                NAT instance
 *
 *  Return:
 *   H_NETINTERFACE      Interface handle
 */
H_NETINTERFACE NatInstanceULInterfaceCreate(H_NETINSTANCE hNat);

/*
 * NatInstanceULInterfaceDestroy
 *  Destroy a NAT UL interface
 *
 *  Args:
 *   hNat                    NAT instance
 *   hInterface              Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG NatInstanceULInterfaceDestroy(H_NETINSTANCE hNat,
                                   H_NETINTERFACE hInterface);

/*
 * NatInstanceULInterfaceIoctl
 *
 *  Args:
 *   hNat                      NAT instance handle
 *   hULInterface              Interface handle
 *   oIoctl                    Ioctl msg
 *   hData                     data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG NatInstanceULInterfaceIoctl(H_NETINSTANCE hNat,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData);

/*
 * NatInstanceWrite
 *  NAT Instance Write function. Follows PFN_NETWORKWRITE
 *  typedef.
 *
 *  Args:
 *   hNat                    NAT Instance handle
 *   hIf                     Interface handle
 *   pxPacket                Packet pointer
 *   wOffset                 Ip PDU offset
 *   hData                   pointer to a net_dst structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG NatInstanceWrite(H_NETINSTANCE hNat,
                      H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,
                      NETPACKETACCESS *pxPktAccess,
                      H_NETDATA hData);

/*
 * NatInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hNat                NAT instance
 *
 *  Return:
 *   H_NETINTERFACE      Interface handle
 */
H_NETINTERFACE NatInstanceLLInterfaceCreate(H_NETINSTANCE hNat);

/*
 * NatInstanceLLInterfaceDestroy
 *  Destroy a NAT LL interface
 *
 *  Args:
 *   hNat                    NAT instance
 *   hInterface              Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG NatInstanceLLInterfaceDestroy(H_NETINSTANCE hNat,
                                   H_NETINTERFACE hInterface);

/*
 * NatInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hNat                         NAT instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG NatInstanceLLInterfaceIoctl(H_NETINSTANCE hNat,
                                 H_NETINTERFACE hLLInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData);


/*
 * NatInstanceRcv
 *   NAT Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hNat                    NAT Instance Handle
 *    hIf                     Interface handle
 *    pxPacket                packet
 *    wOffset                 Ip PDU offset.
 *    hData                   unused
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG NatInstanceRcv(H_NETINSTANCE hNat,
                    H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,
                    NETPACKETACCESS *pxPktAccess,
                    H_NETDATA hData);

/*
 * NatInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hNat                  NAT Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG NatInstanceProcess(H_NETINSTANCE hNat);

#endif /* #ifndef _NAT_H_ */
