/*
 * netdbg.c
 *
 * network debug routines
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * NetPrintPayload
 *  Print a payload to stdout
 *
 *  Args:
 *   poPayload              pointer to the payload. Must be != NULL
 *   wLength                payload length
 *
 *  Return:
 *   0
 */
LONG NetPrintPayload(OCTET *poPayload, WORD wLength)
{
  int i,j;

  ASSERT(poPayload != NULL);

#define ISPRINT(x) ((x>=48) && (x<='z'))

  DEBUG_PRINT(DEBUG_MOC_IPV4,
        "===========network payload begin===============\n");
  for (i=0;i<wLength;i++) {
    if ((i%16) == 0) {
      DEBUG_INT(DEBUG_MOC_IPV4, (sbyte4)(poPayload+i));
    }
    printf("%02x:",*(poPayload + i));
    if (((i + 1)%16) == 0) {
      DEBUG_PRINT(DEBUG_MOC_IPV4,"   ");
      for (j=(i-15);j<=i;j++) {
        if (ISPRINT(*(poPayload+j))) {
            DEBUG_PRINTBYTE(DEBUG_MOC_IPV4, (sbyte )*(poPayload+j));
        } else {
            DEBUG_PRINTBYTE(DEBUG_MOC_IPV4,(sbyte )'.');
        }
      }
      DEBUG_PRINT(DEBUG_MOC_IPV4, "\n");
    }
  }
  DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
  DEBUG_PRINT(DEBUG_MOC_IPV4,
        "===========network payload end=================");
  DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");

#if 0
  fflush(stdout);
#endif /* TBD */

  return 0;
}

