#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

extern poolHeaderDescr gDLLIST_pool;
extern unsigned long gDLLIST_poolCount;
extern poolHeaderDescr gDLLIST_ITEM_pool;
extern unsigned long gDLLIST_ITEM_poolCount;

void del_DLLIST_fl(DLLIST *dllist, void (*free_item)(void *), 
		   char *pFile, int nLine)
{
  clear_DLLIST_fl(dllist, free_item, pFile, nLine);

  //free_fl(dllist, pFile, nLine);
  MEM_POOL_putPoolObject(&gDLLIST_pool,&dllist); 
  gDLLIST_poolCount--;
}

void clear_DLLIST_fl(DLLIST *pDLList, void (*free_item)(void *), 
                     char *pFile, int nLine)
{
  DLLIST_ITEM *tmp1,*tmp2;

  tmp1 = pDLList->head;
  while(tmp1 != NULL) {
    tmp2 = tmp1->next;
    if (free_item) {
      free_item(tmp1->item);
      tmp1->item = NULL;
    }
    //free_fl(tmp1, pFile, nLine);
    MEM_POOL_putPoolObject(&gDLLIST_ITEM_pool,&tmp1); 
    gDLLIST_ITEM_poolCount--;
    tmp1 = tmp2;
  }
  tmp1 = pDLList->free;
  while(tmp1 != NULL) {
    tmp2 = tmp1->next;
    //free_fl(tmp1, pFile, nLine);
    MEM_POOL_putPoolObject(&gDLLIST_ITEM_pool,&tmp1); 
    gDLLIST_ITEM_poolCount--;
    tmp1 = tmp2;
  }
}


