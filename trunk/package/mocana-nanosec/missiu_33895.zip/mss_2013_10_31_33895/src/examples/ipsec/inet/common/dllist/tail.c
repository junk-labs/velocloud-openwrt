#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void DLLIST_tail(DLLIST *dllist)
{
  dllist->cur = dllist->tail;
}

