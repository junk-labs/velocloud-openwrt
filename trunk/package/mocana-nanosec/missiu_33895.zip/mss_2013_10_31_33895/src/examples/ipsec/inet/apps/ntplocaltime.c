/*
 * ntplocaltime.c
 *
 * NTP to Localtime
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include <NNstyle.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <syslog.h>

#include "ntpapi.h"

#define SECSPERMINUTE    (60L)
#define SECSPERHOUR    (3600L)

#define JAN_1970    0x83aa7e80  /* The most signficant 32b word of NTP
                       time on Jan. 1, 1970 */

/* Local function prototypes */
static struct tm *_NtpToLocaltime(LONG *plNtpTime,
                  struct tm *pTmTime,
                  LONG lTimeZone,
                  BOOL bDSTObserved);

/*////////////////////////////////////////////////////////////////////////////
/*  */
/* NtpGetLocaltime. */
/*  */
/* Returns the local (timezone/dst corrected) time. */
/* Return value is TRUE id time is valid (NTP time valid, and conversion */
/* succesfull), FALSE otherwise. lTimeZone is minutes difference from GMT. */
/*  */
/////////////////////////////////////////////////////////////////////////////*/
int NtpGetLocaltime(struct tm *pTmTime, LONG lTimeZone, BOOL bDSTObserved)
{
  int iReturn=FALSE;
  DWORD adwNtpTime[2];

  /* Get NTPTime */
  if (NtpGet(&adwNtpTime[0],&adwNtpTime[1])==TRUE) {
    if (adwNtpTime[0]>JAN_1970) {
      _NtpToLocaltime(adwNtpTime,pTmTime,lTimeZone,bDSTObserved);
      iReturn=TRUE;
    } else {
      DEBUG(SYSLOG(LOG_ERR,"NtpGetLocaltime - time is before Jan 1970\n"));
    }
  } else {
    DEBUG(SYSLOG(LOG_ERR,"NtpGetLocaltime - time is not valid\n"));
  }

  return iReturn;
}


/*/////////////////////////////////////////////////////////////////////////////
/*  _NtpToLocaltime(plNtpTime, pTmTime, lTimeZone, bDSTObserved) */
/*  */
/*  This function populates a tm structure based on the time returned */
/*  by the network time protocol (NTP).  plTime is a pointer to an array */
/*  of 2 32b numbers giving the NTP time.  The first word is the most */
/*  significant.  pTmTime is a pointer to a tm structure where the converted */
/*  time will be stored.  lTimeZone is the local region's standard time offset */
/*  (in minutes) from GMT.  lTimeZone should not take into account daylight */
/*  savings time.  The bDST argument should be nonzero to indicate the local */
/*  region follows daylight savings time.  The rules for when to apply daylight */
/*  savings are complicated and they also vary due to local events.   The */
/*  following rules apply to most of the world, but there are exceptions. */
/*  */
/*  It's left as an exercise for C. Foster to completely internationalize */
/*  this algorithm. */
/*  */
/*  When lTimeZone is in the range -240 to -600 (-4:00 to -10:00 from GMT) */
/*  we use the US daylight savings time schedule: */
/*  */
/*    begins at 2AM local time on the first Sunday of April */
/*    ends at 2AM local time on the last Sunday of October */
/*  */
/*  When lTimeZone is in the range -60 to +120 (-1:00 to +2:00 from GMT) */
/*  we use the common EEC schedule: */
/*  */
/*    begins at 1AM local time on the last Sunday of March */
/*    ends at 1AM local time on the last Sunday of October */
/*  */
/*  If lTimeZone is not in the above ranges, we use the following schedule */
/*  */
/*    begins on March 30 */
/*    ends on October 26 */
/*  */
/*  The structure tm is defined in time.h and is part of ANSI C. */
/*  */
/////////////////////////////////////////////////////////////////////////////*/
static struct tm *_NtpToLocaltime(LONG *plNtpTime,
                  struct tm *pTmTime,
                  LONG lTimeZone,
                  BOOL bDSTObserved)
{
  time_t xTime;

  /* Check the range of lTimeZone.  We must be within 12 hours of GMT */

  ASSERT(lTimeZone <= 12 * 60);
  ASSERT(lTimeZone >= -12 * 60);

  /* The most significant 32b of NTP time give time in seconds which
     is accurate enough for our purposes.  Ignore the 2nd word.

     Add any time zone offset to NTP time and then subtract the
     NTP constant JAN_1970.  This is needed because the ANSI C localtime()
     function expects seconds since Jan. 1, 1970 as it's argument.
  */

  xTime = plNtpTime[0] + lTimeZone * SECSPERMINUTE - JAN_1970;

  /* Determine the local standard time. */

  localtime_r(&xTime, pTmTime);

  /* Adjust the local time if DST is observed and in effect */

  if (bDSTObserved) {
    DWORD bAdjustForDST = FALSE;

    if (lTimeZone <= -240 && lTimeZone >= -600) {      /* US Time Zone */
      if (pTmTime->tm_mon >= 4 && pTmTime->tm_mon <= 8) /* May ... Sept. */
    bAdjustForDST = TRUE;

      else if (pTmTime->tm_mon == 3) {    /* It's April */
    if (pTmTime->tm_wday == 0) {    /* Today's Sunday */
      if (pTmTime->tm_mday > 7 ||    /* There's already been another Sunday
                       this month */
          pTmTime->tm_hour >= 2)      /* This is the first Sunday,
                         and it's after 2AM */
        bAdjustForDST = TRUE;

    } else if (pTmTime->tm_wday < pTmTime->tm_mday) /* There's been a Sunday
                               this month */
      bAdjustForDST = TRUE;

      } else if (pTmTime->tm_mon == 9) { /* It's October */
    if (pTmTime->tm_wday == 0) {    /* Today's Sunday */
      if (pTmTime->tm_mday > 24 &&    /* This must be the last Sunday. */
          pTmTime->tm_hour < 2)
        bAdjustForDST = TRUE;

    } else if (pTmTime->tm_mday + (7 - pTmTime->tm_wday) <= 31) /* Last Sunday
                                       has not
                                       happened yet */
      bAdjustForDST = TRUE;
      }

    } else if (lTimeZone >= -60 && lTimeZone <= 120) { /* European Time Zone */
      if (pTmTime->tm_mon >= 3 && pTmTime->tm_mon <= 8) /* April ... Sept. */
    bAdjustForDST = TRUE;

      else if (pTmTime->tm_mon == 2) {    /* It's March */
    if (pTmTime->tm_wday == 0) {    /* Today's Sunday */
      if (pTmTime->tm_mday > 24 &&    /* This must be the last Sunday. */
          pTmTime->tm_hour >= 1)      /* It's after 1AM */

        bAdjustForDST = TRUE;

    } else if (pTmTime->tm_mday + (7 - pTmTime->tm_wday) > 31) /* No more Sundays
                                      this month */
      bAdjustForDST = TRUE;

      } else if (pTmTime->tm_mon == 9) { /* It's October */
    if (pTmTime->tm_wday == 0) {    /* Today's Sunday */
      if (pTmTime->tm_mday > 24 &&    /* This must be the last Sunday. */
          pTmTime->tm_hour < 1)
        bAdjustForDST = TRUE;

    } else if (pTmTime->tm_mday + (7 - pTmTime->tm_wday) <= 31) /* Last Sunday
                                       has not
                                       happened yet */
      bAdjustForDST = TRUE;
      }

    } else {
      if (pTmTime->tm_mon >= 3 && pTmTime->tm_mon <= 8)  /* April ... Sept. */
    bAdjustForDST = TRUE;

      else if (pTmTime->tm_mon == 2 &&  /* It's on or after March 30 */
           pTmTime->tm_mday >= 30)
    bAdjustForDST = TRUE;

      else if (pTmTime->tm_mon == 9 &&  /* It's before Oct. 26 */
           pTmTime->tm_mday < 26)
    bAdjustForDST = TRUE;
    }

    /* Add the effect of DST, recompute the time. */

    if (bAdjustForDST) {
      xTime += SECSPERHOUR;
      localtime_r(&xTime, pTmTime);

      pTmTime->tm_isdst = 1;

    } else
      pTmTime->tm_isdst = 0;

  } else {
    pTmTime->tm_isdst = 0;

  }

  return (pTmTime);
}
