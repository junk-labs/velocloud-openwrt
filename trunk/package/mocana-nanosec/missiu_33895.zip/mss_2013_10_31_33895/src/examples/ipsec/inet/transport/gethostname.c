/*
 * gethostname.c
 *
 * Function of Domain Name Server client
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "NNstyle.h"
#include "sys/socket_inet.h"
#include "dns_flavor.h"

#include <stdlib.h>
#include <strings.h>

#include <stdio.h>
#include <ctype.h>

#include <errno.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/socket.h> /* sockaddr */
#include "netinet/in.h" /* sockaddr_in */
#include <sys/time.h>
#include <time.h>
#include <sys/select.h> /* FD_xxx */

#include <sys/sockio.h>
#include <net/if.h>

#include <arpa/inet.h>

#include <pthread.h>
#include <semaphore.h>

#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdb.h"

#include "sockapi.h"

#include "dnsdbg.h"
#include "dnsapi.h"
#include "dns.h"

/*
 * gethostname
 *  Get the name of the current host which MUST have
 *  been previously set in NetConf with NetSetParms().
 *
 *  Args:
 *   name                      pointer,where to copy result
 *   namelen                   max size of hostname to be copied
 *
 *  Return:
 *   0 if OK
 *   -1 on error
 */
int gethostname(char *name, size_t namelen)
{
  OCTET szHostname[DNS_MAX_NAME_LEN];
  int hSock;
  struct ifconf       xIfConf;
  mnIoctlArgList_t mnIoctlArgList;

  if ((hSock=socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_DNS, ERROR))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"Can't open socket, mn_errno=",
           mn_errno);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
    }
    ASSERT(0);
    return NETERR_UNKNOWN;
  }

  /* Get hostname for interface 0!!! - any other way we can identify it ??? */
  /* ???? ioctl(hSock, MO_SIOCGIFIHN, szHostname); */
  MOC_MEMSET((ubyte *)&szHostname[0] ,0, DNS_MAX_NAME_LEN);
  xIfConf.ifc_buf = &szHostname[0];
  xIfConf.ifc_len = DNS_MAX_NAME_LEN - 1;
  mnIoctlArgList.oIfIdx = 0;
  mnIoctlArgList.ifconf = (void *)&xIfConf;
  ioctl(hSock, MO_SIOCGIFIHN, &mnIoctlArgList);

  strncpy(name, szHostname, namelen);

  close(hSock);
  return NETERR_NOERR;
}
