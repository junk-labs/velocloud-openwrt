/*
 * nat_icmp.c
 *
 * Does the necessary address translation on ICMP packets,
 * in both Tx and Rx directions.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "nat.h"
#include "nat_defs.h"


/*************************************************
 * NOTE: This file needs some rewrite.
 *       Should be able to share a lot of code
 *       with TCP/UDP handling routines.
 ************************************************/

/*****************************************************************************
Function:
        NatHandleIcmpRx()
Description:
        Handles ICMP packets from WAN to LAN.
Arguments:
        NATSTATE*               pxNat                   NAT instance handle.
        NETPACKET*              pxNetPacket             Packet pointer
        NETPACKETACCESS*        pxNetPacketAccess       Packet info
        H_NETDATA               hData                   NETWORKID*
        void*                   pvProtocolHdr           Pointer to the
                                                        protocol header
                                                        (UDP/TCP)
Outputs:
        None.
Returns:
        LONG                    NAT_TO_CPE              WAN to CPE traffic.
                                NAT_PACKET_UNKNOWN      Unrecognized packet.
                                NAT_OK                  means address
                                                        translation is
                                                        successful.
Revisions:
        15-Oct-2001                                     Initial
        25-Mar-2002                                     API change
*****************************************************************************/
LONG NatHandleIcmpRx(NATSTATE* pxNat,
                     NETPACKET *pxNetPacket,
                     NETPACKETACCESS *pxNetPacketAccess,
                     H_NETDATA hData,
                     void* pvProtocolHdr)
{
  NETWORKID *pxNetworkId = (NETWORKID*) hData;
  OCTET oProtocolId = pxNetworkId->oProtocol;
  DWORD dwSrcIp, dwDstIp;
  WORD wSrcPort, wDstPort;
  void *pvPayloadIpHdr = NULL;
  IPHDR xPayloadIpHdr;
  void* pvPayloadProtocolHdr = NULL;
  ICMP_HDR *pxIcmpHdr = (ICMP_HDR*) pvProtocolHdr;
  ICMP_HDR *pxPayloadIcmpHdr = NULL;
  NAT_ENTRY *pxNatEntry;


  /*
   * Perform some size checks.
   */
  if (pxNetPacket->pxPayload->wSize < (pxNetPacketAccess->wOffset +
                                       pxNetworkId->oIpHdrLen +
                                       sizeof(ICMP_HDR))) {
    return (NAT_PACKET_UNKNOWN);
  }



  switch (pxIcmpHdr->oType) {

    case ICMPTYP_DEST_UNREACH:
    case ICMPTYP_SOURCE_QUENCH:
    case ICMPTYP_TIME_EXCEEDED:
    case ICMPTYP_PARAMETERPROB:
      pvPayloadIpHdr = (void*) (pxNetPacket->pxPayload->poPayload +
                                pxNetPacketAccess->wOffset +
                                pxNetworkId->oIpHdrLen +
                                sizeof(ICMP_HDR));
      MOC_MEMCPY((ubyte *)&xPayloadIpHdr,(ubyte *) pvPayloadIpHdr, sizeof(IPHDR));

      dwSrcIp = xPayloadIpHdr.dwSrcAddr;
      dwDstIp = xPayloadIpHdr.dwDstAddr;

      switch (xPayloadIpHdr.oProtocol) {

        /***************************
         * UDP and TCP
         **************************/
        case IPPROTO_UDP:
        case IPPROTO_TCP:
          /*************************************************************
           * Translation checks on the actual payload
           ************************************************************/
          pvPayloadProtocolHdr = (void*) ((OCTET*) pvPayloadIpHdr + (xPayloadIpHdr.oIpHdrLen << 2));
          ASSERT(((DWORD)pvPayloadProtocolHdr & 0x1) == 0);
          wSrcPort = TRANSPORT_GET_SRC_PORT(pvPayloadProtocolHdr);
          wDstPort = TRANSPORT_GET_DST_PORT(pvPayloadProtocolHdr);


          /*
           * Search for a binding.
           */
          pxNatEntry = NatFindTUBindingRx(pxNat,
                                          dwDstIp, wDstPort,
                                          dwSrcIp, wSrcPort,
                                          xPayloadIpHdr.oProtocol);
          break;


        /***************************
         * ICMP
         **************************/
        case IPPROTO_ICMP:
          pxPayloadIcmpHdr = (ICMP_HDR*) ((OCTET*) pvPayloadIpHdr + (xPayloadIpHdr.oIpHdrLen << 2));

          pxNatEntry = NatFindIcmpQueryBindingRx(pxNat,
                                                 dwDstIp,
                                                 dwSrcIp,
                                                 ICMP_GET_ECHOID(pxPayloadIcmpHdr),
                                                xPayloadIpHdr.oProtocol);
          break;


        default:
          pxNatEntry = NULL;
      }


      if (pxNatEntry == NULL) {
        /*
         * The destination IP address matched  that of the
         * CPE, but the packet cannot be routed properly.
         * This could happen due to the following.
         *
         * NAT has released the binding because of the
         * underlying session exceeding the timeout constraint
         * of NAT.
         */
        return (NAT_PACKET_UNKNOWN);
      }


      /*
       * Reinitialize timer.
       */
      pxNatEntry->dwLastUsed = NetGlobalTimerGet();

      switch (pxNatEntry->eType) {

        case NAT_BINDING_LOCAL:
          return (NAT_TO_CPE);

        case NAT_BINDING_L2W:
          if ((xPayloadIpHdr.oProtocol == IPPROTO_UDP) ||
              (xPayloadIpHdr.oProtocol == IPPROTO_TCP)) {
            TRANSPORT_SET_SRC_PORT(pvPayloadProtocolHdr, pxNatEntry->u.xTUMapping.wLanPort);
          } else {
            if (xPayloadIpHdr.oProtocol == IPPROTO_ICMP) {
              ICMP_SET_ECHOID(pxPayloadIcmpHdr, pxNatEntry->u.xIcmpMapping.wMsgId);
            }
          }
          break;

        case NAT_BINDING_W2L:
          break;

        default:
          break;
      }

      /*
       * NOTE: The tranport layer header checksum is not modified
       *       as only 8 bytes after the IP header is included in
       *       an ICMP packet and there is no way to verify the
       *       checksum of the original packet.
       */

      /*
       * Main IP header changes
       * NOTE: This information will be used to contruct the IP header
       *       and checksum will be calculated in the Ip1toN layer.
       *       So, there is no need to change the IP header in the
       *       packet right here.
       */
      pxNetworkId->dwDstAddr = pxNatEntry->dwLanAddr;


      /*
       * Payload IP header checksum adjustment
       */
      xPayloadIpHdr.wCheck = NatChecksumAdjust(xPayloadIpHdr.wCheck,
                                               (WORD*) (&xPayloadIpHdr.dwSrcAddr),
                                               sizeof(xPayloadIpHdr.dwSrcAddr),
                                               (WORD*) (&pxNatEntry->dwLanAddr),
                                               sizeof(pxNatEntry->dwLanAddr));
      xPayloadIpHdr.dwSrcAddr = pxNatEntry->dwLanAddr;
      MOC_MEMCPY((ubyte *)pvPayloadIpHdr, (ubyte *)&xPayloadIpHdr, sizeof(IPHDR));


      /*
       * ICMP header checksum.
       */
      ICMP_SET_CHECKSUM(pxIcmpHdr, 0);
      ICMP_SET_CHECKSUM(pxIcmpHdr,
                        Checksum16((OCTET*) pxIcmpHdr,
                                   (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen)));
      return (NAT_OK);


    case ICMPTYP_REDIRECT:
      /*
       * According to RFC 1633 and RFC 2663, NAT should
       * not do anything to the REDIRECT messages. Just
       * send it up to the CPE.
       */
      return (NAT_TO_CPE);


    case ICMPTYP_ECHO:
    case ICMPTYP_TIMESTAMP:
    case ICMPTYP_INFO_REQUEST:
    case ICMPTYP_ADDRESS:
      /*
       * Just send any request to CPE.
       * TODO: Forward to DMZ host, if any?
       */
      return (NAT_TO_CPE);


    case ICMPTYP_ECHOREPLY:
    case ICMPTYP_TIMESTAMPREPLY:
    case ICMPTYP_INFO_REPLY:
    case ICMPTYP_ADDRESSREPLY:
      pxNatEntry = NatFindIcmpQueryBindingRx(pxNat,
                                             pxNetworkId->dwSrcAddr,
                                             pxNetworkId->dwDstAddr,
                                             ICMP_GET_ECHOID(pxIcmpHdr),
                                             oProtocolId);

      if (pxNatEntry == NULL) {
        return (NAT_PACKET_UNKNOWN);
      }

      switch (pxNatEntry->eType) {

        case NAT_BINDING_LOCAL:
          return (NAT_TO_CPE);


        case NAT_BINDING_L2W:
          /*
           * Main IP header changes
           * NOTE: This information will be used to contruct the IP header
           *       and checksum will be calculated in the Ip1toN layer.
           *       So, there is no need to change the IP header in the
           *       packet right here.
           */
          pxNetworkId->dwDstAddr = pxNatEntry->dwLanAddr;


          /*
           * ICMP header checksum.
           */
          ICMP_SET_ECHOID(pxIcmpHdr, pxNatEntry->u.xIcmpMapping.wMsgId);
          ICMP_SET_CHECKSUM(pxIcmpHdr, 0);
          ICMP_SET_CHECKSUM(pxIcmpHdr,
                            Checksum16((OCTET*) pxIcmpHdr,
                                       (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen)));
          return (NAT_OK);

        default:
          return (NAT_PACKET_UNKNOWN);
      }
      break;

    default:
      break;
  }


  return(NAT_PACKET_UNKNOWN);
}



/*****************************************************************************
Function:
        NatHandleIcmpTx()
Description:
        Handles ICMP packets from LAN to WAN.
Arguments:
        NATSTATE*               pxNat                   NAT instance handle.
        NETPACKET*              pxNetPacket             Packet pointer
        NETPACKETACCESS*        pxNetPacketAccess       Packet info
        H_NETDATA               hData                   NETWORKID*
        void*                   pvProtocolHdr           Pointer to the
                                                        protocol header
                                                        (UDP/TCP)
Outputs:
        None.
Returns:
        LONG                    NAT_OUT_OF_RESOURCE     means that the
                                                        NAT module could not
                                                        create a binding
                                                        either due to query id.
                                                        shortage or due
                                                        running out of memory.
                                NAT_PACKET_UNKNOWN      Unrecognized packet.
                                NAT_OK                  means address
                                                        translation is
                                                        successful.
Revisions:
        15-Oct-2001                                     Initial
        25-Mar-2002                                     API change
*****************************************************************************/
LONG NatHandleIcmpTx(NATSTATE* pxNat,
                     NETPACKET *pxNetPacket,
                     NETPACKETACCESS *pxNetPacketAccess,
                     H_NETDATA hData,
                     void *pvProtocolHdr)
{
  NETWORKID *pxNetworkId = (NETWORKID*) hData;
  OCTET oProtocolId = pxNetworkId->oProtocol;
  void* pvPayloadIpHdr = NULL;
  IPHDR xPayloadIpHdr;
  DWORD dwSrcIp, dwDstIp;
  WORD wSrcPort, wDstPort;
  void* pvPayloadProtocolHdr = NULL;
  ICMP_HDR *pxIcmpHdr = (ICMP_HDR*) pvProtocolHdr;
  NAT_ENTRY* pxNatEntry;


  /*
   * Perform some size checks.
   */
  if (pxNetPacket->pxPayload->wSize < (pxNetPacketAccess->wOffset +
                                       sizeof(ICMP_HDR))) {
    return (NAT_PACKET_UNKNOWN);
  }


  switch (pxIcmpHdr->oType) {

    case ICMPTYP_DEST_UNREACH:
    case ICMPTYP_SOURCE_QUENCH:
    case ICMPTYP_TIME_EXCEEDED:
    case ICMPTYP_PARAMETERPROB:
      pvPayloadIpHdr = (void*) (pxNetPacket->pxPayload->poPayload +
                                pxNetPacketAccess->wOffset +
                                sizeof(ICMP_HDR));
      MOC_MEMCPY((ubyte *)&xPayloadIpHdr, (ubyte *)pvPayloadIpHdr, sizeof(IPHDR));

      dwSrcIp = xPayloadIpHdr.dwSrcAddr;
      dwDstIp = xPayloadIpHdr.dwDstAddr;

      if ((xPayloadIpHdr.oProtocol != IPPROTO_UDP) &&
          (xPayloadIpHdr.oProtocol != IPPROTO_TCP)) {
        return (NAT_PACKET_UNKNOWN);
      }

      pvPayloadProtocolHdr = (void*) ((OCTET*) pvPayloadIpHdr + (xPayloadIpHdr.oIpHdrLen << 2));
      ASSERT(((DWORD)pvPayloadProtocolHdr & 0x1) == 0);
      wSrcPort = TRANSPORT_GET_SRC_PORT(pvPayloadProtocolHdr);
      wDstPort = TRANSPORT_GET_DST_PORT(pvPayloadProtocolHdr);


      /*************************************************************
       * Translation checks on the actual payload
       ************************************************************/

      /*
       * Search for a binding.
       */
      pxNatEntry = NatFindTUBindingTx(pxNat,
                                      dwDstIp, wDstPort,
                                      dwSrcIp, wSrcPort,
                                      xPayloadIpHdr.oProtocol);


      if (pxNatEntry == NULL) {
        return(NAT_PACKET_UNKNOWN);
      }

      pxNatEntry->dwLastUsed = NetGlobalTimerGet();

      switch (pxNatEntry->eType) {

        case NAT_BINDING_LOCAL:
          return(NAT_OK);

        case NAT_BINDING_L2W:
          TRANSPORT_SET_DST_PORT(pvPayloadProtocolHdr, pxNatEntry->u.xTUMapping.wTransPort);
          break;

        case NAT_BINDING_W2L:
          break;

        default:
          break;
      }

      /*
       * Main IP header changes
       * NOTE: This information will be used to contruct the IP header
       *       and checksum will be calculated in the Ip1toN layer.
       *       So, there is no need to change the IP header in the
       *       packet right here.
       */
      pxNetworkId->dwSrcAddr = pxNatEntry->dwTransAddr;


      /*
       * Payload IP header checksum adjustment
       */
      xPayloadIpHdr.wCheck = NatChecksumAdjust(xPayloadIpHdr.wCheck,
                                               (WORD*) (&xPayloadIpHdr.dwDstAddr),
                                               sizeof(xPayloadIpHdr.dwDstAddr),
                                               (WORD*) (&pxNatEntry->dwTransAddr),
                                               sizeof(pxNatEntry->dwTransAddr));
      xPayloadIpHdr.dwDstAddr = pxNatEntry->dwTransAddr;
      MOC_MEMCPY((ubyte *)pvPayloadIpHdr,(ubyte *) &xPayloadIpHdr, sizeof(IPHDR));


      /*
       * ICMP header checksum.
       */
      ICMP_SET_CHECKSUM(pxIcmpHdr, 0);
      ICMP_SET_CHECKSUM(pxIcmpHdr,
                        Checksum16((OCTET*) pxIcmpHdr,
                                   (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen)));
      return (NAT_OK);


    case ICMPTYP_REDIRECT:
      return (NAT_PACKET_UNKNOWN);


    case ICMPTYP_ECHO:
    case ICMPTYP_TIMESTAMP:
    case ICMPTYP_INFO_REQUEST:
    case ICMPTYP_ADDRESS:
      pxNatEntry = NatFindIcmpQueryBindingTx(pxNat,
                                             pxNetworkId->dwSrcAddr,
                                             pxNetworkId->dwDstAddr,
                                             ICMP_GET_ECHOID(pxIcmpHdr),
                                             oProtocolId);
      if (pxNatEntry == NULL) {
        E_NAT_BINDING eType = NAT_BINDING_L2W;
        IPTABLEENTRY xIpEntry;

        xIpEntry.dwAddr = pxNetworkId->dwSrcAddr;
        xIpEntry.wDefaultVlan = NETVLAN_ANY;
        xIpEntry.oIfIdx = NETIFIDX_ANY;

        if (IPADDRT_MYADDR == IpTableMsg(IPTABLEMSG_GETTYPE, (H_NETDATA) &xIpEntry))
          eType = NAT_BINDING_LOCAL;

        /*
         * Get the translation address.
         */
        xIpEntry.dwAddr = 0x0;
        xIpEntry.eAddrType = IPADDRT_ANY;
        xIpEntry.wDefaultVlan = NETVLAN_ANY;
        xIpEntry.oIfIdx = pxNetworkId->oIfIdx;

        if ((IpTableMsg(IPTABLEMSG_GETDEFAULT, (H_NETDATA) &xIpEntry) < 0) ||
            (xIpEntry.dwAddr == 0x0)) {
          /*
           * If the translation address look up fails, still return NAT_OK.
           * This will allow packets to be sent down without translation.
           * This feature is required for PPP auto-wakeup to work.
           */
          return (NAT_OK);
        };

        pxNatEntry = NatCreateBindingIcmpQuery(pxNat,
                                               pxNetworkId->dwDstAddr,
                                               pxNetworkId->dwSrcAddr,
                                               xIpEntry.dwAddr,
                                               ICMP_GET_ECHOID(pxIcmpHdr),
                           pxNetworkId->oIfIdx,
                                               ICMP_GET_ECHOID(pxIcmpHdr),
                                               eType);
      }

      if (pxNatEntry == NULL) {
        return (NAT_OUT_OF_RESOURCE);
      }


      switch (pxNatEntry->eType) {

        case NAT_BINDING_LOCAL:
          return (NAT_OK);


        case NAT_BINDING_L2W:
          /*
           * Main IP header changes
           * NOTE: This information will be used to contruct the IP header
           *       and checksum will be calculated in the Ip1toN layer.
           *       So, there is no need to change the IP header in the
           *       packet right here.
           */
          pxNetworkId->dwSrcAddr = pxNatEntry->dwTransAddr;


          /*
           * ICMP header checksum.
           */
          ICMP_SET_ECHOID(pxIcmpHdr, pxNatEntry->u.xIcmpMapping.wTransMsgId);
          ICMP_SET_CHECKSUM(pxIcmpHdr, 0);
          ICMP_SET_CHECKSUM(pxIcmpHdr,
                            Checksum16((OCTET*) pxIcmpHdr,
                                       (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen)));
          return (NAT_OK);

        default:
          return (NAT_PACKET_UNKNOWN);
      }
      break;


    case ICMPTYP_ECHOREPLY:
    case ICMPTYP_TIMESTAMPREPLY:
    case ICMPTYP_INFO_REPLY:
    case ICMPTYP_ADDRESSREPLY:
      /*
       * All replies should be emanating from the CPE stack.
       */
      return (NAT_OK);
      break;

    default:
      break;
  }


  return(NAT_PACKET_UNKNOWN);
}
