#ifndef __LANGUAGE_H__
#define __LANGUAGE_H__

/* Use preprocessor constants to define all text strings here.
 * This allows easy translation to other languages.
*/

#endif
