/*
 * mpoa_vars.c
 *
 * mpoa  variables
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "stdlib.h"
#include "pthread.h"
#include "sys/socket.h"
#include "netcommon.h"
#include "netconfig.h"
#include "linkconf.h"
#include "netmain.h"
#include "mpoa.h"

/****************************************************************************
 *
 * global
 *
 ****************************************************************************/
/****************************************************************************
 *
 * MPOA
 *
 ****************************************************************************/
const NETCONFIFTEMPLATE axMpoaULIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{FALSE,0,0,0}}},
};

const NETCONFIFTEMPLATE axMpoaLLIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{FALSE,0,0,0}}},
};

const NETCONFINSTANCETEMPLATE axMpoaInstTemplate[1] =
{
  {
     /* Options settings: */ 6, axNetSettings,
     /* UL interfaces: */ 1,axMpoaULIf,
     /* LL interfaces: */ 1,axMpoaLLIf,
     /* Msgs, not including Open: none */ 0,NULL
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateMpoa = {
  /* Mpoa */
   NULL/*MpoaInitialize*/,NULL/*MpoaTerminate*/,
   MpoaInstanceCreate,
   MpoaInstanceDestroy,MpoaInstanceSet,MpoaInstanceMsg,
   MpoaInstanceULInterfaceCreate,MpoaInstanceLLInterfaceCreate,
   MpoaInstanceWrite,MpoaInstanceRcv,
   NULL,
   MpoaInstanceULInterfaceDestroy,MpoaInstanceULInterfaceIoctl,
   MpoaInstanceLLInterfaceDestroy,MpoaInstanceLLInterfaceIoctl,
   NULL,
   axMpoaInstTemplate};

/****************************************************************************
 *
 * Array initialization
 *
 ****************************************************************************/

const NETCONFLIBRARYTEMPLATE *apxMpoaLibTemplate[] = {
  &gxLibTemplateMpoa};

