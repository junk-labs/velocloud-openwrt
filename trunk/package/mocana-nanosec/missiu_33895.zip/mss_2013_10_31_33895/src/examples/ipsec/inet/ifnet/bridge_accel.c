/*
 * bridge_accel.c
 *
 * Implementation of the bridge module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include <NNstyle.h>
#include "ethbridge_flavor.h"
#include <stdlib.h>
#include <string.h>
#include "sys/socket.h" /* NNOS ntohx, htonx defs */
#include <netinet/in.h> /* Linux ntohx, htonx defs */
#include <pthread.h>
#include "netcommon.h"
#include "dllist.h"
#include "netutils.h"
#include "netdefs.h"
#include "nettime.h"
#include "ethernet.h"
#include "bridgedbg.h"
#include "bridgedefs.h"
#include "netsnmp.h"
#include "snmp_tcpip_data.h"
#include "spanningtree.h"
#include "macfilter.h"
#include "limiter.h"
#include "meter.h"

#ifdef CUSTOM_QUEUE
#include "cqueue.h"
#include "cqueue_int.h"
#endif

/*****************************************************************************
 *
 * Local Function prototypes
 *
 *****************************************************************************/
static void _EthHeaderAdd(H_NETINSTANCE hEth,
                          NETPACKET *pxPacket,
                          NETPACKETACCESS *pxAccess,
                          ETHID *pxEthId,
                          WORD wProtocol);


/*****************************************************************************
 *
 * Constants
 *
 *****************************************************************************/

const OCTET aoEthBroadcastAddr[ETHADDRESS_LEN] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

/*****************************************************************************
 *
 * API
 *
 *****************************************************************************/

/*
 * EthInstanceWrite
 *  Eth Instance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hEth                        Eth Instance handle
 *   hIf                         UL interface handle as provided by
 *                               EthInstanceULInterfaceCreate
 *   pxPacket                    Packet pointer
 *   pxAccess                    NETPACKETACCESS pointer
 *   hData                       OCTET * interface index
 *
 *  Return:
 *  Number of bytes written or a <0 error code
 */
LONG EthInstanceWrite(H_NETINSTANCE hEth,
                      H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,
                      NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  ETH_LL *pxLl;
  ETH_UL *pxUl;
  WORD wProtocol;
  ETHID *pxEthId = (ETHID*)hData;
  OCTET obSendIn = FALSE,obSendOut = TRUE;
  LONG lReturn;
  INT iDx = (int)hIf;
  ETH_CHECK_STATE(pxEth);
  NETPACKET_CHECK(pxPacket);

  ASSERT((((OCTET) hIf) < ETH_MAXULIF) &&
         (pxEthId != NULL) && (pxAccess != NULL));

  lReturn = pxAccess->wLength;

  ASSERT((pxEthId != NULL) && (pxEthId->oIfIdx < (OCTET) ETHBR_MAXNUM_IF));
  pxLl = pxEth->apxIfToLlMap[pxEthId->oIfIdx];

  /* It is possible to get the odd packet on an interface that has just
   * closed, maybe because of changing the encapsulation on the interface.
   * e.g. From Eth to IPoA. (Arp may still have packets to send)
   */
  if (pxLl == NULL) {
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    return lReturn;
  }

#if 0
  /* If the LL interface is bridged and packet is not Bcast or Mcast */
  if (pxLl->obBridged == TRUE && ((0x01 & pxEthId->aoAddr[0]) == 0)) {
    MACFILTERENTRY *pxFilterEntry;

    /* Lookup the destination address */
    pxFilterEntry = MacFilterLookup(pxEthId->aoAddr);
    if (NULL  == pxFilterEntry) {
      /* The address was not found */
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      return lReturn;
    }

    /* Get the new LL */
    ASSERT(pxFilterEntry->oIfIdx < (OCTET) ETHBR_MAXNUM_IF);
    pxLl = pxEth->apxIfToLlMap[pxFilterEntry->oIfIdx];
    ASSERT(pxLl);
    /*
     * Continue if the new LL is open and bridged.
     */
    if (pxLl->obBridged != TRUE) {
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      return lReturn;
    }
  }
#endif

  if (pxLl->obOpen != TRUE) {
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    return lReturn;
  }

  if (pxEthId->wVlan != NETVLAN_DEFAULT) {
    OCTET oIdx;
    /* Check the vlan is allowed */
    for (oIdx = 0; oIdx < pxEth->oSpecificVlanNumber; oIdx++) {
      if ((pxEth->pwSpecificVlan[oIdx] & ETHVID_MASK) ==
          (pxEthId->wVlan & ETHVID_MASK)) {
        break;
      }
    }
    if (oIdx >= pxEth->oSpecificVlanNumber &&
        (pxLl->wDefaultVlan & ETHVID_MASK) != (pxEthId->wVlan & ETHVID_MASK)) {
      /* Not allowed - delete */
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      return lReturn;
    }
  }


  /* Get the protocol */
  pxUl = pxEth->apxUl[iDx];
  ASSERT(pxUl != NULL);
  wProtocol = pxUl->wRoutingId;
  ASSERT((ETHID_MIN <= wProtocol) && (wProtocol <= ETHID_MAX));

#ifndef CUSTOM_QUEUE
  ETH_DBGP(REPETITIVE,
          "EthInstanceWrite:oIfIdx=%d, Dst=%02x:%02x:%02x:%02x:%02x:%02x,Proto=%s, eth payload len=%d, Priority=%d\n",
           pxEthId->oIfIdx,
           HWADDRDISPLAY(pxEthId->aoAddr),
           EthProtoToString(wProtocol),
           pxAccess->wLength,
           pxAccess->oPriority);
#else
  ETH_DBGP(REPETITIVE,
          "EthInstanceWrite:oIfIdx=%d, Dst=%02x:%02x:%02x:%02x:%02x:%02x,Proto=%s, eth payload len=%d, Priority=%d, Class=%d\n",
           pxEthId->oIfIdx,
           HWADDRDISPLAY(pxEthId->aoAddr),
           EthProtoToString(wProtocol),
           pxAccess->wLength,
           pxAccess->oPriority,
           pxAccess->oClass);
#endif

  obSendIn = ((pxEth->obLocalLoopback == TRUE) &&
              ((0xFF == pxEthId->aoAddr[0]) ||
               (0x00 == memcmp(pxEthId->aoAddr,
                               pxEth->aaoIfEthAddr[pxEthId->oIfIdx],
                               ETHADDRESS_LEN))));
  obSendOut = (obSendIn == FALSE) || (0xFF == pxEthId->aoAddr[0]);

  /* Add the ethernet header */
  _EthHeaderAdd(hEth, pxPacket, pxAccess, pxEthId, wProtocol);

  if ((obSendIn != FALSE) && (obSendOut != FALSE)) {
    NETPAYLOAD_ADDUSER(pxPacket->pxPayload);
  }

  {
    NETPACKETACCESS xAccess;
    xAccess.wOffset = pxAccess->wOffset;
    xAccess.wLength = pxAccess->wLength;

    if (obSendOut == TRUE) {
      if (pxLl->obBridged == TRUE && pxEth->obSpanningEnabled == TRUE &&
          ST_PORT_STATE(pxLl->oPortNo) != Forwarding) {
        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      } else {
        /* Call the LL write */
        ASSERT(pxLl->pfnLlWrite);
        pxLl->pfnLlWrite(pxLl->hLlInst,
                         pxLl->hLlIf, pxPacket, pxAccess,(H_NETDATA)pxEthId->oIfIdx);
      }
    }
    if (obSendIn == TRUE) {
      NETIFID xNetIfId;

      /* Ensure Hybrid mode does not forward pkts sent to LAN port */
      pxEth->bSendingPktIn = TRUE;

      xNetIfId.oIfIdx = pxEthId->oIfIdx;
      xNetIfId.wVlan  = pxEthId->wVlan;
      /* Call our own receive function */
      EthInstanceRcv(hEth,(H_NETDATA)pxLl,
                     pxPacket,&xAccess,(H_NETDATA)&xNetIfId);
    }

  }

  return lReturn;
}

#ifdef CUSTOM_QUEUE
#ifdef BRIDGEDBG_HI
BOOL dbg_bCustomQueuePrint = FALSE;
#endif
#endif

/*
 * EthInstanceRcv
 *  Eth Instance Rcv function
 *   Eth Instance Rcv function. Follows PFN_NETRXCBK
 *   def.
 *
 *   Args:
 *    hEth                       Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    pxAccess                   NETPACKETACCESS pointer
 *    hData                      OCTET * interface index
 *
 *   Return:
 *    Number of byte received or a <0 error code
 */
LONG EthInstanceRcv(H_NETINSTANCE hEth,
                    H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,
                    NETPACKETACCESS *pxAccess,
                    H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  NETPAYLOAD *pxPayload;
  ETH_UL *pxUl = NULL;
  ETH_LL *pxLl;
  ETHID xEthId;
  OCTET *poEthHdr;
  OCTET *poSrcHwAddr;
  WORD wNewOffset = pxAccess->wOffset;
  WORD wNewLength = pxAccess->wLength;
  WORD wOldLength = pxAccess->wLength;
  WORD wProtocol;
  WORD wVlan = NETVLAN_DEFAULT;
  OCTET obVlanField = FALSE;
  NETIFID *pxNetIfId = (NETIFID*)hData;
  OCTET oIfIdx;
  OCTET oIdx;
  OCTET obStackAddress = FALSE;

  ETH_CHECK_STATE(pxEth);
  NETPACKET_CHECK(pxPacket);
  ASSERT(pxNetIfId != NULL);

  oIfIdx = pxNetIfId->oIfIdx;
  ASSERT(oIfIdx < (OCTET) ETHBR_MAXNUM_IF);

  pxLl = pxEth->apxIfToLlMap[oIfIdx];
  ASSERT(pxLl != NULL);

  pxPayload = pxPacket->pxPayload;

  if (pxLl->obOpen != TRUE) {
    NETPAYLOAD_DELUSER(pxPayload);
    return (LONG)wOldLength;
  }

  /* Set the pointer to the start of the header */
  poEthHdr = pxPayload->poPayload + wNewOffset;

  /* Get the protocol */
  MOC_MEMCPY((ubyte *)&wProtocol,(ubyte *)(poEthHdr+ETHTYPE_OFFSET),
        (size_t)ETHTYPE_LEN);
  wProtocol = ntohs(wProtocol);

  wNewOffset += ETHHEADER_LEN;
  wNewLength -= ETHHEADER_LEN;

  if (wProtocol == ETHVLAN_TYPE) {
    /* Get the vlan tag */
    MOC_MEMCPY((ubyte *)&wVlan, (ubyte *)(poEthHdr+ETHTYPE_OFFSET+ETHTYPE_LEN),
            sizeof(WORD));
    wVlan = ntohs(wVlan);

    /* Get the real protocol */
    MOC_MEMCPY((ubyte *)&wProtocol,
        (ubyte *)(poEthHdr+ETHTYPE_OFFSET+ETHVLAN_LEN),
        (size_t)ETHTYPE_LEN);
    wProtocol = ntohs(wProtocol);

    wNewOffset += ETHVLAN_LEN;
    wNewLength -= ETHVLAN_LEN;
    obVlanField = TRUE;
  }


  /*
   * Do Broadcast and Multicast filtering and
   * check for bridge management packets
   * these are multicast and IEEE 802.2/802.3
   */
  if ((0x01 & poEthHdr[0]) != 0) { /* Test for both Multicast and Broadcast */

    /*
     * Bcast and Mcast limiting
     */
    if (!memcmp(poEthHdr, aoEthBroadcastAddr, ETHADDRESS_LEN)) {
      ETH_LIMIT_BCAST_RCV((DWORD)pxAccess->wLength, pxLl);
    } else {
      /* Must be a Multicast */
      ETH_LIMIT_MCAST_RCV((DWORD)pxAccess->wLength, pxLl);
    }
    if (ETH_LIMIT_BCAST_CHECK(pxLl) ||
        ETH_LIMIT_MCAST_CHECK(pxLl)) {
      SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
      NETPAYLOAD_DELUSER(pxPayload);
      return (LONG)wOldLength;
    }

    /*
     * Check for the spanning tree multicast address
     */
    if(wProtocol <= ETHDATA_LEN
       && pxEth->obSpanningEnabled == TRUE
       && pxLl->obBridged == TRUE
       && ST_PORT_STATE(pxLl->oPortNo) != Disabled
       && !memcmp(poEthHdr, aoSpanningTreeAddr, ETHADDRESS_LEN)) {

      (void)SpanningTreeRcv(pxLl->oPortNo, (poEthHdr));

      SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
      NETPAYLOAD_DELUSER(pxPayload);
      return (LONG)wOldLength;
    }
  }

  /*
   * Ingress Rule:
   * If the pkt's vlan id == 0 or pkt has no vlan field -
   * reject it if obAdmitOnlyVlan == TRUE
   * OR set the vlan id to the port default - if
   * one has been set.
   */
  if (wVlan == (WORD)0 || obVlanField == FALSE) {
    if (pxEth->obAdmitOnlyVlan == TRUE) {
      SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
      NETPAYLOAD_DELUSER(pxPayload);
      return (LONG)wOldLength;
    } else if (pxLl->wDefaultVlan != NETVLAN_DEFAULT) {
      WORD wTemp;

      /* If the packet does not have a vlan field - add one */
      if (obVlanField == FALSE) {
        OCTET aoScratch[ETHHEADER_LEN];
        /* Need to move the header to 'insert' the 4 byte vlan field */
        /* Check for enough space */
        ASSERT(pxAccess->wOffset >= ETHHEADER_LEN + ETHVLAN_LEN);

        MOC_MEMCPY((ubyte *)&aoScratch[0],
            (ubyte *) poEthHdr, (size_t)ETHHEADER_LEN);
        poEthHdr -= ETHVLAN_LEN;
        MOC_MEMCPY((ubyte *)poEthHdr,
            (ubyte *)&aoScratch[0], (size_t)ETHHEADER_LEN);

        obVlanField = TRUE;
      }
      /* Set the vlan to the default of this LL interface*/
      wTemp = htons((WORD)ETHVLAN_TYPE);
      MOC_MEMCPY((ubyte *)(poEthHdr+ETHTYPE_OFFSET),
            (ubyte *) &wTemp, (size_t)ETHTYPE_LEN);

      wVlan = pxLl->wDefaultVlan;
      wTemp = htons(wVlan);
      MOC_MEMCPY((ubyte *)(poEthHdr+ETHTYPE_OFFSET+ETHTYPE_LEN),
            (ubyte *) &wTemp, sizeof(WORD));
    }
  }

  /*
   * Ingress filter:
   * Check the VLAN is one of the group
   */
  if (pxLl->obIngressFilter == TRUE) {
    for (oIdx = 0; oIdx < pxEth->oSpecificVlanNumber; oIdx++) {
      if ((pxEth->pwSpecificVlan[oIdx] & ETHVID_MASK) == (wVlan & ETHVID_MASK)) {
        break;
      }
    }
    if (oIdx >= pxEth->oSpecificVlanNumber &&
        (pxLl->wDefaultVlan & ETHVID_MASK) != (wVlan & ETHVID_MASK)) {
      /* Not allowed - delete packet */
      SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
      NETPAYLOAD_DELUSER(pxPayload);
      return (LONG)wOldLength;
    }
  }

  /*
   * Set the packet priority - if it has not already been set
   */
  if (obVlanField == TRUE && pxAccess->oPriority == (OCTET)LOW_PRIORITY &&
      (((wVlan & ETHPRI_MASK) >> ETHPRI_SHIFT) > NETVLAN_PRIORITY_LIMIT)) {
      pxAccess->oPriority = (OCTET)HIGH_PRIORITY;
  }

  /* Is the destination the stack */
  if (0x00 == memcmp(poEthHdr, pxEth->aaoIfEthAddr[oIfIdx], (size_t)ETHADDRESS_LEN)) {
    obStackAddress = TRUE;
  }

  /* Set the pointer to the source hardware address */
  poSrcHwAddr = poEthHdr + ETHADDRESS_LEN;

#ifdef CUSTOM_QUEUE
  {
  OCTET oCriteria = 0;  /* Table entry return */

    if (0 == oIfIdx) {
      oCriteria = _CustomQueueMatchCriteria(&CustomQueueTable[0], pxPayload, pxAccess);
      if (oCriteria != CUSTOM_QUEUE_NO_MATCH) {
        pxAccess->oClass = aoCustomQueueClass[oCriteria];  /* Set the class in the packet for later use on transmission */
      }
    }
  }

#ifdef BRIDGEDBG_HI
  if (dbg_bCustomQueuePrint) {
  int i = 0;

    while(i<MAX_CUSTOM_QUEUE_CRITERIA) {
      if (aoCustomQueueClass[i]) {  /* Is entry being used? */
        printf("*** _CustomQueuePrintCriteriaStruct *** %d\n", i);
        _CustomQueuePrintCriteriaStruct(&CustomQueueTable[i]);
      }
      i++;
    }
    dbg_bCustomQueuePrint = 0;
  }
#endif  /* BRIDGEDBG_HI */
#endif  /* CUSTOM_QUEUE */

  /*
   * If this LL is part of the bridge, call -
   * the learning process and
   * the forwarding process
   */
  if (pxLl->obBridged && pxEth->obSpanningEnabled == TRUE) {

    (void)_LearningProcess(pxLl, poSrcHwAddr, wVlan);

    /* If the stack is not the only destination */
    if (!obStackAddress) {
      /* PPPoE Filter - in hybrid mode the bridge only forwards PPPoE packets */
      if (!( (pxEth->bSendingPktIn && (pxNetIfId->oIfIdx == pxEth->oLanIdx)) ||
         (pxEth->obForwardPPPoEOnly &&
          wProtocol != ETHID_PPPOEDISCOVERY &&
          wProtocol != ETHID_PPPOESESSION) )) {
        _ForwardingProcess(pxEth, pxLl, pxPacket, pxAccess, wVlan);
      }
#ifndef NDEBUG
      else {
        ETH_DBGP(REPETITIVE,
          "EthInstanceRcv: Packet is not PPPoE - not forwarding to other bridged legs\n");
      }
#endif
    }
  }
  pxEth->bSendingPktIn = FALSE; /* ensure this flag is now clear */

  /*
   * Send the packet up the stack if we get this far
   */

  if (wProtocol <= ETHDATA_LEN) {/* IEEE 802.2/802.3 pkt- not supported */
    SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInUnknownProtos++ );
    NETPAYLOAD_DELUSER(pxPayload);
    return (LONG)wOldLength;
  }

  /* If the destination address is NOT Bcast/Mcast and NOT ours - delete the pkt */
  if (((0x01 & poEthHdr[0]) == 0) && /* Test for both Multicast and Broadcast */
      !obStackAddress) {
    SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    NETPAYLOAD_DELUSER(pxPayload);
    return (LONG)wOldLength;
  }

  ETH_DBGP(REPETITIVE,
           "EthInstanceRcv:oIfIdx=%d,Dst=%02x:%02x:%02x:%02x:%02x:%02x,Src=%02x:%02x:%02x:%02x:%02x:%02x,Proto=%s, eth len=%d, Priority=%d\n",
           oIfIdx,
           HWADDRDISPLAY(poEthHdr),
           HWADDRDISPLAY(poSrcHwAddr),
           EthProtoToString(wProtocol),
           wOldLength,
           pxAccess->oPriority);

  /*copy the source hw address */
  MOC_MEMCPY((ubyte *)&xEthId.aoAddr,
                (ubyte *)(poSrcHwAddr),
                (size_t)ETHADDRESS_LEN);

  /*Get EHID data*/
  xEthId.oIfIdx = pxNetIfId->oIfIdx;
  xEthId.wVlan = wVlan;

  /* Find match for wProtocol in UL wRoutingId entries */
  for (oIdx = 0; oIdx < pxEth->oUlNumber; oIdx++,pxUl++) {
    pxUl = pxEth->apxUl[oIdx];
    ASSERT(pxUl != NULL);
    if ((pxUl->wRoutingId == wProtocol) &&
        ((pxUl->oIfIdx == pxNetIfId->oIfIdx) || (pxUl->oIfIdx == NETIFIDX_ANY))) {
      break;
    }
  }
  if (oIdx == pxEth->oUlNumber) {
    /* No match - no UL module has been plumbed in to receive the packet */
    SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    NETPAYLOAD_DELUSER(pxPayload);
    return (LONG)wOldLength;
  }

  /* We've found a UL module to take the packet */

  /* Update the pxAccess structure */
  pxAccess->wOffset = wNewOffset;
  pxAccess->wLength = wNewLength;

  /* Write the packet to registered UL */
  ASSERT(pxUl->pfnRxCbk);
  (void)pxUl->pfnRxCbk(pxUl->hUlInst,
                       pxUl->hUlIf,
                       pxPacket,
                       pxAccess,
                       (H_NETDATA)&xEthId);

  return (LONG)wOldLength;
}


/***************************************************************************
* static void _EthHeaderAdd(H_NETINSTANCE hEth,
*                           NETPACKET *pxPacket,
*                           NETPACKETACCESS *pxAccess,
*                           ETHID *pxEthId,
*                           WORD wProtocol)
*  Adds a erhernet header to pxPacket
*
*   Args:
*    hEth                       Instance Handle
*    pxPacket                   NETPACKET packet pointer
*    pxAccess                   NETPACKETACCESS pointer
*    pxEthId                    ETHID pointer
*    wProtocol                  eth frame type
*
*  ret: void
****************************************************************************/
static void _EthHeaderAdd(H_NETINSTANCE hEth,
                          NETPACKET *pxPacket,
                          NETPACKETACCESS *pxAccess,
                          ETHID *pxEthId,
                          WORD wProtocol)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  ETH_LL *pxLl;
  OCTET *poDestAddr = (OCTET *)pxEthId->aoAddr;
  NETPAYLOAD *pxPayload;
  OCTET *poTemp;

  pxLl = pxEth->apxIfToLlMap[pxEthId->oIfIdx];

  ETH_DBG_ASSERT((pxLl != NULL) &&
                 (pxLl->obOpen == TRUE) &&
                 (pxPacket != NULL) &&
                 (pxAccess != NULL) &&
                 (poDestAddr != NULL));

  ASSERT(pxAccess->wOffset >= (WORD)ETHHEADER_LEN);

  pxPayload = pxPacket->pxPayload;

  poTemp = pxPayload->poPayload + pxAccess->wOffset;

  pxAccess->wOffset -= (WORD)ETHHEADER_LEN;
  pxAccess->wLength += (WORD)ETHHEADER_LEN;

  /* Add the protocol */
  poTemp -= ETHTYPE_LEN;
  wProtocol = htons(wProtocol);
  MOC_MEMCPY((ubyte *)poTemp,(ubyte *) &wProtocol, (size_t)ETHTYPE_LEN);

  /* Check for VLAN */
  if (pxEthId->wVlan != NETVLAN_DEFAULT ||
      pxLl->wDefaultVlan != NETVLAN_DEFAULT) {
    WORD wTemp;
    ASSERT(pxAccess->wOffset >= (WORD)(ETHVLAN_LEN));

    /* Copy in the VLAN id */
    if (pxEthId->wVlan == NETVLAN_DEFAULT) {
      wTemp = htons(pxLl->wDefaultVlan);
    } else {
      wTemp = htons(pxEthId->wVlan);
    }
    poTemp -= sizeof(WORD);
    MOC_MEMCPY((ubyte *)poTemp,(ubyte *) &wTemp, sizeof(WORD));

    /* Copy in the VLAN type */
    wTemp = htons((WORD)ETHVLAN_TYPE);
    poTemp -= ETHTYPE_LEN;
    MOC_MEMCPY((ubyte *)poTemp,(ubyte *) &wTemp, (size_t)ETHTYPE_LEN);

    pxAccess->wOffset -= ETHVLAN_LEN;
    pxAccess->wLength += ETHVLAN_LEN;
  }

  /* Add the source address */
  poTemp -= ETHADDRESS_LEN;
  MOC_MEMCPY((ubyte *)poTemp,
                (ubyte *)pxEth->aaoIfEthAddr[pxEthId->oIfIdx],
                (size_t)ETHADDRESS_LEN);

  /* Add the destination address */
  poTemp -= ETHADDRESS_LEN;
  MOC_MEMCPY((ubyte *)poTemp,(ubyte *) poDestAddr, (size_t)ETHADDRESS_LEN);

}
