/*
 * netdbg.h
 *
 * Network wide debug API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETDBG_H_
#define _NETDBG_H_

/****************************************************************************
 *
 * Macros
 *
 ****************************************************************************/

#ifdef NDEBUG
  #ifdef NETDBG_HI
    #undef NETDBG_HI
  #endif /*#ifdef NETDBG_HI*/
#endif /*#ifdef NDEBUG*/

/* Predefine everything to naught. To be redefined at a later
   stage */
#define NETDBG_CHECKSTATE(x,dwMagicCookie)
#define NETDBG_SETCOOKIE(x,dwMagicCookie)
#define NETDBG_UNSETCOOKIE(x)
#if defined (__VXWORKS_RTOS__)
#define NETDBG_LEVELP(level,reference,fmr,args)
#else
#define NETDBG_LEVELP(level,reference,fmr,args...)
#endif
#define NETDBG_LEVEL(level,reference,x)
#define NETDBG_VAR(x)
#define NETDBG_CHECKPOINT(x)
#define NETDBG_ASSERT(x)
#ifndef NDEBUG

 /*#ifdef NETDBG_HI*/
#if defined(NETDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)
#if defined (__VXWORKS_RTOS__)
  #undef NETDBG_LEVELP
  #define NETDBG_LEVELP
#else
  #undef NETDBG_LEVELP
  #define NETDBG_LEVELP(level,reference,fmt,args...)  do { \
    if (level <= reference) {  \
      printf(fmt, ##args);    \
     }       \
    } while (0)
#endif

  #undef NETDBG_CHECKPOINT
  #define NETDBG_CHECKPOINT(x) (x = __LINE__)

  #undef NETDBG_LEVEL
  #define NETDBG_LEVEL(level,reference,x) do {  \
    if (level <= reference) {  \
      x;      \
     }       \
    } while (0)

  #undef NETDBG_VAR
  #define NETDBG_VAR(x)      x

  #undef NETDBG_CHECKSTATE
  #define NETDBG_CHECKSTATE(x,dwRefMagicCookie) \
    ASSERT((x != NULL) && (x->dwMagicCookie == dwRefMagicCookie));

  #undef NETDBG_SETCOOKIE
  #define NETDBG_SETCOOKIE(x,dwRefMagicCookie) \
    ((x)->dwMagicCookie = dwRefMagicCookie)

  #undef NETDBG_UNSETCOOKIE
  #define NETDBG_UNSETCOOKIE(x) ((x)->dwMagicCookie = 0)

  #undef NETDBG_ASSERT
  #define NETDBG_ASSERT(x) ASSERT(x)
 #endif /* #ifdef NETDBG_HI */


/*
 * Ip address display
 */
 #define    IPADDRDISPLAY(a)    ((a >> 24) & 0xff), ((a >> 16) & 0xff), ((a >> 8) & 0xff), (a & 0xff)

 #define IPFORM               "%ld.%ld.%ld.%ld"
/*
 * HW address display
 */
 #define HWADDRDISPLAY(a) a[0],a[1],a[2],a[3],a[4],a[5]
 #define MACFORM              "%02X:%02X:%02X:%02X:%02X:%02X"

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

/*
 * NetPrintPayload
 *  Print a payload to stdout
 *
 *  Args:
 *   poPayload              pointer to the payload. Must be != NULL
 *   wLength                payload length
 *
 *  Return:
 *   0
 */
LONG NetPrintPayload(OCTET *poPayload, WORD wLength);


/*
 * IpProtoToString
 *  Convert to a string(TCP,UDP,ICMP,...) the protocol in the ip header
 */
CHAR *IpProtoToString(OCTET oProtocol);

#endif /* #ifndef NDEBUG */


#endif /* #ifndef _NETDBG_H_ */













