/*
 * netif_process.c
 *
 * NetIfProcess
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "snmp_tcpip_data.h"
#include "../include/if_types.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "netdbg.h"
#include "ethernet.h"
#include "arp.h"
#include "ip1ton.h"
#include "netdefs.h"
#include "netconfig.h"
#include "netmain.h"
#include "linkconf.h"
#include "netif_limiter.h"
#ifdef ETHERNET
#include "ethconf.h"
#include "ethlink.h"
#endif /*#ifdef ETHERNET*/
#ifdef PPP
#include "ppp.h"
#include "pppoeconf.h"
#include "pppconf.h"
#include "pppoecommon.h"
#endif /*#ifdef PPP*/
#ifdef NET_DSL
#include "mpoaconf.h"
#include "mpoa.h"
#include "adslmgr.h"
#endif /*#ifdef NET_DSL*/
#include "netif.h"
#include "netsnmp.h"
#include "routing_table.h"
#include "dhcpclient.h"
#include "dnsapi.h"
#include "sockapi.h"
#include "mn_ndi.h"

#ifdef ROUTER
  #include "router.h"
#endif

#ifdef IPSEC
  #include "ipsec.h"
#endif /*#ifdef IPSEC*/

#ifdef IPFRAG
  #include "ipfrag.h"
#endif /*#ifdef IPFRAG*/

#ifdef NAT
  #include "nat.h"
#endif /*#ifdef NAT*/


void _NetIfNetDrvBufferToNetPacket(DLLIST *pdllNetDrvBuf,DLLIST *pdllNetPacket, NETIFCONF *pxIfConf);
void _NetIfNetDrvBufferTrash(DLLIST *pdllNetDrvBuf,NETIFCONF *pxIfConf);

/*
 * NetIfProcessDrv
 *  Network interface processing: driver & link layer modules.
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Network wrapper
 *   oIfIdx                    interface index
 *
 *  Return:
 *   >= 0 - number of packets read   < 0 - error
 */
LONG NetIfProcessDrv(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETWRAPPERSTATE *pxWrapperState;
  NETIFCONF *pxIfConf;
  NETIFID xNetIfId;
  NETIFLIMITER *pxNetIfLimiter;
  DLLIST *pdllNetPacket;
  DWORD dwPacketCnt = 0;
#ifdef LINK_AGGREGATION
  OCTET trash=0;
#endif

  NETMAIN_ASSERT(pxWrapper != NULL);

  pxWrapperState = NETGETWRAPPERSTATE(pxWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL);

  pxNetIfLimiter = NETGETLIMITER(pxWrapper);
  NETMAIN_ASSERT(pxNetIfLimiter != NULL);

  pxIfConf = NETGETIFCONF(pxWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState = NETGETIFSTATE(pxIfConf); /* RS keep the state of logical itself*/

#ifdef LINK_AGGREGATION
  if ( pxIfConf->oFlags & IFF_LOGICAL ){
      if ( pxIfConf->iActivePhyLinkIfIdx >= 0 ){
         /* pxIfConf = NETGETIFCONF(pxWrapper, pxIfConf->iActivePhyLinkIfIdx ); - Atul*/
          pxIfConf = NETGETIFCONF(pxWrapper, pxIfConf->iLogicalLinkIfIdx );
         NETMAIN_ASSERT(pxIfConf != NULL);
      }else
     return 0;
  }else{
      NETIFCONF *pxLIfConf;
      if ( pxIfConf->iLogicalLinkIfIdx >= 0 ){
          pxLIfConf = NETGETIFCONF(pxWrapper, pxIfConf->iLogicalLinkIfIdx);
          NETMAIN_ASSERT(pxLIfConf != NULL);
          if ( pxLIfConf->iActivePhyLinkIfIdx == oIfIdx )
              return 0; /* come back and read when logical intf processed */
          else
              trash = 1; /* read and trash now */
      }else
          trash = 1;
  }
#endif

  /* if (pxIfConf->oFlags & IFF_PHYUP) { - Atul */
  if (pxIfConf->oFlags & IFF_UP)
  {

    /* NETMAIN_DBGP(REPETITIVE,"NetIfProcessDrv: interface: %d, oFlags= %x\n",
                       oIfIdx, pxIfConf->oFlags); */

  /*
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_REPETITIVE))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"NetIfProcessDrv: interface: ",oIfIdx);
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,", oFlags= ", pxIfConf->oFlags);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }
  */
    xNetIfId.oIfIdx = oIfIdx;
    xNetIfId.wVlan  = NETVLAN_ANY;

    switch(pxIfConf->ePhyLinkType) {
#if defined(ETHERNET) || defined(PPPOE)
    case ETH:
      /*NETMAIN_DBGP(REPETITIVE,"NetIfProcessDrv called on interface %d\n",
                       oIfIdx); */
       /* Dequeue packet from the given oIfIdx */
      /* Poll driver for incoming data */
        {
        NETPACKET *pxPacket;
        NETPACKETACCESS xAccess;

        /* NETMAIN_DBGP(REPETITIVE,
        "NetIfProcessDrv something to read on interface %d\n", oIfIdx); */
        /**
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,
                    "NetIfProcessDrv something to read on interface ",oIfIdx);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
        }
       **/


#ifdef LINK_AGGREGATION
#if 0
        if ( trash ){
           _NetIfNetDrvBufferTrash(&pxWrapperState->dllRxBuf);
            break;
        }
#else
        if ( trash ){
#ifndef __LOCK_OPT_ON__
#ifdef __LOCK_QUEUE__
            RTOS_mutexWait((pxIfConf->xMutex));
#endif
#endif
            _NetIfNetDrvBufferTrash(&pxIfConf->dllRxBuf,pxIfConf);
#ifndef __LOCK_OPT_ON__
#ifdef __LOCK_QUEUE__
            RTOS_mutexRelease((pxIfConf->xMutex));
#endif
#endif
            break;
        }
#endif /* TBD */
#endif
#if 0 /* TBD */
        _NetIfNetDrvBufferToNetPacket(&pxWrapperState->dllRxBuf,
                                      &pxWrapperState->dllNetPacketRx);
#else
#ifndef __LOCK_OPT_ON__
         RTOS_mutexWait((pxIfConf->xMutex));
#endif
        _NetIfNetDrvBufferToNetPacket(&pxIfConf->dllRxBuf,
                                      &pxIfConf->dllNetPacketRx, pxIfConf);
#ifndef __LOCK_OPT_ON__
         RTOS_mutexRelease((pxIfConf->xMutex));
#endif
#endif

#if 0
        if((pxNetIfLimiter->bVlan == TRUE) || (pxNetIfLimiter->bToS == TRUE)){
          NetIfLimiter(pxNetIfLimiter,&pxWrapperState->dllNetPacketRx);
        }

        pdllNetPacket = &pxWrapperState->dllNetPacketRx;
#else
        if((pxNetIfLimiter->bVlan == TRUE) || (pxNetIfLimiter->bToS == TRUE)){
          NetIfLimiter(pxNetIfLimiter,&pxIfConf->dllNetPacketRx);
        }

        pdllNetPacket = &pxIfConf->dllNetPacketRx;
#endif /* TBD */

        DLLIST_head(pdllNetPacket);
        while((pxPacket = (NETPACKET*) DLLIST_remove(pdllNetPacket))!= NULL) {
          NETPACKET_CHECK(pxPacket);
          NETMAIN_ASSERT(((pxPacket->wOffset + pxPacket->wLength) <=
                          pxPacket->pxPayload->wSize) &&
                         (pxPacket->wLength <= NETPACKET_ETH_MAXSIZE));

          /*RS NetMutexUnlockLock(&pxWrapper->xMutex); */
          NetMutexUnlockLock(&pxWrapper->xMutex);
          SNMP(xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInFrames++);

          SNMP(xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInOctets +=
                                                         pxPacket->wLength;);

          dwPacketCnt++;

          xAccess.wOffset = pxPacket->wOffset;
          xAccess.wLength = pxPacket->wLength;
          xAccess.oPriority = pxPacket->oPriority;

          /* NETMAIN_DBGP(REPETITIVE,"NetIfProcess called on interface %d,wOffset=%d,wLength=%d\n",
                       oIfIdx,xAccess.wOffset,xAccess.wLength);*/
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_REPETITIVE))
          {
               DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,
                            "NetIfProcess called on interface ",oIfIdx,
                            ",wOffset=",xAccess.wOffset);
               DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,",wLength=",xAccess.wLength);
               DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
          }

          /* NETMAIN_DBG(XREPETITIVE,(NetPrintPayload(
            pxPacket->pxPayload->poPayload + xAccess.wOffset,xAccess.wLength))); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_DETAIL))
          {
              NetPrintPayload(pxPacket->pxPayload->poPayload + xAccess.wOffset,
                                xAccess.wLength);
          }

          /* Send the data up */
          /* No need to check for the return value: it is packet
             based, and the UL layer will take care of it */
          NETMAIN_ASSERT(pxIfState->pfnBottomLinkRxCbk != NULL);
      /* RS: unlock on exit from wrapper */
          /*RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));*/
          pxIfState->pfnBottomLinkRxCbk(pxIfState->hBottomLinkInst,
                                        pxIfState->hBottomLinkIf,
                                        pxPacket, &xAccess,
                                        (H_NETDATA)&xNetIfId);
        /* RS: lock on entry back into wrapper */
          /* RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));*/
#ifdef __INET_USE_PKT_MEMPOOL__
          pxWrapperState->netPacketPoolUsed--;
          /* printf("Release from NetPacketPool: pointer -> %x - NumUsed = %d\n", *pxPacket,
                  pxWrapperState->netPacketPoolUsed); */
          MEM_POOL_putPoolObject(&pxWrapperState->netPacketPool, (void **)(&pxPacket));
#else
          FREE(pxPacket);
#endif
        }
      }
#if 0
      else{
        /*NETMAIN_DBGP(REPETITIVE, */
      /* "NetIfProcessDrv nothing to read on interface %d\n", oIfIdx); */
      }
#endif
      break;
#endif /*#if defined(ETHERNET) || defined(PPPOE)*/
#ifdef NET_DSL
    case ATM:
      {
        DRIVERBUFFER xDriverBufferRx;
        /* Poll driver for incoming data */
        if (read(pxIfConf->iFd,(char *)&xDriverBufferRx,1) > 0) {
          NETPACKET xPacket;
          NETPACKETACCESS xAccess;

          ASSERT(xDriverBufferRx.dwLength <= NETPACKET_ATM_MAXSIZE);

          dwPacketCnt++;

          xPacket.hMarker = (H_NETDATA)0;

          SNMP(xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInFrames++);
          SNMP(xTcpipData.ifNum[1].ifInOctets += xDriverBufferRx.dwLength;);

          /* NETMAIN_DBGP(REPETITIVE,"NetIfProcess called on interface %d,wOffset=%u,wLength=%lu\n",
                       oIfIdx,xDriverBufferRx.wOffset,xDriverBufferRx.dwLength);*/
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_REPETITIVE))
          {
               DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,
                                     "NetIfProcess called on interface ",oIfIdx);

                 DEBUG_PRINT(",wOffset=");
               DEBUG_UINT(DEBUG_MOC_IPV4,xDriverBufferRx.wOffset);
                 DEBUG_PRINT(",wLength=");
               DEBUG_UINT(DEBUG_MOC_IPV4,xDriverBufferRx.dwLength);
               DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
          }

          /* NETMAIN_DBG(XREPETITIVE,(NetPrintPayload(xDriverBufferRx.poData +
                                             xDriverBufferRx.wOffset,
                                             (WORD)xDriverBufferRx.dwLength))); */

          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_DETAIL))
          {
              NetPrintPayload(xDriverBufferRx.poData + xDriverBufferRx.wOffset,
                              (WORD)xDriverBufferRx.dwLength);
          }

#ifdef LINK_AGGREGATION
        if ( trash ){
            NetFree(xDriverBufferRx.poData);
            break;
        }
#endif
          NETPAYLOAD_CREATE(&(xPacket.pxPayload),
                            NetFree,
                            &(pxWrapper->xMutex),
                            xDriverBufferRx.poData,
                            xDriverBufferRx.wSize);

          xAccess.wOffset = xDriverBufferRx.wOffset;
          xAccess.wLength = (WORD)xDriverBufferRx.dwLength;
          xAccess.oPriority = xDriverBufferRx.oPriority;/*(OCTET)LOW_PRIORITY;*/
          /* Send the data up */
          /* No need to check for the return value: it is packet
             based, and the UL layer will take care of it */
          NETMAIN_ASSERT(pxIfState->pfnBottomLinkRxCbk != NULL);
      /* RS: unlock on exit from wrapper */
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
          pxIfState->pfnBottomLinkRxCbk(pxIfState->hBottomLinkInst,
                                        pxIfState->hBottomLinkIf,
                                        &(xPacket), &(xAccess),
                                        (H_NETDATA)&xNetIfId);
        /* RS: lock on entry back into wrapper */
          RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
        }
        break;
      }

#endif /*#ifdef NET_DSL*/
    default:
      NETMAIN_ASSERT(0);
    }
  }
  return (LONG)dwPacketCnt;
}


/*
 * NetIfProcessLnk
 *  Network interface processing: link layer modules.
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Network wrapper
 *   oIfIdx                 interface index
 *
 *  Return:
 *   0
 */
LONG NetIfProcessLnk(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
  NETIFCONF *pxIfConf;

  NETMAIN_ASSERT(pxWrapper != NULL);

  pxIfConf = NETGETIFCONF(pxWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  if (pxIfConf->oFlags & IFF_PHYUP
#ifdef LINK_AGGREGATION
      && (pxIfConf->oFlags & IFF_LOGICAL)
#endif
  ) {

    /* Link module processing */
    switch(pxIfConf->oType) {

#ifdef ETHERNET
    case IFT_ETHER:
      EthConfProcess(pxIfConf,oIfIdx);

      if (pxIfConf->hDhcpClient != 0) {
        if (--pxIfConf->dwDhcpClientProcessTimer == 0) {

          BOOL bProcessClient = TRUE;

          /*
           * This process can be done every half second
           * Assume DHCPClientInstanceProcess called every 5ms !!
           */
          pxIfConf->dwDhcpClientProcessTimer = 10;

          if (pxIfConf->xEthConf.obBridge) {
            /*
             * Do not process client if the interface is bridged and
             * is not yet in the forwarding state
             */
            H_NETINSTANCE hEthInst = NETGETINST_ETH;
            ETHIFSTATE xEthState;
            xEthState.oIfIdx = oIfIdx;
            EthInstanceMsg(hEthInst,ETHMSG_GETIFSTATE,
                           (H_NETDATA)(&xEthState));
            if (xEthState.eState != BRIF_FORWARDING) {
              bProcessClient = FALSE;
            }
          }

          if (bProcessClient) {
            LONG lReturn;
        /* RS: unlock on exit from wrapper */
            RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
            lReturn = DHCPClientInstanceProcess(pxIfConf->hDhcpClient);
          /* RS: lock on entry back into wrapper */
            RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

            if (lReturn != DHCP_OK &&
                pxWrapper->pfnIfDhcpErrorCbk != NULL) {

              switch (lReturn){
              case DHCP_TIMEOUT:
                pxIfConf->oDhcpErrorFlag = IF_DHCP_TIMEOUT;
                break;
              case DHCP_LEASE_EXPIRED:
                pxIfConf->oDhcpErrorFlag = IF_DHCP_LEASE_EXPIRED;
                break;
#ifdef DHCP_CUSTOM_OPTIONS
              case DHCP_OPT_CHK_COMPLETE:
                pxIfConf->oDhcpErrorFlag = IF_DHCP_OPT_CHK_COMPLETE;
                break;
#endif /*DHCP_CUSTOM_OPTIONS */
              default:
                pxIfConf->oDhcpErrorFlag = IF_DHCP_NACK;
                break;
              }

              /* Signal that a DHCP client error has occured */
              NetIfSignalDhcpError(pxWrapper, oIfIdx);
            } else {
              pxIfConf->oDhcpErrorFlag = 0;
            }
          }
        }
      }
      break;
#endif /*#ifdef ETHERNET*/

#ifdef PPP
    case IFT_PPPOE:
      PppoEConfProcess(pxIfConf,oIfIdx);

    case IFT_PPP:
      PppConfProcess(pxIfConf,oIfIdx);
      break;
#endif /*#ifdef PPP*/
#ifdef IPOA
    case IFT_NULL:
      IpoAConfProcess(pxIfConf,oIfIdx);
      break;
#endif /*#ifdef IPOA*/
  default:
    NETMAIN_ASSERT(0);
    }
  }

  /* Check if interface is to be closed (e.g. after registered
   * callback function has returned */
  if (pxIfConf->bCloseInterface == TRUE) {
    pxIfConf->pth_tThread = 0;
    SocketLibraryMsg(SOCKETLIBMSG_CLOSEIF,(H_NETDATA)oIfIdx);
    NetMainMsg(NETMAINMSG_IFCLOSE,(H_NETDATA)oIfIdx);
  }

  return 0;
}

void _NetIfNetDrvBufferToNetPacket(DLLIST *pdllNetDrvBuf,DLLIST *pdllNetPacket, NETIFCONF *pxIfConf)
{
  NETPACKET      *pxNetPacket;
  NET_DRV_BUFFER *pxNetDrvBuf = NULL;
  NETWRAPPER *pxWrapper = NETGETWRAPPER;
/* #ifdef __INET_USE_MEMPOOL__ */
  NETWRAPPERSTATE *pxWrapperState;
  MSTATUS status;
  DWORD dwPacketCnt = 0;
/* #endif */

  ASSERT((pdllNetDrvBuf != NULL) &&
         (pdllNetPacket != NULL) &&
         (DLLIST_count_inline(pdllNetPacket) == 0));

#ifdef __LOCK_QUEUE__
  DLLIST_head(pdllNetDrvBuf);
  while ((pxNetDrvBuf = DLLIST_remove(pdllNetDrvBuf)) != NULL)
#else
  while ( (OK == (status = CIRCQ_deq (pxIfConf->pRxCq, &pxNetDrvBuf)) ) &&
           (pxNetDrvBuf) )
          /* Atul - Adding this check because De-queue sometimes returns a NULL
           * pointer even though there is a valid entry in the cicular Q.
           * Need to do some more due diligence as to why this happens.
           */
#endif
  {
   dwPacketCnt++;
#ifdef __INET_USE_PKT_MEMPOOL__
   pxWrapperState = NETGETWRAPPERSTATE(pxWrapper);
   if( OK > (status =
             MEM_POOL_getPoolObject(&pxWrapperState->netPacketPool, (void **)&pxNetPacket)))
   {
      DEBUG_ERROR(DEBUG_MOC_IPV4,
            "Error:_NetIfNetDrvBufferToNetPacket - Unable to allocate Packet :", status);
      goto err_exit;
   }
   pxWrapperState->netPacketPoolUsed++;
   /* printf("_NetIfNetDrvBufferToNetPacket- Alloc from NetPacketPool: pointer -> %x - NumUsed = %d\n", *pxNetPacket,
           pxWrapperState->netPacketPoolUsed); */

#else
    pxNetPacket = (NETPACKET*)MALLOC(sizeof(NETPACKET));
#endif /* __INET_USE_MEMPOOL__ */

    ASSERT(pxNetPacket != NULL);
    MOC_MEMSET((ubyte *)pxNetPacket, 0, sizeof(NETPACKET));
    pxNetPacket->wLength = pxNetDrvBuf->dwLength - pxNetDrvBuf->wOffset;

    pxNetPacket->wOffset = pxNetDrvBuf->wOffset;

    NETPAYLOAD_CREATE(&pxNetPacket->pxPayload,
                      NetFree,
                      &pxWrapper->xMutex,
                      pxNetDrvBuf->poData,
                      pxNetDrvBuf->wSize);

    if(NULL == pxNetPacket->pxPayload)
    {
      LONG lRv = NETERR_MEM;
      DEBUG_ERROR(DEBUG_MOC_IPV4,
            "Error:_NetIfNetDrvBufferToNetPacket - Unable to allocate Packet :", lRv);
      NetFree(pxNetDrvBuf->poData);
#ifdef __INET_USE_PKT_MEMPOOL__
      pxWrapperState->netPacketPoolUsed--;
      /* printf("_NetIfNetDrvBufferToNetPacket- Release from NetPacketPool: pointer -> %x - NumUsed = %d\n", *pxNetPacket,
           pxWrapperState->netPacketPoolUsed); */
      MEM_POOL_putPoolObject(&pxWrapperState->netPacketPool, (void **)&pxNetPacket);
#else
      FREE(pxNetPacket);
#endif
      goto err_exit;
    }

    DLLIST_append(pdllNetPacket,(void*)pxNetPacket);
    RTOS_mutexRelease((pxIfConf->xMutex));
    RTOS_mutexWait((pxIfConf->xMutex));

err_exit:
#ifdef __INET_USE_NET_BUF_MEMPOOL__
    (pxWrapperState->netDrvBufPoolUsed)--;
    /* printf("Release from NetDrvBufPool: pointer -> %x - NumUsed = %d\n", *pxNetDrvBuf,
           pxWrapperState->netDrvBufPoolUsed)); */
    MEM_POOL_putPoolObject(&pxWrapperState->netDrvBufPool, (void **)(&pxNetDrvBuf));
#else
    FREE(pxNetDrvBuf);
#endif
    if (  10 < dwPacketCnt )
       break;
  }
}

void _NetIfNetDrvBufferTrash(DLLIST *pdllNetDrvBuf,NETIFCONF *pxIfConf)
{
  NET_DRV_BUFFER *pxNetDrvBuf;
  MSTATUS status = OK;
#ifdef __INET_USE_NET_BUF_MEMPOOL__
  NETWRAPPERSTATE *pxWrapperState;
  NETWRAPPER *pxWrapper = NETGETWRAPPER;
#endif

  ASSERT(pdllNetDrvBuf != NULL);

#ifdef __LOCK_QUEUE__
  DLLIST_head(pdllNetDrvBuf);
  while ((pxNetDrvBuf = DLLIST_remove(pdllNetDrvBuf)) != NULL)
#else
  while ( (OK == (status = CIRCQ_deq (pxIfConf->pRxCq, &pxNetDrvBuf)) ) &&
           (pxNetDrvBuf) )
          /* Atul - Adding this check because De-queue sometimes returns a NULL
           * pointer even though there is a valid entry in the cicular Q.
           * Need to do some more due diligence as to why this happens.
           */
#endif
  {
    NetFree(pxNetDrvBuf->poData);
#ifdef __INET_USE_NET_BUF_MEMPOOL__
   pxWrapperState = NETGETWRAPPERSTATE(pxWrapper);
    pxWrapperState->netDrvBufPoolUsed--;
    /* printf("Release from NetDrvBufPool: pointer -> %x - NumUsed = %d\n", *pxNetDrvBuf,
           pxWrapperState->netDrvBufPoolUsed); */
    RTOS_mutexWait((pxIfConf->xMutex));
    MEM_POOL_putPoolObject(&pxWrapperState->netDrvBufPool, (void **)(&pxNetDrvBuf));
    RTOS_mutexRelease((pxIfConf->xMutex));
#else
    FREE(pxNetDrvBuf);
#endif
    /* Yield Every time so that the others can queue the packets too */
#ifdef __LOCK_QUEUE__
    RTOS_mutexRelease((pxIfConf->xMutex));
    RTOS_mutexWait((pxIfConf->xMutex));
#endif
  }
}

void NetIfProcessNetDrvBuffer(NET_DRV_BUFFER *pxNetDrvBuf, OCTET oIfIdx)
{
  NETPACKET      *pxNetPacket;
  NETPACKET      *pxPacket;
  NETWRAPPER *pxWrapper = NETGETWRAPPER;
  NETWRAPPERSTATE *pxWrapperState;
  NETIFCONF *pxIfConf;
  MSTATUS status;
  DWORD dwPacketCnt = 0;
  NETIFSTATE *pxIfState;
  NETIFID xNetIfId;
  NETIFLIMITER *pxNetIfLimiter;
  NETPACKETACCESS xAccess;
#ifdef LINK_AGGREGATION
  OCTET trash=0;
#endif

  NETMAIN_ASSERT(pxWrapper != NULL);

  pxWrapperState = NETGETWRAPPERSTATE(pxWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL);

  pxNetIfLimiter = NETGETLIMITER(pxWrapper);
  NETMAIN_ASSERT(pxNetIfLimiter != NULL);

  pxIfConf = NETGETIFCONF(pxWrapper,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf); /* RS keep the state of logical itself*/

  xNetIfId.oIfIdx = oIfIdx;
  xNetIfId.wVlan  = NETVLAN_ANY;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
  {
   dwPacketCnt++;
#ifdef __INET_USE_PKT_MEMPOOL__
   pxWrapperState = NETGETWRAPPERSTATE(pxWrapper);
   if( OK > (status =
             MEM_POOL_getPoolObject(&pxWrapperState->netPacketPool, (void **)&pxNetPacket)))
   {
      DEBUG_ERROR(DEBUG_MOC_IPV4,
            "Error:_NetIfNetDrvBufferToNetPacket - Unable to allocate Packet :", status);
      goto err_exit;
   }
   pxWrapperState->netPacketPoolUsed++;
   /* printf("_NetIfNetDrvBufferToNetPacket- Alloc from NetPacketPool: pointer -> %x - NumUsed = %d\n", *pxNetPacket,
           pxWrapperState->netPacketPoolUsed); */

#else
    pxNetPacket = (NETPACKET*)MALLOC(sizeof(NETPACKET));
#endif /* __INET_USE_MEMPOOL__ */

    ASSERT(pxNetPacket != NULL);
    /*MOC_MEMSET((ubyte *)pxNetPacket, 0, sizeof(NETPACKET));*/
    pxNetPacket->wLength = pxNetDrvBuf->dwLength - pxNetDrvBuf->wOffset;

    pxNetPacket->wOffset = pxNetDrvBuf->wOffset;

    NETPAYLOAD_CREATE(&pxNetPacket->pxPayload,
                      NetFree,
                      &pxWrapper->xMutex,
                      pxNetDrvBuf->poData,
                      pxNetDrvBuf->wSize);

    if(NULL == pxNetPacket->pxPayload)
    {
      LONG lRv = NETERR_MEM;
      DEBUG_ERROR(DEBUG_MOC_IPV4,
            "Error:_NetIfNetDrvBufferToNetPacket - Unable to allocate Packet :", lRv);
      NetFree(pxNetDrvBuf->poData);
#ifdef __INET_USE_PKT_MEMPOOL__
      pxWrapperState->netPacketPoolUsed--;
      /* printf("_NetIfNetDrvBufferToNetPacket- Release from NetPacketPool: pointer -> %x - NumUsed = %d\n", *pxNetPacket,
           pxWrapperState->netPacketPoolUsed); */
      MEM_POOL_putPoolObject(&pxWrapperState->netPacketPool, (void **)&pxNetPacket);
#else
      FREE(pxNetPacket);
#endif
      goto err_exit;
    }

  }

  {
          pxPacket = pxNetPacket;
          NETPACKET_CHECK(pxPacket);
          NETMAIN_ASSERT(((pxPacket->wOffset + pxPacket->wLength) <=
                          pxPacket->pxPayload->wSize) &&
                         (pxPacket->wLength <= NETPACKET_ETH_MAXSIZE));

          xAccess.wOffset = pxPacket->wOffset;
          xAccess.wLength = pxPacket->wLength;
          xAccess.oPriority = pxPacket->oPriority;


          /* NETMAIN_DBG(XREPETITIVE,(NetPrintPayload(
            pxPacket->pxPayload->poPayload + xAccess.wOffset,xAccess.wLength))); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_DETAIL))
          {
              NetPrintPayload(pxPacket->pxPayload->poPayload + xAccess.wOffset,
                                xAccess.wLength);
          }

          SNMP(xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInFrames++);

          SNMP(xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInOctets +=
                                                         pxPacket->wLength;);
          /* Send the data up */
          /* No need to check for the return value: it is packet
             based, and the UL layer will take care of it */
          NETMAIN_ASSERT(pxIfState->pfnBottomLinkRxCbk != NULL);
      /* RS: unlock on exit from wrapper */
          pxIfState->pfnBottomLinkRxCbk(pxIfState->hBottomLinkInst,
                                        pxIfState->hBottomLinkIf,
                                        pxPacket, &xAccess,
                                        (H_NETDATA)&xNetIfId);
#ifdef __INET_USE_PKT_MEMPOOL__
          pxWrapperState->netPacketPoolUsed--;
          /* printf("Release from NetPacketPool: pointer -> %x - NumUsed = %d\n", *pxPacket,
                  pxWrapperState->netPacketPoolUsed); */
          MEM_POOL_putPoolObject(&pxWrapperState->netPacketPool, (void **)(&pxPacket));
#else
          FREE(pxPacket);
#endif
        }

err_exit:
#ifdef __INET_USE_NET_BUF_MEMPOOL__
    (pxWrapperState->netDrvBufPoolUsed)--;
    /* printf("Release from NetDrvBufPool: pointer -> %x - NumUsed = %d\n", *pxNetDrvBuf,
           --(pxWrapperState->netDrvBufPoolUsed)); */
    MEM_POOL_putPoolObject(&pxWrapperState->netDrvBufPool, (void **)(&pxNetDrvBuf));
#else
    FREE(pxNetDrvBuf);
#endif
   RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
}
