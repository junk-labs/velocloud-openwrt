/*
 * linkconf.c
 *
 * Gathers all the common link configuration code
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netconfig.h"
#include "linkconf.h"
#include "netmain.h"

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#define NETCONFLIBNUMMAX 20

void LibConfSetOffsetAndTrailer(NETCONF *pxNetConf,WORD wOffset,WORD wTrailer)
{
  NETCONFINSTANCE *pxNetConfInstance;
  NETCONFLIBRARYTEMPLATE **ppxLibTemplate = NULL;
  NETCONFLIBRARYTEMPLATE *pxLibTemplate;
  DWORD dw;

  NETMAIN_ASSERT((pxNetConf != NULL)&&
                 (pxNetConf->eState != NETCONFSTATE_OPENED) &&
                 (pxNetConf->ppxLibTemplate != NULL) &&
                 (pxNetConf->dwLibNum < NETCONFLIBNUMMAX));

  ppxLibTemplate    = pxNetConf->ppxLibTemplate;
  pxNetConfInstance = pxNetConf->pxNetConfInstance;

  for (dw = 0; dw < pxNetConf->dwLibNum; dw++) {
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;
    H_NETINSTANCE           hInst;
    PFN_NETINSTANCESET      pfnInstanceSet;

    pxLibTemplate  = ppxLibTemplate[dw];
    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;

    NETMAIN_ASSERT((pxInstTemplate != NULL) &&
                   (&pxNetConfInstance[dw] != NULL));

    hInst          = pxNetConfInstance[dw].hInst;
    pfnInstanceSet = pxLibTemplate->pfnInstanceSet;

    if(pfnInstanceSet != NULL){
      pfnInstanceSet(hInst,NETOPTION_OFFSET,(H_NETDATA)wOffset);
      pfnInstanceSet(hInst,NETOPTION_TRAILER,(H_NETDATA)wTrailer);
    }

  }
}




