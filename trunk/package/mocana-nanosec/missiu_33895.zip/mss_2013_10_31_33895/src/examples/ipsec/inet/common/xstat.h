/*
 * xstat.h
 *
 * macros to to keep extended stats
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __XSTAT_H__
#define __XSTAT_H__



/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

#include "NNstyle.h"
#include "sahist.h"


/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

#if 0
#  define XSTAT_NO_HIST
#endif


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/

#define ADD_DW2DD(dw, dd) do {                        \
      register DWORD dwAddend = (dd).dwLo;                \
      register DWORD dwSum = (dw);                    \
      dwSum += dwAddend;                        \
      if (dwSum < dwAddend)                        \
        (dd).dwHi++;                        \
      (dd).dwLo = dwSum;                        \
    } while (0)

#ifdef XSTAT_NO_CNT
#define XSTAT_DO_CNT(x)
#define XSTAT_REPORT_CNT(x)
#else
#define XSTAT_DO_CNT(x)    (x).dwCnt++
#define XSTAT_REPORT_CNT(x)                        \
      printf("#instances = 0x%08lX\n", (x).dwCnt)
#endif

#ifdef XSTAT_NO_MAX
#define XSTAT_DO_MAX(x, v)
#else
#define XSTAT_DO_MAX(x, v)                        \
  if ((v) > (x).dwMax)                            \
    (x).dwMax = (v)
#endif

#ifdef XSTAT_NO_MIN
#define XSTAT_DO_MIN(x, v)
#else
#define XSTAT_DO_MIN(x, v)                        \
  if (((v) < (x).dwMin) || (0 == (x).dwCnt))                \
    (x).dwMin = (v)
#endif

#if defined(XSTAT_DO_MIN) && defined(XSTAT_DO_MAX)
#  define XSTAT_REPORT_MINMAX(x)                    \
    printf("instance min = 0x%08lX, max = 0x%08lX\n", (x).dwMin, (x).dwMax)
#elif defined(XSTAT_DO_MIN)
#  define XSTAT_REPORT_MINMAX(x)                    \
    printf("instance min = 0x%08lX\n", (x).dwMin)
#elif defined(XSTAT_DO_MAX)
#  define XSTAT_REPORT_MINMAX(x)                    \
    printf("instance max = 0x%08lX\n", (x).dwMax)
#else
#  define XSTAT_REPORT_MINMAX(x)
#endif

#ifdef XSTAT_NO_TOTAL
#define XSTAT_DO_TOTAL(x, v)
#define XSTAT_REPORT_TOTAL(x)
#else
#define XSTAT_DO_TOTAL(x, v)    ADD_DW2DD((v), (x).ddTotal)
#define XSTAT_REPORT_TOTAL(x)                        \
  printf("total = 0x%08lX 0x%08lX\n", (x).ddTotal.dwHi, (x).ddTotal.dwLo);
#endif

#ifdef XSTAT_NO_HIST
#define XSTAT_DO_HIST8(x, v)
#define XSTAT_REPORT_HIST(x)
#define XSTAT_CLEAR_HIST(x)
#else
#define XSTAT_DO_HIST8(x, v)    SaHist8(&((x).xHist), (v))
#define XSTAT_REPORT_HIST(x)    SaHist8Report(&((x).xHist))
#define XSTAT_CLEAR_HIST(x)    SaHist8Clear(&((x).xHist))
#endif

#define XSTAT_RECORD(x, v) do {                        \
  XSTAT_DO_MAX(x, v);                            \
  XSTAT_DO_MIN(x, v);                            \
  XSTAT_DO_CNT(x);                            \
  XSTAT_DO_TOTAL(x, v);                            \
  XSTAT_DO_HIST8(x, v);                            \
} while (0)

#define XSTAT_REPORT(x) do {                        \
  printf("\nXSTAT " #x " at 0x%08lX:\n", (long unsigned) &x);        \
  XSTAT_REPORT_CNT(x);                            \
  XSTAT_REPORT_MINMAX(x);                        \
  XSTAT_REPORT_TOTAL(x);                        \
  XSTAT_REPORT_HIST(x);                            \
} while (0)

#define XSTAT_CLEAR(x) do {                        \
  XSTAT_CLEAR_HIST(x);                            \
  (x).dwCnt = 0;                            \
  (x).dwMax = 0;                            \
  (x).dwMin = 0;                            \
  (x).ddTotal.dwHi = 0;                            \
  (x).ddTotal.dwLo = 0;                            \
} while (0)


/********************************************************************
 *
 * Typedefs
 *
 ********************************************************************/

typedef struct {
  DWORD dwHi;        /* high order 32 bits */
  DWORD dwLo;        /* low order 32 bits */
} DDWORD;


typedef struct {
  DWORD dwCnt;            /* # times */
  DWORD dwMin;            /* minimum value */
  DWORD dwMax;            /* maximum value */
  DDWORD ddTotal;        /* total */
  SA_HIST8 xHist;        /* histogram */
} XSTAT;


/********************************************************************
 *
 * Functional API
 *
 ********************************************************************/

/* none */


#endif    /* __XSTAT_H__ */
