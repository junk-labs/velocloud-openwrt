/*
 * natcfgapi.h
 *
 * NAT configuration structures for use with socket ioctl calls
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NATCFG_H_
#define _NATCFG_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * Flags used in the port forwarding entries.
 */
#define    NAT_PORT_FORWARD_PROT_TCP    (1 << 0x0)
#define    NAT_PORT_FORWARD_PROT_UDP    (1 << 0x1)
#define    NAT_PORT_FORWARD_PROT_BOTH    (NAT_PORT_FORWARD_PROT_TCP | NAT_PORT_FORWARD_PROT_UDP)
#define NAT_PORT_FORWARD_DYNAMIC        (0x10)

/*
 * Number of port forwarding settings supported.
 */
#define NAT_PORT_FORWARD_LAN_SIZE       24
#define NAT_PORT_FORWARD_LAN_WEB_SIZE   8
#define NAT_PORT_FORWARD_CPE_SIZE       6
#define NAT_PORT_BLOCK_CPE_SIZE         6


/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/
/* Port Forwarding to LAN configuration */
typedef struct nat_portfwd_lan {
  DWORD dwIndex;        /* entry index */
  BOOL  bNullifyEntry;  /* should be set to nullify an entry */
  WORD  wPortBeg;       /* start port number of the range to be forwarded, inclusive */
  WORD  wPortEnd;       /* end port number of the range to be forwarded, inclusive */
  WORD  wPortTrans;     /* WAN side translated port number */
  WORD  wFlags;         /* identifies which protocol(s) will be forwarded */
  DWORD dwIp;           /* LAN IP address to which the packets should be forwarded */
} NATCFG_PORTFWDLAN;

/* Port Forwarding WAN to CPE or Port Blocking LAN to CPE configuration */
typedef struct nat_ports2cpe {
  WORD wPortBeg;        /* start port number of the range to be forwarded/blocked, inclusive */
  WORD wPortEnd;        /* end port number of the range to be forwarded/blocked, inclusive */
  WORD wFlags;          /* identifies which protocol(s) will be forwarded/blocked */
} NATCFG_PORTS2CPE;

#endif
