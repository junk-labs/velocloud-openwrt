/*
 * ipcp_dbg.h
 *
 * IPCP debugging macro
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _IPCP_DBG_H_
#define _IPCP_DBG_H_

#ifndef NDEBUG

  #ifdef NETDBG_HI
    #ifndef IPCPDBG_HI
      #define IPCPDBG_HI
    #endif
  #endif

#else

  #ifdef IPCPDBG_HI
    #undef IPCPDBG_HI
  #endif

#endif

#include "netdbg.h"


/*
 * Constants
 */
#define IPCP_MAGIC_COOKIE 0x70707063 /*"ipcp" = 0x69706370*/


/*
 * Debug macros
 */
/*#ifdef IPCPDBG_HI*/
#if defined(IPCPDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define IPCP_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == IPCP_MAGIC_COOKIE));

  #define IPCP_SET_COOKIE(x) (x)->dwMagicCookie = IPCP_MAGIC_COOKIE
  #define IPCP_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define IPCP_DBGP(level, fmt, args...) do { \
    if (level <= g_dwIpCpDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define IPCP_DBG(level, x) do {  \
    if (level <= g_dwIpCpDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define IPCP_DBG_VAR(x)  x
#else
  #define IPCP_CHECK_STATE(x)
  #define IPCP_SET_COOKIE(x)
  #define IPCP_UNSET_COOKIE(x)
  #define IPCP_DBGP(level, fmt, args...)
  #define IPCP_DBG(level, x)
  #define IPCP_DBG_VAR(x)
#endif

IPCP_DBG_VAR(MOC_EXTERN DWORD g_dwIpCpDebugLevel);

/*
 * Debug levels
 */
#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /*#ifndef _IPCP_DBG_H_*/
