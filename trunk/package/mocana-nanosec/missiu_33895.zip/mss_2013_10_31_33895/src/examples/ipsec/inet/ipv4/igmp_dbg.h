/*
 * igmp_dbg.h
 *
 * IGMP module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IGMP_DBG_H_
#define _IGMP_DBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef IGMPDBG_HI
   #define IGMPDBG_HI
  #endif
 #endif

#else
 #ifdef IGMPDBG_HI
  #undef IGMPDBG_HI
 #endif
#endif

#include "netdbg.h"

#define IGMP_MAGIC_COOKIE 0x69676d70 /* "igmp" = 0x69676d70 */

/*#ifdef IGMPDBG_HI*/
#if defined(IGMPDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define IGMP_CHECK_STATE(x) \
            ASSERT((x) && ((x)->dwMagicCookie == IGMP_MAGIC_COOKIE));

  #define IGMP_SET_COOKIE(x) (x)->dwMagicCookie = IGMP_MAGIC_COOKIE
  #define IGMP_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define IGMP_DBGP(level, fmt, args...)    do {    \
    if (level <= g_dwIgmpDebugLevel) {        \
      printf(fmt, ##args);                \
    }                            \
  } while (0)

  #define IGMP_DBG(level, x)    do {        \
    if (level <= g_dwIgmpDebugLevel) {        \
      x;                        \
    }                            \
  } while (0)

  #define IGMP_DBG_VAR(x)  x

#else
  #define IGMP_CHECK_STATE(x)
  #define IGMP_SET_COOKIE(x)
  #define IGMP_UNSET_COOKIE(x)
#if defined (__RTOS_VXWORKS__)
  #define IGMP_DBGP
#else
  #define IGMP_DBGP(level, fmt, args...)
#endif
  #define IGMP_DBG(level, x)
  #define IGMP_DBG_VAR(x)
#endif

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3
#define XREPETITIVE 4
#endif /* #ifndef _IGMP_DBG_H_ */
