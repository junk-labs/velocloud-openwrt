/*
 * arp_cli.h
 *
 * Implements the CLI callbacks for ARP
 *
 * Copyright Mocana Corp 2007. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ARP_CLI_H_
#define _ARP_CLI_H_

/*
 * ArpCliShow
 * Call back for showing entries within the arp table.
 * command : show arp all
 * Input Parameters:
 * cmdRx : command supported by arp, right now it is "all"
 * uSbuf : out parameter, the result is filled within the allocated memory, as a string.
 * uSbufLen : out parameter, the number of bytes that are written within the memory pointed by "uSbuf"
 * Return Values:
 * 0 : indicates success.
 * NOTE: please see route_table_cli.h/ .c for improvements.
 */
ubyte4 ArpCliShow(ubyte *cmdRx, ubyte *sbuf, ubyte4 *sbuflen);

/*
 * ArpCliConfig
 * Call back for configuring static entries within the arp table.
 * Right now function " not supported "
 */
ubyte4 ArpCliConfig(ubyte *cmdRx);

#endif
