/*
 * Eth.c
 *
 * Implementation of the ethernet module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "eth_flavor.h"
#include "../include/socket_inet.h"
#include "../include/socket.h" /* NNOS ntohx, htonx defs */
#include "../include/in.h" /* Linux ntohx, htonx defs */
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "ethernet.h"
#include "ethdbg.h"
#include "ethdefs.h"
#include "netsnmp.h"
#include "snmp_tcpip_data.h"

/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/

ETH_DBG_VAR(DWORD g_dwEthDebugLevel = 1);


CHAR *EthProtoToString(WORD wProtocol);


/*****************************************************************************
 *
 * Constants
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/


/*****************************************************************************
 *
 * Local Functions
 *
 *****************************************************************************/

/* Note: this function does not assume any particular memory alignment */
static void _EthHeaderAdd(H_NETINSTANCE hEth,
                          NETPACKET *pxPacket,
                          NETPACKETACCESS *pxAccess,
                          ETHID *pxEthId,
                          WORD wProtocol)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  OCTET *poDestAddr = (OCTET *)pxEthId->aoAddr;
  NETPAYLOAD *pxPayload;
  OCTET *poTemp;

  ETH_ASSERT((pxPacket != NULL) &&
             (pxAccess != NULL) &&
             (pxAccess->wOffset >= (WORD)ETHHEADER_LEN));

  ETH_ASSERT(poDestAddr != NULL);

  pxPayload = pxPacket->pxPayload;
  ETH_ASSERT(pxPayload != NULL);

  poTemp = pxPayload->poPayload + pxAccess->wOffset;

  pxAccess->wOffset -= ( (WORD)ETHHEADER_LEN);
  pxAccess->wLength += ( (WORD)ETHHEADER_LEN);

  /* Add the protocol */
  poTemp -= ETHTYPE_LEN;
  wProtocol = htons(wProtocol);
  MOC_MEMCPY((ubyte *)poTemp, (ubyte *)&wProtocol, (ubyte4)ETHTYPE_LEN);

  /* Check for VLAN */
  if (pxEthId->wVlan != NETVLAN_DEFAULT ||
      pxEth->wLlDefaultVlan != NETVLAN_DEFAULT) {
    WORD wTemp;
    ASSERT(pxAccess->wOffset >= (WORD)(ETHVLAN_LEN));

    /* Copy in the VLAN id */
    if (pxEthId->wVlan == NETVLAN_DEFAULT) {
      wTemp = htons(pxEth->wLlDefaultVlan);
    } else {
      wTemp = htons(pxEthId->wVlan);
    }
    poTemp -= sizeof(WORD);
    MOC_MEMCPY((ubyte *)poTemp,(ubyte *) &wTemp, sizeof(WORD));

    /* Copy in the VLAN type */
    wTemp = htons((WORD)ETHVLAN_TYPE);
    poTemp -= ETHTYPE_LEN;
    MOC_MEMCPY((ubyte *)poTemp,(ubyte *) &wTemp, (ubyte4)ETHTYPE_LEN);

    pxAccess->wOffset -= ETHVLAN_LEN;
    pxAccess->wLength += ETHVLAN_LEN;
  }

  /* Add the source address */
  poTemp -= ETHADDRESS_LEN;
  MOC_MEMCPY((ubyte *)poTemp,
                (ubyte *)pxEth->aaoIfEthAddr[pxEthId->oIfIdx],
                (ubyte4)ETHADDRESS_LEN);

  /* Add the destination address */
  poTemp -= ETHADDRESS_LEN;
  MOC_MEMCPY((ubyte *)poTemp,(ubyte *) poDestAddr, (ubyte4)ETHADDRESS_LEN);

}

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * EthInstanceCreate
 *  Creates a ETH Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */

H_NETINSTANCE EthInstanceCreate(void)
{
  ETHSTATE *pxEth;

  pxEth = (ETHSTATE *)MALLOC(sizeof(ETHSTATE));
  ASSERT(pxEth != NULL);
  MOC_MEMSET((ubyte *)pxEth, 0, sizeof(ETHSTATE));

  ETH_SET_COOKIE(pxEth);

  return (H_NETINSTANCE)pxEth;
}
/*
 * EthInstanceDestroy
 *  Destroy a ETH Instance
 *
 *  Args:
 *   hEth                       ETH instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceDestroy(H_NETINSTANCE hEth)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  INT iDx;
  ETH_UL *pxUl;

  ETH_CHECK_STATE(pxEth);

  /* Destroy all the remaining UL interfaces */
  for (iDx = 0; iDx < ETH_MAXULIF; iDx ++) {
    pxUl = pxEth->apxUl[iDx];
    if (pxUl != NULL) {
      FREE(pxUl);
    }
  }

  if (pxEth->pwSpecificVlan != NULL) {
    FREE(pxEth->pwSpecificVlan);
  }

  ETH_UNSET_COOKIE(pxEth);
  FREE(pxEth);

  return 0;
}


/*
 * EthInstanceSet
 *  Set a ETH Instance Option
 *
 *  Args:
 *   hEth                       ETH instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceSet(H_NETINSTANCE hEth,OCTET oOption,
                    H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  LONG lReturn = NETERR_NOERR;

  ETH_CHECK_STATE(pxEth);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ETH_DBGP(REPETITIVE, "EthInstanceSet: Option: %x\n", oOption); */
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "EthInstanceSet - Option : 0x", oOption);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oOption) {

  case ETHOPTION_MACADDR:
    {
      ETHID *pxEthId = (ETHID*)hData;
      ETH_ASSERT(pxEthId->oIfIdx < ETH_MAXNUM_IF);

      MOC_MEMCPY((ubyte *)pxEth->aaoIfEthAddr[pxEthId->oIfIdx],
                    (ubyte *)pxEthId->aoAddr,
                    ETHADDRESS_LEN);
    }
    break;

#ifndef NDEBUG
  case NETOPTION_FREE:
  case NETOPTION_MALLOC:
  case NETOPTION_PAYLOADMUTEX:
  case NETOPTION_NETCBK:
  case NETOPTION_OFFSET:
  case NETOPTION_TRAILER:
  case ETHOPTION_IFTOLLMAP:
    break;
  default:
    lReturn = NETERR_UNKNOWN;
    ETH_ASSERT(0);
#endif
  }

  return lReturn;
}


/*
 * EthInstanceMsg
 *  Send a msg to a ETH instance
 *
 *  Args:
 *   hEth                       ETH instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceMsg(H_NETINSTANCE hEth,OCTET oMsg,
                    H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  LONG lReturn = NETERR_NOERR;
  OCTET oIdx;

  ETH_CHECK_STATE(pxEth);



  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_REPETITIVE))
  {
    /*(ETH_DBGP(REPETITIVE, "EthInstanceMsg: oMsg: %x\n", oMsg);*/
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "EthInstanceMsg - oMsg : 0x", oMsg);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oMsg) {
  case ETHMSG_LOCALLOOPBACK:
    pxEth->obLocalLoopback = (OCTET)hData;
    break;

  case ETHMSG_SETLLDEFAULTVLAN:
    {
      ETHID *pxEthId = (ETHID *)hData;
      ASSERT(pxEthId->oIfIdx < (OCTET) ETH_MAXNUM_IF);

      pxEth->wLlDefaultVlan = pxEthId->wVlan;
      /*JJ GOt to figure this one out why its being reset to 0 */
      pxEth->wLlDefaultVlan = NETVLAN_DEFAULT;

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_NORMAL))
      {
        /*ETH_DBGP(NORMAL,"ETHMSG_SETLLDEFAULTVLAN: oIfIdx=%d wVlan=0x%04x\n",
               pxEthId->oIfIdx, pxEthId->wVlan);*/
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "ETHMSG_SETLLDEFAULTVLAN: oIfIdx= ",pxEthId->oIfIdx );
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, " wVlan=: 0x",pxEthId->wVlan );
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }

    }
    break;

  case ETHMSG_ADDSPECIFICVLAN:
      /* Find an empty slot and save the Vlan in it */
    for (oIdx = 0; oIdx < pxEth->oSpecificVlanNumber; oIdx++) {
      if (pxEth->pwSpecificVlan[oIdx] == NETVLAN_DEFAULT ||
          pxEth->pwSpecificVlan[oIdx] == (WORD)hData) {
        pxEth->pwSpecificVlan[oIdx] = (WORD)hData;
        break;
      }
    }
    /* If no slot found - realloc and save Vlan in new slot */
    if (oIdx >= pxEth->oSpecificVlanNumber) {

      {
      WORD *pwTempSpecificVlan = NULL;

      pwTempSpecificVlan = (WORD *)MALLOC((pxEth->oSpecificVlanNumber+1)* sizeof(WORD));
      ASSERT(pwTempSpecificVlan);
      MOC_MEMCPY((ubyte *)pwTempSpecificVlan, (ubyte *)(pxEth->pwSpecificVlan),
            pxEth->oSpecificVlanNumber * sizeof(WORD));

      pxEth->pwSpecificVlan = (WORD *)pwTempSpecificVlan;
      pxEth->oSpecificVlanNumber++;

      }
      if (pxEth->pwSpecificVlan) {
        pxEth->pwSpecificVlan[pxEth->oSpecificVlanNumber-1] = (WORD)hData;
      } else {
        lReturn = NETERR_MEM;
      }
    }
    break;

  case ETHMSG_REMOVESPECIFICVLAN:
    ETH_ASSERT(pxEth->pwSpecificVlan);
    /* Find the Vlan and set to empty */
    for (oIdx = 0; oIdx < pxEth->oSpecificVlanNumber; oIdx++) {
      if (pxEth->pwSpecificVlan[oIdx] == (WORD)hData) {
        pxEth->pwSpecificVlan[oIdx] = NETVLAN_DEFAULT;
        break;
      }
    }
    /* If not found - return error */
    if (oIdx >= pxEth->oSpecificVlanNumber) {
      lReturn = NETERR_BADVALUE;
    }
    break;

  case ETHMSG_SETIFBITRATE:
    /* RS: ASSERTION failing if this empty case stmt is not here */
    break;

#ifndef NDEBUG
  case NETMSG_OPEN :
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    break;

  default:
    ETH_ASSERT(0);
#endif
  }

  return lReturn;
}

/*
 * EthInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer : UDP,TCP,ICMP,IGMP, etc
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hEth                       ETH instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE EthInstanceULInterfaceCreate(H_NETINSTANCE hEth)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  INT iDx;

  ETH_CHECK_STATE(pxEth);

  for(iDx = 0; iDx < ETH_MAXULIF; iDx++){
    if(pxEth->apxUl[iDx] == NULL){
      break;
    }
  }

  ASSERT(iDx < ETH_MAXULIF);

  pxEth->apxUl[iDx] = (ETH_UL*)MALLOC(sizeof(ETH_UL));
  MOC_MEMSET ((ubyte *)(pxEth->apxUl[iDx]), 0, sizeof(ETH_UL));
  pxEth->oUlNumber++;
  ASSERT(pxEth->oUlNumber <= ETH_MAXULIF);
  pxEth->apxUl[iDx]->oIfIdx = NETIFIDX_ANY;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_NORMAL))
  {
    /*ETH_DBGP(NORMAL,"EthULIfCreate:hEth=%d,hLlIf=%d\n",(int)hEth,iDx);  */
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "EthULIfCreate:hEth= ", (int)hEth);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", hLlIf= ",iDx );
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  return (H_NETINTERFACE) (iDx);

}

/*
 * EthInstanceULInterfaceDestroy
 *  Destroy a ETH UL interface
 *
 *  Args:
 *   hEth                       ETH instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG EthInstanceULInterfaceDestroy(H_NETINSTANCE hEth,
                                   H_NETINTERFACE hInterface)
{
  ETHSTATE  *pxEth = (ETHSTATE *)hEth;
  ETH_UL *pxUl;
  INT iDx = (int)hInterface;
  ETH_CHECK_STATE(pxEth);


  ASSERT((pxEth->oUlNumber > 0) &&
         (iDx < ETH_MAXULIF) &&
         (iDx >= 0));


  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_NORMAL))
  {
    /*ETH_DBGP(NORMAL,"EthULIfDestroy:hEth=%d,hLlIf=%d\n",(int)hEth,(int)iDx);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "EthULIfDestroy:hEth ", (int)hEth);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", hLlIf= ",iDx );
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  pxEth->oUlNumber--;

  pxUl = pxEth->apxUl[iDx];
  ASSERT(pxUl != NULL);
  FREE(pxUl);
  pxEth->apxUl[iDx] = NULL;

  return 0;
}

/*
 * EthInstanceULInterfaceIoctl
 *  Eth UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and ip.h
 *  for precisions
 *
 *  Args:
 *   hEth                         ETH instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG EthInstanceULInterfaceIoctl(H_NETINSTANCE hEth,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  ETHSTATE  *pxEth = (ETHSTATE *)hEth;
  ETH_UL *pxUl;
  LONG lReturn = NETERR_NOERR;

  ETH_CHECK_STATE(pxEth);
  ETH_ASSERT((0 <= (int)hULInterface) &&
             ((int)hULInterface <= pxEth->oUlNumber));

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ETH_DBGP(REPETITIVE,
           "EthInstanceULInterfaceIoctl: If = %d oIoctl= %d hData = 0x%x \n",
           (int)hULInterface,
           (int)oIoctl,
           (int)hData);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "EthInstanceULInterfaceIoctl: If = ", (int)hULInterface);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", oIoctl = ",(int)oIoctl );
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", hData = ",(int)hData);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  pxUl = pxEth->apxUl[(int)hULInterface];
  ASSERT(pxUl != NULL);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_SETHINST:
    pxUl->hUlInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxUl->pfnRxCbk = (PFN_NETRXCBK)hData;;
    break;

  case NETINTERFACEIOCTL_SETROUTINGID:
    pxUl->wRoutingId = (WORD)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxUl->hUlIf = (H_NETINTERFACE)hData;
    break;

#ifndef NDEBUG
  case NETINTERFACEIOCTL_OPEN:
      ASSERT(pxUl->wRoutingId != 0);
      ASSERT(pxUl->pfnRxCbk != NULL);
      break;
  case ETHULINTERFACEIOCTL_SETIFIDX:
  case NETINTERFACEIOCTL_CLOSE:
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ETH_ASSERT(0);
#endif
  }

  return lReturn;
}

/*
 * EthInstanceWrite
 *  Eth Instance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hEth                        Eth Instance handle
 *   hIf                         UL interface handle as provided by
 *                               EthInstanceULInterfaceCreate
 *   pxPacket                    Packet pointer
 *   pxAccess                    NETPACKETACCESS pointer
 *   hData                       OCTET * interface index
 *
 *  Return:
 *  Number of bytes written or a <0 error code
 */
LONG EthInstanceWrite(H_NETINSTANCE hEth,
                      H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,
                      NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  ETH_UL *pxUl;
  WORD wProtocol;
  ETHID *pxEthId = (ETHID*)hData;
  OCTET obSendIn = FALSE,obSendOut = TRUE;
  LONG lReturn;
  sbyte4 cmpResult;

  ETH_CHECK_STATE(pxEth);
  NETPACKET_CHECK(pxPacket);
  ETH_ASSERT((OCTET)hIf < pxEth->oUlNumber);

  ETH_ASSERT(pxEthId != NULL);
  ETH_ASSERT(pxAccess != NULL);

  lReturn = pxAccess->wLength;

  if (pxEthId->wVlan != NETVLAN_DEFAULT) {
    OCTET oIdx;
    /* Check the vlan is allowed */
    for (oIdx = 0; oIdx < pxEth->oSpecificVlanNumber; oIdx++) {
      if ((pxEth->pwSpecificVlan[oIdx] & ETHVID_MASK) ==
          (pxEthId->wVlan & ETHVID_MASK)) {
        break;
      }
    }
    if (oIdx >= pxEth->oSpecificVlanNumber &&
        (pxEth->wLlDefaultVlan & ETHVID_MASK) != (pxEthId->wVlan & ETHVID_MASK)) {
      /* Not allowed - delete */
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      return lReturn;
    }
  }

  pxUl = pxEth->apxUl[(int)hIf];
  ASSERT(pxUl != NULL);
  wProtocol = pxUl->wRoutingId;


  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ETH_DBGP(REPETITIVE,
          "EthInstanceWrite:Dst=%02x:%02x:%02x:%02x:%02x:%02x,Proto=%s, eth payload len=%d\n",
           HWADDRDISPLAY(pxEthId->aoAddr),
           EthProtoToString(wProtocol),
           pxAccess->wLength);*/
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "EthInstanceWrite:Dst= ",pxEthId->aoAddr[0] ,
                            ":", pxEthId->aoAddr[1]);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", pxEthId->aoAddr[2],
                            ":", pxEthId->aoAddr[3]);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", pxEthId->aoAddr[4],
                            ":", pxEthId->aoAddr[5]);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, " ,Proto=", EthProtoToString(wProtocol));
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " , eth payload len=", pxAccess->wLength);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " , oIfIdx = ",pxEthId->oIfIdx );
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

#if 1
  MOC_MEMCMP((ubyte *)pxEthId->aoAddr,
                (ubyte *)pxEth->aaoIfEthAddr[pxEthId->oIfIdx],
                ETHADDRESS_LEN, &cmpResult);
  obSendIn = ((pxEth->obLocalLoopback == TRUE) &&
              ((0xFF == pxEthId->aoAddr[0]) ||
               (0x00 == cmpResult)));
#else
  obSendIn = ((pxEth->obLocalLoopback == TRUE) &&
              ((0xFF == pxEthId->aoAddr[0]) ||
               (0x00 == memcmp(pxEthId->aoAddr,
                               pxEth->aaoIfEthAddr[pxEthId->oIfIdx],
                               ETHADDRESS_LEN))));
#endif
  obSendOut = (obSendIn == FALSE) || (0xFF == pxEthId->aoAddr[0]);

  /* Add the ethernet header */
  _EthHeaderAdd(hEth, pxPacket, pxAccess, pxEthId, wProtocol);

  if ((obSendIn != FALSE) && (obSendOut != FALSE)) {
    NETPAYLOAD_ADDUSER(pxPacket->pxPayload);
  }

  {
    NETPACKETACCESS xAccess;
    xAccess.wOffset = pxAccess->wOffset;
    xAccess.wLength = pxAccess->wLength;

    if (obSendOut == TRUE) {
      ASSERT(pxEth->pfnLlWrite != NULL);
      /* Call the LL write */
      pxEth->pfnLlWrite(pxEth->hLl,
                       pxEth->hLlIf, pxPacket, pxAccess,(H_NETDATA)pxEthId->oIfIdx);
    }
    if (obSendIn == TRUE) {
      NETIFID xNetIfId;
      xNetIfId.oIfIdx = pxEthId->oIfIdx;
      xNetIfId.wVlan  = pxEthId->wVlan;
      /* Call our own receive function */
      EthInstanceRcv(hEth,1,pxPacket,&xAccess,(H_NETDATA)&xNetIfId);
    }

  }

  return lReturn;
}


/*
 * EthInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hEth                       ETH instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE EthInstanceLLInterfaceCreate(H_NETINSTANCE hEth)
{
  ETH_CHECK_STATE((ETHSTATE*) hEth);

  return (H_NETINTERFACE)1;
}


/*
 * EthInstanceLLInterfaceDestroy
 *  Destroy a ETH LL interface
 *
 *  Args:
 *   hEth                       ETH instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG EthInstanceLLInterfaceDestroy(H_NETINSTANCE hEth,
                                   H_NETINTERFACE hInterface)
{
  ETH_ASSERT(hInterface == 1);
  return NETERR_NOERR;
}

/*
 * EthInstanceLLInterfaceIoctl
 *  ETH LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and netransport.h
 *  for precisions
 *
 *  Args:
 *   hEth                         Eth instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG EthInstanceLLInterfaceIoctl(H_NETINSTANCE hEth,
                                H_NETINTERFACE hLLInterface,
                                OCTET oIoctl,
                                H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  LONG lReturn = NETERR_NOERR;

  ETH_CHECK_STATE(pxEth);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_REPETITIVE))
  {

    /*ETH_DBGP(REPETITIVE,
           "EthInstanceLLInterfaceIoctl: If = %d oIoctl= %d hData = 0x%x \n",
           (int)hLLInterface,
           (int)oIoctl,
           (int)hData);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "EthInstanceLLInterfaceIoctl: If = ", (int)hLLInterface);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", oIoctl = ",(int)oIoctl );
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", hData = ",(int)hData);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  ETH_ASSERT(hLLInterface == 1);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
    ETH_ASSERT(pxEth->pfnLlWrite != NULL);
    break;

  case NETINTERFACEIOCTL_CLOSE:
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxEth->hLl = (H_NETINSTANCE) hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxEth->pfnLlWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxEth->hLlIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ETH_ASSERT(0);
  }

  return lReturn;
}

/*
 * EthInstanceRcv
 *  Eth Instance Rcv function
 *   Eth Instance Rcv function. Follows PFN_NETRXCBK
 *   def.
 *
 *   Args:
 *    hEth                       Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    pxAccess                   NETPACKETACCESS pointer
 *    hData                      OCTET * interface index
 *
 *   Return:
 *    Number of byte received or a <0 error code
 */
LONG EthInstanceRcv(H_NETINSTANCE hEth,
                    H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,
                    NETPACKETACCESS *pxAccess,
                    H_NETDATA hData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  NETPAYLOAD *pxPayload;
  ETH_UL *pxUl = NULL;
  ETHID xEthId;
  OCTET *poEthHdr;
  OCTET *poSrcHwAddr;
  OCTET *poPayload;
  WORD wNewOffset = pxAccess->wOffset;
  WORD wNewLength = pxAccess->wLength;
  WORD wOldLength = pxAccess->wLength;
  WORD wProtocol;
  WORD wVlan = NETVLAN_DEFAULT;
  NETIFID *pxNetIfId = (NETIFID*)hData;
  OCTET oIfIdx,oIdx;
  INT iDx;
  BOOL bDuplicatedHwAddr =FALSE;
  sbyte4 cmpResult;

  ETH_CHECK_STATE(pxEth);
  NETPACKET_CHECK(pxPacket);
  ASSERT(pxNetIfId != NULL);

  oIfIdx = pxNetIfId->oIfIdx;
  ETH_ASSERT(oIfIdx < (OCTET) ETH_MAXNUM_IF);

  pxPayload = pxPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  /* Set the pointer to the start of the header */
  poEthHdr = poPayload + wNewOffset;

  /*Set the pointer to the source hardware address*/
  poSrcHwAddr = poEthHdr + ETHADDRESS_LEN;

  #if 0
  /*Check if the source address is our address*/
  if(memcmp((const void*)poSrcHwAddr,
            (const void*)pxEth->aaoIfEthAddr[oIfIdx],
            (ubyte4)ETHADDRESS_LEN) == 0 ){
    bDuplicatedHwAddr = TRUE;
  } else {
    bDuplicatedHwAddr = FALSE;
  }
  #endif

#if 1
  MOC_MEMCMP ((ubyte *)poEthHdr,
            (ubyte *)pxEth->aaoIfEthAddr[oIfIdx],
            (ubyte4)ETHADDRESS_LEN, &cmpResult);
  /* If the destination address is NOT Bcast/Mcast and NOT ours,
     or if the source address is our address - delete the pkt */
  if ((((0x01 & poEthHdr[0]) == 0x00) && /* Test for both Multicast and Broadcast */
      (0 != cmpResult))||
      (bDuplicatedHwAddr == TRUE)) {
    SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    NETPAYLOAD_DELUSER(pxPayload);
    return (LONG)wOldLength;
  }
#else
  /* If the destination address is NOT Bcast/Mcast and NOT ours,
     or if the source address is our address - delete the pkt */
  if ((((0x01 & poEthHdr[0]) == 0x00) && /* Test for both Multicast and Broadcast */
      (0 != memcmp(poEthHdr, pxEth->aaoIfEthAddr[oIfIdx], (ubyte4)ETHADDRESS_LEN)))||
      (bDuplicatedHwAddr == TRUE)) {
    SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    NETPAYLOAD_DELUSER(pxPayload);
    return (LONG)wOldLength;
  }
#endif

  /* Test the protocol and send the packet up to the correct interface */
  MOC_MEMCPY((ubyte *)&wProtocol,
        (ubyte *)(poEthHdr+ETHTYPE_OFFSET), (ubyte4)ETHTYPE_LEN);
  wProtocol = ntohs(wProtocol);
  wNewOffset += (ETHHEADER_LEN);
  wNewLength -= (ETHHEADER_LEN);


    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ETH_DBGP(REPETITIVE,
           "EthInstanceRcv:oIfIdx=%d,Dst=%02x:%02x:%02x:%02x:%02x:%02x,Src=%02x:%02x:%02x:%02x:%02x:%02x,Proto=%s, eth len=%d\n",
           oIfIdx,
           HWADDRDISPLAY(poEthHdr),
           HWADDRDISPLAY(poSrcHwAddr),
           EthProtoToString(wProtocol),
           wOldLength); */
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "EthInstanceRcv:Dst= ",poEthHdr[0] ,
                            ":", poEthHdr[1]);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", poEthHdr[2],
                            ":", poEthHdr[3]);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", poEthHdr[4],
                            ":", poEthHdr[5]);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ", Src= ",poSrcHwAddr[0] ,
                            ":", poSrcHwAddr[1]);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", poSrcHwAddr[2],
                            ":", poSrcHwAddr[3]);
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ":", poSrcHwAddr[4],
                            ":", poSrcHwAddr[5]);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, " ,Proto=", EthProtoToString(wProtocol));
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " , eth payload len=", wOldLength);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " , oIfIdx =",oIfIdx );
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /* Don't allow non-vlan packets if the default vlan is set */
  if (pxEth->wLlDefaultVlan != NETVLAN_DEFAULT &&
      wProtocol != ETHVLAN_TYPE) {
      /* Not allowed - delete packet */
      SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
      NETPAYLOAD_DELUSER(pxPayload);
      return (LONG)wOldLength;

  } else if (wProtocol == ETHVLAN_TYPE) { /* VLAN pkt */
    MOC_MEMCPY((ubyte *)&wVlan,
        (ubyte *)(poEthHdr+ETHTYPE_OFFSET+ETHTYPE_LEN), sizeof(wVlan));
    wVlan = ntohs(wVlan);
    /* Check the vlan is allowed */
    for (iDx = 0; iDx < pxEth->oSpecificVlanNumber; iDx++) {
      if ((pxEth->pwSpecificVlan[iDx] & ETHVID_MASK) == (wVlan & ETHVID_MASK)) {
        break;
      }
    }
    if (iDx >= pxEth->oSpecificVlanNumber &&
        (pxEth->wLlDefaultVlan & ETHVID_MASK) != (wVlan & ETHVID_MASK)) {
      /* Not allowed - delete packet */
      SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
      NETPAYLOAD_DELUSER(pxPayload);
      return (LONG)wOldLength;
    }

    MOC_MEMCPY((ubyte *)&wProtocol,
        (ubyte *)(poEthHdr+ETHVLAN_LEN+ETHTYPE_OFFSET), (ubyte4)ETHTYPE_LEN);
    wProtocol = ntohs(wProtocol);
    wNewOffset += ETHVLAN_LEN;
    wNewLength -= ETHVLAN_LEN;
  }
  else if (wProtocol <= ETHDATA_LEN) {/* IEEE 802.2/802.3 pkt- not supported */
    SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInUnknownProtos++ );
    NETPAYLOAD_DELUSER(pxPayload);
    return (LONG)wOldLength;
  }

  /*copy the source hw address */
  MOC_MEMCPY((ubyte *)&xEthId.aoAddr,
                (ubyte *)(poEthHdr+ETHADDRESS_LEN),
                (ubyte4)ETHADDRESS_LEN);

  /*Get EHID data*/
  xEthId.oIfIdx = oIfIdx;
  xEthId.wVlan = wVlan;

  /* Find match for wProtocol in UL wRoutingId entries */
  for (oIdx = 0; oIdx < pxEth->oUlNumber; oIdx++) {
    pxUl = pxEth->apxUl[oIdx];
    ASSERT(pxUl != NULL);
    if ((pxUl->wRoutingId == wProtocol) &&
        ((pxUl->oIfIdx == pxNetIfId->oIfIdx) || (pxUl->oIfIdx == NETIFIDX_ANY))) {
      break;
    }
  }

  if (oIdx == pxEth->oUlNumber) {
    /* No match - no UL module has been plumbed in to receive the packet */
    SNMP( xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    ETH_DBGP(REPETITIVE, "EthInstanceRcv: Discard (Reason: unsupported protocol)\n");
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ETH, INET_DBG_LEVEL_REPETITIVE))
    {
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "EthInstanceRcv: Discard (Reason: unsupported protocol)");
    }
    NETPAYLOAD_DELUSER(pxPayload);
    return (LONG)wOldLength;
  }

  /* We've found a UL module to take the packet */
  ETH_ASSERT(pxUl->pfnRxCbk != NULL);

  /* Update the pxAccess structure */
  pxAccess->wOffset = wNewOffset;
  pxAccess->wLength = wNewLength;

  /* Write the packet to registered UL */
  (void)pxUl->pfnRxCbk(pxUl->hUlInst,
                       pxUl->hUlIf,
                       pxPacket,
                       pxAccess,
                       (H_NETDATA)&xEthId);

  return (LONG)wOldLength;
}


CHAR *EthProtoToString(WORD wProtocol)
{
  switch(wProtocol){
  case ETHID_IP:
    return "IP";

  case ETHID_ARP:
    return "ARP";

  case ETHID_RARP:
    return "RARP";

  case ETHVLAN_TYPE:
    return "VLAN";

  case ETHID_PPPOEDISCOVERY:
    return "PPPoE-Discovery";

  case ETHID_PPPOESESSION:
    return "PPPoE-Session";

  default:
    return "???";
  }
}
