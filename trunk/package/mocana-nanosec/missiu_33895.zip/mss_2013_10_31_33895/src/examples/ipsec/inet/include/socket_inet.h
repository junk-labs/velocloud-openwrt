/*
 * socket_inet.h
 *
 * Definitions for the Socket API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef socket_inet_h
#define socket_inet_h

/***************************************************************************/
/*                             D E F I N E S                               */
/***************************************************************************/

/* Code that is OS dependent can exclude VLAN by using this: */
#define VLAN

/* protocol families */
#define    PF_INET        2        /* TCP/IP and related */
#define AF_UNSPEC       0               /* Unspecified */
#define    AF_INET        2        /* TCP/IP and related */
#define    AF_INET6    10        /* TCP/IPv6 and related */

/* socket types */
#define    SOCK_STREAM    1        /* stream socket */
#define    SOCK_DGRAM    2        /* datagram socket */
#define    SOCK_RAW    3        /* raw socket */

#define SHUT_RD        0         /* read half */
#define SHUT_WR        1         /* write half */
#define SHUT_RDWR    2         /* read and write halves */

#define SOMAXCONN    64        /* max TCP conns */

/* Socket State bits (i) = implemented/used */
#define SS_NOFDREF              0x001   /* no file table ref any more */
#define SS_ISCONNECTED          0x002   /* socket connected to a peer (i) */
#define SS_ISCONNECTING         0x004   /* in process of connecting to peer */
#define SS_ISDISCONNECTING      0x008   /* in process of disconnecting */
#define SS_CANTSENDMORE         0x010   /* can't send more data to peer (i) */
#define SS_CANTRCVMORE          0x020   /* can't recv more data from peer (i) */
#define SS_RCVATMARK            0x040   /* at mark on input */
#define SS_PRIV                 0x080   /* privileged for broadcast, raw... */
#define SS_NBIO                 0x100   /* non-blocking ops (i) */
#define SS_ASYNC                0x200   /* async i/o notify */
#define SS_ISCONFIRMING         0x400   /* deciding to accept connection req */
#define SS_ISACCEPTED         0x800   /* socket is accept()ed */
#define SS_ISCONNECTOR         0x1000   /* was initiator of connection */
#define SS_ISRESET             0x2000   /* initiator of reset by peer */

/* MSG definitions */
#define MSG_OOB         0x1             /* process out-of-band data */
#define MSG_PEEK        0x2             /* peek at incoming message */
#define MSG_DONTROUTE   0x4             /* send without using routing tables */
#define MSG_EOR         0x8             /* data completes record */
#define MSG_TRUNC       0x10            /* data discarded before delivery */
#define MSG_CTRUNC      0x20            /* control data lost before delivery*/
#define MSG_WAITALL     0x40            /* wait for full request or error */
#define MSG_DONTWAIT    0x80            /* Don't block for this recv */
#define MN_ZEROCOPY    0x40000000    /* passed in buffer is alloced
                       using mn_sock_alloc_sendbuf() or
                                           using mn_sock_alloc_segment()
                                           By default its assumed that
                                           Async Payload will be Segment
                                           for TCP. */
#define MN_ASYNCBUF    0x80000000    /* passed in buffer is alloced
                       using mn_sock_alloc_sendbuf()
                                           This along with ZEROCOPY needs
                                           to be passed if its a pure Async
                                           buf and not Segment*/

/* Misc */
#define    MLEN        108        /* Net/3 value used in setsockopt etc */

/* Option levels */
#define SOL_SOCKET     0xFFFF         /* options for socket level */

/*
 * Option flags per-socket.
 */
#define SO_DEBUG        0x0001          /* turn on debugging info recording */
#define SO_ACCEPTCONN   0x0002          /* socket has had listen() */
#define SO_REUSEADDR    0x0004          /* allow local address reuse */
#define SO_KEEPALIVE    0x0008          /* keep connections alive */
#define SO_DONTROUTE    0x0010          /* just use interface addresses */
#define SO_BROADCAST    0x0020          /* permit sending of broadcast msgs */
#define SO_USELOOPBACK  0x0040          /* bypass hardware when possible */
#define SO_LINGER       0x0080          /* linger on close if data present */
#define SO_OOBINLINE    0x0100          /* leave received OOB data in line */
#define SO_VLAN         0x0200          /* socket to use vlan tags */
/*
 * Additional options
 */
#define SO_SNDBUF       0x1001          /* send buffer size */
#define SO_RCVBUF       0x1002          /* receive buffer size */
#define SO_SNDLOWAT     0x1003          /* send low-water mark */
#define SO_RCVLOWAT     0x1004          /* receive low-water mark */
#define SO_SNDTIMEO     0x1005          /* send timeout */
#define SO_RCVTIMEO     0x1006          /* receive timeout */
#define SO_ERROR        0x1007          /* get error status and clear */
#define SO_TYPE         0x1008          /* get socket type */

/* fcntl options */
#define FNDELAY        O_NDELAY
#define FNONBLOCK       O_NDELAY        /* kernel */

/* JJ */
#define EBADARG  -9999
#define EBADREQ  -9998

/***************************************************************************/
/*                  D A T A    S T R U C T U R E S                         */
/***************************************************************************/
typedef unsigned int   socklen_t;   /* 32 bit */

struct sockaddr {
    unsigned char sa_len;
    unsigned char sa_family;          /* Address family AF_XXX */
    char          sa_data[14];         /* Protocol specific address */
};

/* Structure for linger */
struct linger {
    int l_onoff; /* option on/off */
    int l_linger; /* linger time in seconds */
};

/* Structure for VLAN tag */
struct vlan {
#if 0
    BOOL bVlanOnOff;  /* option on/off */
#else
    WORD bVlanOnOff;  /* option on/off */
#endif
    WORD wVlanProto;  /* Should always be VLAN_TYPE 0x8100 */
    WORD wVlanTCI;    /* Tag Control Info - encapsulates priority and vlan ID */
};
#define VLAN_TYPE 0x8100

/***************************************************************************/
/*                       M A C R O S                                       */
/***************************************************************************/

/***************************************************************************/
/*           F U N C T I O N    P R O T O T Y P E S                        */
/***************************************************************************/

/*
 * socket
 *  Creates a socket.
 *  Remarks:Default is blocking socket. Non-blocking will be implemented
 *          first.
 *
 *  Args:
 *   family                      The address protocol family
 *                               Should be AF_INET: Internet Protocols.
 *   type                        The type for the socket.
 *                               Should be one of
 *                                 SOCK_STREAM: Stream Socket (TCP/IP)
 *                                 SOCK_DGRAM : Datagram Socket (UDP/IP)
 *   protocol                    Should be set to 0.
 *
 * Return:
 *  0 or more: successful socket (sockfd)
 *  -1       : error
 */
int socket(int family, int type, int protocol);

/*
 * mn_sock_connect_cb_t
 *  Called by TCP stack to indicate a new incoming connection.
 *  Remarks:
 *   Original sockfd can still be used to accept new connections. *
 * Args:
 *  result             0 on success, -1 on failure establishing connection
 *  sockfd             Socket on which connect() was done.
 *  servaddr           The protocol address of the server connected to.
 *  addrlen            size of the servaddr structure.
 *  arg               Callback argument passed to connect()
 *
 * Return:
 *   void
 */
typedef void (*mn_sock_connect_cb_t)(int result, int sockfd,
        struct sockaddr *servaddr, socklen_t addrlen, void *arg);

/*
 * connect
 *  Used by a TCP or UDP client to establish a connection with a server.
 *  Remarks: A UDP client can also use the connect function. This only stores
 *   the address/port specified in the servaddr structure, so that the system
 *   knows where to send any future data that the application writes to the
 *   sockfd. Also, only datagrams from this address will be received
 *   from the socket. Once connect() has been called on a UDP socket, send()
 *   must be used instead of sendto() and recv() must be used instead of
 *   recvfrom().
 *
 *  Args:
 *   sockfd                      The socket returned by the socket function.
 *   servaddr                    The structure in which the remote IP address
 *                               and remote port should be specified.
 *   addrlen                     size of the servaddr structure.
 *   cb                  Callback routine to be called whenever a new
 *                               connection comes in (could be immediate)
 *   cbarg             Argument to be passed back to cb
 *
 *  Return:
 *   0 : Success. A connection to remote server has been established.
 *   -1: Error
 */
int connect(int sockfd, const struct sockaddr *servaddr, socklen_t addrlen,
        mn_sock_connect_cb_t cb, void *cbarg);

/*
 * bind
 *  Assigns a local protocol address to a socket.
 *
 * Args:
 *  sockfd                       The socket returned by the socket function.
 *  myaddr                       The structure in which the local IP address
 *                               and local port should be specified.
 *  addrlen                      size of the servaddr structure.
 *
 * Return:
 *  0 : Success. Address successfully bound
 *  -1: Error
 */
int bind(int sockfd, const struct sockaddr *myaddr, socklen_t addrlen);

/*
 * listen
 *  Used by a TCP server to start listening for connections.
 *
 *  Args:
 *    sockfd                     The socket returned by the socket function.
 *    backlog                    maximum number of connections that should be
 *                               queued; for this sockfd. Ignored, a value of
 *                               1 will be used.
 *  Return:
 *    0 : Success.
 *    -1: Error
 */
int listen(int sockfd, int backlog);

/*
 * mn_sock_accept_cb_t
 *  Called by TCP stack to indicate a new incoming connection.
 *  Remarks:
 *   Original sockfd can still be used to accept new connections. *
 * Args:
 *  listeningSockFd              Original socket on which listen() was done.
 *  acceptedSockFd               New socket created for the new connection
 *  cliaddr                      The protocol address of the connected client.
 *  addrlen                      size of the cliaddr structure.
 *  arg                 Callback argument passed to accept()
 *
 * Return:
 *   void
 */
typedef void (*mn_sock_accept_cb_t)(int listeningSockFd, int acceptedSockFd,
        struct sockaddr *cliaddr, socklen_t addrlen, void *arg);
/*
 * accept
 *  Called by a TCP Server to return a completed connection.
 *  Remarks:
 *   Original sockfd can still be used to accept new connections. *
 * Args:
 *  sockfd                       The socket returned by the socket function.
 *  cliaddr                      On return, has the protocol address of
 *                               the connected client.
 *  addrlen                      Before the call, should be set to the size
 *                               of the structure pointed to by cliaddr. On
 *                               return, this will point to the size of
 *                             the returned structure.
 *  cb                  Callback routine to be called whenever a new
 *                               connection comes in (could be immediate)
 *  cbarg             Argument to be passed back to cb
 *
 * Return:
 *  >0 : Success. New socket created in sync mode.
 *   0 : Success. Async mode.
 *  -1: Error
 */
int accept(int sockfd, struct sockaddr *cliaddr, socklen_t *addrlen,
         mn_sock_accept_cb_t cb, void *cbarg);

/*
 * mn_sock_recv_cb_t
 *  Called by TCP/UDP stack to indicate new incoming data.
 *
 * Args:
 *  lSockfd                        The socket on which data arrived
 *  buff                           The buffer into which data is stored.
 *  nbytes                         Number of bytes received.
 *  from                           Protocol address of the sender.
 *  addrlen                        Length of the structure 'from' points to.
 *  arg                   Callback argument passed to recv()/recvfrom()
 *  pFreeArg   Arg to be passed to mn_sock_free_recvbuf();
 *
 * Return:
 *   void
 */
typedef void (*mn_sock_recv_cb_t)(int lsockfd, void *buff,
    ubyte4 nbytes, struct sockaddr *from, socklen_t addrlen, void *arg, void *pFreeArg);
/*
 * recv
 *  Used to receive a message on an established connection.
 *  Async operation is always zero-copy.
 *
 *  Args:
 *    lSockfd     The socket returned by the socket function.
 *     buff       The buffer into which data will be stored.
 *     nbytes     Maximum number of bytes to be received.
 *     Flags      Ignored. Future implementation.
 *     cb      Callback routine to be called whenever data
 *                comes in (could be immediate).  Optional.
 *     cbarg      Argument to be passed back to cb. Optional.
 *     pBuff      Zero copy sync operation. If pBuff specified,
 *                pointer to recvd data will be stored in it. Free that pointer
 *                using mn_sock_free_recvbuf().
 *     pFreeArg   Arg to be passed to mn_sock_free_recvbuf();
 *
 *  Return:
 *   >0 : Number of bytes read in sync mode.
 *    0 : Success. Async mode.
 *   -1: Error
 */
sbyte4 recv(int sockfd, void *buff, ubyte4 nbytes, int iFlags,
         mn_sock_recv_cb_t cb, void *cbarg, /* async stuff */
         void **pBuff, void **pFreeArg); /* zero-copy stuff */

/*
 * send
 *  Send a message on an established connection.
 *  If MN_ZEROCOPY flags bit is set in iFlags,
 *    -  buff should have been alloced using mn_sock_alloc_sendbuf().
 *    -  nbytes should be <= nbytes passed to mn_sock_alloc_sendbuf()
 *    -  buff will be freed upon return i.e. it can not be reused by app
 *
 * Args:
 *  lSockfd                      The socket returned by the socket function.
 *  buff                         The buffer that needs to be sent.
 *  nbytes                       Number of bytes to be sent.
 *  iFlags                       Only MN_ZEROCOPY supported
 *
 * Return:
 *  0 or more : Number of bytes sent.
 *  -1: Error
 */
sbyte4 send(int lsockfd, void *buff, ubyte4 nbytes, int iFlags);


/*
 * recvfrom
 *  Used to receive a message.
 *  Async operation is always zero-copy.
 *
 * Args:
 *  lSockfd      The socket returned by the socket function.
 *  buff         The buffer into which data will be stored.
 *  nbytes       Maximum number of bytes to be received.
 *  Flags        Ignored. Future Implementation.
 *  from         On return, filled with the protocol address of the sender.
 *  addrlen      On return, this pointer has the length of
 *               the structure 'from' points to.
 *  pfCb     Callback routine to be called whenever data
 *               comes in (could be immediate).
 *  pfCbArg     Argument to be passed back to pfCb
 *  pBuff        Zero copy sync operation. If pBuff specified,
 *               pointer to recvd data will be stored in it.
 *               Free that pointer using mn_sock_free_recvbuf().
 *  pFreeArg     Arg to be passed to mn_sock_free_recvbuf();
 *
 * Return:
 *  >0 : Number of bytes read in sync mode.
 *   0 : Success. Async mode.
 *  -1: Error
 */
sbyte4 recvfrom(int lsockfd, void *buff, ubyte4 nbytes, int iFlags,
                 struct sockaddr *from, socklen_t *addrlen,
         mn_sock_recv_cb_t pfCb, void *pvCbArg, /* async stuff */
         void **pBuff, void **pFreeArg); /* zero-copy stuff */

/*
 * sendto
 *  Send a message.
 *  If MN_ZEROCOPY flags bit is set in iFlags,
 *    -  buff should have been alloced using mn_sock_alloc_sendbuf().
 *    -  nbytes should be <= nbytes passed to mn_sock_alloc_sendbuf()
 *    -  buff will be freed upon return i.e. it can not be reused
 *
 *  Args:
 *   lSockfd                       The socket returned by the socket function.
 *   buff                          The buffer that needs to be sent.
 *   nbytes                        Number of bytes to be sent.
 *   iFlags                        Only MN_ZEROCOPY supported.
 *   to                            The protocol address of the remote host
 *                                 should be specified.
 *   addrlen                       The length of the structure 'to' points to.
 *
 *  Return:
 *   0 or more : Number of bytes sent.
 *   -1: Error
 */
sbyte4 sendto(int lsockfd, void *buff, ubyte4 nbytes, int iFlags,
               const struct sockaddr *to, socklen_t addrlen);

/*
 * getsockopt
 *  Get options for a socket
 *
 *  Args:
 *   sockfd                       The socket returned by the socket function.
 *   level                        level at which the option is interpreted.
 *                                Should be SOL_SOCKET. IPPROTO_IP ,
 *                                IP_PROTO_TCP : Future implementation.
 *   optname                      The name of the option itself.
 *                                See table 1.1 below.
 *   optval                       Pointer to a variable into which the current
 *                                value of the option is stored.
 *   optlen                       Pointer to the size of the data stored in
 *                                'optval'.
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int getsockopt(int sockfd, int level, int optname, void *optval,
               socklen_t *optlen);

/*
 * setsockopt
 *  Set options that affect a socket
 *
 *  Args:
 *   sockfd                       The socket returned by the socket function.
 *   level                        level at which the option is interpreted.
 *                              Should be SOL_SOCKET. IPPROTO_IP ,
 *                                IP_PROTO_TCP : Future implementation.
 *   optname                      The name of the option itself.
 *                                See table 1.1 below.
 *   optval                       Pointer to a variable from which the new
 *                                value of the option is retrieved.
 *   optlen                       Pointer to the size of the data stored in
 *                               'optval'.
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int setsockopt(int sockfd, int level, int optname, const void *optval,
               socklen_t optlen);

/*
 * shutdown
 *  Shuts down part of a connection
 *
 *  Args:
 *   sockfd                        The socket returned by the socket function.
 *   howto                         Should be one of:
 *                                 SHUT_RD: The read half of the connection
 *                                  is closed; no more data can be received on
 *                                  the socket. No more read functions can be
 *                                  issued on the socket
 *                                 SHUT_WR: The write half of the connection
 *                                  is closed; no more data can be sent on the
 *                                  socket. No more write functions can be
 *                                  issued on the socket
 *                                 SHUT_RDWR: Both halves of the connection
 *                                  are closed. Equivalent to calling shutdown,
 *                                  first with SHUT_RD, then with SHUT_WR.
 *
 *  Return:
 *  0 : Success.
 *  -1: Error
 */
int shutdown(int sockfd, int howto);

/*
 * getpeername
 *  Gets remote protocol address associated with a socket
 *
 *  Args:
 *   lsockfd                       The socket returned by the socket function.
 *   peeraddr                      Pointer to structure into which the remote
 *                                 address information is stored.
 *   addrlen:                      On return, pointer to the length of the
 *                                 structure 'peeraddr' points to.
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int getpeername(int lsockfd, struct sockaddr *peeraddr, socklen_t *addrlen);


/*
 * getsockname
 *  Gets local protocol address associated with a socket
 *
 *  Args:
 *   lsockfd                       The socket returned by the socket function.
 *   localaddr                     Pointer to structure into which the local
 *                                 address information is stored.
 *   addrlen                       On return, pointer to the length of the
 *                                 structure 'localaddr' points to.
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int getsockname(int lsockfd, struct sockaddr *localaddr, socklen_t *addrlen);
#define socket mn_socket
#define listen mn_listen
#define accept mn_accept
#define bind mn_bind
#define connect mn_connect
#define shutdown mn_shutdown
#define getsockopt mn_getsockopt
#define setsockopt mn_setsockopt
#define getsockname mn_getsockname
#define open mn_open
#define ioctl mn_ioctl
#define close mn_close
#define write mn_write
#define read mn_read
#define send mn_send
#define recv mn_recv
#define recvfrom mn_recvfrom
#define select mn_select
#define pselect mn_pselect
#define gethostbyname mn_gethostbyname

/*
 * mn_tcp_sock_rx_errs_t
 *
 *  Socket RX Errors
    unsigned int wChecksumErrs - checksum errors for this connection
    unsigned int wBadLenErrs - bad length errors for this connection
 */
typedef struct {
    unsigned int wChecksumErrs;
    unsigned int wBadLenErrs;
} mn_tcp_sock_rx_errs_t;

/*
 * mn_tcp_sock_tx_errs_t
 *
 *  Socket TX Errors
 *       unsigned int wRetransSegs - retransmissions for this connection
 */
typedef struct {
    unsigned int wRetransSegs;
} mn_tcp_sock_tx_errs_t;

/*
 * mn_sock_event_t
 *
 *  Socket events
 *   MN_TCP_SOCK_RST         - TCP connection has been reset by other side. No data passed to callback
 *   MN_TCP_SOCK_TIMEDOUT    - TCP connection has timedout. No data passed to callback
 *   MN_TCP_SOCK_HALFCLOSED  - Remote end has closed its output pipe. No data passed to callback
 *   MN_TCP_SOCK_RX_ERRS  - Receive errors threshold hit. Data is pointer to mn_tcp_sock_rx_errs_t.
 *   MN_TCP_SOCK_TX_ERRS  - Transmit errors threshold hit. Data is pointer to mn_tcp_sock_tx_errs_t.
 */
typedef enum {
    MN_TCP_SOCK_RST = 1,
    MN_TCP_SOCK_TIMEDOUT,
    MN_TCP_SOCK_HALFCLOSED,
     MN_TCP_SOCK_RX_ERRS,
    MN_TCP_SOCK_TX_ERRS,
} mn_sock_event_t;

/*
 * mn_sock_event_cb_t
 *  Application callback prototype
 *
 *  Args:
 *   lsockfd                       The socket returned by the socket function.
 *   event                         Socket event
 *   data                          Event related data, if any
 *
 *  Return:
 *   void
 */
typedef void (*mn_sock_event_cb_t)(int lsockfd, mn_sock_event_t event,
                    void *arg, void *data);

/*
 * mn_register_sock_event_cb
 *  Registers application callback to receive socket events
 *
 *  Args:
 *   lsockfd                       The socket returned by the socket function.
 *   cb                            Callback routine to handle socket event.
 *   cbArg                         Argument to be passed back to Callback
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int mn_register_sock_event_cb(int lsockfd, mn_sock_event_cb_t cb, void *cbArg);

/*
 * mn_tcp_sock_stats_t
 *
 *  TCP Socket stats
 *      txAvailableSpace;
 *      txUsedSpace;
 *      txRetransSegs;

 *      rxAvailableSpace;
 *      rxUsedSpace;
 *      rxChecksumErrs;
 *      rxBadLenErrs;

 *      MSS; - max segment size
 *      SRTT; - smoothed RTT - milli secs
 */
typedef struct {
    unsigned int txAvailableSpace;
    unsigned int txUsedSpace;
    unsigned int txRetransSegs;
    unsigned int txMemCopies;

    unsigned int rxAvailableSpace;
    unsigned int rxUsedSpace;
    unsigned int rxChecksumErrs;
    unsigned int rxBadLenErrs;
    unsigned int rxMemCopies;

    unsigned int MSS;
    unsigned int RMSS;
    unsigned int SRTT;
        unsigned int rxWindow;
        unsigned int txWindow;
} mn_tcp_sock_stats_t;

#if defined (__VXWORKS_RTOS__)
#else
/*
 * mn_udp_sock_stats_t
 *
 *  UDP Socket stats
 *      TBD
 */
typedef struct {
      /* TBD; */
} mn_udp_sock_stats_t;
#endif

/*
 * mn_sock_stats
 *  Retrieve socket TCP/UDP statistics
 *
 *  Args:
 *   lsockfd     The socket returned by the socket function.
 *   stats       Pointer to mn_tcp_sock_stats_t or mn_udp_sock_stats_t
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int mn_sock_stats(int lSockfd, void *stats);

/*
 * MN_sockTcpGetRemoteMss
 *  Retrieve socket TCP Remote MSS
 *
 *  Args:
 *   lsockfd     The socket returned by the socket function.
 *   mss         Pointer to int
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int MN_sockTcpGetRemoteMss(int lSockfd, int *mss);

/*
 * MN_sockTcpChangeRxWin
 *  Change Current Rx Win  Based upon App Logic
 *
 *  Args:
 *   lsockfd     The socket returned by the socket function.
 *   win         Win Scaling Value 30 to 100
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int MN_sockTcpChangeRxWin(int lSockfd, int win);
/*
 * mn_sock_alloc_sendbuf
 *  Allocate a buffer to send data in. Used for zero copy transmission.
 *  Application fills the buffer gotten from this API and sends using
 *  send()/sendto() with a flag MN_ZEROCOPY flag set. Allocated buffer will
 *  be freed by send()/sendto(). Once send()/sendto() is called, do not
 *  call mn_sock_free_sendbuf() again.
 *
 *  Args:
 *   lsockfd      The socket returned by the socket function.
 *   nbytes       Number of bytes required
 *
 *  Return:
 *   Pointer to allocated buffer: Success.
 *   NULL: Error
 */
void *mn_sock_alloc_sendbuf(int lsockfd, ubyte4 nbytes);

/*
 * mn_sock_free_sendbuf
 *  Free the buffer alloced by mn_sock_alloc_sendbuf().
 *
 *  Args:
 *   lsockfd    The socket returned by the socket function.
 *   buff       The buffer alloced using mn_sock_alloc_sendbuf()
 *
 *  Return:
 *   void:
 */

void mn_sock_free_sendbuf(int lsockfd, void *buff);

/*
 * mn_sock_free_recvbuf
 *  Free the buffer pointer retruned in recv()/recvfrom() for zero-copy
 *
 *  Args:
 *   buff       The zero-copy buffer pointer returned in recv()/recvfrom()
 *
 *  Return:
 *   void:
 */

void mn_sock_free_recvbuf(void *buff);

#ifdef __TCP_USE_SEGMENTS__
/*
 * mn_sock_free_recvsegment
 *  Free the segment pointer  chain retruned in recv()/recvfrom() for zero-copy
 *
 *  Args:
 *   buff       The zero-copy buffer pointer returned in recv()/recvfrom()
 *
 *  Return:
 *   void:
 */

void mn_sock_free_recvsegment(void *buff);
#endif

/* When the Socket Fd is handed Over between Threads
   Call this to register from the New Thread the Interest on
   The Sock Fd, so that Selects etc get Optimized for that Thread
   and Fd */
LONG SocketRegisterInterest(LONG lFd);
/* SHow the TCP Session COntrol Blocks */
LONG TcpShowAllInfo(void);

#endif

