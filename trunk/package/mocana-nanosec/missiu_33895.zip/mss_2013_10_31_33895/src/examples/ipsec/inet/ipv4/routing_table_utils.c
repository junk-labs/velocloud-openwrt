/*
 * routing_table_utils.c
 *
 * routing table utility function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/

#include "router.h"
#include "routing_table_defs.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

