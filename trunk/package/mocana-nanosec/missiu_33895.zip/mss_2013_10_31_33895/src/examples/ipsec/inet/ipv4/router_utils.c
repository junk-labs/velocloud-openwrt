/*
 * router_utils.c
 *
 * router utility function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/
#include "router.h"
#include "router_defs.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * RouterCheckFrag
 *  Utility to check if fragmentation is needed. Also sends
 *  ICMP message to the originating host if necessary.
 *
 * Args:
 *  hRouter                    router Instance handle
 *  pxNetPacket                Packet pointer
 *  pxNetPacketAccess          Packet access parameters
 *  hData                      pointer to a NETWORKID structure
 *  oSrcIfIdx                  Interface whose IP address to be used as source address.
 *  wSrcVlan                   Src Vlan
 *
 * Return:
 *  0                          no fragmentation needed
 *                             (or) packet can be fragmented.
 *  -1                         packet needs fragmentation, but
 *                             cannot be fragmented.
 */
LONG RouterCheckFrag(H_NETINSTANCE    hRouter,
                     NETPACKET        *pxNetPacket,
                     NETPACKETACCESS  *pxNetPacketAccess,
                     H_NETDATA        hData,
                     OCTET            oSrcIfIdx,
                     WORD             wSrcVlan)
{
  ROUTERSTATE *pxRouter = (ROUTERSTATE*) hRouter;
  NETWORKID *pxNetworkId = (NETWORKID*) hData;
  WORD wPacketSize = pxNetworkId->oIpHdrLen + pxNetPacketAccess->wLength;

  ROUTER_CHECK_STATE(pxRouter);

  /*
   * Check if the packet needs to be fragmented,
   * but the DF bit in the Ip Header is set
   */
  ASSERT(pxNetworkId->oIfIdx < ROUTER_MAXNUM_IF);
  if ((wPacketSize > pxRouter->awMtu[pxNetworkId->oIfIdx]) &&
      ((pxNetworkId->wFragOffset & (WORD)IPFRAGMASK_DF) != (WORD)0x0000)) {
    RouterSendIcmpMsg(hRouter,
                      pxNetPacket,
                      pxNetPacketAccess,
                      hData,
                      oSrcIfIdx,
                      wSrcVlan,
                      (OCTET) ROUTERCBK_DEST_UNREACH_FRAG_NEEDED);

    SNMP(xTcpipData.ipFragFails ++;)

    return -1;
  }

  return 0;
}


/*
 * RouterSendIcmpMsg
 *  Sends ICMP message to the originating host if the
 * destination network is unreachable.
 *
 * Args:
 *  hRouter                    router Instance handle
 *  pxNetPacket                Packet pointer
 *  pxNetPacketAccess          Packet access parameters
 *  hData                      Pointer to a NETWORKID structure
 *  oSrcIfIdx                  Interface whose IP address to be used as source address.
 *  wSrcVlan                   Src Vlan
 *  oCbkMsg                    Callback message type.
 *
 * Return:
 *  None
 */
void RouterSendIcmpMsg(H_NETINSTANCE    hRouter,
                       NETPACKET        *pxNetPacket,
                       NETPACKETACCESS  *pxNetPacketAccess,
                       H_NETDATA        hData,
                       OCTET            oSrcIfIdx,
                       WORD             wSrcVlan,
                       OCTET            oCbkMsg)
{
  ROUTERSTATE *pxRouter = (ROUTERSTATE*) hRouter;
  NETWORKID *pxNetworkId = (NETWORKID*) hData;
  ICMPMSGDATA xIcmpMsgData;

  ROUTER_CHECK_STATE(pxRouter);

  oSrcIfIdx = (oSrcIfIdx == NETIFIDX_ANY) ? (pxRouter->oIfIdxLan) : (oSrcIfIdx);

  /*
   * fill the ICMPMSGDATA structure
   */
#ifdef _RADIX_ROUTING_ON_
  if(ROUTERCBK_LINK_DOWN == oCbkMsg)
  {
    xIcmpMsgData.dwSrcAddr = pxNetworkId->dwDstAddr;
    xIcmpMsgData.dwDstAddr = pxNetworkId->dwSrcAddr;
    xIcmpMsgData.oProtocol = pxNetworkId->oProtocol;
  }
  else
#endif
  {
    IPTABLEENTRY xIpEntry;

    xIpEntry.dwAddr = 0x0;
    xIpEntry.eAddrType = IPADDRT_ANY;
    xIpEntry.wDefaultVlan = NETVLAN_ANY;
    xIpEntry.oIfIdx = oSrcIfIdx;

    if (IpTableMsg(IPTABLEMSG_GETDEFAULT, (H_NETDATA) &xIpEntry) < 0) {
      return;
    }

    /*
     * If the source address of the interface has not been
     * obtained yet, do nothing.
     */
    if (xIpEntry.dwAddr == INADDR_ANY) {
      return;
    }

    xIcmpMsgData.dwSrcAddr = xIpEntry.dwAddr;
    xIcmpMsgData.dwDstAddr = pxNetworkId->dwSrcAddr;
  }
  xIcmpMsgData.pxNetPacket = pxNetPacket;
  xIcmpMsgData.pxNetPacketAccess = pxNetPacketAccess;
  xIcmpMsgData.oIfIdx = oSrcIfIdx;
  xIcmpMsgData.wVlan = wSrcVlan;
  ASSERT(pxNetworkId->oIfIdx < ROUTER_MAXNUM_IF);
  xIcmpMsgData.wMtu = pxRouter->awMtu[pxNetworkId->oIfIdx];

  NETPAYLOAD_ADDUSER(pxNetPacket->pxPayload);

  /*
   * send an ICMP Dest Unreachable message to the source address
   */
  ASSERT(pxRouter->pfnNetCbk != NULL);
  pxRouter->pfnNetCbk((H_NETINSTANCE) pxRouter,
                      oCbkMsg,
                      (H_NETDATA)&xIcmpMsgData);

  return;
}
