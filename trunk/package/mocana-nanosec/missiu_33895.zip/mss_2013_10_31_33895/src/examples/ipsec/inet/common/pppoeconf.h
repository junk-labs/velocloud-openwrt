/*
 * pppoeconf.h
 *
 * PPPoE client link configuration common API.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPPOECONF_H_
#define _PPPOECONF_H_

/****************************************************************************
 *
 * defines
 *
 ****************************************************************************/


/****************************************************************************
 *
 * API
 *
 ****************************************************************************/

/*
 * PppoEConfSetup
 *  Specific setup for straight PPPoE interfaces
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   NETLINKLEG
 */
LONG PppoEConfSetup(NETIFCONF *pxIfConf,OCTET oIfIdx);

/*
 * PppoEConfOpen
 *  Specific openings for straight PPPoE interfaces
 *
 *  Args:
 *   pxIfConf           interface conf structure
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG PppoEConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx);

/*
 * PppoEConfProcess
 *  straight PPPoE link processing
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG PppoEConfProcess(NETIFCONF *pxIfConf, OCTET oIfIdx);

/*
 * PppoEConfClose
 *  PPPoE specific if close
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return 0
 */
LONG PppoEConfClose(NETIFCONF *pxIfConf, OCTET oIfIdx);

/*
 * PppoEConfDestroy
 *  PPPoE specific if destroy
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG PppoEConfDestroy(NETIFCONF *pxIfConf, OCTET oIfIdx);



/*
 * NetAdminPppoECbk
 *  Network wrapper PppoE Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminPppoECbk(H_NETINSTANCE hInst,
                      OCTET oCbk,
                      H_NETDATA hData);


LONG PppoEPlumbing(NETIFCONF *pxIfConf);

#endif /* #ifndef _PPPOECONF_H_ */
