/*API file for the SNMP aware TCP IP library */
/*#include "snmp_tcpip_data.h" */

/* General TCP/IP data gathering routines */
DWORD TcpipSnmpGetData(DWORD , void *);
DWORD TcpipSnmpSetData(DWORD , void *);

/* ARP Table Routines */
DWORD TcpipSnmpGetArpTable(void **, DWORD *, DWORD *);
DWORD TcpipSnmpAddArpTableEntry(DWORD dwIfNos, DWORD dwIP, OCTET *poMacAddr);

/* Address Entry Table Routine */
DWORD TcpipSnmpGetAdEntTable(void **, DWORD *, DWORD *);

/* udpEntry Table Routine */
DWORD TcpipSnmpGetUdpEntryTable(void **, DWORD *, DWORD *);

/* tcpEntry Table Routine */
DWORD TcpipSnmpGetTcpEntryTable(void **, DWORD *, DWORD *);

/* ipNetToMedia Table Routine */
DWORD TcpipSnmpGetNetToMediaTable(void **, DWORD *, DWORD *);

/* ifEntry Table routine */
DWORD TcpipSnmpGetIfTable(void **, DWORD *, DWORD *);

/* ifX Table routine */
DWORD TcpipSnmpGetifXTable(void **, DWORD *, DWORD *);

/* routing Table routine */
DWORD TcpipSnmpGetRoutingTable(void **, DWORD *, DWORD *);

DWORD TcpipSnmpGetIfOperStatus(DWORD);

DWORD TcpipSnmpAddipNetToMediaTableEntry(DWORD, OCTET *, DWORD);

int DeleteTCB(DWORD , WORD , DWORD , WORD );

