/*
 * casestat.h
 *
 * macros to use in place of "case" for adding measuring things like "time in case", "# breaks without advance", ...
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __CASE_H__
#define __CASE_H__



/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

/* add VxWorks hardware.h to take care of getting timer ticks */
#if defined(_LINUX) || defined(_SUNOS) || defined(_VXWORKS)
#  include "time.h"
#else
#  include "hardware.h"
#endif

#include "NNstyle.h"
#include "xstat.h"


/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/

#if defined(LINUX) || defined(SUNOS)
#define CSTAT_TIMER clock()
#else
#define CSTAT_TIMER HW_GET_TIMER(0)
#endif

#ifdef CASE_STATS

#define CASE_STAT_DEFS(l, max)                        \
    CASE_STAT a##l##CaseStats[1 + (max)];                \
    DWORD e##l##CurrCase = (max);                    \
    DWORD e##l##MaxCase = (max)

#define CASE_STAT_REPORT(l, s) do {                    \
      printf("CASE_STAT_REPORT(" #l ", %d)\n", (s));        \
      CaseStatReport(&(a##l##CaseStats[0]), (s));            \
    } while (0)
#define CASE_STAT_REPORT_ALL(l) do {                    \
      printf("CASE_STAT_REPORT_ALL(" #l ")\n");            \
      CaseStatReportAll(&(a##l##CaseStats[0]), e##l##MaxCase);    \
    } while (0)


#define CASE_ENTER(l, s) do {                        \
  DWORD dwInTimer = CSTAT_TIMER;                    \
  a##l##CaseStats[(s)].dwInTimer = dwInTimer;                \
  if (e##l##CurrCase != (s)) {                        \
    /* entering from another case */                    \
    e##l##CurrCase = (s);                        \
    a##l##CaseStats[(s)].dwInTime = 0;                    \
    a##l##CaseStats[s].dwIns = 1;                    \
    a##l##CaseStats[(s)].dwOutTime = 0;                    \
    a##l##CaseStats[s].dwOuts = 0;                    \
  } else {                                \
    /* reentering after a break */                    \
    DWORD dwOutTime =                            \
      dwInTimer - a##l##CaseStats[(s)].dwOutTimer;            \
    dwOutTime += a##l##CaseStats[(s)].dwOutTime;            \
    a##l##CaseStats[(s)].dwOutTime = dwOutTime;                \
    a##l##CaseStats[s].dwIns++;                        \
  }                                    \
} while (0)

#define CASE_SUSPEND(l) do {                        \
  DWORD s = e##l##CurrCase;                        \
  DWORD dwOutTimer = CSTAT_TIMER;                    \
  DWORD dwInTime =                            \
      dwOutTimer - a##l##CaseStats[s].dwInTimer;            \
  dwInTime += a##l##CaseStats[s].dwInTime;                \
  a##l##CaseStats[s].dwInTime = dwInTime;                \
  a##l##CaseStats[s].dwOuts++;                        \
  a##l##CaseStats[(s)].dwOutTimer = dwOutTimer;                \
} while (0)

#define CASE_DONE(l) do {                        \
  DWORD s1 = e##l##CurrCase;                        \
  CASE_SUSPEND(l);                            \
  XSTAT_RECORD(a##l##CaseStats[s1].xStatIns, a##l##CaseStats[s1].dwIns); \
  XSTAT_RECORD(a##l##CaseStats[s1].xStatInTime,             \
        a##l##CaseStats[s1].dwInTime);                \
  XSTAT_RECORD(a##l##CaseStats[s1].xStatOuts, a##l##CaseStats[s1].dwOuts); \
  XSTAT_RECORD(a##l##CaseStats[s1].xStatOutTime,            \
        a##l##CaseStats[s1].dwOutTime);                \
  e##l##CurrCase = e##l##MaxCase;                    \
} while (0)



#else /* #ifdef CASE_STATS */

#define CASE_STAT_DEFS(l, max)

#define CASE_STAT_REPORT(l, s)
#define CASE_STAT_REPORT_ALL(l)

#define CASE_ENTER(l, s)
#define CASE_SUSPEND(l)
#define CASE_DONE(l)

#endif /* #ifdef CASE_STATS else  */

/********************************************************************
 *
 * Typedefs
 *
 ********************************************************************/

typedef struct {
  /*
   * InTime   is cycles executing instructions in this state
   * OutTime  is cycles during breaks, but still in this state
   *
   * InTime + OutTime =
   *  (current clock) - (clock at entering this state)
   */
  DWORD  dwIns;            /* # (re)entries into state */
  XSTAT  xStatIns;        /* stats for # (re)entries */
  DWORD  dwInTimer;        /* clock at (re)entry of state */
  DWORD  dwInTime;        /* # cycles so far executing this state */
  XSTAT  xStatInTime;        /* stats for in-time in this state */
  DWORD  dwOuts;        /* # breaks/leaves from state */
  XSTAT  xStatOuts;        /* stats for # breaks/leaves */
  DWORD  dwOutTimer;        /* clock at break, possibly to other state */
  DWORD  dwOutTime;        /* # cycles so far in breaks */
  XSTAT  xStatOutTime;        /* stats for out-time in this state */
} CASE_STAT;


/********************************************************************
 *
 * Functional API
 *
 ********************************************************************/

MOC_EXTERN void CaseStatReport(CASE_STAT *pStats, DWORD eState);
MOC_EXTERN void CaseStatReportAll(CASE_STAT *pStats, DWORD dwMax);



#endif    /* __CASE_H__ */
