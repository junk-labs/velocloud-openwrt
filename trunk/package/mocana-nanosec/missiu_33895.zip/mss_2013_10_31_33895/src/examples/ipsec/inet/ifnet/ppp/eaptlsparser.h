/*
 * eaptlsparser.h
 *
 * EAPTLS parsing library
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _EAPTLSPARSER_H_
#define _EAPTLSPARSER_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/
/*
 * CHAP parsing macros
 */
#define EAPTLS_HLEN 4

#define EAPTLSOFFSET_TYPE 0


/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

#define EAPTLSOFFSET_LENGTH 2
#define EAPTLSGET_LENGTH(poPacket) ntohs((*((WORD *)(poPacket + EAPTLSOFFSET_LENGTH))))


#define EAPTLSOFFSET_DATA 0
#define EAPTLSGET_DATAPOINTER(poPacket) (poPacket + EAPTLSOFFSET_DATA)

/*
 * EAPTLS packet types
 */
typedef enum {
  EAPTLSPACKETTYPE_CHALLENGE = 1,
  EAPTLSPACKETTYPE_RESPONSE,
  EAPTLSPACKETTYPE_SUCCESS,
  EAPTLSPACKETTYPE_FAILURE
} E_EAPTLSPACKETTYPE;


#endif /* #ifndef _EAPTLSPARSER_H_ */
