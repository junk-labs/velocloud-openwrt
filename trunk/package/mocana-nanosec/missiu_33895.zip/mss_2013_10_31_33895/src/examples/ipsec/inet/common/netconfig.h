/*
 * netconfig.h
 *
 * Network module configuration utilities
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETCONFIG_H_
#define _NETCONFIG_H_

/****************************************************************************
 *
 * Defines
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Typedefs
 *
 ****************************************************************************/
typedef enum {
  NETCONFSTATE_INIT = 0,   /* Initial state */
  NETCONFSTATE_SETUP = 1,  /* setup done    */
  NETCONFSTATE_CLOSED = 1,  /* Closed        */
  NETCONFSTATE_OPENED = 2,  /* Opened        */

} E_NETCONF_STATE;
/*
 * NETCONFSETTING structure
 *  Defines argument for pfnInstanceSet
 */
typedef struct {
  OCTET oCode; /* Code 0xFF means no msg */
  H_NETDATA hData;
} NETCONFSETTING;

/*
 * NETCONFMSG structure
 *  Defines arguments for pfnInstanceMsg
 */
typedef NETCONFSETTING NETCONFMSG;

/*
 * NETCONFSCALARIOCTL structure
 *  Defines arguments for a scalar(== data is not a handle, nor
 *  a pointer == not a plumbing) ioctl
 */
typedef NETCONFMSG NETCONFSCALARIOCTL;
/*
 * NETIF structure
 *  Gather all needed info for an interface configuration
 */

typedef struct {
  /* Non-plumbing ioctls for this interface,
     not including the final open done in NetConfOpen and the SETWRITE
     and SETRCVCBK, which are done automatically */
  OCTET oIoctlNum;  /* Number of scalar ioctls */
  const NETCONFSCALARIOCTL *pxScalarIoctl; /* Table */

  union {
    struct ul {
      OCTET oValid;    /* Valid entry */
      OCTET oLibIdx; /* -1 means don't care */
      OCTET oInstIdx;/* -1 means don't care */
      OCTET oIfIdx;/* -1 means don't care */
    } xUL;
    struct ll {
      OCTET oValid;  /* Valid entry */
      OCTET oLibIdx; /* -1 means don't care */
      OCTET oInstIdx;/* -1 means don't care */
      OCTET oIfIdx;/* -1 means don't care */
    } xLL;
  } u; /* used for plumbing: allow to retrieve the arguments
          of the SETHUL/SETHLL and SETIF ioctls in the NETCONF
          structure. Note: if this info is not part of the
          NETCONF structure, then a scalar ioctl will have to
          be used */

} NETCONFIFTEMPLATE;

/*
 * NETINSTANCE structure
 *  Gather all info necessary for the configuration of the instance
 */
typedef struct {
  OCTET oSettingNum; /* Number of settings */
  const NETCONFSETTING *pxSetting; /* All settings registered here must be
                            scalar. invalid ones will be marked with
                            0xFF code */

  OCTET oULNum; /* Number of UL interfaces */
  const NETCONFIFTEMPLATE *pxULIf; /* UL interface array */

  OCTET oLLNum; /* Number of LL interfaces */
  const NETCONFIFTEMPLATE *pxLLIf; /* LL interface array */

  OCTET oMsgNum; /* Number of messages */
  NETCONFMSG *pxMsg; /* should not not include OPEN */
} NETCONFINSTANCETEMPLATE;

/*
 * NETCONFINSTANCE
 *  Gathers all the handles used by an instance
 *  Must be used in conjunction with a NETCONFINSTANCETEMPLATE
 */
typedef struct {
  H_NETINSTANCE hInst; /* Instance handle */
  DWORD dwNextCallTime; /* In msec */

  H_NETINSTANCE *phULIf; /* UL interface handle array. The number of
                            interfaces is provided by the oULNum member
                            of the coresponding NETCONFINSTANCETEMPLATE */
  H_NETINSTANCE *phLLIf;  /* LL interface handle array. The number of
                            interfaces is provided by the oULNum member
                            of the coresponding NETCONFINSTANCETEMPLATE */
} NETCONFINSTANCE;



/*
 * NETCONFLIBRARYTEMPLATE structure
 *  Gather all data necessary to initialize, configure and start up this
 *  library
 */
typedef struct {
  /* Library functions */
  PFN_NETINITIALIZE pfnInitialize;
  PFN_NETTERMINATE pfnTerminate;
  PFN_NETINSTANCECREATE pfnInstanceCreate;
  PFN_NETINSTANCEDESTROY pfnInstanceDestroy;

  /* Instance functions */
  PFN_NETINSTANCESET pfnInstanceSet;
  PFN_NETMSG pfnInstanceMsg;
  PFN_NETINSTANCEINTERFACECREATE pfnInstanceULInterfaceCreate;
  PFN_NETINSTANCEINTERFACECREATE pfnInstanceLLInterfaceCreate;
  PFN_NETWRITE pfnInstanceWrite;
  PFN_NETRXCBK pfnInstanceRcv;
  PFN_NETINSTANCEPROCESS pfnInstanceProcess;

  /* UL Interface functions */

  PFN_NETINSTANCEINTERFACEDESTROY pfnInstanceULInterfaceDestroy;
  PFN_NETIOCTL pfnInstanceULInterfaceIoctl;

  /* LL Interface function */
  PFN_NETINSTANCEINTERFACEDESTROY pfnInstanceLLInterfaceDestroy;
  PFN_NETIOCTL pfnInstanceLLInterfaceIoctl;

  PFN_NETCBK pfnNetAdminCbk;
  const NETCONFINSTANCETEMPLATE *pxInstanceTemplate;
} NETCONFLIBRARYTEMPLATE;

/*
 * Network configuration main structure
 */
typedef struct {
  E_NETCONF_STATE eState;

  NETCONFLIBRARYTEMPLATE **ppxLibTemplate;
  NETCONFINSTANCE *pxNetConfInstance; /* Contains instance handle info.
                                  size is given by the dwInstanceNum
                                  of the coresponding NETCONFLIBRARYTEMPLATE
                                  */
  DWORD dwLibNum; /* could be a byte, but there would be 3 bytes
                     wasted anyway */
} NETCONF;


/*****************************************************************************
 *
 * API function
 *
 *****************************************************************************/


/*
 * NetConfSetup
 *  Set up all libraries in the NETCONF argument, and open them
 *  If a problem occurs, it will close/terminate all libraries
 *  and return -1. Netconf must be in NETCONFSTATE_INIT state.
 *  NetConfOpen will proceed as follow (if no error occurs)
 *   1. Initialize all libraries in pxNetConf
 *   2. (Creates + (set option for) + (creates/scalar-ioctls all interfaces
 *      for)) *(all instances for all libraries)
 *   3. Plumbs all interfaces (non-scalar ioctls).
 *   4. return 0;
 *
 *   Notes:
 *   -If the pfnInitialize is not set, the code will assume that the
 *   library has been initialized
 *   -If the pfnInstanceCreate is not set, the code will just proceed
 *   as if the instance had been created before-hand.
 *   -If the pfnCbk for the instance is NULL, it will not be registered
 *   -If the pfnInstanceULInterfaceCreate or pfnInstanceLLInterfaceCreate
 *   have not been set for the library, the interfaces will be assumed
 *   to exist.
 *
 *  Args:
 *   pxNetConf             NetConf
 *
 *  Return:
 *   >=0 for success
 */
LONG NetConfSetup(NETCONF *pxNetConf);

/*
 * NetConfOpen
 *  Open all registered instances and interfaces
 *
 *  Args:
 *   pxNetConf            NetConf
 *
 *  Return:
 *   >=0 for success
 */
LONG NetConfOpen(NETCONF *pxNetConf);

/*
 * NetConfClose
 *  Close all interfaces and all instances
 *
 *  Args:
 *   pxNetConf           NetConf
 *
 *  Return:
 *   >=0 for success
 */
LONG NetConfClose(NETCONF *pxNetConf);

/*
 * NetConfProcess
 *  Calls the process functions of all registered instances
 *  which need it
 *
 *  Args:
 *   pxNetConf
 *
 *  Return:
 *   delay (in msec) till next needed call
 */
LONG NetConfProcess(NETCONF *pxNetConf);

/*
 * NetConfTearDown
 *  Tears down the provided netconf: if not closed closes,
 *  destroy and terminates
 *  All registered items.
 *
 *  Args:
 *   pxNetConf             NetConf
 *
 *  Return:
 *   >=0 for success
 */
LONG NetConfTearDown(NETCONF *pxNetConf);


#endif /* #ifndef _NETCONFIG_H_ */





















