/*
 * cstatrpt.c
 *
 * implement Case Stat Reporting
 *    (this keeps printf calls out of NDEBUG makes if
 *     CaseStatReport() not called)
 *
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

#include <stdio.h>

#include "NNstyle.h"

#ifndef CASE_STATS
#define CASE_STATS
#endif

#include "casestat.h"


/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Typedefs
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Global Variables
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Static Variables
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Static Function Declarations
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Static Functions
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Public Functions
 *
 ********************************************************************/


/*
 * CaseStatReport
 *     print Case Stat for a state
 *
 * Arguments:
 *      pCaseStat    the addr of CaseStat[0]
 *    eState        the state
 * Returns:
 *      none
 */
void CaseStatReport(CASE_STAT *pStats, DWORD eState)
{

  XSTAT *pXstat;

  printf("\nCase Stats for %lu\n", (long unsigned) eState);
  printf("\n(Re)Entry count stats:\n");
  pXstat = &((*(pStats + eState)).xStatIns);
  printf("#state changes = 0x%08lX\n", pXstat->dwCnt);
  printf("(re)entries per state change min = 0x%08lX, max = 0x%08lX\n",
     pXstat->dwMin, pXstat->dwMax);
  printf("total (re)entries = 0x%08lX 0x%08lX\n",
     pXstat->ddTotal.dwHi, pXstat->ddTotal.dwLo);
  SaHist8Report(&(pXstat->xHist));

  printf("\nIn-Time stats:\n");
  pXstat = &((*(pStats + eState)).xStatInTime);
  printf("#state changes = 0x%08lX\n", pXstat->dwCnt);
  printf("In-Time per state change min = 0x%08lX, max = 0x%08lX\n",
     pXstat->dwMin, pXstat->dwMax);
  printf("total In-Time = 0x%08lX 0x%08lX\n",
     pXstat->ddTotal.dwHi, pXstat->ddTotal.dwLo);
  SaHist8Report(&(pXstat->xHist));

  printf("\nBreak/Leave count stats:\n");
  pXstat = &((*(pStats + eState)).xStatOuts);
  printf("#state changes = 0x%08lX\n", pXstat->dwCnt);
  printf("break/leaves per state change min = 0x%08lX, max = 0x%08lX\n",
     pXstat->dwMin, pXstat->dwMax);
  printf("total breaks/leaves = 0x%08lX 0x%08lX\n",
     pXstat->ddTotal.dwHi, pXstat->ddTotal.dwLo);
  SaHist8Report(&(pXstat->xHist));

  printf("\nOut-Time stats:\n");
  pXstat = &((*(pStats + eState)).xStatOutTime);
  printf("#state changes = 0x%08lX\n", pXstat->dwCnt);
  printf("Out-Time per state change min = 0x%08lX, max = 0x%08lX\n",
     pXstat->dwMin, pXstat->dwMax);
  printf("total Out-Time = 0x%08lX 0x%08lX\n",
     pXstat->ddTotal.dwHi, pXstat->ddTotal.dwLo);
  SaHist8Report(&(pXstat->xHist));
}


/*
 * CaseStatReportAll
 *     print Case Stat for a all states
 *
 * Arguments:
 *      pCaseStat    the addr of CaseStat[0]
 *    eMax        max state
 * Returns:
 *      none
 */
void CaseStatReportAll(CASE_STAT *pStats, DWORD dwMax)
{
  DWORD i;

  printf("\n\nCase Stats at 0x%08lX:\n", (long unsigned) pStats);
  for (i = 0; i <= dwMax; i++) {
    printf("    State %lu", (long unsigned) i);
    if (i == dwMax)
      printf(" (overflow state)");
    printf("\n");
    CaseStatReport(pStats, i);
  }

}




