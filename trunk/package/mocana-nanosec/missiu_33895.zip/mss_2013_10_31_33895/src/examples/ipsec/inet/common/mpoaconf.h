/*
 * mpoaconf.h
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _MPOACONF_H_
#define _MPOACONF_H_

/****************************************************************************
 *
 * extern
 *
 ****************************************************************************/

MOC_EXTERN NETCONFLIBRARYTEMPLATE *apxMpoaLibTemplate[1];

/****************************************************************************
 *
 * API
 *
 ****************************************************************************/
#if 0
/*
 * MpoaConfSetup
 *  Specific setup for straight ethernet interfaces
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   NETLINKLEG
 */
LONG MpoaAtmConfSetup(NETIFCONF *pxIfConf,OCTET oIfIdx);

#endif
/*
 * MpoaConfOpen
 *  Specific openings for straight ethernet interfaces
 *
 *  Args:
 *   pxIfConf           interface conf structure
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG MpoaAtmConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx);

/*
 * MpoaConfProcess
 *  straight ethernet link processing
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG MpoaAtmConfProcess(NETIFCONF *pxIfConf, OCTET oIfIdx);

/*
 * MpoaConfClose
 *  Mpoaernet specific if close
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return 0
 */
LONG MpoaConfClose(NETIFCONF *pxIfConf, OCTET oIfIdx);

/*
 * MpoaConfDestroy
 *  Mpoaernet specific if destroy
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG MpoaConfDestroy(NETIFCONF *pxIfConf, OCTET oIfIdx);


LONG MpoaLinkSetup(NETIFCONF *pxIfConf,OCTET oIfIdx);

/***********************************************************
 *
 * Plumbing function
 *
 ***********************************************************/

LONG EthoAPlumbing(NETIFCONF *pxIfConf);
LONG PppoEoAPlumbing(NETIFCONF *pxIfConf);
LONG PppoAPlumbing(NETIFCONF *pxIfConf);
LONG IpoAPlumbing(NETIFCONF *pxIfConf);

/***********************************************************
 *
 * IpoA function
 *
 ***********************************************************/

LONG IpoAConfSetup(NETIFCONF *pxIfConf,OCTET oIfIdx);
LONG IpoAConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx);
LONG IpoAConfClose(NETIFCONF *pxIfConf,OCTET oIfIdx);
LONG IpoAConfDestroy(NETIFCONF *pxIfConf,OCTET oIfIdx);
LONG IpoAConfProcess(NETIFCONF *pxIfConf,OCTET oIfIdx);
#endif /* #ifndef _MPOACONF_H_ */
