/*
 * arpdbg.h
 *
 * Arp module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ARPDBG_H_
#define _ARPDBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef ARPDBG_HI
   #define ARPDBG_HI
  #endif
 #endif

#else
 #ifdef ARPDBG_HI
  #undef ARPDBG_HI
 #endif
#endif

#include "netdbg.h"

#define ARP_MAGIC_COOKIE 0x61727000 /*"arp" = 0x61727000*/
#define DBGLVL_ERROR_RARE 1
#define DBGLVL_NORMAL     2
#define DBGLVL_REPETITIVE 3

/* #ifdef ARPDBG_HI */
#if defined(ARPDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  /* Debug levels */
  MOC_EXTERN DWORD g_dwArpDebugLevel;

  #define ARP_DBG_ASSERT(x) ASSERT(x)

  #define ARP_CHECK_STATE(x) \
            ASSERT((x != NULL) && ((x)->dwMagicCookie == ARP_MAGIC_COOKIE));

  #define ARP_SET_COOKIE(x) (x)->dwMagicCookie = ARP_MAGIC_COOKIE
  #define ARP_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define ARP_DBGP(level, fmt, args...) do { \
    if (level <= g_dwArpDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define ARP_DBG(level, x) do {  \
    if (level <= g_dwArpDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define ARP_DBG_VAR(x)  x

  #define ARP_CHECKPOINT(A) A = __LINE__
#else
  #define ARP_DBG_ASSERT(x)
  #define ARP_CHECK_STATE(x)
  #define ARP_SET_COOKIE(x)
  #define ARP_UNSET_COOKIE(x)
#if defined (__RTOS_VXWORKS__)
  #define ARP_DBGP
#else
  #define ARP_DBGP(level, fmt, args...)
#endif

  #define ARP_DBG(level, x)
  #define ARP_DBG_VAR(x)
  #define ARP_CHECKPOINT(A)
#endif


ARP_DBG_VAR(MOC_EXTERN DWORD dbg_dwArpRxCbkLine);
ARP_DBG_VAR(MOC_EXTERN DWORD dbg_dwArpRefreshLine);
ARP_DBG_VAR(MOC_EXTERN DWORD dbg_dwArpPrintTable);
ARP_DBG_VAR(MOC_EXTERN DWORD dbg_dwArpPrintHash);
ARP_DBG_VAR(MOC_EXTERN DWORD dbg_dwArpNumCurrentEntries);
ARP_DBG_VAR(MOC_EXTERN DWORD dbg_dwArpMaxEntries);

#endif /* #ifndef _ARPDBG_H_ */
