/*
 * ethconf.c
 *
 * ethernet link configuration code
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include <mqueue.h>
#include "netdb.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/if_types.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netconfig.h"
#include "netdefs.h"
#include "netmain.h"
#include "linkconf.h"
#include "netif.h"
#include "ethernet.h"
#include "arp.h"
#include "ip2eth.h"
#include "ethconf.h"
#include "ethlink.h"


/****************************************************************************
 *
 * debug
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Local functions
 *
 ****************************************************************************/

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * EthConfSetup
 *  Specific setup for straight ethernet interfaces
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   NETLINKLEG
 */
LONG EthConfSetup(NETIFCONF *pxIfConf,OCTET oIfIdx)
{

  NETIFSTATE *pxIfState;
  H_NETINSTANCE hEth,hIp2Eth,hArp;
  H_NETINTERFACE hEthUlIf,hIp2EthLlIf,hIp2EthUlIf,hEthLlIf;
  NETCONFINSTANCE  *pxEthInst;
  ETHIFTOLL xEthIfToLL;
  static OCTET oFirst = 0;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      /* NETMAIN_DBGP(NORMAL,"EthConfSetup:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx); */
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"EthConfSetup:pxIfConf=0x",(int)pxIfConf);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,",oIfIdx=",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  hArp        = NETGETINST_ARP;
  hEth        = NETGETINST_ETH;
  hIp2Eth     = NETGETINST_IP2ETH;

  pxEthInst   = NETGETCONFINST_ETH;
  hIp2EthLlIf = NETGETIF_IP2ETHLL;
  hIp2EthUlIf = NETGETIF_IP2ETHUL;

  pxIfState->hTopLinkInst        = hIp2Eth;
  pxIfState->hTopLinkIf          = hIp2EthUlIf;
  pxIfState->pfnTopLinkWrite     = Ip2EthInstanceWrite;
  pxIfState->pfnTopLinkUlIfIoctl = Ip2EthInstanceULInterfaceIoctl;

  if ( oFirst == 0 ){ /* RS: only have to do it once */
  oFirst = 1;
  /* Misc configuration */
  /* Eth UL interface to IP */
  hEthUlIf = EthInstanceULInterfaceCreate(hEth);
  NETSETIF_ETHUL(pxIfState,hEthUlIf);

  EthInstanceULInterfaceIoctl(hEth,hEthUlIf,NETINTERFACEIOCTL_SETROUTINGID,
                              (H_NETDATA)ETHID_IP);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIf,NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hIp2Eth);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIf,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hIp2EthLlIf);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIf,NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)Ip2EthInstanceRcv);

  Ip2EthInstanceLLInterfaceIoctl(hIp2Eth,hIp2EthLlIf,
                                 NETINTERFACEIOCTL_SETHINST,(H_NETDATA)hEth);
  Ip2EthInstanceLLInterfaceIoctl(hIp2Eth,hIp2EthLlIf,
                                 NETINTERFACEIOCTL_SETIF,
                                 (H_NETDATA)hEthUlIf);
  Ip2EthInstanceLLInterfaceIoctl(hIp2Eth,hIp2EthLlIf,
                                 NETINTERFACEIOCTL_SETOUTPUTPFN,
                                 (H_NETDATA)EthInstanceWrite);

  Ip2EthInstanceSet(hIp2Eth,IP2ETHOPTION_SETARPINSTANCE,(H_NETDATA)hArp);

  } /* if (oIfIdx == 0) */

  /*Create and configure the Eth LL If */
  hEthLlIf = EthInstanceLLInterfaceCreate(hEth);
  NETSETIF_ETHLL(pxIfState,hEthLlIf);

  xEthIfToLL.oIfIdx = oIfIdx;
  xEthIfToLL.hLlIf  = hEthLlIf;
  EthInstanceSet(hEth,ETHOPTION_IFTOLLMAP,(H_NETDATA)&xEthIfToLL);

#ifdef LINK_AGGREGATION   /* move to EthLinkSetup() */
  pxIfState->hBottomLinkIf = NETGETIF_ETHLL(pxIfState);
  pxIfState->hBottomLinkInst = hEth;
  pxIfState->pfnBottomLinkRxCbk = EthInstanceRcv;
  pxIfState->pfnBottomLinkLlIfIoctl = EthInstanceLLInterfaceIoctl;
#endif
  return 0;
}

/*
 * EthConfOpen
 *  Specific openings for straight ethernet interfaces
 *
 *  Args:
 *   pxIfConf           Interface conf structure
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG EthConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState = NETGETIFSTATE(pxIfConf);
  H_NETINSTANCE hEth, hArp;

  /* NETMAIN_DBGP(NORMAL,"EthConfOpen:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"EthConfOpen:pxIfConf=0x",(int)pxIfConf);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,",oIfIdx=",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  hEth = NETGETINST_ETH;
  hArp = NETGETINST_ARP;

  NETMAIN_ASSERT(pxIfState != NULL);

  {
    ETHID xId;
    xId.oIfIdx = oIfIdx;
    xId.wVlan = pxIfConf->wVlan;
    EthInstanceMsg(hEth,ETHMSG_SETLLDEFAULTVLAN,(H_NETDATA)&xId);
  }

#ifdef NET_BR
  /* Inform the eth module of the bridged LL interfaces */
  {
    OCTET oMsg;
    if (pxIfConf->xEthConf.obBridge == TRUE) {
      oMsg = ETHMSG_ENABLEBRIDGE;
    }
    else {
      oMsg = ETHMSG_DISABLEBRIDGE;
    }
    EthInstanceMsg(hEth,oMsg,(H_NETDATA)oIfIdx);
  }

  /* Set the eth module Broadcast and Multicast limits on this if */
  {
    ETHIFLIMIT xEthLimit;
    xEthLimit.oIfIdx = oIfIdx;
    xEthLimit.oPercent = pxIfConf->xEthConf.oBcastLimit;
    EthInstanceMsg(hEth,ETHMSG_SETIFBCASTLIMIT,(H_NETDATA)&xEthLimit);
    xEthLimit.oPercent = pxIfConf->xEthConf.oMcastLimit;
    EthInstanceMsg(hEth,ETHMSG_SETIFMCASTLIMIT,(H_NETDATA)&xEthLimit);
  }
#endif /*#ifdef NET_BR*/

  /* Set the eth module hardware address*/
  {
    ETHID xId;
    xId.oIfIdx = oIfIdx;
    MOC_MEMCPY((ubyte *)xId.aoAddr, (ubyte *)pxIfConf->aoHWAddr, ETHADDRESS_LEN);
    EthInstanceSet(hEth,ETHOPTION_MACADDR,(H_NETDATA)&xId);
  }

  /* Set the eth address in ARP too */
  {
    ARPETHDATA xEth;
    MOC_MEMCPY((ubyte *)xEth.aoEthAddr,(ubyte *)pxIfConf->aoHWAddr,ARP_ETHLEN);
    xEth.oIfIdx = oIfIdx;
    ArpInstanceSet(hArp,ARPOPTION_ETHADDRESS,(H_NETDATA)&xEth);
  }

  /* Open Eth interfaces */
  EthInstanceLLInterfaceIoctl(hEth,NETGETIF_ETHLL(pxIfState),
                              NETINTERFACEIOCTL_OPEN,(H_NETDATA)0);

  return 0;
}

/*
 * EthConfProcess
 *  straight ethernet link processing
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG EthConfProcess(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  return 0;
}

/*
 * EthConfClose
 *  Ethernet specific if close
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx             Interface index
 *
 *  Return 0
 */
LONG EthConfClose(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hEth;

  /* NETMAIN_DBGP(NORMAL,"EthConfClose:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"EthConfClose:pxIfConf=0x",(int)pxIfConf);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,",oIfIdx=",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  ASSERT(pxIfConf != NULL);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  hEth = NETGETINST_ETH;

  /* Close interface if */
  EthInstanceLLInterfaceIoctl(hEth,NETGETIF_ETHLL(pxIfState),
                              NETINTERFACEIOCTL_CLOSE,(H_NETDATA)0);

  return 0;
}

/*
 * EthConfDestroy
 *  Ethernet specific if destroy
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG EthConfDestroy(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hEth;

  NETMAIN_ASSERT(pxIfConf != NULL);

  /* NETMAIN_DBGP(NORMAL,"EthConfDestroy:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"EthConfClose:pxIfConf=0x",(int)pxIfConf);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,",oIfIdx=",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }
  pxIfState = NETGETIFSTATE(pxIfConf);
  ASSERT(pxIfState != NULL);

  hEth = NETGETINST_ETH;

  EthInstanceLLInterfaceDestroy(hEth,NETGETIF_ETHLL(pxIfState));

  return 0;
}
