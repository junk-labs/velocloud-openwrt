/*
 * tcp_dbg.h
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __TCP_DBG_H__
#define __TCP_DBG_H__

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef TCPDBG_HI
   #define TCPDBG_HI
  #endif
 #endif

#else
 #ifdef TCPDBG_HI
  #undef TCPDBG_HI
 #endif
#endif

#include "netdbg.h"

#define TCPCONN_MAGIC_COOKIE 0x74637063 /*"tcpc" = 0x74637063*/
#define TCP_MAGIC_COOKIE 0x74637020 /*"tcp " = 0x74637020*/

/*#ifdef TCPDBG_HI*/
#if defined(TCPDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define TCPCONN_CHECK(x) \
            ASSERT( ((x) != NULL) && ((x)->dwMagicCookie == TCPCONN_MAGIC_COOKIE));

  #define TCP_CHECK_STATE(x) \
            ASSERT((x) && ((x)->dwMagicCookie == TCP_MAGIC_COOKIE));

  #define TCP_SET_COOKIE(x) (x)->dwMagicCookie = TCP_MAGIC_COOKIE

  #define TCP_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define TCP_DBGP(level, fmt, args...)  do {  \
    if (level <= g_dwTcpDebugLevel) {    \
      printf(fmt, ##args);        \
    }              \
  } while (0)

  #define TCP_DBG(level, x)  do {    \
    if (level <= g_dwTcpDebugLevel) {    \
      x;            \
    }              \
  } while (0)

  #define TCP_DBG_VAR(x)  x

  #define TCP_CHECKPOINT(x) (x = __LINE__)

  #define TCP_ASSERT_HI(x) ASSERT(x)

#else
  #define TCPCONN_CHECK(x)
  #define TCP_CHECK_STATE(x)
  #define TCP_SET_COOKIE(x)
  #define TCP_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define TCP_DBGP
#else
  #define TCP_DBGP(level, fmt, args...)
#endif
  #define TCP_DBG(level, x)
  #define TCP_DBG_VAR(x)
  #define TCP_CHECKPOINT(x)
  #define TCP_ASSERT_HI(x)
#endif

#define CHECKPOINT(x)
#define CHECKPOINTCLEAR(x)
#define CHECKPOINTCLEARRETX(x)
#define CHECKPOINTCLEARSND(x)


#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /*#ifndef __TCP_DBG_H__*/


