/*
 * nat_bind.c
 *
 * Creates a NAT binding.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "nat.h"
#include "nat_defs.h"


/**************************
 * Static Routines
 *************************/
static NAT_ENTRY* _NatCreateBinding(NATSTATE* pxNat,
                                    DWORD dwWanIp,
                                    WORD wWanPort,
                                    DWORD dwLanIp,
                                    WORD wLanPort,
                                    DWORD dwTransIP,
                                    WORD wTransPort,
                                    OCTET oIfIdx,
                                    OCTET oProtocol,
                                    E_NAT_BINDING eType);
static LONG _NatFindFreeSpot(DWORD adwStatus[], DWORD dwLength);
static void _NatLockSpot(DWORD adwStatus[], WORD wPort);
static DWORD _NatFindFirstZero(OCTET oData);
static NAT_ENTRY* _NatFindFreeBindingInChunks(NAT_CHUNK* apxNatChunks[],
                                              DWORD dwSize,
                                              OCTET* poNumUsedChunks,
                                              OCTET oNumAllowedChunks);


/*****************************************************************************
Function:
        NatCreateBindingTU()
Description:
        Creates a NAT binding for a TCP/UDP session.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        DWORD           dwWanIp         WAN IP address.
        WORD            wWanPort        WAN Port.
        DWORD           dwLanIp         LAN IP address.
        WORD            wLanPort        LAN Port.
        DWORD           dwTransIP       IP address for translation.
    WORD        wTransPort    Translated Port Number (used only
                    in some dynamic port forwarding
                    cases)
        OCTET           oIfIdx          Interface index.
        OCTET           oProtocol       Transport layer protocol
                                        (should be either TCP or UDP).
        E_NAT_BINDING   eType           Tpye of binding.
Outputs:
        None.
Returns:
        NAT_ENTRY*      non-NULL        Handle to the newly
                                        created binding.
                        NULL            If binding creation fails.
Revisions:
        13-Oct-2001                     Initial
*****************************************************************************/
NAT_ENTRY* NatCreateBindingTU(NATSTATE* pxNat,
                              DWORD dwWanIp, WORD wWanPort,
                              DWORD dwLanIp, WORD wLanPort,
                              DWORD dwTransIP, WORD wTransPort,
                  OCTET oIfIdx,
                              OCTET oProtocol,
                              E_NAT_BINDING eType)
{
  NAT_ENTRY* pxNatEntry;

  pxNatEntry = _NatCreateBinding(pxNat,
                                 dwWanIp, wWanPort,
                                 dwLanIp, wLanPort,
                                 dwTransIP, wTransPort,
                 oIfIdx,
                                 oProtocol, eType);

  if (pxNatEntry) {
    pxNatEntry->u.xTUMapping.wWanPort = wWanPort;
    pxNatEntry->u.xTUMapping.wLanPort = wLanPort;
  }


  NAT_DBG(DBGLVL_REPETITIVE, if (pxNatEntry) {
               printf("NatCreateBindingTU(): Bind %ld.%ld.%ld.%ld:%d <==> %ld.%ld.%ld.%ld:%d via %ld.%ld.%ld.%ld:%d <==> %ld.%ld.%ld.%ld:%d of type %s\n",
                        IPADDRDISPLAY(dwLanIp), wLanPort,
                        IPADDRDISPLAY(dwWanIp), wWanPort,
                        IPADDRDISPLAY(pxNatEntry->dwTransAddr), pxNatEntry->u.xTUMapping.wTransPort,
                        IPADDRDISPLAY(dwWanIp), wWanPort,
                        NatGetBindingName(eType));
             } else {
               printf("NatCreateBindingTU(): Could not create NAT binding\n");
             });

  return(pxNatEntry);
}


/*****************************************************************************
Function:
        NatCeateBindingIcmpQuery()
Description:
        Creates a NAT binding for an ICMP Query.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        DWORD           dwWanIp         WAN IP address.
        DWORD           dwLanIp         LAN IP address.
        DWORD           dwTransIP       IP address for translation.
        OCTET           oIfIdx          Interface index.
        WORD            wTransMsgId    Translated message id.
                    (used only for NAT_BINDING_LOCAL)
        WORD            wQueryId        ICMP Query identifier.
        E_NAT_BINDING   eType           Tpye of binding.
Outputs:
        None.
Returns:
        NAT_ENTRY*      non-NULL        Handle to the newly
                                        created binding.
                        NULL            If binding creation fails.
Revisions:
        16-Oct-2001                     Initial
*****************************************************************************/
NAT_ENTRY* NatCreateBindingIcmpQuery(NATSTATE* pxNat,
                                     DWORD dwWanIp, DWORD dwLanIp,
                                     DWORD dwTransIP, WORD wTransMsgId,
                     OCTET oIfIdx, WORD wQueryId,
                                     E_NAT_BINDING eType)
{
  NAT_ENTRY* pxNatEntry;

  pxNatEntry = _NatCreateBinding(pxNat, dwWanIp, 0, dwLanIp, 0,
                                 dwTransIP, wTransMsgId, oIfIdx, IPPROTO_ICMP, eType);

  if (pxNatEntry) {
    pxNatEntry->u.xIcmpMapping.wMsgId = wQueryId;
  }

  return(pxNatEntry);
}



/*****************************************************************************
Function:
        NatDeleteBinding()
Description:
        Deletes or unbinds a NAT binding.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        NAT_ENTRY*      pxNatEntry      The binding to be deleted.
Outputs:
        None.
Returns:
        None.
Revisions:
        13-Oct-2001                     Initial
*****************************************************************************/
void NatDeleteBinding(NATSTATE* pxNat, NAT_ENTRY* pxNatEntry)
{
  ASSERT(pxNatEntry);

  NAT_DBG(DBGLVL_NORMAL, if (pxNatEntry) {
               if ((pxNatEntry->oProtocolId == IPPROTO_UDP) ||
                   (pxNatEntry->oProtocolId == IPPROTO_TCP)) {
                 printf("NatDeleteBinding():lan=%ld.%ld.%ld.%ld:%d,wan=%ld.%ld.%ld.%ld:%d,trans=%ld.%ld.%ld.%ld:%d  %s  %s\n",
                        IPADDRDISPLAY(pxNatEntry->dwLanAddr), pxNatEntry->u.xTUMapping.wLanPort,
                        IPADDRDISPLAY(pxNatEntry->dwWanAddr), pxNatEntry->u.xTUMapping.wWanPort,
                        IPADDRDISPLAY(pxNatEntry->dwTransAddr), pxNatEntry->u.xTUMapping.wTransPort,
                        IpProtoToString(pxNatEntry->oProtocolId),
                        NatGetBindingName(pxNatEntry->eType));
               }

               if (pxNatEntry->oProtocolId == IPPROTO_ICMP) {
                 printf("NatDeleteBinding():lan=%ld.%ld.%ld.%ld,wan=%ld.%ld.%ld.%ld,trans=%ld.%ld.%ld.%ld  %d  %d  %s  %s\n",
                        IPADDRDISPLAY(pxNatEntry->dwLanAddr),
                        IPADDRDISPLAY(pxNatEntry->dwWanAddr),
                        IPADDRDISPLAY(pxNatEntry->dwTransAddr),
                        pxNatEntry->u.xIcmpMapping.wMsgId,
                        pxNatEntry->u.xIcmpMapping.wTransMsgId,
                        IpProtoToString(pxNatEntry->oProtocolId),
                        NatGetBindingName(pxNatEntry->eType));
               }
             } else {
               printf("NatFindTUBindingRx(): No Entry\n");
             });


  /*
   * Delete from LAN hash table
   */
  NatDeleteFromLanHashTable(pxNat, pxNatEntry);


  /*
   * Delete from Trans hash table
   */
  NatDeleteFromTransHashTable(pxNat, pxNatEntry);


  /*
   * Free the previously acquired port for translation
   * purposes.
   */
  if (pxNatEntry->eType == NAT_BINDING_L2W) {

    WORD wPort = NAT_NUM_ALLOCATED_PORTS + 1;
    WORD* pwPort = (WORD*) &pxNatEntry->u;

    if (*pwPort != 0) {
      wPort = *pwPort - NAT_PORT_BASE;
      ASSERT(wPort < NAT_NUM_ALLOCATED_PORTS);
      pxNat->adwPortStatus[wPort >> 5] &= ~(1 << (wPort & 0x1f));
    }
  }

  /*
   * Free the NAT binding
   */
  {
    NAT_CHUNK* pxNatChunk = pxNatEntry->pxNatChunk;
    DWORD dwSpot = pxNatEntry - &pxNatChunk->axNatBindings[0];
    ASSERT((pxNatChunk->adwBindingStatus[dwSpot >> 5] & (1 << (dwSpot & 0x1f))) != 0);
    pxNatChunk->adwBindingStatus[dwSpot >> 5] &= ~(1 << (dwSpot & 0x1f));
    ASSERT((pxNatChunk->adwBindingStatus[dwSpot >> 5] & (1 << (dwSpot & 0x1f))) == 0);
  }

  if (pxNatEntry->eType != NAT_BINDING_LOCAL) {
    pxNat->wNumBindingsActive --;
    ASSERT((SHORT) pxNat->wNumBindingsActive >= 0);
    DEBUG(g_dwNatTotalNumBindings = (DWORD) pxNat->wNumBindingsActive);
  }

  NAT_DBG(DBGLVL_REPETITIVE, g_adwNatNumActiveBindings[pxNatEntry->eType] --);

  return;
}


/*****************************************************************************
Function:
        _NatCreateBinding()
Description:
        Creates a generic NAT binding. Called by specific
        transport identifiers.
Arguments:
        NATSTATE*       pxNat           NAT Instance handle.
        DWORD           dwWanIp         WAN IP address.
        WORD            wWanPort        WAN port number
                                        (unused for ICMP).
        DWORD           dwLanIp         LAN IP address.
        WORD            wLanPort        LAN port number
                                        (unused for ICMP).
        DWORD           dwTransIp       IP address for translation.
    WORD        wTransPort    Translated Port Number (used only
                    in some dynamic port forwarding
                    cases)
        OCTET           oIfIdx          Interface index.
        OCTET           oProtocol       Transport layer protocol.
        E_NAT_BINDING   eType           Type of binding.
Outputs:
        None.
Returns:
        NAT_ENTRY*      non-NULL        Handle to the newly
                                        created binding.
                        NULL            If binding creation fails.
Revisions:
        13-Oct-2001                     Initial
*****************************************************************************/
static NAT_ENTRY* _NatCreateBinding(NATSTATE* pxNat,
                                    DWORD dwWanIp,
                                    WORD wWanPort,
                                    DWORD dwLanIp,
                                    WORD wLanPort,
                                    DWORD dwTransIp,
                    WORD wTransPort,
                                    OCTET oIfIdx,
                                    OCTET oProtocol,
                                    E_NAT_BINDING eType)
{
  NAT_ENTRY *pxNatEntry = NULL;
  DWORD dwIdx;
  WORD* pwTrans;

  if ((eType != NAT_BINDING_LOCAL) && (pxNat->wNumBindingsActive >= pxNat->wNumBindingsMax)) {
    return (NULL);
  }


  /*
   * Do not create a binding if the LAN IP address is not
   * on the same subnet as the LAN interface IP address of
   * the CPE or one of the CPE's IP addresses.
   */
  if (eType != NAT_BINDING_LOCAL) {
    IPTABLEENTRY xIpEntry;

    xIpEntry.dwAddr = dwLanIp;
    xIpEntry.wDefaultVlan = NETVLAN_ANY;
    xIpEntry.oIfIdx = pxNat->oIfIdxLan;

    if (IPADDRT_MYSUBNET != IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry)) {
      return (NULL);
    }
  }

  NAT_DBG(DBGLVL_REPETITIVE, printf("_NatCreateBinding():lan=%ld.%ld.%ld.%ld:%d,wan=%ld.%ld.%ld.%ld:%d  %s  %s\n",
                        IPADDRDISPLAY(dwLanIp), wLanPort,
                        IPADDRDISPLAY(dwWanIp), wWanPort,
                        IpProtoToString(oProtocol),
                        NatGetBindingName(eType));
             );


  if (eType == NAT_BINDING_LOCAL) {
    /*
     * Find a free LOCAL NAT binding
     */
    pxNatEntry = _NatFindFreeBindingInChunks(pxNat->apxNatChunksLocal, NAT_CHUNK_MAX_NUM_LOCAL,
                                             &pxNat->oNumUsedLocalChunks, NAT_CHUNK_MAX_NUM_LOCAL);
  } else {
    /*
     * Find a free non-LOCAL NAT binding
     */
    NatSortChunks(pxNat);
    pxNatEntry = _NatFindFreeBindingInChunks(pxNat->apxNatChunks, NAT_CHUNK_MAX_NUM,
                                             &pxNat->oNumUsedChunks, pxNat->oNumAllowedChunks);
  }


  if (pxNatEntry) {

    pxNatEntry->dwWanAddr = dwWanIp;
    pxNatEntry->dwLanAddr = dwLanIp;
    pxNatEntry->dwTransAddr = dwTransIp;        /* WAN IP of CPE (the appropriate WAN leg) */

    pxNatEntry->oIfIdx = oIfIdx;
    pxNatEntry->oProtocolId = oProtocol;
    pxNatEntry->dwLastUsed = NetGlobalTimerGet();
    pxNatEntry->eType = eType;

    pxNatEntry->wFlags = 0;
    if (dwWanIp == 0) {
      pxNatEntry->wFlags |= NAT_WAN_IP_EMPTY;
    }
    if (wWanPort == 0) {
      pxNatEntry->wFlags |= NAT_WAN_PORT_EMPTY;
    }

    pwTrans = (WORD*) &pxNatEntry->u;

    if (eType == NAT_BINDING_L2W) {
      LONG lSpot;
      lSpot = _NatFindFreeSpot(pxNat->adwPortStatus, (NAT_NUM_ALLOCATED_PORTS >> 5));
      if (lSpot < 0) {
        NAT_CHUNK* pxNatChunk = pxNatEntry->pxNatChunk;
        DWORD dwSpot = pxNatEntry - &pxNatChunk->axNatBindings[0];
        ASSERT((pxNatChunk->adwBindingStatus[dwSpot >> 5] & (1 << (dwSpot & 0x1f))) != 0);
        pxNatChunk->adwBindingStatus[dwSpot >> 5] &= ~(1 << (dwSpot & 0x1f));
        return (NULL);
      }
      *pwTrans = NAT_PORT_BASE + (WORD) lSpot;
      _NatLockSpot(pxNat->adwPortStatus, *pwTrans - NAT_PORT_BASE);
    } else {
      *pwTrans = wTransPort;
    }


    /*
     * Add the newly created entry to the hash tables.
     */
    dwIdx = NatHash(dwLanIp, wLanPort, oProtocol);
    pxNatEntry->pxLanNext = pxNat->apxLanHashTable[dwIdx];
    pxNat->apxLanHashTable[dwIdx] = pxNatEntry;

    dwIdx = NatHash(pxNatEntry->dwTransAddr, *pwTrans, oProtocol);
    pxNatEntry->pxTransNext = pxNat->apxTransHashTable[dwIdx];
    pxNat->apxTransHashTable[dwIdx] = pxNatEntry;

    if (eType != NAT_BINDING_LOCAL) {
      pxNat->wNumBindingsActive ++;
      DEBUG(g_dwNatTotalNumBindings = (DWORD) pxNat->wNumBindingsActive);
    }

    NAT_DBG(DBGLVL_REPETITIVE, g_adwNatNumActiveBindings[pxNatEntry->eType] ++);
  }

  return(pxNatEntry);
}


/*****************************************************************************
Function:
        _NatFindFreeSpot()
Description:
        Finds a free spot in a given array to use.
Arguments:
        DWORD           adwStatus[]     Array holding occupancy information.
        DWORD           dwLength        Length of the array.
Outputs:
        None.
Returns:
        LONG            >= 0            Free port.
                        -1              All ports occupied.
Revisions:
        16-Oct-2001                     Initial
*****************************************************************************/
static LONG _NatFindFreeSpot(DWORD adwStatus[], DWORD dwLength)
{
  DWORD dwIdx;
  DWORD dwPos = 0xFFFFFFFF;

  for (dwIdx = 0; dwIdx < dwLength; dwIdx++) {

    register DWORD dwStatus = adwStatus[dwIdx];

    /*
     * Check if all the ports occupied in this range.
     */
    if (dwStatus != 0xffffffff) {

      /*
       * Look for a free port.
       */
      if ((dwStatus & 0xff) != 0xff) {
        dwPos = _NatFindFirstZero(dwStatus & 0xff);
        break;
      }

      if ((dwStatus & 0xff00) != 0xff00) {
        dwPos = 8 + _NatFindFirstZero((dwStatus & 0xff00) >> 8);
        break;
      }

      if ((dwStatus & 0xff0000) != 0xff0000) {
        dwPos = 16 + _NatFindFirstZero((dwStatus & 0xff0000) >> 16);
        break;
      }

      dwPos = 24 + _NatFindFirstZero((dwStatus & 0xff000000) >> 24);
      break;
    }
  }

  if (dwIdx == dwLength)
    return (-1);

  ASSERT(dwPos != 0xFFFFFFFF);
  return ((dwIdx << 5) + dwPos);
}


/*****************************************************************************
Function:
        _NatLockSpot()
Description:
        Marks the given spot as used.
Arguments:
        DWORD           adwStatus[]     Array holding occupancy status.
        WORD            wPos            Position to be locked up.
Outputs:
        None.
Returns:
        None.
Revisions:
        18-Oct-2001                     Initial
*****************************************************************************/
static void _NatLockSpot(DWORD adwStatus[], WORD wPos)
{
  adwStatus[wPos >> 5] |= (1 << (wPos & 0x1f));
}


/*****************************************************************************
Function:
        _NatFindFirstZero()
Description:
        Finds a bit postion whose value is zero.
Arguments:
        OCTET           oData           Data to examined for
                                        0 bit.
Outputs:
        None.
Returns:
        DWORD           0 - 7           Position of zero bit.
                        0xFFFFFFFF      If no zero bit found.
Revisions:
        16-Oct-2001                     Initial
*****************************************************************************/
static DWORD _NatFindFirstZero(OCTET oData)
{
  DWORD dwPos;
  OCTET oMask = 1;

  for (dwPos = 0; dwPos < 8; dwPos ++) {
    if ((oData & oMask) == 0)
      return (dwPos);
    oMask <<= 1;
  }

  return (0xFFFFFFFF);
}


/*****************************************************************************
Function:
        _NatFindFreeBindingInChunks()
Description:
        Finds a free binding spot in a NAT chunk.
Arguments:
        NAT_CHUNK*      apxNatChunks[]          Array of pointers to NAT chunks.
        DWORD           dwSize                  Size of the array.
        OCTET*          poNumUsedChunks         Pointer to the number of chunks in use.
        OCTET           oNumAllowedChunks       Number of chunks allowed.
Outputs:
        OCTET*          poNumUsedChunks         Updated number of chunks in use.
                                                A new chunk could be allocated.
Returns:
        NAT_ENTRY*      non NULL                Binding handle.
                        NULL                    Cannot find a binding.
Revisions:
        23-Aug-2002                             Initial
*****************************************************************************/
static NAT_ENTRY* _NatFindFreeBindingInChunks(NAT_CHUNK* apxNatChunks[], DWORD dwSize,
                                              OCTET* poNumUsedChunks, OCTET oNumAllowedChunks)
{
  DWORD dwIdx;
  NAT_ENTRY* pxNatEntry = NULL;

  for (dwIdx = 0; dwIdx < dwSize; dwIdx ++) {
    if (apxNatChunks[dwIdx] != NULL) {
      LONG lSpot = _NatFindFreeSpot(apxNatChunks[dwIdx]->adwBindingStatus, (NAT_CHUNK_NUM_BINDINGS >> 5));

      if (lSpot >= 0) {
        pxNatEntry = &apxNatChunks[dwIdx]->axNatBindings[lSpot];
        MOC_MEMSET((ubyte *)pxNatEntry, 0x0, sizeof(NAT_ENTRY));
        pxNatEntry->pxNatChunk = apxNatChunks[dwIdx];
        ASSERT((apxNatChunks[dwIdx]->adwBindingStatus[lSpot >> 5] & (1 << (lSpot & 0x1f))) == 0x0);
        _NatLockSpot(apxNatChunks[dwIdx]->adwBindingStatus, lSpot);
        ASSERT((apxNatChunks[dwIdx]->adwBindingStatus[lSpot >> 5] & (1 << (lSpot & 0x1f))) != 0x0);
        break;
      }
    }
  }


  /*
   * Try to allocate a new chunk if all the exisiting chunks are full.
   * Make sure that the existing number of chunks does not exceed the
   * maximum allowed range.
   */
  if (pxNatEntry == NULL) {

    if (*poNumUsedChunks < oNumAllowedChunks) {

      /*
       * Find an unallocated chunk.
       */
      for (dwIdx = 0; dwIdx < dwSize; dwIdx ++) {
        if (NULL == apxNatChunks[dwIdx])
          break;
      }

      apxNatChunks[dwIdx] = (NAT_CHUNK*) MALLOC(sizeof(NAT_CHUNK));
      if (apxNatChunks[dwIdx] == NULL)
          return NULL;
      MOC_MEMSET((ubyte *)(apxNatChunks[dwIdx]), 0, sizeof(NAT_CHUNK));

      /*
       * Take spot 0 in the new chunk.
       */
      pxNatEntry = &apxNatChunks[dwIdx]->axNatBindings[0];
      pxNatEntry->pxNatChunk = apxNatChunks[dwIdx];
      ASSERT((apxNatChunks[dwIdx]->adwBindingStatus[0] & 0x1) == 0x0);
      _NatLockSpot(apxNatChunks[dwIdx]->adwBindingStatus, 0);
      ASSERT((apxNatChunks[dwIdx]->adwBindingStatus[0] & 0x1) == 0x1);

      *poNumUsedChunks = *poNumUsedChunks + 1;
    }
  }

  return (pxNatEntry);
}
