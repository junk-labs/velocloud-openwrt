/*
 * sockdbg.h
 *
 * socket common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _SOCKDBG_H_
#define _SOCKDBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef SOCKETDBG_HI
   #define SOCKETDBG_HI
  #endif
 #endif

#else
 #ifdef SOCKETDBG_HI
  #undef SOCKETDBG_HI
 #endif

#endif


#include "netdbg.h"

 #define SOCKET_MAGIC_COOKIE 0x534F434B /* "SOCK" */

/*#ifdef SOCKETDBG_HI*/
#if defined(SOCKETDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

 #define SOCKET_CHECK_STATE(x) \
  ASSERT((x != NULL) && (x->dwMagicCookie == SOCKET_MAGIC_COOKIE));

 #define SOCKET_SET_COOKIE(x) (x)->dwMagicCookie = SOCKET_MAGIC_COOKIE

 #define SOCKET_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

 #define SOCKET_DBGP(level,fmt,args...)  do { \
  if (level <= g_dwSocketDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

 #define SOCKET_DBG(level, x) do {  \
    if (level <= g_dwSocketDebugLevel) {  \
      x;      \
    }       \
  } while (0)

 #define SOCKET_DBG_VAR(x) x

 #define SOCKET_CHECKPOINT(x) (x = __LINE__)

 #define SOCKET_CHECKFD(a) ASSERT(((a) & DEVICE_NMBR_MASK) < MAX_FD)

 #define SOCKET_ASSERT(a) ASSERT(a)
#else
  #define SOCKET_CHECK_STATE(x)
  #define SOCKET_SET_COOKIE(x)
  #define SOCKET_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define SOCKET_DBGP
#else
  #define SOCKET_DBGP(level, fmt, args...)
#endif
  #define SOCKET_DBG(level, x)
  #define SOCKET_DBG_VAR(x)
  #define SOCKET_CHECKPOINT(x)
  #define SOCKET_CHECKFD(a)
  #define SOCKET_ASSERT(a)
#endif

SOCKET_DBG_VAR(MOC_EXTERN DWORD g_dwSocketDebugLevel);

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _SOCKDBG_H_ */
