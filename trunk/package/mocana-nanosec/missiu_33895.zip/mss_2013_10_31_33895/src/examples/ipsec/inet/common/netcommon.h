/*
 * netcommon.h
 *
 * Network libraries common definitions.
 *  SHOULD NOT be used outside of the network area
 *  Note: throughout this API, UL stands for Upper Layer,
 *  LL for Lower Layer
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _NETCOMMON_H_
#define _NETCOMMON_H_

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
/*#include "nettime.h" */
/*#include "../include/netpthread.h" */

/*****************************************************************************
 *
 * define
 *
 *****************************************************************************/
/*
 * Global defines
 *  (!!! SB must be moved in Makefiles)
 */
/*#define NET_ASYNC 1 */
/*#define NETPACKETMACRO 1 */
/*
 * Network Return codes
 *  - 0 means OK
 *  - Positive codes are module & function dependants
 *  - Negative code are defined here in ]NETERR_MODULESPECIFICBEGIN,-1].
 *    <NETERR_MODULESPECIFICBEGIN are module/function dependant
 *    (check relevant APIs)
 */


#define NETERR_NOERR          0

/* Option handling error codes */
#define NETERR_UNKNOWN       -1     /* the action/option/ioctl does not
                                       exist */
#define NETERR_UNSUPPORTED   -2     /* Understood but not supported */
#define NETERR_BADVALUE      -3     /* the given value is not acceptable */
#define NETERR_BADHANDLE     -4     /* provided handle is not valid */
#define NETERR_MEM           -5     /* Memory problem */
#define NETERR_MODULESPECIFICBEGIN -6 /* Module specific < -5 */

#define DISABLE_INTERRUPTS
#define RESTORE_INTERRUPTS
/*
 * Network generic options
 * (size: octet)
 */
#define NETOPTION_FREE       0  /* Module free function. Data is
                                   PFN_NETFREE. used in the NetPayload
                                   pfnFree member.*/
#define NETOPTION_MALLOC     1  /* Module malloc function.
                                   Data is PFN_NETMALLOC. The alloc
                                   function must be used for transiting
                                   payload data only (poPayload member in
                                   the NETPAYLOAD struct); Data which
                                   has to be kept in a module should
                                   be allocated by the module own means.
                                   If a payload has to be kept (ex:
                                   ip fragmentation or TCP), it should
                                   be copied internally and the original
                                   freed; only when a payload to be
                                   passed shortly to an interface should
                                   be allocated using the provided
                                   malloc */
#define NETOPTION_PAYLOADMUTEX    2  /* Module Payload mutex. Data is
                                        pthread_mutex_t * */

#define NETOPTION_NETCBK        3 /* Set the module Admin CBK function.
                                  data if PFN_NETCBK */
#define NETOPTION_NETCBKHINST   4 /* Set the module handle to provide
                                     with the cbk */

#define NETOPTION_OFFSET        5 /* Set the interface offset
                                   for the module PDU. Used for traffic
                                   generated in module. value is
                                   NETOPTIONOFFSETDATA*/

#define NETOPTION_TRAILER       6 /* Set the interface trailer.Used for
                                     traffic generated in the module.
                                     NETOPTIONTRAILERDATA */



#define NETOPTION_MODULESPECIFICBEGIN 7

#define NETOPTION_MAX        0xFF

/*
 * Network generic interface Ioctls
 */
#define NETINTERFACEIOCTL_OPEN             0 /* Open.

                                                Data module specific */
#define NETINTERFACEIOCTL_CLOSE            1 /* Close.
                                                Data module specific */

#define NETINTERFACEIOCTL_SETHINST         2 /* Set the interface instance
                                                handle (to be provided to
                                                RxCbk/Write function):
                                                The UL instance for UL
                                                interfaces, LL instance for
                                                LL interfaces
                                                data type:H_NETINSTANCE */
#define NETINTERFACEIOCTL_SETOUTPUTPFN     3 /* Set the data Output function
                                                for the interface:
                                                PFN_NETRXCBK for UL interfaces
                                                and PFN_NETWRITE for LL
                                                interfaces*/
#define NETINTERFACEIOCTL_SETIF            4 /* Set the interface interface
                                                handle passed to the output
                                                function */
#define NETINTERFACEIOCTL_SETROUTINGID     5 /* UL interface:
                                                Id allowing the
                                                module to identify a Rx
                                                packet going to this UL
                                                interface. Typically,
                                                the routing Id of the IP
                                                interface in PPP will be
                                                0x0021, the value of
                                                the protocol field for IP
                                                in PPP.
                                                LL interface:
                                                no usage defined so far*/
#define NETINTERFACEIOCTL_MODULESPECIFICBEGIN 6

/*
 * Module specific ioctls: see modules API files
 */

#define NETINTERFACEIOCTL_MAX              0xFF


/*
 * Administrative Msg
 *  From the wrapper to the modules
 *  module specific messages are given in each module's API
 */
#define NETMSG_OPEN               0   /* Open traffic through a module.
                                             Note: may not be immediate. Check
                                             individual modules */
#define NETMSG_CLOSE              1     /* Close traffic */
#define NETMSG_LOWERLAYERUP       2     /* Lower Layer is Up */
#define NETMSG_LOWERLAYERDOWN     3     /* Lower Layer is Down */

#define NETMSG_MODULESPECIFICBEGIN 4
/*
 * Module specific messages from this point.
 *  See each modules API
 */

#define NETMSG_MAX                0xFF

/*
 * Network module callback
 *  From the modules to the wrapper
 *  Module specific Cbk are >= NETCBK_MODULESPECIFICBEGIN and
 *  defined in the relevant APIs
 */

#define NETCBK_TLU     0   /* This layer Up: traffic can go through */
#define NETCBK_TLD     1   /* This layer down: traffic can't go
                                    through */
#define NETCBK_TLS     2   /* This layer started (received an Open,
                                  is processing it */
#define NETCBK_TLF     3   /* This layer finished. Received a close */

#define NETCBK_NEEDPROCESSING   4   /* The wrapper should call the
                                       Process
                                       function of the module */
#define NETCBK_MODULESPECIFICBEGIN 5 /* All module specific callbacks
                                        are >=  NETCBK_MODULESPECIFICBEGIN */

/*
 * Net default IDs
 */
#define NETIFIDX_ANY ((OCTET)0xFF)    /* Undefined/any ifidx */
#define NETIFIDX_DEFAULT NETIFIDX_ANY /* IfIdx default == undefined */
#define NETVLAN_ANY  ((WORD)0xFFFF)   /* None/any vlan */
#define NETVLAN_DEFAULT NETVLAN_ANY   /* Vlan default == none */
#define NETVLAN_VIDMASK ((WORD)0x0FFF) /* Use to mask the VID */
#define NETVLAN_PRIMASK ((WORD)0xE000) /* Use to mask the user priority */
#define NETVLAN_PRISHIFT 13



/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/
/*
 * IP address type
 */
typedef enum {
  IPADDRT_UNKNOWN,                          /* unknown                */
  IPADDRT_LOOPBACK,                         /* address is for LOOPBACK      */
  IPADDRT_BROADCAST,                        /* address is a valid broadcast */
  IPADDRT_MULTICAST,                        /* address is a valid multicast */
  IPADDRT_MYADDR,                           /* address is (one of) our own  */
  IPADDRT_MYSUBNET,                         /* address is in my subnet      */
  IPADDRT_OUTSIDE,                          /* address is outside our Subnet*/
  IPADDRT_INVBCAST,                         /* Wrong netmask bcast not for us*/
  IPADDRT_MULTICASTJOINED,                  /* address is a valid multicast */
  IPADDRT_MULTICASTJOINEDPROXY,             /* address is a valid multicast proxied */
  IPADDRT_MULTICASTJOINEDSOCKPROXY,         /* address is a valid multicast which is also proxied */
  IPADDRT_PPPPEER,                          /* address is the PPP peer address */
  IPADDRT_ANY = 0xFF                        /* Any value */
} E_ADDRTYPE;

/*
 * Generic network handle
 *  All handle type should derive from it
 */
typedef DWORD H_NET;

/*
 * Generic Network Module Instance handle
 */
typedef H_NET H_NETINSTANCE;

/*
 * Module Interface (UpperLayer and LowerLayer) handle
 */
typedef H_NET H_NETINTERFACE;

/*
 * Network Data Handle
 */
typedef H_NET H_NETDATA;


/*
 * Option Data definition
 */
/* Offset */
typedef H_NETDATA NETOPTIONOFFSETDATA; /* LS WORD is offset,
                                          LS -1 WORD is If index */

/* Trailer */
typedef H_NETDATA NETOPTIONTRAILERDATA; /* LS WORD is trailer,
                                           LS -1 WORD is If index  */

/*
 * Network Call back data definition
 */

/* NEED_PROCESSING: Timer (unit = 1ms) */
typedef H_NETDATA NETCBK_NEEDPROCESSING_DATA;

/*
 * Network module Initialize
 *  Initialize a module
 */

typedef LONG (*PFN_NETINITIALIZE)();

/*
 * Network module Terminate
 *  Terminate a module
 */

typedef LONG (*PFN_NETTERMINATE)();

/*
 * Network module InstanceCreate
 *  create an instance
 */

typedef H_NETINSTANCE (*PFN_NETINSTANCECREATE)();

/*
 * Network module InstanceDestroy
 *  destroy an instance
 */

typedef LONG (*PFN_NETINSTANCEDESTROY)(H_NETINSTANCE);

/*
 * Network module Set
 *
 *
 *  Args:
 *   hInst             module instance
 *   oMsg              Msg code
 *   hData             data handle
 */
typedef LONG (*PFN_NETINSTANCESET) (H_NETINSTANCE hInst,
                                    OCTET oMsg,
                                    H_NETDATA hData);

/*
 * Network module msg function
 *  Send a msg to a module
 *
 *  Args:
 *   hInst             module instance
 *   oMsg              Msg code
 *   hData             data handle
 */
typedef LONG (*PFN_NETMSG) (H_NETINSTANCE hInst,
                            OCTET oMsg,
                            H_NETDATA hData);

/*
 * Network module OptionSet
 *  Set a network module option
 *
 *  Args:
 *   hInst              module instance
 *   oOption            Option Code
 *   hData              Option Data
 *
 *  Return:
 *   >=0 for success
 */
typedef LONG (*PFN_NETSETOPT) (H_NETINSTANCE hInst,
                               OCTET oOption,
                               H_NETDATA hData);

/*
 * Network module OptionQuery
 *  Set a network module option
 *
 *  Args:
 *   hInst              module instance
 *   oOption            Option Code
 *   *phData            Option Data (to be filled)
 *
 *  Return:
 *   >=0 for success
 */
typedef LONG (*PFN_NETQUERYOPT) (H_NETINSTANCE hInst,
                                 OCTET oOption,
                                 H_NETDATA *phData);


/*
 * Network module InstanceInterfaceCreate
 *  create an interface instance
 *
 *  Args:
 *   hInst              module instance
 */

typedef H_NETINTERFACE (*PFN_NETINSTANCEINTERFACECREATE)(H_NETINSTANCE);

/*
 * Network module InstanceInterfaceDestroy
 *  destroy an UL interface instance
 *
 *  Args:
 *   hInst              module instance
 *   hIf                module interface
 */

typedef LONG (*PFN_NETINSTANCEINTERFACEDESTROY)(H_NETINSTANCE,H_NETINTERFACE);


/*
 * Network Interface Ioctl
 *  Performs a Ioctl operation on a network module interface
 *  network wide IOCTLs messages are defined above
 *  (NETINTERFACEIOCTL_XXX). Each module may define its
 *  own (see relavant APIS)
 *
 *  Args:
 *   hInst                 module instance handle
 *   hIf                   interface handle
 *   oIoctl                Ioctl code
 *   hData                 Ioctl data handle
 *
 *  Return:
 *   NET_OK or >=0 if successfull (check relevant module APIs for
 *    specific definitions
 *   < 0 if error (Return codes are defined above as NETERR_XXX,
 *    or in the relevant module API)
 */
typedef LONG (*PFN_NETIOCTL) (H_NETINSTANCE hInst,
                              H_NETINTERFACE hIf,
                              OCTET oIoctl,
                              H_NETDATA hData);

/*
 * Network module instance Call back definition
 *  performs a call back from the hInst instance
 *
 *  Args:
 *   hInst              Instance handle
 *   oCbk               Callback code. Callback code are defined above
 *                      as NETCBK_XXX or in each module API.
 *   hData              Data handle associated with the Callback
 *
 *  Return:
 *   NET_OK or >=0 if successfull (check relevant module APIs for
 *    specific definitions
 *   < 0 if error (Return codes are defined above as NETERR_XXX,
 *    or in the relevant module API)
 */
typedef LONG (*PFN_NETCBK) (H_NETINSTANCE hInst,
                            OCTET oCbk,
                            H_NETDATA hData);

/*
 * Network malloc
 *  malloc associated with a network module. provided
 *  to a module as the NETOPTION_MALLOC, it may be used
 *  to allocate traffic (in fact, only the poPayload member of the
 *  pxPayload member of the NETPACKET structure) going out of the module;
 *  IT MUST NOT BE USED FOR THE MODULE'S INTERNAL ALLOCATION, ONLY FOR
 *  IMMEDIATE OUTGOING TRAFFIC. In particular, if a payload must be kept
 *  around, it shall not be allocated with this provided malloc
 *  Follows stdlib malloc definition.
 */
typedef void * (*PFN_NETMALLOC)(ubyte4 size);

/*
 * Network free
 *  free associated with a network module.provided
 *  to a module as the NETOPTION_FREE, it must be used
 *  in conjunction with the provided network malloc, as the
 *  pfnFree member of NETPAYLOAD which poPayload member has
 *  been allocated using this Network Malloc
 *  Follows stdlib malloc definition.
 */
typedef void (*PFN_NETFREE)(void *);

/*
 * Network module InstanceProcess
 *  process the instance
 *
 *  Args:
 *   hInst              module instance
 */

typedef LONG (*PFN_NETINSTANCEPROCESS) (H_NETINSTANCE);

/*
 * DRIVERBUFFER structure
 * use by interface drivers
 */

typedef struct {
  OCTET *poData;
  DWORD dwLength;

  WORD wSize;
  WORD wOffset;

  OCTET oPriority;
#ifdef CUSTOM_QUEUE
  OCTET oClass;
#endif

  PFN_NETFREE pfnFree;
} DRIVERBUFFER;

typedef struct {
#ifdef __ENABLE_MOCANA_ZEROCOPY__
  DWORD dwMagicCookie;         /* Must be 0xdeadbeef */
#endif
  OCTET *poData;
  DWORD dwLength;

  WORD wSize;
  WORD wOffset;

  OCTET oPriority;
#ifdef __TCP_SEND_SEGMENT__
  OCTET *pTxSegment;
  OCTET oUserCount;
#endif
#ifdef CUSTOM_QUEUE
  OCTET oClass;
#endif

  PFN_NETFREE pfnFree;
} NET_DRV_BUFFER;
/*
 * Packet Priority
 */

typedef enum {
  LOW_PRIORITY = 0,
  MEDIUM_PRIORITY = 127,
  HIGH_PRIORITY = 255,
} E_PRIORITY;

/*
 * NETPAYLOAD structure:
 *  Used in NetPacket for memory management
 */
typedef struct {
  DWORD dwMagicCookie;         /* Must be 0xdeadbeef */
  OCTET *poPayload;
  WORD wSize; /* Size of the poPayload buffer */
  OCTET oUserCount;
  PFN_NETFREE pfnFree; /* Free function set by the allocating module
                             (must be the module coresponding option value */
#ifdef __TCP_SEND_SEGMENT__
  OCTET *pTxSegment;
#endif
#ifdef NET_ASYNC
  RTOS_MUTEX pxMutex;/* Mutex set by the allocating module
                              (must be the module coresponding option value */
#endif
#ifdef __ENABLE_MOCANA_ZEROCOPY__
  DWORD dwLength; /* Length of the poPayload buffer (Data present, for transfer from Vxworks driver to IPStack  */
#endif
} NETPAYLOAD;

/*
 * NETPACKET structure
 *  Network packet handling structure
 *  o A NETPACKET pointer must not be simultaneously shared by parallel
 *    modules.
 *  o The allocating module is responsible for the freeing of the structure
 *    pointer and of the header and trailer fields. The user module
 *    is responsible for calling NETPAYLOAD_REMOVE_USER.
 *    (Note: all extra users must therefore  be added before the payload is
 *     passed down, or it will be freed !)
 *  o the pxPayload pointer will automatically be freed by
 *    the NETPAYLOAD_REMOVE_USER when the user count reaches 0
 *    (and the poPayload user of it will freed as well)
 *
 */
typedef struct {
  /* Payload structure pointer:
   *  o It will typically contain the UDP and IP header
   *    and the application payload. For efficiency, it
   *    should contain the biggest chunk in the packet that
   *    will remain unchanged during all processing:
   *    it may actually contain the whole packet (typically,
   *    in the Tx case, if oIfIndex is defined, the socket is
   *    of SOCK_DGRAM type, the whole packet may be put in there)
   *  o The pointer may be shared simultaneously by several
   *    NET_PACKET
   *  o Creation of a new payload must be done through
   *    the NETPAYLOAD_CREATE macro call (see netcommon.h)
   *  o The only modifiable item is oCount, which should only
   *    be accessed using the NETPAYLOAD_ADDUSER and the
   *    NETPAYLOAD_REMOVEUSER macros defined in netcommon.h
   *    (will take care of sync problems)
   */
  NETPAYLOAD *pxPayload;

  H_NETDATA hMarker; /* packet marker: used by the wrapper */
  WORD wOffset;
  WORD wLength;
  WORD wVlan;
  OCTET oIfIdx;
  OCTET oPriority;
#ifdef CUSTOM_QUEUE
  OCTET oClass;
#endif
} NETPACKET;

/*
 * NETPACKETACCESS
 *  structure passed along with NETPACKET,
 *  containing layer dependant information to access the
 *  payload. Contrary to NETPACKET, this structure may be changed
 *  by whoever it is being passed to.
 */
typedef struct {
  WORD wOffset;
  WORD wLength; /* Length of the relevant data, from wOffset */
  OCTET oPriority; /* Software priority of the packet. see NETPRIORITY_
                      defines */
#ifdef CUSTOM_QUEUE
  OCTET oClass;
#endif
} NETPACKETACCESS;


typedef struct {
  WORD wVlan;  /* VLAN tag. Equivalent to the TAG CONTROL INFORMATION
                     specified in 802.1Q
                     Default value: NETVLAN_DEFAULT (see net default IDs above) */
  OCTET oIfIdx; /* Interface index.
                     Default value: NETIFIDX_DEFAULT (see net default IDs above)
                     Tx path: if it is not NETIFIDX_DEFAULT,
                     the packet must go to this interface, and this
                     interface alone.
                     Rx path: indicates on which interface the
                     packet has been received */
  E_ADDRTYPE eDstAddrType;
  DWORD dwSrcIpAddr;
  DWORD dwDstIpAddr;
  DWORD dwGatewayAddr;
} NETIFID;
/*
 * Network Rx CallBack definition
 *  Rx traffic callback function.
 *  There are 2 types of interfaces: streaming one or packet
 *  based one:
 *   -in streaming interfaces, the calling module will be responsible
 *   for freeing the data if not all of it has been accepted
 *   (return value is less than the Access wLength, or is < 0). If all
 *   the data has been accepted, the called module (the Rx Callback) will
 *   free the data.
 *  -in packet based interfaces, the called module will always call
 *  NETPAYLOAD_DELUSER.
 *  Each module must indicate which type of interface it has
 *
 *  Args:
 *   hULInst                     Receiving UL module
 *   hIf                         Interface on which the data is received,
 *                               in the receiving module.
 *   pxPacket                    packet pointer
 *   pxAccess                    NETPACKETACCESS pointer
 *   hData                       Out-of-Band data associated with the
 *                               received packet. SHOULD NOT BE USED
 *                               for signaling. Each layer will defined
 *                               what it is
 *  Return:
 *   Number of effectively received bytes (including the offset) or <0
 *   (error. see NETERR_XXX definitions and/or module APIs)
 */
typedef LONG (*PFN_NETRXCBK) (H_NETINSTANCE hULInst,
                              H_NETINTERFACE hIf,
                              NETPACKET *pxPacket,
                              NETPACKETACCESS *pxAccess,
                              H_NETDATA hData);

/*
 * Network Tx traffic write
 *  Tx traffic write function

 *  There are 2 types of interfaces: streaming one or packet
 *  based one:
 *   -in streaming interfaces, the calling module will be responsible
 *   for freeing the data if not all of it has been accepted
 *   (return value is less than the Access wLength, or is < 0). If all
 *   the data has been accepted, the called module (the Rx Callback) will
 *   free the data.
 *  -in packet based interfaces, the called module will always call
 *  NETPAYLOAD_DELUSER.
 *  Each module must indicate which type of interface it has
 *
 *  Args:
 *   hLLInst                     Written-to module instance
 *   hIf                         Interface to which the packet is given.
 *   pxPacket                    packet pointer
 *   pxAccess                    NETPACKETACCESS pointer
 *   hData                       Destination identification,
 *                               as understood by the written-to
 *                               protocol
 *
 *  Return:
 *   Number of effectively written bytes, or <0
 *   (error. see NETERR_XXX definitions and/or module APIs)
 */
typedef LONG (*PFN_NETWRITE) (H_NETINSTANCE hLLInst,
                              H_NETINTERFACE hIf,
                              NETPACKET *pxPacket,
                              NETPACKETACCESS *pxAccess,
                              H_NETDATA hData);




/*****************************************************************************
 *
 * NETPACKET & NETPAYLOAD handling
 *
 *****************************************************************************/

#define NETPAYLOAD_COOKIE 0xdeadbeef
#ifdef NETDBG_HI
#define NETPAYLOAD_CHECK(pxPayload) ASSERT((pxPayload != NULL) && (pxPayload->dwMagicCookie == NETPAYLOAD_COOKIE))
#define NETPACKET_CHECK(pxNetPacket) \
          ASSERT(((pxNetPacket) != NULL) && \
                 ((pxNetPacket)->pxPayload != NULL) && \
                 ((pxNetPacket)->pxPayload->dwMagicCookie == NETPAYLOAD_COOKIE) && \
                 ((pxNetPacket)->pxPayload->poPayload != NULL))
#else
#define NETPAYLOAD_CHECK(x)
#define NETPACKET_CHECK(x)
#endif
/*
 * NETPAYLOAD_CREATE
 *  Creates a Netpayload. Number of users is set to 1.
 *
 *  Args:
 *   pfnFree                Free function of the payload
 *   pxMutex                Mutex of the payload
 *   ppxPayload             payload pointer to be filled up
 *
 *  Returns:
 */
void NetPayloadCreate(NETPAYLOAD **ppxPayload,
                      PFN_NETFREE pfnFreeF,
                      RTOS_MUTEX pxMutexX,
                      OCTET *poPayloadD,
                      WORD wSizeE);


#ifdef __INET_USE_PAYLOAD_MEMPOOL__
MOC_EXTERN MSTATUS NetFreePayload(OCTET * pxPoPayload);
MOC_EXTERN MSTATUS NetAllocPayload(OCTET ** ppxPoPayload,WORD wSize);
#endif

#ifdef NET_ASYNC
#ifdef NETPACKETMACRO
#ifndef NDEBUG
  #define NETPAYLOAD_CREATE(ppxPayload,pfnFreeF,pxMutexX,poPayloadD,wSizeE)do{\
    *(ppxPayload) = (NETPAYLOAD *)calloc(1,sizeof(NETPAYLOAD)); \
    (*(ppxPayload))->dwMagicCookie = NETPAYLOAD_COOKIE;\
    (*(ppxPayload))->pfnFree = (pfnFreeF); \
    (*(ppxPayload))->pxMutex = (pxMutexX); \
    (*(ppxPayload))->poPayload = (poPayloadD); \
    (*(ppxPayload))->wSize = (wSizeE); \
    (*(ppxPayload))->oUserCount = (1); \
    } while(0)
#else
  #define NETPAYLOAD_CREATE(ppxPayload,pfnFreeF,pxMutexX,poPayloadD,wSizeE)do{\
    *(ppxPayload) = (NETPAYLOAD *)calloc(1,sizeof(NETPAYLOAD)); \
    (*(ppxPayload))->pfnFree = (pfnFreeF); \
    (*(ppxPayload))->pxMutex = (pxMutexX); \
    (*(ppxPayload))->poPayload = (poPayloadD); \
    (*(ppxPayload))->wSize = (wSizeE); \
    (*(ppxPayload))->oUserCount = (1); \
    } while(0)
#endif
#else /*#ifdef NETPACKETMACRO*/
  #define NETPAYLOAD_CREATE(ppxPayload,pfnFreeF,pxMutexX,poPayloadD,wSizeE) \
          NetPayloadCreate((ppxPayload),(pfnFreeF),(pxMutexX),(poPayloadD),(wSizeE))
#endif /*#ifdef NETPACKETMACRO*/
#else /*#ifdef NET_ASYNC*/
#ifdef NETPACKETMACRO
#ifndef NDEBUG
#define NETPAYLOAD_CREATE(ppxPayload,pfnFreeF,pxMutexX,poPayloadD,wSizeE) do {\
  *ppxPayload = calloc(1,sizeof(NETPAYLOAD)); \
  (*(ppxPayload))->dwMagicCookie = NETPAYLOAD_COOKIE;\
  (*(ppxPayload))->pfnFree = pfnFreeF; \
  (*(ppxPayload))->poPayload = (poPayloadD); \
  (*(ppxPayload))->wSize = (wSizeE); \
  (*(ppxPayload))->oUserCount = (1); \
  } while(0)
#else
#define NETPAYLOAD_CREATE(ppxPayload,pfnFreeF,pxMutexX,poPayloadD,wSizeE) do {\
  *ppxPayload = calloc(1,sizeof(NETPAYLOAD)); \
  (*(ppxPayload))->pfnFree = pfnFreeF; \
  (*(ppxPayload))->poPayload = (poPayloadD); \
  (*(ppxPayload))->wSize = (wSizeE); \
  (*(ppxPayload))->oUserCount = (1); \
  } while(0)
#endif
#else /*#ifdef NETPACKETMACRO*/
  #define NETPAYLOAD_CREATE(ppxPayload,pfnFreeF,pxMutexX,poPayloadD,wSizeE) \
          NetPayloadCreate((ppxPayload),(pfnFreeF),(pxMutexX),(poPayloadD),(wSizeE))
#endif
#endif /*#ifdef NET_ASYNC*/


/*
 * NETPAYLOAD_LOCK
 *  Lock the access to a NETPAYLOAD pointer
 *
 *  Args:
 *   pxPayload
 *
 */
#ifdef NET_ASYNC
#define NETPAYLOAD_LOCK(pxPayload) RTOS_recursiveMutexWait(pxPayload->pxMutex)
#else
#define NETPAYLOAD_LOCK(pxPayload)
#endif

/*
 * NETPAYLOAD_UNLOCK
 *  Unlock the access to a payload pointer
 *
 *  Args:
 *   pxPayload
 */
#ifdef NET_ASYNC
#define NETPAYLOAD_UNLOCK(pxPayload) RTOS_recursiveMutexRelease(pxPayload->pxMutex)
#else
#define NETPAYLOAD_UNLOCK(pxPayload)
#endif


/*
 * NETPAYLOAD_ADDUSER
 *  Add a user to a NetPayload
 *
 *  Args
 *   pxNetPayload
 *
 */
#ifdef NET_ASYNC
#define NETPAYLOAD_ADDUSER(pxNetPayload) do {\
  int iRvPML;\
  iRvPML = RTOS_recursiveMutexWait(pxNetPayload->pxMutex); \
  ASSERT(iRvPML == 0); \
  pxNetPayload->oUserCount ++; \
  (int)RTOS_recursiveMutexRelease(pxNetPayload->pxMutex); \
 } while(0)
#else
#define NETPAYLOAD_ADDUSER(pxNetPayload) do {\
  pxNetPayload->oUserCount ++; \
 } while(0)
#endif

/*
 * NETPAYLOAD_DELUSER
 *  Remove a user from a NetPayload.
 *  Will free the pxNetPayload and its content if the number
 *  if users reach 0.
 *
 *  Args
 *   pxNetPayload
 *
 */
void NetPayloadDelUser(NETPAYLOAD *pxNetPayload);

#ifdef NET_ASYNC
#ifdef NETPACKETMACRO
  #define NETPAYLOAD_DELUSER(pxNetPayload) do {\
    int iRvPML; \
    RTOS_MUTEX pxMutex; \
    ASSERT(pxNetPayload->dwMagicCookie == 0xdeadbeef);\
    pxMutex = pxNetPayload->pxMutex; \
    iRvPML = RTOS_recursiveMutexWait(pxMutex); \
    ASSERT(iRvPML ==0); \
    if ((--(pxNetPayload->oUserCount)) == 0) { \
     pxNetPayload->pfnFree(pxNetPayload->poPayload); \
     FREE(pxNetPayload); \
    } \
    (int)RTOS_RecursiveMutexRelease(pxMutex); \
   } while (0)
#else /*#ifdef NETPACKETMACRO*/
  #define NETPAYLOAD_DELUSER(pxNetPayload) \
          NetPayloadDelUser((pxNetPayload));
#endif /*#ifdef NETPACKETMACRO*/
#else /*#ifdef NET_ASYNC*/
#ifdef NETPACKETMACRO
#define NETPAYLOAD_DELUSER(pxNetPayload) do {\
  if ((--pxNetPayload->oUserCount) == 0) { \
   pxNetPayload->pfnFree(pxNetPayload->poPayload); \
   FREE(pxNetPayload); \
  } \
 } while (0)
#else /*#ifdef NETPACKETMACRO*/
  #define NETPAYLOAD_DELUSER(pxNetPayload) \
          NetPayloadDelUser((pxNetPayload));
#endif /*#ifdef NETPACKETMACRO*/
#endif

/*
 * NetPacketDuplicate
 *  Duplicate a Net packet. Creates a new NETPAYLOAD in
 *  which the original data is copied
 *
 *  Args:
 *   pxDst                Destination
 *   pxSrc                Src
 *   pxMutex              mutex to be used on the new NETPAYLOAD
 *
 *  Return:
 */
void NetPacketDuplicate(NETPACKET *pxDst,NETPACKET *pxSrc,
                        RTOS_MUTEX pxMutex);


#ifdef NETDBG_HI
void NetPacketPrint(char *pcExtrastr,NETPACKET *pxNetPacket);
#endif /*#ifdef NETDBG_HI*/

/*****************************************************************************
 *
 * extern
 *
 *****************************************************************************/

#ifndef NDEBUG
MOC_EXTERN const OCTET *apoNetOptionString[NETOPTION_MODULESPECIFICBEGIN];
MOC_EXTERN const OCTET *apoNetMsgString[NETMSG_MODULESPECIFICBEGIN];
MOC_EXTERN const OCTET *apoNetCbkString[NETCBK_MODULESPECIFICBEGIN];
MOC_EXTERN const OCTET *apoNetIoctlString[NETINTERFACEIOCTL_MODULESPECIFICBEGIN];
#endif /*#ifndef NDEBUG*/

#endif /* #ifndef _NETCOMMON_H_ */









