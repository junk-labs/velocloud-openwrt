/*
 * ppp_accel.c
 *
 * PPP time critical functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "pppdefs.h"

/***************************************************************************
 *
 * API functions
 *
 ***************************************************************************/
/*
 * PppInstanceWrite
 *  Ppp instance write function
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *   pxPacket          packet pointer
 *   pxAccess          access info
 *   hData             NETIFID *
 *
 *  Return:
 *   length written
 */
LONG PppInstanceWrite(H_NETINSTANCE hPpp,H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  PPPSTATE *pxPpp = (PPPSTATE *)hPpp;
  LONG lReturn;

  PPP_CHECK_STATE(pxPpp);
  ASSERT(pxAccess != NULL);
  NETPACKET_CHECK(pxPacket);
  ASSERT((pxAccess->wOffset + pxAccess->wLength) <= pxPacket->pxPayload->wSize);
  ASSERT((pxPpp->pfnNetWrite != NULL) && (pxPpp->pfnNetCbk != NULL));

  lReturn = (LONG)pxAccess->wLength;

  if (pxPpp->ePhase != PPPPHASE_DEAD) {
    OCTET *poPayload;
    /* If the instance is not in DEAD phase */
    NETPAYLOAD_LOCK(pxPacket->pxPayload);

    /* Set the tunneling protocol 1st, as it impacts the offset size */
    if (pxPpp->oTunnelMode == PPPTUNNELMODE_PPTP) {
      ASSERT(pxAccess->wOffset > PPPPPTP_HDRLEN);
      pxAccess->wLength += PPPPPTP_HDRLEN;
      pxAccess->wOffset -= PPPPPTP_HDRLEN;
      PPPPPTPSET_HDR((pxPacket->pxPayload->poPayload + pxAccess->wOffset));
      poPayload = pxPacket->pxPayload->poPayload +
        pxAccess->wOffset + PPTP_HDRLEN;
    }
    else {
      ASSERT(pxAccess->wOffset > PPPDEFAULT_HDRLEN);
      pxAccess->wLength += PPPDEFAULT_HDRLEN;
      pxAccess->wOffset -= PPPDEFAULT_HDRLEN;
      poPayload = pxPacket->pxPayload->poPayload +  pxAccess->wOffset;
    }


    /* 1. check for LCP: all phases */
    if (PPPID_LCP == (WORD)hIf) {
      PPPSET_HDR(poPayload, PPPID_LCP);
      NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
      pxPpp->pfnNetWrite(pxPpp->hLl,pxPpp->hLlIf,pxPacket,
                           pxAccess,hData);
    }
    else {
      /* If non LCP: */
      PPPULIF *pxIf = pxPpp->pxUlTable + ((WORD)hIf -1);

      ASSERT ((WORD)hIf <= pxPpp->wUlTableSize);

      if (pxIf->wProtocolId < 0xC000) {
        /* Network protocol */
        if ((pxIf->obUp == TRUE) &&
              (pxPpp->ePhase == PPPPHASE_NETWORK)) {
          PPPSET_HDR(poPayload,pxIf->wProtocolId);
          NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
          pxPpp->pfnNetWrite(pxPpp->hLl,pxPpp->hLlIf,pxPacket,
                               pxAccess,hData);
        }
        else {
            /* Just dump the data */
          NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
          NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        }
      }  /* End network protocol */
      else {
        /* Must be a Link protocol : check if it coresponds to
           either current authentification or link Quality
           protocols */
        if (pxPpp->ePhase != PPPPHASE_ESTABLISH) {
          WORD wLocalApIdx,wLocalLqpIdx,wRemoteApIdx,wRemoteLqpIdx,wIdx;
          /* Link type protocol, apart from LCP, are allowed
             in any phase but the ESTABLISH & DEAD. DEAD is
             already ruled out in this if statement */
          wIdx = (WORD)hIf -1;
          wLocalApIdx =
            (OCTET)pxPpp->ahLcpLocalOption[PPPLCPOPTION_AP -
                                            PPPLCPOPTION_MRU];
          wLocalLqpIdx =
            (OCTET)pxPpp->ahLcpLocalOption[PPPLCPOPTION_LQP -
                                                 PPPLCPOPTION_MRU];
          wRemoteApIdx =
            (OCTET)pxPpp->ahLcpRemoteOption[PPPLCPOPTION_AP -
                                                  PPPLCPOPTION_MRU];
          wRemoteLqpIdx =
            (OCTET)pxPpp->ahLcpRemoteOption[PPPLCPOPTION_LQP -
                                             PPPLCPOPTION_MRU];

          if ((wIdx == wLocalApIdx) || (wIdx == wLocalLqpIdx) ||
              (wIdx == wRemoteApIdx) || (wIdx == wRemoteLqpIdx)) {
            /* Link */
            PPPSET_HDR(poPayload,pxIf->wProtocolId);
            NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
            pxPpp->pfnNetWrite(pxPpp->hLl,pxPpp->hLlIf,pxPacket,
                                 pxAccess,hData);

          }
          else {
            NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
            NETPAYLOAD_DELUSER(pxPacket->pxPayload);
          }
        }
        else {
          NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
          NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        }
      } /* End of no LCP no network protocol */
    } /* End of no LCP protocol */

    /* Push back the next idle TO, if needed */
    if (pxPpp->dwIdleTOCurrent != PPPIDLETO_NONE) {
      pxPpp->dwIdleTOCurrent =  NetGlobalTimerGet(); /* Store current time */
      pxPpp->dwNextIdleTO = pxPpp->dwIdleTOCurrent + pxPpp->dwIdleTO;
    }
  }
  else {
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    /* Traffic detected in DEAD phase: signal it up */
    pxPpp->pfnNetCbk(pxPpp->hNetCbk,PPPCBK_TRAFFICDETECTED,
                       (H_NETDATA)0);
  }

  return lReturn;
}


/*
 * PppInstanceRcv
 *  PppInstanceRcv function
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *   pxPacket          packet pointer
 *   pxAccess          access info
 *   hData             NETIFID *
 *
 *  Return:
 *   length written
 */
LONG PppInstanceRcv(H_NETINSTANCE hPpp,H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                    H_NETDATA hData)
{
  PPPSTATE *pxPpp = (PPPSTATE *)hPpp;
  LONG lReturn;

  PPP_CHECK_STATE(pxPpp);
  ASSERT(pxAccess != NULL);
  NETPACKET_CHECK(pxPacket);
  ASSERT((pxAccess->wOffset + pxAccess->wLength) <= pxPacket->pxPayload->wSize);

  lReturn = (LONG)pxAccess->wLength;

  if (pxPpp->ePhase != PPPPHASE_DEAD) {
    WORD wProtocolId;
    OCTET *poPayload;
    OCTET obProtocolReject = TRUE;
    OCTET obSilentlyDiscard = TRUE;

    NETPAYLOAD_LOCK(pxPacket->pxPayload);

    poPayload = pxPacket->pxPayload->poPayload + pxAccess->wOffset;

    wProtocolId = PPPGET_HDR(poPayload);

    /* check for tunneling */
    if (wProtocolId == PPPID_PPTP) {
      pxAccess->wOffset += 2;
      pxAccess->wLength -= 2;
      poPayload += 2;
      wProtocolId = PPPGET_HDR(poPayload);
    }

    if (*poPayload & 0x1) {
      /* One bit protocol field: uncompress */
      wProtocolId = PPPHDR_UNPFC(*poPayload);
      pxAccess->wOffset ++;
      pxAccess->wLength --;
    }
    else {
      pxAccess->wOffset += 2;
      pxAccess->wLength -= 2;
    }

    /*
     * LCP
     */
    if (wProtocolId == PPPID_LCP) {
      obProtocolReject = FALSE;

      NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
      PppCpInstanceRcv(pxPpp->hCp,pxPpp->hCpIf,
                       pxPacket,pxAccess,hData);
    }
    else {
      LONG lUlIdx;

      lUlIdx = PppInstanceFindUlIdxFromProtocolId(pxPpp,wProtocolId);

      if (lUlIdx >= 0) {
        /* There is a coresponding protocol */
        /* Non LCP protocols */
        if (wProtocolId < 0xC000) {
        /* Network layer protocols, whether normal ones, NCP
           or Low speed */
          obProtocolReject = FALSE;
          if ((pxPpp->ePhase == PPPPHASE_NETWORK) &&
              (pxPpp->pxUlTable[lUlIdx].obUp == TRUE)) {
            /* Network state, and it is up */
            obSilentlyDiscard = FALSE;
          }
        }  /* end Network protocols */
        else {
          /* Link protocols */
          WORD wLocalApIdx =(WORD)pxPpp->ahLcpLocalOption[PPPLCPOPTION_AP];
          WORD wLocalLqpIdx = (WORD)pxPpp->ahLcpLocalOption[PPPLCPOPTION_LQP];
          WORD wRemoteApIdx = (WORD)pxPpp->ahLcpRemoteOption[PPPLCPOPTION_AP];
          WORD wRemoteLqpIdx = (WORD)pxPpp->ahLcpRemoteOption[PPPLCPOPTION_LQP];

          if ((wLocalApIdx == lUlIdx) || (wLocalLqpIdx == lUlIdx) ||
              (wRemoteApIdx == lUlIdx) || (wRemoteLqpIdx == lUlIdx)) {
            /* The protocol does corespond to a negociated link
               protocol */
            obProtocolReject = FALSE;
            if (pxPpp->ePhase != PPPPHASE_ESTABLISH) {
              /* If, more over, the automaton is passed the ESTABLISH
                 phase */
              obSilentlyDiscard = FALSE;
            }
          }
          else {
            PPP_DBGP(ERROR,"PppInstanceRcv:can't handle lcp request for protocol %d\n",wProtocolId);
          }
        }
      }

      /* Check for Protocol rejects ... */
      if (obProtocolReject == TRUE) {
        PPPCPPACKET xPppCpPacket;
        /* Reset the access data to include the PPP header */
        pxAccess->wLength += 2;
        pxAccess->wOffset -= 2;

        xPppCpPacket.pxPacket = pxPacket;
        xPppCpPacket.pxAccess = pxAccess;
        xPppCpPacket.hData = hData;

        NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
        /* PPP CP will take care of the DELUSER */
        PppCpInstanceMsg(pxPpp->hCp,PPPCPMSG_PROTOCOLREJECT,
                         (H_NETDATA)&xPppCpPacket);
      }
      else if (obSilentlyDiscard == TRUE) {
        /* silently discard */
        NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      }
      else {
        /* Pass up the data */
        PPPULIF *pxUl = pxPpp->pxUlTable + lUlIdx;
        ASSERT(lUlIdx != NETERR_UNKNOWN);

        NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
        pxUl->pfnRxCbk(pxUl->hUl,pxUl->hUlIf,pxPacket,pxAccess,(H_NETDATA)hData);
      }
    }

    /* Push back the next idle TO, if needed */
    if (pxPpp->dwIdleTOCurrent != PPPIDLETO_NONE) {
      pxPpp->dwIdleTOCurrent =  NetGlobalTimerGet(); /* Store current time */
      pxPpp->dwNextIdleTO = pxPpp->dwIdleTOCurrent + pxPpp->dwIdleTO;
    }
  } /* End not Phase DEAD */
  else {
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    /* Traffic detected in DEAD phase: signal it up */
    pxPpp->pfnNetCbk(pxPpp->hNetCbk,PPPCBK_TRAFFICDETECTED,
                       (H_NETDATA)0);
  }

  return lReturn;
}

/*
 * PppInstanceFindUlIdxFromProtocolId
 *  Finds the index in the Ul Table, based on the Protocol Field
 *
 *  Args:
 *   pxPpp               instance pointer
 *   wProtocolId           Protocol Id
 *
 *  Return:
 *   index or NETERR_UNKNOWN
 */
LONG PppInstanceFindUlIdxFromProtocolId(PPPSTATE *pxPpp,WORD wProtocolId)
{
  LONG lReturn = NETERR_UNKNOWN;
  WORD w;

  ASSERT(pxPpp != NULL);

  for (w=0;w<pxPpp->wUlTableSize;w++) {
    if (wProtocolId == pxPpp->pxUlTable[w].wProtocolId) {
      return (LONG)w;
    }
  }

  return lReturn;
}
