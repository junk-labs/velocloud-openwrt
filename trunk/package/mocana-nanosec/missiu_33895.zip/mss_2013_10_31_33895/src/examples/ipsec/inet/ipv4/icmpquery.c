/*
 * icmpquery.c
 *
 * Isolated icmp query for codespace savings
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "icmp_defs.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * IcmpInstanceQuery
 *  Query a ICMP Instance Option
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceQuery(H_NETINSTANCE hIcmp,
                       OCTET oOption,
                       H_NETDATA *phData)
{
  LONG lReturn = NETERR_NOERR;
  ICMP_STATE *pxIcmp = (ICMP_STATE *)hIcmp;
  ICMP_CHECK_STATE(pxIcmp);

  switch(oOption) {

  case NETOPTION_PAYLOADMUTEX:
    *phData = (H_NETDATA)pxIcmp->pxMutex;
    break;

  case NETOPTION_OFFSET:
    *phData = (H_NETDATA)pxIcmp->wOffset;
    break;

  case NETOPTION_TRAILER:
    *phData = (H_NETDATA)pxIcmp->wTrailer;
    break;

  case NETOPTION_NETCBK:
    *phData = (H_NETDATA)pxIcmp->pfnNetCbk;
    break;

  default:
    lReturn = NETERR_BADVALUE;
    ASSERT(0);
  }

  return lReturn;
}


