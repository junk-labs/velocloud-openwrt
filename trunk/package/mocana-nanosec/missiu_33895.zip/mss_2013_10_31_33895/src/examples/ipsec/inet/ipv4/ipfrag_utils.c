/*
 * ipfrag_util.c
 *
 * Ip fragmentation utility function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/

#include "ipfrag_defs.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * IpFragFreePacket
 *  Free a FRAG_PACKET * pointer cast as a void *
 *
 *  Args:
 *   pxFragPacket                packet pointer
 *
 *  Return:
 */
void IpFragFreePacket(void *pvFragPacket)
{
  FRAG_PACKET *pxFragPacket = (FRAG_PACKET*)pvFragPacket;
  ASSERT(pxFragPacket != NULL);
  if(pxFragPacket->pxNetPayload != NULL){
    NETPAYLOAD_DELUSER(pxFragPacket->pxNetPayload);
  }
#ifdef __IPFRAG_USE_MEMPOOL__
  MEM_POOL_putPoolObject(&pxFragPacket->pxIpFragState->fragPacketPool, (void **)(&pxFragPacket));
#else
  FREE(pvFragPacket);
#endif
  return;
}

/*
 * IpFragFreeDgram
 *  Free a Datagram structure memory
 *
 *  Args:
 *   px                   pointer to the datagram structure
 *
 *  Return;
 */
void IpFragFreeDgram(void *px)
{
  FRAG_DATAGRAM *pxDgram = (FRAG_DATAGRAM *)px;

  ASSERT(pxDgram != NULL);

  clear_DLLIST(&pxDgram->dllPacket,IpFragFreePacket);

#ifdef __IPFRAG_USE_MEMPOOL__
  MEM_POOL_putPoolObject(&pxDgram->pxIpFragState->fragDatagramPool, (void **)(&pxDgram));
#else
  FREE(pxDgram);
#endif
  return;
}


