/*
 * papparser.h
 *
 * PAP parsing library
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PAPPARSER_H_
#define _PAPPARSER_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * PAP parsing macros
 */
#define PAPOFFSET_TYPE 0
#define PAPGET_TYPE(poPacket) ((E_PAPPACKETTYPE) *(poPacket + PAPOFFSET_TYPE))
#define PAPSET_TYPE(poPacket, eType) (*(poPacket + PAPOFFSET_TYPE) = (OCTET)eType)

#define PAPOFFSET_ID 1
#define PAPGET_ID(poPacket) (*(poPacket + PAPOFFSET_ID))
#define PAPSET_ID(poPacket,oId) (*(poPacket + PAPOFFSET_ID) = oId)

#define PAPOFFSET_LENGTH 2
#define PAPGET_LENGTH(poPacket) (ntohs((*((WORD *)(poPacket + PAPOFFSET_LENGTH))))
#define PAPSET_LENGTH(poPacket,wLength) (*((WORD *)(poPacket + PAPOFFSET_LENGTH)) = htons(wLength))

#define PAPGET_DATAPOINTER(poPacket) (poPacket + PAP_HLEN)

#define PAP_HLEN 4

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/
/*
 * PAP packet types
 */
typedef enum {
  PAPPACKETTYPE_AUTHENTICATEREQUEST = 1,
  PAPPACKETTYPE_AUTHENTICATEACK,
  PAPPACKETTYPE_AUTHENTICATENAK,
} E_PAPPACKETTYPE;


#endif
