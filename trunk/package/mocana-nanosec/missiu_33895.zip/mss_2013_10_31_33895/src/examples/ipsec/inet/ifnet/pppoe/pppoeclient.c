/*
 * pppoeclient.c
 *
 * PPPoE client functionnality
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "pppoeclientdefs.h"

/*****************************************************************************
 *
 * Globals
 *
 *****************************************************************************/
PPPOECLIENT_DBGVAR(DWORD g_dwPppoEClientDebugLevel = 1);

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * PppoEClientInitialize
 *  Initializes the library
 *
 *  Args:
 *
 *  Return:
 *   0
 */
LONG PppoEClientInitialize(void)
{
  return NETERR_NOERR;
}

/*
 * PppoEClientTerminate
 *  Terminates the library
 *
 *  Args:
 *
 *  Return:
 *   0
 */
LONG PppoEClientTerminate(void)
{
  return NETERR_NOERR;
}

/*
 * PppoEClientInstanceCreate
 *  Creates a PPPoE instance
 *
 *  Args:
 *
 *  Return:
 *   instance handle
 */
H_NETINSTANCE PppoEClientInstanceCreate(void)
{
  PPPOECLIENTSTATE *pxPppoeClient;

  pxPppoeClient = (PPPOECLIENTSTATE *)calloc(1,sizeof(PPPOECLIENTSTATE));
  ASSERT(pxPppoeClient != NULL);

  PPPOECLIENT_SETCOOKIE(pxPppoeClient);

  pxPppoeClient->eState = PPPOECLIENTSTATE_INIT;

  pxPppoeClient->dwRetransmissionTOBase = PPPOEDEFAULT_RETRANSMISSIONTO;
  pxPppoeClient->dwReconnectionTOBase = PPPOEDEFAULT_RECONNECTION_TO;

  pxPppoeClient->dwRetranmissionCounterBase = PPPOEDEFAULT_RETRANSMISSIONCOUNTER;
  pxPppoeClient->dwRetranmissionCounter = PPPOEDEFAULT_RETRANSMISSIONCOUNTER;

  /* Set the server ethernet address to broadcast */
  memset(pxPppoeClient->xServerEthId.aoAddr,0xFF,ETHADDRESS_LEN);
  pxPppoeClient->xServerEthId.oIfIdx = NETIFIDX_ANY;
  pxPppoeClient->xServerEthId.wVlan = NETVLAN_ANY;

  pxPppoeClient->xHdr.oCode = PPPOECODE_PADI;
  pxPppoeClient->xHdr.oVersionType = PPPOEDEFAULT_VERTYPE;

  /* Set service name to "any" */
  {
    PPPOETAG *pxTag = &(pxPppoeClient->axTagTable[PPPOETAGIDX_SERVICENAME]);

    pxTag->wItemNum = 1;
    pxTag->pxItemList = (PPPOETAGITEM *)calloc(1,sizeof(PPPOETAGITEM));
    ASSERT(pxTag->pxItemList != NULL);

  }

  return (H_NETINSTANCE)pxPppoeClient;
}

/*
 * PppoEClientInstanceDestroy
 *  Creates a PPPoE instance
 *
 *  Args:
 *   hInst                   instance handle
 *
 *  Return:
 *   0
 */
LONG PppoEClientInstanceDestroy(H_NETINSTANCE hInst)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);

  PppoETagTableClear(pxPppoeClient->axTagTable);

  PPPOECLIENT_UNSETCOOKIE(pxPppoeClient);

  free(pxPppoeClient);

  return NETERR_NOERR;
}

/*
 * PppoEClientInstanceSet
 *  Set an option value
 *
 *  Args:
 *   hInst                   instance handle
 *   oOption                 option code
 *   hDdata                  option value
 *
 *  Return:
 *   >=0 if success
 */
LONG PppoEClientInstanceSet(H_NETINSTANCE hInst,OCTET oOption,H_NETDATA hData)
{
  LONG lReturn = NETERR_NOERR;
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);

  switch(oOption) {
  case NETOPTION_FREE:
    pxPppoeClient->pfnNetFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_MALLOC:
    pxPppoeClient->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    pxPppoeClient->pxNetMutex = (pthread_mutex_t *)hData;
    break;

  case NETOPTION_NETCBK:
    pxPppoeClient->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case NETOPTION_NETCBKHINST:
    pxPppoeClient->hNetCbk = (H_NETINSTANCE)hData;
    break;

  case NETOPTION_OFFSET:
    pxPppoeClient->wOffset = (WORD)hData;
    break;

  case NETOPTION_TRAILER:
    pxPppoeClient->wTrailer = (WORD)hData;
    break;

  case PPPOEOPTION_RETRANSMISSIONTO:
    pxPppoeClient->dwRetransmissionTOBase = (DWORD)hData;
    break;

  case PPPOEOPTION_RECONNECTIONTO:
    pxPppoeClient->dwReconnectionTOBase = (DWORD)hData;
    break;

  case PPPOEOPTION_RETRANSMISSIONCOUNTER:
    pxPppoeClient->dwRetranmissionCounterBase = (DWORD)hData;
    pxPppoeClient->dwRetranmissionCounter = (DWORD)hData;
    break;

  case PPPOEOPTION_PHYIF:
    pxPppoeClient->xServerEthId.oIfIdx = (OCTET)hData;
    break;

  case PPPOEOPTION_VLAN:
    pxPppoeClient->xServerEthId.wVlan = (WORD)hData;
    break;

  case PPPOECLIENTOPTION_ACNAME:
  /* Fall through */
  case PPPOECLIENTOPTION_SERVICENAME:
    {
      OCTET *pcSrcName = (char *)hData;
      OCTET oTagIndex;
      PPPOETAGITEM *pxTagItem;
      PPPOETAG *pxTag;

      oTagIndex = (oOption == PPPOECLIENTOPTION_SERVICENAME) ?
                  PPPOETAGIDX_SERVICENAME:PPPOETAGIDX_ACNAME;
      pxTag = &pxPppoeClient->axTagTable[oTagIndex];

      if (pxTag->wItemNum == 0) {
        pxTag->wItemNum = 1;
        pxTag->pxItemList = (PPPOETAGITEM *)calloc(1,sizeof(PPPOETAGITEM));
      }

      pxTagItem = pxTag->pxItemList;
      ASSERT(pxTagItem != NULL);

      if (pxTagItem->poData != NULL) {
        free(pxTagItem->poData);
        pxTagItem->wLength = 0;
        pxTagItem->poData = NULL;
      }
      if ((pcSrcName != NULL) &&
          ((pxTagItem->wLength = (WORD)strlen(pcSrcName)) != 0)) {
        pxTagItem->poData = (OCTET *)
          malloc((pxTagItem->wLength)*sizeof(OCTET));
        ASSERT(pxTagItem->poData != NULL);
        memcpy(pxTagItem->poData,pcSrcName,pxTagItem->wLength);
      }
    }
  break;

  default:
    ASSERT(0);
    lReturn = NETERR_UNKNOWN;
  }

  return lReturn;
}

/*
 * PppoEClientInstanceMsg
 *  PPPoE client Msg function
 *
 *  Args:
 *   hInst                   instance handle
 *   oMsg                    msg code
 *   hData                   msg data
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceMsg(H_NETINSTANCE hInst,OCTET oMsg,H_NETDATA hData)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);

  PPPOECLIENT_DBGP(NORMAL,"PppoEClientInstanceMsg:hPppoE=%d,oMsg=%s,hData=%d\n",
                          (int)hInst,
                          apoNetMsgString[oMsg],
                          (int)hData);

  switch(oMsg) {
  case NETMSG_OPEN:
    if ((pxPppoeClient->eState == PPPOECLIENTSTATE_INIT) ||
        (pxPppoeClient->eState == PPPOECLIENTSTATE_TERMINATE)) {
      /* ASSERT(pxPppoeClient->pfnRxCbk != NULL); */
      ASSERT(pxPppoeClient->pfnLlWrite != NULL);
      ASSERT(pxPppoeClient->pxNetMutex != NULL);
      ASSERT(pxPppoeClient->pfnNetFree != NULL);
      ASSERT(pxPppoeClient->pfnNetMalloc != NULL);
      ASSERT(pxPppoeClient->pfnNetCbk != NULL);

      pxPppoeClient->eState = PPPOECLIENTSTATE_DISCOVER;
      pxPppoeClient->xHdr.oCode = PPPOECODE_PADI;
      pxPppoeClient->xHdr.wSessionId = 0;
      memset(pxPppoeClient->xServerEthId.aoAddr,0xFF,ETHADDRESS_LEN);
      PppoEClientInstanceResetTransmission(pxPppoeClient);
    }
    break;

  case NETMSG_CLOSE:
    if (pxPppoeClient->eState != PPPOECLIENTSTATE_INIT) {
      pxPppoeClient->eState = PPPOECLIENTSTATE_TERMINATE;
      pxPppoeClient->xHdr.oCode = PPPOECODE_PADT;
      /* Note: if the client is already in TERMINATE state, this
         will reset the transmission. Does not harm. */
      PppoEClientInstanceResetTransmission(pxPppoeClient);
      PppoETagTableClear(pxPppoeClient->axTagTable);
    }
    break;

  default:
  }

  return NETERR_NOERR;
}

/*
 * PppoEClientInstanceULInterfaceCreate
 *  Create the UL interface. There can be only one of these.
 *
 *  Args:
 *   hInst                   instance handle
 *
 *  Return:
 *   interface handle
 */
H_NETINTERFACE PppoEClientInstanceULInterfaceCreate(H_NETINSTANCE hInst)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);

  ASSERT(pxPppoeClient->oULNumber == 0);
  pxPppoeClient->oULNumber = 1;

  return (H_NETINTERFACE)1;
}

/*
 * PppoEClientInstanceULInterfaceDestroy
 *  Destroy the UL interface.
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     interface handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceULInterfaceDestroy(H_NETINSTANCE hInst,
                                           H_NETINTERFACE hIf)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);

  ASSERT(pxPppoeClient->oULNumber == 1);
  pxPppoeClient->oULNumber = 0;

  return NETERR_NOERR;
}

/*
 * PppoEClientInstanceULInterfaceIoctl
 *  Destroy the UL interface.
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     interface handle
 *   oIoctl                  ioctl code
 *   hData                   data handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceULInterfaceIoctl(H_NETINSTANCE hInst,
                                         H_NETINTERFACE hIf,
                                         OCTET oIoctl,
                                         H_NETDATA hData)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);
  ASSERT(hIf == (H_NETINTERFACE)1);
  ASSERT(pxPppoeClient->oULNumber == 1);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_SETHINST:
    pxPppoeClient->hUl = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxPppoeClient->pfnRxCbk = (PFN_NETRXCBK)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxPppoeClient->hUlIf = (H_NETINTERFACE)hData;
    break;

  default:
    break;
  }

  return NETERR_NOERR;

}

/*
 * PppoEClientInstanceLLInterfaceCreate
 *  Create the LL interface. There can be only one of these.
 *
 *  Args:
 *   hInst                   instance handle
 *
 *  Return:
 *   interface handle
 */
H_NETINTERFACE PppoEClientInstanceLLInterfaceCreate(H_NETINSTANCE hInst)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);

  ASSERT(pxPppoeClient->oLLNumber == 0);
  pxPppoeClient->oLLNumber = 1;

  return (H_NETINTERFACE)1;
}

/*
 * PppoEClientInstanceLLInterfaceDestroy
 *  Destroy the LL interface.
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     interface handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceLLInterfaceDestroy(H_NETINSTANCE hInst,
                                           H_NETINTERFACE hIf)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);

  ASSERT(pxPppoeClient->oLLNumber == 1);
  pxPppoeClient->oLLNumber = 0;

  return NETERR_NOERR;
}

/*
 * PppoEClientInstanceLLInterfaceIoctl
 *  Destroy the LL interface.
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     interface handle
 *   oIoctl                  ioctl code
 *   hData                   data handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceLLInterfaceIoctl(H_NETINSTANCE hInst,
                                         H_NETINTERFACE hIf,
                                         OCTET oIoctl,
                                         H_NETDATA hData)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);
  ASSERT(hIf == (H_NETINTERFACE)1);
  ASSERT(pxPppoeClient->oLLNumber == 1);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_SETHINST:
    pxPppoeClient->hLl = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxPppoeClient->pfnLlWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxPppoeClient->hLlPppoEIf = (H_NETINTERFACE)hData;
    break;

  case PPPOELLINTERFACEIOCTL_SETSESSIONIF:
    pxPppoeClient->hLlSessionIf = (H_NETINTERFACE)hData;
    break;

  default:
    break;
  }

  return NETERR_NOERR;

}



/*
 * PppoEClientInstanceProcess
 *  PPPoE client process function.
 *
 *  Args:
 *   hInst                   instance handle
 *
 *  Return:
 *   Delay till next call
 */

PPPOECLIENT_DBGVAR(DWORD dbgdwPppoEClientInstanceProcessCnt = 0);

LONG PppoEClientInstanceProcess(H_NETINSTANCE hInst)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;
  LONG lReturn = 0x7FFFFFFF;
  DWORD dwCurrentTime;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);
  ASSERT((pxPppoeClient->pfnLlWrite != NULL) && (pxPppoeClient->pfnNetCbk != NULL));
  PPPOECLIENT_DBGVAR(dbgdwPppoEClientInstanceProcessCnt++;);

  dwCurrentTime = NetGlobalTimerGet();

  switch(pxPppoeClient->eState) {
  case PPPOECLIENTSTATE_INIT:
  case PPPOECLIENTSTATE_SESSION:
    break;

  case PPPOECLIENTSTATE_DISCOVER:
  case PPPOECLIENTSTATE_REQUEST:
  case PPPOECLIENTSTATE_TERMINATE:
    if (dwCurrentTime >= pxPppoeClient->dwNextRetransmissionT) {
      /* retransmit the packet */
      NETPACKET xNetPacket;
      NETPACKETACCESS xAccess;
      ASSERT((pxPppoeClient->xHdr.oCode == PPPOECODE_PADI) ||
             (pxPppoeClient->xHdr.oCode == PPPOECODE_PADR) ||
             (pxPppoeClient->xHdr.oCode == PPPOECODE_PADT));

      DEBUG(if((pxPppoeClient->eState == PPPOECLIENTSTATE_DISCOVER) ||
              (pxPppoeClient->eState == PPPOECLIENTSTATE_REQUEST)){
              ASSERT(pxPppoeClient->xHdr.wSessionId == 0);
            });

      PppoEClientCreatePacket(pxPppoeClient,&xNetPacket,&xAccess);


      PPPOECLIENT_DBGP(REPETITIVE,
                       "PppoEClientInstanceProcess:%d,sending %s to oIfIdx=%d, MAC="MACFORM", SessionId=%d\n",
                       (int)pxPppoeClient,
                       PppoECodeToString(pxPppoeClient->xHdr.oCode),
                       pxPppoeClient->xServerEthId.oIfIdx,
                       HWADDRDISPLAY(pxPppoeClient->xServerEthId.aoAddr),
                       pxPppoeClient->xHdr.wSessionId);

      PPPOECLIENT_DBG(REPETITIVE,PppoEPrintTagTable(pxPppoeClient->axTagTable));

#if 0
      /* Useful debug code - dumps the contents of outgoing PPPoE packet */
      {
        int p,q = 0;

        for(p=((DWORD)xNetPacket.pxPayload->poPayload + pxPppoeClient->wOffset); p<=((DWORD)xNetPacket.pxPayload->poPayload + xNetPacket.pxPayload->wSize - pxPppoeClient->wTrailer); p++, q++) {
          printf("%02X ", *((OCTET*)p));
      if (15 == q)
            printf("\n");
        }
      }
      printf("\n");
#endif

      pxPppoeClient->pfnLlWrite(pxPppoeClient->hLl,pxPppoeClient->hLlPppoEIf,
                          &xNetPacket,&xAccess,
                          (H_NETDATA)&(pxPppoeClient->xServerEthId));

      /* reset the next time to retransmit */
      pxPppoeClient->dwNextRetransmissionT = dwCurrentTime +
        pxPppoeClient->dwRetransmissionTO;

      /* No retranmission for PADT */
      if (pxPppoeClient->eState == PPPOECLIENTSTATE_TERMINATE) {
        pxPppoeClient->dwRetranmissionCounter = 0;
      }

      if (pxPppoeClient->dwRetranmissionCounter <= 1) {
      /* This is the last transmission in this cycle */
        if (pxPppoeClient->eState == PPPOECLIENTSTATE_DISCOVER) {
          /* signal the expiration up */
          pxPppoeClient->pfnNetCbk(pxPppoeClient->hNetCbk,
                             PPPOECLIENTCBK_COUNTEREXPIRED,(H_NETDATA)0);

      /* Reset the timing counters, but don't force immediate send of next packet */
      pxPppoeClient->dwRetranmissionCounter = pxPppoeClient->dwRetranmissionCounterBase;
      pxPppoeClient->dwRetransmissionTO = pxPppoeClient->dwRetransmissionTOBase;

      /* Make next transmission occur after reconnect time */
          pxPppoeClient->dwNextRetransmissionT = dwCurrentTime + pxPppoeClient->dwReconnectionTOBase;
        }
        else if (pxPppoeClient->eState == PPPOECLIENTSTATE_REQUEST) {
          /* jump back to discover, as recommended */
          pxPppoeClient->eState = PPPOECLIENTSTATE_DISCOVER;
          pxPppoeClient->xHdr.oCode = PPPOECODE_PADI;
          PppoEClientInstanceResetTransmission(pxPppoeClient);
        }
        else {
          /* Terminate state: signal the closure and jumps
             to INIT  */
          pxPppoeClient->xHdr.oCode = PPPOECODE_PADI;
          pxPppoeClient->eState = PPPOECLIENTSTATE_INIT;
          pxPppoeClient->pfnNetCbk(pxPppoeClient->hNetCbk,
                             NETCBK_TLF,(H_NETDATA)0);
          PppoEClientInstanceResetTransmission(pxPppoeClient);
        }
      }
      else {
      /* Decrement the retransmission counter */
        pxPppoeClient->dwRetranmissionCounter --;
      }

    }
    ASSERT(pxPppoeClient->dwNextRetransmissionT >= dwCurrentTime);
    lReturn = pxPppoeClient->dwNextRetransmissionT - dwCurrentTime;
    break;

  }

  return lReturn;
}


/*
 * PppoEClientCreatePacket
 *  Creates a PPPoE packet. The code must have been
 *  set beforehand in pxPppoeClient
 *
 *  Args:
 *   pxNetPacket               Netpacket to fill up
 *   pxNetPacket
 */
LONG PppoEClientCreatePacket(PPPOECLIENTSTATE *pxPppoeClient,
                             NETPACKET *pxNetPacket,
                             NETPACKETACCESS *pxAccess)
{
  WORD wSize;
  OCTET *poPayload;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);

  /* Remove all but the first AC-Name tag - this is required because sometimes
   * PPPoE server may send more than one (which is incorrect behaviour), e.g.
   * Cisco-3620 */
  PppoETagTableDeleteRedundantTags(pxPppoeClient->axTagTable, PPPOETAGIDX_ACNAME);

  pxPppoeClient->xHdr.wLength = PppoETagTablePayloadLength(pxPppoeClient->axTagTable);

  pxAccess->wLength = PPPOE_HDRLEN + pxPppoeClient->xHdr.wLength;

  wSize = pxAccess->wLength + pxPppoeClient->wOffset + pxPppoeClient->wTrailer;
  pxAccess->wOffset = pxPppoeClient->wOffset;

  ASSERT((pxPppoeClient->pfnNetMalloc != NULL) && (pxPppoeClient->pfnNetFree != NULL));

  poPayload = (OCTET *)pxPppoeClient->pfnNetMalloc(wSize);

  NETPAYLOAD_CREATE(&(pxNetPacket->pxPayload),pxPppoeClient->pfnNetFree,
                    pxPppoeClient->pxNetMutex,poPayload,wSize);
  pxNetPacket->hMarker = (H_NETDATA)0;

  NETPAYLOAD_LOCK(pxNetPacket->pxPayload);
  PppoEEncode(poPayload + pxPppoeClient->wOffset,
              &(pxPppoeClient->xHdr),pxPppoeClient->axTagTable);

  NETPAYLOAD_UNLOCK(pxNetPacket->pxPayload);

  return 0;
}


#ifdef PPPOECLIENTDBG_HI
CHAR* PppoECodeToString(OCTET oCode)
{
  switch(oCode){
  case PPPOECODE_PADI:
    return "PADI";
  case PPPOECODE_PADO:
    return "PADO";
  case PPPOECODE_PADR:
    return "PADR";
  case PPPOECODE_PADS:
    return "PADS";
  case PPPOECODE_PADT:
    return "PADT";
  case PPPOECODE_SESSION:
    return "SESSION";
  default:
    return "???";
  }
}

#endif /*PPPOECLIENTDBG_HI*/
