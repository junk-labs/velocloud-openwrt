/*
 * router_write.c
 *
 * router Tx function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/
#include "router.h"
#include "router_defs.h"
#include "netdefs.h"
#include "meter.h"

/*****************************************************************************
 *
 * DEBUG
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * RouterInstanceWrite
 *  RouterInstance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hRouter                    router Instance handle
 *   hIf                        Upper Layer interface handle
 *   pxNetPacket                Packet pointer
 *   wOffset                    IP PDU offset
 *   hData                      pointer to a NETWORKID structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG RouterInstanceWrite(H_NETINSTANCE    hRouterInst,
                         H_NETINTERFACE   hULIf,
                         NETPACKET        *pxNetPacket,
                         NETPACKETACCESS  *pxNetPacketAccess,
                         H_NETDATA        hData)
{
  ROUTERSTATE *pxRouter = (ROUTERSTATE *)hRouterInst;
  NETWORKID *pxNetworkId = (NETWORKID *)hData;
  OCTET oIfIdxRx;
  WORD wVlanRx;
  DWORD dwGatewayAddrRx;
  E_ADDRTYPE eDstAddrTypeRx;
  E_ADDRTYPE eSrcAddrType = IPADDRT_ANY;
  LONG status;

  ROUTER_CHECK_STATE(pxRouter);
  NETPACKET_CHECK(pxNetPacket);
  ASSERT((pxNetPacketAccess != NULL) &&
         (pxNetworkId != NULL) &&
         (pxRouter->pfnLLWrite != NULL));


  /*************************************************
   *
   * Check if the UL Interface is valid
   *
   ************************************************/
  NETDBG_ASSERT((OCTET)hULIf == 1);


  /******************************************************
   *
   * Get routing information for packet to be tunneled
   *
   *****************************************************/
#ifdef IPSEC
  if (pxNetworkId->dwSecurityPolicy != 0x0) {
    pxNetworkId->oIfIdx =
               IPSecGetIfIdx((void*)pxNetworkId->dwSecurityPolicy,
                pxNetworkId->oIfIdx);
    pxNetworkId->dwGatewayAddr =
             IPSecGetGateway((void*)pxNetworkId->dwSecurityPolicy,
                pxNetworkId->dwGatewayAddr);
  }
#endif


  /*
   * Indicates interface on which the packet was received.
   * NOTE: This is used in deciding the source address for
   *       ICMP reports.
   */
  oIfIdxRx = pxNetworkId->oIfIdx;
  wVlanRx = pxNetworkId->wVlan;
  dwGatewayAddrRx = pxNetworkId->dwGatewayAddr;
  eDstAddrTypeRx = pxNetworkId->eDstAddrType;

    /* RS: since we may have switched oIfIdx above if original one is down,
     * restore them before returning
     */
#define _ROUTERINSTANCEWRITE_RESTORE_RX                             \
    {                                                           \
          pxNetworkId->oIfIdx = oIfIdxRx;                     \
          pxNetworkId->wVlan = wVlanRx;                       \
          pxNetworkId->dwGatewayAddr = dwGatewayAddrRx;       \
          pxNetworkId->eDstAddrType = eDstAddrTypeRx;         \
    }

  /************************************************************
   *
   * Interface/Route lookup
   *
   ************************************************************/
#if 0 /* RS added one more condition i.e if intf specified and is down */
  if (pxNetworkId->dwGatewayAddr == INADDR_ANY)
#else
  if ((pxNetworkId->dwGatewayAddr == INADDR_ANY) ||
      ( (pxNetworkId->oIfIdx != NETIFIDX_ANY) &&
        (pxRouter->abIsLinkUp[pxNetworkId->oIfIdx] != TRUE)) )
#endif
  {
    ROUTEENTRY xRouteEntry;

    /*
     * Look up gateway address and interface index to which
     * the packet has to be forwarded.
     */
#ifdef _RADIX_ROUTING_ON_
    xRouteEntry.xRouteNodes->RadixNodeKey  = pxNetworkId->dwDstAddr;
    xRouteEntry.xRouteNodes->RadixNodeMask = 0;
    xRouteEntry.dwGateway = 0;
#else
    xRouteEntry.dwDstAddr = pxNetworkId->dwDstAddr;
#endif
    xRouteEntry.oIfIdx = NETIFIDX_ANY;
    xRouteEntry.wVlan = NETVLAN_ANY;
    xRouteEntry.eDstAddrType = pxNetworkId->eDstAddrType;

    RoutingTableMsg(ROUTINGTABLEMSG_FINDROUTE,(H_NETDATA)&xRouteEntry);

    pxNetworkId->dwGatewayAddr = xRouteEntry.dwGateway;
    pxNetworkId->oIfIdx = xRouteEntry.oIfIdx;
    pxNetworkId->wVlan = xRouteEntry.wVlan;
    pxNetworkId->eDstAddrType = xRouteEntry.eDstAddrType;
  }


  /*************************************************
   *
   * Determine source address type.
   *
   ************************************************/
  {
    IPTABLEENTRY xIpEntry;

    /*
     * Determine source address type.
     */
    xIpEntry.dwAddr = pxNetworkId->dwSrcAddr;
    xIpEntry.wDefaultVlan = NETVLAN_ANY;
    xIpEntry.oIfIdx = NETIFIDX_ANY;

    eSrcAddrType = (OCTET) IpTableMsg(IPTABLEMSG_GETTYPE, (H_NETDATA) &xIpEntry);
  }


  /************************************************************
   *
   * Send an ICMP message (Desitnation Unreachable with net
   * unreachable code) if a gateway cannot be found
   * or if a link is down.
   *
   ************************************************************/
  if ((pxNetworkId->dwGatewayAddr == INADDR_ANY) ||
      (pxNetworkId->oIfIdx == NETIFIDX_ANY) ||
      (pxRouter->abIsLinkUp[pxNetworkId->oIfIdx] != TRUE)) {

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ROUTER_DBGP(DBGLVL_REPETITIVE,
        "RouterInstanceWrite(): Cannot find gateway or target interface or "
        "link down, Source: %ld.%ld.%ld.%ld Destination: %ld.%ld.%ld.%ld "
        "Gateway: %ld.%ld.%ld.%ld  Interface:%d\n",
        IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
        IPADDRDISPLAY(pxNetworkId->dwDstAddr),
        IPADDRDISPLAY(pxNetworkId->dwGatewayAddr),
        pxNetworkId->oIfIdx);*/
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4,
                                "RouterInstanceWrite(): Cannot find gateway or target interface or, link down, Source: ",
                                pxNetworkId->dwSrcAddr);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " Destination: ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " Gateway: ", pxNetworkId->dwGatewayAddr);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " Interface :", pxNetworkId->oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }

    if (((eSrcAddrType == IPADDRT_MYSUBNET) ||
         (eSrcAddrType == IPADDRT_OUTSIDE)) &&
        (pxRouter->abIsLinkUp[oIfIdxRx] == TRUE)) {
      RouterSendIcmpMsg(hRouterInst,
                        pxNetPacket,
                        pxNetPacketAccess,
                        hData,
                        oIfIdxRx,
                        wVlanRx,
                        (OCTET) ROUTERCBK_DEST_UNREACH_NET_UNREACH);
    }
#ifdef _RADIX_ROUTING_ON_
    else if((eSrcAddrType == IPADDRT_MYADDR) &&
            (pxRouter->abIsLinkUp[pxNetworkId->oIfIdx] != TRUE))
    {
      RouterSendIcmpMsg(hRouterInst,
                        pxNetPacket,
                        pxNetPacketAccess,
                        hData,
                        pxNetworkId->oIfIdx,
                        pxNetworkId->wVlan,
                        (OCTET) ROUTERCBK_LINK_DOWN);
    }
#endif
    NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
    _ROUTERINSTANCEWRITE_RESTORE_RX;
    return (LONG)-1;
  }

  /************************************************************
   *
   * Send an ICMP message (Time Exceeded with time to live
   * exceeded in transit code) if TTL is 1.
   *
   ************************************************************/
  if ((1 == pxNetworkId->oTtL) && (IPADDRT_MYADDR != eSrcAddrType)) {

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ROUTER_DBGP(DBGLVL_REPETITIVE,
        "RouterInstanceWrite():  TTL is 1, Source: %ld.%ld.%ld.%ld "
        "Destination: %ld.%ld.%ld.%ld Gateway: %ld.%ld.%ld.%ld  Interface:%d\n",
        IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
        IPADDRDISPLAY(pxNetworkId->dwDstAddr),
        IPADDRDISPLAY(pxNetworkId->dwGatewayAddr),
        pxNetworkId->oIfIdx);*/
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "RouterInstanceWrite():  TTL is 1, Source: ",
                                pxNetworkId->dwSrcAddr);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " Destination: ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " Gateway: ", pxNetworkId->dwGatewayAddr);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " Interface: ", pxNetworkId->oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }

    if (pxRouter->abIsLinkUp[oIfIdxRx] == TRUE) {
      RouterSendIcmpMsg(hRouterInst,
                        pxNetPacket,
                        pxNetPacketAccess,
                        hData,
                        oIfIdxRx,
                        wVlanRx,
                        (OCTET) ROUTERCBK_TIME_EXCEEDED_TTL_EXPIRED);
    }

    NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
    _ROUTERINSTANCEWRITE_RESTORE_RX;
    return (LONG)-1;
  }


  /************************************************************
   *
   * Routing enable/disable check
   *
   ************************************************************/
  if ((TRUE == pxRouter->abRoutingDisabled[pxNetworkId->oIfIdx]) &&
      (pxRouter->oIfIdxLan != pxNetworkId->oIfIdx)) {

    if ((IPADDRT_MYADDR != eSrcAddrType) &&
        (!((0x0 == pxNetworkId->dwSrcAddr /* DHCP client messages case */) &&
         /* don't send DHCP from LAN on non-routed interfaces */
        (oIfIdxRx != pxRouter->oIfIdxLan))) ) {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
      {
        /*ROUTER_DBGP(DBGLVL_REPETITIVE,
             "RouterInstanceWrite(): Routing disabled on interface %d, "
             "hence dropping packet\n",
             pxNetworkId->oIfIdx);*/
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceWrite(): Routing disabled on interface ",
                            pxNetworkId->oIfIdx);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "hence dropping packet.");
      }
      NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
      _ROUTERINSTANCEWRITE_RESTORE_RX;
      return (LONG)-1;
    }
  }


  /************************************************************
   *
   * Fragmentation check
   *
   ************************************************************/
  if (-1 == RouterCheckFrag(hRouterInst,
                            pxNetPacket,
                            pxNetPacketAccess,
                            hData,
                            oIfIdxRx,
                            wVlanRx)) {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ROUTER_DBGP(DBGLVL_REPETITIVE,
             "RouterInstanceWrite(): MTU exceeded on interface %d, "
             "hence dropping packet\n",
             pxNetworkId->oIfIdx);*/
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceWrite(): MTU exceeded on interface ",
                          pxNetworkId->oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "hence dropping packet");
    }
    NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
    _ROUTERINSTANCEWRITE_RESTORE_RX;
    return (LONG)-1;
  }


  /************************************************************
   *
   * Available bandwidth check
   *
   ************************************************************/
  {
    METERREQUEST xMeterReq;

    xMeterReq.oIfIdx = pxNetworkId->oIfIdx;
    xMeterReq.wSize = pxNetPacketAccess->wLength + pxNetworkId->oIpHdrLen + LINK_SIZE_MIN;
    xMeterReq.oPriority = pxNetPacketAccess->oPriority;

    if (MeterMsg(METERMSG_REQBANDWIDTH,(H_METERDATA)&xMeterReq) < METER_NOERR) {
      NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
      _ROUTERINSTANCEWRITE_RESTORE_RX;
      return (LONG)-1;
    }

    pxNetPacketAccess->oPriority = xMeterReq.oPriority;
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ROUTER_DBGP(DBGLVL_REPETITIVE,
        "RouterInstanceWrite():oIfIdx=%d,%ld.%ld.%ld.%ld ==> %ld.%ld.%ld.%ld: "
        "%s %d,Gateway: %ld.%ld.%ld.%ld\n",
        pxNetworkId->oIfIdx,
        IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
        IPADDRDISPLAY(pxNetworkId->dwDstAddr),
        IpProtoToString(pxNetworkId->oProtocol),
        pxNetworkId->wTotalLen,
        IPADDRDISPLAY(pxNetworkId->dwGatewayAddr));*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceWrite():oIfIdx = ", pxNetworkId->oIfIdx);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", ", pxNetworkId->dwSrcAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " ==> ", pxNetworkId->dwDstAddr);
    DEBUG_PRINT(DEBUG_MOC_IPV4, " " );
    DEBUG_PRINT2(DEBUG_MOC_IPV4, IpProtoToString(pxNetworkId->oProtocol), " wTotalLength ");
    DEBUG_UINT(DEBUG_MOC_IPV4, pxNetworkId->wTotalLen);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Gateway : ", pxNetworkId->dwGatewayAddr);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }


  /************************************************************
   *
   * TTL adjustment
   *
   ************************************************************/
  if (IPADDRT_MYADDR != eSrcAddrType) {
    ASSERT(pxNetworkId->oTtL != 1);
    pxNetworkId->oTtL --;
  }


  /************************************************************
   *
   * Pass the data down
   *
   ************************************************************/
  status = pxRouter->pfnLLWrite(pxRouter->hLLInst,
                              pxRouter->hLLIf,
                              pxNetPacket,
                              pxNetPacketAccess,
                              hData);

  _ROUTERINSTANCEWRITE_RESTORE_RX;

  return status;
}
