#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

DLLIST_ITEM *DLLIST_append_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem)
{
  dllitem->next = NULL;
  dllist->cur = dllitem;
  if (dllist->tail) {
    dllitem->prev = dllist->tail;
    dllist->tail->next = dllitem;
  } else {
    dllitem->prev = NULL;
    dllist->head = dllitem;
  }
  dllist->tail = dllitem;
  dllist->count++;
  return(dllitem);
}

