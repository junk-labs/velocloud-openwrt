/*
 * routing_table_cli.c
 *
 * Implements the routing table
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifdef __MOC_CLI__ /* file is compiled when the __MOC_CLI__ is turned on */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/
#include "arpdefs.h"
#include "../include/socket_inet.h"
#include "../include/if.h"
#include "../include/if_types.h"
#include "../common/netmain.h"
#include "arp_cli.h"

/*
 * ArpCliShow
 */
ubyte4 ArpCliShow(ubyte *cmdRx, ubyte *uSbuf, ubyte4 *uSbufLen)
{
  if(!MOC_STRNICMP(cmdRx, "all", 3))
  {
    ARPCLIGET xArpCliGet;
    xArpCliGet.poSbuf = uSbuf;
    xArpCliGet.dwSbufLen = *uSbufLen;

    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
    ArpInstanceMsg(NETGETINST_ARP, ARPMSG_CLI_SHOW, (H_NETDATA)&xArpCliGet);
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    *uSbufLen = xArpCliGet.dwSbufLen;
  }
  else
    printf("----\nUSAGE : show arp all\n----\n");
  return(0);
}

/*
 * ArpCliConfig
 */
ubyte4 ArpCliConfig(ubyte *cmdRx)
{
  return 0;
}

#endif
