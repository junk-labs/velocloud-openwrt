/*
 * hmac_md5.c
 *
 * HMAC message authentication using md5
 *    code modified from RFC-2104.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "stdlib.h"
#include "strings.h"
#include "cryptcommon.h"
#include "md5.h"
#include "hmac_md5.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*****************************************************************************
 * hmac_md5
 *   poText : pointer to data stream
 *   dwTextLen :length of data stream
 *   poKey : pointer to authentication key
 *   dwKeyLen : length of authentication key
 *   poDigest : pointer to caller digest to be filled in (should be allocated)
 *****************************************************************************/
void hmac_md5(OCTET* poText,
              DWORD dwTextLen,
              OCTET* poKey,
              DWORD dwKeyLen,
              OCTET* poDigest)
{
  MD5_CTX* pxContext;
  OCTET aoKIpad[65];    /* inner padding - */
  OCTET aoKOpad[65];    /* outer padding - */
  int i;

  ASSERT(poText!=NULL);
  ASSERT(poKey!=NULL);
  ASSERT(poDigest!=NULL);

  if (poText && poKey && poDigest) {

    /* if key is longer than 64 bytes reset it to key=MD5(key) */
    if (dwKeyLen > 64) {
      MD5_CTX*      pxTctx;
      OCTET aoTk[MD5_HASH_SIZE];

      pxTctx = (MD5_CTX*) MD5Init();
      MD5Update((H_CRYPT)pxTctx, poKey, dwKeyLen);
      MD5Final((H_CRYPT)pxTctx,aoTk);

      poKey = aoTk;
      dwKeyLen = MD5_HASH_SIZE;
    }

    /*
     * the HMAC_MD5 transform looks like:
     *
     * MD5(K XOR opad, MD5(K XOR ipad, text))
     *
     * where K is an n byte key
     * ipad is the byte 0x36 repeated 64 times
     * opad is the byte 0x5c repeated 64 times
     * and text is the data being protected
     */

    /* start out by storing key in pads */
    bzero( aoKIpad, sizeof aoKIpad);
    bzero( aoKOpad, sizeof aoKOpad);
    bcopy( poKey, aoKIpad, dwKeyLen);
    bcopy( poKey, aoKOpad, dwKeyLen);

    /* XOR key with ipad and opad values */
    for (i=0; i<64; i++) {
      aoKIpad[i] ^= 0x36;
      aoKOpad[i] ^= 0x5c;
    }
    /*
     * perform inner MD5
     */
    pxContext = (MD5_CTX*) MD5Init();        /* init context for 1st pass */
    MD5Update((H_CRYPT)pxContext, aoKIpad, 64);    /* start with inner pad */
    MD5Update((H_CRYPT)pxContext, poText, dwTextLen);/* then text of datagram */
    MD5Final((H_CRYPT)pxContext,poDigest);    /* finish up 1st pass */

    /*
     * perform outer MD5
     */
    pxContext = (MD5_CTX*) MD5Init();        /* init context for 2nd pass */
    MD5Update((H_CRYPT)pxContext, aoKOpad, 64);    /* start with outer pad */
    MD5Update((H_CRYPT)pxContext, poDigest, MD5_HASH_SIZE);    /* then results of 1st */
    MD5Final((H_CRYPT)pxContext,poDigest);    /* finish up 2nd pass */
  }
} /* end of hmac_md5() */

