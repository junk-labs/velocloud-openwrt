/*
 * mac_table.c
 *
 * Packet filtering based upon MAC address used for bridging (802.1d)
/*   MAC addresses are learnt from packets arriving from the local LAN
/*   These addresses can then be used to negatively filter packets
/*   arriving from the local LAN and positively filter packets arriving
/*   from the WAN
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include <NNstyle.h>
#include "ethbridge_flavor.h"
#include <stdlib.h>
#include <strings.h>
#include <pthread.h>
#include "netcommon.h"
#include "ethernet.h"
#include "bridgedbg.h"
#include "macfilter.h"


/***************************************************************************/
/*                           D E B U G   S T U F F                         */
/***************************************************************************/

#ifdef BRIDGEDBG_HI

#define CHECKPOINT(x)   dwMacStage = x
DWORD dwMacStage=__LINE__;
DWORD dwCurrentMacTableEntries = 0;
DWORD dwMaxMacTableEntries = 0;
OCTET oDbgPrintMacTable;

#else

#define CHECKPOINT(x)
#define MACTABLEDEBUG(x)

#endif



/***************************************************************************/
/*                     G L O B A L   V A R I A B L E S                     */
/***************************************************************************/

MACFILTERENTRY *pxMacFilterTable;
extern MACFILTERENTRY *apxFilterEntryHash[];
MACFILTERENTRY * gpxFirstFreeMacEntry;

DWORD dwRefreshMacTicks;

#ifdef BRIDGEDBG_HI
DWORD dbg_dwMacFilterDroppedPkts = 0;
#endif

#ifdef BRIDGEDBG_HI
/***************************************************************************
*  print out the mac list
*
*  par: void
*
*  ret: void
****************************************************************************/
void dbgPrintMacFilterEntries(void)
{
  int i=0;

  printf("\nActive Entry        Mac        Next   LastUsed  Port No.\n");
  for (i=0; i<MAC_FILTER_MAX_ENTRIES; i++) {
    if (pxMacFilterTable[i].dwLastUsed) {
      printf("[%d]:        %02x:%02x:%02x:%02x:%02x:%02x   0x%p   %lu        %d\n",
             i,
             pxMacFilterTable[i].oMacAddr[0], pxMacFilterTable[i].oMacAddr[1],
             pxMacFilterTable[i].oMacAddr[2], pxMacFilterTable[i].oMacAddr[3],
             pxMacFilterTable[i].oMacAddr[4], pxMacFilterTable[i].oMacAddr[5],
             pxMacFilterTable[i].next, pxMacFilterTable[i].dwLastUsed, pxMacFilterTable[i].oIfIdx );
    }
  }
  printf("\n# Current Entries %lu\n",dwCurrentMacTableEntries);
  printf("Max # Entries %lu\n",dwMaxMacTableEntries);
}

void dbgPrintMacFilterHash(void)
{
  int i = 0;

  printf("\nidx  MacFilterHash[idx]\n");
  for (i = 0; i < MAC_FILTER_HASH_SIZE; i++) {
    printf("%d:  %p\n", i, apxFilterEntryHash[i]);
  }
}
#endif



/***************************************************************************
*  Delete an MAC mapping entry in the cache.
*
*  par: paddr    IP address to delete
*
*  ret: void
****************************************************************************/
void _MacDeleteEntry(MACFILTERENTRY *ppxFilterEntry, MACFILTERENTRY *pxFilterEntry, int nMacHashIdx)
{

  ETH_DBGP(NORMAL, "_MacDeleteEntry(): entered for *ppxFilterEntry 0x%p, pxFilterEntry 0x%p, hash table idx %d\n",
                ppxFilterEntry, pxFilterEntry, nMacHashIdx);

  if (apxFilterEntryHash[nMacHashIdx] == pxFilterEntry) {
    apxFilterEntryHash[nMacHashIdx] = pxFilterEntry->next;
  }
  else {
    ppxFilterEntry->next = pxFilterEntry->next;
  }

  /* Clear entry from pxMacFilterTable */
  MOC_MEMSET(((ubyte *) pxFilterEntry), 0x00, sizeof(MACFILTERENTRY));

  /* Add this pxFilterEntry to the free list */
  pxFilterEntry->next = gpxFirstFreeMacEntry;
  gpxFirstFreeMacEntry = pxFilterEntry;

#ifdef BRIDGEDBG_HI
  dwCurrentMacTableEntries--;
#endif
  return;
}


/***************************************************************************
*  update the entries in the MAC table
*
*  par: void
*
*  ret: void
****************************************************************************/
void MacFilterRefresh(DWORD dwTimeout)
{
  static DWORD dwMacTimeout = MAC_FILTER_TIMEOUT_DEFAULT;
  MACFILTERENTRY *pxFilterEntry;
  MACFILTERENTRY **ppxFilterEntry;
  int i = 0;

  dwMacTimeout = dwTimeout;

#ifdef BRIDGEDBG_HI
    if (oDbgPrintMacTable) {
      dbgPrintMacFilterHash();
      dbgPrintMacFilterEntries();
      oDbgPrintMacTable = 0;
    }
    {
     static DWORD dwOldTimeout = 0;
      if (dwOldTimeout != dwMacTimeout) {
        ETH_DBGP(NORMAL,
          "Mac table timeout changed from %lds to %lds\n",
          (DWORD)(dwOldTimeout/1000),
          (DWORD)(dwMacTimeout/1000));
        dwOldTimeout = dwMacTimeout;
      }
    }
#endif

  CHECKPOINT(__LINE__);
  for (i = 0; i < MAC_FILTER_HASH_SIZE; i++) {
    ppxFilterEntry = &apxFilterEntryHash[i];
    while ((pxFilterEntry = *ppxFilterEntry) != NULL) {
      if (dwRefreshMacTicks - pxFilterEntry->dwLastUsed > dwMacTimeout) {
        ETH_DBGP(NORMAL, "MacFilterRefresh(): delete entry %02x:%02x:%02x:%02x:%02x:%02x\n",
              pxFilterEntry->oMacAddr[0], pxFilterEntry->oMacAddr[1],
              pxFilterEntry->oMacAddr[2], pxFilterEntry->oMacAddr[3],
              pxFilterEntry->oMacAddr[4], pxFilterEntry->oMacAddr[5]);
        _MacDeleteEntry((MACFILTERENTRY *) ppxFilterEntry, pxFilterEntry, i);
        if (pxFilterEntry == *ppxFilterEntry)
          ppxFilterEntry = &pxFilterEntry->next;
      }
      else
        ppxFilterEntry = &pxFilterEntry->next;
    }
  }
  CHECKPOINT(__LINE__);
}


/***************************************************************************
*  Create an Mac entry.  The caller should check for duplicates!
*
*  par: addr    MAC address pointer
*
*  ret: 0 Sucess, -1 Fail
****************************************************************************/
LONG _MacFilterCreateEntry(OCTET *poMacAddr, OCTET oIfIdx)
{
  DWORD dwHash, dwMin = 0xFFFFFFFF;
  MACFILTERENTRY *pxFreeMacEntry = NULL, **ppxOldestEntry, *pxFilterEntry, *pxPrevFreeMacEntry = NULL;
  INT i, iHashIdx = -1;

  pxFreeMacEntry = gpxFirstFreeMacEntry;
  if (NULL != pxFreeMacEntry) {
    gpxFirstFreeMacEntry = gpxFirstFreeMacEntry->next;
    ETH_DBGP(REPETITIVE, "_MacFilterCreateEntry(): Table NOT full next 0x%p\n",gpxFirstFreeMacEntry);
  } else  {
    ETH_DBGP(NORMAL, "_MacFilterCreateEntry(): Table full next 0x%p\n", gpxFirstFreeMacEntry);
    /* The Table is full, Use LRU to delete least recently used entry */
    /* Find Least recently used entry */
    for (i=0; i<MAC_FILTER_HASH_SIZE; i++) {
      ppxOldestEntry = &apxFilterEntryHash[i];
      while ((pxFilterEntry = *ppxOldestEntry) != NULL) {
        if (pxFilterEntry->dwLastUsed < dwMin) {
          dwMin = pxFilterEntry->dwLastUsed;
          pxFreeMacEntry = pxFilterEntry;
          pxPrevFreeMacEntry = (MACFILTERENTRY *) ppxOldestEntry;
          iHashIdx = i;
        }
        ppxOldestEntry = &pxFilterEntry->next;
      }
    }
    /* Free that entry, verify success */
    _MacDeleteEntry((MACFILTERENTRY *) pxPrevFreeMacEntry, pxFreeMacEntry, iHashIdx);
    if (!gpxFirstFreeMacEntry)
      return -1;
    gpxFirstFreeMacEntry = NULL;
  }

  /* Fill in the allocated Mac cache entry. */
  dwHash = poMacAddr[5] & (MAC_FILTER_HASH_SIZE - 1);
  MOC_MEMCPY((ubyte *)pxFreeMacEntry->oMacAddr,
        (ubyte *)poMacAddr, ETHADDRESS_LEN);
  pxFreeMacEntry->dwLastUsed = dwRefreshMacTicks;
  pxFreeMacEntry->oIfIdx = oIfIdx;
  pxFreeMacEntry->next = apxFilterEntryHash[dwHash];
  apxFilterEntryHash[dwHash] = pxFreeMacEntry;

  ETH_DBGP(NORMAL,
       "_MacFilterCreateEntry(): Port: %d Addr: %02x:%02x:%02x:%02x:%02x:%02x\n",
       oIfIdx,
       HWADDRDISPLAY(poMacAddr));

#ifdef BRIDGEDBG_HI
  dwCurrentMacTableEntries++;
  if ( dwCurrentMacTableEntries > dwMaxMacTableEntries)
    dwMaxMacTableEntries = dwCurrentMacTableEntries;
#endif

  return 0; /* successful */
}


/***************************************************************************
*  Add an entry to the Mac cache.  Check for dupes!
*
*  par: poMacAddr    pointer to a MAC addr
*
*  ret: void
****************************************************************************/
void MacFilterAdd(OCTET *poMacAddr, OCTET oIfIdx)
{
  MACFILTERENTRY *pxFilterEntry;

  /* First see if the address is already in the table. */
  pxFilterEntry = MacFilterLookup(poMacAddr);
  if (NULL  != pxFilterEntry) {
    /* Overwrite the existing port number (even if it is the same) */
    /* Mac addresses are unique in the table */
    pxFilterEntry->oIfIdx = oIfIdx;
    pxFilterEntry->dwLastUsed = dwRefreshMacTicks;
    return;
  }
  _MacFilterCreateEntry(poMacAddr, oIfIdx);
}



/****************************************************************************
 * MacFilterCreate - Allocate an initialize the Mac table
 *
 *  param: void
 * return: 0 Success, -1 Failure
 ****************************************************************************/
LONG MacFilterCreate(void)
{
  int idx;

  /* Initialize Mac Free Entry Table list */
  if ((pxMacFilterTable =
        MALLOC(MAC_FILTER_MAX_ENTRIES*sizeof(MACFILTERENTRY))) <= 0)
    return -1;
  MOC_MEMSET((ubyte *)pxMacFilterTable, 0,
                          MAC_FILTER_MAX_ENTRIES*sizeof(MACFILTERENTRY));
  for (idx=0;idx<MAC_FILTER_MAX_ENTRIES - 1;idx++) {
    pxMacFilterTable[idx].next = &pxMacFilterTable[idx + 1];
  }
  pxMacFilterTable[MAC_FILTER_MAX_ENTRIES - 1].next = NULL;
  gpxFirstFreeMacEntry = &pxMacFilterTable[0];
  return 0;
}


/****************************************************************************
 * MacFilterDestroy(void) - free Mac table
 *
 *  param: void
 * return: void
 ****************************************************************************/
void MacFilterDestroy(void)
{
  if (pxMacFilterTable)
    FREE(pxMacFilterTable);
  gpxFirstFreeMacEntry = NULL;
  pxMacFilterTable = NULL;
}

