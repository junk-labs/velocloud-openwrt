/*
 * connect.c
 *
 * implement the connect function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"

#ifdef IPSEC
#include "ipsec.h"
#endif /* IPSEC */

#ifdef SOCK_RT
  #include "nat.h"
#endif

#ifdef SOCK_BR
  #include "ethernet.h"
#endif

#include "../libsock/libsockserver.h"
/****************************************************************************
 *
 * Debug
 *
 ****************************************************************************/
SOCKET_DBG_VAR(DWORD dbg_dwConnectLine=0);


/****************************************************************************


****************************************************************************/

extern sbyte4  mn_connect_func(int sockfd, const struct sockaddr *pSockAddrServer,
            socklen_t addrlen, mn_sock_connect_cb_t cb, void *cbarg,void *ipc_req);
/****************************************************************************
 *
 * Socket API functions
 *
 ****************************************************************************/
/*
 * connect
 *  Used by a TCP or UDP client to establish a connection with a server.
 *  Remarks: A UDP client can also use the connect function. This only stores
 *   the address/port specified in the servaddr structure, so that the system
 *   knows where to send any future data that the application writes to the
 *   sockfd. Also, only datagrams from this address will be received
 *   from the socket. Once connect() has been called on a UDP socket, send()
 *   must be used instead of sendto() and recv() must be used instead of
 *   recvfrom().
 *
 *  Args:
 *   sockfd                      The socket returned by the socket function.
 *   servaddr                    The structure in which the remote IP address
 *                               and remote port should be specified.
 *   addrlen                     size of the servaddr structure.
 *
 *  Return:
 *   0 : Success. A connection to remote server has been established.
 *   -1: Error
 */
#ifndef __MOCANA_ASYNC_API__
int mn_connect(int sockfd, const struct sockaddr *pSockAddrServer,
               socklen_t addrlen, mn_sock_connect_cb_t cb, void *cbarg)
{
     return(mn_connect_func(sockfd, pSockAddrServer, addrlen, cb, cbarg,NULL));
}
#else
int mn_connect(int sockfd, const struct sockaddr *pSockAddrServer,
               socklen_t addrlen)
{
     return(mn_connect_func(sockfd, pSockAddrServer, addrlen, NULL, NULL, NULL));
}
#endif


int mn_connect_func(int sockfd, const struct sockaddr *pSockAddrServer,
            socklen_t addrlen, mn_sock_connect_cb_t cb, void *cbarg,void *ipc_req)
{
  struct sockaddr_in *pSockAddrInServer =
    (struct sockaddr_in *) pSockAddrServer;
  int lReturn = -1;
  SOCKET *pxSock;
  DWORD dwDstAddr;
  OCTET oProtIdx;
  H_NETINSTANCE hInst;
  PFN_NETIOCTL pfnIoctl;
  TRANSPORTID *pxId;
  NETWORKID *pxNetId;

  /*
   * Argument check
   */
  if( pSockAddrServer == 0) {
    mn_errno = MO_EFAULT;
    SOCKET_CHECKPOINT(dbg_dwConnectLine);
    return -1;
  }

  /* A non-zero sockaddr structure */
  /* Length should be proper */
  if(addrlen != sizeof(struct sockaddr_in) ||
     (pSockAddrInServer->sin_family != AF_INET)) {
#ifdef __RTOS_VXWORKS__
    mn_errno = MO_EINVAL;
#else
    mn_errno = MO_EBADR;
#endif
    SOCKET_CHECKPOINT(dbg_dwConnectLine);
    return -1;
  }

  /* If remote ip or port is zero, return error
   * you have to connect to some valid address.
   * !!! SB TO DO If remote ip=0, connect to local host !!!
   */
  if(pSockAddrInServer->sin_addr.s_addr == 0 ||
     pSockAddrInServer->sin_port == 0 ) {
    mn_errno = MO_ECONNREFUSED; /* Specify foreign socket unspecified ANVL 4.17 s3.9 p56 rfc 793 */
    SOCKET_CHECKPOINT(dbg_dwConnectLine);
    return -1;
  }
#if 0
  ASSERT((pSockAddrInServer != NULL) &&
         (addrlen == sizeof(struct sockaddr_in)) &&
         (pSockAddrInServer->sin_family == AF_INET) &&
         (pSockAddrInServer->sin_addr.s_addr != 0)  &&
         (pSockAddrInServer->sin_port != 0));
#endif

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(sockfd);

  if (pxSock == NULL) {
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    mn_errno = MO_EBADF;
    SOCKET_CHECKPOINT(dbg_dwConnectLine);
    return -1;
  }


  oProtIdx = SOCKTYPE2PROTINDEX(pxSock->lType);
  pfnIoctl = xSocketRep.axProtocols[oProtIdx].pfnIoctl;
  hInst = xSocketRep.axProtocols[oProtIdx].hInst;

  pxId = &(pxSock->xTransportId);
  pxNetId = (NETWORKID *)(&pxId->xNetId);

  dwDstAddr = ntohl(pSockAddrInServer->sin_addr.s_addr);

  if ((pxSock->oBoundFlag & SOCKETBOUNDFLAG_IP) &&
      (pxNetId->dwSrcAddr == dwDstAddr)) {
    /* Dst and Src Addr are the same */
    if (pxId->wSrcPort == ntohs(pSockAddrInServer->sin_port)) {
      /* Disallow user from connecting to itself on same port.
         Note: the Ip address will never be bound if
         the port is not also bound. So that the port setting
         checked-here will always be valid */
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      mn_errno = MO_EADDRNOTAVAIL;
      return -1;
    }
  }

  /* Get the route.
     This will also calculate the dst addr type */
  {
    ROUTEENTRY xRoute;

#if 0
    xRoute.dwDstAddr = htonl(dwDstAddr);
#else
#ifdef _RADIX_ROUTING_ON_
    xRoute.xRouteNodes->RadixNodeKey  = dwDstAddr;
    xRoute.xRouteNodes->RadixNodeMask = 0;
    xRoute.dwGateway                  = 0;
#else
    xRoute.dwDstAddr = dwDstAddr;
#endif
#endif
    /*  xRoute.oIfIdx = pxNetId->oIfIdx; */
    /* Atul - Forcing to get the correct ofIdx */
    xRoute.oIfIdx = NETIFIDX_ANY;
    xRoute.wVlan = pxNetId->wVlan;
    xRoute.eDstAddrType = IPADDRT_UNKNOWN;

    if (RoutingTableMsg(ROUTINGTABLEMSG_FINDROUTE,
                        (H_NETDATA)&(xRoute)) < 0) {
      mn_errno = MO_EHOSTDOWN;
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return -1;
    }

    pxNetId->dwGatewayAddr = xRoute.dwGateway;
    pxNetId->eDstAddrType = xRoute.eDstAddrType;
    pxNetId->oIfIdx = xRoute.oIfIdx;
  }

  pxNetId->dwDstAddr = dwDstAddr;
  pxNetId->dwSrcAddr =
    xNetWrapper.pxIfConf[pxNetId->oIfIdx].pxIPAlias[0].dwAddr;

  if ((pxSock->oBoundFlag & SOCKETBOUNDFLAG_TOS) == 0) {
    pxNetId->oToS = xNetWrapper.pxIfConf[pxNetId->oIfIdx].oTos;
  }

  if (pxNetId->eDstAddrType == IPADDRT_MULTICAST) {
    ASSERT(pxSock->lType == SOCK_DGRAM);
    pxNetId->oTtL = pxSock->u.pxUdp->oMcastTtl;
  }

  /*Set protocol*/
  if(pxSock->lType == SOCK_DGRAM){
    pxNetId->oProtocol = IPPROTO_UDP;
  } else {
    pxNetId->oProtocol = IPPROTO_TCP;
  }

  pxId->wDstPort = ntohs(pSockAddrInServer->sin_port);

  if (pxId->wSrcPort == 0) {
    pfnIoctl(hInst,pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_SETLOCALPORT,
             (H_NETDATA)0);
    /* Query the local port */
    pfnIoctl(hInst,pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT,
             (H_NETDATA)&(pxId->wSrcPort));
  }
  ASSERT(pxId->wSrcPort != 0);
  pxId->wSrcPort =   pxId->wSrcPort;

  /* Set the Security Policy */
#ifdef IPSEC
  if ((pxNetId->dwSecurityPolicy = (DWORD)
       IPSecGetSP(dwDstAddr,pxId->wDstPort,pxNetId->dwSrcAddr,pxId->wSrcPort,
                  pxNetId->oProtocol, 0))) {
    pxNetId->wIpSecHdrLength =
                       IPSecGetHdrLen((void *)pxNetId->dwSecurityPolicy);
  }
#endif

  /* Set up the Connection to the connect type */
  lReturn =  pfnIoctl(hInst,pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_CONNECT,
           (H_NETDATA)pxId);
  /*
  if (lReturn != 0) {
    mn_errno = lReturn;
    lReturn = -1;
  }
  */


  /* Early checks succeeded: call the connect function */
  lReturn = xSocketRep.axProtocols[oProtIdx].pfnConnectConn(pxSock, cb, cbarg,ipc_req);


  if (lReturn != 0) {
    mn_errno = lReturn;
    lReturn = -1;
  }

  /* Connect successfull. Force the binding of the IF, IP and ToS */
  pxSock->oBoundFlag |= (SOCKETBOUNDFLAG_IF |
                         SOCKETBOUNDFLAG_IP |
                         SOCKETBOUNDFLAG_TOS);

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  SOCKET_CHECKPOINT(dbg_dwConnectLine);

  return lReturn;
}
