/*
 * socketio.c
 *
 * Provides functions for socket I/O.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "nettime.h"
#include "../include/netselect.h"
#include "../include/if.h"
#include "mqueue.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netdefs.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "../libsock/libsockserver.h"


/****************************************************************************
 *
 * DEBUG Apparatus
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Typedef & structure
 *
 ****************************************************************************/
struct timeval
  {
    long int tv_sec;            /* Seconds.  */
    long int tv_usec;      /* Microseconds.  */
  };

/*
 * Select set basic structure
 */

#define MN_READSET_MASK 0x01
#define MN_WRITESET_MASK 0x02

typedef struct selectfdset {
  mo_fd_set xRdFdSet;
  mo_fd_set xWrFdSet;
  pthread_cond_t xCond;  /* A Condition variable, per thread for select
                            fd_set */
  struct timespec tsAbsTimeOut;
  OCTET  oInUse;         /* Used as a BOOL for now (SB Aug-2001) */
  ubyte  *ipc_req;
  ubyte  bitMask;
  ubyte4 iMaxFd;
#ifndef __SELECT_OPT_ON__
  sbyte4 lPid; /* The Pid to which this select belongs */
#endif
} SELECTFDSET;


/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/
SELECTFDSET gaxSelectInfo[MAX_SELECTS];

/****************************************************************************
 *
 * Local functions
 *
 ****************************************************************************/

void    TimespecAdd(struct timespec *tsTimeOut, struct timespec * pxTsTimeOut, struct timespec * sTimeOut) {
    sTimeOut->tv_sec = tsTimeOut->tv_sec + pxTsTimeOut->tv_sec;
    sTimeOut->tv_nsec = tsTimeOut->tv_nsec + pxTsTimeOut->tv_nsec;

}
void    TimespecAddNsec(struct timespec *tsTimeOut, DWORD pxTs) {
    tsTimeOut->tv_nsec +=  pxTs;

}
/*
 * _SocketGetFirstEmptySelectSetIdx
 *  Go through gaxSelectInfo to find empty slot. Return the index
 *  or -1 (if no slot is available)
 *
 *  Args:
 *
 *  Return:
 *   slot index (success) or -1
 */
int _SocketGetFirstEmptySelectSetIdx()
{
  int i;

  /* Go through selectfdset array to find empty slot */
  for (i=0; i<MAX_SELECTS; i++) {
    if (gaxSelectInfo[i].oInUse == 0) {
      return i;
    }
  }

  /* No select available */
  ASSERT(0);
  return -1;
}

/*
 * _SocketSetSelectFlag
 *  Indicate a select in progress for all sockets in set.
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pReadSet                     select read set
 *   pWriteSet                    select write set
 *   flag                         select started / ended
 *
 *  Return:
 *   >=0 for success
 */
#ifndef __SELECT_OPT_ON__
LONG _SocketSetSelectFlag(mo_fd_set *pReadSet, mo_fd_set *pWriteSet, BOOL bFlag, LONG lPid)
#else
LONG _SocketSetSelectFlag(mo_fd_set *pReadSet, mo_fd_set *pWriteSet, BOOL bFlag)
#endif
{
  int i;
  SOCKET *pxSock;
#ifndef __SELECT_OPT_ON__
  RBLIST    *rbList = NULL;
  PIDINFO   *pxPid = NULL;
  PIDINFO    xPid;
  PIDFDINFO *pxPidFd = NULL;
  xPid.lPid = lPid;

  pxPid = rbfind(&xPid, xSocketRep.pidTree);
  if (!pxPid)
    return -1;
#endif

#ifndef __SELECT_OPT_ON__
  rbList = rbopenlist(pxPid->fdTree);
  while ((pxPidFd = (PIDFDINFO *)rbreadlist(rbList))) {
    i = pxPidFd->lFd;
#else
  for (i=0;i<MAX_FD;i++) {
#endif
    if (((MO_FD_ISSET(i, pReadSet)) != 0) || ((MO_FD_ISSET(i,pWriteSet)) != 0))     {
      pxSock = RETRIEVE_SOCKET(i);
      ASSERT(pxSock != NULL);
      if(pxSock != NULL) {
        if (bFlag == TRUE) {
          pxSock->oSelect++;
        }
        else      {
          ASSERT(pxSock->oSelect > 0);
          pxSock->oSelect--;
        }
      }
    }
  }
#ifndef __SELECT_OPT_ON__
  rbcloselist(rbList);
#endif

  return 1;
}

/*
 * SocketWakeSelect
 *  Wakeup select on behalf of a socket (connection) which can now send
 *  or receive data.
 *  !!! Does not lock the mutex !!!
 *
 * Args:
 *  lFd                          socket file descriptot
 *  oType                        available for read or write
 *
 * Return:
 *  >=0
 */
LONG SocketWakeSelect(SOCKET *pxSock, OCTET oType)
{
  int i,nRet ;
  mo_fd_set *hReadSet = NULL, *hWriteSet = NULL;
  LONG lFd = pxSock->lFd;

  if (pxSock->lType == SOCK_STREAM) {
    pxSock->u.pxTcp->oType = oType;
  }

  if (pxSock->oSelect > 0) {
    /* Go over SelectInfo list, wake up the threads which were
       waiting on this particular socket */
    for (i = 0; i < MAX_SELECTS; i++) {
      if (gaxSelectInfo[i].oInUse &&
          (((oType & SELECT_RD) && MO_FD_ISSET(lFd, &(gaxSelectInfo[i].xRdFdSet))) ||
           ((oType & SELECT_WR) && MO_FD_ISSET(lFd, &(gaxSelectInfo[i].xWrFdSet))))) {
        if (gaxSelectInfo[i].ipc_req)
        {
            if (gaxSelectInfo[i].bitMask & MN_READSET_MASK)
                hReadSet = &(gaxSelectInfo[i].xRdFdSet);
            if (gaxSelectInfo[i].bitMask & MN_WRITESET_MASK)
                hWriteSet = &(gaxSelectInfo[i].xWrFdSet);

            nRet = checkSelectFds( hReadSet, hWriteSet,
                            (gaxSelectInfo[i].xRdFdSet),
                            (gaxSelectInfo[i].xWrFdSet),
                            (gaxSelectInfo[i].iMaxFd));

#ifndef __SELECT_OPT_ON__
            _SocketSetSelectFlag(&(gaxSelectInfo[i].xRdFdSet),
                                 &(gaxSelectInfo[i].xWrFdSet),FALSE, gaxSelectInfo[i].lPid );
#else
            _SocketSetSelectFlag(&(gaxSelectInfo[i].xRdFdSet),
                                 &(gaxSelectInfo[i].xWrFdSet),FALSE );
#endif
#ifdef __MOCANA_IPC_LIBSOCK__
            SOCKSERVER_selectReply(gaxSelectInfo[i].ipc_req,nRet);
#endif
            MOC_MEMSET((ubyte *) &(gaxSelectInfo[i]), 0x00, sizeof(SELECTFDSET));
        }
        else
            pthread_cond_broadcast(&gaxSelectInfo[i].xCond);
      }
    }
  }

  return 0;
}


/*
 * SocketRcvRdy
 *  check if socket ready to receive (for select purpose)
 *  !!! Does not lock the mutex !!!
 *
 *  Arg:
 *   nSockFd                socket to check
 *
 *  Return:
 *   1 if ready, 0 if not ready , -1 if error
 */
SHORT SocketRcvRdy(SHORT sSockFd)
{
  SOCKET *pxSock;
  SHORT sReturn = -1;

  pxSock = RETRIEVE_SOCKET(sSockFd);

  if (pxSock != NULL) {
    if (pxSock->lType == SOCK_DGRAM) {
      /* UDP */
      ASSERT(pxSock->u.pxUdp != NULL);
      if (pxSock->u.pxUdp->wBufferedLength > 0) {
        sReturn = 1;
      }
    }
    else if (pxSock->lType == SOCK_STREAM){
      OCTET *poType;
      ASSERT(pxSock->u.pxTcp != NULL);
      poType = &pxSock->u.pxTcp->oType;
      /* Must be a connected TCP socket */
      if (*poType & SELECT_RD) {
        *poType &= ~SELECT_RD;
        sReturn = 1;
      } else if (pxSock->dwSockOptions & SO_ACCEPTCONN) {
        /* Listen socket */
        if (NULL != PeekQueueFront(pxSock->u.pxTcp->u.pxListen->qWaitForAccept)) {
          sReturn = 1;
        }
      } else {
        WORD wLength;
        /* Connection socket */
        TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                                    pxSock->hLL,
                                    TCPULINTERFACEIOCTL_GETRXDATALENGTH,
                                    (H_NETDATA)
                                    &wLength);
        if (wLength > 0) {
          sReturn = 1;
        }
      }
    } else {
      ASSERT(0);
    }
  }

  return sReturn;
}

/*
 * SocketSndRdy
 *  Check if socket ready to send
 *  !!! Does not lock the mutex !!!
 *  Args:
 *   sSockFd                   socket to check
 *
 *  Return:
 *   1 if ready, 0 if not ready , -1 if error
 */
SHORT SocketSndRdy(SHORT sSockFd)
{
  SOCKET *pxSock;
  SHORT sReturn = -1;

  pxSock = RETRIEVE_SOCKET(sSockFd);

  if ((pxSock != NULL) &&
      ((pxSock->dwSockState & SS_CANTSENDMORE) == 0)) {
    if (pxSock->lType == SOCK_DGRAM) {
      /* Always ready to send in the SOCK_DGRAM case  */
      sReturn = 1;
    } else if ((pxSock->lType == SOCK_STREAM) &&
               (pxSock->dwSockOptions & SO_ACCEPTCONN) == 0) {
      WORD wTxAvailableSpace;

      /* No need to check the TCP oType, as the call to
         get the Tx available space is necessary anyway */
      TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                                  pxSock->hLL,
                                  TCPULINTERFACEIOCTL_GETTXAVAILSPACE,
                                  (H_NETDATA)&wTxAvailableSpace);
      if ((pxSock->dwSockState & SS_CANTSENDMORE) ||
          ((pxSock->dwSockState & SS_ISCONNECTED) &&
           (wTxAvailableSpace > 0))) {
        sReturn = 1;
      }
    }
  }
  else {
    /* The socket has either been closed or reset */
    sReturn = 1;
  }

  return sReturn;
}


/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/


/*
 * recv
 *  Used to receive a message on an established connection.
 *  Async operation is always zero-copy.
 *
 *  Args:
 *     lSockfd       The socket returned by the socket function.
 *     buff          The buffer into which data will be stored.
 *     nbytes        Maximum number of bytes to be received.
 *     Flags         Ignored. Future implementation.
 *     pBuff         Zero-copy sync operation. Ptr to ptr to
 *                   data is stored here on return.
 *                   Free that pointer using mn_sock_free_recvbuf().
 *     pFreeArg      Arg to be passed to mn_sock_free_recvbuf();
 *
 *  Return:
 *   0 or more : Number of bytes read.
 *   -1: Error
 */
#ifndef __MOCANA_ASYNC_API__
ubyte4 mn_recv(int lSockfd, void *buff, ubyte4 nbytes, int iFlags,
            mn_sock_recv_cb_t pfCb, void *pvCbArg, /* async stuff */
                void **pBuff, void **pFreeArg) /* zero-copy stuff */
#else
ubyte4 mn_recv(int lSockfd, void *buff, ubyte4 nbytes, int iFlags)
#endif
{

#ifndef __MOCANA_ASYNC_API__
  return(mn_recvfrom(lSockfd, buff, nbytes, iFlags, 0, 0,
            pfCb, pvCbArg,       /* async stuff */
            pBuff, pFreeArg));   /* zero-copy stuff */
#else
  return(mn_recvfrom(lSockfd, buff, nbytes, iFlags, 0, 0));
#endif
}


/*
 * send
 *  Send a message on an established connection.
 *  If MN_ZEROCOPY flags bit is set in iFlags,
 *    -  buff should have been alloced using mn_sock_getbuf().
 *    -  nbytes should be <= nbytes passed to mn_sock_getbuf()
 *    -  buff will be freed upon return i.e. it can not be reused by app.
 *
 * Args:
 *  lSockfd                      The socket returned by the socket function.
 *  buff                         The buffer that needs to be sent.
 *  nbytes                       Number of bytes to be sent.
 *  Flags                        Ignored. Future Implementation.
 *
 * Return:
 *  0 or more : Number of bytes sent.
 *  -1: Error
 */
ubyte4 mn_send(int lSockfd, void *buff, ubyte4 nbytes, int iFlags)
{

  return(mn_sendto(lSockfd, buff, nbytes, iFlags,
                NULL,0));

}


/*
 * pselect
 *  Waits for multiple events on a set of sockets
 *  A maximum of OPEN_MAX sockets are possible.
 *  Following macros are used to fill read/write/except socket sets.
 *  Macro                      Description
 *  FD_ZERO(&fd_set)           Clears the socket list
 *  FD_SET(sockfd, &fd_set)    Add sockfd to the socket set.
 *  FD_CLR(sockfd, &fd_set)    Remove sockfd from the socket set.
 *  FD_ISSET(sockfd, &fd_set)  Query the set. Return non-zero is sockfd is
 *                             in set
 *
 *  Args:
 *   iMaxFdP1                     Highest numbered socket to be tested + 1.
 *   pxFdSetRead                     Specify the sockets to test for reading.
 *   pxFdSetWrite                    Specify the sockets to test for write.
 *   pxFdSetExcept                   Specify the sockets to test for exception.
 *   pxTsTimeOut                     Specify the time after which sockselect() will
 *                               return if none of the read, write, except
 *                               events occur. There are 3 possibilities:
 *                                1. To wait forever, specify 'pxTsTimeOut' as
 *                                null pointer.
 *                                2. To wait for a fixed amount or return if
 *                                events are detected, specify the time to
 *                                wait in 'pxTsTimeOut'.
 *                                3. To not wait at all and return immediately
 *                                after checking all the sockets, specify the
 *                                number of seconds and microseconds in the
 *                                timeval structure as zero.
 *
 *  Return:
 *   0 : timeout occurred.
 *   -1: Error
 *   >0: ie number of sockets on which the specified events did occur.
 */
int
mn_pselect(int iMaxFdP1, mo_fd_set *pxFdSetRead, mo_fd_set *pxFdSetWrite,
        mo_fd_set *pxFdSetExcept, const struct timespec *pxTsTimeOut, ubyte *ipc_req)
{
  struct timespec tsTimeOut;
  int nRc = 0;
  mo_fd_set hReadSet, hWriteSet;
  int nRet = 0, iFd, iFdBase, idx = -1;
  mo_fd_mask xFdMaskBits;
#ifndef __SELECT_OPT_ON__
  RBLIST    *rbList = NULL;
  PIDINFO   *pxPid = NULL;
  PIDINFO    xPid;
  PIDFDINFO *pxPidFd = NULL;
  xPid.lPid = RTOS_currentThreadId();

  pxPid = (PIDINFO *)rbfind(&xPid, xSocketRep.pidTree);
  if (!pxPid)
    return -1;
#endif

  ASSERT(pxFdSetExcept == NULL); /* does not support except set now */

  if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
  {
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "mn_pselect: locking\n");
  }
  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
  if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
  {
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "mn_pselect: locked\n");
  }

  /*iMaxFdP1 &= DEVICE_NMBR_MASK; RS: no need to apply msk. app fds are full 32 bits */

  /* We copy and zero the whole array even though only part of it may
   * be used.  We could copy only the needed DWORDS for efficiency if
   * more sockets are used in the future.
   */
  MO_FD_ZERO(&hReadSet);
  MO_FD_ZERO(&hWriteSet);

  if (pxFdSetRead)  {
    hReadSet = *pxFdSetRead;
    MO_FD_ZERO(pxFdSetRead);
  }

  if (pxFdSetWrite) {
    hWriteSet = *pxFdSetWrite;
    MO_FD_ZERO(pxFdSetWrite);
  }

  idx = _SocketGetFirstEmptySelectSetIdx();
  ASSERT((0 <= idx) && (idx < MAX_SELECTS));

  pthread_cond_init(&gaxSelectInfo[idx].xCond,NULL);

#ifndef __SELECT_OPT_ON__
  gaxSelectInfo[idx].lPid = xPid.lPid;
#endif
  /* calculate timeout, this value should not be recomputed in case of a
     false wake up */
  if (pxTsTimeOut) {
    clock_gettime(CLOCK_REALTIME, &tsTimeOut);
    TimespecAdd(&tsTimeOut, (struct timespec *)pxTsTimeOut, &tsTimeOut);
  }

  while (1) {
    /* Check and Post:
     *  Check which sockets for rd/wr/ex the app wants to select on. If
     *  data is available (rd/wr/ex) change pxFdSetRead/pxFdSetWrite and return.
     *  else Post this info into selectfdset
     */
    /* Note: SB-March 2002. This code does not check the
       socket Id:If a socket is closed then re-opened while asleep, it will
       not detect it. However, this should not happen often, and
       will not cause much trouble if it does */
    if (pxFdSetRead) {
#ifndef __SELECT_OPT_ON__
      rbList = rbopenlist(pxPid->fdTree);
      while ((pxPidFd = (PIDFDINFO *)rbreadlist(rbList))) {
        if (pxPidFd->lFd >= iMaxFdP1)
          continue;
        iFdBase = pxPidFd->lFd;
        if (MO_FD_ISSET(iFdBase, &hReadSet)) {
          if (SocketRcvRdy(iFdBase) > 0) {
            /* data is available for reading */
            MO_FD_SET(iFdBase, pxFdSetRead);
            nRet++;
          }
        }
#else
      for (iFdBase = 0; iFdBase < iMaxFdP1; iFdBase += MO_NFDBITS) {
        for (xFdMaskBits = hReadSet.__fds_bits[iFdBase/MO_NFDBITS], iFd = iFdBase;
             xFdMaskBits && iFd < iMaxFdP1;
             xFdMaskBits >>= 1, iFd++) {
          if (xFdMaskBits & 1) {
            if (SocketRcvRdy(iFd) > 0) {
              /* data is available for reading */
              MO_FD_SET(iFd, pxFdSetRead);
              nRet++;
            }
          }
        }
#endif
      }
#ifndef __SELECT_OPT_ON__
      rbcloselist(rbList);
#endif
    }

    if (pxFdSetWrite) {
#ifndef __SELECT_OPT_ON__
      rbList = rbopenlist(pxPid->fdTree);
      while ((pxPidFd = (PIDFDINFO *)rbreadlist(rbList))) {
        if (pxPidFd->lFd >= iMaxFdP1)
          continue;
        iFdBase = pxPidFd->lFd;
        if (MO_FD_ISSET(iFdBase, &hWriteSet)) {
          if (SocketSndRdy(iFdBase) > 0) {
            /* space is available for writing */
            MO_FD_SET(iFdBase, pxFdSetWrite);
            nRet++;
          }
        }
#else
      for (iFdBase = 0; iFdBase < iMaxFdP1; iFdBase += MO_NFDBITS) {
        for (xFdMaskBits = hWriteSet.__fds_bits[iFdBase/MO_NFDBITS], iFd = iFdBase;
             xFdMaskBits && iFd < iMaxFdP1;
             xFdMaskBits >>= 1, iFd++) {
          if (xFdMaskBits & 1) {
            if (SocketSndRdy(iFd) > 0) {
              /* space is available for writing */
              MO_FD_SET(iFd, pxFdSetWrite);
              nRet++;
            }
          }
        }
#endif
      }
#ifndef __SELECT_OPT_ON__
      rbcloselist(rbList);
#endif
    }

    if (nRet) {

      /* Data was available for reading or space was available for writing for
       * at least one of the sockets. Therefore clear the slot */
      pthread_cond_destroy(&gaxSelectInfo[idx].xCond);
      MOC_MEMSET((ubyte *) &(gaxSelectInfo[idx]), 0x00, sizeof(SELECTFDSET));
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return nRet;
    }
    else {
      /* No Rd/Wr mo_fd_set event triggered. Check whether a pxTsTimeOut woke
         this thread */
      if ((pxTsTimeOut != NULL) &&
          (((0 == pxTsTimeOut->tv_sec) && (0 == pxTsTimeOut->tv_nsec))  ||
           (MO_ETIMEDOUT == nRc))) {
        /* return 0 immediately */
        pthread_cond_destroy(&gaxSelectInfo[idx].xCond);
        MOC_MEMSET((ubyte *) &(gaxSelectInfo[idx]), 0x00,sizeof(SELECTFDSET));
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        if ((ipc_req) && (MO_ETIMEDOUT != nRc))
            return (ERR_LIBSOCK_SELECT_TIMEOUT);
        else
            return 0;
      }

      /* Nothing happened. Post the select, and wait on the condition
         variable */
      /* wait for Rd/Wr */
      gaxSelectInfo[idx].oInUse = (OCTET) TRUE;
      if (pxTsTimeOut) {
        gaxSelectInfo[idx].tsAbsTimeOut.tv_sec = tsTimeOut.tv_sec;
        gaxSelectInfo[idx].tsAbsTimeOut.tv_nsec = tsTimeOut.tv_nsec;
      }

      /* Post/Set the appropriate bit in the selectfdset structure */
      gaxSelectInfo[idx].xRdFdSet = hReadSet;
      gaxSelectInfo[idx].xWrFdSet = hWriteSet;
      /* Flags the socket waiting on Read or Write */
#ifndef __SELECT_OPT_ON__
      _SocketSetSelectFlag(&hReadSet, &hWriteSet, TRUE, xPid.lPid);
#else
      _SocketSetSelectFlag(&hReadSet, &hWriteSet, TRUE);
#endif

      /* Go to sleep */
      if (ipc_req)
      {
          /* We need to put this in the link list of the Sock  and Return*/
          if (pxFdSetWrite)
              gaxSelectInfo[idx].bitMask |= MN_WRITESET_MASK;
          if (pxFdSetRead)
              gaxSelectInfo[idx].bitMask |= MN_READSET_MASK;
          gaxSelectInfo[idx].iMaxFd = iMaxFdP1;

          gaxSelectInfo[idx].ipc_req = ipc_req;

          pthread_cond_destroy(&gaxSelectInfo[idx].xCond);
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
          return 0;
      }

      if (pxTsTimeOut)
      {
        nRc = pthread_cond_timedwait(&gaxSelectInfo[idx].xCond,
                                     &(xNetWrapper.xMutex),
                                     &(gaxSelectInfo[idx].tsAbsTimeOut));
        ASSERT((nRc == 0) || (nRc == MO_ETIMEDOUT));

        if (nRc == 0)
        {
            if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
            {
                DEBUG_PRINTNL(DEBUG_MOC_IPV4,
                    "select has been awaken by condition\n");
            }
        }
      }
      else {
        if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
        {
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,"mn_pselect: waiting for signal\n");
        }
#if 1
        nRc = pthread_cond_wait(&gaxSelectInfo[idx].xCond,
                                &(xNetWrapper.xMutex));
#else
    pthread_mutex_t tmpm = PTHREAD_MUTEX_INITIALIZER;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        nRc = pthread_cond_wait(&gaxSelectInfo[idx].xCond, &tmpm);
        if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETATIVE))
        {
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,"mn_pselect: got signal, locking\n");
        }
        RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
        if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETATIVE))
        {
            DEBUG_PRINTNL(REPETITIVE,"mn_pselect: got signal, locked\n");
        }

#endif
        ASSERT(nRc == 0);
      }

      /* Aha, either data is ready to be read, or space is avail to be
       * written on a socket, or the pxTsTimeOut has occured
       * Find which socket(s) and return
       * Also unflag oSelect */
#ifndef __SELECT_OPT_ON__
      _SocketSetSelectFlag(&hReadSet, &hWriteSet, FALSE, xPid.lPid);
#else
      _SocketSetSelectFlag(&hReadSet, &hWriteSet, FALSE);
#endif
    }
  }

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return -1;
}

/*
 * select
 *  Wait for any socket in the read/write sets to be availble for read
 *  or write respectively. Wait is limited by specified pxTsTimeOut
 *
 *  Args:
 *   iMaxFdP1                     Highest numbered socket to be tested + 1.
 *   pxFdSetRead                     read set
 *   pxFdSetWrite                    write set
 *   pxFdSetExcept                   exception set (unused)
 *   pxTvTimeOut                     pxTvTimeOut as timeval
 *
 *  Return:
 *   return value indicates number of ready sockets or TIMEOUT
 *   read/write sets are modified to indicate which sockets are
 *   ready for requested operation
 */
int mn_select(int iMaxFdP1, mo_fd_set *pxFdSetRead, mo_fd_set *pxFdSetWrite,
           mo_fd_set *pxFdSetExcept,  struct timeval *pxTvTimeOut)
{

    return(mn_select_func(iMaxFdP1, pxFdSetRead, pxFdSetWrite,
           pxFdSetExcept,  pxTvTimeOut, NULL));
}

extern int
    mn_select_func(int iMaxFdP1, mo_fd_set *pxFdSetRead, mo_fd_set *pxFdSetWrite,
           mo_fd_set *pxFdSetExcept,  struct timeval *pxTvTimeOut, ubyte * ipc_req)
{
  struct timespec ts;

  if (pxTvTimeOut) {
    ts.tv_sec  = pxTvTimeOut->tv_sec;
    ts.tv_nsec = pxTvTimeOut->tv_usec * 1000;
  }

  return (mn_pselect(iMaxFdP1, pxFdSetRead, pxFdSetWrite, pxFdSetExcept,
                  pxTvTimeOut ? &ts : NULL, ipc_req));
}


int
checkSelectFds( mo_fd_set *pxFdSetRead, mo_fd_set *pxFdSetWrite,
                mo_fd_set hReadSet, mo_fd_set hWriteSet,int iMaxFdP1)
{
  int nRet = 0, iFd, iFdBase, idx = -1;
  mo_fd_mask xFdMaskBits;

    if (pxFdSetRead) {
      for (iFdBase = 0; iFdBase < iMaxFdP1; iFdBase += MO_NFDBITS) {
        for (xFdMaskBits = hReadSet.__fds_bits[iFdBase/MO_NFDBITS], iFd = iFdBase;
             xFdMaskBits && iFd < iMaxFdP1;
             xFdMaskBits >>= 1, iFd++) {
          if (xFdMaskBits & 1) {
            if (SocketRcvRdy(iFd) > 0) {
              /* data is available for reading */
              MO_FD_SET(iFd, pxFdSetRead);
              nRet++;
            }
          }
        }
      }
    }

    if (pxFdSetWrite) {
      for (iFdBase = 0; iFdBase < iMaxFdP1; iFdBase += MO_NFDBITS) {
        for (xFdMaskBits = hWriteSet.__fds_bits[iFdBase/MO_NFDBITS], iFd = iFdBase;
             xFdMaskBits && iFd < iMaxFdP1;
             xFdMaskBits >>= 1, iFd++) {
          if (xFdMaskBits & 1) {
            if (SocketSndRdy(iFd) > 0) {
              /* space is available for writing */
              MO_FD_SET(iFd, pxFdSetWrite);
              nRet++;
            }
          }
        }
      }
    }
    return nRet;
}




