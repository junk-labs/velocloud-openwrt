/*
 * netconfig.c
 *
 * Implements automatic configuration of stack modules
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netconfig.h"
#include "netdbg.h"

/****************************************************************************
 *
 * define
 *
 ****************************************************************************/

#define NETCONFLIBNUMMAX 20

/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/

LONG LinkConfAllocLib(NETCONF *pxNetConf);
LONG LinkConfFreeLib(NETCONF *pxNetConf);

/*****************************************************************************
 *
 * API function
 *
 *****************************************************************************/

/*
 * NetConfSetup
 *  Set up all libraries in the NETCONF argument, and open them
 *  If a problem occurs, it will close/terminate all libraries
 *  and return -1.
 *  NetConfOpen will proceed as follow (if no error occurs)
 *   1. For all active libraries:
 *    1.1 Initialize
 *    1.2 For all instances of the library
 *     1.2.1 Create the instance
 *     1.2.2 Instance settings
 *     1.2.3 For all UL interfaces of the instance
 *      1.2.3.1 Create the interface
 *      1.2.3.2 Scalar ioctls on the interface
 *     1.2.4 For all LL interfaces on the instance
 *      1.2.4.1 Create the interface
 *      1.2.4.2 Scalar ioctls on the interface
 *   2. For all active libraries
 *    2.1 For all instances in the library
 *     2.1.2 For all UL interfaces in the instance
 *      2.1.2.1 Non-scalar ioctls (so called "plumbing")
 *     2.1.3 For all LL interfaces in the instance
 *      2.1.3.1 Non-scalar ioctls (so called "plumbing")
 *   3. For all active libraries
 *    3.1 For all instances in the library
 *     3.1.1 Send Msgs to the instances.
 *     3.1.2 Open the instance
 *     3.1.3 For all UL interfaces in the instance
 *      3.1.3.1 Open the interface
 *     3.1.4 For all LL interfaces in the instance
 *      3.1.4.1 Open the interface
 *   4. Return 0
 *
 *   Note:
 *   -If the pfnInitialize is not set, the code will assume that the
 *   library has been initialized
 *   -If the pfnInstanceCreate is not set, the code will just proceed
 *   as if the instance had been created before-hand.
 *   -If the pfnInstanceULInterfaceCreate or pfnInstanceLLInterfaceCreate
 *   have not been set for the library, the interfaces will be assumed
 *   to exist
 *
 *  Args:
 *   pxNetConf             NetConf
 *
 *  Return:
 *   >=0 for success
 */
LONG NetConfSetup(NETCONF *pxNetConf)
{
  NETCONFINSTANCE *pxNetConfInstance = NULL;
  NETCONFLIBRARYTEMPLATE **ppxLibTemplate = NULL;
  DWORD dw;

  NETDBG_ASSERT((pxNetConf != NULL) &&
                (pxNetConf->ppxLibTemplate != NULL));

  /* Early return if we are not in the right state */
  if (pxNetConf->eState != NETCONFSTATE_INIT) {
    return -1;
  }

  LinkConfAllocLib(pxNetConf);

  ppxLibTemplate    = pxNetConf->ppxLibTemplate;
  pxNetConfInstance = pxNetConf->pxNetConfInstance;

  for (dw = 0; dw < pxNetConf->dwLibNum; dw ++) {
    const NETCONFLIBRARYTEMPLATE  *pxLibTemplate  = ppxLibTemplate[dw];
    NETCONFINSTANCE         *pxInst         = &pxNetConfInstance[dw];
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;

    NETDBG_ASSERT((pxLibTemplate != NULL) && (pxInst != NULL));

    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;
    NETDBG_ASSERT(pxInstTemplate != NULL);

    {
      PFN_NETINITIALIZE              pfnInitialize                = pxLibTemplate->pfnInitialize;
      PFN_NETINSTANCECREATE          pfnInstanceCreate            = pxLibTemplate->pfnInstanceCreate;
      PFN_NETSETOPT                  pfnInstanceSet               = pxLibTemplate->pfnInstanceSet;
      PFN_NETCBK                     pfnNetAdminCbk               = pxLibTemplate->pfnNetAdminCbk;
      PFN_NETINSTANCEINTERFACECREATE pfnInstanceULInterfaceCreate = pxLibTemplate->pfnInstanceULInterfaceCreate;
      PFN_NETINSTANCEINTERFACECREATE pfnInstanceLLInterfaceCreate = pxLibTemplate->pfnInstanceLLInterfaceCreate;
      PFN_NETIOCTL                   pfnInstanceULInterfaceIoctl  = pxLibTemplate->pfnInstanceULInterfaceIoctl;
      PFN_NETIOCTL                   pfnInstanceLLInterfaceIoctl  = pxLibTemplate->pfnInstanceLLInterfaceIoctl;
      OCTET o;

      /* Initializes */
      if (pfnInitialize != NULL) {
        LONG lRv;
        lRv = pfnInitialize();
        ASSERT(lRv == 0);
      }

      /* Creates and configure instances */
      NETDBG_ASSERT(pfnInstanceCreate != NULL);
      pxInst->hInst = pfnInstanceCreate();
      ASSERT(pxInst->hInst != 0);

      if (pfnInstanceSet != NULL ) {

        (LONG)pfnInstanceSet(pxInst->hInst,
                             NETOPTION_NETCBK,(H_NETDATA)pfnNetAdminCbk);

        NETDBG_ASSERT((pxInstTemplate->oSettingNum == 0) ||
                      (pxInstTemplate->pxSetting != NULL));

        for (o=0;o<pxInstTemplate->oSettingNum;o++) {
          if (pxInstTemplate->pxSetting[o].oCode == 0xFF) {
            /* invalid setting */
            continue;
          }
          /* Valid setting */
          (LONG)pfnInstanceSet(pxInst->hInst,
                               pxInstTemplate->pxSetting[o].oCode,
                               pxInstTemplate->pxSetting[o].hData);

        }
      }

      /* Creates UL interfaces */
      for (o=0;o < pxInstTemplate->oULNum; o ++) {
        OCTET o1;
        const NETCONFIFTEMPLATE *pxIfTemplate = pxInstTemplate->pxULIf + o;

        NETDBG_ASSERT((pxInstTemplate->pxULIf != NULL) &&
                      (pfnInstanceULInterfaceCreate != NULL));

        pxInst->phULIf[o] = pfnInstanceULInterfaceCreate(pxInst->hInst);

        NETDBG_ASSERT((pxIfTemplate->oIoctlNum == 0) ||
                      ((pfnInstanceULInterfaceIoctl != NULL) &&
                       (pxIfTemplate->pxScalarIoctl != NULL)));
        /* Scalar config */
        for (o1 = 0; o1 < pxIfTemplate->oIoctlNum; o1 ++) {
          if (pxIfTemplate->pxScalarIoctl[o1].oCode == 0xFF) {
            /* invalid ioctl */
            continue;
          }

          /* valid ioctl */
          pfnInstanceULInterfaceIoctl(pxInst->hInst,
                                      pxInst->phULIf[o],
                                      pxIfTemplate->pxScalarIoctl[o1].oCode,
                                      pxIfTemplate->pxScalarIoctl[o1].hData);
        }
      }

      NETDBG_ASSERT((pxInstTemplate->oLLNum == 0) ||
                    ((pxInstTemplate->pxLLIf != NULL) &&
                     (pfnInstanceLLInterfaceCreate != NULL) &&
                     (pfnInstanceLLInterfaceIoctl != NULL)));
      /* Creates LL interfaces */
      for (o=0;o < pxInstTemplate->oLLNum; o ++) {
        OCTET o1;
        const NETCONFIFTEMPLATE *pxIfTemplate = pxInstTemplate->pxLLIf + o;

        pxInst->phLLIf[o] = pfnInstanceLLInterfaceCreate(pxInst->hInst);

        /* Scalar config */
        NETDBG_ASSERT((pxIfTemplate->oIoctlNum == 0) ||
                      (pxIfTemplate->pxScalarIoctl != NULL));

        for (o1 = 0; o1 < pxIfTemplate->oIoctlNum; o1 ++) {
          if (pxIfTemplate->pxScalarIoctl[o1].oCode == 0xFF) {
            /* invalid ioctl */
            continue;
          }
          /* valid ioctl */
          pfnInstanceLLInterfaceIoctl(pxInst->hInst,
                                      pxInst->phLLIf[o],
                                      pxIfTemplate->pxScalarIoctl[o1].oCode,
                                      pxIfTemplate->pxScalarIoctl[o1].hData);
        }
      }
    }
  }

  /* At this point, NetConf is ready for plumbing */
  for (dw = 0; dw < pxNetConf->dwLibNum; dw ++) {
    const NETCONFLIBRARYTEMPLATE  *pxLibTemplate  = ppxLibTemplate[dw];
    NETCONFINSTANCE         *pxInst         = &pxNetConfInstance[dw];
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;
    OCTET o;

    NETDBG_ASSERT((pxLibTemplate != NULL) && (pxInst != NULL));

    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;
    NETDBG_ASSERT(pxInstTemplate != NULL);

    {
      PFN_NETIOCTL pfnInstanceULInterfaceIoctl = pxLibTemplate->pfnInstanceULInterfaceIoctl;
      PFN_NETIOCTL pfnInstanceLLInterfaceIoctl = pxLibTemplate->pfnInstanceLLInterfaceIoctl;

      /* UL interface plumbing */
      for (o=0;o < pxInstTemplate->oULNum; o ++) {
        const NETCONFIFTEMPLATE *pxIfTemplate = pxInstTemplate->pxULIf + o;

        if (pxIfTemplate->u.xUL.oValid == TRUE) {
          OCTET oLibIdx = pxIfTemplate->u.xUL.oLibIdx;
          OCTET oIfIdx = pxIfTemplate->u.xUL.oIfIdx;

          NETDBG_ASSERT((oLibIdx < pxNetConf->dwLibNum) &&
                        (oIfIdx < ppxLibTemplate[oLibIdx]->pxInstanceTemplate->oLLNum));

          pfnInstanceULInterfaceIoctl(pxInst->hInst,
                                      pxInst->phULIf[o],
                                      NETINTERFACEIOCTL_SETHINST,
                                      (H_NETDATA)pxNetConfInstance[oLibIdx].hInst);
          pfnInstanceULInterfaceIoctl(pxInst->hInst,
                                      pxInst->phULIf[o],
                                      NETINTERFACEIOCTL_SETIF,
                                      (H_NETDATA)pxNetConfInstance[oLibIdx].phLLIf[oIfIdx]);
          pfnInstanceULInterfaceIoctl(pxInst->hInst,
                                      pxInst->phULIf[o],
                                      NETINTERFACEIOCTL_SETOUTPUTPFN,
                                      (H_NETDATA)ppxLibTemplate[oLibIdx]->pfnInstanceRcv);

        }
      }

      /* LL interface plumbing */
      for (o=0;o < pxInstTemplate->oLLNum; o ++) {
        const NETCONFIFTEMPLATE *pxIfTemplate = pxInstTemplate->pxLLIf + o;

        if (pxIfTemplate->u.xLL.oValid == TRUE) {
          OCTET oLibIdx = pxIfTemplate->u.xLL.oLibIdx;
          OCTET oIfIdx = pxIfTemplate->u.xLL.oIfIdx;

          NETDBG_ASSERT((oLibIdx < pxNetConf->dwLibNum) &&
                        (oIfIdx < ppxLibTemplate[oLibIdx]->pxInstanceTemplate->oULNum));

          pfnInstanceLLInterfaceIoctl(pxInst->hInst,
                                      pxInst->phLLIf[o],
                                      NETINTERFACEIOCTL_SETHINST,
                                      (H_NETDATA)pxNetConf->pxNetConfInstance[oLibIdx].hInst);

          pfnInstanceLLInterfaceIoctl(pxInst->hInst,
                                      pxInst->phLLIf[o],
                                      NETINTERFACEIOCTL_SETIF,
                                      (H_NETDATA)pxNetConf->pxNetConfInstance[oLibIdx].phULIf[oIfIdx]);
          pfnInstanceLLInterfaceIoctl(pxInst->hInst,
                                      pxInst->phLLIf[o],
                                      NETINTERFACEIOCTL_SETOUTPUTPFN,
                                      (H_NETDATA)pxNetConf->ppxLibTemplate[oLibIdx]->pfnInstanceWrite);

        }
      }
    }
  }


  /* Send msgs to the instances, open instances and ifs */
  for (dw = 0; dw < pxNetConf->dwLibNum; dw ++) {
    const NETCONFLIBRARYTEMPLATE  *pxLibTemplate  = ppxLibTemplate[dw];
    NETCONFINSTANCE         *pxInst         = &pxNetConfInstance[dw];
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;
    PFN_NETMSG pfnInstanceMsg;
    OCTET o;

    NETDBG_ASSERT((pxLibTemplate != NULL) && (pxInst != NULL));

    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;
    NETDBG_ASSERT(pxInstTemplate != NULL);

    pfnInstanceMsg  = pxLibTemplate->pfnInstanceMsg;

    NETDBG_ASSERT((pxInstTemplate->oMsgNum == 0) |
                  ((pxLibTemplate->pfnInstanceMsg != NULL) &&
                  (pxInstTemplate->pxMsg != NULL)));

    for (o=0; o < pxInstTemplate->oMsgNum ; o ++) {
      if (pxInstTemplate->pxMsg[o].oCode == 0xFF) {
        /* invalid message */
        continue;
      }

      (LONG)pfnInstanceMsg(pxInst->hInst,
                           pxInstTemplate->pxMsg[o].oCode,
                           pxInstTemplate->pxMsg[o].hData);

    }
  }

  pxNetConf->eState = NETCONFSTATE_SETUP;

  return 0;
}

/*
 * NetConfOpen
 *  Open all registered instances and interfaces
 *
 *  Args:
 *   pxNetConf            NetConf
 *
 *  Return:
 *   >=0 for success
 */
LONG NetConfOpen(NETCONF *pxNetConf)
{
  NETCONFINSTANCE *pxNetConfInstance = NULL;
  NETCONFLIBRARYTEMPLATE **ppxLibTemplate = NULL;
  DWORD dw;

  NETDBG_ASSERT((pxNetConf != NULL) &&
                (pxNetConf->ppxLibTemplate != NULL) &&
                (pxNetConf->eState == NETCONFSTATE_SETUP));

  /* Early return if not in the right state */
  if (pxNetConf->eState != NETCONFSTATE_SETUP) {
    return -1;
  }

  ppxLibTemplate    = pxNetConf->ppxLibTemplate;
  pxNetConfInstance = pxNetConf->pxNetConfInstance;

  /* Open all instances and all interfaces */
  for (dw = 0; dw < pxNetConf->dwLibNum; dw ++) {
    const NETCONFLIBRARYTEMPLATE  *pxLibTemplate  = ppxLibTemplate[dw];
    NETCONFINSTANCE         *pxInst         = &pxNetConfInstance[dw];
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;
    OCTET o;

    NETDBG_ASSERT((pxLibTemplate != NULL) && (pxInst != NULL));

    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;
    NETDBG_ASSERT(pxInstTemplate != NULL);
    {
      PFN_NETIOCTL pfnInstanceULInterfaceIoctl  = pxLibTemplate->pfnInstanceULInterfaceIoctl;
      PFN_NETIOCTL pfnInstanceLLInterfaceIoctl  = pxLibTemplate->pfnInstanceLLInterfaceIoctl;
      PFN_NETMSG   pfnInstanceMsg               = pxLibTemplate->pfnInstanceMsg;

      NETDBG_ASSERT(pfnInstanceMsg != NULL);
      pfnInstanceMsg(pxInst->hInst,NETMSG_OPEN,0);

      /* Open UL interfaces */
      NETDBG_ASSERT((pxInstTemplate->oULNum == 0) ||
                    ((pxInst->phULIf != NULL) &&
                     (pxLibTemplate->pfnInstanceULInterfaceIoctl != NULL)));

      for (o=0;o < pxInstTemplate->oULNum; o ++) {
        pfnInstanceULInterfaceIoctl(pxInst->hInst,pxInst->phULIf[o],NETINTERFACEIOCTL_OPEN,0);
      }

      /* Open LL interfaces */
      NETDBG_ASSERT((pxInstTemplate->oLLNum == 0) ||
                    ((pxInst->phLLIf != NULL) &&
                     (pxLibTemplate->pfnInstanceLLInterfaceIoctl != NULL)));

      for (o=0;o < pxInstTemplate->oLLNum; o ++) {
        pfnInstanceLLInterfaceIoctl(pxInst->hInst,pxInst->phLLIf[o],NETINTERFACEIOCTL_OPEN,0);
      }
    }
    /* Initialize the next call time to current time for first iteration */
    pxInst->dwNextCallTime = NetGetMsecTime();
  }

  pxNetConf->eState = NETCONFSTATE_OPENED;

  return 0;
}

/*
 * NetConfClose
 *  Close all interfaces and all instances
 *
 *  Args:
 *   pxNetConf           NetConf
 *
 *  Return:
 *   >=0 for success
 */
LONG NetConfClose(NETCONF *pxNetConf)
{
  NETCONFINSTANCE *pxNetConfInstance = NULL;
  NETCONFLIBRARYTEMPLATE **ppxLibTemplate = NULL;
  DWORD dw;

  NETDBG_ASSERT((pxNetConf != NULL)&&
                (pxNetConf->ppxLibTemplate != NULL));

  if (pxNetConf->eState != NETCONFSTATE_OPENED){
    return -1;
  }

  ppxLibTemplate    = pxNetConf->ppxLibTemplate;
  pxNetConfInstance = pxNetConf->pxNetConfInstance;

  for (dw = 0; dw < pxNetConf->dwLibNum; dw ++) {
    const NETCONFLIBRARYTEMPLATE  *pxLibTemplate  = ppxLibTemplate[dw];
    NETCONFINSTANCE         *pxInst         = &pxNetConfInstance[dw];
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;
    OCTET o;

    NETDBG_ASSERT((pxLibTemplate != NULL) && (pxInst != NULL));

    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;
    NETDBG_ASSERT(pxInstTemplate != NULL);
    {
      PFN_NETIOCTL pfnInstanceULInterfaceIoctl  = pxLibTemplate->pfnInstanceULInterfaceIoctl;
      PFN_NETIOCTL pfnInstanceLLInterfaceIoctl  = pxLibTemplate->pfnInstanceLLInterfaceIoctl;
      PFN_NETMSG   pfnInstanceMsg               = pxLibTemplate->pfnInstanceMsg;

      NETDBG_ASSERT(pfnInstanceMsg != NULL);
      pfnInstanceMsg(pxInst->hInst,NETMSG_CLOSE,0);

      /* Open UL interfaces */
      NETDBG_ASSERT((pxInstTemplate->oULNum == 0) ||
                    ((pxInst->phULIf != NULL) &&
                     (pxLibTemplate->pfnInstanceULInterfaceIoctl != NULL)));

      for (o=0;o < pxInstTemplate->oULNum; o ++) {
        pfnInstanceULInterfaceIoctl(pxInst->hInst,pxInst->phULIf[o],NETINTERFACEIOCTL_CLOSE,0);
      }

      /* Open LL interfaces */
      NETDBG_ASSERT((pxInstTemplate->oLLNum == 0) ||
                    ((pxInst->phLLIf != NULL) &&
                     (pxLibTemplate->pfnInstanceLLInterfaceIoctl != NULL)));

      for (o=0;o < pxInstTemplate->oLLNum; o ++) {
        pfnInstanceLLInterfaceIoctl(pxInst->hInst,pxInst->phLLIf[o],NETINTERFACEIOCTL_CLOSE,0);
      }
      if(pxLibTemplate->pfnInstanceProcess != NULL){
        pxLibTemplate->pfnInstanceProcess(pxInst->hInst);
      }
    }
  }



  pxNetConf->eState = NETCONFSTATE_CLOSED;
  return 0;
}
/*
 * NetConfTearDown
 *  Tears down the provided netconf: closes, destroy and terminates
 *  All registered items. It will only terminate the library if
 *  the pfnTerminate function is set.
 *
 *  Args:
 *   pxNetConf             NetConf
 *
 *  Return:
 *   >=0 for success
 */
LONG NetConfTearDown(NETCONF *pxNetConf)
{
  NETCONFINSTANCE *pxNetConfInstance = NULL;
  NETCONFLIBRARYTEMPLATE **ppxLibTemplate = NULL;
  DWORD dw;

  NETDBG_ASSERT((pxNetConf != NULL)&&
                (pxNetConf->ppxLibTemplate != NULL));

  if(pxNetConf->eState == NETCONFSTATE_INIT) {
    return -1;
  }

  ppxLibTemplate    = pxNetConf->ppxLibTemplate;
  pxNetConfInstance = pxNetConf->pxNetConfInstance;

  if (pxNetConf->eState == NETCONFSTATE_OPENED) {
    NetConfClose(pxNetConf);
  }

  NETDBG_ASSERT(pxNetConf->eState == NETCONFSTATE_CLOSED);

  for (dw = 0; dw < pxNetConf->dwLibNum; dw ++) {
    const NETCONFLIBRARYTEMPLATE  *pxLibTemplate  = ppxLibTemplate[dw];
    NETCONFINSTANCE         *pxInst         = &pxNetConfInstance[dw];
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;
    OCTET o;

    NETDBG_ASSERT((pxLibTemplate != NULL) && (pxInst != NULL));

    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;
    NETDBG_ASSERT(pxInstTemplate != NULL);
      /* destroy all interfaces */
    NETDBG_ASSERT((pxInstTemplate->oULNum == 0) ||
                  ((pxLibTemplate->pfnInstanceULInterfaceDestroy != NULL) &&
                   (pxInst->phULIf != NULL)));
    for (o=0;o < pxInstTemplate->oULNum; o ++) {
      pxLibTemplate->pfnInstanceULInterfaceDestroy(pxInst->hInst,pxInst->phULIf[o]);
    }

    NETDBG_ASSERT((pxInstTemplate->oLLNum == 0) ||
                  ((pxLibTemplate->pfnInstanceLLInterfaceDestroy!= NULL) &&
                   (pxInst->phLLIf != NULL)));
    for (o=0;o < pxInstTemplate->oLLNum; o ++) {
      pxLibTemplate->pfnInstanceLLInterfaceDestroy(pxInst->hInst,pxInst->phLLIf[o]);
    }

    /* destroy the instance */
    NETDBG_ASSERT(pxLibTemplate->pfnInstanceDestroy != NULL);
    pxLibTemplate->pfnInstanceDestroy(pxInst->hInst);

    /* Terminate the library */
    if (pxLibTemplate->pfnTerminate != NULL) {
      pxLibTemplate->pfnTerminate();
    }
  }

  pxNetConf->eState = NETCONFSTATE_INIT;

  LinkConfFreeLib(pxNetConf);
  return 0;
}

/* LinkConfFreeLib
 *  Frees the pxLib member of a NETCONF structure
 *
 *  Args:
 *   pxNetConf                 NETCONF pointer
 *
 *  Return:
 *   0
 */
LONG LinkConfFreeLib(NETCONF *pxNetConf)
{
  NETCONFINSTANCE *pxNetConfInstance;
  NETCONFLIBRARYTEMPLATE **ppxLibTemplate = NULL;
  NETCONFLIBRARYTEMPLATE *pxLibTemplate = NULL;
  DWORD dw;

  NETDBG_ASSERT((pxNetConf != NULL)&&
                 (pxNetConf->eState == NETCONFSTATE_INIT) &&
                 (pxNetConf->ppxLibTemplate != NULL) &&
                 (pxNetConf->dwLibNum < NETCONFLIBNUMMAX));

  ppxLibTemplate    = pxNetConf->ppxLibTemplate;
  pxNetConfInstance = pxNetConf->pxNetConfInstance;

  for (dw = 0; dw < pxNetConf->dwLibNum; dw++) {
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;
    NETCONFINSTANCE *pxInst = &pxNetConfInstance[dw];

    pxLibTemplate = ppxLibTemplate[dw];
    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;

    NETDBG_ASSERT(pxInst != NULL);

    NETDBG_ASSERT((pxInstTemplate->oULNum == 0) ||
                   (pxInst->phULIf != NULL));

    if (pxInstTemplate->oULNum > 0) {
      FREE(pxInst->phULIf);
      pxInst->phULIf = NULL;
    }

    NETDBG_ASSERT((pxInstTemplate->oLLNum == 0) ||
                   (pxInst->phLLIf != NULL));

    if (pxInstTemplate->oLLNum > 0) {
      FREE(pxInst->phLLIf);
      pxInst->phLLIf = NULL;
      }

  }
  FREE(pxNetConfInstance);
  pxNetConfInstance = NULL;

  return 0;
}

/*
 * LinkConfAllocLib
 *  Allocs the pxLib member of a NETCONF structure
 *
 *  Args:
 *   pxNetConf                 NETCONF pointer
 *
 *  Return:
 *   0
 */


LONG LinkConfAllocLib(NETCONF *pxNetConf)
{
  NETCONFINSTANCE *pxNetConfInstance;
  NETCONFLIBRARYTEMPLATE **ppxLibTemplate = NULL;
  const NETCONFLIBRARYTEMPLATE *pxLibTemplate;
  DWORD dw;

  NETDBG_ASSERT((pxNetConf != NULL) &&
                 (pxNetConf->eState == NETCONFSTATE_INIT) &&
                 (pxNetConf->dwLibNum < NETCONFLIBNUMMAX));

  pxNetConfInstance = (NETCONFINSTANCE*)MALLOC(pxNetConf->dwLibNum * sizeof(NETCONFINSTANCE));
  NETDBG_ASSERT(pxNetConfInstance != NULL);
  MOC_MEMSET((ubyte*)pxNetConfInstance,0,
        pxNetConf->dwLibNum*sizeof(NETCONFINSTANCE));
  pxNetConf->pxNetConfInstance = pxNetConfInstance;

  ppxLibTemplate = pxNetConf->ppxLibTemplate;

  for (dw = 0;dw < pxNetConf->dwLibNum; dw++) {
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;
    NETCONFINSTANCE *pxInst = &pxNetConfInstance[dw];

    pxLibTemplate = ppxLibTemplate[dw];
    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;

    if (pxInstTemplate->oULNum > 0) {
      pxInst->phULIf = (H_NETINSTANCE *) MALLOC(pxInstTemplate->oULNum*
                                                sizeof(H_NETINSTANCE));
      ASSERT(pxInst->phULIf != NULL);
      MOC_MEMSET((ubyte *)(pxInst->phULIf), 0,
            pxInstTemplate->oULNum* sizeof(H_NETINSTANCE));
    }

    if (pxInstTemplate->oLLNum > 0) {
      pxInst->phLLIf = (H_NETINSTANCE *) MALLOC(pxInstTemplate->oLLNum*
                                                sizeof(H_NETINSTANCE));
      ASSERT(pxInst->phLLIf != NULL);
      MOC_MEMSET((ubyte *)(pxInst->phLLIf), 0,
                  pxInstTemplate->oLLNum * sizeof(H_NETINSTANCE));
    }
  }
  return 0;
}
