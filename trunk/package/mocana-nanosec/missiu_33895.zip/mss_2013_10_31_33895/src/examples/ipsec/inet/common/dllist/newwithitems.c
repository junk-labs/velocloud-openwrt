#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

DLLIST *new_DLLIST_WithItems_fl(ubyte4 n, ubyte4 sz, char *pFile, int nLine)
{
  DLLIST *tmp;
  int i;

  /* new dll */
  tmp = new_DLLIST_fl(pFile, nLine);
  if (tmp == NULL)
    return tmp;

  /* append all n */
  for (i=0; i<n; i++) {
    void *item;
    item = malloc_fl(sz, pFile, nLine);
    ASSERT(item);
    DLLIST_append_fl(tmp, item, pFile, nLine);
  }

  /* remove all n */
  DLLIST_head(tmp);
  for (i=0; i<n; i++)
    DLLIST_remove(tmp);

  return tmp;
}

