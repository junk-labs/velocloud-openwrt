 /*
 * Copyright Mocana Corp 2003-2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/


#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <linux/if_ether.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/ethernet.h>
#include <linux/sockios.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include "string.h"
#include <linux/if.h>
#include "sys/socket.h" /* NNOS ntohx, htonx defs */
#include <netinet/in.h> /* Linux ntohx, htonx defs */
#include "ethdrive_pvt.h"

/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Constants
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/


/*****************************************************************************
 *
 * Local Functions
 *
 *****************************************************************************/

int _EthDrvFns_fd2idx(int lSockfd)
{
    int i;
    for(i=0; i < ETHDRV_MAXNUM_IF; i++){
        if (lSockfd == ethDrvCB[i].iFd)
             return ethDrvCB[i].index;
    }
    return -1;
}

int _EthDrvFns_allocidx()
{
    int i;
    for(i=0; i < ETHDRV_MAXNUM_IF; i++){
        if (ethDrvCB[i].iFd == -1)
             return ethDrvCB[i].index;
    }
    return -1;
}

/*------------------------------------------------------------------*/

/*extern int            EthDrv_read(int fd,void * buff ,int len) ; */

int
_EthDrvFns_close(int iFd)
{
    return close(iFd);
}



int
_EthDrvFns_read(int ifd,char * frame, int nbytes )
{
     return (read(ifd,frame,nbytes));
}

/*------------------------------------------------------------------*/

int
_EthDrvFns_select(int ifd, long secs, long usecs)
{
    fd_set fdset;
    struct timeval timeout;
    int i, status;
    int max_sock;


    FD_ZERO(&fdset);
#if (ETHDRV_MAXNUM_IF == 2)
    max_sock = 0;
    if (ethDrvCB[0].iFd == ifd){
        FD_SET(ethDrvCB[0].iFd,&fdset);
        max_sock = ethDrvCB[0].iFd;
    }

    if (ethDrvCB[1].iFd == ifd){
        FD_SET(ethDrvCB[1].iFd,&fdset);
        if (max_sock <= ethDrvCB[1].iFd)
            max_sock = ethDrvCB[1].iFd;
    }
#else
    max_sock = 0;
    for(i=0; i < ETHDRV_MAXNUM_IF; i++){
        if (ethDrvCB[i].iFd == ifd){
            FD_SET(ifd, &fdset);
                max_sock = ifd;
        break;
    }
    }
    if ( max_sock == 0 ) return 0;
#endif

    timeout.tv_sec = secs;
    timeout.tv_usec = usecs;
    status = select (max_sock+1,&fdset,NULL,NULL,&timeout);

#if 0
    if (status > 0)
    {
        if (FD_ISSET(ethDrvCB[0].iFd, &fdset))
        {
            /*EthDrv_read(ethDrvCB[0].iFd,NULL,0) ; */
        }
        if (FD_ISSET(ethDrvCB[1].iFd, &fdset))
        {
            /*EthDrv_read(ethDrvCB[1].iFd,NULL,0) ; */
        }
    }
#endif

    return status;
}


/*------------------------------------------------------------------*/



int
_EthDrvFns_write(int lSockfd, void *buff, size_t nbytes)
{
    int status = 0;
    struct sockaddr sa;
    int oIfIdx;

#if (ETHDRV_MAXNUM_IF == 2)
    if (lSockfd == ethDrvCB[0].iFd)
         oIfIdx = ethDrvCB[0].index;
    else if (lSockfd == ethDrvCB[1].iFd)
         oIfIdx = ethDrvCB[1].index;
    else
         return 0 ;
#else
    oIfIdx = _EthDrvFns_fd2idx(lSockfd);
    if ( oIfIdx < 0 ) return 0;
#endif

    /* sendto */
    memset((char *)&sa, 0, sizeof(struct sockaddr));
    sa.sa_family = AF_INET;
    strcpy(sa.sa_data, ethDrvCB[oIfIdx].intfName);

    if ((status = send(lSockfd, buff,nbytes,0)) <0)
    {
        printf("Unable to send data Packet to Network\n");
        perror("send");
        goto exit;
    }

exit:
    return status;
}

/*------------------------------------------------------------------*/

int
_EthDrvFns_open(EthDrvCB * ethDrv)
{

    int status = 0;
    struct ifreq ifr;
    struct sockaddr_ll ll;
    struct sockaddr_in addr;
    int opt = 1,oldflag;

    memset(&ifr,0,sizeof(struct ifreq));
    ethDrv->iFd = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    strncpy(ifr.ifr_name, ethDrv->intfName, strlen(ethDrv->intfName));

    if (ioctl(ethDrv->iFd, SIOCGIFINDEX, &ifr) < 0)
    {
        perror("ioctl[SIOCGIFINDEX]");
        close(ethDrv->iFd);
        ethDrv->iFd = -1;
        return ERR_SOCKET_OPEN;
    }

    memset(&ll, 0, sizeof(ll));
    ll.sll_family = PF_PACKET;
    ll.sll_ifindex = ifr.ifr_ifindex;
    /*ll.sll_protocol = htons(0x0800); */
    ll.sll_protocol = htons(ETH_P_ALL);

    if (bind(ethDrv->iFd, (struct sockaddr *) &ll, sizeof(ll)) < 0)
    {
        perror("bind[PF_PACKET]");
        close(ethDrv->iFd);
        ethDrv->iFd = -1;
        return ERR_SOCKET_BIND;
    }

    if (ioctl(ethDrv->iFd, SIOCGIFHWADDR, &ifr) < 0)
    {
        perror("ioctl[SIOCGIFHWADDR]");
        close(ethDrv->iFd);
        ethDrv->iFd = -1;
        return ERR_SOCKET_IOCTL;
    }

    memcpy(ethDrv->myMacaddr, ifr.ifr_hwaddr.sa_data, ETH_ALEN);
    printf("My MAC Addr is %x.%x.%x.%x.%x.%x\n",
            ethDrv->myMacaddr[0],
            ethDrv->myMacaddr[1],
            ethDrv->myMacaddr[2],
            ethDrv->myMacaddr[3],
            ethDrv->myMacaddr[4],
            ethDrv->myMacaddr[5]);

    ethDrv->iState = ETH_DRV_STATE_OPEN;
exit:
    return status;
}

