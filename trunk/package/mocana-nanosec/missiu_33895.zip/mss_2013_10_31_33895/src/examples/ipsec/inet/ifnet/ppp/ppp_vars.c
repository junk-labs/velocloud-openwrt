/*
 * ppp_vars.c
 *
 * Ppp variables
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "pppdefs.h"

/*
 * Lcp Option Default
 *  Specified in RFC 1661
 */
const H_NETDATA ahLcpOptionDefault[PPPLCPOPTION_ENUMMAX] =
{
  (H_NETDATA)PPPDEFAULT_MRU,
  (H_NETDATA)PPPPROTIDX_NONE,
  (H_NETDATA)PPPPROTIDX_NONE,
  (H_NETDATA)PPPDEFAULT_MN,
  (H_NETDATA)PPPDEFAULT_ACFC,
  (H_NETDATA)PPPDEFAULT_PFC
};

/*
 * Option To Code mapping table
 */
const OCTET aoLcpOptionToCode[PPPLCPOPTION_ENUMMAX] = {
  PPPLCPOPTIONCODE_MRU,
  PPPLCPOPTIONCODE_AP,
  PPPLCPOPTIONCODE_LQP,
  PPPLCPOPTIONCODE_MN,
  PPPLCPOPTIONCODE_ACFC,
  PPPLCPOPTIONCODE_PFC
};

/*
 * Code to Option mapping table
 */
const SHORT aoLcpCodeToOption[PPPLCPOPTIONCODE_MAX + 1] = {
  NETERR_UNKNOWN,
  PPPLCPOPTION_MRU,
  NETERR_UNKNOWN,
  PPPLCPOPTION_AP,
  PPPLCPOPTION_LQP,
  PPPLCPOPTION_MN,
  NETERR_UNKNOWN,
  PPPLCPOPTION_ACFC,
  PPPLCPOPTION_PFC
};

/*
 * Option to  Option Field length
 */
const OCTET aoLcpOptionToLength[PPPLCPOPTION_ENUMMAX] = {
  PPPLCPOPTIONLENGTH_MRU,
  PPPLCPOPTIONLENGTH_AP,
  PPPLCPOPTIONLENGTH_LQP,
  PPPLCPOPTIONLENGTH_MN,
  PPPLCPOPTIONLENGTH_ACFC,
  PPPLCPOPTIONLENGTH_PFC
};


/*
 * Lcp Remote Option Check function table
 */
const PFN_LCPREMOTEOPTIONCHECK
apfnPppInstanceLcpCheckRemoteOption[PPPLCPOPTION_ENUMMAX]= {
  PppInstanceRemoteMruCheck,
  PppInstanceRemoteApCheck,
  PppInstanceRemoteLqpCheck,
  PppInstanceRemoteMnCheck,
  PppInstanceRemoteAcfcCheck,
  PppInstanceRemotePfcCheck
};




const PFN_LCPLOCALOPTIONCHECK
apfnPppInstanceLcpCheckLocalOption [PPPLCPOPTION_ENUMMAX]= {
  PppInstanceLocalMruCheck,
  PppInstanceLocalApCheck,
  PppInstanceLocalLqpCheck,
  PppInstanceLocalMnCheck,
  PppInstanceLocalAcfcCheck,
  PppInstanceLocalPfcCheck
};

#ifdef PPPDBG_HI
const OCTET *apoPppOptionString[] = {
  "LOCALMRU",
  "REMOTEMRU",
  "LOCALAP",
  "REMOTEAP",
  "LOCALLQP",
  "REMOTELQP",
  "LOCALMAGICNUMBER",
  "REMOTEMAGICNUMBER",
  "LOCALACFC",
  "REMOTEACFC",
  "LOCALPFC",
  "REMOTEPFC",
  "TUNNELMODE",
  "IFIDX",
  "VLAN",
  "RETRANSMISSIONTIMER",
  "MAXCONFRETRIES",
  "MAXTERMRETRIES",
  "IDLETO",
};

const OCTET *apoPppMsgString[] = {
 "AUTHSUCCESS",
 "PPPMSG_AUTHFAILURE"
};

const OCTET *apoPppCbkString[] = {
 "IDLETO",
 "TRAFFICDETECTED",
 "AUTHENTICATECONF",
 "AUTHENTICATE"
};

#endif /*PPPDBG_HI*/
