#ifndef __DLLCOMMON_H__
#define __DLLCOMMON_H__

#ifndef malloc_fl
#  define malloc_fl(s, f, l) MALLOC(s)
#endif

#ifndef free_fl
#  define free_fl(p, f, l) FREE(p)
#endif


LONG this_item(void *a, void *b);


#endif

