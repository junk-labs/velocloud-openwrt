/*
 * udpmain.c
 *
 * UDP module main
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "udp_flavor.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "netnetwork.h"
#include "../include/in.h"
#include "../include/socket.h"
#include "netutils.h"
#include "nettransport.h"
#include "ecc.h"
#include "udp.h"
#include "udpdefs.h"
#include "udp_dbg.h"

#ifdef NEW_ICMP_MSG_ADDED
#include "icmp.h"
#endif

UDP_DBG_VAR(DWORD g_dwUdpDebugLevel = 3);
/*UDP_DBG_VAR(DWORD g_dwUdpDebugLevel = ERROR); */

UDPSTATE  **ppxUdpInstanceList = NULL;
OCTET     oUdpInstances = 0;

/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/
void _UdpPrintConnection(UDPSTATE *pxUdp);

/*****************************************************************************
 *
 * Local functions definition
 *
 *****************************************************************************/

static LONG _UdpIdCmp(void *pUdpConn, void *pUdpId);
/*
 * _UdpFindItemByAddress
 *  DLLIST find function using the pointer address
 *  to find a given item in the linklist
 *
 *  Args:
 *   pxItem1                    Item1 pointer
 *   pxItem2                    Item2 pointer
 *
 *  Return:
 *   0 if both pointers are equal, -1 otherwise
 */
static LONG _UdpFindItemByAddress(void *pxItem1,void *pxItem2)
{
  UDP_ASSERT_HI(pxItem1 != NULL && pxItem2 != NULL);

  if (pxItem1 == pxItem2) {
    return 0;
  }
  else {
    return -1;
  }
}

/*
 * _UdpFreeConn
 *  free a connection
 */
static void _UdpFreeConn(void *px)
{
  UDP_ASSERT_HI(px != NULL);

  FREE(px);
}

/*
 * _UdpMReqCmp
 *  Compare two IPMCASTREQ * (casted as void *).
 *  Return 0 if they have identical contents
 *
 *  Args:
 *   pxMReq1                  1st MReq pointer
 *   pxMReq2                  2nd MReq pointer
 *
 *  Return:
 *   0 if contents equal
 */
#if 0
static LONG _UdpMReqCmp(void *pxMReq1, void *pxMReq2)
{
  ubyte4 cmpResult;

  UDP_ASSERT_HI(pxMReq1 != NULL && pxMReq2 != NULL);

  MOC_MEMSET(pxMReq1, pxMReq2, sizeof(IPMCASTREQ), &cmpResult);
  return cmpResult;
}
#endif
/*
 * _UdpLocalIdCmp
 *  See if two UDPCONNs have matching local transport ids
 *
 *  Args:
 *   pxConn1                  casted type UDPCONN* reference point
 *   pxConn2                  casted type UDPCONN* reference point
 *  Return:
 *   0 if contents equal
 */
static LONG _UdpLocalIdCmp(void *pxConn1, void *pxConn2)
{
  TRANSPORT2NETWORKID *pxNetId1,*pxNetId2;
  /* first check if we are on different interfaces,
     or different VLANs on the same interface. If so, we're
     OK even if transport id's match */
  UDP_ASSERT_HI(pxConn1 != NULL && pxConn2 != NULL);

  pxNetId1 = &(((UDPCONN *)pxConn1)->xId.xNetId);
  pxNetId2 = &(((UDPCONN *)pxConn2)->xId.xNetId);

  if ((pxNetId1->oIfIdx != NETIFIDX_ANY) &&
      (pxNetId2->oIfIdx != NETIFIDX_ANY) &&
      (pxNetId1->oIfIdx != pxNetId2->oIfIdx)) {
    /* not the same if */
    return -1;
  }

  if ((pxNetId1->wVlan != NETVLAN_ANY) &&
      (pxNetId2->wVlan != NETVLAN_ANY) &&
      ((pxNetId1->wVlan & NETVLAN_VIDMASK) !=
         (pxNetId2->wVlan & NETVLAN_VIDMASK))) {
    /* not the same VLAN */
    return -1;
  }

  if (
      (
       (pxNetId1->dwSrcIpAddr == pxNetId2->dwSrcIpAddr) ||
       ((UDPCONN *)pxConn1)->bWithInAddrAny ||
       ((UDPCONN *)pxConn2)->bWithInAddrAny
       ) &&
      (((UDPCONN *)pxConn1)->xId.wSrcPort  ==
       ((UDPCONN *)pxConn2)->xId.wSrcPort)
      ) {
    /* IP, port match OR port matches and bWithInAddrAny set */
    return 0;
  }

  return -1;
}

/*
 * _UdpSetLocalPort
 *  Sets a local port in UDPCONN and checks for duplicate port/IP
 *
 *  Args:
 *   pxUdp                    UDP instance structure
 *   pxConn                   UDP connection structure
 *   wPort                    port id
 *   bIsReuseAllowed          Can this port be reused?
 *  Return:
 *   0 port ok
 *  -1 if duplicate found
 */
static LONG _UdpSetLocalPort(UDPSTATE *pxUdp,
                             UDPCONN *pxConn,
                             WORD wPort,
                             BOOL bIsReuseAllowed)
{
  /* put a UDPCONN on the stack for the find operation */
  UDPCONN xConn = *pxConn;

  UDP_ASSERT_HI(pxUdp != NULL && pxConn != NULL);

  if (FALSE == bIsReuseAllowed) {

    xConn.xId.wSrcPort = (wPort);

    /* MUST Check that the port has not been used for the
         same IP address !!! */
    DLLIST_head(&pxUdp->dllConns);
    if (DLLIST_find(&pxUdp->dllConns,(void *)&xConn,
                   _UdpLocalIdCmp) != NULL) {
      /* there is a match*/
      return -1;
    }
  }

  pxConn->xId.wSrcPort = (wPort);

  return 0;
}

/*
 * _UdpFindNewLocalPort
 *  Finds a new local port in UDPCONN and checks for duplicate port/IP
 *
 *  Args:
 *   pxUdp                    UDP instance structure
 *   pxConn                   UDP connection structure
 *   wPort                    port id
 *  Return:
 *   0 port ok
 *  -1 if duplicate found
 */
static LONG _UdpFindNewLocalPort(UDPSTATE *pxUdp, UDPCONN *pxConn)
{
  DWORD dwNport;
  LONG lReturn = -1;

  UDP_ASSERT_HI(pxUdp != NULL && pxConn != NULL);

  for (dwNport = UDP_USRPORT; dwNport <= UDP_MAXPORT; dwNport++) {
    if (_UdpSetLocalPort(pxUdp, pxConn, (WORD) dwNport, FALSE) == 0) {
      lReturn = 0;
      break;
    }
  }
  return lReturn;
}

/*
 * _UdpIdCmp
 *  See if a given UDPCONN has a matching udp id
 *
 *  Args:
 *   pxConn                   casted type UDPCONN* reference point
 *   pxUdpId                  casted type TRANSPORTID* reference point
 *  Return:
 *   0 if contents equal
 */
static LONG _UdpIdCmp(void *pUdpConn, void *pUdpId)
{
  UDPCONN *pxConn = (UDPCONN*)pUdpConn;
  TRANSPORTID *pxTransportId = (TRANSPORTID*)pUdpId;
  TRANSPORT2NETWORKID *pxConnNetId,*pxNetId;

  UDP_ASSERT_HI( (pxConn != NULL) && (pxTransportId != NULL));

  pxConnNetId = &(pxConn->xId.xNetId);
  pxNetId = &(pxTransportId->xNetId);
  UDP_ASSERT_HI(pxConnNetId != NULL && pxNetId != NULL);

  /* first eliminate mismatch of remote IP */
  if ((pxConnNetId->dwDstIpAddr != 0) &&
      (pxConnNetId->dwDstIpAddr != pxNetId->dwSrcIpAddr)) {
    /* remote ip mismatch */
    return -1;
  }

  /* eliminate mismatch of local IP */
  if ((pxConn->bWithInAddrAny == FALSE) &&
      (pxNetId->eDstAddrType != IPADDRT_BROADCAST) &&
      (pxConnNetId->dwSrcIpAddr != pxNetId->dwDstIpAddr)) {

    /* local IP mismatch, check if there is a multicast group
       registered on this socket with the destination address */
    if (!((pxNetId->eDstAddrType == IPADDRT_MULTICAST ||
           pxNetId->eDstAddrType == IPADDRT_MULTICASTJOINED ||
           pxNetId->eDstAddrType == IPADDRT_MULTICASTJOINEDSOCKPROXY) &&
          pxConn->pxIpMcastReq != NULL &&
          pxNetId->dwDstIpAddr == pxConn->pxIpMcastReq->dwMulticastAddr &&
          (pxConn->pxIpMcastReq->oPhyIf == NETIFIDX_ANY ||
           pxConn->pxIpMcastReq->oPhyIf == pxNetId->oIfIdx))) {
      /* no local ip or multicast group ip match */
      return -1;
    }
  }

  /* eliminate mismatch of remote port */
  if ((pxConn->xId.wDstPort != 0) &&
      (pxConn->xId.wDstPort != pxTransportId->wSrcPort)) {
    /* remote ip mismatch */
    return -1;
  }

  /* eliminate mismatch of local port */
  if((pxConn->xId.wSrcPort == 0) ||
     (pxConn->xId.wSrcPort != pxTransportId->wDstPort)){
    /*port mismatch*/
    return -1;
  }

  /* now eliminate mismatched interface */
  if ((pxConnNetId->oIfIdx != NETIFIDX_ANY) &&
      (pxConnNetId->oIfIdx != pxNetId->oIfIdx)) {
    /* interface mismatch */
    return -1;
  }

  /* now eliminate mismatched VLAN */
  if ((pxConnNetId->wVlan != NETVLAN_ANY) &&
      ((pxConnNetId->wVlan & NETVLAN_VIDMASK) !=
       (pxNetId->wVlan & NETVLAN_VIDMASK))) {
    /* VLAN mismatch */
    return -1;
  }

  /* all match ! */
  return 0;
}

#if 0
/*
 * _UdpMcIpCmp
 *  See if a given IPMCASTREQ matches IP in transport id
 *
 *  Args:
 *   pxIpmcr                  casted type IPMCASTREQ* reference point
 *   pxTpId                   casted type TRANSPORT2NETWORKID* reference point
 *  Return:
 *   0 if contents equal
 */
static LONG _UdpMcIpCmp(void *pxIpmcr, void *pxTpId)
{
  UDP_ASSERT_HI(pxIpmcr != NULL && pxTpId != NULL);

  if (((IPMCASTREQ *)pxIpmcr)->dwMulticastAddr
      == ((TRANSPORT2NETWORKID *)pxTpId)->dwDstIpAddr)
    /* same IP address */
    return 0;
  else
    return -1;
}

/*
 * _UdpTpMcCmp
 *  See if a given UDPCONN has a matching transport id, taking the
 *  IP address from the multicast list
 *
 *  Args:
 *   pxConn                   casted type UDPCONN* reference point
 *   pxTpId                   casted type TRANSPORTID* reference point
 *  Return:
 *   0 if contents equal
 */
static LONG _UdpTpMcCmp(void *pConn, void *pTpId)
{

  UDPCONN *pxConn = (UDPCONN *)pConn;                      _UdpTpMcCmp
  TRANSPORTID *pxTpId = (TRANSPORTID *)pTpId;

  UDP_ASSERT_HI(pxConn != NULL && pxTpId != NULL);

  if ((pxConn->xId.wSrcPort == pxTpId->wDstPort) && (pxConn->pxIpMcastReq != NULL)) {
    return 0;
  } else {
    return -1;
  }
}

/*
 * _UdpFindUdpConn
 *  Finds a UDPCONN pointer in UDP instance structure based on port/IP
 *
 *  Args:
 *   pxUdp                    UDP instance structure
 *   pxTpId                   transport ID structure
 *  Return:
 *   pointer to UDP connection structure if found
 *   NULL if not found
 */
static UDPCONN *_UdpFindUdpConn(UDPSTATE *pxUdp, TRANSPORTID *pxTransportId)
{
  UDPCONN *pxConn = NULL;

  UDP_ASSERT_HI(pxUdp != NULL && pxTransportId != NULL && &pxUdp->dllConns != NULL);

  DLLIST_head(&pxUdp->dllConns);

  pxConn = DLLIST_find(&pxUdp->dllConns,(void *)pxTransportId,_UdpIdCmp);

  return pxConn;
}

#endif
/*****************************************************************************
 *
 * API functions implementation
 *
 *****************************************************************************/

/*
 * UdpInitialize
 *  Initialize the Udp Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG UdpInitialize(void)
{
  /* nothing */

  return 0;
}
/*
 * UdpTerminate
 *  Terminate the UDP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG UdpTerminate(void)
{
  /* nothing */
  return 0;
}

/*
 * UdpInstanceCreate
 *  Creates a UDP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE UdpInstanceCreate(void)
{
  UDPSTATE *pxUdp;

  pxUdp = (UDPSTATE *)MALLOC(sizeof(UDPSTATE));
  ASSERT(pxUdp != NULL);
  MOC_MEMSET((ubyte *)pxUdp, 0, sizeof(UDPSTATE));

  UDP_SET_COOKIE(pxUdp);

    {
        UDPSTATE *pxTempUdpInstanceList;

        pxTempUdpInstanceList = (UDPSTATE *)MALLOC((oUdpInstances+1)*sizeof(UDPSTATE *));
        ASSERT(pxTempUdpInstanceList);
        MOC_MEMCPY((ubyte *)pxTempUdpInstanceList,(ubyte *)ppxUdpInstanceList,
            (oUdpInstances*sizeof(UDPSTATE *)));

        ++oUdpInstances;
        ppxUdpInstanceList = (UDPSTATE **)pxTempUdpInstanceList;
    }
  ppxUdpInstanceList[oUdpInstances-1] = pxUdp;

  return (H_NETINSTANCE)pxUdp;
}

/*
 * UdpInstanceDestroy
 *  Destroy a UDP Instance
 *
 *  Args:
 *   hUdp                       UDP instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG UdpInstanceDestroy(H_NETINSTANCE hUdp)
{
  UDPSTATE *pxUdp = (UDPSTATE *)hUdp;
  WORD wCnt;

  UDP_CHECK_STATE(pxUdp);

  clear_DLLIST(&pxUdp->dllConns,_UdpFreeConn);

  UDP_UNSET_COOKIE(pxUdp);
  FREE(pxUdp);

  /* have to take pointer out of snmp list */
  wCnt = 0;
  while (wCnt < oUdpInstances) {
    if (ppxUdpInstanceList[wCnt] == pxUdp) break;
    wCnt++;
  }
  ASSERT(wCnt < oUdpInstances);

  oUdpInstances--;
  while (wCnt < oUdpInstances) {
    ppxUdpInstanceList[wCnt] = ppxUdpInstanceList[wCnt+1];
    wCnt++;
  }

    {
        UDPSTATE *pxTempUdpInstanceList;

        pxTempUdpInstanceList = (UDPSTATE *)MALLOC((oUdpInstances)*sizeof(UDPSTATE *));
        ASSERT(pxTempUdpInstanceList);
        MOC_MEMCPY((ubyte *)pxTempUdpInstanceList,(ubyte *)ppxUdpInstanceList,
            (oUdpInstances*sizeof(UDPSTATE *)));

        ppxUdpInstanceList = (UDPSTATE **)pxTempUdpInstanceList;
    }

  return 0;
}

/*
 * UdpInstanceSet
 *  Set a UDP Instance Option
 *
 *  Args:
 *   hUdp                       UDP instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG UdpInstanceSet(H_NETINSTANCE hUdp,OCTET oOption,
                    H_NETDATA hData)
{
  UDPSTATE *pxUdp = (UDPSTATE *)hUdp;
  LONG lReturn = NETERR_NOERR;
  UDP_CHECK_STATE(pxUdp);
  switch(oOption) {

  case NETOPTION_OFFSET:
    pxUdp->wOffset = (WORD)hData;
    break;

  case NETOPTION_TRAILER:
    pxUdp->wTrailer = (WORD)hData;
    break;

  case NETOPTION_NETCBK:
    pxUdp->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case NETOPTION_NETCBKHINST:
    pxUdp->hNetCbk = (H_NETINSTANCE)hData;

  case NETOPTION_FREE:
    /* No use for UDP */
    break;

  case NETOPTION_MALLOC:
    /* No use for UDP */
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}


/*
 * UdpInstanceMsg
 *  Send a msg to a UDP instance
 *
 *  Args:
 *   hUdp                       UDP instance
 *   oMsg                       Msg. See netcommon.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG UdpInstanceMsg(H_NETINSTANCE hUdp,OCTET oMsg,
                    H_NETDATA hData)
{
  /* ignores the message for now */
#ifdef NEW_ICMP_MSG_ADDED
  switch(oMsg)
  {
    case UDPMSG_ICMPERRORS:
    {
      TRANSPORTMSGDATA *pxTransportMsgData;
      NETPAYLOAD *pxPayload;
      NETPACKET *pxNetPacket;
      ubyte *poPayload;
      ubyte oErrNo;

      pxTransportMsgData = (TRANSPORTMSGDATA *)(hData);
      pxNetPacket        = pxTransportMsgData->pxNetPacket;
      pxPayload          = pxNetPacket->pxPayload;
      poPayload          = pxPayload->poPayload;
      oErrNo             = pxTransportMsgData->oCode;

      if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_UDP, NORMAL))
      {
          DEBUG_PRINTSTR1INT1 (DEBUG_MOC_IPV4,"UdpInstanceMsg: icmp error message obtained with error code :", oErrNo);
      }
      switch(oErrNo)
      {
        case ICMPERR_UNREACH_NET: break;
        default: break;
      }

      NETPAYLOAD_DELUSER(pxPayload);
      break;
    }
    default:
      break;
  }
#endif
  return 0;
}

/*
 * UdpInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer. It corresponds
 *  to a socket.
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hUdp                       UDP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE UdpInstanceULInterfaceCreate(H_NETINSTANCE hUdp)
{
  UDPSTATE *pxUdp = (UDPSTATE *)hUdp;
  UDPCONN *pxConn;
  UDP_CHECK_STATE(pxUdp);

  pxConn = (UDPCONN *)MALLOC(sizeof(UDPCONN));
  ASSERT(pxConn != NULL);
  MOC_MEMSET((ubyte *)pxConn, 0, sizeof(UDPCONN));

  pxConn->xId.xNetId.oIfIdx = NETIFIDX_ANY;
  pxConn->xId.xNetId.wVlan = NETVLAN_ANY;
  pxConn->xId.xNetId.eDstAddrType = IPADDRT_UNKNOWN;

  /* initialise as non-connected*/
  pxConn->bWithInAddrAny = TRUE;

  /*Compute the udp checksum, RFC says it must be on by default*/
  pxConn->bTxCheck = TRUE;

  DLLIST_append(&pxUdp->dllConns, pxConn);

  return (H_NETINTERFACE)pxConn;
}

/*
 * UdpInstanceULInterfaceDestroy
 *  Destroy a UDP UL interface
 *
 *  Args:
 *   hUdp                       UDP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG UdpInstanceULInterfaceDestroy(H_NETINSTANCE hUdp,
                                   H_NETINTERFACE hInterface)
{
  UDPSTATE *pxUdp = (UDPSTATE *)hUdp;
  LONG lReturn = NETERR_NOERR;
  UDP_CHECK_STATE(pxUdp);

  DLLIST_head(&pxUdp->dllConns);
  if (DLLIST_find(&pxUdp->dllConns,(void *)hInterface,
                  _UdpFindItemByAddress) != NULL) {
    UDPCONN *pxConn;

    pxConn = DLLIST_remove(&pxUdp->dllConns);
    FREE(pxConn);
  }
  else {
    ASSERT(0);
    lReturn = NETERR_BADHANDLE;
  }

  return lReturn;
}


/*
 * UdpInstanceULInterfaceIoctl
 *  Udp UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and nettransport.h for precisions
 *
 *  Args:
 *   hUdp                         UDP instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG UdpInstanceULInterfaceIoctl(H_NETINSTANCE hUdp,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  UDPSTATE *pxUdp = (UDPSTATE *)hUdp;
  UDPCONN *pxConn = (UDPCONN *)hULInterface;
  LONG lReturn = NETERR_NOERR;
  UDP_CHECK_STATE(pxUdp);
  ASSERT(pxConn != NULL);

#ifndef NDEBUG
  DLLIST_head(&pxUdp->dllConns);
#endif

  if ((pxConn
#ifndef NDEBUG
       /* Make sure the connection exists. Only in debug mode ??? */
       = DLLIST_find(&pxUdp->dllConns,(void *)hULInterface,
                     _UdpFindItemByAddress)
#endif
       ) != NULL) {
    TRANSPORT2NETWORKID *pxConnNetId;
    /* Interface exists */

    pxConnNetId = &(pxConn->xId.xNetId);

#ifndef NDEBUG
    /* Handle Ioctl *QUERY ASSERTs to minimise codespace in debug */
    switch(oIoctl) {
      case NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALIP:
      case NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT:
      case NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEIP:
      case NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEPORT:
      case NETTRANSPORTULINTERFACEIOCTL_QUERYTRANSPORTID:
        ASSERT(hData != (H_NETDATA) NULL);

      default:
        break;
    }
#endif

    switch(oIoctl) {
        /* configuration ioctls */
    case NETTRANSPORTULINTERFACEIOCTL_SETLOCALIP: /* Set Local IP. Data is a
                                                     DWORD.MANDATORY */
      pxConnNetId->dwSrcIpAddr = (DWORD)hData;
      pxConn->bWithInAddrAny = 0;
      break;

    case NETTRANSPORTULINTERFACEIOCTL_SETLOCALPORT:/* Set Local Port.
                                                      Data is WORD */

      if ((WORD) hData == 0) {
        return _UdpFindNewLocalPort(pxUdp, pxConn);
      }
      else {
        return _UdpSetLocalPort(pxUdp, pxConn,(WORD) hData, pxConn->bIsReuseAllowed);
      }

    case NETTRANSPORTULINTERFACEIOCTL_SETIF: /* Set interface index */
      pxConnNetId->oIfIdx = (OCTET)hData;
      break;

    case NETTRANSPORTULINTERFACEIOCTL_SETVLAN: /* Set VLAN tag */
      pxConnNetId->wVlan = (WORD)hData;
      break;

    case NETTRANSPORTULINTERFACEIOCTL_SETREUSEADDR: /* reuse addr option */
      pxConn->bIsReuseAllowed = (BOOL)hData;
      break;

    case NETTRANSPORTULINTERFACEIOCTL_CONNECT:/* UDP will only receive data
                                                 from the provided UDP peer,
                                                 and discard the rest. Data
                                                 is TRANSPORTID  */
      {
        TRANSPORTID *pxNewId = (TRANSPORTID *)hData;

        ASSERT(pxNewId != NULL);

        /* Check the local port. Set it if not set */
        if (pxConn->xId.wSrcPort ==0) {
          /* local port not set */
          lReturn = _UdpFindNewLocalPort(pxUdp, pxConn);
          if (lReturn == -1)
            break;
        }
        /* At this point, the connect has been accepted: */

        pxConn->oRemoteNotVolatile = (OCTET) TRUE;
        if (pxConn->bWithInAddrAny == FALSE) {
          /* Local Ip Address was already set: keep it */
          pxNewId->xNetId.dwSrcIpAddr = pxConnNetId->dwSrcIpAddr;
        }
        if (pxConnNetId->oIfIdx != NETIFIDX_ANY) {
          pxNewId->xNetId.oIfIdx = pxConnNetId->oIfIdx;
        }
        if (pxConnNetId->wVlan != NETVLAN_ANY) {
          pxNewId->xNetId.wVlan = pxConnNetId->wVlan;
        }
        pxNewId->wSrcPort = pxConn->xId.wSrcPort;

        /* Free the old NetId */
        /* Copy in the network part, as is */
        MOC_MEMCPY((ubyte *)&(pxConn->xId),(ubyte *)pxNewId,
            sizeof(TRANSPORTID));
      }
    break;

    case NETINTERFACEIOCTL_SETHINST:

      pxConn->hUL = (H_NETINSTANCE)hData;
      break;

    case NETINTERFACEIOCTL_SETIF:

      pxConn->hIf = (H_NETINTERFACE)hData;
      break;

    case NETINTERFACEIOCTL_SETOUTPUTPFN:/* Set the Rx Call back. Data is
                                         PFN_NETRXCBK */
      pxConn->pfnRxCbk = (PFN_NETRXCBK)hData;
      break;

    case NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALIP:/* Query Local IP. Data is
                                                      DWORD * */
      *((DWORD *)hData) = pxConnNetId->dwSrcIpAddr;
      break;

    case NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT:/* Query Local Port.
                                                        Data is WORD * */
      *((WORD *)hData) =  pxConn->xId.wSrcPort;
      break;

    case NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEIP:/* Query the Remote IP.
                                                       Data is DWORD * */
      *((DWORD *)hData) = pxConnNetId->dwDstIpAddr;
      break;

    case NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEPORT:/* Query the Remote Port.
                                                         Data is WORD **/
      *((WORD *)hData) =  pxConn->xId.wDstPort;
      break;

    case NETINTERFACEIOCTL_OPEN:
    case NETINTERFACEIOCTL_CLOSE:
      break;

    case NETTRANSPORTULINTERFACEIOCTL_QUERYTRANSPORTID:
      MOC_MEMCPY((ubyte *)hData,(ubyte *)&(pxConn->xId),sizeof(TRANSPORTID));
      break;

    case UDPULINTERFACEIOCTL_TXCHECK:
      pxConn->bTxCheck = (BOOL) hData;
      break;

    case UDPULINTERFACEIOCTL_MCASTJOIN:
    {
      IPMCASTREQ *pxIpMcastReq = (IPMCASTREQ *) hData;
      ASSERT(pxIpMcastReq != NULL);

      #if 0
      if (pxConnNetId->dwSrcIpAddr == 0) {
        /* local IP not yet set, error */
        lReturn = -1;
        break;
      }
      #endif

      pxConn->pxIpMcastReq = (IPMCASTREQ *)MALLOC(sizeof(IPMCASTREQ));
      ASSERT(pxConn->pxIpMcastReq != NULL);
      MOC_MEMSET((ubyte *)pxConn->pxIpMcastReq, 0, sizeof(IPMCASTREQ));

      MOC_MEMCPY((ubyte *)pxConn->pxIpMcastReq,
            (ubyte *)pxIpMcastReq,sizeof(IPMCASTREQ));
      pxConn->xId.xNetId.oIfIdx = NETIFIDX_ANY;
      lReturn = 0;
    }
    break;

    case UDPULINTERFACEIOCTL_MCASTDROP:
      {
        IPMCASTREQ *pxIpMcastReq = (IPMCASTREQ *) hData;
        ASSERT(pxIpMcastReq != NULL);

        if(pxConn->pxIpMcastReq == NULL){
          return -1;
        }

        if((pxConn->pxIpMcastReq->dwMulticastAddr == pxIpMcastReq->dwMulticastAddr) &&
           (pxConn->pxIpMcastReq->oPhyIf          == pxIpMcastReq->oPhyIf)){
          FREE(pxConn->pxIpMcastReq);
          pxConn->pxIpMcastReq = NULL;
          lReturn = 0;
        } else {
          lReturn = -1;
        }
      }
    break;

    case UDPULINTERFACEIOCTL_MCASTADDR:
      pxConn->dwMcastIf = (DWORD) hData;
      break;

    case NETTRANSPORTULINTERFACEIOCTL_QUERYSTATS:
      /* none for now - intentional fallthru !! */
    default:
      lReturn = NETERR_UNKNOWN;
    }
  }
  else {
    ASSERT(0);
    lReturn = NETERR_BADHANDLE;
  }

  return lReturn;
}

/*
 * UdpInstanceWrite
 *  Udp Instance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hUdp                        Udp Instance handle
 *   hIf                         must be the UL interface handle
 *   pxPacket                    Packet pointer
 *   pxAccess                    NETPACKETACCESS pointer
 *   hData                       casted TRANSPORTID
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG UdpInstanceWrite(H_NETINSTANCE hUdp,
          H_NETINTERFACE hIf,
          NETPACKET *pxPacket,
          NETPACKETACCESS *pxAccess,
          H_NETDATA hData)
{
  UDPSTATE *pxUdp = (UDPSTATE *)hUdp;
  UDPCONN *pxConn = (UDPCONN *)hIf;
  TRANSPORTID *pxTransportId = (TRANSPORTID *)hData, *pxConnId;
  UDPHDR *pxUdph;
  UDPPSH *pxUdPsh;
  LONG lReturn = pxAccess->wLength;

  UDP_CHECK_STATE(pxUdp);
  NETPACKET_CHECK(pxPacket);
  ASSERT(pxUdp != NULL && pxConn != NULL && pxAccess != NULL);

  pxConnId = &(pxConn->xId);
  ASSERT((pxConnId != NULL) &&
        ((((DWORD)(pxPacket->pxPayload->poPayload)) & 3) == 0) &&
        (pxAccess->wOffset > (sizeof(UDPHDR) + sizeof(UDPPSH))));

  if (pxConn->oRemoteNotVolatile == FALSE) {
    ASSERT(pxTransportId != NULL);

    if (pxConnId->wSrcPort == 0) {
      /* local port not assigned - set it now */
      if ( _UdpFindNewLocalPort(pxUdp, pxConn) < 0) {
        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        return NETERR_UNKNOWN;
      }
    }

    /* If the Conn local IP is set, use it (or we assume that the one
       on pxTransportId is valid */
    if (pxConn->bWithInAddrAny == FALSE) {
      /* get local IP from UDPCONN */
      pxTransportId->xNetId.dwSrcIpAddr = pxConnId->xNetId.dwSrcIpAddr;
    }
    /* If the Conn Idx is set, use it */
    if (pxConnId->xNetId.oIfIdx != NETIFIDX_ANY) {
      pxTransportId->xNetId.oIfIdx = pxConnId->xNetId.oIfIdx;
    }
    /* If the Conn Vlan is set, use it */
    if (pxConnId->xNetId.wVlan != NETVLAN_ANY) {
      pxTransportId->xNetId.wVlan = pxConnId->xNetId.wVlan;
    }
  }
  else {
    /* connected socket: use the connection TRANSPORTID */
    pxConnId->xNetId.wIpSecTrailLength = pxTransportId->xNetId.wIpSecTrailLength;
    pxTransportId = pxConnId;
  }

  ASSERT(pxTransportId != NULL);

  pxUdph = (UDPHDR *) (pxPacket->pxPayload->poPayload
                + pxAccess->wOffset - sizeof(UDPHDR));

  pxUdph->wSrcport = htons(pxTransportId->wSrcPort);
  pxUdph->wDstport = htons(pxTransportId->wDstPort);

  if (((pxTransportId->xNetId.eDstAddrType == IPADDRT_MULTICAST) ||
       (pxTransportId->xNetId.eDstAddrType == IPADDRT_MULTICASTJOINED)) &&
      (pxConn->dwMcastIf != 0)) {
    /* use mcast */
    pxTransportId->xNetId.oIfIdx = (OCTET)pxConn->dwMcastIf;
  }


  pxUdph->wLen = htons(pxAccess->wLength + sizeof(UDPHDR));

  pxUdPsh = (UDPPSH *) (((OCTET *) pxUdph) - sizeof(UDPPSH));

  pxUdph->wCheck = 0;

  if (pxConn->bTxCheck) {
    /* use checksum on tx */
    pxUdPsh->dwSrcIP = htonl(pxTransportId->xNetId.dwSrcIpAddr);
    pxUdPsh->dwDstIP = htonl(pxTransportId->xNetId.dwDstIpAddr);
    pxUdPsh->oNull = 0;
    pxUdPsh->oProt = 17;
    pxUdPsh->wLen = pxUdph->wLen;
    pxUdph->wCheck = Checksum16((OCTET *)pxUdPsh,
                                ntohs(pxUdPsh->wLen)+sizeof(UDPPSH));
  }
  /* JJ As of now set it to 0; */
  pxUdph->wCheck = 0;
  ASSERT(pxAccess->wOffset >= sizeof(UDPHDR));
  pxAccess->wOffset -= sizeof(UDPHDR);
  pxAccess->wLength += sizeof(UDPHDR);

  if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_UDP, NORMAL))
  {
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"UdpInstanceWrite:oIfIdx=",
        pxTransportId->xNetId.oIfIdx);
    DEBUG_PRINT(DEBUG_MOC_IPV4,", from ");
    /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4,pxTransportId->xNetId.dwSrcIpAddr);*/
    DEBUG_INT(DEBUG_MOC_IPV4,pxTransportId->xNetId.dwSrcIpAddr);
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"port ", ntohs(pxUdph->wSrcport));
    DEBUG_PRINT(DEBUG_MOC_IPV4," to ");
    /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4,pxTransportId->xNetId.dwDstIpAddr);*/
    DEBUG_INT(DEBUG_MOC_IPV4,pxTransportId->xNetId.dwDstIpAddr);
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"port ", ntohs(pxUdph->wDstport));
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"pkt len ", ntohs(pxUdph->wLen));
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "\n");
  }

  SNMP( xTcpipData.udpOutDatagrams++ );

  ASSERT(pxUdp->pfnLLWrite != NULL && pxUdp->hLL != (H_NETINSTANCE) NULL &&
    pxUdp->hUdpLLIf != (H_NETINTERFACE) NULL);

  (*(pxUdp->pfnLLWrite))(pxUdp->hLL, pxUdp->hUdpLLIf,
                         pxPacket, pxAccess,
                         (H_NETDATA)&(pxTransportId->xNetId));

  return lReturn;
}


/*
 * UdpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hUdp                       UDP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE UdpInstanceLLInterfaceCreate(H_NETINSTANCE hUdp)
{
  /* The LL interface does not exist outside of the instance anyway */
  return (H_NETINTERFACE)UDPLLINTERFACEHANDLE;
}

/*
 * UdpInstanceLLInterfaceDestroy
 *  Destroy a UDP LL interface
 *
 *  Args:
 *   hUdp                       UDP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG UdpInstanceLLInterfaceDestroy(H_NETINSTANCE hUdp,
                                   H_NETINTERFACE hInterface)
{
  ASSERT((DWORD)hInterface == UDPLLINTERFACEHANDLE);

  return 0;
}

/*
 * UdpInstanceLLInterfaceIoctl
 *  UDP LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions for precisions
 *
 *  Args:
 *   hUdp                         Udp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG UdpInstanceLLInterfaceIoctl(H_NETINSTANCE hUdp,
                                 H_NETINTERFACE hLLInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  UDPSTATE *pxUdp = (UDPSTATE *) hUdp;
  LONG lReturn = NETERR_NOERR;
  UDP_CHECK_STATE(pxUdp);
  ASSERT((DWORD) hLLInterface == UDPLLINTERFACEHANDLE);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_SETIF: /* Set the ID of UDP as understood by the
                                     lower protocol. */
    pxUdp->hUdpLLIf = (H_NETINTERFACE)hData;
    break;

  case NETINTERFACEIOCTL_SETHINST:/* Set the Lower layer Instance Handle */

    pxUdp->hLL = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:/* Set the write function. Data is
                                       PFN_NETWRITE; this function
                                       will be given the IP address of the
                                       remote end as the hDst */
    pxUdp->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_OPEN:  /* Open the interface */
  case NETINTERFACEIOCTL_CLOSE: /* Close the interface */

    break;

  default:
    lReturn = NETERR_UNKNOWN;
  }

  return lReturn;
}


/*
 * UdpInstanceRcv
 *  Udp Instance Rcv function
 *   Udp Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hUdp                        Ud Instance Handle
 *    hIf                         Interface handle
 *    pxPacket                    packet pointer
 *    pxAccess                    NETPACKETACCESS pointer
 *    hData                       casted TRANSPORT2NETWORKID *
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG UdpInstanceRcv(H_NETINSTANCE hUdp,H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                    H_NETDATA hData)
{
  UDPSTATE *pxUdp = (UDPSTATE *)hUdp;
  TRANSPORT2NETWORKID *pxTp2NetId = (TRANSPORT2NETWORKID *)hData;
  UDPCONN *pxConn;
  UDPHDR *pxUdph;
  UDPPSH xUdPsh;
  OCTET *poHdr;
  UDPPSH oIPHdr;
  NETPAYLOAD *pxPayload;
  OCTET *poPayload;
  WORD wLength;
  TRANSPORTID xTransportId;
  WORD wChecksum;
  LONG lRC = pxAccess->wLength;;

  UDP_CHECK_STATE(pxUdp);
  ASSERT(((int)hIf == UDPLLINTERFACEHANDLE) &&
         (pxAccess != NULL) &&
         (pxTp2NetId != NULL));

  NETPACKET_CHECK(pxPacket);

  pxPayload = pxPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  SNMP( xTcpipData.udpInDatagrams++ );

  poHdr = poPayload + pxAccess->wOffset;
  pxUdph = (UDPHDR *)poHdr;

  wLength = ntohs(pxUdph->wLen);

  /* if UDP length field exceeds packet length, trash the packet */
  if (wLength > lRC) {
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_UDP, ERROR))
    {
        DEBUG_PRINTSTR2INT2 (DEBUG_MOC_IPV4, "UdpInstanceRcv:UDP len ",
            wLength, "!= TCP len ", (WORD)lRC);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
    }
    NETPAYLOAD_DELUSER(pxPayload);
    SNMP(xTcpipData.udpInErrors++);
    return -1;
  }

  if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_UDP, NORMAL))
  {
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"UdpInstanceRcv:oIfIdx=",
       pxTp2NetId->oIfIdx);
    DEBUG_PRINT(DEBUG_MOC_IPV4,", from ");
    /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4,pxTp2NetId->dwSrcIpAddr);*/
    DEBUG_INT(DEBUG_MOC_IPV4,pxTp2NetId->dwSrcIpAddr);
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," port ", ntohs(pxUdph->wSrcport));
    DEBUG_PRINT(DEBUG_MOC_IPV4," to ");
    /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4, pxTp2NetId->dwDstIpAddr);*/
    DEBUG_INT(DEBUG_MOC_IPV4, pxTp2NetId->dwDstIpAddr);
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," port ", ntohs(pxUdph->wDstport));
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," pkt len ", wLength);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
  }

  ASSERT(pxAccess->wOffset >= sizeof(UDPPSH));

  if (pxUdph->wCheck) {
    /* sender has computed checksum */
    xUdPsh.dwSrcIP = htonl(pxTp2NetId->dwSrcIpAddr);
    xUdPsh.dwDstIP = htonl(pxTp2NetId->dwDstIpAddr);
    xUdPsh.oNull = 0;
    xUdPsh.oProt = 17;
    xUdPsh.wLen = (pxUdph->wLen);

    poHdr -= sizeof(UDPPSH);
    /* Save the Original part in the IP Hdr JJ */
    MOC_MEMCPY((ubyte *)&oIPHdr,(ubyte *)poHdr,sizeof(UDPPSH));
    /* copy UDP pseudo header into packet */
    MOC_MEMCPY((ubyte *)poHdr,(ubyte *)&xUdPsh, sizeof(UDPPSH));

    /*(pxUdph->wCheck)  = 0; //JJ  *//*for Now Got to fix big packets */
    if (pxUdph->wCheck) {
        if ((wChecksum=Checksum16(poHdr, wLength+sizeof(UDPPSH))) != 0) {
            if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_UDP, ERROR))
            {
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,
                    "UdpInstanceRcv:Bad checksum calc=", wChecksum);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, ", set=", pxUdph->wCheck);
                DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
            }
            NETPAYLOAD_DELUSER(pxPayload);
            SNMP(xTcpipData.udpInErrors++);
            return -1;
        }
    }/* JJ DID this */
  }

  xTransportId.wSrcPort = ntohs(pxUdph->wSrcport);
  xTransportId.wDstPort = ntohs(pxUdph->wDstport);
  /* Copy the original NETWORKID. Is there a way to avoid this ? */
  xTransportId.xNetId = *pxTp2NetId;

  /* locate UDPCONN for this IP, port */
  DLLIST_head(&pxUdp->dllConns);
  pxConn = DLLIST_find(&pxUdp->dllConns,(void *)&xTransportId,_UdpIdCmp);

  if (pxConn == NULL) {
    UDPCBKDATA xCbkData;

    /* Could not find a connection. If it is a broadcast or
       a multicast, just toss the packet and return */
    if( (pxTp2NetId->eDstAddrType == IPADDRT_BROADCAST) ||
        (pxTp2NetId->eDstAddrType == IPADDRT_MULTICAST) ||
        (pxTp2NetId->eDstAddrType == IPADDRT_MULTICASTJOINED)){
      NETPAYLOAD_DELUSER(pxPayload);
      SNMP(xTcpipData.udpNoPorts++);
      return -1;
    }

    /* otherwise, signal a Dst unreach, port unreach */
    /* Copy Back the Original IP Hdr JJ, only if the wCheck flag is true.  */
    if (pxUdph->wCheck)
      MOC_MEMCPY((ubyte *)poHdr,(ubyte *) &oIPHdr,sizeof(UDPPSH));

    xCbkData.pxNetPacket           = pxPacket;
    xCbkData.pxNetPacketAccess     = pxAccess;
    xCbkData.xId = xTransportId;

    /* no destination UDP - signal to wrapper */
    ASSERT(pxUdp->pfnNetCbk != NULL);
    (*pxUdp->pfnNetCbk)(pxUdp->hNetCbk,
                        UDPCBK_DSTUNREACHABLE, (H_NETDATA)&xCbkData);

    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_UDP, NORMAL))
    {
        DEBUG_PRINT(DEBUG_MOC_IPV4, "UdpInstanceRcv:Dest ");
        /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4, pxTp2NetId->dwDstIpAddr);*/
        DEBUG_INT(DEBUG_MOC_IPV4, pxTp2NetId->dwDstIpAddr);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," unreachalble port",
            ntohs(xTransportId.wDstPort));
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
    }
    SNMP(xTcpipData.udpNoPorts++);
    return -1;
  }

  /* set wlength, in case packet exceeds udplen */
  pxAccess->wLength = wLength - sizeof(UDPHDR);
  pxAccess->wOffset += sizeof(UDPHDR);

  /* send UDP data to socket */
  ASSERT(pxConn->pfnRxCbk != NULL);
  (*pxConn->pfnRxCbk)(pxConn->hUL,
                      pxConn->hIf, pxPacket, pxAccess,
                      (H_NETDATA)&xTransportId);

  return lRC;
}

BOOL gbUdpPrintConnection;
/*
 * UdpInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hUdp                        Udp Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG UdpInstanceProcess(H_NETINSTANCE hUdp)
{
  UDPSTATE *pxUdp = (UDPSTATE *)hUdp;
  UDP_CHECK_STATE(pxUdp);

  if(gbUdpPrintConnection == TRUE){
    _UdpPrintConnection(pxUdp);
    gbUdpPrintConnection = FALSE;
  }

  return 1000;
}

void _UdpPrintConnection(UDPSTATE *pxUdp)
{
  UDPCONN *pxUdpConn;

  printf("**** UdpPrintConnection ****\n");

  DLLIST_head(&pxUdp->dllConns);
  while((pxUdpConn = DLLIST_read(&pxUdp->dllConns)) != NULL){
    printf("[%d] 0x%p from %ld.%ld.%ld.%ld/%d to %ld.%ld.%ld.%ld/%d, oIfIdx=%d, wVlan=%d\n",
           (int)pxUdpConn->hUL,
           pxUdpConn,
           IPADDRDISPLAY(pxUdpConn->xId.xNetId.dwSrcIpAddr),
           pxUdpConn->xId.wSrcPort,
           IPADDRDISPLAY(pxUdpConn->xId.xNetId.dwDstIpAddr),
           pxUdpConn->xId.wSrcPort,
           pxUdpConn->xId.xNetId.oIfIdx,
           pxUdpConn->xId.xNetId.wVlan);
    DLLIST_next(&pxUdp->dllConns);
  }

}
