#ifndef _I386_ERRNO_H
#define _I386_ERRNO_H

#if defined (__RTOS_LINUX__) || defined (__RTOS_CYGWIN__)

#define	MO_EPERM		 1	/* Operation not permitted */
#define	MO_ENOENT		 2	/* No such file or directory */
#define	MO_ESRCH		 3	/* No such process */
#define	MO_EINTR		 4	/* Interrupted system call */
#define	MO_EIO			 5	/* I/O error */
#define	MO_ENXIO		 6	/* No such device or address */
#define	MO_E2BIG		 7	/* Arg list too long */
#define	MO_ENOEXEC		 8	/* Exec format error */
#define	MO_EBADF		 9	/* Bad file number */
#define	MO_ECHILD		10	/* No child processes */
#define	MO_EAGAIN		11	/* Try again */
#define	MO_ENOMEM		12	/* Out of memory */
#define	MO_EACCES		13	/* Permission denied */
#define	MO_EFAULT		14	/* Bad address */
#define	MO_ENOTBLK		15	/* Block device required */
#define	MO_EBUSY		16	/* Device or resource busy */
#define	MO_EEXIST		17	/* File exists */
#define	MO_EXDEV		18	/* Cross-device link */
#define	MO_ENODEV		19	/* No such device */
#define	MO_ENOTDIR		20	/* Not a directory */
#define	MO_EISDIR		21	/* Is a directory */
#define	MO_EINVAL		22	/* Invalid argument */
#define	MO_ENFILE		23	/* File table overflow */
#define	MO_EMFILE		24	/* Too many open files */
#define	MO_ENOTTY		25	/* Not a typewriter */
#define	MO_ETXTBSY		26	/* Text file busy */
#define	MO_EFBIG		27	/* File too large */
#define	MO_ENOSPC		28	/* No space left on device */
#define	MO_ESPIPE		29	/* Illegal seek */
#define	MO_EROFS		30	/* Read-only file system */
#define	MO_EMLINK		31	/* Too many links */
#define	MO_EPIPE		32	/* Broken pipe */
#define	MO_EDOM			33	/* Math argument out of domain of func */
#define	MO_ERANGE		34	/* Math result not representable */
#define	MO_EDEADLK		35	/* Resource deadlock would occur */
#define	MO_ENAMETOOLONG		36	/* File name too long */
#define	MO_ENOLCK		37	/* No record locks available */
#define	MO_ENOSYS		38	/* Function not implemented */
#define	MO_ENOTEMPTY		39	/* Directory not empty */
#define	MO_ELOOP		40	/* Too many symbolic links encountered */
#define	MO_EWOULDBLOCK		MO_EAGAIN	/* Operation would block */
#define	MO_ENOMSG		42	/* No message of desired type */
#define	MO_EIDRM		43	/* Identifier removed */
#define	MO_ECHRNG		44	/* Channel number out of range */
#define	MO_EL2NSYNC		45	/* Level 2 not synchronized */
#define	MO_EL3HLT		46	/* Level 3 halted */
#define	MO_EL3RST		47	/* Level 3 reset */
#define	MO_ELNRNG		48	/* Link number out of range */
#define	MO_EUNATCH		49	/* Protocol driver not attached */
#define	MO_ENOCSI		50	/* No CSI structure available */
#define	MO_EL2HLT		51	/* Level 2 halted */
#define	MO_EBADE		52	/* Invalid exchange */
#define	MO_EBADR		53	/* Invalid request descriptor */
#define	MO_EXFULL		54	/* Exchange full */
#define	MO_ENOANO		55	/* No anode */
#define	MO_EBADRQC		56	/* Invalid request code */
#define	MO_EBADSLT		57	/* Invalid slot */

#define	MO_EDEADLOCK	MO_EDEADLK

#define	MO_EBFONT	59	/* Bad font file format */
#define	MO_ENOSTR	60	/* Device not a stream */
#define	MO_ENODATA	61	/* No data available */
#define	MO_ETIME	62	/* Timer expired */
#define	MO_ENOSR	63	/* Out of streams resources */
#define	MO_ENONET	64	/* Machine is not on the network */
#define	MO_ENOPKG	65	/* Package not installed */
#define	MO_EREMOTE	66	/* Object is remote */
#define	MO_ENOLINK	67	/* Link has been severed */
#define	MO_EADV		68	/* Advertise error */
#define	MO_ESRMNT	69	/* Srmount error */
#define	MO_ECOMM	70	/* Communication error on send */
#define	MO_EPROTO	71	/* Protocol error */
#define	MO_EMULTIHOP	72	/* Multihop attempted */
#define	MO_EDOTDOT	73	/* RFS specific error */
#define	MO_EBADMSG	74	/* Not a data message */
#define	MO_EOVERFLOW	75	/* Value too large for defined data type */
#define	MO_ENOTUNIQ	76	/* Name not unique on network */
#define	MO_EBADFD	77	/* File descriptor in bad state */
#define	MO_EREMCHG	78	/* Remote address changed */
#define	MO_ELIBACC	79	/* Can not access a needed shared library */
#define	MO_ELIBBAD	80	/* Accessing a corrupted shared library */
#define	MO_ELIBSCN	81	/* .lib section in a.out corrupted */
#define	MO_ELIBMAX	82	/* Attempting to link in too many shared libraries */
#define	MO_ELIBEXEC	83	/* Cannot exec a shared library directly */
#define	MO_EILSEQ	84	/* Illegal byte sequence */
#define	MO_ERESTART	85	/* Interrupted system call should be restarted */
#define	MO_ESTRPIPE	86	/* Streams pipe error */
#define	MO_EUSERS	87	/* Too many users */
#define	MO_ENOTSOCK	88	/* Socket operation on non-socket */
#define	MO_EDESTADDRREQ	89	/* Destination address required */
#define	MO_EMSGSIZE	90	/* Message too long */
#define	MO_EPROTOTYPE	91	/* Protocol wrong type for socket */
#define	MO_ENOPROTOOPT	92	/* Protocol not available */
#define	MO_EPROTONOSUPPORT	93	/* Protocol not supported */
#define	MO_ESOCKTNOSUPPORT	94	/* Socket type not supported */
#define	MO_EOPNOTSUPP	95	/* Operation not supported on transport endpoint */
#define	MO_EPFNOSUPPORT	96	/* Protocol family not supported */
#define	MO_EAFNOSUPPORT	97	/* Address family not supported by protocol */
#define	MO_EADDRINUSE	98	/* Address already in use */
#define	MO_EADDRNOTAVAIL	99	/* Cannot assign requested address */
#define	MO_ENETDOWN	100	/* Network is down */
#define	MO_ENETUNREACH	101	/* Network is unreachable */
#define	MO_ENETRESET	102	/* Network dropped connection because of reset */
#define	MO_ECONNABORTED	103	/* Software caused connection abort */
#define	MO_ECONNRESET	104	/* Connection reset by peer */
#define	MO_ENOBUFS	105	/* No buffer space available */
#define	MO_EISCONN	106	/* Transport endpoint is already connected */
#define	MO_ENOTCONN	107	/* Transport endpoint is not connected */
#define	MO_ESHUTDOWN	108	/* Cannot send after transport endpoint shutdown */
#define	MO_ETOOMANYREFS	109	/* Too many references: cannot splice */
#define	MO_ETIMEDOUT	110	/* Connection timed out */
#define	MO_ECONNREFUSED	111	/* Connection refused */
#define	MO_EHOSTDOWN	112	/* Host is down */
#define	MO_EHOSTUNREACH	113	/* No route to host */
#define	MO_EALREADY	114	/* Operation already in progress */
#define	MO_EINPROGRESS	115	/* Operation now in progress */
#define	MO_ESTALE	116	/* Stale NFS file handle */
#define	MO_EUCLEAN	117	/* Structure needs cleaning */
#define	MO_ENOTNAM	118	/* Not a XENIX named type file */
#define	MO_ENAVAIL	119	/* No XENIX semaphores available */
#define	MO_EISNAM	120	/* Is a named type file */
#define	MO_EREMOTEIO	121	/* Remote I/O error */
#define	MO_EDQUOT	122	/* Quota exceeded */

#define	MO_ENOMEDIUM	123	/* No medium found */
#define	MO_EMEDIUMTYPE	124	/* Wrong medium type */


#elif defined (__RTOS_VXWORKS__)

/*
 * POSIX Error codes
 */

#define	MO_EPERM		1		/* Not owner */
#define	MO_ENOENT		2		/* No such file or directory */
#define	MO_ESRCH		3		/* No such process */
#define	MO_EINTR		4		/* Interrupted system call */
#define	MO_EIO		5		/* I/O error */
#define	MO_ENXIO		6		/* No such device or address */
#define	MO_E2BIG		7		/* Arg list too long */
#define	MO_ENOEXEC		8		/* Exec format error */
#define	MO_EBADF		9		/* Bad file number */
#define	MO_ECHILD		10		/* No children */
#define	MO_EAGAIN		11		/* No more processes */
#define	MO_ENOMEM		12		/* Not enough core */
#define	MO_EACCES		13		/* Permission denied */
#define	MO_EFAULT		14		/* Bad address */
#define	MO_ENOTEMPTY	15		/* Directory not empty */
#define	MO_EBUSY		16		/* Mount device busy */
#define	MO_EEXIST		17		/* File exists */
#define	MO_EXDEV		18		/* Cross-device link */
#define	MO_ENODEV		19		/* No such device */
#define	MO_ENOTDIR		20		/* Not a directory*/
#define	MO_EISDIR		21		/* Is a directory */
#define	MO_EINVAL		22		/* Invalid argument */
#define	MO_ENFILE		23		/* File table overflow */
#define	MO_EMFILE		24		/* Too many open files */
#define	MO_ENOTTY		25		/* Not a typewriter */
#define	MO_ENAMETOOLONG	26		/* File name too long */
#define	MO_EFBIG		27		/* File too large */
#define	MO_ENOSPC		28		/* No space left on device */
#define	MO_ESPIPE		29		/* Illegal seek */
#define	MO_EROFS		30		/* Read-only file system */
#define	MO_EMLINK		31		/* Too many links */
#define	MO_EPIPE		32		/* Broken pipe */
#define	MO_EDEADLK		33		/* Resource deadlock avoided */
#define	MO_ENOLCK		34		/* No locks available */
#define	MO_ENOTSUP		35		/* Unsupported value */
#define	MO_EMSGSIZE		36		/* Message size */

/* ANSI math software */
#define	MO_EDOM		37		/* Argument too large */
#define	MO_ERANGE		38		/* Result too large */

/* ipc/network software */

	/* argument errors */
#define	MO_EDESTADDRREQ	40		/* Destination address required */
#define	MO_EPROTOTYPE	41		/* Protocol wrong type for socket */
#define	MO_ENOPROTOOPT	42		/* Protocol not available */
#define	MO_EPROTONOSUPPORT	43		/* Protocol not supported */
#define	MO_ESOCKTNOSUPPORT	44		/* Socket type not supported */
#define	MO_EOPNOTSUPP	45		/* Operation not supported on socket */
#define	MO_EPFNOSUPPORT	46		/* Protocol family not supported */
#define	MO_EAFNOSUPPORT	47		/* Addr family not supported */
#define	MO_EADDRINUSE	48		/* Address already in use */
#define	MO_EADDRNOTAVAIL	49		/* Can't assign requested address */
#define	MO_ENOTSOCK	50		/* Socket operation on non-socket */

	/* operational errors */
#define	MO_ENETUNREACH	51		/* Network is unreachable */
#define	MO_ENETRESET	52		/* Network dropped connection on reset*/
#define	MO_ECONNABORTED	53		/* Software caused connection abort */
#define	MO_ECONNRESET	54		/* Connection reset by peer */
#define	MO_ENOBUFS		55		/* No buffer space available */
#define	MO_EISCONN		56		/* Socket is already connected */
#define	MO_ENOTCONN	57		/* Socket is not connected */
#define	MO_ESHUTDOWN	58		/* Can't send after socket shutdown */
#define	MO_ETOOMANYREFS	59		/* Too many references: can't splice */
#define	MO_ETIMEDOUT	60		/* Connection timed out */
#define	MO_ECONNREFUSED	61		/* Connection refused */
#define	MO_ENETDOWN	62		/* Network is down */
#define	MO_ETXTBSY		63		/* Text file busy */
#define	MO_ELOOP		64		/* Too many levels of symbolic links */
#define	MO_EHOSTUNREACH	65		/* No route to host */
#define	MO_ENOTBLK		66		/* Block device required */
#define	MO_EHOSTDOWN	67		/* Host is down */

/* non-blocking and interrupt i/o */
#define	MO_EINPROGRESS	68		/* Operation now in progress */
#define	MO_EALREADY	69		/* Operation already in progress */
#define	MO_EWOULDBLOCK	70		/* Operation would block */

#define	MO_ENOSYS		71		/* Function not implemented */

/* aio errors (should be under posix) */
#define	MO_ECANCELED	72		/* Operation canceled */


/* specific STREAMS errno values */
#define MO_ENOSR           74              /* Insufficient memory */
#define MO_ENOSTR          75              /* STREAMS device required */
#define MO_EPROTO          76              /* Generic STREAMS error */
#define MO_EBADMSG         77              /* Invalid STREAMS message */
#define MO_ENODATA         78              /* Missing expected message data */
#define MO_ETIME           79              /* STREAMS timeout occurred */
#define MO_ENOMSG          80              /* Unexpected message type */ 

#define	MO_ERRMAX		81


#endif

#endif

