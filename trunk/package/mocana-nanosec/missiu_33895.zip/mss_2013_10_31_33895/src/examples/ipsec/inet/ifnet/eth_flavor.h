#ifndef __FLAVOR_H__
#define __FLAVOR_H__

/* Map the build flavor into more meaningful constants internal
 * to the library.  The constant _FLAVOR_myflavor where myflavor is
 * the build flavor will be defined by the build environment.
 *
 * Be sure to check that a valid build flavor is defined.
 *
 * This file should be included by all source files.
*/

#if defined(_FLAVOR_gn)
#define ETH_MAXNUM_IF            NUM_IFS
#elif defined(_FLAVOR_gn1)
#define ETH_MAXNUM_IF            1
#elif defined(_FLAVOR_gn2)
#define ETH_MAXNUM_IF            2
#elif defined(_FLAVOR_gn3)
#define ETH_MAXNUM_IF            3
#elif defined(_FLAVOR_gn4)
#define ETH_MAXNUM_IF            4
#elif defined(_FLAVOR_gn5)
#define ETH_MAXNUM_IF            5
#elif defined(_FLAVOR_gn6)
#define ETH_MAXNUM_IF            6
#elif defined(_FLAVOR_gn7)
#define ETH_MAXNUM_IF            7
#elif defined(_FLAVOR_gn8)
#define ETH_MAXNUM_IF            8
#elif defined(_FLAVOR_gn9)
#define ETH_MAXNUM_IF            9
#elif defined(_FLAVOR_gn10)
#define ETH_MAXNUM_IF            10
#elif defined(_FLAVOR_gn11)
#define ETH_MAXNUM_IF            11
#elif defined(_FLAVOR_gn12)
#define ETH_MAXNUM_IF            12
#elif defined(_FLAVOR_gn13)
#define ETH_MAXNUM_IF            13
#elif defined(_FLAVOR_gn14)
#define ETH_MAXNUM_IF            14
#elif defined(_FLAVOR_gn15)
#define ETH_MAXNUM_IF            15
#elif defined(_FLAVOR_gn16)
#define ETH_MAXNUM_IF            16
#else
#  error Unknown Build Flavor
#endif

#endif
