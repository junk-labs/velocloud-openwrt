/*
 * pppcp.c
 *
 * PPP Control Protocol Core. This is composed of the automaton and of the common part of LCP and IPCP parsers.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "pppcp_defs.h"

/*****************************************************************************
 *
 * Global
 *
 *****************************************************************************/

PPPCP_DBG_VAR(DWORD g_dwPppCpDebugLevel = 1);

/*****************************************************************************
 *
 * Local Function Implementation
 *
 *****************************************************************************/




/*****************************************************************************
 *
 * API Function Implementation
 *
 *****************************************************************************/

/*
 * PppCpInitialize
 *   Initialize the pppcp library
 *
 *   Args:
 *
 *   Returns:
 *    >=0
 */
LONG PppCpInitialize(void)
{

  return 0;
}

/*
 * PppCpTerminate
 *   Terminate the pppcp library
 *
 *   Args:
 *
 *   Returns:
 *    >=0
 */
LONG PppCpTerminate(void)
{
  return 0;
}

/*
 * PppCpInstanceCreate
 *   Create a PppCpInstance
 *
 *   Args:
 *
 *   Returns:
 *     H_NETINSTANCE          Instance Handle
 */
H_NETINSTANCE PppCpInstanceCreate(void)
{
  PPPCPSTATE *pxCpState;

  pxCpState = (PPPCPSTATE *)calloc(1,sizeof(PPPCPSTATE));
  ASSERT(pxCpState != NULL);

  PPPCP_SET_COOKIE(pxCpState);
  pxCpState->dwTimerInitial = PPPCPDEFAULT_TIMER;
  pxCpState->oMaxConfigure = PPPCPDEFAULT_MAXCONF;
  pxCpState->oMaxTerminate = PPPCPDEFAULT_MAXTERM;

  memset(pxCpState->aoCurrRcvId,
         ((DWORD)pxCpState) & 0xFF,PPPCPCOMMAND_MAX*sizeof(OCTET));

  memset(pxCpState->aoCurrSndId,
         ((DWORD)pxCpState) & 0xFF,PPPCPCOMMAND_MAX*sizeof(OCTET));

  return (H_NETINSTANCE)pxCpState;
}
/*
 * PppCpInstanceDestroy
 *   Destroy a pppcp instance
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceDestroy(H_NETINSTANCE hPppCp)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  PPPCP_CHECK_STATE(pxCpState);

  if (pxCpState->poCurrOptions != NULL) {
    free(pxCpState->poCurrOptions);
  }

  /* Cleans Up event list */
  clear_DLLIST(&(pxCpState->xdllEvent), PppCpFreeEvent);

  PPPCP_SET_COOKIE(pxCpState);

  free(pxCpState);

  return 0;
}

/*
 * PppCpInstanceSet
 *   Set PPPCP options
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceSet(H_NETINSTANCE hPppCp,OCTET oOption,
                      H_NETDATA hData)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  PPPCP_CHECK_STATE(pxCpState);

  PPPCP_DBGP(NORMAL,"PppCpInstanceSet:hPppCp=%d,oOption=%s,hData=%d\n",
           (int)hPppCp,
           ((oOption >= NETOPTION_MODULESPECIFICBEGIN) ?
           apoPppCpOptionString[oOption - NETOPTION_MODULESPECIFICBEGIN]:
           apoNetOptionString[oOption]),
           (int)hData);

  switch(oOption) {
  case NETOPTION_FREE:
    pxCpState->pfnNetFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_MALLOC:
    pxCpState->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    pxCpState->pxNetMutex = (pthread_mutex_t *)hData;
    break;

  case NETOPTION_NETCBK:
    pxCpState->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case NETOPTION_NETCBKHINST:
    pxCpState->hNetInst = (H_NETINSTANCE)hData;
    break;

  case NETOPTION_OFFSET:
    pxCpState->wOffset = (WORD)( (DWORD)hData & 0xFFFF);
    break;

  case NETOPTION_TRAILER:
    pxCpState->wTrailer = (WORD)( (DWORD)hData & 0xFFFF);
    break;

  case PPPCPOPTION_TIMER:
    pxCpState->dwTimerInitial = (DWORD)hData;
    break;

  case PPPCPOPTION_MAXCONF:
    pxCpState->oMaxConfigure = (OCTET)hData;
    break;

  case PPPCPOPTION_MAXTERM:
    pxCpState->oMaxTerminate = (OCTET)hData;
    break;

  case PPPCPOPTION_IFIDX:
    pxCpState->oIfIdx = (OCTET)hData;
    break;

  case PPPCPOPTION_VLAN:
    pxCpState->wVlan = (OCTET)hData;
    break;


  default:
    ASSERT(0);
  }

  return NETERR_NOERR;
}

/*
 * PppCpInstanceMsg
 *   PPPCP msg function
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceMsg(H_NETINSTANCE hPppCp,OCTET oMsg,H_NETDATA hData)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  PPPCPEVENT xEvent;

  PPPCP_CHECK_STATE(pxCpState);

  ASSERT(pxCpState->pfnNetCbk != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceMsg:hPppCp=%d,oMsg=%s,hData=%d\n",
           (int)hPppCp,
           ((oMsg >= NETMSG_MODULESPECIFICBEGIN) ?
           apoPppCpMsgString[oMsg - NETMSG_MODULESPECIFICBEGIN]:
           apoNetMsgString[oMsg]),
           (int)hData);

  switch(oMsg) {
  case NETMSG_OPEN:
    xEvent.eType = PPPCPADMINEVENT_OPEN;
    xEvent.hData = hData;
    PppCpInstanceEvent(hPppCp,&xEvent);
    break;

  case NETMSG_CLOSE:
    xEvent.eType = PPPCPADMINEVENT_CLOSE;
    xEvent.hData = hData;
    PppCpInstanceEvent(hPppCp,&xEvent);
    break;

  case NETMSG_LOWERLAYERUP:
    xEvent.eType = PPPCPADMINEVENT_UP;
    xEvent.hData = hData;
    PppCpInstanceEvent(hPppCp,&xEvent);
    break;

  case NETMSG_LOWERLAYERDOWN:
    xEvent.eType = PPPCPADMINEVENT_DOWN;
    xEvent.hData = hData;
    PppCpInstanceEvent(hPppCp,&xEvent);
    break;

  case PPPCPMSG_PROTOCOLREJECT:
    {
      PPPCPPACKET *pxPacket = (PPPCPPACKET *)hData;
      PppCpInstanceSendCommand(hPppCp,PPPCPCOMMAND_PROTOCOLREJECT,
                               pxPacket->pxPacket->pxPayload->poPayload +
                               pxPacket->pxAccess->wOffset,
                               pxPacket->pxAccess->wLength);
      NETPAYLOAD_DELUSER(pxPacket->pxPacket->pxPayload);
    }
  break;

  case PPPCPMSG_ECHOREQUEST:
    {
      PppCpInstanceActionSer(hPppCp,0);
    }
  break;

  default:
    ASSERT(0);

  }

  pxCpState->pfnNetCbk(pxCpState->hNetInst,NETCBK_NEEDPROCESSING,0);

  return NETERR_NOERR;
}

/*
 * PppCpInstanceLLInterfaceCreate
 *   Create PPPCP LL interface
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE PppCpInstanceLLInterfaceCreate(H_NETINSTANCE hPppCp)
{
  return (H_NETINTERFACE)1;
}

/*
 * PppCpInstanceLLInterfaceDestroy
 *   Destroy PPPCP LL interface
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceLLInterfaceDestroy(H_NETINSTANCE hPppCp, H_NETINTERFACE hIf)
{
  ASSERT(hIf == (H_NETINTERFACE)1);

  return NETERR_NOERR;
}

/*
 * PppCpInstanceLLInterfaceIoctl
 *   PPPCP LL interface ioctl function
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceLLInterfaceIoctl(H_NETINSTANCE hPppCp, H_NETINTERFACE hIf,
                                    OCTET oIoctl,H_NETDATA hData)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT(hIf == (H_NETINTERFACE)1);

  ASSERT(pxCpState != NULL);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_SETHINST:
    pxCpState->hLl = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxCpState->pfnLlWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxCpState->hLlIf = (H_NETINTERFACE)hData;
    break;


  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    break;

  default:
    ASSERT(0);
  }

  return NETERR_NOERR;
}

/*
 * PppCpInstanceRcv
 *   PPP CP instance rcv
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            unused
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceRcv(H_NETINSTANCE hPppCp, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  OCTET oCommand;
  OCTET oIdentifier;
  WORD  wLength;
  OCTET *poPacketPointer;

  ASSERT(hIf == (H_NETINTERFACE)1);

  ASSERT(pxCpState != NULL);

  NETPACKET_CHECK(pxPacket);
  NETPAYLOAD_LOCK(pxPacket->pxPayload);
  ASSERT(pxCpState->pfnNetCbk != NULL);
  ASSERT(pxAccess != NULL);
  ASSERT((pxAccess->wOffset + pxAccess->wLength) <= pxPacket->pxPayload->wSize);

  poPacketPointer = pxPacket->pxPayload->poPayload + pxAccess->wOffset;
  wLength = pxAccess->wLength;

  oCommand = PPPCPGET_COMMAND(poPacketPointer);
  oIdentifier  = PPPCPGET_ID(poPacketPointer);
  wLength      = PPPCPGET_LENGTH(poPacketPointer);

  if((oCommand == 0) ||
     (oCommand >= PPPCPCOMMAND_MAX) ||
     (wLength > pxAccess->wLength)  ||
     (wLength < PPPCP_HLEN)){
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    ASSERT(0);
    return -1;
  }

  PPPCP_DBGP(NORMAL,"PppCpInstanceRcv:hPppCp=%d,Command=%s,oIdentifier=%d,wLength=%d\n",
            (int)hPppCp,apoPppCpCommandString[oCommand - 1],oIdentifier,wLength);

  PPPCP_DBG(XREPETITIVE,NetPrintPayload(poPacketPointer,wLength));

  if ((pxCpState->aoCurrRcvId[oCommand - 1] !=
       oIdentifier) || (pxCpState->eState != PPPCPSTATE_OPENED)) {
    /* If it is not a retransmission or we are not in the opened
       state. SB is this is enough to control retransmission ??? */
    /* Valid command */
    OCTET *poDataPointer =  (poPacketPointer + PPPCP_HLEN);
    PPPCPEVENT xEvent = {PPPCPEVENT_ENUMMAX,0};

    /* Update the corresponding Rcvd Identifier */
    pxCpState->aoCurrRcvId[oCommand - 1] = oIdentifier;


    switch(oCommand) {
    case PPPCPCOMMAND_CONFIGUREREQUEST:
      {
        PPPCPOPTIONFIELDS xOptions;

        xOptions.poReq = poDataPointer;
        xOptions.wReqLength= wLength - PPPCP_HLEN;
        xOptions.poRej = NULL;
        xOptions.wRejLength = 0;
        xOptions.poNak = NULL;
        xOptions.wNakLength = 0;
        if (pxCpState->pfnNetCbk(pxCpState->hNetInst,PPPCPCBK_RXCONFREQ,
                                 (H_NETDATA) &xOptions) < 0) {
          ASSERT(((xOptions.poNak != NULL) && (xOptions.wNakLength != 0)) ||
                 ((xOptions.poRej != NULL) && (xOptions.wRejLength != 0)));
          /* Does not accept the options */
          xEvent.eType = PPPCPPARSEEVENT_RCRMINUS;
          xOptions.poReq = NULL;
          xOptions.wReqLength= 0;
        }
        else {
          xEvent.eType = PPPCPPARSEEVENT_RCRPLUS;
          ASSERT((xOptions.poNak == NULL) &&
                 (xOptions.poRej == NULL) &&
                 (xOptions.wNakLength == 0) &&
                 (xOptions.wRejLength == 0));
          /* Copy the options away */
          xOptions.poReq = (OCTET *)malloc(xOptions.wReqLength);
          ASSERT(xOptions.poReq != NULL);
          memcpy(xOptions.poReq,poDataPointer,xOptions.wReqLength);
        }

        xEvent.hData = (H_NETDATA)&xOptions;
        PppCpInstanceEvent(hPppCp,&xEvent);

        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        NETPAYLOAD_UNLOCK(pxPacket->pxPayload);

      }
      break;

    case PPPCPCOMMAND_CONFIGUREACK:

      if (oIdentifier == pxCpState->aoCurrSndId[PPPCPCOMMAND_CONFIGUREREQUEST-PPPCPCOMMAND_CONFIGUREREQUEST]) {
        /* The Identifier matches the one of the last Configure-Request.
           More over, all the options field must be exactly the same. Being
           lazy Netizens, we don't check this !!! */
        xEvent.eType = PPPCPPARSEEVENT_RCA;

        PppCpInstanceEvent(hPppCp,&xEvent);

      }

      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
      break;

    case PPPCPCOMMAND_CONFIGURENAK:
    case PPPCPCOMMAND_CONFIGUREREJECT:

      if (oIdentifier == pxCpState->aoCurrSndId[PPPCPCOMMAND_CONFIGUREREQUEST-PPPCPCOMMAND_CONFIGUREREQUEST]) {
        PPPCPOPTIONFIELDS xOptions;
        OCTET oCbk;
        ASSERT(wLength >= PPPCP_HLEN);

        if (oCommand == PPPCPCOMMAND_CONFIGURENAK) {
          xOptions.poNak = poDataPointer;
          xOptions.wNakLength = wLength - PPPCP_HLEN;
          oCbk = PPPCPCBK_RXCONFNAK;
        }
        else {
          xOptions.poRej = poDataPointer;
          xOptions.wRejLength = wLength - PPPCP_HLEN;
          oCbk = PPPCPCBK_RXCONFREJ;
        }

        pxCpState->pfnNetCbk(pxCpState->hNetInst,oCbk,(H_NETDATA)&xOptions);

        xEvent.eType = PPPCPPARSEEVENT_RCN;

        PppCpInstanceEvent(hPppCp,&xEvent);

      }
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      NETPAYLOAD_UNLOCK(pxPacket->pxPayload);

      break;

    case PPPCPCOMMAND_TERMINATEREQUEST:
      xEvent.eType = PPPCPPARSEEVENT_RTR;
      xEvent.hData = (H_NETDATA)TRUE;
      PppCpInstanceEvent(hPppCp,&(xEvent));

      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
      break;

    case PPPCPCOMMAND_TERMINATEACK:
      /* don't even look at the data */
      xEvent.eType = PPPCPPARSEEVENT_RTA;
      PppCpInstanceEvent(hPppCp,&(xEvent));

      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
      break;

    case PPPCPCOMMAND_CODEREJECT:
      /* don't even look at the data */
      xEvent.eType = PPPCPPARSEEVENT_RXJPLUS;
      PppCpInstanceEvent(hPppCp,&(xEvent));

      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
      break;

    case PPPCPCOMMAND_PROTOCOLREJECT:
      /* don't even look at the data */
      xEvent.eType = PPPCPPARSEEVENT_RXJPLUS;
      PppCpInstanceEvent(hPppCp,&(xEvent));

      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
      break;

    default:
      {
        PPPCPPACKET xPacket;
        /* Unknown code */

        xPacket.pxPacket = pxPacket;
        xPacket.pxAccess = pxAccess;
        xPacket.hData    = hData;

        /* The callee will free the packet */
        NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
        NETPAYLOAD_ADDUSER(pxPacket->pxPayload);
        if (pxCpState->pfnNetCbk(pxCpState->hNetInst,PPPCPCBK_RXUNKNOWNCODE,
                                 (H_NETDATA) &xPacket) < 0) {
          xEvent.eType = PPPCPADMINEVENT_RUC;
          xEvent.hData = (H_NETDATA)&xPacket;
          PppCpInstanceEvent(hPppCp,&(xEvent));
        }
        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      }
    }
    /* Need processing */
    pxCpState->pfnNetCbk(pxCpState->hNetInst,NETCBK_NEEDPROCESSING,
                         0);

  }
  else {
    NETPAYLOAD_UNLOCK(pxPacket->pxPayload);
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);

  }

  return (LONG)pxAccess->wLength;
}

/*
 * PppCpInstanceProcess
 *   PPP CP processing function
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG PppCpInstanceProcess(H_NETINSTANCE hPppCp)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  DWORD dwCurrentTime;
  PPPCPEVENT *pxEvent;
  LONG lReturn = 0;

  PPPCP_CHECK_STATE(pxCpState);

  dwCurrentTime = NetGlobalTimerGet();

  /* Process Events*/
  DLLIST_head(&(pxCpState->xdllEvent));
  while ((pxEvent = DLLIST_remove(&(pxCpState->xdllEvent))) != NULL) {
    /* Process event will free the event */
    PPPCP_DBGP(REPETITIVE,"PppCpInstanceProcess:calling PppCpInstanceProcessEvent with event=%s,%ld remaining events\n",
               apoPppCpEventString[pxEvent->eType],DLLIST_count_inline(&pxCpState->xdllEvent));

    PppCpInstanceProcessEvent(hPppCp,pxEvent);
  }

  /* Process the Timer */
  if ((pxCpState->bTimer == TRUE) && (dwCurrentTime > pxCpState->dwTimer)) {
    /* Timer has expired */
    PPPCPEVENT xEvent;
    PPPCP_DBGP(REPETITIVE,"PppCpInstanceProcess:hPppCp=%d, timer has expired\n",(int)hPppCp);
    pxCpState->bTimer = FALSE;

    if (0 == pxCpState->dwCounter) {
      xEvent.eType =  PPPCPADMINEVENT_TOMINUS;
      xEvent.hData = TRUE;
    }
    else {
      xEvent.eType =  PPPCPADMINEVENT_TOPLUS;
      xEvent.hData = FALSE;
    }

    PppCpInstanceEvent(hPppCp,&xEvent);
  }

  if (pxCpState->bTimer == TRUE) {
    ASSERT(pxCpState->dwTimer >= dwCurrentTime);
    lReturn = pxCpState->dwTimer - dwCurrentTime;
  } else {
    /*TODO: what's happened when pxCpState->bTimer = FALSE ? */
    lReturn = 10;
  }

  return lReturn;
}





