/*
 * chapparser.h
 *
 * CHAP parsing library
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _CHAPPARSER_H_
#define _CHAPPARSER_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/
/*
 * CHAP parsing macros
 */
#define CHAP_HLEN 4

#define CHAPOFFSET_TYPE 0
#define CHAPGET_TYPE(poPacket) ((E_CHAPPACKETTYPE) (*poPacket + CHAPOFFSET_TYPE))
#define CHAPSET_TYPE(poPacket,eType) ((*(poPacket + CHAPOFFSET_TYPE)) = (OCTET) eType)

#define CHAPOFFSET_ID 1
#define CHAPGET_ID(poPacket) (*(poPacket + CHAPOFFSET_ID))
#define CHAPSET_ID(poPacket,oId) ((*(poPacket + CHAPOFFSET_ID)) = oId)

#define CHAPOFFSET_LENGTH 2
#define CHAPGET_LENGTH(poPacket) ntohs((*((WORD *)(poPacket + CHAPOFFSET_LENGTH))))
#define CHAPSET_LENGTH(poPacket,wLength) (*((WORD *)(poPacket + CHAPOFFSET_LENGTH)) = htons(wLength))

#define CHAPOFFSET_DATA 4
#define CHAPGET_DATAPOINTER(poPacket) (poPacket + CHAPOFFSET_DATA)

/* Reset to 0 the offset, as we start from the data pointer */
#define CHAPDATAOFFSET_VALUESIZE          0
#define CHAPDATAGET_VALUESIZE(poPacket) (*(poPacket + CHAPDATAOFFSET_VALUESIZE))
#define CHAPDATASET_VALUESIZE(poPacket,oSize) ((*(poPacket + CHAPDATAOFFSET_VALUESIZE) = oSize))

#define CHAPDATAOFFSET_VALUE 1
#define CHAPDATAGET_VALUEPOINTER(poPacket) (poPacket + CHAPDATAOFFSET_VALUE)


/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * CHAP packet types
 */
typedef enum {
  CHAPPACKETTYPE_CHALLENGE = 1,
  CHAPPACKETTYPE_RESPONSE,
  CHAPPACKETTYPE_SUCCESS,
  CHAPPACKETTYPE_FAILURE
} E_CHAPPACKETTYPE;


#endif /* #ifndef _CHAPPARSER_H_ */
