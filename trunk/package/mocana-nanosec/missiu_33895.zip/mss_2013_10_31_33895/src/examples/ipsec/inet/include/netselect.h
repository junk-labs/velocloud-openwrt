/* `fd_set' type and related macros, and `select'/`pselect' declarations.
   Copyright (C) 1996,97,98,99,2000,01,02 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

/* POSIX 1003.1g: 6.2 Select from File Descriptor Sets <sys/select.h>  */

#ifndef _SYS_NETSELECT_H
#define _SYS_NETSELECT_H	1


/* The fd_set member is required to be an array of longs.  */
typedef long int __mo_fd_mask;

/* Sometimes the fd_set member is assumed to have this type.  */
typedef __mo_fd_mask mo_fd_mask;



/* Number of descriptors that can fit in an `fd_set'.  */
#ifndef __SELECT_OPT_ON__
#define __MO_FD_SETSIZE            4096 
#else
#define __MO_FD_SETSIZE            1024
#endif

/* Maximum number of file descriptors in `fd_set'.  */
#define	MO_FD_SETSIZE		__MO_FD_SETSIZE





/* It's easier to assume 8-bit bytes than to get CHAR_BIT.  */
#define __MO_NFDBITS	(8 * sizeof (__mo_fd_mask))
#define	__MO_FDELT(d)	((d) / __MO_NFDBITS)
#define	__MO_FDMASK(d)	((__mo_fd_mask) 1 << ((d) % __MO_NFDBITS))

/* Number of bits per word of `fd_set' (some code assumes this is 32).  */
#define MO_NFDBITS		__MO_NFDBITS

/* fd_set for select and pselect.  */
typedef struct
  {
    /* XPG4.2 requires this member name.  Otherwise avoid the name
       from the global namespace.  */
#ifdef __USE_XOPEN
    __mo_fd_mask fds_bits[__MO_FD_SETSIZE * 16 / __MO_NFDBITS];
#define __FDS_BITS(set) ((set)->fds_bits)
#else
    __mo_fd_mask __fds_bits[__MO_FD_SETSIZE * 16 / __MO_NFDBITS];
#define __MO_FDS_BITS(set) ((set)->__fds_bits)
#endif
  } mo_fd_set;






#if 0
# define __MO_FD_ZERO(fdsp) \
  do {									      \
    int __d0, __d1;							      \
    __asm__ __volatile__ ("cld; rep; stosl"				      \
			  : "=c" (__d0), "=D" (__d1)			      \
			  : "a" (0), "0" (sizeof (mo_fd_set)		      \
					  / sizeof (__mo_fd_mask)),	      \
			    "1" (&__MO_FDS_BITS (fdsp)[0])		      \
			  : "memory");					      \
  } while (0)

# define __MO_FD_SET(fd, fdsp) \
  __asm__ __volatile__ ("btsl %1,%0"					      \
			: "=m" (__MO_FDS_BITS (fdsp)[__MO_FDELT (fd)])	      \
			: "r" (((int) (fd)) % __MO_NFDBITS)		      \
			: "cc","memory")
# define __MO_FD_CLR(fd, fdsp) \
  __asm__ __volatile__ ("btrl %1,%0"					      \
			: "=m" (__MO_FDS_BITS (fdsp)[__MO_FDELT (fd)])	      \
			: "r" (((int) (fd)) % __MO_NFDBITS)		      \
			: "cc","memory")
# define __MO_FD_ISSET(fd, fdsp) \
  (__extension__					      		      \
   ({register char __result;						      \
     __asm__ __volatile__ ("btl %1,%2 ; setcb %b0"			      \
			   : "=q" (__result)				      \
			   : "r" (((int) (fd)) % __MO_NFDBITS),		      \
			     "m" (__MO_FDS_BITS (fdsp)[__MO_FDELT (fd)])      \
			   : "cc");					      \
     __result; }))


#else /* NEW MACROS FOR POWERPC: MANOJ */
#define	__MO_FD_SET(d, set)	((set)->__fds_bits[__MO_FDELT(d)] |= __MO_FDMASK(d))
#define	__MO_FD_CLR(d, set)	((set)->__fds_bits[__MO_FDELT(d)] &= ~__MO_FDMASK(d))
#define	__MO_FD_ISSET(d, set)	(((set)->__fds_bits[__MO_FDELT(d)] & __MO_FDMASK(d)) != 0)
#define	__MO_FD_ZERO(set)  	((void) memset ((void *) (set), 0, sizeof (mo_fd_set)))
#endif






/* Access macros for `fd_set'.  */
#define	MO_FD_SET(fd, fdsetp)	__MO_FD_SET (fd, fdsetp)
#define	MO_FD_CLR(fd, fdsetp)	__MO_FD_CLR (fd, fdsetp)
#define	MO_FD_ISSET(fd, fdsetp)	__MO_FD_ISSET (fd, fdsetp)
#define	MO_FD_ZERO(fdsetp)	__MO_FD_ZERO (fdsetp)

/* Check the first NFDS descriptors each in READFDS (if not NULL) for read
   readiness, in WRITEFDS (if not NULL) for write readiness, and in EXCEPTFDS
   (if not NULL) for exceptional conditions.  If TIMEOUT is not NULL, time out
   after waiting the interval specified therein.  Returns the number of ready
   descriptors, or -1 for errors.  */
/*MOC_EXTERN int select (int __nfds, fd_set *__readfds,
//		   fd_set * __writefds,
//		   fd_set * __exceptfds,
//		   struct timeval * __timeout);
*/

#ifdef __USE_XOPEN2K
/* Same as above only that the TIMEOUT value is given with higher
   resolution and a sigmask which is been set temporarily.  This version
   should be used.  */
/*MOC_EXTERN int pselect (int __nfds, fd_set *__restrict __readfds,
//		    fd_set *__restrict __writefds,
//		    fd_set *__restrict __exceptfds,
//		    const struct timespec *__restrict __timeout,
//		    const __sigset_t *__restrict __sigmask) __THROW;
*/
#endif

#endif /* sys/select.h */
