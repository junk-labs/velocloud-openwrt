/*
 * cbufo.h
 *
 * provides general circular buffers of OCTETs
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _CBUFO_H
#define _CBUFO_H
/*
**  cbufo.h
**
**  provides general circular buffers of OCTETs, including:
**
**    CBUFO b;            declare b as a cbuf structure for OCTETs
**    AllocCBufo(b, s);        allocate the buffer of s OCTETs
**    FreeCBufo(b);        free the buffer
**    PutCBufo(b, v);        put value v into CBUFO b and advance fill point
**                 (and assert(!overflow))
**    GetCBufo(b, &v)        get next value from CBUFO b and advance drain
**                 point (and assert(!underflow))
**    PrimeCBufo(b, n, v);    prime the CBUFO b with n elements of value v
**                 (and assert(!overflow))
**    FillCBufo(b v);        fill the whole CBUFO b with value v
**    DrainCBufo(b, n);        drain n elements from the CBUFO b (and
**                 assert(!underflow))
**    EmptyCBufo(b);        empty the CBUFO b
**    CBufoEmpty(b)        return the amount of unused space in the CBUF b
**    CBufoFull(b)        return the amount of used space in the CBUF b
**    CheckCBufo(b)        check the integrity of the cbuf
**
**
**  See comments before each MACRO definition for a more complete
**  description of each one.
**
**
**  Example:
**
**    #include <stdio.h>
**    #include "cbufo.h"
**
**    CBUFO b;
**
**    void main(void)
**    {
**      int i, j;
**
**      AllocCBufo(b, 10);
**      FillCBufo(b, 'c');
**    while (CBufoFull(b) != 0) {
**      GetCBufo(b, &j);
**      printf(" %d", j);
**    }
**    printf("\n");
**      PrimeCBufo(b, 3, 0xCC);
**      for (i = 0; i < 20; i++) {
**      PutCBufo(b, i);
**      GetCBufo(b, &j);
**      printf(" put: %d, got: %d\n", i, j);
**      CheckCBufo(b);
**      }
**      printf("now %n used, %d unused\n", CBufoFull(b), CBufoEmpty(b));
**      DrainCBufo(b, 2);
**      printf("now %n used, %d unused\n", CBufoFull(b), CBufoEmpty(b));
**      EmptyCBufo(b);
**      printf("now %n used, %d unused\n", CBufoFull(b), CBufoEmpty(b));
**      ASSERT(b.pFill == b.pDrain);
**    CheckCBufo(b);
**      FreeCBufo(b);
**    }
**
** Copyright 1994 Integrated Information Technology, Inc. All rights reserved.
 * Copyright 2000 Netergy Networks, Inc.  All rights reserved.
**
**   29-jul-94  JK    Initial Version
**
*/
#include <stdlib.h>
#include "NNstyle.h"




/*---------------------------------------------------------------------------
 *  TYPEDEFS
 */
#define CBUFO                            \
   struct {                            \
     int nElements;    /* # elements in the buffer    */    \
     OCTET *pGuard1;    /* addr beginning guard        */    \
     OCTET *pBeg;    /* addr of 1st element        */    \
     OCTET *pEnd;    /* addr past last element    */    \
     OCTET *pGuard2;    /* addr end guard        */    \
     OCTET *pFill;    /* addr of fill point        */    \
     OCTET *pDrain;    /* addr of drain point        */    \
   }




/*---------------------------------------------------------------------------
 *  CONSTANTs
 */
#define CBUFO_WHOLE_BUF -1
#define CBUFO_INIT_FILL 0xFF



/*---------------------------------------------------------------------------
 *  MACROs
 */

/*
 * alloc the actual buffer space
 *
 * parms:    b    the CBUF for which to allocate the space
 *        s    # bytes to allocate (actually allocates
 *             9 more, 1 because a full buffer needs
 *              to keep pFill != pDrain, 8 more for
 *               a guard at either end)
 */
#define AllocCBufo(b, s)                        \
    do {                                \
      (b).pGuard1 = MALLOC((s) + 1 + 8);                \
      *((b).pGuard1) = 0xAA;                    \
      *((b).pGuard1 + 1) = 0xAA;                    \
      *((b).pGuard1 + 2) = 0xAA;                    \
      *((b).pGuard1 + 3) = 0xAA;                    \
      (b).pBeg = (b).pGuard1 + 4;                    \
      (b).pEnd = (b).pBeg + (s) + 1;                \
      (b).pGuard2 = (b).pEnd;                    \
      *((b).pGuard2) = 0xAA;                    \
      *((b).pGuard2 + 1) = 0xAA;                    \
      *((b).pGuard2 + 2) = 0xAA;                    \
      *((b).pGuard2 + 3) = 0xAA;                    \
      (b).nElements = (s);                        \
      (b).pFill = (b).pBeg;                        \
      while ((b).pFill < (b).pEnd)                    \
        *((b).pFill)++ = CBUFO_INIT_FILL;                \
      (b).pDrain = (b).pBeg;                    \
      (b).pFill = (b).pDrain;                    \
      ASSERT((b).pFill < (b).pEnd);                    \
    } while (0)




/*
 * free the allocated buffer
 *
 * parms:    b    the CBUF to init
 */
#define FreeCBufo(b)                            \
    do {                                \
      FREE((b).pGuard1);                        \
    } while (0)




/*
 * put another value into the CBUF
 *
 * parms:    b    the CBUF
 *        v    the value to place in the CBUF at the fill point
 */
#define PutCBufo(b, v)                            \
    do {                                \
      *((b).pFill)++ = (v);                        \
      if ((b).pFill >= (b).pEnd)                    \
        (b).pFill = (b).pFill - ((b).nElements + 1);        \
      ASSERT((b).pFill != (b).pDrain);    /* overflow!!!!    */    \
    } while (0)




/*
 * prime the CBUF b with n elements
 *
 * parms:    b    the CBUF
 *        n    the number of elements to add
 *        v    the value to prime with
 */
#define PrimeCBufo(b, n, v)                        \
    do {                                \
      int i;                            \
      for (i = 0; i < (n); i++)                    \
        PutCBufo((b), (v));                        \
    } while (0)




/*
 * fill the unused space in CBUF b with value v
 *
 * parms:    b    the CBUF
 *        v    the value to fill with
 */
#define FillCBufo(b, v)                            \
    do {                                \
      while  (CBufoEmpty(b) != 0)                    \
        PutCBufo((b), (v));                        \
    } while (0)





/*
 * get a value from the CBUF
 *
 * parms:    b    the CBUF
 *        pv    place to put the value
 */
#define GetCBufo(b, pv)                        \
    do {                                \
      ASSERT((b).pFill != (b).pDrain);    /* underflow!!!    */    \
      *(pv) = *((b).pDrain)++;                    \
      if ((b).pDrain >= (b).pEnd)                    \
        (b).pDrain = (b).pDrain - ((b).nElements + 1);        \
    } while (0)




/*
 * drain the CBUF b of n elements
 *
 * parms:    b    the CBUF
 *        n    the number of elements to remove
 */
#define DrainCBufo(b, n)                        \
    do {                                \
      int i, nTrash;                        \
      for (i = 0; i < (n); i++)                    \
        GetCBufo((b), &nTrash);                    \
      (void) nTrash;                        \
    } while (0)




/*
 * empty the CBUF b
 *
 * parms:    b    the CBUF
 */
#define EmptyCBufo(b)                            \
    do {                                \
      (b).pDrain = (b).pFill;                    \
    } while (0)






/*
 * return amount of unused space
 *
 * parms:    b    the CBUF
 */
#define CBufoEmpty(b)                            \
    (((b).pDrain > (b).pFill) ? ((b).pDrain - (b).pFill - 1) :    \
                    (((b).pEnd - (b).pFill) +        \
                     ((b).pDrain - (b).pBeg) - 1))






/*
 * return amount of used space
 *
 * parms:    b    the CBUF
 */
#define CBufoFull(b)                            \
    ((b).nElements - CBufoEmpty(b))





/*
 * check the buffer integrity
 *
 * parms:    b    the CBUF
 */
#define CheckCBufo(b)                            \
    do {                                \
      ASSERT((b).pFill < (b).pEnd);                    \
      ASSERT((b).pDrain < (b).pEnd);                \
      ASSERT((b).pFill >= (b).pBeg);                \
      ASSERT((b).pDrain >= (b).pBeg);                \
      ASSERT((b).pBeg == ((b).pGuard1 + 4));            \
      ASSERT(*((b).pGuard1 + 0) == 0xAA);                \
      ASSERT(*((b).pGuard1 + 1) == 0xAA);                \
      ASSERT(*((b).pGuard1 + 2) == 0xAA);                \
      ASSERT(*((b).pGuard1 + 3) == 0xAA);                \
      ASSERT((b).pEnd == (b).pGuard2);                \
      ASSERT(*((b).pGuard2 + 0) == 0xAA);                \
      ASSERT(*((b).pGuard2 + 1) == 0xAA);                \
      ASSERT(*((b).pGuard2 + 2) == 0xAA);                \
      ASSERT(*((b).pGuard2 + 3) == 0xAA);                \
      ASSERT((b).nElements == ((b).pEnd - (b).pBeg - 1));        \
    } while (0)


#endif
