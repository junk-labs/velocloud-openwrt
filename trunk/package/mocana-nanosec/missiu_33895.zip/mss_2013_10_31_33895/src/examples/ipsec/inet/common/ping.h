/*
 * ping .h
 *
 * NetPing local API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PING_H_
#define _PING_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * Number of the concurrent ping table
 */
#define   NETPINGTABLE_SIZE 10

/*****************************************************************************
 *
 * externs
 *
 *****************************************************************************/
MOC_EXTERN DWORD adwPingReplyIpAddrTable[NETPINGTABLE_SIZE];


#endif /* #ifndef _PING_H_ */






