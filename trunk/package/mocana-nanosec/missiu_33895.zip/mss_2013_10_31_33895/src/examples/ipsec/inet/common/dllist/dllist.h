#ifndef __DLLIST_H__
#define __DLLIST_H__

#if 0 
#include <NNstyle.h>
#include <stddef.h>
#endif

typedef struct DLLIST_ITEM {
  void *item;
  struct DLLIST_ITEM *prev;
  struct DLLIST_ITEM *next;
} DLLIST_ITEM;

#define DLLIST_ITEM_INITILIZER {NULL, NULL, NULL}


typedef struct DLLIST {
  DWORD	count;
  DLLIST_ITEM *cur;
  DLLIST_ITEM *head;
  DLLIST_ITEM *tail;
  DLLIST_ITEM *free;
} DLLIST;

#define DLLIST_INITIALIZER {0, NULL, NULL, NULL, NULL}

/*
 * Basic functions
 */

#define new_DLLIST() new_DLLIST_fl(__FILE__, __LINE__)
DLLIST *new_DLLIST_fl(char *pFile, int nLine);
#define del_DLLIST(pdll, pf) del_DLLIST_fl((pdll), (pf), __FILE__, __LINE__)
void del_DLLIST_fl(DLLIST *dllist, void (*free_item)(void *), 
		   char *pFile, int nLine);
#define reserve_free_items_DLLIST(pdll, n)                              \
          reserve_free_items_DLLIST_fl((pdll), (n), __FILE__, __LINE__)
void reserve_free_items_DLLIST_fl(DLLIST *pdllist, int n, 
                                  char *pFile, int nLine);
void init_DLLIST(DLLIST *pDLList);
#define clear_DLLIST(pdll, pf) clear_DLLIST_fl((pdll), (pf), __FILE__, __LINE__)
void clear_DLLIST_fl(DLLIST *pDLList, void (*free_item)(void *), 
                     char *pFile, int nLine);

#define DLLIST_append(pdll, pitem)					\
	  DLLIST_append_fl((pdll), (pitem), __FILE__, __LINE__)
void *DLLIST_append_fl(DLLIST *dllist, void *item, char *pFile, int nLine);
#define DLLIST_prepend(pdll, pitem)					\
	  DLLIST_prepend_fl((pdll), (pitem), __FILE__, __LINE__)
void *DLLIST_prepend_fl(DLLIST *dllist, void *item, char *pFile, int nLine);
#define DLLIST_insert_before(pdll, pitem) 				\
	  DLLIST_insert_before_fl((pdll), (pitem), __FILE__, __LINE__)
void *DLLIST_insert_before_fl(DLLIST *dllist, void *item, 
			      char *pFile, int nLine);
#define DLLIST_insert_after(pdll, pitem)				\
	  DLLIST_insert_after_fl((pdll), (pitem), __FILE__, __LINE__)
void *DLLIST_insert_after_fl(DLLIST *dllist, void *item, 
			     char *pFile, int nLine);

#define DLLIST_add_sorted(pdll, pitem, pf)				\
	  DLLIST_add_sorted_fl((pdll), (pitem), (pf), __FILE__, __LINE__)
void *DLLIST_add_sorted_fl(DLLIST *dllist, void *item, 
			   LONG (*sortfcn)(void *,void *), 
			   char *pFile, int nLine);
void DLLIST_sort( DLLIST *dllist, LONG (*sortfcn)(void *,void *));
void *DLLIST_find( DLLIST *dllist, void *pKey, LONG (*sortfcn)(void *,void *));

void DLLIST_head( DLLIST *dllist);
void DLLIST_tail( DLLIST *dllist);
void DLLIST_next( DLLIST *dllist);
void DLLIST_prev( DLLIST *dllist);
DWORD DLLIST_count( DLLIST *dllist);
#define DLLIST_count_inline(x) (((x)==NULL)?0:((x)->count))
void *DLLIST_read( DLLIST *dllist);
LONG DLLIST_cur_is_null( DLLIST *dllist);
void *DLLIST_remove(DLLIST *dllist);
void DLLIST_print( DLLIST *dllist, OCTET *prefixstr, void (*print_item)());
void DLLIST_copy(DLLIST *dllSrc, DLLIST *dllDst);

/*
 * ITEM-type functions
 */

#define new_DLLIST_ITEM(pdll) new_DLLIST_ITEM_fl((pdll), __FILE__, __LINE__)
DLLIST_ITEM *new_DLLIST_ITEM_fl(DLLIST *dllist, char *pFile, int nLine);
void del_DLLIST_ITEM( DLLIST *dllist, DLLIST_ITEM *dllitem);
#define new_DLLIST_WithItems(n, sz)					\
	  new_DLLIST_WithItems_fl((n), (sz), __FILE__, __LINE__)
DLLIST *new_DLLIST_WithItems_fl(ubyte4 n, ubyte4 sz, char *pFile, int nLine);

DLLIST_ITEM *DLLIST_append_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem);
DLLIST_ITEM *DLLIST_prepend_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem);
DLLIST_ITEM *DLLIST_insert_after_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem);
DLLIST_ITEM *DLLIST_insert_before_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem);
DLLIST_ITEM *DLLIST_read_ITEM(DLLIST *dllist);
DLLIST_ITEM *DLLIST_remove_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem);

#endif
