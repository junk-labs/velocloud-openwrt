/*
 * sahist.h.
 *
 * macros to implement Self-Adjusting Histograms
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __SAHIST_H__
#define __SAHIST_H__



/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

#include "NNstyle.h"


/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/



/********************************************************************
 *
 * Typedefs
 *
 ********************************************************************/

typedef struct {
  WORD wRangeShift;        /* bucket range is 2**wRangeShift */
  DWORD dwLimit;        /* current upper limit on values */
  DWORD adwBkt[8];        /* 8 buckets */
} SA_HIST8;



/********************************************************************
 *
 * Functional API
 *
 ********************************************************************/

MOC_EXTERN void SaHist8(SA_HIST8 *pHist8, DWORD dwValue);
MOC_EXTERN void SaHist8Clear(SA_HIST8 *pHist8);
MOC_EXTERN void SaHist8Report(SA_HIST8 *pHist8);


#endif    /* __SAHIST_H__ */


