
#if !defined(_VXWORKS) && !defined(_NO_NNOS)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <NNstyle.h>

#if defined(_LINUX) || defined(_SUNOS)
#  include <sys/uio.h>
#else
#  include <iovec.h>
#endif
#include <circbuf.h>

CIRC_BUF *new_CIRC_BUF(DWORD u32Size)
{
   CIRC_BUF *tmp;

   tmp = (CIRC_BUF *) MALLOC(sizeof(CIRC_BUF));
   MOC_MEMSET((ubyte *)tmp, 0, sizeof(CIRC_BUF));

   tmp->pBuf = (OCTET *) MALLOC((ubyte4) u32Size);
   tmp->dwSize = u32Size;

   return tmp;
}

void del_CIRC_BUF(CIRC_BUF *pCircBuf)
{
   FREE(pCircBuf->pBuf);
   FREE(pCircBuf);
}

LONG CIRC_BUF_space(CIRC_BUF *pCircBuf)
{
   LONG dwSpace;

   dwSpace = (pCircBuf->dwRead - pCircBuf->dwWrite) - 1;

   if (dwSpace < 0) {
      dwSpace += pCircBuf->dwSize;
   }

   return dwSpace;
}

LONG CIRC_BUF_filled(CIRC_BUF *pCircBuf)
{
   return ((pCircBuf->dwSize - 1) - CIRC_BUF_space(pCircBuf));
}

void
CIRC_BUF_updateptrs_wr(CIRC_BUF *pCircBuf, ubyte4 count)
{
   DWORD dwTmp;

   dwTmp = pCircBuf->dwWrite + (DWORD) count;
   if (dwTmp >= pCircBuf->dwSize) {
      pCircBuf->dwWrite = dwTmp - pCircBuf->dwSize;
   } else {
      pCircBuf->dwWrite = dwTmp;
   }
}

LONG CIRC_BUF_setupiov_wr(CIRC_BUF *pCircBuf, struct iovec *pIov, ubyte4 count)
{
   DWORD u32WrIndx = pCircBuf->dwWrite;
   DWORD u32RdIndx = pCircBuf->dwRead;
   ubyte4 i,j;

   for(i=0;i<count;i++) {
      pIov[i].iov_base = &(pCircBuf->pBuf[u32WrIndx]);
      if (u32WrIndx >= u32RdIndx) {
         if (u32RdIndx) {
            pIov[i].iov_len = (int) (pCircBuf->dwSize - u32WrIndx);
            u32WrIndx = 0;
         } else {
            pIov[i].iov_len = (int) ((pCircBuf->dwSize - u32WrIndx) - 1);
            u32WrIndx = pCircBuf->dwSize - 1;
         }
      } else {
         pIov[i].iov_len = (int) ((u32RdIndx - u32WrIndx) - 1);
         u32WrIndx += pIov[i].iov_len;
      }
      if (pIov[i].iov_len == 0) {
         i++;
         break;
      }
   }
   for(j=i;j<count;j++) {
      pIov[j].iov_base = &(pCircBuf->pBuf[u32WrIndx]);
      pIov[j].iov_len = 0;
   }
   return(i);
}

void
CIRC_BUF_updateptrs_rd(CIRC_BUF *pCircBuf, ubyte4 count)
{
   DWORD dwTmp;

   dwTmp = pCircBuf->dwRead + count;
   if (dwTmp >= pCircBuf->dwSize) {
      pCircBuf->dwRead = dwTmp - pCircBuf->dwSize;
   } else {
      pCircBuf->dwRead = dwTmp;
   }
}

LONG CIRC_BUF_setupiov_rd(CIRC_BUF *pCircBuf, struct iovec *pIov, ubyte4 count)
{
   DWORD u32RdIndx = pCircBuf->dwRead;
   DWORD u32WrIndx = pCircBuf->dwWrite;
   ubyte4 i,j;

   for(i=0;i<count;i++) {
      pIov[i].iov_base = &(pCircBuf->pBuf[u32RdIndx]);
      if (u32RdIndx > u32WrIndx) {
         pIov[i].iov_len = (int) (pCircBuf->dwSize - u32RdIndx);
         u32RdIndx = 0;
      } else {
         pIov[i].iov_len = (int) (u32WrIndx - u32RdIndx);
         u32RdIndx += pIov[i].iov_len;
      }
      if (pIov[i].iov_len == 0) {
         i++;
         break;
      }
   }
   for(j=i;j<count;j++) {
      pIov[j].iov_base = &(pCircBuf->pBuf[u32RdIndx]);
      pIov[j].iov_len = 0;
   }
   return(i);
}

LONG
CIRC_BUF_write(CIRC_BUF *pCircBuf, OCTET *pData, DWORD u32Len)
{
   struct iovec Iov[2];
   ubyte4 cnt = 2;
   ubyte4 i;
   DWORD u32Left;
   DWORD u32DataIndx;

   cnt = (ubyte4) (CIRC_BUF_setupiov_wr(pCircBuf, Iov, cnt));

   u32Left = u32Len;
   u32DataIndx = 0;

   for(i=0;i<cnt;i++) {
      if (u32Left <= Iov[i].iov_len) {
         MOC_MEMCPY((ubyte *)Iov[i].iov_base,(ubyte *)&pData[u32DataIndx],(ubyte4) u32Left);
         u32Left = 0;
         break;
      } else {
         MOC_MEMCPY((ubyte *)Iov[i].iov_base,(ubyte *)&pData[u32DataIndx],Iov[i].iov_len);
         u32Left -= Iov[i].iov_len;
         u32DataIndx += Iov[i].iov_len;
      }
   }
   CIRC_BUF_updateptrs_wr(pCircBuf, (ubyte4) (u32Len - u32Left));
#ifdef notdef
   {
      DWORD u32NextWriteIndx;
      u32NextWriteIndx = pCircBuf->dwWrite + (u32Len - u32Left);
      if (u32NextWriteIndx >= pCircBuf->dwSize) {
         pCircBuf->dwWrite = u32NextWriteIndx - pCircBuf->dwSize;
      } else {
         pCircBuf->dwWrite = u32NextWriteIndx;
      }
   }
#endif
   return (u32Len - u32Left);
}

LONG
CIRC_BUF_read(CIRC_BUF *pCircBuf, OCTET *pData, DWORD u32Len)
{
   struct iovec Iov[2];
   ubyte4 cnt = 2;
   ubyte4 i;
   DWORD u32Left;
   DWORD u32DataIndx;

   cnt = (ubyte4) (CIRC_BUF_setupiov_rd(pCircBuf, Iov, cnt));

   u32Left = u32Len;
   u32DataIndx = 0;

   for(i=0;i<cnt;i++) {
      if (u32Left <= Iov[i].iov_len) {
         MOC_MEMCPY((ubyte *)&pData[u32DataIndx],(ubyte *)Iov[i].iov_base,(ubyte4) u32Left);
         u32Left = 0;
         break;
      } else {
         MOC_MEMCPY((ubyte *)&pData[u32DataIndx],(ubyte *)Iov[i].iov_base,Iov[i].iov_len);
         u32Left -= Iov[i].iov_len;
         u32DataIndx += Iov[i].iov_len;
      }
   }
   CIRC_BUF_updateptrs_rd(pCircBuf, (ubyte4) (u32Len - u32Left));
#ifdef notdef
   {
      DWORD u32NextReadIndx;
      u32NextReadIndx = pCircBuf->dwRead + (u32Len - u32Left);
      if (u32NextReadIndx >= pCircBuf->dwSize) {
         pCircBuf->dwRead = u32NextReadIndx - pCircBuf->dwSize;
      } else {
         pCircBuf->dwRead = u32NextReadIndx;
      }
   }
#endif
   return (u32Len - u32Left);
}
#endif
