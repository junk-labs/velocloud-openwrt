/*
 * dhcp.h
 *
 * DHCP client internal header file
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef __DHCP_H__
#define __DHCP_H__

#include "dhcpclient.h"

/****************************************************************************
 *
 * Definitions
 *
 ****************************************************************************/
#define OP_SUBNET_MASK                      1
#define OP_UTC_TIME_OFFSET                  2
#define OP_GATEWAY                          3
#define OP_TIME_SERVER                      4
#define OP_NAME_SERVERS                     5
#define OP_DNS_SERVER                       6
#define OP_HOST_NAME                        12
#define OP_BOOT_FILE_SIZE                   13
#define OP_DOMAIN_NAME                      15
#define OP_IP_FORWARDING_ENABLE_DISABLE     19
#define OP_DEFAULT_IP_TIME_TO_LIVE          23
#define OP_ETHERNET_ENCAPSULATION           36
#define OP_NETWORK_TIME_PROTOCOL_SERVERS    42
#define OP_REQUEST_IP_ADDRESS               50
#define OP_LEASE                            51
#define OP_OPTION_OVERLOAD                  52
#define OP_DHCP_MESSAGE_TYPE                53
#define OP_SERVER_IDENTIFIER                54
#define OP_PARAMETER_REQUEST_LIST           55
#define OP_ERROR_MESSAGE_FROM_SERVER        56
#define OP_MAXIMUM_DHCP_MESSAGE_SIZE        57
#define OP_RENEWAL_T1_TIME                  58
#define OP_REBINDING_T2_TIME                59
#define OP_CLASS_IDENTIFIER                 60
#define OP_CLIENT_IDENTIFIER                61

#define DHCPCLIENT_CREATED            1
#define DHCPCLIENT_INIT_STAGE         2
#define DHCPCLIENT_DISCOVER_STAGE     3
#define DHCPCLIENT_REQUEST_STAGE      4
#define DHCPCLIENT_RENEWING_STAGE     5
#define DHCPCLIENT_REBINDING_STAGE    6
#define DHCPCLIENT_BOUND_STAGE        7

#define EHERNET_HTYPE                 1
#define EHERNET_HTYPE_LEN             6

#define BOOTREPQUEST                  1
#define BOOTREPLY                     2

#define DHCPSERVERPORT                67
#define DHCPCLIENTPORT                68

#define DHCPDISCOVER                  1
#define DHCPOFFER                     2
#define DHCPREQUEST                   3
#define DHCPDECLINE                   4
#define DHCPACK                       5
#define DHCPNAK                       6
#define DHCPRELEASE                   7

#define DHCP_PACKET_SIZE              sizeof(DHCP_PACKET)

#define MAX_CID_LEN                   32


/****************************************************************************
 *
 * Typedefs
 *
 ****************************************************************************/
typedef struct Dhcp_Packet{
  OCTET OP;
  OCTET HTYPE;
  OCTET HLEN;
  OCTET HOPS;
  DWORD XID;
  OCTET SECS[2];
  OCTET FLAGS[2];
  DWORD CIADDR;
  DWORD YIADDR;
  DWORD SIADDR;
  DWORD GIADDR;
  OCTET CHADDR[16];
  OCTET SNAME[64];
  OCTET FILE[128];
  OCTET OPTIONS[312];
} DHCP_PACKET;


typedef struct Dhcp_Client {
  LONG  lDhcpSock;            /* DHCP client socket */
  DWORD dwXID;                /* transaction id */
  DWORD dwDhcpServerIP;       /* DHCP server IP address */
  DWORD dwOfferedIP;          /* Offered IP address */
  DWORD dwLeaseDuration;      /* Offered Lease duration */
  DWORD dwLeaseStartTime;     /* Start time of lease */
  DWORD dwT1Timer;            /* T1 timer (~0.5*lease_duration) */
  DWORD dwT2Timer;            /* T2 timer (~0.875*lease_duration) */
  DWORD dwTransmitTime;       /* (re)transmit timer */
  OCTET oState;               /* Current client state */
  OCTET oRTXCount;            /* Retransmission counter */
  OCTET oIfIdx;               /* Interface on which client is open */
  OCTET poHardwareAddress[6]; /* MAC address */
#ifdef DHCP_CUSTOM_OPTIONS
  DLLIST *pdllCustomOptions;  /* list of "extra" client dhcp options */
#endif /*DHCP_CUSTOM_OPTIONS */
  char  *pcCustomClientId;    /* Custom client Id */
  DHCP_PACKET *pDhcpPacket;   /* Packet buffer for client */
} DHCPCLIENT;


#endif     /*__DHCP_H__*/












