/*
 * ip2eth_defs.h
 *
 * IP to Ethernet module (using ARP)
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "ip2eth_flavor.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "iptable.h"
#include "../include/socket.h"
#include "../include/in.h"
#include "netnetwork.h"
#include "arp.h"
#include "ethernet.h"
#include "ip.h"
#include "ip2eth.h"
#include "ip2eth_dbg.h"

/*****************************************************************************
 *
 * defines and macros
 *
 *****************************************************************************/

#define IPHDR_SOURCE_IPADDRESS_OFFSET 12
#define IPHDR_DEST_IPADDRESS_OFFSET   16

#ifdef IPFRAG
#define ARP_PENDING_PACKET_MAX  12 /* 16000 * 1.024 / 1400 , 16K/mss , roughly comes up to 12*/
#else
#define ARP_PENDING_PACKET_MAX 1
#endif

 /*****************************************************************************
 *
 * typedef
 *
 *****************************************************************************/

typedef struct {

  #ifndef NDEBUG
  DWORD dwMagicCookie;
  #endif
  /* ARP */
  H_NETINSTANCE hArp;
  H_NETINTERFACE hArpLL;
  H_NETINTERFACE hArpEthUL;

  PFN_NETMALLOC pfnNetMalloc;
  PFN_NETFREE   pfnNetFree;

  RTOS_MUTEX pxMutex;

  /* IP Interface (UL) */
  H_NETINSTANCE hIpInst;
  H_NETINTERFACE hIpIf;
  PFN_NETRXCBK pfnRxCbk;
  /* Ethernet interface (LL) */
  H_NETINSTANCE hEthInst;
  H_NETINTERFACE hEthIf;
  PFN_NETWRITE  pfnLLWrite;

  DLLIST dllPendingArp;

} IP2ETHSTATE;


typedef struct {
  DWORD dwDstIpAddr;
  NETPACKET xNetPacket;
  NETPACKETACCESS xNetPacketAccess;
  NETIFID xNetIfId;
} ARPPENDING;

