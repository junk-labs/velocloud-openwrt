
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcfg.h"
#include "setupnet.h"

/*
 * SetupNetGetIfDhcp
 *  Get whether interface is DHCP enabled or not
 *
 *  Args:
 *   oIfIdx               Interface index
 *
 *  Return:
 *   1 - DHCP enabled
 *   0 - DHCP disabled
 */
BOOL SetupNetGetIfDhcp(OCTET oIfIdx)
{
  DWORD dwStats = 0;
  SetupNetGetIfStatus(oIfIdx, &dwStats);
  return ((dwStats & IFF_DYNAMIC)?TRUE:FALSE);
}
