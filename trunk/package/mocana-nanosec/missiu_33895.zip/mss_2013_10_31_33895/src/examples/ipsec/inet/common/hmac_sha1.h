/*
 * hmac_sha1.h
 *
 * HMAC-SHA1 algorithm API.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _HMAC_SHA1_H_
#define _HMAC_SHA1_H_

/*****************************************************************************
 *
 * Function prototypes
 *
 *****************************************************************************/

/*****************************************************************************
 * hmac_sha1_ref (HMAC-SHA1 reference implementation)
 * Generate message digest using HMAC-SHA1 algorithm
 *   poText : pointer to data stream
 *   dwTextLen :length of data stream
 *   poKey : pointer to authentication key
 *   dwKeyLen : length of authentication key
 *   poDigest : pointer to caller digest to be filled in (should be allocated)
 *****************************************************************************/
void hmac_sha1_ref(OCTET* poText,
                   DWORD dwTextLen,
                   OCTET* poKey,
                   DWORD dwKeyLen,
                   OCTET* poDigest);

/*****************************************************************************
 * hmac_sha1 (HMAC-SHA1 fast implementation for T2 processor)
 * Generate message digest using HMAC-SHA1 algorithm
 *   poText : pointer to data stream
 *   dwTextLen :length of data stream
 *   poKey : pointer to authentication key
 *   dwKeyLen : length of authentication key
 *   poDigest : pointer to caller digest to be filled in (should be allocated)
 *****************************************************************************/
void hmac_sha1(OCTET* poText,
               DWORD dwTextLen,
               OCTET* poKey,
               DWORD dwKeyLen,
               OCTET* poDigest);

#endif
/* //////////////////////////////// End of File //////////////////////////////// */

