/*
 * snmp_arp.c
 *
 * SNMP access functions to the ARP table
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "arpdefs.h"
#include "snmp_tcpip_rtn.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/



/***************************************************************************
*    called from by SNMP Agent to retrieve an entire ARP table
*
*    par:    void **ppvData - area of memory for placing the table
*            DWORD *pdwNosStructs - dimension of array
*            DWORD *pdwStructSize - size of array element
*
*    ret:    DWORD - nos bytes in pValue
*
*    (see rfc1213)
****************************************************************************/
DWORD TcpipSnmpGetArpTable(void **ppvData, DWORD *pdwNosStructs, DWORD *pdwStructSize)
{
  extern ARPSTATE *pxArpInstance;
  struct ARP_TABLE_ENTRY *pxAt=NULL;
  ARPSTATE *pxArp;
  OCTET oIdx;
#ifndef ARP_CACHE_32
   ARPENTRYSTATE *pxArpEntry = NULL;
   ARPENTRYSTATE **ppxArpEntry = NULL;
#endif

  *ppvData = NULL;
  *pdwNosStructs = 0;
  /* Find the dimension of the array, and the size of each element */
  *pdwStructSize = sizeof(struct ARP_TABLE_ENTRY);
  pxArp = pxArpInstance;
#ifdef ARP_CACHE_32
  for (oIdx = 0; oIdx < pxArp->oArpTableSize; oIdx++) {
    if (pxArp->pxArpTable[oIdx].xEntry.dwIpAddr) {
#else
  for (oIdx = 0; oIdx < pxArp->wArpHashSize; oIdx++) {
    ppxArpEntry = &(pxArp->apxArpHashTable[oIdx]);
    ARP_DBG_ASSERT(ppxArpEntry != NULL);
    while(((pxArpEntry = *ppxArpEntry) != NULL)) {
#endif
        {
            void *pvTempData;

            pvTempData = MALLOC((*pdwNosStructs + 1) * (*pdwStructSize));

            ASSERT(pvTempData);

            MOC_MEMCPY((ubyte *)pvTempData, (ubyte *)*ppvData,
                (*pdwNosStructs) * (*pdwStructSize));
            FREE(*ppvData);
            *ppvData = pvTempData;
            ++(*pdwNosStructs);
        }
      /* Point to the correct element of the array */
      pxAt = ((struct ARP_TABLE_ENTRY *)(*ppvData))+(*pdwNosStructs)-1;
      /* Fill out structure */
#ifdef ARP_CACHE_32
      pxAt->dwIfNos = 1+(DWORD)(pxArp->pxArpTable[oIdx].xEntry.oIfIdx);
#else
      pxAt->dwIfNos = 1+(DWORD)(pxArpEntry->xEntry.oIfIdx);
#endif
      if (pxAt->dwIfNos > 1)
        pxAt->dwIfNos = 2;
#ifdef ARP_CACHE_32
      MOC_MEMCPY((ubyte *)pxAt->oMacAddr,
                (ubyte *) pxArp->pxArpTable[oIdx].xEntry.aoEthAddr,
                NET_ADDR_LEN);
      pxAt->dwIP = pxArp->pxArpTable[oIdx].xEntry.dwIpAddr;
    } else
      break;
#else
      MOC_MEMCPY((ubyte *)pxAt->oMacAddr,
                (ubyte *) pxArpEntry->xEntry.aoEthAddr,
                NET_ADDR_LEN);
      pxAt->dwIP = pxArpEntry->xEntry.dwIpAddr;
      ppxArpEntry = &pxArpEntry->pxNext;
    } /*End of while (((pxArpEntry = *ppxArpEntry) != NULL))*/
#endif
  } /*end of for loop*/
  return 0;
}



/***************************************************************************
 *    called from by SNMP Agent to retrieve an entire ipNetToMedia table
 *
 *    par:    void **ppvData - area of memory for placing the table
 *            DWORD *pdwNosStructs - dimension of array
 *            DWORD *pdwStructSize - size of array element
 *
 *    ret:    DWORD - nos bytes in pValue
 *
 *    (see rfc1213)
 ****************************************************************************/
DWORD
TcpipSnmpGetNetToMediaTable(void **ppvData, DWORD *pdwNosStructs, DWORD *pdwStructSize)
{
  extern ARPSTATE *pxArpInstance;
  struct NETTOMEDIA_TABLE_ENTRY *pxNet2MediaEntry=NULL;
  ARPSTATE *pxArp;
  OCTET oIdx;
#ifndef ARP_CACHE_32
   ARPENTRYSTATE *pxArpEntry = NULL, **ppxArpEntry = NULL;
#endif

  *ppvData = NULL;
  *pdwNosStructs = 0;

  /* Find the dimension of the array, and the size of each element */
  *pdwStructSize = sizeof(struct NETTOMEDIA_TABLE_ENTRY);
  pxArp = pxArpInstance;
#ifdef ARP_CACHE_32
  for (oIdx = 0; oIdx < pxArp->oArpTableSize; oIdx++) {
    if (pxArp->pxArpTable[oIdx].xEntry.dwIpAddr) {
#else
  for (oIdx = 0; oIdx < pxArp->wArpHashSize; oIdx++) {
    ppxArpEntry = &(pxArp->apxArpHashTable[oIdx]);
    ARP_DBG_ASSERT(ppxArpEntry != NULL);
    while(((pxArpEntry = *ppxArpEntry) != NULL)) {
#endif
        {
            void *pvTempData;

            pvTempData = MALLOC((*pdwNosStructs + 1) * (*pdwStructSize));

            ASSERT(pvTempData);

            MOC_MEMCPY((ubyte *)pvTempData, (ubyte *)*ppvData,
                (*pdwNosStructs) * (*pdwStructSize));
            FREE(*ppvData);
            *ppvData = pvTempData;
            ++(*pdwNosStructs);
        }
      /* Point to the correct element of the array */
      pxNet2MediaEntry = ((struct NETTOMEDIA_TABLE_ENTRY *)(*ppvData))+(*pdwNosStructs)-1;
      /* Fill out structure */
#ifdef ARP_CACHE_32
      pxNet2MediaEntry->dwIfIndex = 1+(DWORD)(pxArp->pxArpTable[oIdx].xEntry.oIfIdx);
#else
      pxNet2MediaEntry->dwIfIndex = 1 + (DWORD)(pxArpEntry->xEntry.oIfIdx);
#endif
      if (pxNet2MediaEntry->dwIfIndex > 1)
        pxNet2MediaEntry->dwIfIndex = 2;
#ifdef ARP_CACHE_32
      MOC_MEMCPY((ubyte *)pxNet2MediaEntry->oMacAddr,
             (ubyte *)pxArp->pxArpTable[oIdx].xEntry.aoEthAddr, NET_ADDR_LEN);
      pxNet2MediaEntry->dwIP = pxArp->pxArpTable[oIdx].xEntry.dwIpAddr;
#else
      MOC_MEMCPY((ubyte *)pxNet2MediaEntry->oMacAddr,
             (ubyte *)pxArpEntry->xEntry.aoEthAddr, NET_ADDR_LEN);
      pxNet2MediaEntry->dwIP = pxArpEntry->xEntry.dwIpAddr;
#endif
      pxNet2MediaEntry->dwType = MediaTypeDynamic;
#ifdef ARP_CACHE_32
    } else /*End of "if"*/
      break;
#else
      ppxArpEntry = &pxArpEntry->pxNext;
    } /*End of while (((pxArpEntry = *ppxArpEntry) != NULL))*/
#endif
  } /*end of for loop*/
  return 0;
}



/***************************************************************************
*    called from by SNMP Agent to set an entry in the ARP table
*
*    par:    DWORD *pArpTable - area of memory containing the ARP entry
*
*    ret:    DWORD - 1 for success, -1 for error
****************************************************************************/
DWORD TcpipSnmpAddArpTableEntry(DWORD dwIfNos, DWORD dwIP, OCTET *poMacAddr)
{
  extern ARPSTATE *pxArpInstance;
  ARPSTATE *pxArp;

  pxArp = pxArpInstance;
  if (1 == dwIfNos) {
    ARPENTRY xEntry;

    xEntry.dwIpAddr = dwIP;
    xEntry.wVlan = NETVLAN_ANY;
    xEntry.oIfIdx = NETIFIDX_ANY;
    MOC_MEMCPY((ubyte *)xEntry.aoEthAddr,(ubyte *)poMacAddr,ARP_ETHLEN);

    ArpAdd(pxArp, &xEntry);
  }
  return 0;
}



/***************************************************************************
 *    called from by SNMP Agent to set an entry in the ipNetToMedia table
 *
 *    par:    DWORD dwIfIndex  - Interface number of entry to add.
 *            OCTET *poMacAddr - Mac address of entry
 *            DWORD dwIP       - IP address of entry
 *
 *    ret:    DWORD - 1 for success, -1 for error
 ****************************************************************************/
DWORD TcpipSnmpAddipNetToMediaTableEntry(DWORD dwIfIndex, OCTET *poMacAddr, DWORD dwIP)
{
  return TcpipSnmpAddArpTableEntry(dwIfIndex, dwIP, poMacAddr);
}
