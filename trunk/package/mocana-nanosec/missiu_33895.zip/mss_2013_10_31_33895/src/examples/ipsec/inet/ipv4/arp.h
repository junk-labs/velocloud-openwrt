/*
 * arp.h
 *
 * ARP module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ARP_H_
#define _ARP_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/
/*
 * ARP field sizes in bytes
 */
#define ARP_HRDLEN        6
#define ARP_OPLEN         2
#define ARP_ETHLEN        6
#define ARP_IPLEN         4
#define ARP_TOTALLEN      (ARP_HRDLEN+ARP_OPLEN+(ARP_ETHLEN*2)+(ARP_IPLEN*2))

/*
 * ARP operation codes
 */
#define ARPOP_ARPREQUEST  1
#define ARPOP_ARPREPLY    2
#define ARPOP_RARPREQUEST 3
#define ARPOP_RARPREPLY   4

/*
 * ARP options defaults
 */
#define ARPDEFAULT_OFFSET          0
#define ARPDEFAULT_PAD             0
#ifdef ARP_CACHE_32
#define ARPDEFAULT_MAXENTRIES      32
#else
#define ARP_CACHE_TABLE_SIZE       256  /*Hash done with "value" - 1 */
#endif

/*
 * ARP specific return codes
 */
#define ARPRCODE_RESOLVING 1    /* ARP is resolving the IP address. Returned
                                   by ArpInstanceMsg when it can't resolve an
                                   IP address immediately */

/*
 * ARP specific error codes
 */
#define NETERR_ARPREQUESTQUEUEFULL \
  NETERR_MODULESPECIFICBEGIN       /* ARP has no more space in its request queue
                                    */
#define NETERR_ARPSENDREQUESTFAILED \
  (NETERR_MODULESPECIFICBEGIN -1)  /* ARP could not send a request */

/*
 * ARP specific message
 */
#define ARPMSG_RESOLVE   \
  NETMSG_MODULESPECIFICBEGIN  /* Resolve an IP address into a ethernet
                                 address. Data is (ARPREQUEST*).
                                 If immediately available, fills up the
                                 structure and returns NET_OK. If a request
                                 must be sent, return ARPRCODE_RESOLVING;
                                 The Eth addr will be provided through
                                 ARPCBK_RESOLVED callback, or a
                                 ARPCBK_FAILURE will be issued */
#define ARPMSG_ADD \
  (NETMSG_MODULESPECIFICBEGIN + 1) /* Add an ARP entry to the table
                                      Data is (ARPENTRY*) */

#define ARPMSG_REACQUIRE \
  (NETMSG_MODULESPECIFICBEGIN + 2) /* Reacquire an ARP address before it is
                                      actually removed from the ARP table */
#ifdef __MOC_CLI__
#define ARPMSG_CLI_SHOW \
  (NETMSG_MODULESPECIFICBEGIN + 3) /* Fill the appropriate values within Arp module
                                      to be given back to the CLI module for display */
#endif

/*
 * ARP specific network module callback
 *  From ARP to the wrapper.
 */
#define ARPCBK_RESOLVED \
  (NETCBK_MODULESPECIFICBEGIN)  /* An IP address has been successfully
                                   resolved in a Eth address. Data
                                   is (ARPREQUEST*) */
#define ARPCBK_FAILURE \
  (NETCBK_MODULESPECIFICBEGIN + 1) /* Can't resolve the IP address
                                      data is (ARPREQUEST*), the arp_pa
                                      member indicating which IP address
                                      can't be resolved */
#define ARPCBK_MAX \
  (NETCBK_MODULESPECIFICBEGIN + 2)

/*
 * ARP Instance Options
 */
#define ARPOPTION_CACHESIZE \
  (NETOPTION_MODULESPECIFICBEGIN)/* size of the ARP cache (in entry number).
                                    Data is OCTET. Can only be set once,
                                    before the OPEN message*/
#define ARPOPTION_ETHADDRESS \
  (NETOPTION_MODULESPECIFICBEGIN + 1) /* Set the ethernet address/interface
                                         for arp Data is (ARPETHDATA*) */
#define ARPOPTION_MAX \
  (NETOPTION_MODULESPECIFICBEGIN + 2)

/*
 * Arp LL Ioctls
 *  o All Ioctls are covered in netcommon.h
 */
#define ARPLLINTERFACEIOCTL_SETRARPIF  \
     (NETINTERFACEIOCTL_MODULESPECIFICBEGIN) /* Set the RARP LL hIf */
#define ARPLLINTERFACEIOCTL_MAX \
     (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 1)

/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/
/*
 * ARP Flags
 */
typedef enum{
  E_ARPBROADCAST = 0,
  E_ARPLOCAL,
  E_ARPDYNAMIC,
  E_ARPSTATIC
} ARPENTRYFLAG;

/*
 * ARP entry structure
 */
typedef struct arp_entry {
  DWORD dwIpAddr;
  OCTET aoEthAddr[ARP_ETHLEN];
  WORD wVlan;
  OCTET oIfIdx;
  ARPENTRYFLAG eArpFlag;
} ARPENTRY;

/*
 * ARP request structures
 */
typedef struct arp_request {
  ARPENTRY xEntry;
  E_ADDRTYPE eAddrType;
  DWORD dwGatewayAddr;
} ARPREQUEST;

/*
 * ARP_ETHDATA structure
 */
typedef struct arp_ethdata {
  OCTET aoEthAddr[ARP_ETHLEN];
  OCTET oIfIdx;
} ARPETHDATA;

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * ArpInitialize
 *  Initialize the ARP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG ArpInitialize(void);

/*
 * ArpTerminate
 *  Terminate the ARP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG ArpTerminate(void);

/*
 * ArpInstanceCreate
 *  Creates a ARP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE ArpInstanceCreate(void);

/*
 * ArpInstanceDestroy
 *  Destroy a ARP Instance
 *
 *  Args:
 *   hArp                       ARP instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG ArpInstanceDestroy(H_NETINSTANCE hArp);

/*
 * ArpInstanceSet
 *  Set a ARP Instance Option
 *
 *  Args:
 *   hArp                       ARP instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG ArpInstanceSet(H_NETINSTANCE hArp,OCTET oOption,
                    H_NETDATA hData);

/*
 * ArpInstanceQuery
 *  Query a ARP Instance Option
 *
 *  Args:
 *   hArp                       ARP instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG ArpInstanceQuery(H_NETINSTANCE hArp,OCTET oOption,
                      H_NETDATA *phData);

/*
 * ArpInstanceMsg
 *  Send a msg to a ARP instance
 *
 *  Args:
 *   hArp                       ARP instance
 *   oMsg                       Msg. See netcommon.h and arp.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG ArpInstanceMsg(H_NETINSTANCE hArp,OCTET oMsg,
                    H_NETDATA hData);

/*
 * ArpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hArp                       ARP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE ArpInstanceLLInterfaceCreate(H_NETINSTANCE hArp);

/*
 * ArpInstanceLLInterfaceDestroy
 *  Destroy a ARP LL interface
 *
 *  Args:
 *   hArp                       ARP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG ArpInstanceLLInterfaceDestroy(H_NETINSTANCE hArp,
                                   H_NETINTERFACE hInterface);


/*
 * ArpInstanceLLInterfaceIoctl
 *  ARP LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and netransport.h
 *  for precisions
 *
 *  Args:
 *   hArp                         Arp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG ArpInstanceLLInterfaceIoctl(H_NETINSTANCE hArp,
                                H_NETINTERFACE hLLInterface,
                                OCTET oIoctl,
                                H_NETDATA hData);


/*
 * ArpInstanceRcv
 *  Arp Instance Rcv function
 *   Follows PFN_NETRXCBK def.
 *
 *   Args:
 *    hArp                       Instance Handle
 *    hIf                        LL interface handle as provided by
 *                               ArpInstanceLLInterfaceCreate
 *    pxPacket                   packet
 *    pxAccess                   NETPACKETACCESS pointer
 *    hData                      ETHID pointer
 *
 *   Return:
 *    Number of bytes received or a <0 error code
 */
LONG ArpInstanceRcv(H_NETINSTANCE hArp,
            H_NETINTERFACE hIf,
            NETPACKET *pxPacket,
            NETPACKETACCESS *pxAccess,
            H_NETDATA hData);


/*
 * ArpInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hArp                        Arp Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 5 ms)
 */
LONG ArpInstanceProcess(H_NETINSTANCE hArp);

#endif /* #ifndef _ARP_H_ */







