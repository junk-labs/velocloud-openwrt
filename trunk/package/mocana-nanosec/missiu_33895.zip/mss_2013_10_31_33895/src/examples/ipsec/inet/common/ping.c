/*
 * ping.c
 *
 * A wrapper for PING functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/if_types.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "routing_table.h"
#include "iptable.h"
#include "netnetwork.h"
#include "netconfig.h"
#include "icmp.h"
#include "netmain.h"
#include "netdefs.h"
#include "ping.h"


/****************************************************************************
 *
 * Defines
 *
 ****************************************************************************/

/*
 * ping icmp payload size
 */
#define   NETPINGPAYLOADLENGTH 100


/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/
DWORD adwPingReplyIpAddrTable[NETPINGTABLE_SIZE] = {
  0,0,0,0,0,0,0,0,0,0
};

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * NetPing
 *  Ping RemoteIP from LocalIP
 *
 * Arg:
 *  dwLocalIP                      Local IP address of the host.
 *                                 If zero, first default IP address entry
 *                                 is used. If that is also zero, error is
 *                                 returned.
 *  dwRemoteIP                     Remote IP address of the remote host which
 *                                 is ping-ed
 *
 * Return :
 *  0 or more: successful connection number
 */
LONG NetPing(DWORD dwLocalIP, DWORD dwRemoteIP)
{
  H_NETINSTANCE hIcmpInst;
  ICMPMSGDATA xIcmpMsgData;
  NETPACKET xNetPacket;
  NETPACKETACCESS xNetPacketAccess;
  ROUTEENTRY xRoute;
  OCTET *poPayload;
  LONG iRv;


  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#ifdef _RADIX_ROUTING_ON_
  xRoute.xRouteNodes->RadixNodeKey  = dwRemoteIP;
  xRoute.xRouteNodes->RadixNodeMask = 0;
#else
  xRoute.dwDstAddr = dwRemoteIP;
#endif
  xRoute.wVlan = NETVLAN_ANY;
  xRoute.oIfIdx = NETIFIDX_ANY;
  xRoute.eDstAddrType = IPADDRT_UNKNOWN;

  if (RoutingTableMsg(ROUTINGTABLEMSG_FINDROUTE,(H_NETDATA)&xRoute) < 0) {
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return NETERR_UNKNOWN;
  }
  else {
    NETMAIN_ASSERT(xRoute.oIfIdx != NETIFIDX_ANY);

    if (dwLocalIP == 0) {
      if ((xNetWrapper.pxIfConf[xRoute.oIfIdx].oFlags & (IFF_UP | IFF_IPUP))
          != (IFF_UP | IFF_IPUP)) {
        /* Early return: local IP is not set */
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return NETERR_UNKNOWN;
      }
      dwLocalIP =xNetWrapper.pxIfConf[xRoute.oIfIdx].pxIPAlias[0].dwAddr;
    }

    /*Find out the icmp instance*/
    hIcmpInst = NETGETINST_ICMP;

    /*Fill the ICMPMSGDATA structure*/
    xIcmpMsgData.pxNetPacket       = &xNetPacket;
    xIcmpMsgData.pxNetPacketAccess = &xNetPacketAccess;
    xIcmpMsgData.dwDstAddr         = dwRemoteIP;
    xIcmpMsgData.dwSrcAddr         = dwLocalIP;
    xIcmpMsgData.wVlan             = xRoute.wVlan;
    xIcmpMsgData.oIfIdx            = xRoute.oIfIdx;

    /*payload memory allocation */
#ifdef __INET_USE_PAYLOAD_MEMPOOL__
     iRv = NetAllocPayload(&poPayload,NETPINGPAYLOADLENGTH);
     if (OK > iRv)
     {
         RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
         return -1;
     }
#else
    poPayload = (OCTET*) MALLOC(NETPINGPAYLOADLENGTH);
#endif
    ASSERT(poPayload != NULL);
    /*MOC_MEMSET((ubyte *)poPayload,0xFF,NETPINGPAYLOADLENGTH);*/

    NETPAYLOAD_CREATE(&xNetPacket.pxPayload,
                      NetFree,
                      &xNetWrapper.xMutex,
                      poPayload,
                      NETPINGPAYLOADLENGTH);

    if(NULL == xNetPacket.pxPayload)
    {
        LONG lRv = NETERR_MEM;
        DEBUG_ERROR(DEBUG_MOC_IPV4, "Error:NetPing - NETPAYLOAD_CREATE failed : %d",lRv);
        NetFree(poPayload);
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return lRv;
    }


    /*Fill the NETPACKETACCESS structure*/
    xNetPacketAccess.wOffset = 0;
    xNetPacketAccess.wLength = NETPINGPAYLOADLENGTH;

    (LONG)IcmpInstanceMsg(hIcmpInst,ICMPMSG_SENDECHO,
                          (H_NETDATA)&xIcmpMsgData);
  }

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return 0;
}


/*
 * NetPingStat
 *  Check Status on Ping request (from LocalIP to RemoteIP)
 *
 * Args:
 *  dwLocalIP                    Local IP address of the host. If zero,
 *                               first default IP address entry is used.
 *                               If that is also zero, error is returned.
 *  dwRemoteIP                   Remote IP address of the remote host which
 *                               is ping-ed
 *
 * Return:
 *  0 : ping failed
 *  1 : ping success
 */
LONG NetPingStat(DWORD dwLocalIP,DWORD dwRemoteIP)
{
  int i;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  /* Look through ping reply table for IP address */
  for (i = 0; i < NETPINGTABLE_SIZE; i++) {
    if (adwPingReplyIpAddrTable[i] == dwRemoteIP) {
      /* We've had a echo reply from this user. Clear the entry, so another
       * IP's reply can use it. */
      adwPingReplyIpAddrTable[i] = 0;
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return 1;
    }
  }

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return 0;
}

