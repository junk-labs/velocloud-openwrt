/*
 * syscalls.c
 *
 * Provides functions for basics system calls (open/close/ioctl) API.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"

#ifdef IPSEC
#include "ipsec.h"
#if 0 /* IPSEC is not configed by us */
#include "ipsec_api.h"
#endif
#endif /* IPSEC */

#ifdef SOCK_RT
  #include "router.h"
  #include "nat.h"
#endif

#ifdef SOCK_BR
  #include "ethernet.h"
#endif

/****************************************************************************
 *
 * Debug
 *
 ****************************************************************************/


/****************************************************************************
 *
 * Global variable
 *
 ****************************************************************************/

struct device_fops fops_demux[MAX_DEVICE_FOPS];

/****************************************************************************
 *
 * Local functions
 *
 ****************************************************************************/

/****************************************************************************
  open functions based upon name and returns a fd from the right function
  like SocketOpen or EthDrv_Open.
  We map the fd to a Fops This we can do either by FD space mapping
  i.e fd from 10 to 20000000 coudl be Socket FD and from 2000001 to X
  could be ETh Driver Fd and then when close/ioctl/read / write are
  called on these FD we simple get the right Fops and call the relevant Fn

 ****************************************************************************/

int register_chrdev(int major, char *name,struct file_operations *fops) {

  int iReturn = 0,i;
  for ( i =0; i< MAX_DEVICE_FOPS;i++)
  {
    if (!(fops_demux[i].occupied))
    {
        MOC_STRCBCPY(fops_demux[i].device_name, MOC_STRLEN(name)+1, name);
        fops_demux[i].occupied = 1;
        fops_demux[i].fops  = fops ;
        fops_demux[i].inode = MALLOC(sizeof(INODE));
        if (!fops_demux[i].inode)
            return MO_ENOMEM;
        fops_demux[i].pFile = MALLOC(sizeof(struct file));
        if (!fops_demux[i].pFile)
            return MO_ENOMEM;

        fops_demux[i].inode->private_data = MALLOC(strlen(name) + 1);
        if (NULL == fops_demux[i].inode->private_data)
            return MO_ENOMEM;
        MOC_STRCBCPY(fops_demux[i].inode->private_data, MOC_STRLEN(name) + 1, name);
    if (DEVICE_MAJOR_SCK == major)
        fops_demux[i].fd_mask = SCK_DEV_FD_BIT;
    if (DEVICE_MAJOR_ETHIF == major)
        fops_demux[i].fd_mask = ETH_DEV_FD_BIT;
        break;
    }
  }

  if (MAX_DEVICE_FOPS == i)
      return -1;

  return iReturn;
}

int mn_open (char *name, int mode)
{

  int iReturn = 0,i;
  for (i =0; i< MAX_DEVICE_FOPS;i++)
  {
      if ((fops_demux[i].occupied))
      {
          if (!(MOC_STRNICMP(fops_demux[i].device_name,name,MOC_STRLEN(name))))
      {
              return fops_demux[i].fops->open(fops_demux[i].inode,
                          fops_demux[i].pFile);
      }
      }
  }

  return -1;
}


LONG mn_ioctl(int ifd, DWORD dwRequest, mnIoctlArgList_t *pMnArgList)
{
  int iReturn = 0,i;
  struct file fl;

  for (i =0; i< MAX_DEVICE_FOPS;i++)
  {
      if ((fops_demux[i].occupied))
      {
      if (fops_demux[i].fd_mask == (ifd & DEV_FD_MASK))
      {


              if  (ETH_DEV_FD_BIT > ifd )
                  fl.private_data = (void *)ifd;
              else
              fl.private_data = fops_demux[i].pFile->private_data ;
              iReturn = fops_demux[i].fops->ioctl(fops_demux[i].inode,
                          &fl,
                          dwRequest, (pMnArgList));
          return iReturn;
      }
      }

  }

  return -1;
}

LONG mn_write(int ifd, OCTET * data, DWORD len)
{
  int iReturn = 0,i;
  struct file fl;

  for (i =0; i< MAX_DEVICE_FOPS;i++)
  {
      if ((fops_demux[i].occupied))
      {
      if (fops_demux[i].fd_mask == (ifd & DEV_FD_MASK))
      {
          /* RS added following two lines */
              if  (ETH_DEV_FD_BIT > ifd )
                  fl.private_data = (void *)ifd;
              else
              fl.private_data = fops_demux[i].pFile->private_data ;
              iReturn = fops_demux[i].fops->write(fops_demux[i].inode,
                          &fl,
                          data,len);
          return iReturn;
      }
      }

  }
  return -1;
}

LONG mn_read(int ifd, OCTET * data, DWORD len)
{
  int iReturn = 0,i;
  struct file fl;

  for (i =0; i< MAX_DEVICE_FOPS;i++)
  {
      if ((fops_demux[i].occupied))
      {
      if (fops_demux[i].fd_mask == (ifd & DEV_FD_MASK))
      {
          /* RS added following two lines */
              if  (ETH_DEV_FD_BIT > ifd )
                  fl.private_data = (void *)ifd;
              else
              fl.private_data = fops_demux[i].pFile->private_data ;
              iReturn = fops_demux[i].fops->read(fops_demux[i].inode,
                          &fl,
                          data,len);
          return iReturn;
      }
      }

  }
  return -1;
}

LONG mn_close(int ifd)
{
  int iReturn = 0,i;
  struct file fl;

  for (i =0; i< MAX_DEVICE_FOPS;i++)
  {
      if ((fops_demux[i].occupied))
      {
      if (fops_demux[i].fd_mask == (ifd & DEV_FD_MASK))
      {
              if  (ETH_DEV_FD_BIT > ifd )
                  fl.private_data = (void *)ifd;
              else
              fl.private_data = fops_demux[i].pFile->private_data ;
              iReturn = fops_demux[i].fops->close(fops_demux[i].inode,
                          &fl
                          );
          return iReturn;
      }
      }

  }
  return -1;
}
