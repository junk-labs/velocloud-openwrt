/*
 * ip1ton.c
 *
 * Implements the Ip1toN module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/

#include "ip1ton_defs.h"

/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/

IP1TON_DBG_VAR(DWORD g_dwIp1toNDebugLevel = REPETITIVE);

/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/


/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * Ip1toNInitialize
 *  Initialize the Ip1toN library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG Ip1toNInitialize(void)
{
  /* Initialise the debug to ERRROR */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_IP1TON, INET_DBG_LEVEL_ERROR);
  return NETERR_NOERR;
}

/*
 * Ip1toNTerminate
 *  Terminate the Ip1toN library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG Ip1toNTerminate(void)
{
  return NETERR_NOERR;
}


/*
 * Ip1toNInstanceCreate
 *  Creates a Ip1toN Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE Ip1toNInstanceCreate(void)
{
  IP1TONSTATE *pxIp1toN;

  /*Allocate memory for the the ip fragmentation state*/
  pxIp1toN = (IP1TONSTATE *)MALLOC(sizeof(IP1TONSTATE));
  ASSERT(pxIp1toN != NULL);
  MOC_MEMSET((ubyte *)pxIp1toN, 0, sizeof(IP1TONSTATE));

  /*set the magic cookie*/
  IP1TON_SET_COOKIE(pxIp1toN);

  return (H_NETINSTANCE)pxIp1toN;
}

/*
 * Ip1toNInstanceDestroy
 *  Destroy a Ip1toN Instance
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip1toNInstanceDestroy(H_NETINSTANCE hIp1toN)
{
  IP1TONSTATE *pxIp1toN = (IP1TONSTATE *)hIp1toN;
  IP1TON_CHECK_STATE(pxIp1toN);

  IP1TON_UNSET_COOKIE(pxIp1toN);

  if(pxIp1toN->pxLl != NULL){
    FREE(pxIp1toN->pxLl);
  }

  FREE(pxIp1toN);

  return 0;
}

/*
 * Ip1toNInstanceSet
 *  Set a Ip1toN Instance Option
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */

LONG Ip1toNInstanceSet(H_NETINSTANCE hIp1toN,
                       OCTET oOption,
                       H_NETDATA hData)
{
  return NETERR_NOERR;
}

/*
 * Ip1toNInstanceQuery
 *  Query a Ip1toN Instance Option
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip1toNInstanceQuery(H_NETINSTANCE hIp1toN,
                         OCTET oOption,
                         H_NETDATA *phData)
{
  return NETERR_NOERR;
}

/*
 * Ip1toNInstanceMsg
 *  Send a msg to a Ip1toN instance
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */

LONG Ip1toNInstanceMsg(H_NETINSTANCE hIp1toN,
                       OCTET oMsg,
                       H_NETDATA hData)
{
  return NETERR_NOERR;
}


/*
 * Ip1toNInstanceULInterfaceCreate
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hIp1toN                       Ip1toNinstance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */

H_NETINTERFACE Ip1toNInstanceULInterfaceCreate(H_NETINSTANCE hIp1toN)
{
  return (H_NETINTERFACE)1;
}

/*
 * Ip1toNInstanceULInterfaceDestroy
 *  Destroy a Ip1toN UL interface
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   hULIf                      Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */

LONG Ip1toNInstanceULInterfaceDestroy(H_NETINSTANCE hIp1toN,
                                      H_NETINTERFACE hULIf)
{

  ASSERT(hULIf == (H_NETINTERFACE) 1);

  return NETERR_NOERR;
}

/*
 * Ip1toNInstanceULInterfaceIoctl
 *
 *  Args:
 *   hIp1toN                      Ip1toN instance handle
 *   hULIf                        Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */

LONG Ip1toNInstanceULInterfaceIoctl(H_NETINSTANCE hIp1toN,
                                    H_NETINTERFACE hULIf,
                                    OCTET oIoctl,
                                    H_NETDATA hData)
{
  IP1TONSTATE *pxIp1toN = (IP1TONSTATE *)hIp1toN;
  LONG lReturn = NETERR_NOERR;

  IP1TON_CHECK_STATE(pxIp1toN);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP1TON, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IP1TON_DBGP(REPETITIVE,
              "Ip1toNInstanceULInterfaceIoctl: If: %x oIoctl: %x\n",
              (int)hULIf,oIoctl);*/
    DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "Ip1toNInstanceULInterfaceIoctl: If: ", (int)hULIf, " oIoctl: ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* ignore those */
    break;
  case NETINTERFACEIOCTL_SETHINST:
    pxIp1toN->hULInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIp1toN->pfnRxCbk = (PFN_NETRXCBK)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIp1toN->hULIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
  }


  return lReturn;
}


/*
 * Ip1toNInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIp1toN                Ip1toN instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */

H_NETINTERFACE Ip1toNInstanceLLInterfaceCreate(H_NETINSTANCE hIp1toN)
{
  IP1TONSTATE *pxIp1toN = (IP1TONSTATE *)hIp1toN;
  OCTET o;

  IP1TON_CHECK_STATE(pxIp1toN);

  for (o=0;o<pxIp1toN->oLLNumberIf;o++) {
    if (pxIp1toN->pxLl[o].obUsed == FALSE) {
      break;
    }
  }

  if (o == pxIp1toN->oLLNumberIf) {
  {
  IP1TON_LL *pxTempIp1toN;

  pxTempIp1toN = (IP1TON_LL *)MALLOC((pxIp1toN->oLLNumberIf+1) *sizeof(IP1TON_LL));
  ASSERT(pxTempIp1toN);
  MOC_MEMCPY((ubyte *)pxTempIp1toN, (ubyte *)(pxIp1toN->pxLl),
            pxIp1toN->oLLNumberIf*sizeof(IP1TON_LL));
  FREE(pxIp1toN->pxLl);
  pxIp1toN->pxLl = pxTempIp1toN;
  pxIp1toN->oLLNumberIf++;
  }
    o = pxIp1toN->oLLNumberIf;
  }
  else {
    o++;
  }
  /* Mark the entry as used */
  pxIp1toN->pxLl[o -1].obUsed = TRUE;

  return (H_NETINTERFACE)o;
}

/*
 * Ip1toNInstanceLLInterfaceDestroy
 *  Destroy a Ip1toN LL interface
 *
 *  Args:
 *   hIp1toN                    Ip1toN instance
 *   hLLIf                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */

LONG Ip1toNInstanceLLInterfaceDestroy(H_NETINSTANCE hIp1toN,
                                      H_NETINTERFACE hLLIf)
{
  IP1TONSTATE *pxIp1toN = (IP1TONSTATE *)hIp1toN;
  IP1TON_CHECK_STATE(pxIp1toN);


  ASSERT((0 < (int)hLLIf) && ((int)hLLIf <= pxIp1toN->oLLNumberIf));

  /* Reset the mapping */
  pxIp1toN->aIfIdxToLlMap[pxIp1toN->pxLl[(int)hLLIf -1].oIfIdx] =
    IP1TONLLIDX_INVALID;

  /* Mark the entry as unused, for future re-use */
  pxIp1toN->pxLl[(int)hLLIf -1].obUsed = FALSE;

  return NETERR_NOERR;
}

/*
 * Ip1toNInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hIp1toN                      Ip1toN instance handle
 *   hULIf                        Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG Ip1toNInstanceLLInterfaceIoctl(H_NETINSTANCE hIp1toN,
                                    H_NETINTERFACE hLLIf,
                                    OCTET oIoctl,
                                    H_NETDATA hData)
{
  IP1TONSTATE *pxIp1toN = (IP1TONSTATE *)hIp1toN;
  IP1TON_LL *pxLl;
  LONG lRv = NETERR_NOERR;

  IP1TON_CHECK_STATE(pxIp1toN);

  ASSERT((0 < (int)hLLIf) && ((int)hLLIf <= pxIp1toN->oLLNumberIf));

  pxLl = &pxIp1toN->pxLl[(OCTET)hLLIf-1];

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP1TON, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IP1TON_DBGP(REPETITIVE,
              "Ip1toNInstanceLLInterfaceIoctl: If:%x oIoctl: %x\n",
              (int)hLLIf,oIoctl);*/
    DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "Ip1toNInstanceLLInterfaceIoctl: If: ", (int)hLLIf, " oIoctl: ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oIoctl) {


  case NETINTERFACEIOCTL_SETHINST:
    pxLl->hLLInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxLl->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxLl->hLLIf = (H_NETINTERFACE)hData;
    break;

  case IP1TONLLINTERFACEIOCTL_SETIFIDX:
    ASSERT((int)hData < IP1TON_MAXIF);
    pxIp1toN->aIfIdxToLlMap[(OCTET)hData] = (OCTET)(hLLIf -1);
    pxLl->oIfIdx = (OCTET)hData;
    break;

#ifdef NDEBUG
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* Ignore these */
    break;
  default:
    lRv = NETERR_UNKNOWN;
    ASSERT(0);
#endif
  }

  return lRv;
}










