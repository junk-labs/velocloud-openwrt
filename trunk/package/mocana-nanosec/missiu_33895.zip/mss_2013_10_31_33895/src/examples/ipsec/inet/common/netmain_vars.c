/*
 * netmain_vars.c
 *
 * Network Wrapper Main variables
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include <mqueue.h>
#include "../include/in.h"
#include "netdb.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/if_types.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "nettime.h"
#include "iptable.h"
#include "netconfig.h"
#include "sockapi.h"
#include "nettransport.h"
#include "tcp.h"
#include "udp.h"
#include "netnetwork.h"
#include "ip.h"
#include "ip2eth.h"
#include "ethernet.h"
#include "arp.h"
#include "icmp.h"
#include "igmp.h"
#include "ip1ton.h"
#include "netmain.h"
#include "linkconf.h"
#include "netif.h"
#include "snmp_tcpip_data.h"
#include "routing_table.h"
#include "dnsapi.h"
#include "ping.h"

#ifdef ROUTER
  #include "router.h"
#endif /*#ifdef ROUTER*/
#ifdef NAT
  #include "nat.h"
#endif /*#ifdef NAT*/
#ifdef IPFRAG
#include "ipfrag.h"
#endif /*#ifdef IPFRAG*/
#ifdef AAL5
  #include "aal5devapi.h"
#endif /*#ifdef AAL5*/
#ifdef IPSEC
#include "ipsec.h"
#endif /*#ifdef IPSEC*/
/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/

int mn_errno = 0;

/*
 * Main trunk common settings
 */
const NETCONFSETTING axNetSettings[]= {
  {NETOPTION_FREE,(H_NETDATA)NetFree},
  {NETOPTION_MALLOC,(H_NETDATA)NetMalloc},
  {NETOPTION_PAYLOADMUTEX,(H_NETDATA)(&(xNetWrapper.xMutex))},
  {NETOPTION_OFFSET,0},
  {NETOPTION_TRAILER,0},
  {NETOPTION_NETCBK,(H_NETDATA)NetAdminCommonCbk},
  {NETOPTION_NETCBKHINST,(H_NETDATA)0}
};

/*
 * Array of interface configs
 */

NETIFCONF axIfConf[IFNUMMAX];

#ifndef PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP

#define PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP \
        { 0, 0, 0, PTHREAD_MUTEX_RECURSIVE_NP, __LOCK_INITIALIZER }
/*        { { 0, 0, 0, PTHREAD_MUTEX_RECURSIVE_NP, 0, 0 } } */


#endif

/*
 * Network wrapper main structure
 */
NETWRAPPER xNetWrapper = {
  axIfConf,
  0,
  0,
  DLLIST_INITIALIZER,/*dllPfnIfCloseCbk*/
  DLLIST_INITIALIZER,/*dllPfnIfOpenCbk*/
  NULL,/*pfnIfDhcpErrorCbk*/
  NULL,/*pfnIfLinkStatusCbk*/
  DLLIST_INITIALIZER,/* MnConfigNetDevices */
  DLLIST_INITIALIZER, /* dllMnDeviceInstanceEvents */
#if defined (__VXWORKS_RTOS__)
  0,
#else
  PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP,
#endif
  0
};


/****************************************************************************
 *
 * UDP Configuration
 *
 ****************************************************************************/

H_NETINTERFACE hUdpLlIf;

NETCONFINSTANCE xUdpInstance = {0,0,NULL,&hUdpLlIf};

/* Udp LL interface default config structure */
const NETCONFIFTEMPLATE axUdpLlIfIp[1] = {
  {
    /* Ioctls */ 0,NULL,
    /* Plumbing */ {{TRUE,MAINTRUNKLIBIDX_IP,0,IPULIFIDX_UDP}}
  }
};

/* UDP instance default configuration structure */
const NETCONFINSTANCETEMPLATE xUdpInstanceTemplate = {
    /* Options settings:*/0, axNetSettings,
    /* UL interfaces: none valid at start-up */ 0,NULL ,
    /* LL interfaces : IP */ 1,axUdpLlIfIp,
    /* Msgs, not including Open: none */ 0,NULL
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateUdp = {
  UdpInitialize, UdpTerminate, UdpInstanceCreate, UdpInstanceDestroy,
  UdpInstanceSet,UdpInstanceMsg,
  UdpInstanceULInterfaceCreate,UdpInstanceLLInterfaceCreate,
  UdpInstanceWrite,UdpInstanceRcv,
#ifndef NDEBUG
  UdpInstanceProcess,
#else
  NULL,
#endif
  UdpInstanceULInterfaceDestroy,UdpInstanceULInterfaceIoctl,
  UdpInstanceLLInterfaceDestroy,UdpInstanceLLInterfaceIoctl,
  NetAdminUdpCbk,
  &xUdpInstanceTemplate};

/****************************************************************************
 *
 * TCP Configuration
 *
 ****************************************************************************/
H_NETINTERFACE hTcpLlIf;

NETCONFINSTANCE xTcpInstance = {0,0,NULL,&hTcpLlIf};

/* Tcp LL interface default config structure */
const NETCONFIFTEMPLATE xTcpLlIfIp = {
    /* Ioctls */ 0,NULL,
    /* Plumbing : can't be done here */
    {{TRUE,MAINTRUNKLIBIDX_IP,0,IPULIFIDX_TCP}}
};

/* TCP instance default configuration structure */
const NETCONFINSTANCETEMPLATE xTcpInstanceTemplate =  {
    /* Options Setting: */3,axNetSettings,
    /* UL interfaces: none valid at start-up */0, NULL,
    /* LL interfaces: IP */1,&xTcpLlIfIp ,
    /* Msgs, not including open */ 0,NULL
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateTcp =
  {TcpInitialize, TcpTerminate, TcpInstanceCreate, TcpInstanceDestroy,
   TcpInstanceSet,TcpInstanceMsg,
   TcpInstanceULInterfaceCreate,TcpInstanceLLInterfaceCreate,
   TcpInstanceWrite,TcpInstanceRcv,
   TcpInstanceProcess,
   TcpInstanceULInterfaceDestroy,TcpInstanceULInterfaceIoctl,
   TcpInstanceLLInterfaceDestroy,TcpInstanceLLInterfaceIoctl,
#ifdef NEW_ICMP_MSG_ADDED
   NetAdminTcpCbk,
#else
   NetAdminCommonCbk,
#endif
   &xTcpInstanceTemplate};

/****************************************************************************
 *
 * IP Configuration
 *
 ****************************************************************************/
H_NETINTERFACE ahIpUlIf[4];

H_NETINTERFACE ahIpLlIf[1];

NETCONFINSTANCE axIpInstance[1] = {
  {0,0,ahIpUlIf,ahIpLlIf}
};

/* IP Ul ioctls defaults structure */
const NETCONFSCALARIOCTL axIpUlIfUdpIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)IPID_UDP}
};

const NETCONFSCALARIOCTL axIpUlIfTcpIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)IPID_TCP}
};

const NETCONFSCALARIOCTL axIpUlIfIcmpIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)IPID_ICMP}
};

const NETCONFSCALARIOCTL axIpUlIfIgmpIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)IPID_IGMP}
};

/* IP UL interfaces configuration structure */
const NETCONFIFTEMPLATE axIpUlIf[4] = {
  /* UDP */
  { 1,axIpUlIfUdpIoctl /* Ioctls */,
    /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_UDP,0,0}}},
  /* TCP */
  {1,axIpUlIfTcpIoctl,{{TRUE,MAINTRUNKLIBIDX_TCP,0,0}}},
  /* ICMP */
  {1,axIpUlIfIcmpIoctl,{{TRUE,MAINTRUNKLIBIDX_ICMP,0,0}}},
  /* IGMP */
  {1,axIpUlIfIgmpIoctl,{{TRUE,MAINTRUNKLIBIDX_IGMP,0,0}}},
};

#ifdef ROUTER
    const NETCONFIFTEMPLATE axIpLlIf[1] = {
          { 0,NULL /* Ioctls */,
            /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_ROUTER,0,0}}}
    };
#else /* #ifdef ROUTER */

    #ifdef IPSEC
        const NETCONFIFTEMPLATE axIpLlIf[1] = {
              { 0,NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IPSEC,0,0}}}
        };
    #else /* #ifdef IPSEC */
        const NETCONFIFTEMPLATE axIpLlIf[1] = {
              { 0,NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IP1TON,0,0}}}
        };
    #endif /* #ifdef IPSEC else */

#endif /* #ifdef ROUTER else */

/* IP instance configuration structure */
const NETCONFINSTANCETEMPLATE axIpInstTemplate[1] = {
  {
    /* Options settings: */ 0, axNetSettings,
    /* UL interfaces */ 4,axIpUlIf,
    /* LL interfaces: */1,axIpLlIf,
    /* Msgs, not including Open: none */ 0,NULL
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateIp =
  {IpInitialize, IpTerminate, IpInstanceCreate, IpInstanceDestroy,
   IpInstanceSet,IpInstanceMsg,
   IpInstanceULInterfaceCreate,IpInstanceLLInterfaceCreate,
   IpInstanceWriteFast,IpInstanceRcv,
#ifdef NETDBG_HI
   IpInstanceProcess,
#else
   NULL,
#endif
   IpInstanceULInterfaceDestroy,IpInstanceULInterfaceIoctl,
   IpInstanceLLInterfaceDestroy,IpInstanceLLInterfaceIoctl,
#ifdef NEW_ICMP_MSG_ADDED
   NetAdminIpCbk,
#else
   NetAdminCommonCbk,
#endif
   axIpInstTemplate};

/****************************************************************************
 *
 * ICMP Configuration
 *
 ****************************************************************************/
H_NETINTERFACE hIcmpLlIf;

NETCONFINSTANCE axIcmpInstance[1] = {
  {0,0,NULL,&hIcmpLlIf}
};

/* Icmp LL interface default config structure */
const NETCONFIFTEMPLATE axIcmpLlIf[1] = {
  {
    /* Ioctls */0,NULL,
    /* Plumbing */{{TRUE,MAINTRUNKLIBIDX_IP,0,IPULIFIDX_ICMP}}
  }
};

/* Icmp instance default configuration structure */
const NETCONFINSTANCETEMPLATE axIcmpInstanceTemplate[1] = {
  {
    /* Options Setting: */3,axNetSettings,
    /* UL Interfaces: none */0,NULL,
    /* LL interfaces: IP */1,axIcmpLlIf,
    /* Msgs, not including open: */ 0,NULL
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateIcmp =
  {IcmpInitialize, IcmpTerminate, IcmpInstanceCreate,
   IcmpInstanceDestroy,
   IcmpInstanceSet,IcmpInstanceMsg,
   NULL,IcmpInstanceLLInterfaceCreate,
   NULL,IcmpInstanceRcv,NULL,
   NULL,NULL,
   IcmpInstanceLLInterfaceDestroy,IcmpInstanceLLInterfaceIoctl,
   NetAdminIcmpCbk,
   axIcmpInstanceTemplate};

/****************************************************************************
 *
 * IGMP Configuration
 *
 ****************************************************************************/
H_NETINTERFACE hIgmpLlIf;

NETCONFINSTANCE axIgmpInstance[1] = {
  {0,0,NULL,&hIgmpLlIf}
};

/* Igmp LL interface default config structure */
const NETCONFIFTEMPLATE axIgmpLlIf[1] = {
  {
    /* Ioctls */0,NULL,
    /* Plumbing */{{TRUE,MAINTRUNKLIBIDX_IP,0,IPULIFIDX_IGMP}}
  }
};

/* Igmp Instance default config structure */
const NETCONFINSTANCETEMPLATE axIgmpInstanceTemplate[1] = {
  {
    /* Options settings:*/3, axNetSettings,
    /* UL interfaces none */ 0,NULL,
    /* LL interfaces : IP */ 1,axIgmpLlIf,
    /* Msgs, not including Open: none */ 0,NULL
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateIgmp =
  {IgmpInitialize, IgmpTerminate, IgmpInstanceCreate, IgmpInstanceDestroy,
   IgmpInstanceSet,IgmpInstanceMsg,
   NULL,IgmpInstanceLLInterfaceCreate,
   NULL,IgmpInstanceRcv,
   IgmpInstanceProcess,
   NULL,NULL,
   IgmpInstanceLLInterfaceDestroy,IgmpInstanceLLInterfaceIoctl,
   NetAdminCommonCbk,
   axIgmpInstanceTemplate};

/****************************************************************************
 *
 * IP1TON Configuration
 *
 ****************************************************************************/
H_NETINTERFACE ahIp1toNUlIf[1];

NETCONFINSTANCE axIp1toNInstance[1] = {
  {0,0,ahIp1toNUlIf,NULL}
};

#ifdef ROUTER
    /*
     * Ip1toN Configuration
     */

    const NETCONFIFTEMPLATE axIp1toNULIf[1] = {
          /* IpFrag */
          { 0,NULL /* Ioctls */,
            /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IPFRAG,0,0}}}
    };

    /* Ip1toN instance configuration structure */
    const NETCONFINSTANCETEMPLATE axIp1toNInstTemplate[1] = {
          {
            0, axNetSettings,/* Options settings: */
            1,axIp1toNULIf,/* UL interfaces */
            0,NULL,/* LL interfaces: none plumbed at start up */
            0,NULL /* Msgs, not including Open: none */
          }
    };

#else    /* ROUTER */

    #ifdef IPSEC
        const NETCONFIFTEMPLATE axIp1toNULIf[1] = {
              /* IP */
              { 0,NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IPSEC,0,0}}}
        };
    #else /* #ifdef IPSEC */
        const NETCONFIFTEMPLATE axIp1toNULIf[1] = {
              /* IP */
              { 0,NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IP,0,0}}}
        };
    #endif /* #ifdef IPSEC else */

    /* Ip1toN instance configuration structure */
    const NETCONFINSTANCETEMPLATE axIp1toNInstTemplate[1] = {
          {
            0, axNetSettings,/* Options settings: */
            1,axIp1toNULIf,/* UL interfaces */
            0,NULL,/* LL interfaces: none plumbed at start up */
            0,NULL/* Msgs, not including Open: none */
            }
    };


#endif    /* ROUTER */

const NETCONFLIBRARYTEMPLATE gxLibTemplateIp1toN =
  {Ip1toNInitialize, Ip1toNTerminate,
   Ip1toNInstanceCreate, Ip1toNInstanceDestroy,
   /*Ip1toNInstanceSet*/ NULL,Ip1toNInstanceMsg,
   Ip1toNInstanceULInterfaceCreate,Ip1toNInstanceLLInterfaceCreate,
   Ip1toNInstanceWrite,Ip1toNInstanceRcv,NULL,
   Ip1toNInstanceULInterfaceDestroy,Ip1toNInstanceULInterfaceIoctl,
   Ip1toNInstanceLLInterfaceDestroy,Ip1toNInstanceLLInterfaceIoctl,
   NetAdminCommonCbk,
   axIp1toNInstTemplate};

/****************************************************************************
 *
 * ROUTER Configuration
 *
 ****************************************************************************/
#ifdef ROUTER
H_NETINTERFACE ahRouterUlIf[1];
H_NETINTERFACE ahRouterLlIf[1];

NETCONFINSTANCE axRouterInstance[1] = {
  {0,0,ahRouterUlIf,ahRouterLlIf}
};

/* Router UL interfaces configuration structure */
const NETCONFIFTEMPLATE axRouterULIf[1] = {
  /* IP */
  { 0, NULL /* Ioctls */,
    /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IP,0,0}}}
};

#ifdef NAT
    /* Router LL interfaces configuration structure */
    const NETCONFIFTEMPLATE axRouterLLIf[1] = {
          /* NAT */
          { 0,NULL /* Ioctls */,
            /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_NAT,0,0}}}
    };
#else /* NAT */
    #ifdef IPSEC
        /* Router LL interfaces configuration structure */
        const NETCONFIFTEMPLATE axRouterLLIf[1] = {
              /* IPSEC */
              { 0,NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IPSEC,0,0}}}
        };
    #else
        /* Router LL interfaces configuration structure */
        const NETCONFIFTEMPLATE axRouterLLIf[1] = {
              /* IPFRAG */
              { 0,NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IPFRAG,0,0}}}
        };
    #endif
#endif

/* Router instance configuration structure */
const NETCONFINSTANCETEMPLATE axRouterInstTemplate[1] = {
  {
    3, axNetSettings,/* Options settings: */
    1,axRouterULIf,/* UL interfaces */
    1,axRouterLLIf,/* LL interfaces: */
    0,NULL/* Msgs, not including Open: none */
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateRouter =
  {RouterInitialize, RouterTerminate, RouterInstanceCreate, RouterInstanceDestroy,
   RouterInstanceSet,RouterInstanceMsg,
   RouterInstanceULInterfaceCreate,RouterInstanceLLInterfaceCreate,
   RouterInstanceWrite,RouterInstanceRcv,
   NULL,
   RouterInstanceULInterfaceDestroy,RouterInstanceULInterfaceIoctl,
   RouterInstanceLLInterfaceDestroy,RouterInstanceLLInterfaceIoctl,
   NetAdminRouterCbk,
   axRouterInstTemplate};
#endif /*#ifdef ROUTER*/

/****************************************************************************
 *
 * NAT Configuration
 *
 ****************************************************************************/

#ifdef NAT
H_NETINTERFACE ahNatUlIf[1];
H_NETINTERFACE ahNatLlIf[1];

NETCONFINSTANCE axNatInstance[1] = {
  {0,0,ahNatUlIf,ahNatLlIf}
};

/* NAT UL interfaces configuration structure */
const NETCONFIFTEMPLATE axNatULIf[1] = {
  /* Router */
  { 0, NULL /* Ioctls */,
    /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_ROUTER,0,0}}}
};

/* NAT LL interfaces configuration structure */
#ifdef IPSEC
    const NETCONFIFTEMPLATE axNatLLIf[1] = {
          /* IPSec */
          { 0,NULL /* Ioctls */,
            /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IPSEC,0,0}}}
      };
#else /* #ifdef IPSEC */
    const NETCONFIFTEMPLATE axNatLLIf[1] = {
          /* IpFrag */
          { 0,NULL /* Ioctls */,
            /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IPFRAG,0,0}}}
      };
#endif /* #ifdef IPSEC else */

/* NAT instance configuration structure */
const NETCONFINSTANCETEMPLATE axNatInstTemplate[1] = {
  {
    3, axNetSettings,/* Options settings: */
    1,axNatULIf,/* UL interfaces */
    1,axNatLLIf,/* LL interfaces: */
    0,NULL/* Msgs, not including Open: none */
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateNat =
  {NatInitialize,NatTerminate,NatInstanceCreate,NatInstanceDestroy,
   NULL,NatInstanceMsg,
   NatInstanceULInterfaceCreate,NatInstanceLLInterfaceCreate,
   NatInstanceWrite,NatInstanceRcv,NatInstanceProcess,
   NatInstanceULInterfaceDestroy,NatInstanceULInterfaceIoctl,
   NatInstanceLLInterfaceDestroy,NatInstanceLLInterfaceIoctl,
   NetAdminCommonCbk,
   axNatInstTemplate};
#endif /*#ifdef NAT*/

/****************************************************************************
 *
 * IPFRAG Configuration
 *
 ****************************************************************************/

#ifdef IPFRAG /* always required with ROUTER */
H_NETINTERFACE ahIpFragUlIf[1];
H_NETINTERFACE ahIpFragLlIf[1];

NETCONFINSTANCE axIpFragInstance[1] = {
  {0,0,ahIpFragUlIf,ahIpFragLlIf}
};

/* IpFrag UL interfaces configuration structure */
#ifdef IPSEC
    const NETCONFIFTEMPLATE axIpFragULIf[1] = {
          { 0, NULL /* Ioctls */,
            /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IPSEC,0,0}}}
    };
#else /* #ifdef IPSEC */
    #ifdef NAT
        const NETCONFIFTEMPLATE axIpFragULIf[1] = {
              { 0, NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_NAT,0,0}}}
        };
    #else
        const NETCONFIFTEMPLATE axIpFragULIf[1] = {
              { 0, NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_ROUTER,0,0}}}
        };
    #endif
#endif /* #ifdef IPSEC else */

/* IpFrag LL interfaces configuration structure */
const NETCONFIFTEMPLATE axIpFragLLIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IP1TON,0,0}}}
};

/* IpFrag instance configuration structure */
const NETCONFINSTANCETEMPLATE axIpFragInstTemplate[1] = {
  {
    3,axNetSettings,/* Options settings: */
    1,axIpFragULIf,/* UL interfaces */
    1,axIpFragLLIf,/* LL interfaces: */
    0,NULL /* Msgs, not including Open: none */
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateIpFrag =
  {IpFragInitialize,IpFragTerminate,
   IpFragInstanceCreate,IpFragInstanceDestroy,
   IpFragInstanceSet,IpFragInstanceMsg,
   IpFragInstanceULInterfaceCreate,IpFragInstanceLLInterfaceCreate,
   IpFragInstanceWrite,IpFragInstanceRcv,IpFragInstanceProcess,
   IpFragInstanceULInterfaceDestroy,IpFragInstanceULInterfaceIoctl,
   IpFragInstanceLLInterfaceDestroy,IpFragInstanceLLInterfaceIoctl,
   NetAdminIpFragCbk,
   axIpFragInstTemplate};
#endif /*#ifdef IPFRAG*/

/****************************************************************************
 *
 * IPSEC Configuration
 *
 ****************************************************************************/
#ifdef IPSEC
H_NETINTERFACE ahIPSecUlIf[1];
H_NETINTERFACE ahIPSecLlIf[1];

NETCONFINSTANCE axIPSecInstance[1] = {
  {0,0,ahIPSecUlIf,ahIPSecLlIf}
};

#ifdef ROUTER
    #ifdef NAT
        /* IPSec UL interfaces configuration structure */
        const NETCONFIFTEMPLATE axIPSecULIf[1] = {
              { 0, NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_NAT,0,0}}}
        };
    #else
        /* IPSec UL interfaces configuration structure */
        const NETCONFIFTEMPLATE axIPSecULIf[1] = {
              { 0, NULL /* Ioctls */,
                /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_ROUTER,0,0}}}
        };
    #endif

    /* IPSec LL interfaces configuration structure */
    const NETCONFIFTEMPLATE axIPSecLLIf[1] = {
          { 0,NULL /* Ioctls */,
            /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IPFRAG,0,0}}}
    };
#else /* #ifdef ROUTER */
    /* IPSec UL interfaces configuration structure */
    const NETCONFIFTEMPLATE axIPSecULIf[1] = {
          { 0, NULL /* Ioctls */,
            /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IP,0,0}}}
    };

    /* IPSec LL interfaces configuration structure */
    const NETCONFIFTEMPLATE axIPSecLLIf[1] = {
          { 0,NULL /* Ioctls */,
            /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_IP1TON,0,0}}}
    };
#endif /* #ifdef ROUTER else */

/* IPSec instance configuration structure */
const NETCONFINSTANCETEMPLATE axIPSecInstTemplate[1] = {
  {
    0,axNetSettings,/* Options settings: */
    1,axIPSecULIf,/* UL interfaces */
    1,axIPSecLLIf,/* LL interfaces: */
    0,NULL /* Msgs, not including Open: none */
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateIpSec =
  {IPSecInitialize,IPSecTerminate,
   IPSecInstanceCreate,IPSecInstanceDestroy,
   IPSecInstanceSet,IPSecInstanceMsg,
   IPSecInstanceULInterfaceCreate,IPSecInstanceLLInterfaceCreate,
   IPSecInstanceWrite,IPSecInstanceRcv,IPSecInstanceProcess,
   IPSecInstanceULInterfaceDestroy,IPSecInstanceULInterfaceIoctl,
   IPSecInstanceLLInterfaceDestroy,IPSecInstanceLLInterfaceIoctl,
   NetAdminCommonCbk,
   axIPSecInstTemplate};
#endif /*#ifdef IPSEC*/

/****************************************************************************
 *
 * ETH Configuration
 *
 ****************************************************************************/
H_NETINTERFACE ahEthUlIf[ETHULIFIDX_MAX];

NETCONFINSTANCE axEthInstance[1] = {
  {0,0,ahEthUlIf,NULL}
};

const NETCONFSCALARIOCTL axEthUlIfArpIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)ETHID_ARP}
};

const NETCONFSCALARIOCTL axEthUlIfRarpIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)ETHID_RARP}
};

const NETCONFSCALARIOCTL axEthUlIfIp2EthIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)ETHID_IP}
};

const NETCONFIFTEMPLATE axEthUlIf[ETHULIFIDX_MAX] = {
  /* ARP */
  { 1,axEthUlIfArpIoctl /* Ioctls */,
    /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_ARP,0,0}}},
  { 1,axEthUlIfRarpIoctl /* Ioctls */,
    /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_ARP,0,0}}},
};


const NETCONFINSTANCETEMPLATE xEthInstanceTemplate = {
#ifdef NET_BR
  3, axNetSettings, /* Bridge Options settings: */
#else
  0, axNetSettings, /* Options settings: */
#endif
  2,axEthUlIf, /* UL interfaces. ARP and RARP only as default */
  0,NULL /* LL interfaces: none as default*/ ,
  /* Msgs, not including Open: none */ 0,NULL
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateEth =
 {NULL,NULL, EthInstanceCreate, EthInstanceDestroy,
  EthInstanceSet,EthInstanceMsg,
  EthInstanceULInterfaceCreate,EthInstanceLLInterfaceCreate,
  EthInstanceWrite,EthInstanceRcv,
#ifdef NET_BR
  EthInstanceProcess,
#else
  /* No processing */NULL,
#endif
  EthInstanceULInterfaceDestroy,EthInstanceULInterfaceIoctl,
  EthInstanceLLInterfaceDestroy,EthInstanceLLInterfaceIoctl,
  NetAdminCommonCbk,
  &xEthInstanceTemplate};

/****************************************************************************
 *
 * ARP Configuration
 *
 ****************************************************************************/
H_NETINTERFACE ahArpLlIf[1];

NETCONFINSTANCE axArpInstance[1] = {
  {0,0,NULL,ahArpLlIf}
};

const NETCONFIFTEMPLATE xArpLlIf = {
  0,NULL /* Ioctls */,
  /* Plumbings */{{TRUE,MAINTRUNKLIBIDX_ETH,0,ETHULIFIDX_ARP}}
};


const NETCONFINSTANCETEMPLATE xArpInstanceTemplate = {
  3, axNetSettings, /* Options settings: */
  0,NULL, /* no UL interface */
  1, &xArpLlIf/* LL interfaces: none as default*/ ,
  0,NULL /* Msgs, not including Open: none */
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateArp =
  {ArpInitialize, ArpTerminate, ArpInstanceCreate, ArpInstanceDestroy,
   ArpInstanceSet,ArpInstanceMsg,
   NULL,ArpInstanceLLInterfaceCreate,
   NULL,ArpInstanceRcv,
   ArpInstanceProcess,
   NULL,NULL,
   ArpInstanceLLInterfaceDestroy,ArpInstanceLLInterfaceIoctl,
   NetAdminArpCbk,
   &xArpInstanceTemplate};

/****************************************************************************
 *
 * IP2ETH
 *
 ****************************************************************************/
H_NETINTERFACE ahIp2EthUlIf[1];
H_NETINTERFACE ahIp2EthLlIf[1];

NETCONFINSTANCE axIp2EthInstance[1] = {
  {0,0,ahIp2EthUlIf,ahIp2EthLlIf}
};

const NETCONFIFTEMPLATE axIp2EthLLIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{FALSE,0,0,0}}},
};

const NETCONFIFTEMPLATE axIp2EthULIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{FALSE,0,0,0}}},
};

const NETCONFINSTANCETEMPLATE axIp2EthInstTemplate[1] =
{
  {
     /* Options settings: */ 7, axNetSettings,
     /* UL interfaces:*/ 1,axIp2EthULIf,
     /* LL interfaces:*/ 1,axIp2EthLLIf,
     /* Msgs, not including Open: none */ 0,NULL
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateIp2Eth = {
   Ip2EthInitialize, Ip2EthTerminate, Ip2EthInstanceCreate,
   Ip2EthInstanceDestroy,Ip2EthInstanceSet,Ip2EthInstanceMsg,
   Ip2EthInstanceULInterfaceCreate,Ip2EthInstanceLLInterfaceCreate,
   Ip2EthInstanceWrite,Ip2EthInstanceRcv,
   NULL/*Ip2EthInstanceProcess*/,
   Ip2EthInstanceULInterfaceDestroy,Ip2EthInstanceULInterfaceIoctl,
   Ip2EthInstanceLLInterfaceDestroy,Ip2EthInstanceLLInterfaceIoctl,
   NULL,
   axIp2EthInstTemplate};

/****************************************************************************
 *
 * Array initialization
 *
 ****************************************************************************/

const NETCONFLIBRARYTEMPLATE *apxMainTrunkLibTemplate[] = {
  &gxLibTemplateUdp,
  &gxLibTemplateTcp,
  &gxLibTemplateIcmp,
  &gxLibTemplateIgmp,
  &gxLibTemplateIp,
  &gxLibTemplateEth,
  &gxLibTemplateArp,
  &gxLibTemplateIp2Eth,
  &gxLibTemplateIp1toN,
#ifdef ROUTER
  &gxLibTemplateRouter,
#endif
#ifdef NAT
  &gxLibTemplateNat,
#endif
#ifdef IPSEC
  &gxLibTemplateIpSec,
#endif
#ifdef IPFRAG /* always required with ROUTER */
  &gxLibTemplateIpFrag,
#endif
  };

#ifndef NDEBUG
const OCTET *apoNetOptionString[] = {
  "FREE",
  "MALLOC",
  "PAYLOADMUTEX",
  "NETCBK",
  "NETCBKHINST",
  "OFFSET",
  "TRAILER",
};

const OCTET *apoNetMsgString[] = {
  "OPEN",
  "CLOSE",
  "LLUP",
  "LLDOWN",
};

const OCTET *apoNetCbkString[] = {
  "TLU",
  "TLD",
  "TLS",
  "TLF",
  "NEEDPROCESSING"
};

const OCTET *apoNetIoctlString[] = {
  "OPEN",
  "CLOSE",
  "SETHINST",
  "SETOUTPUTPFN",
  "SETIF",
  "SETROUTINGID",
};

#endif /*NDEBUG*/

