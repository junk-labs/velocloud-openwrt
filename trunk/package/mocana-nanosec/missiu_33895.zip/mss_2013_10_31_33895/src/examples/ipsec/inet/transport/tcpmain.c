/*
 * tcpmain.c
 *
 * TCP module main
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "tcp_flavor.h"
#include "dllist.h"
#include "../include/in.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#ifdef __TCP_USE_SEGMENTS__
#include "../include/netsegment.h"
#endif
#include "ecc.h"
#include "macros.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"
#include "iptable.h"
#include "routing_table.h"
#include "nettransport.h"
#include "netnetwork.h"
#include "netsnmp.h"
#include "snmp_tcpip_data.h"
#include "tcp.h"
#include "tcpdefs.h"
#include "sockapi.h"
#include "tcp_dbg.h"
#ifdef IPSEC
#include "ipsec.h"
#endif /* IPSEC */
#ifdef NEW_ICMP_MSG_ADDED
#include "icmp.h"
#endif
/*****************************************************************************
 *
 * defines
 *
 *****************************************************************************/

/*
 * TCP LL interface handle value
 */
#define TCPLLINTERFACEHANDLE  1



/*****************************************************************************
 *
 * global
 *
 *****************************************************************************/

#ifdef TCPDBG_HI
DWORD gbTcpPrintConnection = 0;
#endif


TCP_DBG_VAR(DWORD g_dwTcpDebugLevel = REPETITIVE);
TCP_DBG_VAR(DWORD g_dwTcpConnSendSegmentLine = 1);
TCP_DBG_VAR(DWORD g_dwTcpInstanceRcv = 1);
TCP_DBG_VAR(DWORD g_dwSendRetx = 1);
TCP_DBG_VAR(DWORD g_dwSend = 1);


TCPSTATE  **ppxTcpInstanceList = NULL;
OCTET     oTcpInstances = 0;

/*****************************************************************************
 *
 * Local functions prototypes
 *
 *****************************************************************************/
static LONG _TcpLocalCompare(TCPSTATE *pxTcp, const void *pxConn1v);
static int _TcpAfter(DWORD seq1, DWORD seq2);
static int _TcpBefore(DWORD seq1, DWORD seq2);

/*#ifdef TCPDBG_HI*/
void  _TcpPrintConnection(TCPSTATE *pxTcp);
CHAR* _TcpStateToString(E_TCPCONN_STATE eState);
/*#endif*/

/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/

#ifndef __TCP_OPT_ON__

void _TcpInsertOrderedList (TCP_TIMER_LIST  *lTimerList,
                            TCPCONN *pxConn,
                            TCP_TIMER_TYPE timerType)
{
    TCPCONN *pInConn = NULL;
    TCPCONN *pLastConn = NULL;
    TCPCONN_CONNECT *pxConnect;

    pxConnect = pxConn->u.pxConnect;
    TCP_ASSERT_HI(pxConnect != NULL);

    /*TCP_DBGP(NORMAL,"_TcpInsertOrderedList:[%d] 0x%p \n", timerType, pxConn );*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
    {
        DEBUG_PRINT(DEBUG_MOC_IPV4,"_TcpInsertOrderedList:[");
        DEBUG_INT(DEBUG_MOC_IPV4,timerType);
        DEBUG_PRINT(DEBUG_MOC_IPV4,"] 0x");
        DEBUG_HEXINT(DEBUG_MOC_IPV4, (sbyte4)pxConn);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
    }

    if (LIST_EMPTY(lTimerList))
    {
       switch (timerType)
       {
           case TCP_TIMER_PERSIST:
           {
               LIST_INSERT_HEAD (lTimerList, pxConn, persist_link);
               break;
           }
           case TCP_TIMER_LINGER:
           {
               LIST_INSERT_HEAD (lTimerList, pxConn, linger_link);
               break;
           }
           case TCP_TIMER_CONESTAB:
           {
               LIST_INSERT_HEAD (lTimerList, pxConn, conestab_link);
               break;
           }
           case TCP_TIMER_REASM:
           {
               LIST_INSERT_HEAD (lTimerList, pxConn, reasm_link);
               break;
           }
           case TCP_TIMER_RETRANS:
           {
               LIST_INSERT_HEAD (lTimerList, pxConn, retrans_link);
               break;
           }
           case TCP_TIMER_FINWAIT2:
           {
               LIST_INSERT_HEAD (lTimerList, pxConn, finack2_link);
               break;
           }
           case TCP_TIMER_FASTACK:
           {
               LIST_INSERT_HEAD (lTimerList, pxConn, fastack_link);
               break;
           }
           default:
               break;
        }
        return;
    }

    switch (timerType)
    {
        case TCP_TIMER_PERSIST:
        {
            LIST_FOREACH(pInConn, lTimerList,persist_link)
            {
                pLastConn = pInConn;
                if (_TcpAfter(pInConn->u.pxConnect->wPersistTimer , pxConnect->wPersistTimer))
                {
                    LIST_INSERT_BEFORE(pInConn, pxConn, persist_link);
                    return;
                }
            }
            break;
        }

        case TCP_TIMER_LINGER:
        {
            LIST_FOREACH(pInConn, lTimerList,linger_link)
            {
                pLastConn = pInConn;
                if (_TcpAfter(pInConn->u.pxConnect->wLingerTimer , pxConnect->wLingerTimer))
                {
                    LIST_INSERT_BEFORE(pInConn, pxConn, linger_link);
                    return;
                }
            }
            break;
        }
        case TCP_TIMER_CONESTAB:
        {
            LIST_FOREACH(pInConn, lTimerList,conestab_link)
            {
                pLastConn = pInConn;
                if (_TcpAfter(pInConn->u.pxConnect->wConestabTimer , pxConnect->wConestabTimer))
                {
                    LIST_INSERT_BEFORE(pInConn, pxConn, conestab_link);
                    return;
                }
            }
            break;
        }
        case TCP_TIMER_REASM:
        {
            LIST_FOREACH(pInConn, lTimerList,reasm_link)
            {
                pLastConn = pInConn;
                if (_TcpAfter(pInConn->u.pxConnect->wReasmTimer , pxConnect->wReasmTimer))
                {
                    LIST_INSERT_BEFORE(pInConn, pxConn, reasm_link);
                    return;
                }
            }
            break;
        }
        case TCP_TIMER_RETRANS:
        {
            LIST_FOREACH(pInConn, lTimerList,retrans_link)
            {
                pLastConn = pInConn;
                if (_TcpAfter(pInConn->u.pxConnect->wRetransmitTimer , pxConnect->wRetransmitTimer))
                {
                    LIST_INSERT_BEFORE(pInConn, pxConn, retrans_link);
                    return;
                }
            }
            break;
        }
        case TCP_TIMER_FINWAIT2:
        {
            LIST_FOREACH(pInConn, lTimerList,finack2_link)
            {
                pLastConn = pInConn;
                if (_TcpAfter(pInConn->u.pxConnect->wFinwait2Timer , pxConnect->wFinwait2Timer))
                {
                    LIST_INSERT_BEFORE(pInConn, pxConn, finack2_link);
                    return;
                }
            }
            break;
        }
        case TCP_TIMER_FASTACK:
        {
            LIST_FOREACH(pInConn, lTimerList,fastack_link)
            {
                pLastConn = pInConn;
                if (_TcpAfter(pInConn->u.pxConnect->wFastackTimer , pxConnect->wFastackTimer))
                {
                    LIST_INSERT_BEFORE(pInConn, pxConn, fastack_link);
                    return;
                }
            }
            break;
        }
        default:
            return;
    }

    /* We Reached Here, We need to insert it at the end */

    switch (timerType)
    {
       case TCP_TIMER_PERSIST:
       {
           LIST_INSERT_AFTER (pLastConn, pxConn, persist_link);
           break;
       }
       case TCP_TIMER_LINGER:
       {
           LIST_INSERT_AFTER (pLastConn, pxConn, linger_link);
           break;
       }
       case TCP_TIMER_CONESTAB:
       {
           LIST_INSERT_AFTER (pLastConn, pxConn, conestab_link);
           break;
       }
       case TCP_TIMER_REASM:
       {
           LIST_INSERT_AFTER (pLastConn, pxConn, reasm_link);
           break;
       }
       case TCP_TIMER_RETRANS:
       {
           LIST_INSERT_AFTER (pLastConn, pxConn, retrans_link);
           break;
       }
       case TCP_TIMER_FINWAIT2:
       {
           LIST_INSERT_AFTER (pLastConn, pxConn, finack2_link);
           break;
       }
       case TCP_TIMER_FASTACK:
       {
           LIST_INSERT_AFTER (pLastConn, pxConn, fastack_link);
           break;
       }
       default:
           break;
    }

    return;
}

#endif /* __TCP_OPT_ON__*/

void _TcpCheckRxErrs(TCPCONN *pxConn)
{
    WORD _wRxErrs;
    mn_tcp_sock_rx_errs_t _e;

    if ( ! pxConn || ! pxConn->pfnCbk )
    return;

    _wRxErrs = pxConn->wRxChecksumErrs + pxConn->wRxBadLenErrs;
    if ( _wRxErrs && (_wRxErrs % TCP_RX_ERRS_THRESHOLD) == 0 ){
    /* send callback to socket */
    _e.wChecksumErrs = pxConn->wRxChecksumErrs;
    _e.wBadLenErrs = pxConn->wRxBadLenErrs;
      (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                              (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                              TCPULINTERFACECBK_RX_ERRS,
                (H_NETDATA)&_e);
    }
}

void _TcpCheckTxErrs(TCPCONN *pxConn)
{
    WORD _wTxErrs;
    mn_tcp_sock_tx_errs_t _e;

    if ( ! pxConn || ! pxConn->pfnCbk )
    return;

    _wTxErrs = pxConn->wTxRetransSegs;
    if ( _wTxErrs && (_wTxErrs % TCP_TX_ERRS_THRESHOLD) == 0 ){
    /* send callback to socket */
    _e.wRetransSegs = pxConn->wTxRetransSegs;
      (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                              (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                              TCPULINTERFACECBK_TX_ERRS,
                (H_NETDATA)&_e);
    }
}

/*
 * The next routines deal with comparing 32 bit unsigned ints
 * and worry about wraparound (automatic with unsigned arithmetic).
 */

static int _TcpBefore(DWORD seq1, DWORD seq2)
{
        return (LONG)(seq1-seq2) < 0;
}

static int _TcpAfter(DWORD seq1, DWORD seq2)
{
        return (LONG)(seq2-seq1) < 0;
}


/* is s2<=s1<=s3 ? */
static int _TcpBetween(DWORD seq1, DWORD seq2, DWORD seq3)
{
        return seq3 - seq2 >= seq1 - seq2;
}

/*
 * _TcpFindItemByAddress
 *  DLLIST find function using the pointer address
 *  to find a given item in the linklist
 *
 *  Args:
 *   pxItem1                    Item1 pointer
 *   pxItem2                    Item2 pointer
 *
 *  Return:
 *   0 if both pointers are equal, -1 otherwise
 */
static LONG _TcpFindItemByAddress(void *pxItem1,void *pxItem2)
{
  if (pxItem1 == pxItem2) {
    return 0;
  }
  else {
    return -1;
  }
}
#if 0
/*
 * _TcpFindItemByIndex
 *  DLLIST find function using the interface index
 *  (upper word) to find a given item in the linklist
 *
 *  Args:
 *   pxItem1                    Item1 pointer
 *   pxItem2                    Item2 pointer
 *
 *  Return:
 *   0 if both indexes are equal, -1 otherwise
 */
static LONG _TcpFindItemByIndex(void *pxItem1,void *pxItem2)
{
  if ((((DWORD)pxItem1) & 0xFFFF0000) == (((DWORD)pxItem2) & 0xFFFF0000)) {
    return 0;
  }
  return -1;
}
#endif
/*
 * _TcpLocalCmp
 *  See if two TCPCONNs have matching local IP, port ID
 *
 *  Args:
 *   pxConn1                  casted type TCPCONN* reference point
 *   pxConn2                  casted type TCPCONN* reference point
 *  Return:
 *   0 if contents equal
 */
static LONG _TcpLocalCmp(void *pxConn1v, void *pxConn2v)
{
  /* first check if we are on different interfaces,
     or different VLANs on the same interface. If so, we're
     OK even if transport id's match */

  TCPCONN *pxConn1 = (TCPCONN *)pxConn1v;
  TCPCONN *pxConn2 = (TCPCONN *)pxConn2v;
  TRANSPORT2NETWORKID *pxConnNetId1,*pxConnNetId2;

  TCP_ASSERT_HI(pxConn1 != NULL && pxConn2 != NULL);
  pxConnNetId1 = &(pxConn1->xId.xNetId);
  pxConnNetId2 = &(pxConn2->xId.xNetId);

  if (pxConnNetId1->oIfIdx != NETIFIDX_DEFAULT
      && pxConnNetId2->oIfIdx != NETIFIDX_DEFAULT
      && pxConnNetId1->oIfIdx != pxConnNetId2->oIfIdx) {
    /* not the same if */
    return -1;
  }

  if (pxConnNetId1->wVlan != NETVLAN_DEFAULT &&
      pxConnNetId2->wVlan != NETVLAN_DEFAULT &&
      (pxConnNetId1->wVlan & NETVLAN_VIDMASK) !=
         (pxConnNetId2->wVlan & NETVLAN_VIDMASK)) {
    /* not the same VLAN */
    return -1;
  }

  if (pxConn1->xId.wSrcPort == pxConn2->xId.wSrcPort) {
    return 0;
  }
  else {
    return -1;
  }
}

#ifndef __TCP_OPT_ON__

static LONG _TcpLocalCompare(TCPSTATE *pxTcp, const void *pxConn1v)
{
  /* first check if we are on different interfaces,
     or different VLANs on the same interface. If so, we're
     OK even if transport id's match */
  RBLIST                 *rbList;
  TCPCONN *pxConn1 = (TCPCONN *)pxConn1v;
  TCPCONN *pxConn2 = NULL;
  TRANSPORT2NETWORKID *pxConnNetId1,*pxConnNetId2;

  if ((rbList = rbopenlist(pxTcp->connTree)) == NULL)
  {
  /*out of memory */
      return 0;
  }

  while ((pxConn2 = (TCPCONN *)rbreadlist(rbList)))
  {

    TCP_ASSERT_HI(pxConn1 != NULL && pxConn2 != NULL);
    pxConnNetId1 = &(pxConn1->xId.xNetId);
    pxConnNetId2 = &(pxConn2->xId.xNetId);

    if (pxConnNetId1->oIfIdx != NETIFIDX_DEFAULT
        && pxConnNetId2->oIfIdx != NETIFIDX_DEFAULT)
    {
      if (pxConnNetId1->oIfIdx != pxConnNetId2->oIfIdx)
      /* not the same if */
          continue;
    }

    if (pxConnNetId1->wVlan != NETVLAN_DEFAULT &&
        pxConnNetId2->wVlan != NETVLAN_DEFAULT)
    {
      if ((pxConnNetId1->wVlan & NETVLAN_VIDMASK) !=
           (pxConnNetId2->wVlan & NETVLAN_VIDMASK))
        continue;
      /* not the same VLAN */
    }

    if (pxConn1->xId.wSrcPort != pxConn2->xId.wSrcPort)
      continue;
    /* Found It */
    return 0;
  }
  rbcloselist(rbList);
  return -1;
}

#endif /*__TCP_OPT_ON__*/
/*
 * _TcpSetLocalPort
 *  Sets a local port in TCPCONN and checks for duplicate port/IP
 *
 *  Args:
 *   pxTcp                    TCP instance structure
 *   pxConn                   TCP connection structure
 *   wPort                    port id
 *   bIsReuseAllowed          Can this port be reused?
 *  Return:
 *   0 port ok
 *  -1 if duplicate found
 */
static LONG _TcpSetLocalPort(TCPSTATE *pxTcp,
                             TCPCONN *pxConn,
                             WORD wPort,
                             BOOL bIsReuseAllowed)
{
  /* put a TCPCONN on the stack for the find operation */
  TCPCONN xConn = *pxConn;
  LONG lReturn =  -1;

  TCP_ASSERT_HI (pxTcp != NULL && pxConn != NULL);

  /* allow reuse of the port info if reuse address is set */
  if (FALSE == bIsReuseAllowed) {

    xConn.xId.wSrcPort = wPort;

    /* MUST Check that the port has not been used for the
            same IP address !!! */
#ifndef __TCP_OPT_ON__
    /* Go through the MBITMAP For Connecting Sockets */
    if ( 1024 <= wPort)
    {
      lReturn = MBITMAP_testAndSetIndex(pxTcp->portNumbers, wPort);
      if (( OK > lReturn ))
      {
        /*TCP_DBGP(NORMAL,"_TcpSetLocalPort:Error Conn %p While Setting [%d]\n", pxConn, wPort);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"_TcpSetLocalPort:Error Conn : 0x", (sbyte4)pxConn);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," While Setting Port :", wPort);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
        }
        return -1;
      }
      else
      {
        /*TCP_DBGP(NORMAL,"_TcpSetLocalPort: Conn %p Set [%d]\n", pxConn, wPort);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"_TcpSetLocalPort: Conn : 0x", (sbyte4)pxConn);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," Setting Port :", wPort);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
        }
        pxConn->xId.wSrcPort = wPort;
        return 0;

      }
    }

#endif
    /* First Go Through the Listening Ports and then Through the Coonnected Ports */
    DLLIST_head(&pxTcp->dllConns);
    if (DLLIST_find(&pxTcp->dllConns,(void *)&xConn,
                    _TcpLocalCmp) != NULL) {
#ifndef __TCP_OPT_ON__
      /* there is a match */
      /*TCP_DBGP(NORMAL,"_TcpSetLocalPort:Error Conn %p While Setting [%d] \n", pxConn, wPort);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4,"_TcpSetLocalPort:Error Conn : 0x",(sbyte4) pxConn," While Setting Port :0x", wPort);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
      }
#endif
      return -1;
    }

/* This will not be needed if using MBITMAP */
#if 0
#ifndef __TCP_OPT_ON__
    if (0 == _TcpLocalCompare(pxTcp,&xConn))
      /* there is a match */
      return -1;
#endif
#endif

  }

  pxConn->xId.wSrcPort = wPort;
  /*TCP_DBGP(NORMAL,"_TcpSetLocalPort: Conn %p Set [%d]\n", pxConn, wPort);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4,"_TcpSetLocalPort:Conn : 0x", (sbyte4)pxConn," Set Port :0x", wPort);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
  }
  return 0;
}

/*
 * _TcpFindNewLocalPort
 *  Finds a new local port in TCPCONN and checks for duplicate port/IP
 *
 *  Args:
 *   pxUdp                    TCP instance structure
 *   pxConn                   TCP connection structure
 *   wPort                    port id
 *  Return:
 *   0 port ok
 *  -1 all duplicates found
 */
static LONG _TcpFindNewLocalPort(TCPSTATE *pxTcp, TCPCONN *pxConn)
{
  DWORD dwNport;
  LONG lReturn = -1;

  TCP_ASSERT_HI (pxTcp != NULL && pxConn != NULL);

#ifndef __TCP_OPT_ON__
  lReturn = MBITMAP_findVacantIndex(pxTcp->portNumbers, &dwNport);
  if (OK > lReturn)
  {
    /*TCP_DBGP(NORMAL,"_TcpFindNewLocalPort:Error  Conn %p  [%d]\n", pxConn, lReturn);*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
    {
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"_TcpFindNewLocalPort: Error Conn : 0x", (sbyte4)pxConn);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," Error ", lReturn);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
      }
    return -1;
  }
  pxConn->xId.wSrcPort = dwNport;
  /*TCP_DBGP(NORMAL,"_TcpFindNewLocalPort: Conn %p Allocated [%d]\n", pxConn, dwNport);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"_TcpFindNewLocalPort: Conn : 0x", (sbyte4)pxConn);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," Allocated Port ", dwNport);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
  }
  lReturn = 0;
#else
  for (dwNport = TCP_USRPORT; dwNport <= TCP_MAXPORT; dwNport++) {
    if (_TcpSetLocalPort(pxTcp, pxConn, (WORD) dwNport, FALSE) == 0)
    {
      lReturn = 0;
      break;
    }
  }
#endif
  return lReturn;
}

/***************************************************************************
*  destroy the retransmission buffer
*
*  par:  control  ptr to the buffer control block
*
*  ret:  void
****************************************************************************/
static void _TcpClearRetransmissionBuffer(void *pxBuffv)
{
  TCP_RTX_BUF *pxBuff = (TCP_RTX_BUF *)pxBuffv;
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  TCPSTATE *pxTcp = NULL;
  MSTATUS status = OK;
#elif defined(__TCP_USE_MEMPOOL_PERF__)
  TCPCONN_CONNECT *pxTcp = NULL;
  MSTATUS status = OK;
#endif

  TCP_ASSERT_HI(pxBuff != NULL);

  NETPACKET_CHECK(&pxBuff->xNetPacket);
  NETPAYLOAD_DELUSER(pxBuff->xNetPacket.pxPayload);
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  pxTcp = (TCPSTATE *)pxBuff->hTcp;
#elif defined(__TCP_USE_MEMPOOL_PERF__)
  pxTcp = (TCPCONN_CONNECT *)pxBuff->hTcp;
#endif

#if defined(__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  TCP_ASSERT_HI(pxTcp != NULL);
  pxBuff->hTcp = NULL;
  if (OK > (status = MEM_POOL_putPoolObject(&pxTcp->retransPool, (void **)(&pxBuff))))
    DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpClearRetransmissionBuffer: unable to put buffer within retransPool Status = %d\n", status);
#else
  FREE(pxBuff);
#endif
}

/***************************************************************************
*  destroy the reassembly buffer
*
*  par:  pxBuffv    ptr to the buffer control block
*
*  ret:  void
****************************************************************************/
static void _TcpClearReassemblyBuffer(void *pxBuffv)
{
  TCP_RAS_BUF *pxBuff = (TCP_RAS_BUF *)pxBuffv;
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  TCPSTATE *pxTcp = NULL;
  MSTATUS status = OK;
#elif defined (__TCP_USE_MEMPOOL_PERF__)
  TCPCONN_CONNECT *pxTcp = NULL;
  MSTATUS status = OK;
#endif

  TCP_ASSERT_HI(pxBuff != NULL);

  NETPACKET_CHECK(&pxBuff->xNetPacket);
  NETPAYLOAD_DELUSER(pxBuff->xNetPacket.pxPayload);
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  pxTcp = (TCPSTATE *)pxBuff->hTcp;
#elif defined (__TCP_USE_MEMPOOL_PERF__)
  pxTcp = (TCPCONN_CONNECT *)pxBuff->hTcp;
#endif

#if defined(__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  TCP_ASSERT_HI(pxTcp != NULL);
  pxBuff->hTcp = NULL;
  if (OK > (status = MEM_POOL_putPoolObject(&pxTcp->reassemblePool, (void **)(&pxBuff))))
    DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpClearReassemblyBuffer: unable to put buffer within reassemblePool Status = %d\n", status);
#else
  FREE(pxBuff);
#endif
}

/***************************************************************************
*  destroy the sending buffer
*
*  par:  pxBuffv    ptr to the buffer control block
*
*  ret:  void
****************************************************************************/
static void _TcpClearSendingBuffer(void *pxBuffv)
{
  TCP_SND_BLK *pxBuff = (TCP_SND_BLK *) pxBuffv;
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  TCPSTATE *pxTcp = NULL;
  MSTATUS status = OK;
#elif defined (__TCP_USE_MEMPOOL_PERF__)
  TCPCONN_CONNECT *pxTcp = NULL;
  MSTATUS status = OK;
#endif

  TCP_ASSERT_HI(pxBuff != NULL);

  NETPACKET_CHECK(&pxBuff->xNetPacket);
  NETPAYLOAD_DELUSER(pxBuff->xNetPacket.pxPayload);
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  pxTcp = (TCPSTATE *)pxBuff->hTcp;
#elif defined(__TCP_USE_MEMPOOL_PERF__)
  pxTcp = (TCPCONN_CONNECT *)pxBuff->hTcp;
#endif

#if defined(__TCP_USE_MEMPOOL_NORMAL__) || defined(__TCP_USE_MEMPOOL_PERF__)
  TCP_ASSERT_HI(pxTcp != NULL);
  pxBuff->hTcp = NULL;
  if (OK > (status = MEM_POOL_putPoolObject(&pxTcp->sendbuffPool, (void **)(&pxBuff))))
    DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpClearSendingBuffer: unable to put buffer within sendbuffPool Status = %d\n", status);
#else
  FREE(pxBuff);
#endif

  return;
}

/*
 * _TcpConnFree
 *  Free a Connection pointer (casted as void * for DLLIST
 *  usage
 *
 *  Args:
 *   pxConn                       Conn pointer
 *
 *  Return:
 */
static void _TcpConnFree(void *pxConnv)
{
  TCPCONN *pxConn = (TCPCONN *)pxConnv;
  TCPCONN_CONNECT *pxConnect;
  TCPCONN_LISTEN *pxListen;
  TCPSTATE *pxTcp = (TCPSTATE *) pxConn->hTcp;

  TCPCONN_CHECK(pxConn);

  /*TCP_DBGP(NORMAL,"_TcpConnFree:[%ld] 0x%p\n", pxConn->lConnNo, pxConn);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4,"_TcpConnFree : 0x", pxConn->lConnNo," Conn :0x", (sbyte4)pxConn);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
  }

  if ((pxConn->oFlag & TCPCONN_FLAGMASK_MODE) ==
      TCPCONN_FLAGVALUE_MODECONNECT){
    /* Connect case */
    if ((pxConnect = pxConn->u.pxConnect) != NULL) {
#ifdef __TCP_USE_MEMPOOL_PERF__
      void *pTemp = NULL;
#endif
      clear_DLLIST(&pxConnect->dllSendBuff, _TcpClearSendingBuffer);

      clear_DLLIST(&pxConnect->dllReTxBuff, _TcpClearRetransmissionBuffer);

      clear_DLLIST(&pxConnect->dllReAsBuff, _TcpClearReassemblyBuffer);

#ifndef __TCP_OPT_ON__
      if (pxConnect->wPersistTimer)
          LIST_REMOVE(pxConn, persist_link);
      if (pxConnect->wLingerTimer)
          LIST_REMOVE(pxConn, linger_link);
      if (pxConnect->wReasmTimer)
          LIST_REMOVE(pxConn, reasm_link);
      if (pxConnect->wRetransmitTimer)
          LIST_REMOVE(pxConn, retrans_link);
      if (pxConnect->wFinwait2Timer)
          LIST_REMOVE(pxConn, finack2_link);
      if (pxConnect->wConestabTimer)
          LIST_REMOVE(pxConn, conestab_link);
      if (pxConnect->bDelayedAck)
          LIST_REMOVE(pxConn, fastack_link);
#endif /*__TCP_OPT_ON__*/
#ifdef __TCP_USE_MEMPOOL_PERF__
  if (OK <= MEM_POOL_uninitPool(&pxConnect->retransPool, &pTemp))
        FREE(pTemp);
  if (OK <= MEM_POOL_uninitPool(&pxConnect->reassemblePool, &pTemp))
        FREE(pTemp);
  if (OK <= MEM_POOL_uninitPool(&pxConnect->sendbuffPool, &pTemp))
        FREE(pTemp);
#endif
      FREE(pxConnect);
    }
  }
  else {
    /* Listen case */
    if ((pxListen = pxConn->u.pxListen) != NULL) {
      FREE(pxListen);
    }
  }

  DEBUG(pxConn->dwMagicCookie = 0);
#ifdef __TCP_USE_MEMPOOL__
  MEM_POOL_putPoolObject(&pxTcp->connPool, (void **)(&pxConnv));
#else
  FREE(pxConnv);
#endif
  return;
}

/*
 * _TcpConnClose
 *  Report close
 *
 *  Args:
 *   pxTxp                        Instance pointer
 *   pxConn                       Conn pointer
 *
 *  Return:
 */
static void _TcpConnClose(TCPSTATE *pxTcp, TCPCONN *pxConn)
{
  LONG lRc;

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);

  pxConn->eState = TCPCONN_STATE_CLOSED;

  /* send callback to socket */
  TCP_ASSERT_HI(pxConn->pfnCbk != NULL);
  lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                          (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                          TCPULINTERFACECBK_CLOSED,(H_NETDATA)0);

  /* if (lRc < 0) { */
    /* callback fail - destroy connection */
    lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                  (H_NETINTERFACE) pxConn);
  /* } */
}


/*
 * _TcpPassiveConnClose
 *  Change the state of the connection to close, without informing the user.
 *  Also, called as close for "PASSIVE OPEN"
 *
 *  Args:
 *   pxTxp                        Instance pointer
 *   pxConn                       Conn pointer
 *
 *  Return:
 */
static void _TcpPassiveConnClose(TCPSTATE *pxTcp, TCPCONN *pxConn)
{
  LONG lRc;

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);

  pxConn->eState = TCPCONN_STATE_CLOSED;

  /* send callback to socket */
  TCP_ASSERT_HI(pxConn->pfnCbk != NULL);
  lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                          (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                          TCPULINTERFACECBK_PASSIVECLOSE,(H_NETDATA)0);
  /*if (lRc < 0) {
     callback fail - destroy connection */
    lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                  (H_NETINTERFACE) pxConn);
  //}*/
}


/*
 * _TcpConnRst
 *  Report Rst
 *
 *  Args:
 *   pxTxp                        Instance pointer
 *   pxConn                       Conn pointer
 *
 *  Return:
 */
static void _TcpConnRst(TCPSTATE *pxTcp, TCPCONN *pxConn)
{
  LONG lRc;

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);

  pxConn->eState = TCPCONN_STATE_CLOSED;

  /* send callback to socket */
  TCP_ASSERT_HI(pxConn->pfnCbk != NULL);
  lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                          (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                          TCPULINTERFACECBK_RST,(H_NETDATA)0);
#if 0
  if (lRc < 0) {
    /* callback fail - destroy connection */
    lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                  (H_NETINTERFACE) pxConn);
  }
#endif
    lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                  (H_NETINTERFACE) pxConn);
}

/*
 * _TcpConnTimeout
 *  Report timeout
 *
 *  Args:
 *   pxTxp                        Instance pointer
 *   pxConn                       Conn pointer
 *
 *  Return:
 */
static void _TcpConnTimeout(TCPSTATE *pxTcp, TCPCONN *pxConn)
{
  LONG lRc;

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  TCP_ASSERT_HI(pxTcp->pfnNetFree);

  pxConn->eState = TCPCONN_STATE_CLOSED;

  /* send callback to socket */
  TCP_ASSERT_HI(pxConn->pfnCbk != NULL);
  lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                          (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                          TCPULINTERFACECBK_TIMEDOUT,(H_NETDATA)0);

#if 0
  if (lRc < 0) {
    /* callback fail - destroy connection */
    lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                  (H_NETINTERFACE) pxConn);
  }
#endif
    lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                  (H_NETINTERFACE) pxConn);
}

/*
 * _TcpGetPayload
 *  Gets NETPAYLOAD structure and buffer
 *
 *  Args:
 *   wSize                     Buffer size
 *
 *  Return:
 *      NETPAYLOAD *  OK
 *      NULL          Error
 */
static NETPAYLOAD *_TcpGetPayload(TCPSTATE *pxTcp,WORD wSize)
{
  NETPAYLOAD *pxPayload;
  OCTET *poPayload;

  TCP_CHECK_STATE(pxTcp);
  ASSERT(pxTcp->pfnNetFree && pxTcp->pfnNetMalloc && pxTcp->pxMutex);

  if ((poPayload = pxTcp->pfnNetMalloc(wSize)) == NULL) {
    /*TCP_DBGP(ERROR, "_TcpGetPayload: calloc() failed\n");*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
    {
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_TcpGetPayload: calloc() failed");
    }
    return NULL;
  }
  NETPAYLOAD_CREATE(&pxPayload,pxTcp->pfnNetFree,pxTcp->pxMutex, poPayload, wSize);
  if (pxPayload == NULL) {
    /*TCP_DBGP(ERROR, "_TcpGetPayload: NETPAYLOAD_CREATE failed\n");*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_TcpGetPayload: NETPAYLOAD_CREATE failed ");
#ifdef __INET_USE_PAYLOAD_MEMPOOL__
    NetFree(poPayload);
#else
    (*pxTcp->pfnNetFree)(poPayload);
#endif
    return NULL;
  }
  return pxPayload;
}

#if 0
/*
* _TcpGetOffsetTrailer
*  this function gets offset and trailer for a given connection
*  par:  pxTcp ptr to TCPSTATE
*    pxCONN   ptr to TCPCONN
*    *wOffset  returned offset
*    *wTrailer returned trailer
*
*  ret:   0  OK
*       -1  index not found
****************************************************************************/
static LONG _TcpGetOffsetTrailer(TCPSTATE *pxTcp, TCPCONN *pxConn,
                  WORD *pwOffset, WORD *pwTrailer)
{
  void *pvIndex;
  long lRc = 0;

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  TCP_ASSERT_HI(pwOffset != NULL && pwTrailer != NULL);

  /* first get offset using interface index */
  if ((pvIndex = DLLIST_find(pxTcp->pDllOffsets,
                    (void *)((DWORD)pxConn->oIfIdx), _TcpFindItemByIndex))
    != NULL) {
    *pwOffset = ((DWORD) pvIndex) & 0xFFFF;
  }
  else {
    lRc = -1;
  }
  /* now get trailer */
  if ((pvIndex = DLLIST_find(pxTcp->pDllTrailers,
                    (void *)((DWORD)pxConn->oIfIdx), _TcpFindItemByIndex))
    != NULL) {
    *pwTrailer = ((DWORD) pvIndex) & 0xFFFF;
  }
  else {
    lRc = -1;
  }
  return lRc;
}
#endif
/*
* _TcpGetEmptyPacket
*  this function sets up an empty NETPACKET
*
*  par:  pxTcp ptr to the TCPSTATE
*    pxConn    ptr to the TCPCONN
*    pxPacket  ptr to the NETPACKET
*    pxAccess  ptr to the NETPACKETACCESS
*    wOptLen   Option length, in octets
*
*  Note: to be consistent with packets passed down from the socket, this
*  procedure sets pxAccess->wOffset to point to the start of the (empty)
*  application data, and pxAccess->length to be 0. The allows the code in
*  _TcpConnSendSegment() to write the TCP header into the correct place.
*  The length of the tcp options must be a multiple of 4. If an option is
*  less than 4 octets in length, then the options field can be padded with
*  TCP_OPT_NOOP [==1] to the correct length.
*
*  ret:  0   OK
*      -1   No buffer
****************************************************************************/
static LONG _TcpGetEmptyPacket(TCPSTATE *pxTcp, TCPCONN *pxConn,
                  NETPACKET *pxPacket, NETPACKETACCESS *pxAccess, WORD wOptLen)
{
  NETPAYLOAD *pxPayload;
  WORD wBufLen;
  /*WORD wTrailer; */
#ifdef IPSEC
  void* pxSP=NULL;              /* pointer for Security Policy data structure */
  int nHdrLen=0;
  int nTrailLen=0;
#endif /* IPSEC */

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  TCP_ASSERT_HI(pxPacket != NULL && pxAccess != NULL);

  wBufLen = pxTcp->wOffset+ (WORD)sizeof(TCPHDR) + pxTcp->wTrailer + wOptLen;

#ifdef IPSEC
  /* check security policy */
  if ((pxSP = IPSecGetSP(pxConn->xId.xNetId.dwDstIpAddr, pxConn->xId.wDstPort,
                         pxConn->xId.xNetId.dwSrcIpAddr, pxConn->xId.wSrcPort,
                         IPPROTO_TCP, 0))) {
    /* allocate header space for AH or ESP */
    nHdrLen = IPSecGetHdrLen(pxSP);
    /* allocate more space for ESP trailer and ESP-Auth */
    nTrailLen = IPSecGetTrailLen(pxSP,TCPDEFAULT_HDRSIZE);
    wBufLen += (nHdrLen + nTrailLen);
    /* store IPSec data into NETWORKID */
    pxConn->xId.xNetId.dwSecurityPolicy =  (DWORD)pxSP;
    pxConn->xId.xNetId.wIpSecHdrLength =   (WORD)nHdrLen;
    pxConn->xId.xNetId.wIpSecTrailLength = (WORD)nTrailLen;
  }
#endif /* IPSEC */

  pxPayload = _TcpGetPayload(pxTcp,wBufLen);
  if (pxPayload == NULL) {
    /*TCP_DBGP(ERROR, "_TcpGetEmptyPacket:_TcpGetPayload() failed\n");*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_TcpGetEmptyPacket:_TcpGetPayload() failed");
    return -1;
  }
#ifdef IPSEC
  pxAccess->wOffset = pxTcp->wOffset + sizeof(TCPHDR) + wOptLen + nHdrLen;
#else /* #ifdef IPSEC */
  pxAccess->wOffset = pxTcp->wOffset + sizeof(TCPHDR) + wOptLen;
#endif /* #ifdef IPSEC #else */

  pxAccess->wLength = 0;

  /* set up NETPACKET */
  pxPacket->pxPayload = pxPayload;
  pxPacket->hMarker = (H_NETDATA)pxConn->hUL;

  return 0;
}

/*
 * _TcpSetPersist
 *  Sets the persist timer
 *
 *  Args:
 *   pxConnect                        ptr to the TCPCONN_CONNECT
 *
 *  Return:
 *   None
 */
static void _TcpSetPersist(TCPCONN_CONNECT *pxConnect)
{
  TCPSTATE *pxTcp = NULL;
  TCPCONN  *pxConn = NULL;
  TCP_ASSERT_HI(pxConnect != NULL);
  pxTcp = (TCPSTATE *) pxConnect->hTcp;
  TCP_ASSERT_HI(pxTcp != NULL);
  pxConn = (TCPCONN *)pxConnect->hConn;

#ifndef __TCP_OPT_ON__
  if (pxConnect->wPersistTimer )
    LIST_REMOVE(pxConn, persist_link);
#endif /* __TCP_OPT_ON__*/

  /* the Rto uses 1 ms ticks, so divide by 500 to get slow ticks */
  pxConnect->wPersistTimer = min(TCP_PER_UBOUND,max(TCP_PER_LBOUND,
      (pxConnect->dwRto/500) * (1<<pxConnect->oPersistCount)));

#ifndef __TCP_OPT_ON__
  /* Convert it to Actual  Ticks */
  pxConnect->wPersistTimer = pxConnect->wPersistTimer * 500 +  pxTcp->dwTicks;
  _TcpInsertOrderedList (&pxTcp->lPersistList,
                         pxConn,
                         TCP_TIMER_PERSIST);

#endif /* __TCP_OPT_ON__*/
}

/***************************************************************************
*  when a segement has been putted in the output buffer, the buffer control block
*  hast to carried into the retransmission buffer
*
*  par:  pxConn        ptr to the TCPCONN
*      block      ptr to the data block
*      poBuf      ptr to the data in the sended segment
*      wLen       OCTETs of buf
*      dwSeq      sequece nbr of the first byte in this segment
*      oFlags      the flags of this segment
*      dwTimestamp   time in enet_ticks
*      oRetries      nbr of retries
*
*  ret:  0        success
*    -1        error
****************************************************************************/
static LONG _TcpAddToRetransmissionBuffer(TCPCONN_CONNECT *pxConnect,
                                          NETPACKET *pxPacket,
                                          NETPACKETACCESS *pxAccess,
                                          DWORD dwSeq, OCTET oFlags,
                                          DWORD dwTimestamp, OCTET oRetries)
{
  TCP_RTX_BUF *pxRtxBuff;
  TCPCONN *pxConn = NULL;
  TCPSTATE *pxTcp = NULL;
#ifndef __TCP_OPT_ON__
  LONG        lMinReTxTime ;
  LONG        lMaxReTxTime ;
#endif
#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  MSTATUS mStatus;
#endif

  TCP_ASSERT_HI(pxConnect != NULL && pxAccess != NULL);
  NETPACKET_CHECK(pxPacket);

  pxConn = (TCPCONN *) pxConnect->hConn;
  pxTcp = (TCPSTATE *) pxConnect->hTcp;

#ifndef __TCP_OPT_ON__
  lMinReTxTime = pxTcp->dwTicks + (500) ;
  lMaxReTxTime = lMinReTxTime;
#endif

  /*TCP_DBGP(REPETITIVE,"_TcpAddToRetransmissionBuffer: Seq=%ld, Flags=0x%x, Timestamp=%ld, Retries=%d\n",
           dwSeq, oFlags, dwTimestamp, oRetries);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
  {
      DEBUG_PRINT(DEBUG_MOC_IPV4,"_TcpAddToRetransmissionBuffer :Seq= ");
      DEBUG_INT(DEBUG_MOC_IPV4,dwSeq);
      DEBUG_PRINT(DEBUG_MOC_IPV4,", Flags= 0x");
      DEBUG_HEXINT(DEBUG_MOC_IPV4,oFlags);
      DEBUG_PRINT(DEBUG_MOC_IPV4,", Timestamp= ");
      DEBUG_INT(DEBUG_MOC_IPV4,dwTimestamp);
      DEBUG_PRINT(DEBUG_MOC_IPV4,", Retries= ");
      DEBUG_INT(DEBUG_MOC_IPV4,oRetries);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }

  /* save only segments when len>0 or FIN/SYN Flags is set */
  if (pxAccess->wLength == 0) {
    if(!((oFlags & TCPCONN_FLAGMASK_SYN) || (oFlags & TCPCONN_FLAGMASK_FIN))) {
      /* this packet needs not to be resent */
      /* only SYN or FIN ocopy seqence number space */
      /*TCP_DBGP(REPETITIVE, "_TcpAddToRetransmissionBuffer: sending Not SYN Not FIN need not be resent **\n");*/
       if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
           DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_TcpAddToRetransmissionBuffer: sending Not SYN Not FIN need not be resent **\n");
      /* not going on queue so delete count now */
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      return 0;
    }
  }
  if(oRetries > 0) {
    /*segment is still in the retransmission queue -> update entry*/
    DLLIST_head(&pxConnect->dllReTxBuff);
    while ((pxRtxBuff = (TCP_RTX_BUF *) DLLIST_read(&pxConnect->dllReTxBuff)) != NULL) {
      NETPACKET_CHECK(&pxRtxBuff->xNetPacket);
      if (pxRtxBuff->dwSequenceNbr == dwSeq) {
        pxRtxBuff->dwTimeStamp=dwTimestamp;
        pxRtxBuff->oRetries++;
      }
#ifndef __TCP_OPT_ON__
      /* Calculate the Max Time that we can wait for the Retransmit Timer
         but minimum of dwTicks + 500 ms*/
      lMinReTxTime =  pxRtxBuff->dwTimeStamp +   (1 << (pxRtxBuff->oRetries - 1)) * pxConnect->dwRto;
      if (_TcpBefore(lMinReTxTime , lMaxReTxTime))
        lMinReTxTime = lMaxReTxTime;
#endif
      DLLIST_next(&pxConnect->dllReTxBuff);
    }
#ifndef __TCP_OPT_ON__
    if (pxConnect->wRetransmitTimer)
      LIST_REMOVE(pxConn, retrans_link);

    pxConnect->wRetransmitTimer = lMinReTxTime;
    _TcpInsertOrderedList (&pxTcp->lRetransList,
                            pxConn,
                            TCP_TIMER_RETRANS);
#endif
    return 1;
  }

  /* add an entry in the retransmission buffer */
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  if(OK > (mStatus = MEM_POOL_getPoolObject(&pxTcp->retransPool, (void **) &pxRtxBuff)))
#elif defined (__TCP_USE_MEMPOOL_PERF__)
  if(OK > (mStatus = MEM_POOL_getPoolObject(&pxConnect->retransPool, (void **) &pxRtxBuff)))
#endif

#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  {
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: _TcpAddToRetransmissionBuffer: unable to allocate buffer");
    return -1;
  }
#else
  pxRtxBuff = (TCP_RTX_BUF *)MALLOC(sizeof(TCP_RTX_BUF));
  if(pxRtxBuff == NULL) {
    /*TCP_DBGP(ERROR, "_TcpAddToRetransmissionBuffer:calloc() failed\n");*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_TcpAddToRetransmissionBuffer:calloc() failed");
    return -1;
  }
#endif
  MOC_MEMSET((ubyte *)pxRtxBuff, 0, sizeof(TCP_RTX_BUF));

#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  pxRtxBuff->hTcp = (H_NETINSTANCE)pxTcp;
#elif defined (__TCP_USE_MEMPOOL_PERF__)
  pxRtxBuff->hTcp = (H_NETINSTANCE)pxConnect;
#endif

  DLLIST_append(&pxConnect->dllReTxBuff, pxRtxBuff);


  /*data need not to be copied - only pointers must be transferred*/
  pxRtxBuff->dwSequenceNbr = dwSeq;
  pxRtxBuff->oFlags        = oFlags;
  pxRtxBuff->dwTimeStamp   = dwTimestamp;
  pxRtxBuff->oRetries      = 1;

  MOC_MEMCPY((ubyte *)&pxRtxBuff->xNetPacket,
                (ubyte *)pxPacket,
                sizeof(NETPACKET));

  MOC_MEMCPY((ubyte *)&pxRtxBuff->xAccess,
                (ubyte *)pxAccess,
              sizeof(NETPACKETACCESS));

#ifndef __TCP_OPT_ON__
  if (pxConnect->wRetransmitTimer)
      LIST_REMOVE(pxConn, retrans_link);
/* Min Possible Time , i.e slow Timeout */
  pxConnect->wRetransmitTimer = pxTcp->dwTicks + 500;
  _TcpInsertOrderedList (&pxTcp->lRetransList,
                          pxConn,
                          TCP_TIMER_RETRANS);
#endif

  /*TCP_DBGP(REPETITIVE,"_TcpAddToRetransmissionBuffer: adding (AL) 0x%lx->0x%lx->0x%lx for seg len =%ld\n",
                    (DWORD)pxRtxBuff,(DWORD)pxPacket,
                    (DWORD)pxRtxBuff->xNetPacket.pxPayload,
                    (DWORD)pxRtxBuff->xAccess.wLength);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
  {
      DEBUG_PRINT(DEBUG_MOC_IPV4,"_TcpAddToRetransmissionBuffer: adding (AL) 0x");
      DEBUG_HEXINT(DEBUG_MOC_IPV4, (DWORD)pxRtxBuff);
      DEBUG_PRINT(DEBUG_MOC_IPV4,"->0x");
      DEBUG_HEXINT(DEBUG_MOC_IPV4, (DWORD)pxPacket);
      DEBUG_PRINT(DEBUG_MOC_IPV4,"->0x");
      DEBUG_HEXINT(DEBUG_MOC_IPV4, (DWORD)pxRtxBuff->xNetPacket.pxPayload);
      DEBUG_PRINT(DEBUG_MOC_IPV4,"for seg len =  ");
      DEBUG_INT(DEBUG_MOC_IPV4, (DWORD)pxRtxBuff->xAccess.wLength);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
  }
  return 0;
}

/*
 * _TcpConnSendSegment
 *  this function generates and puts a TCP segment in the output buffers,
 *  if enabled, a piggybacked piece of data is taken from the sending buffer
 *
 *  par:  pxTcp ptr to the TCPSTATE
 *    pxCONN     ptr to the TCPCONN
 *    dwSeq    the sequencenbr in the TCP header
 *    dwAck    the acknowledgenumber in the TCP header
 *    oCtl    the control flags in the TCP header
 *    bEnableDataSend  DATAON  a piece of data ist packed into the segment
 *          NODATA  only the TCP header would be send
 *
 *  ret:  void
 ****************************************************************************/
static void _TcpConnSendSegment(TCPSTATE *pxTcp, TCPCONN *pxConn,
                  DWORD dwSeq, DWORD dwAck, OCTET oCtl, BOOL bEnableDataSend)
{
  OCTET oFlags=0;
  BOOL bFinStateAfterTransmit=0;

  TCPHDR *pxTcpHeader;
  TCPPSH *pxTcpPseudoHeader;

  OCTET *poDataToSend=NULL;
  WORD wDataToSendLen=0, wOptLen=0;
  DWORD dwSendWindow;
  OCTET oRetries=0;
  BOOL bPushRequested=0;
  TCP_SND_BLK *pxSndBlk;
  NETPACKET xPacket;
  NETPACKETACCESS xAccess;
  NETPAYLOAD *pxPayload;
  OCTET *poOptions;
  TRANSPORT2NETWORKID *pxConnNetId;
  WORD  rxWin;
#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  MSTATUS status = OK;
#endif

  TCPCONN_CONNECT *pxConnect;
  LONG lRc;

  /* Set each tcp option off to begin with */
#if 0
  BOOL  bTcpOptions_WSF  = TCP_OPT_OFF,
        bTcpOptions_TMST = TCP_OPT_OFF;
#endif
  BOOL  bTcpOptions_MSS  = TCP_OPT_OFF;


#ifdef IPSEC
  void* pxSP=NULL;              /* pointer for Security Policy data structure */
  int nHdrLen=0;
  int nTrailLen=0;
#endif /* IPSEC */

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  pxConnect = pxConn->u.pxConnect;
  TCP_ASSERT_HI(pxConnect != NULL);
  pxConnNetId = &(pxConn->xId.xNetId);

#ifndef NDEBUG
  xAccess.wOffset = 0;
  xAccess.wLength = 0;
#endif

  /*TCP_DBGP(REPETITIVE,
           "_TcpConnSendSegment: pxConn=0x%p, seq=%ld, ack=%ld, oCtl=0x%x, bEnableDataSend=%d\n",
           pxConn, dwSeq, dwAck, oCtl, bEnableDataSend);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
  {
      DEBUG_PRINT(DEBUG_MOC_IPV4, "_TcpConnSendSegment: pxConn=0x");
      DEBUG_HEXINT(DEBUG_MOC_IPV4, (sbyte4)pxConn);
      DEBUG_PRINT(DEBUG_MOC_IPV4, ", seq= ");
      DEBUG_INT(DEBUG_MOC_IPV4, dwSeq);
      DEBUG_PRINT(DEBUG_MOC_IPV4, ", ack= ");
      DEBUG_INT(DEBUG_MOC_IPV4, dwAck);
      DEBUG_PRINT(DEBUG_MOC_IPV4, ", oCtl= 0x");
      DEBUG_HEXINT(DEBUG_MOC_IPV4, oCtl);
      DEBUG_PRINT(DEBUG_MOC_IPV4, ", bEnableDataSend= ");
      DEBUG_INT(DEBUG_MOC_IPV4, bEnableDataSend);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  CHECKPOINT(g_dwTcpConnSendSegmentLine);

  SNMP( xTcpipData.tcpOutSegs++ );
  SNMP( if (oCtl&TCPCONN_FLAGMASK_RST) xTcpipData.tcpOutRsts++ );

  /*Is it possible to send Data within this segment ?*/
  if(bEnableDataSend) {

    CHECKPOINT(g_dwTcpConnSendSegmentLine);
    DLLIST_head(&(pxConnect->dllSendBuff));

    CHECKPOINT(g_dwTcpConnSendSegmentLine);
    pxSndBlk = DLLIST_read(&(pxConnect->dllSendBuff));

    CHECKPOINT(g_dwTcpConnSendSegmentLine);
    /*is there data to send ?*/
    if(pxSndBlk) {
      /*if there are flags - this MUST be a to retransmitt segment*/
      CHECKPOINT(g_dwTcpConnSendSegmentLine);
      NETPACKET_CHECK(&(pxSndBlk->xNetPacket));
      oFlags = pxSndBlk->oFlags;
      bFinStateAfterTransmit = pxSndBlk->bFinStateAfterTransmit;
      CHECKPOINT(g_dwTcpConnSendSegmentLine);
      SNMP(
        if (oFlags) {
          xTcpipData.tcpRetransSegs++;
          xTcpipData.tcpOutSegs--;
        }
      );
      if (oFlags) {
         pxConn->wTxRetransSegs++;
         _TcpCheckTxErrs(pxConn);
      }


      CHECKPOINT(g_dwTcpConnSendSegmentLine);

      /* if we are executing the persist probe send 1 byte */
      if (pxConnect->bForce1Byte) {
        CHECKPOINT(g_dwTcpConnSendSegmentLine);
        dwSendWindow = 0;
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Force 1 Byte Being Sent");
      }
      else {
        CHECKPOINT(g_dwTcpConnSendSegmentLine);
        dwSendWindow = pxConnect->dwSendWindow;
        /* check to see if we need to start the persist timer */
        if (dwSendWindow == 0 && pxConnect->wPersistTimer == 0) {
          pxConnect->oPersistCount = 0;
          CHECKPOINT(g_dwTcpConnSendSegmentLine);
          _TcpSetPersist(pxConnect);
        }
      }
      CHECKPOINT(g_dwTcpConnSendSegmentLine);

      /*determine the max. datalen for this segment*/
#ifdef IPSEC
      /* check security policy */
      if ((pxSP = IPSecGetSP(pxConnNetId->dwDstIpAddr, pxConn->xId.wDstPort,
                             pxConnNetId->dwSrcIpAddr, pxConn->xId.wSrcPort,
                             IPPROTO_TCP, 0))) {
        /* allocate header space for AH or ESP */
        nHdrLen = IPSecGetHdrLen(pxSP);
        /* allocate more space for ESP trailer and ESP-Auth */
        nTrailLen = IPSecGetTrailLen(pxSP,TCPDEFAULT_HDRSIZE);
        /* store IPSec data into TRANSPORT2NETWORKID */
        pxConnNetId->dwSecurityPolicy = (DWORD)pxSP;
        pxConnNetId->wIpSecHdrLength = (WORD)nHdrLen;
        pxConnNetId->wIpSecTrailLength = (WORD)nTrailLen;
      }
      wDataToSendLen = min3(pxSndBlk->wDatalen - pxSndBlk->wSent,
                            dwSendWindow - nHdrLen - nTrailLen,
                            pxConn->wMss - nHdrLen - nTrailLen);
#else /* #ifdef IPSEC */
      wDataToSendLen = min3(pxSndBlk->wDatalen - pxSndBlk->wSent,
          dwSendWindow, pxConn->wMss);
#endif /* #ifdef IPSEC #else */


      if ((wDataToSendLen > 0) || (oFlags & (TCPCONN_FLAGMASK_SYN | TCPCONN_FLAGMASK_FIN))) {
        /* if there is only one segment to send out of this buffer, we
          can just send the existing NETPAYLOAD and put it on the
          retransmission list. If not, we must allocate a new NETPAYLOAD
          for each segment.
         */

        CHECKPOINT(g_dwTcpConnSendSegmentLine);

        MOC_MEMCPY((ubyte *)&xPacket,
                      (ubyte *)&pxSndBlk->xNetPacket,
                      sizeof(xPacket));

        MOC_MEMCPY((ubyte *)&xAccess,
                      (ubyte *)&pxSndBlk->xAccess,
                      sizeof(xAccess));

        CHECKPOINT(g_dwTcpConnSendSegmentLine);

        poDataToSend = pxSndBlk->poNextToSendData;

        CHECKPOINT(g_dwTcpConnSendSegmentLine);

        if (pxSndBlk->wSent == 0  /* i.e. first segment out of buffer */
          && wDataToSendLen == pxSndBlk->wDatalen /* the whole buffer */ ) {
         /* do nothing - already set up */
        }
        else {
          /* must get another buffer for the segment!
             must retain header+trailer size from buffer
          */
          CHECKPOINT(g_dwTcpConnSendSegmentLine);
          pxPayload = _TcpGetPayload(pxTcp,wDataToSendLen +
                                     xPacket.pxPayload->wSize -
                                     pxSndBlk->wDatalen);
          if (pxPayload == NULL) {
            CHECKPOINT(g_dwTcpConnSendSegmentLine);
            /*TCP_DBGP(ERROR, "_TcpConnSendSegment:_TcpGetPayload() failed\n");*/
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
                DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_TcpConnSendSegment:_TcpGetPayload() failed");
            return;
          }
          CHECKPOINT(g_dwTcpConnSendSegmentLine);
      pxConn->wTxMemCopies++;
          MOC_MEMCPY((ubyte *)(pxPayload->poPayload+xAccess.wOffset),
                  (ubyte *) poDataToSend, wDataToSendLen);
          xPacket.pxPayload = pxPayload;
          xAccess.wLength = wDataToSendLen;
          /* If the pxSndBlk is completely used up after fragmentation
             Free the NetPayload */
          if (pxSndBlk->wSent + wDataToSendLen == pxSndBlk->wDatalen)
              NETPAYLOAD_DELUSER(pxSndBlk->xNetPacket.pxPayload);

        }

        CHECKPOINT(g_dwTcpConnSendSegmentLine);
        pxSndBlk->poNextToSendData += wDataToSendLen;
        pxSndBlk->wSent+=wDataToSendLen;

        CHECKPOINT(g_dwTcpConnSendSegmentLine);

      }

      /* execute the following for any value of wDataToSendLen */
      oRetries=pxSndBlk->oRetries;

      CHECKPOINT(g_dwTcpConnSendSegmentLine);

      /*is this the last segment sending out of this buffer block ?*/
      if (pxSndBlk->wSent == pxSndBlk->wDatalen) {

        CHECKPOINT(g_dwTcpConnSendSegmentLine);
        if (oRetries == 0) {
          CHECKPOINT(g_dwTcpConnSendSegmentLine);
          bPushRequested=1;
        }
        CHECKPOINT(g_dwTcpConnSendSegmentLine);

        /*remove this buffer block from the sending queue*/
        /*TCP_DBGP(REPETITIVE,"_TcpConnSendSegment:[%ld] 0x%p: DLLIST_remove: send pxPacket 0x%p\n",
                 pxConn->lConnNo, pxConn, &xPacket);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINT(DEBUG_MOC_IPV4,"_TcpConnSendSegment:[");
            DEBUG_INT(DEBUG_MOC_IPV4,pxConn->lConnNo);
            DEBUG_PRINT(DEBUG_MOC_IPV4,"]: 0x");
            DEBUG_HEXINT(DEBUG_MOC_IPV4,(sbyte4)pxConn);
            DEBUG_PRINT(DEBUG_MOC_IPV4," DLLIST_remove: send pxPacket 0x");
            DEBUG_HEXINT(DEBUG_MOC_IPV4,(sbyte4)&xPacket);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }

        DLLIST_remove(&pxConnect->dllSendBuff);
#if defined(__TCP_USE_MEMPOOL_NORMAL__)
        pxSndBlk->hTcp = NULL;
        if(OK > (status = MEM_POOL_putPoolObject(&pxTcp->sendbuffPool, (void **)(&pxSndBlk))))
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
              DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpConnSendSegment: unable to put buffer within sendbuffPool Status = %d\n", status);
#elif defined (__TCP_USE_MEMPOOL_PERF__)
        pxSndBlk->hTcp = NULL;
        if (OK > (status = MEM_POOL_putPoolObject(&pxConnect->sendbuffPool, (void **)(&pxSndBlk))))
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
              DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpConnSendSegment: unable to put buffer within sendbuffPool Status = %d\n", status);
#else
        FREE(pxSndBlk);
#endif
        CHECKPOINT(g_dwTcpConnSendSegmentLine);

      }
    } else {
      /*pxSndBlk == NULL*/
    }
  }


  {
    OCTET oCheck;

    oCheck = (oFlags == 0) ? (oCtl) : (oFlags);

    /* switch options on, and define the option length */
    if (oCheck & TCPCONN_FLAGMASK_SYN) {
      bTcpOptions_MSS  = TCP_OPT_ON;
      wOptLen += 4;
#if 0
      bTcpOptions_WSF  = TCP_OPT_ON;
      wOptLen += 4;
      bTcpOptions_TMST = TCP_OPT_ON;
      wOptLen += 12;
#endif
    }
  }


  CHECKPOINT(g_dwTcpConnSendSegmentLine);
  /* if control only segment, we must get a payload with proper offset
     and trailer
   */
  if (poDataToSend == NULL){
    CHECKPOINT(g_dwTcpConnSendSegmentLine);

    lRc = _TcpGetEmptyPacket(pxTcp, pxConn, &xPacket, &xAccess, wOptLen);

    CHECKPOINT(g_dwTcpConnSendSegmentLine);
    if (lRc < 0) {
      CHECKPOINT(g_dwTcpConnSendSegmentLine);
      /*TCP_DBGP(ERROR, "_TcpConnSendSegment:_TcpGetEmptyPacket() failed\n");*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_TcpConnSendSegment:_TcpGetEmptyPacket() failed");
      return;
    }
  }

  CHECKPOINT(g_dwTcpConnSendSegmentLine);

  NETPACKET_CHECK(&xPacket);
  TCP_ASSERT_HI(xAccess.wOffset >= sizeof(TCPPSH) + sizeof(TCPHDR) &&
         ((int)xAccess.wOffset % sizeof(int)) == 0);/*possibly need to add wOptLen to sizeof(TCPHDR) */

  /*create TCP Header*/
  pxTcpHeader = (TCPHDR *)(xPacket.pxPayload->poPayload +
                           xAccess.wOffset - sizeof(TCPHDR) - wOptLen);
  /*create Pseudo TCP Header - not to be sended - only for checksum*/
  pxTcpPseudoHeader = (TCPPSH*)((OCTET*)pxTcpHeader - sizeof(TCPPSH));

  pxTcpPseudoHeader->dwSrcIP = htonl(pxConnNetId->dwSrcIpAddr);
  pxTcpPseudoHeader->dwDstIP = htonl(pxConnNetId->dwDstIpAddr);
  pxTcpPseudoHeader->oProt = IPPROTO_TCP;
  pxTcpPseudoHeader->wLen = htons(sizeof(TCPHDR) + wOptLen + wDataToSendLen);
  pxTcpPseudoHeader->oNull = 0;
  pxTcpHeader->wSrcPort=htons(pxConn->xId.wSrcPort);/*ARR */
  pxTcpHeader->wDstPort=htons(pxConn->xId.wDstPort);/*ARR */
  pxTcpHeader->dwSequencenumber=htonl(dwSeq);
  pxTcpHeader->dwAcknowledgenumber=htonl(dwAck);
  pxTcpHeader->wChecksum=0;
  pxTcpHeader->wUrgent=0;

  if (pxConnect->wRxUsedSpace <= pxConn->wWin) {
    pxTcpHeader->wWindowsize = htons(pxConn->wWin - pxConnect->wRxUsedSpace);
    /* Application can Adjust Window Size for Async */
    if (pxConn->dwAppWinFactor < 100)
    {
      rxWin = htons( pxTcpHeader->wWindowsize );
      rxWin = rxWin * ( pxConn->dwAppWinFactor / 100.0 );
      pxTcpHeader->wWindowsize = htons (rxWin);
    }
  } else {
    pxTcpHeader->wWindowsize = 0;
  }
#ifdef TCPSECURE
  pxConnect->dwMaxSendWindowSize = max(pxConnect->dwMaxSendWindowSize,
                    ntohs(pxTcpHeader->wWindowsize));
#endif

  poOptions = (OCTET *)pxTcpHeader + sizeof(TCPHDR);

  /* Fill out MSS option, if enabled */
  if (bTcpOptions_MSS) {
    poOptions[0] = TCP_OPT_MSS;
    poOptions[1] = 4;
    *((WORD *)(poOptions+2)) = htons(pxConn->wLocalMss);
    poOptions += 4;
  }

#if 0
  if (bTcpOptions_WSF)
  {
    poOptions[0] = TCP_OPT_NOOP;
    poOptions[1] = TCP_OPT_WSF;
    poOptions[2] = 3;
    poOptions[3] = 0; /*shift count - 0 has no effect. */
    poOptions += 4;
  }

  if (bTcpOptions_TMST)
   {
    poOptions[0] = TCP_OPT_NOOP;
    poOptions[1] = TCP_OPT_NOOP;
    poOptions[2] = TCP_OPT_TMST;
    poOptions[3] = 10;
    *((DWORD *)(poOptions+4)) = htonl(12345); /*timestamp value */
    *((DWORD *)(poOptions+8)) = htonl(67890); /*timestamp echo reply */
    poOptions += 8;
  }
#endif

  pxTcpHeader->oTcpHdrLen=(sizeof(TCPHDR) + wOptLen)<<2;

  CHECKPOINT(g_dwTcpConnSendSegmentLine);

  if (bPushRequested) {
    CHECKPOINT(g_dwTcpConnSendSegmentLine);
    if (bFinStateAfterTransmit == 1) {
      pxTcpHeader->oFlags=oCtl | TCPCONN_FLAGMASK_FIN;
      pxConnect->dwSendNext+=1;
      CHECKPOINT(g_dwTcpConnSendSegmentLine);
      switch (pxConn->eState) {
      case TCPCONN_STATE_CLOSE_WAIT:
        /*TCP_DBGP(REPETITIVE,"_TcpConnSendSegment:[%ld] 0x%p: CLOSE_WAIT->LAST_ACK\n", pxConn->lConnNo, pxConn);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpConnSendSegment:[", pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] CLOSE_WAIT->LAST_ACK : 0x", (sbyte4)pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }
        pxConn->eState = TCPCONN_STATE_LAST_ACK;
        CHECKPOINT(g_dwTcpConnSendSegmentLine);
        break;
      case TCPCONN_STATE_ESTABLISHED:
        /*TCP_DBGP(REPETITIVE,"_TcpConnSendSegment:[%ld] 0x%p: ESTABLISHED->FIN_WAIT_1\n", pxConn->lConnNo, pxConn);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpConnSendSegment:[", pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] ESTABLISHED->FIN_WAIT_1 : 0x",(sbyte4) pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }
        pxConn->eState = TCPCONN_STATE_FIN_WAIT_1;
        CHECKPOINT(g_dwTcpConnSendSegmentLine);
        break;
      default:
        break;
      }
    }
    else {
      pxTcpHeader->oFlags=oCtl | TCPCONN_FLAGMASK_PSH;
    }
  }
  else {
    pxTcpHeader->oFlags=oCtl;
  }


  CHECKPOINT(g_dwTcpConnSendSegmentLine);
  /*flags are ONLY be stored in the sending buffer on a
    RETRANSMISSION SEGMENT, so use them */
  if ( oFlags ) {
    /*use the flags stored*/
    CHECKPOINT(g_dwTcpConnSendSegmentLine);
    pxTcpHeader->oFlags = oFlags;
  }
  else {
    /*advance the send sequence nbr to the beginning of the next to send packet */
    /*do NOT increase snd_nxt on retransmission segements (these seq nbrs have already been count) */
    pxConnect->dwSendNext+=wDataToSendLen;
  }

  CHECKPOINT(g_dwTcpConnSendSegmentLine);

  /*generate TCP checksum including the pseudoheader*/
  pxTcpHeader->wChecksum = Checksum16((OCTET*)pxTcpPseudoHeader,sizeof(TCPPSH) + ntohs(pxTcpPseudoHeader->wLen) );

  /*TCP_DBGP(REPETITIVE,"_TcpConnSendSegment:[%ld] 0x%p: Send data segment len=%d\n",
                      pxConn->lConnNo, pxConn, wDataToSendLen);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpConnSendSegment:[", pxConn->lConnNo);
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] Send Data Segment : 0x",(sbyte4) pxConn);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," len =  : ", wDataToSendLen);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
  }
  /*Now the TCP segment is ready for take off*/
  SNMP(xTcpipData.ifNum[ETH_SNMP_IF_NUM].ifOutUcastPkts++);

  CHECKPOINT(g_dwTcpConnSendSegmentLine);
  if( (pxTcpHeader->oFlags & TCPCONN_FLAGMASK_RST) != TCPCONN_FLAGMASK_RST){
    /* Now the segment is in sending process - we have to preserve the
       containing data in the retransmission buffer*/
    /* have to add a user to whichever packet gets sent */
    CHECKPOINT(g_dwTcpConnSendSegmentLine);

    NETPAYLOAD_ADDUSER(xPacket.pxPayload);

    CHECKPOINT(g_dwTcpConnSendSegmentLine);

    lRc = _TcpAddToRetransmissionBuffer(pxConnect,
                                        &xPacket, &xAccess,
                                        dwSeq, pxTcpHeader->oFlags,
                                        pxTcp->dwTicks, oRetries);

    /* buffer not added to queue, decrement user count */
    CHECKPOINT(g_dwTcpConnSendSegmentLine);
    if (lRc < 0) {
      CHECKPOINT(g_dwTcpConnSendSegmentLine);
      NETPAYLOAD_DELUSER(xPacket.pxPayload);
    }
    else {
      if (lRc == 0) {     /* lRc > 0 indicates retransmission which does not take up space */
        /* data is on the queue, so bump tx used space */
        CHECKPOINT(g_dwTcpConnSendSegmentLine);
        /*pxConnect->wTxUsedSpace += wDataToSendLen;*/
      }
    }

    if (pxTcpHeader->oFlags & TCPCONN_FLAGMASK_ACK) {
      CHECKPOINT(g_dwTcpConnSendSegmentLine);
#ifndef __TCP_OPT_ON__
      if ( pxConnect->bDelayedAck )
        LIST_REMOVE (pxConn, fastack_link);
#endif /* __TCP_OPT_ON__*/
      pxConnect->bDelayedAck = 0;
    }
  }

  CHECKPOINT(g_dwTcpConnSendSegmentLine);

  TCP_ASSERT_HI(pxTcp->pfnLLWrite != NULL && (TCPSTATE *)pxTcp->hLL != NULL &&
         (TCPCONN *)pxTcp->hTcpLLIf != NULL);

  xAccess.wOffset -= (sizeof(TCPHDR) + wOptLen);
  xAccess.wLength += (sizeof(TCPHDR) + wOptLen);

  CHECKPOINT(g_dwTcpConnSendSegmentLine);

  lRc = (*pxTcp->pfnLLWrite)(pxTcp->hLL, pxTcp->hTcpLLIf,
                             &xPacket, &xAccess, (H_NETDATA)pxConnNetId);

  CHECKPOINT(g_dwTcpConnSendSegmentLine);

}

/*
 * _TcpDrop
 *  Drop a Connection
 *  Send a RST
 *
 *  Args:
 *   pxTcp                        TCPSTATE pointer
 *   pxConn                       Conn pointer
 *   dwSnd                        Send #
 *   dwRcv                        Receive #
 *
 *  Return:
 */
static void _TcpDrop(TCPSTATE *pxTcp, TCPCONN *pxConn, DWORD dwSnd, DWORD dwRcv)
{

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);

  _TcpConnSendSegment(pxTcp, pxConn, dwSnd, dwRcv,
        TCPCONN_FLAGMASK_RST, TCP_NODATA);

  pxConn->eState = TCPCONN_STATE_CLOSED;
}

/*
 * _TcpCheckRxConn
 *  find out the corresponding TCB ptr on an Rx segment by
 *  its IP and TCP header
 *
 *  Args:
 *   pxTcp                         TCP instance
 *   pxT2NID                        IP source/destination
 *   pxTcpHeader                        TCP header
 *
 *  Return:
 *      ptr to the TCB if found
 *      NULL if none
 */
static TCPCONN *_TcpCheckRxConn(TCPSTATE *pxTcp,
                                TRANSPORT2NETWORKID *pxT2NID,
                                TCPHDR *pxTcpHeader)
{
  TCPCONN *pxConn;

  SNMP(xTcpipData.tcpCurrEstab = (DWORD)0);
  SNMP(xTcpipData.tcpInSegs++);

  TCP_CHECK_STATE(pxTcp);
  TCP_ASSERT_HI(pxT2NID != NULL && pxTcpHeader != NULL);

  DLLIST_head(&pxTcp->dllConns);
  while ((pxConn = (TCPCONN *) DLLIST_read(&pxTcp->dllConns)) != NULL) {
    TRANSPORT2NETWORKID *pxConnNetId = &(pxConn->xId.xNetId);
    if(pxConn->eState == TCPCONN_STATE_LISTEN) {
      /* ie it was a PASSIVE OPEN */
      if((pxConn->xId.wSrcPort == pxTcpHeader->wDstPort) &&
         ((pxConnNetId->dwSrcIpAddr == 0) ||
          (pxConnNetId->dwSrcIpAddr == pxT2NID->dwDstIpAddr)) &&
         (pxConnNetId->oIfIdx == NETIFIDX_DEFAULT ||
          pxConnNetId->oIfIdx == pxT2NID->oIfIdx) &&
         (pxConnNetId->wVlan == NETVLAN_DEFAULT ||
          (pxConnNetId->wVlan & NETVLAN_VIDMASK) ==
             (pxT2NID->wVlan & NETVLAN_VIDMASK))
         ) {
        return pxConn;
      }
    } else if ((pxConn->eState == TCPCONN_STATE_TIME_WAIT) &&
               (pxTcpHeader->oFlags & TCPCONN_FLAGMASK_SYN)) {
      /* corner case when new incoming SYN is received
         while the old connection is in TIME_WAIT state */

    } else if ((pxConnNetId->dwDstIpAddr == pxT2NID->dwSrcIpAddr) &&
             (pxConn->xId.wSrcPort == pxTcpHeader->wDstPort) &&
             (pxConn->xId.wDstPort == pxTcpHeader->wSrcPort) &&
             (pxConnNetId->dwSrcIpAddr == pxT2NID->dwDstIpAddr) &&
             (pxConnNetId->oIfIdx == pxT2NID->oIfIdx) &&
             ((pxConnNetId->wVlan == NETVLAN_DEFAULT) ||
              ((pxConnNetId->wVlan & NETVLAN_VIDMASK) ==
                 (pxT2NID->wVlan & NETVLAN_VIDMASK)))) {
        /* either in ESTABLISHED or other states */
      return pxConn;
    }
    DLLIST_next(&pxTcp->dllConns);
  }

  return NULL;
}


static LONG _TcpCompareRxConn (const void *pxConn1v, const void *pxConn2v, const void *config)

{
  TCPCONN *pxConn1 = (TCPCONN *)pxConn1v;
  TCPCONN *pxConn2 = (TCPCONN *)pxConn2v;
  TRANSPORT2NETWORKID *pxConnNetId1,*pxConnNetId2;

  TCP_ASSERT_HI(pxConn1 != NULL && pxConn2 != NULL);
  pxConnNetId1 = &(pxConn1->xId.xNetId);
  pxConnNetId2 = &(pxConn2->xId.xNetId);

  if (pxConnNetId1->oIfIdx != NETIFIDX_DEFAULT
      && pxConnNetId2->oIfIdx != NETIFIDX_DEFAULT)
  {
    if (pxConnNetId1->oIfIdx < pxConnNetId2->oIfIdx)
    /* not the same if */
      return -1;
    else if (pxConnNetId1->oIfIdx > pxConnNetId2->oIfIdx)
      return 1;
  }

  if (pxConnNetId1->wVlan != NETVLAN_DEFAULT &&
      pxConnNetId2->wVlan != NETVLAN_DEFAULT)
  {
    if ((pxConnNetId1->wVlan & NETVLAN_VIDMASK) <
         (pxConnNetId2->wVlan & NETVLAN_VIDMASK))
      return -1;
    else if ((pxConnNetId1->wVlan & NETVLAN_VIDMASK) >
         (pxConnNetId2->wVlan & NETVLAN_VIDMASK))
      return 1;
    /* not the same VLAN */
  }

  if ((pxConnNetId1->dwDstIpAddr < pxConnNetId2->dwDstIpAddr) ||
             (pxConn1->xId.wSrcPort < pxConn2->xId.wSrcPort) ||
             (pxConn1->xId.wDstPort < pxConn2->xId.wDstPort) ||
             (pxConnNetId1->dwSrcIpAddr < pxConnNetId2->dwSrcIpAddr))
    return -1;


  if ((pxConnNetId1->dwDstIpAddr > pxConnNetId2->dwDstIpAddr) ||
             (pxConn1->xId.wSrcPort > pxConn2->xId.wSrcPort) ||
             (pxConn1->xId.wDstPort > pxConn2->xId.wDstPort) ||
             (pxConnNetId1->dwSrcIpAddr > pxConnNetId2->dwSrcIpAddr))
    return 1;


  return 0;

}

/*
 * _TcpInitConnect
 *  Initialises new TCPCONN_CONNECT structure
 *
 *  Args:
 *   pxTcp                          TCP state
 *   pxConn                         TCP conn
 *   pxConnnect                     TCP connect
 *
 *  Return:
 *   none
 */
static void _TcpInitConnect(TCPSTATE *pxTcp, TCPCONN *pxConn,
                  TCPCONN_CONNECT *pxConnect)
{
#ifdef __TCP_USE_MEMPOOL_PERF__
  void *pTempMemBuffer = NULL;
  MSTATUS status = OK;
#endif

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  TCP_ASSERT_HI(pxConnect != NULL);

  /* inint DLLs */
  init_DLLIST(&(pxConnect->dllReTxBuff));
  init_DLLIST(&(pxConnect->dllReAsBuff));
  init_DLLIST(&(pxConnect->dllSendBuff));

  /* set up sequence numbers */
  pxConnect->dwSendIss = pxTcp->dwIss;
  pxConnect->dwSendNext=pxConnect->dwSendIss+1;
  pxConnect->dwSendUnacked=pxConnect->dwSendIss;

  /* set up receive, send window */
  pxConnect->dwRcvWindow = pxConn->wWin;
  pxConnect->dwSendWindow = pxConn->wWin;

  /* set up rto */
  pxConnect->dwRto = TCP_RTO_LBOUND;

#ifdef __TCP_USE_MEMPOOL_PERF__
  /* Creation of mempool for Re-Transmission pool */
  pTempMemBuffer = MALLOC (sizeof(TCP_RTX_BUF) * TCP_RTX_BUF_MAX);

  if (OK > (status = MEM_POOL_initPool(&pxConnect->retransPool, pTempMemBuffer, sizeof(TCP_RTX_BUF) * TCP_RTX_BUF_MAX, sizeof(TCP_RTX_BUF))))
  {
      DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpInitConnect: Unable to Create Re-Transmission MemPool Status = %d\n", status);
      FREE(pxTcp);
      return;
  }

  /* Creation of mempool for Re-Assemble pool */
  pTempMemBuffer = MALLOC (sizeof(TCP_RAS_BUF) * TCP_RAS_BUF_MAX);

  if (OK > (status = MEM_POOL_initPool(&pxConnect->reassemblePool, pTempMemBuffer, sizeof(TCP_RAS_BUF) * TCP_RAS_BUF_MAX, sizeof(TCP_RAS_BUF))))
  {
      DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpInitConnect: Unable to Create Re-Assemble MemPool Status = %d\n", status);
      FREE(pxTcp);
      return;
  }

  /* Creation of mempool for Send pool */
  pTempMemBuffer = MALLOC (sizeof(TCP_SND_BLK) * TCP_SND_BLK_MAX);

  if (OK > (status = MEM_POOL_initPool(&pxConnect->sendbuffPool, pTempMemBuffer, sizeof(TCP_SND_BLK) * TCP_SND_BLK_MAX, sizeof(TCP_SND_BLK))))
  {
      DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpInitConnect: Unable to Create Send Buffer MemPool Status = %d\n", status);
      FREE(pxTcp);
      return;
  }
#endif
  return;
}

/*
 * _TcpSaveHeader
 *  Save information from the TCP header in the TCPCONN_CONNECT structure
 *
 *  Args:
 *   pxConnect                     TCP connect
 *   pxTcpHeader                        TCP header
 *   wDatalen                      TCP data length
 *
 *  Return:
 *      none
 */
static void _TcpSaveHeader(TCPCONN_CONNECT *pxConnect, TCPHDR *pxTcpHeader,
                           WORD wDatalen)
{
  TCP_ASSERT_HI(pxConnect != NULL && pxTcpHeader != NULL);

  /* save incoming Header */
  pxConnect->dwSegSequenceNumber = pxTcpHeader->dwSequencenumber;
  pxConnect->dwSegAckNumber = pxTcpHeader->dwAcknowledgenumber;
  pxConnect->dwSegLength = wDatalen;
  pxConnect->dwSegWindow = pxTcpHeader->wWindowsize;
  pxConnect->oSegControl = pxTcpHeader->oFlags;
}

/***************************************************************************
*  This function checks, if there are any segments remaining in the retransmission
*  buffer with retransmission time is running out. If yes, remove these segments
*  from the retransmission queue and put them back into the tcp_out_buffer
*  for resending, the retries counter is increased. The check concerns all of the open TCBs
*
*  par:  pxTcp   pointer to TCPSTATE
*
*  ret:  void
****************************************************************************/
static void _TcpCheckForRetransmit(TCPSTATE *pxTcp, TCPCONN *pxConn, TCPCONN_CONNECT *pxConnect)
{
  /* pxTcp->dwTicks counts the number of clock ticks (each 1 ms)*/
  TCP_RTX_BUF *pxReTxBuff;
  TCP_SND_BLK *pxSendBuff;
#ifndef __TCP_OPT_ON__
  LONG        lMinReTxTime = pxTcp->dwTicks + (500) ;
  LONG        lMaxReTxTime = lMinReTxTime;
#endif
#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  MSTATUS mStatus;
#endif

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  TCP_ASSERT_HI(pxConnect != NULL);

  /* Retransmission timer: is there a retransmission buffer ?*/
  if (DLLIST_count_inline(&pxConnect->dllReTxBuff) != 0) {

    DLLIST_head(&pxConnect->dllReTxBuff);
    while((pxReTxBuff= (TCP_RTX_BUF *)DLLIST_read(&pxConnect->dllReTxBuff)) != NULL) {

      NETPACKET_CHECK(&pxReTxBuff->xNetPacket);

      if(pxReTxBuff->oRetries > TCP_MAX_RETRIES ) {
        /*purge the connection*/
        /*TCP_DBGP(ERROR,"_TcpCheckForRetransmit: [%ld] 0x%p,pxReTxBuff = 0x%p, MAX_TRIES over, calling _TcpDrop\n",
                 pxConn->lConnNo, pxConn,pxReTxBuff);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpCheckForRetransmit:[", pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4) pxConn);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," pxReTxBuff  =  :0x", (sbyte4)pxReTxBuff);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," MAX_TRIES over, calling _TcpDrop");
        }
        _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
        /* send callback to socket */
        _TcpConnTimeout(pxTcp, pxConn);
        TCP_CHECKPOINT(g_dwSendRetx);
        return;
      }

      TCP_CHECKPOINT(g_dwSendRetx);
#ifndef __TCP_OPT_ON__
      /* Calculate the Max Time that we can wait for the Retransmit Timer
         but minimum of dwTicks + 500 ms*/
      lMinReTxTime =  pxReTxBuff->dwTimeStamp +   (1 << (pxReTxBuff->oRetries - 1)) * pxConnect->dwRto;
      if (_TcpBefore(lMinReTxTime , lMaxReTxTime))
        lMinReTxTime = lMaxReTxTime;
#endif

      /*do only retransmitt when no ARP request is pending*/
      /* Use the following to have exponential backoff in retransmissions */
      if ( (pxTcp->dwTicks - pxReTxBuff->dwTimeStamp > (1 << (pxReTxBuff->oRetries - 1)) * pxConnect->dwRto) &&
      /* This is linear backoff for retransmits
         Retransmission and Persist are mutually exclusive JJ */
      /*if ( (pxTcp->dwTicks - pxReTxBuff->dwTimeStamp > pxConnect->dwRto) && */
           1 && (pxConnect->oPersistCount == 0) ) {
        /*this segment must be resent */
        /*insert the data in the sending buffer with the flags specified */
        TCP_CHECKPOINT(g_dwSendRetx);

#if defined (__TCP_USE_MEMPOOL_NORMAL__)
        if(OK > (mStatus = MEM_POOL_getPoolObject(&pxTcp->sendbuffPool, (void **) &pxSendBuff)))
#elif defined (__TCP_USE_MEMPOOL_PERF__)
        if(OK > (mStatus = MEM_POOL_getPoolObject(&pxConnect->sendbuffPool, (void **) &pxSendBuff)))
#endif

#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
        {
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: _TcpCheckForRetransmit: unable to allocate buffer");
          return ;
        }
#else
        if ((pxSendBuff = (TCP_SND_BLK *) MALLOC(sizeof(TCP_SND_BLK))) == NULL){
          TCP_CHECKPOINT(g_dwSendRetx);
          /*TCP_DBGP(ERROR,"_TcpCheckForRetransmit: calloc() failed\n");*/
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
              DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_TcpCheckForRetransmit: calloc() failed");
          return;
        }
#endif

        MOC_MEMSET((ubyte *)pxSendBuff, 0, sizeof(TCP_SND_BLK));

#if defined (__TCP_USE_MEMPOOL_NORMAL__)
        pxSendBuff->hTcp = (H_NETINSTANCE)pxTcp;
#elif defined (__TCP_USE_MEMPOOL_PERF__)
        pxSendBuff->hTcp = (H_NETINSTANCE)pxConnect;
#endif

        DLLIST_prepend(&pxConnect->dllSendBuff, pxSendBuff);

        pxSendBuff->poNextToSendData = pxReTxBuff->xNetPacket.pxPayload->poPayload+
              pxReTxBuff->xAccess.wOffset;
        pxSendBuff->wDatalen = pxReTxBuff->xAccess.wLength;

        MOC_MEMCPY((ubyte *)&pxSendBuff->xNetPacket,
                      (ubyte *)&pxReTxBuff->xNetPacket,
                      sizeof(NETPACKET));

        MOC_MEMCPY((ubyte *)&pxSendBuff->xAccess,
                      (ubyte *)&pxReTxBuff->xAccess,
                      sizeof(NETPACKETACCESS));

        pxSendBuff->oRetries = pxReTxBuff->oRetries;
        pxSendBuff->oFlags = pxReTxBuff->oFlags;

        SNMP( xTcpipData.tcpRetransSegs++ );
        pxConn->wTxRetransSegs++;
        _TcpCheckTxErrs(pxConn);

        /*TCP_DBGP(REPETITIVE,"_TcpCheckForRetransmit:[%ld] 0x%p pxReTxBuff=0x%p, oRetries=%d\n",
                 pxConn->lConnNo, pxConn,pxReTxBuff,pxReTxBuff->oRetries);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpCheckForRetransmit:[", pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4) pxConn);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," pxReTxBuff  =  :0x",(sbyte4) pxReTxBuff);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," oRetries  =  ", pxReTxBuff->oRetries);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }

        _TcpConnSendSegment (pxTcp, pxConn, pxReTxBuff->dwSequenceNbr, pxConnect->dwRcvNext,
              0, TCP_DATAON);

      }
      DLLIST_next(&pxConnect->dllReTxBuff);
    }
  }

#ifndef __TCP_OPT_ON__
  if (DLLIST_count_inline(&pxConnect->dllReTxBuff) != 0) {
    /* FInd the Least Max Time required and schedule it for that */
    if (!pxConnect->wRetransmitTimer)
    {
        pxConnect->wRetransmitTimer = lMinReTxTime;
        _TcpInsertOrderedList (&pxTcp->lRetransList,
                               pxConn,
                               TCP_TIMER_RETRANS);
    }
  }
#endif
}

/***************************************************************************
*  the reassembly of the received data packets is performed by this function
*  by looking at the sequence-nbrs.
*  Zero-copy returns one segment at a time.
*
*  par:  pxConn    ptr to the TCPCONN
*
*  ret:  allocated ptr to the reassembled data
*      -1 if none or error
*       0 data returned in buffer
****************************************************************************/
static LONG _TcpReassembleInBuffer(TCPCONN *pxConn, OCTET *poBuff,
                   WORD *pwDatalen, OCTET **ppBuff,
                   NETPAYLOAD **ppPayload)
{
  TCPCONN_CONNECT *pxConnect;
  TCP_RAS_BUF *pxBuff;
  DWORD dwMatchSequenceNbr;
  WORD wCount = 0;
  WORD wChain = 0;
  WORD wLen;
  BOOL bFound,bPush;
#ifdef __TCP_USE_SEGMENTS__
  segmentStructure *pxSegment = NULL;
#endif
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  TCPSTATE *pxTcp;
  MSTATUS status = OK;
#elif defined (__TCP_USE_MEMPOOL_PERF__)
  MSTATUS status = OK;
#endif

  TCPCONN_CHECK(pxConn);
  pxConnect = pxConn->u.pxConnect;
  TCP_ASSERT_HI(pxConnect != NULL && (poBuff != NULL || ppBuff != NULL) &&
        pwDatalen != NULL);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "_TcpReassembleInBuffer: pxConnect: 0x",(sbyte4)pxConnect);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
  }
  /*get the first seq nbr to read */
  dwMatchSequenceNbr=pxConnect->dwLastUnpackedSequenceNbr+1;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
  {
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "_TcpReassembleInBuffer: First Seq NBR To read ",dwMatchSequenceNbr);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
  }
  /* keep attempting "reassembly" until no buffer found */
  do {
    bFound = 0;
    bPush = FALSE;
    DLLIST_head(&pxConnect->dllReAsBuff);
    while((pxBuff = (TCP_RAS_BUF *) DLLIST_read(&pxConnect->dllReAsBuff)) != NULL) {
      NETPACKET_CHECK(&pxBuff->xNetPacket);

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "_TcpReassembleInBuffer: Buffer Seq NBR ",pxBuff->dwSequenceNbr);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }
      if(pxBuff->dwSequenceNbr == dwMatchSequenceNbr) {
        bPush = pxBuff->bPushFlag;
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "_TcpReassembleInBuffer: Buffer Seq NBR Matched ",pxBuff->dwSequenceNbr);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }
        if ( ppBuff ) /* zero-copy */
        {
          wLen = pxBuff->wDatalen;
#ifdef __TCP_USE_SEGMENTS__
          if ( NULL == pxSegment)
          {
              pxSegment = MALLOC(sizeof(segmentStructure));
              TCP_ASSERT_HI(pxSegment != NULL);
              *ppBuff = (void *)pxSegment;
              *ppPayload = (void *)pxSegment;
              pxSegment->pNextSegment = NULL;
              if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "_TcpReassembleInBuffer: Creating Segment 0x",(sbyte4)pxSegment);
          }
          else
          {
              /* Chain It */
              pxSegment->pNextSegment = MALLOC(sizeof(segmentStructure));
              TCP_ASSERT_HI(pxSegment->pNextSegment != NULL);
              pxSegment = pxSegment->pNextSegment;
              pxSegment->pNextSegment = NULL;
              if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
                DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "_TcpReassembleInBuffer: Chaining Segment ",++wChain);

          }

          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " : Length of  Segment ",wLen);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
          }
          pxSegment->lengthOfSegment = wLen;
#endif
        }
        else
          wLen = *pwDatalen - wCount;
        if (wLen < pxBuff->wDatalen) {
          /* partial copy */
          MOC_MEMCPY((ubyte *)(poBuff + wCount),
                  (ubyte *) pxBuff->poBegin, wLen);
          pxConnect->dwLastUnpackedSequenceNbr += wLen;
          pxBuff->dwSequenceNbr += wLen;
          pxBuff->poBegin += wLen;
          pxBuff->wDatalen -= wLen;
          *pwDatalen = wCount + wLen;
          pxConnect->wRxUsedSpace -= *pwDatalen;
          if (pxConnect->wRxUsedSpace <= TCP_RX_RELSPACE) {
            /* open the receive window */
            pxConnect->dwRcvWindow=pxConn->wWin;
          }
          return 0;
        }
        else {
          /* full copy */
          if ( ppBuff ){ /* zero-copy */
#ifdef __TCP_USE_SEGMENTS__
             pxSegment->pSegment = (ubyte *) ( pxBuff->poBegin);
             pxSegment->pFreeArg = (ubyte *) pxBuff->xNetPacket.pxPayload;
#else
             *ppBuff = pxBuff->poBegin;
             *ppPayload = pxBuff->xNetPacket.pxPayload;
#endif
          }else
              MOC_MEMCPY((ubyte *)(poBuff + wCount),
                  (ubyte *) pxBuff->poBegin, pxBuff->wDatalen);
          pxConnect->dwLastUnpackedSequenceNbr += pxBuff->wDatalen;
          dwMatchSequenceNbr += pxBuff->wDatalen;
          wCount += pxBuff->wDatalen;

          if ( ppBuff == NULL ) /* not zero-copy */
              NETPAYLOAD_DELUSER(pxBuff->xNetPacket.pxPayload);
          DLLIST_remove(&pxConnect->dllReAsBuff);
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
          pxTcp = (TCPSTATE *)pxConn->hTcp;
          pxBuff->hTcp = NULL;
          if (OK > (status = MEM_POOL_putPoolObject(&pxTcp->reassemblePool, (void **)(&pxBuff))))
              if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
                  DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpReassembleInBuffer: unable to put buffer within reassemblePool Status = %d\n", status);
#elif defined (__TCP_USE_MEMPOOL_PERF__)
          pxBuff->hTcp = NULL;
          if(OK > (status = MEM_POOL_putPoolObject(&pxConnect->reassemblePool, (void **)(&pxBuff))))
              if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
                 DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpReassembleInBuffer: unable to put buffer within reassemblePool Status = %d\n", status);
#else
          FREE(pxBuff);
#endif
          bFound = 1;
          break;
        }
      }
      /*printf(" seq num not match, checking next\n"); */
      DLLIST_next(&pxConnect->dllReAsBuff);
    }
  } while ((!bPush) && (bFound) && (wCount < *pwDatalen) &&
#ifdef __TCP_USE_SEGMENTS__
    (pxBuff != NULL /* Go Through All the Buffers for ZeroCopy */));
#else
    (ppBuff == NULL /* not zero-copy */ ));
#endif

  if (wCount > 0) {
     if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
     {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "_TcpReassembleInBuffer: Total Length of  Segment ",wCount);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
     }
    *pwDatalen = wCount;
    pxConnect->wRxUsedSpace -= wCount;
    if (pxConnect->wRxUsedSpace <= TCP_RX_RELSPACE) {
      /* open the receive window */
      pxConnect->dwRcvWindow=pxConn->wWin;
    }

    return 0;
  }
  else {
    *ppBuff=NULL;
    *ppPayload=NULL;
    *pwDatalen=0;
    return -1;
  }
}

/***************************************************************************
*  this function returns the amount of data ready to be read from the
*  reassembly buffer by looking at the sequence-nbrs
*
*  par:  pxConn    ptr to the TCPCONN
*
*  ret:  size of contiguous data available
*      0 if none
****************************************************************************/
static WORD _TcpReassembleCount(TCPCONN_CONNECT *pxConnect)
{
  TCP_RAS_BUF *pxBuff;
  DWORD dwMatchSequenceNbr;
  WORD wCount=0;
  BOOL bFound,bPush;

  TCP_ASSERT_HI(pxConnect != NULL);
  /*TCP_DBGP(NORMAL,"_TcpReassembleCount: pxConnect: %p\n", pxConnect);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "_TcpReassembleCount: pxConnect: 0x",(sbyte4)pxConnect);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
  }

  /*get the first seq nbr to read */
  dwMatchSequenceNbr=pxConnect->dwLastUnpackedSequenceNbr+1;

  /* keep attempting "reassembly" until no buffer found */
  do {
    bFound = 0;
    bPush = FALSE;
    DLLIST_head(&pxConnect->dllReAsBuff);
    while((pxBuff = (TCP_RAS_BUF *) DLLIST_read(&pxConnect->dllReAsBuff)) != NULL) {
      NETPACKET_CHECK(&pxBuff->xNetPacket);
      if(pxBuff->dwSequenceNbr == dwMatchSequenceNbr) {
        /* If App buffer >= data available in 1st segment return 1st segmen */
        wCount += pxBuff->wDatalen;
        dwMatchSequenceNbr += pxBuff->wDatalen;
        bFound = 1;
        bPush = pxBuff->bPushFlag;
        break;
      }
      /*printf(" seq num not match, checking next\n"); */
      DLLIST_next(&pxConnect->dllReAsBuff);
    }
  } while (bFound && (!bPush));
  return wCount;
}

/***************************************************************************
*  this function is called after LRBLYU is exceeded, or a timeout of RBLYTO,
*  or receipt of the PUSH flag.
*  It finds contiguous buffers in the reassembly list and forwards them to
*  the socket via the rx callback. It terminates if the end of contiguous
*  data is found, if wRxCount is reached, or if the callback returns a
*  partial accept or an error.
*
*  par: pxTcp   ptr to the TCPSTATE
*    pxConn     ptr to the TCPCONN
*    wRxCount   size of data
*
*  ret:  none
****************************************************************************/
static void _TcpSendToSocket(TCPSTATE *pxTcp, TCPCONN *pxConn, WORD wRxCount)
{
  TCPCONN_CONNECT *pxConnect;
  NETPAYLOAD *pxPayload;
  NETPACKETACCESS xAccess;
  TCP_RAS_BUF *pxBuff;
  DWORD dwMatchSequenceNbr;
  WORD wCount=0;
  BOOL bFound,bPush;
  LONG lRc;
#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  MSTATUS status = OK;
#endif

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);

  pxConnect = pxConn->u.pxConnect;
  TCP_ASSERT_HI(pxConnect != NULL);

  if (pxConn->eState != TCPCONN_STATE_ESTABLISHED) {
    /* don't call back to socket becase close() already destroy socket */
    return;
  }

  /*get the first seq nbr to read */
  dwMatchSequenceNbr=pxConnect->dwLastUnpackedSequenceNbr+1;

  /* keep attempting "reassembly" until no buffer found */
  do {
    bFound = 0;
    bPush = FALSE;
    DLLIST_head(&pxConnect->dllReAsBuff);
    while((pxBuff = (TCP_RAS_BUF *) DLLIST_read(&pxConnect->dllReAsBuff)) != NULL) {
      NETPACKET_CHECK(&pxBuff->xNetPacket);
      if(pxBuff->dwSequenceNbr == dwMatchSequenceNbr) {
        /* set up NETACCESS for data */
        pxPayload = pxBuff->xNetPacket.pxPayload;
        TCP_ASSERT_HI(pxPayload != NULL && pxPayload->poPayload != NULL &&
               pxPayload->poPayload <= pxBuff->poBegin);
        xAccess.wOffset = pxBuff->poBegin - pxPayload->poPayload;
        xAccess.wLength = pxBuff->wDatalen;
        wCount += pxBuff->wDatalen;

        /* write data to socket */
        TCP_ASSERT_HI(pxConn->pfnRxCbk != NULL);

        lRc =
          (*pxConn->pfnRxCbk)(pxConn->hUL, pxConn->hIf, &pxBuff->xNetPacket,
                              &xAccess, (H_NETDATA)&(pxConn->xId));

        if (lRc < 0) {
          /* error return */
          return;
        }
        else if (lRc < pxBuff->wDatalen) {
          /* partial accept */
          pxConnect->dwLastUnpackedSequenceNbr += lRc;
          pxBuff->dwSequenceNbr += lRc;
          pxBuff->poBegin += lRc;
          pxBuff->wDatalen -= lRc;
          return;
        }
        else {
          /* full accept. The upper layer will
             have taken care of freeing the packet */
          pxConnect->dwLastUnpackedSequenceNbr += pxBuff->wDatalen;
          dwMatchSequenceNbr += pxBuff->wDatalen;
          wCount += pxBuff->wDatalen;

          pxConnect->wRxUsedSpace -= pxBuff->wDatalen;
          if (pxConnect->wRxUsedSpace <= TCP_RX_RELSPACE) {
            /* open the receive window */
            pxConnect->dwRcvWindow=pxConn->wWin;
          }

          DLLIST_remove(&pxConnect->dllReAsBuff);
          bPush = pxBuff->bPushFlag;
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
          pxBuff->hTcp = NULL;
          if(OK > (status = MEM_POOL_putPoolObject(&pxTcp->reassemblePool, (void **)(&pxBuff))))
            DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpSendToSocket: unable to put buffer within reassemblePool Status = %d\n", status);
#elif defined (__TCP_USE_MEMPOOL_PERF__)
          pxBuff->hTcp = NULL;
          if(OK > (status = MEM_POOL_putPoolObject(&pxConnect->reassemblePool, (void **)(&pxBuff))))
            DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpSendToSocket: unable to put buffer within reassemblePool Status = %d\n", status);
#else
          FREE(pxBuff);
#endif
          bFound = 1;
          break;
        }
      }
      /*printf(" seq num not match, checking next\n"); */
      DLLIST_next(&pxConnect->dllReAsBuff);
    }
  } while ((!bPush) && bFound && wCount < wRxCount);
}


/***************************************************************************
*  this function flushes all rx data to the socket.
*  it is called upon receipt of a PUSH, FIN, or before a drop.
*  it is also called with bLrblyu set upon receipt of any data,
*  and forwards the data to the socket if wLrblyu is exceeded.
*
*  par: pxTcp   ptr to the TCPSTATE
*    pxConn     ptr to the TCPCONN
*    bLrblyu    = 1 flush only on least reasm unit

*  ret:  none
****************************************************************************/
static void _TcpRxFlush(TCPSTATE *pxTcp, TCPCONN *pxConn, BOOL bLrblyu)
{
  TCPCONN_CONNECT *pxConnect;
  WORD wRxCount;

  pxConnect = pxConn->u.pxConnect;
  TCP_ASSERT_HI(pxConnect != NULL);

  wRxCount = _TcpReassembleCount(pxConnect);

  if (wRxCount > 0) {
    if (!bLrblyu || (pxConn->wLrblyu > 0 && wRxCount >= pxConn->wLrblyu)){
      _TcpSendToSocket(pxTcp, pxConn, wRxCount);
#ifndef __TCP_OPT_ON__
      if ( pxConnect->wReasmTimer )
        LIST_REMOVE (pxConn, reasm_link);
#endif /* __TCP_OPT_ON__*/
      /* flushed, so restart reasm timer */
      pxConnect->wReasmTimer = pxConn->wReasmTimer;
#ifndef __TCP_OPT_ON__
      /* Convert it to Actual  Ticks */
      pxConnect->wReasmTimer = pxConnect->wReasmTimer * 500 +  pxTcp->dwTicks;
      _TcpInsertOrderedList (&pxTcp->lReasmList,
                             pxConn,
                             TCP_TIMER_REASM);
#endif /* __TCP_OPT_ON__*/
    }
  }
}

#ifndef __TCP_OPT_ON__
static void _TcpCheckFastackTimerList (TCPSTATE *pxTcp)
{
  TCPCONN *pxConn;
  TCPCONN_CONNECT *pxConnect;

  TCP_CHECK_STATE(pxTcp);

  if (LIST_EMPTY(&pxTcp->lFastackList))
    return;

  pxConn = LIST_FIRST(&pxTcp->lFastackList);

  while (pxConn)
  {
    TCPCONN_CHECK(pxConn);
    pxConnect = pxConn->u.pxConnect;
    TCP_ASSERT_HI(pxConnect != NULL);
    if ( _TcpAfter(pxTcp->dwTicks , pxConnect->wFastackTimer ))
    {
      LIST_REMOVE(pxConn,fastack_link);
      /*TCP_DBGP(NORMAL,"_TcpFastTimeout:[%ld] Sending Delayed Ack Ticks[%ld] \n",pxConn->lConnNo,pxConnect->wFastackTimer);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,"_TcpFastTimeout[",pxConn->lConnNo, "] Sending Delayed Ack Ticks :",pxConnect->wFastackTimer);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }
      pxConnect->bDelayedAck = 0;
      _TcpConnSendSegment(pxTcp,pxConn,pxConnect->dwSendNext,pxConnect->dwRcvNext,
            TCPCONN_FLAGMASK_ACK,TCP_NODATA);
      /* Get the Next Connection in the List */
      pxConn = LIST_FIRST(&pxTcp->lFastackList);
    }
    else
    {
      return;
    }
  }
  return;
}
#endif /* __TCP_OPT_ON__*/

/*
 * _TcpFastTimeout
 *  Handles the delayed ACK timeout
 *  Called every 200 ms
 *
 *  Args:
 *   pxTcp                        pxTcp ptr to the TCPSTATE
 *
 *  Return:
 *   None
 */
static void _TcpFastTimeout(TCPSTATE *pxTcp)
{
  TCPCONN *pxConn;
  TCPCONN_CONNECT *pxConnect;

  /* walk though all the connections looking for the delayed ACK flag */

  TCP_CHECK_STATE(pxTcp);

#ifndef __TCP_OPT_ON__
  _TcpCheckFastackTimerList (pxTcp);
#endif

#ifdef __TCP_OPT_ON__
  DLLIST_head(&pxTcp->dllConns);
  while ((pxConn = (TCPCONN *) DLLIST_read(&pxTcp->dllConns)) != NULL) {
    TCPCONN_CHECK(pxConn);
    if (pxConn->eState >= TCPCONN_STATE_ESTABLISHED) {
      pxConnect = pxConn->u.pxConnect;
      TCP_ASSERT_HI(pxConnect != NULL);

      if(pxConnect->bDelayedAck) {
        /* send an ACK on this connection */
        _TcpConnSendSegment(pxTcp,pxConn,pxConnect->dwSendNext,pxConnect->dwRcvNext,
              TCPCONN_FLAGMASK_ACK,TCP_NODATA);
        pxConnect->bDelayedAck = 0;
      }
    }
    DLLIST_next(&pxTcp->dllConns);
  }
#endif

}

#ifndef __TCP_OPT_ON__

static void _TcpCheckFinwait2TimerList (TCPSTATE *pxTcp)
{
  TCPCONN *pxConn;
  TCPCONN_CONNECT *pxConnect;

  TCP_CHECK_STATE(pxTcp);

  if (LIST_EMPTY(&pxTcp->lFinwait2List))
    return;

  pxConn = LIST_FIRST(&pxTcp->lFinwait2List);

  while (pxConn)
  {
    TCPCONN_CHECK(pxConn);
    pxConnect = pxConn->u.pxConnect;
    TCP_ASSERT_HI(pxConnect != NULL);
    if ( _TcpAfter(pxTcp->dwTicks , pxConnect->wFinwait2Timer ))
    {
      LIST_REMOVE(pxConn,finack2_link);
      pxConnect->wFinwait2Timer = 0;
      TCP_CHECKPOINT(g_dwSendRetx);
      /* Aha, a TCB is in FIN_WAIT_2 or TIME_WAIT state
      * Check if it has been in FIN_WAIT_2 or TIME_WAIT for long */
      if(pxConn->eState == TCPCONN_STATE_FIN_WAIT_2
        || pxConn->eState == TCPCONN_STATE_TIME_WAIT){
        /* Waited too long! Time to clear this connection */
        TCP_CHECKPOINT(g_dwSendRetx);
        /*TCP_DBGP(NORMAL,"_TcpSlowTimeout:[%ld] Finwait2Timer over, closing\n",pxConn->lConnNo);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINT(DEBUG_MOC_IPV4,"_TcpSlowTimeout:[");
            DEBUG_INT(DEBUG_MOC_IPV4,pxConn->lConnNo);
            DEBUG_PRINT(DEBUG_MOC_IPV4, "] Finwait2Timer over, closing");
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
        }
        /* send callback to socket */
        _TcpConnTimeout(pxTcp, pxConn);
        TCP_CHECKPOINT(g_dwSendRetx);
        /*printf("TCP_check_for_retransmit: clearing FIN_WAIT_2 timer \n"); */
      }
      /* Get the Next Connection in the List */
      pxConn = LIST_FIRST(&pxTcp->lFinwait2List);
    }
    else
    {
      return;
    }
  }
  return;
}

static void _TcpCheckConestabTimerList (TCPSTATE *pxTcp)
{
  TCPCONN *pxConn;
  TCPCONN_CONNECT *pxConnect;

  TCP_CHECK_STATE(pxTcp);

  if (LIST_EMPTY(&pxTcp->lConestabList))
    return;

  pxConn = LIST_FIRST(&pxTcp->lConestabList);

  while (pxConn)
  {
    TCPCONN_CHECK(pxConn);
    pxConnect = pxConn->u.pxConnect;
    TCP_ASSERT_HI(pxConnect != NULL);
    if ( _TcpAfter(pxTcp->dwTicks , pxConnect->wConestabTimer ))
    {
      LIST_REMOVE(pxConn,conestab_link);
      pxConnect->wConestabTimer = 0;
      TCP_CHECKPOINT(g_dwSendRetx);
      /* First check if waiting for connection */
      if(pxConn->eState < TCPCONN_STATE_ESTABLISHED ) {
        /* send callback to socket */
        TCP_CHECKPOINT(g_dwSendRetx);
        /*TCP_DBGP(ERROR,"_TcpSlowTimeout: ConEstabTimer over, calling _TcpDrop\n");*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
        {
            DEBUG_PRINT(DEBUG_MOC_IPV4,"_TcpSlowTimeout:[");
            DEBUG_INT(DEBUG_MOC_IPV4,pxConn->lConnNo);
            DEBUG_PRINT(DEBUG_MOC_IPV4, "] ConEstabTimer over, calling _TcpDrop");
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
        }
        _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
        _TcpConnTimeout(pxTcp, pxConn);
        TCP_CHECKPOINT(g_dwSendRetx);
      }
      else if(pxConn->eState < TCPCONN_STATE_CLOSE_WAIT ) {
        /* this is the keepalive timer  TODO Fix the ubyte4 Roll Over*/
        if ( _TcpAfter((pxTcp->dwTicks - pxConnect->wIdleTimer)  , (500 * (pxTcp->wKeepAliveTimer + TCP_MAX_IDLE_TIMER)))) {
          /* send callback to socket */
          /*TCP_DBGP(ERROR,"_TcpSlowTimeout: KeepAliveTimer over, calling _TcpDrop\n");*/
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          {
              DEBUG_PRINT(DEBUG_MOC_IPV4,"_TcpSlowTimeout:[");
              DEBUG_INT(DEBUG_MOC_IPV4,pxConn->lConnNo);
              DEBUG_PRINT(DEBUG_MOC_IPV4, "] KeepAliveTimer over, calling _TcpDrop");
              DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
          }
          _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
          _TcpConnTimeout(pxTcp, pxConn);
          TCP_CHECKPOINT(g_dwSendRetx);
        } else {
          _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwRcvNext,
                              pxConnect->dwSendUnacked-1, 0, TCP_NODATA);
          pxConnect->wConestabTimer = TCP_KEEPINTL_TIMER;
         /* Convert it to Actual  Ticks */
          pxConnect->wConestabTimer = pxConnect->wConestabTimer * 500 +  pxTcp->dwTicks;
          _TcpInsertOrderedList (&pxTcp->lConestabList,
                                 pxConn,
                                 TCP_TIMER_CONESTAB);
        }
      }
      /* Get the Next Connection in the List */
      pxConn = LIST_FIRST(&pxTcp->lConestabList);
    }
    else
    {
      return;
    }
  }
  return;
}

static void _TcpCheckReasmTimerList (TCPSTATE *pxTcp)
{
  TCPCONN *pxConn;
  TCPCONN_CONNECT *pxConnect;

  TCP_CHECK_STATE(pxTcp);

  if (LIST_EMPTY(&pxTcp->lReasmList))
    return;

  pxConn = LIST_FIRST(&pxTcp->lReasmList);

  while (pxConn)
  {
    TCPCONN_CHECK(pxConn);
    pxConnect = pxConn->u.pxConnect;
    TCP_ASSERT_HI(pxConnect != NULL);
    if ( _TcpAfter(pxTcp->dwTicks , pxConnect->wReasmTimer ))
    {
      LIST_REMOVE(pxConn,reasm_link);
      pxConnect->wReasmTimer = 0;
      /*(TCP_DBGP(NORMAL,"_TcpReasmTimeout:[%ld] RxFlushing Ticks[%ld] \n",pxConn->lConnNo,pxConnect->wReasmTimer);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,"_TcpReasmTimeout:[",pxConn->lConnNo, "] RxFlushing Ticks : ",pxConnect->wReasmTimer);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }
      /* reasm timeout, send all to socket */
      _TcpRxFlush(pxTcp, pxConn, 0);
      /* Get the Next Connection in the List */
      pxConn = LIST_FIRST(&pxTcp->lReasmList);
    }
    else
    {
      return;
    }
  }
  return;
}

static void _TcpCheckRetransTimerList (TCPSTATE *pxTcp)
{
  TCPCONN *pxConn;
  TCPCONN_CONNECT *pxConnect;

  TCP_CHECK_STATE(pxTcp);

  if (LIST_EMPTY(&pxTcp->lRetransList))
    return;

  pxConn = LIST_FIRST(&pxTcp->lRetransList);

  while (pxConn)
  {
    TCPCONN_CHECK(pxConn);
    pxConnect = pxConn->u.pxConnect;
    TCP_ASSERT_HI(pxConnect != NULL);
    if ( _TcpAfter(pxTcp->dwTicks , pxConnect->wRetransmitTimer ))
    {
      LIST_REMOVE(pxConn,retrans_link);
      /*TCP_DBGP(NORMAL,"_TcpRetransTimeout:[%ld] Retransmitting Ticks[%ld] \n",pxConn->lConnNo,pxConnect->wRetransmitTimer);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,"_TcpRetransTimeout:[",pxConn->lConnNo, "] Rxtransmitting Ticks : ",pxConnect->wRetransmitTimer);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }
      pxConnect->wRetransmitTimer = 0;

      _TcpCheckForRetransmit(pxTcp, pxConn, pxConnect);
      /* Get the Next Connection in the List */
      pxConn = LIST_FIRST(&pxTcp->lRetransList);
    }
    else
    {
      return;
    }
  }
  return;
}

static void _TcpCheckLingerTimerList (TCPSTATE *pxTcp)
{
  TCPCONN *pxConn;
  TCPCONN_CONNECT *pxConnect;

  TCP_CHECK_STATE(pxTcp);

  if (LIST_EMPTY(&pxTcp->lLingerList))
    return;

  pxConn = LIST_FIRST(&pxTcp->lLingerList);

  while (pxConn)
  {
    TCPCONN_CHECK(pxConn);
    pxConnect = pxConn->u.pxConnect;
    TCP_ASSERT_HI(pxConnect != NULL);
    if ( _TcpAfter(pxTcp->dwTicks , pxConnect->wLingerTimer ))
    {
      LIST_REMOVE(pxConn,linger_link);
      pxConnect->wLingerTimer = 0;

      TCP_CHECKPOINT(g_dwSendRetx);
      /*TCP_DBGP(NORMAL,"_TcpLingerTimeout:[%ld] Dropping Conn Ticks[%ld] \n",pxConn->lConnNo,pxConnect->wLingerTimer);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,"_TcpLingerTimeout:[",pxConn->lConnNo, "] Dropping Conn Ticks : ",pxConnect->wLingerTimer);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }
      _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
      /* send callback to socket */
      _TcpConnClose(pxTcp, pxConn);
      TCP_CHECKPOINT(g_dwSendRetx);
      /* Get the Next Connection in the List */
      pxConn = LIST_FIRST(&pxTcp->lLingerList);
    }
    else
    {
      return;
    }
  }
  return;
}


static void _TcpCheckPersistTimerList (TCPSTATE *pxTcp)
{
  TCPCONN *pxConn;
  TCPCONN_CONNECT *pxConnect;

  TCP_CHECK_STATE(pxTcp);

  if (LIST_EMPTY(&pxTcp->lPersistList))
    return;

  pxConn = LIST_FIRST(&pxTcp->lPersistList);
  TCPCONN_CHECK(pxConn);

  while (pxConn)
  {
    TCPCONN_CHECK(pxConn);
    pxConnect = pxConn->u.pxConnect;
    TCP_ASSERT_HI(pxConnect != NULL);
    if ( _TcpAfter(pxTcp->dwTicks , pxConnect->wPersistTimer ))
    {
      LIST_REMOVE(pxConn,persist_link);
      pxConnect->wPersistTimer = 0;
      if (pxConnect->dwSendWindow == 0)
      {
        /*TCP_DBGP(NORMAL,"_TcpPersistTimeout:[%ld] Sending Segment Ticks[%ld] \n",pxConn->lConnNo,pxConnect->wPersistTimer);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,"_TcpPersistTimeout:[",pxConn->lConnNo, "] Sending Segments  Ticks : ",pxConnect->wPersistTimer);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }
        TCP_CHECKPOINT(g_dwSendRetx);
        pxConnect->bForce1Byte = 1;
        _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext,
                              pxConnect->dwRcvNext, 0, TCP_DATAON);
        pxConnect->bForce1Byte = 0;

        if (pxConnect->oPersistCount < TCP_PER_MAXSHF)
          pxConnect->oPersistCount++;
        _TcpSetPersist(pxConnect);
      }
      /* Get the Next Connection in the List */
      pxConn = LIST_FIRST(&pxTcp->lPersistList);
    }
    else
    {
      return;
    }
  }
  return;
}

#endif /* __TCP_OPT_ON__*/
/*
 * _TcpSlowTimeout
 *  Handles the slow timeout
 *  Called every 500 ms
 *
 *  Args:
 *   pxTcp                        pxTcp ptr to the TCPSTATE
 *
 *  Return:
 *   None
 */

#if 0
LONG gdwTcpSlowTimeoutPrevTime = 0;
LONG gdwTcpSlowTimeoutCurrTime = 0;
#endif

static void _TcpSlowTimeout(TCPSTATE *pxTcp)
{
  TCPCONN *pxConn;
  TCPCONN_CONNECT *pxConnect;

  TCP_CHECK_STATE(pxTcp);

  #if 0
  gdwTcpSlowTimeoutCurrTime = NetGetMsecTime();
  printf("_TcpSlowTimeout delta time=%ld\n",gdwTcpSlowTimeoutCurrTime - gdwTcpSlowTimeoutPrevTime);
  gdwTcpSlowTimeoutPrevTime = gdwTcpSlowTimeoutCurrTime;
  #endif

  /* increment ISS */
  pxTcp->dwIss += TCP_ISSINCR;

  /*TCP_DBGP(NORMAL,"_TcpSlowTimeout: Ticks [%d]\n", pxTcp->dwTicks);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_DETAIL))
  {
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "_TcpSlowTimeout: Ticks :", pxTcp->dwTicks);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
  }
#ifndef __TCP_OPT_ON__
  _TcpCheckLingerTimerList (pxTcp);
  _TcpCheckFinwait2TimerList (pxTcp);
  _TcpCheckPersistTimerList(pxTcp);
  _TcpCheckConestabTimerList(pxTcp);
  _TcpCheckReasmTimerList  (pxTcp);
  _TcpCheckRetransTimerList  (pxTcp);
#endif

#ifdef __TCP_OPT_ON__
  DLLIST_head(&pxTcp->dllConns);
  while ((pxConn = (TCPCONN *) DLLIST_read(&pxTcp->dllConns)) != NULL) {
    TCP_CHECKPOINT(g_dwSendRetx);
    if (pxConn->eState > TCPCONN_STATE_LISTEN) {
      pxConnect = pxConn->u.pxConnect;
      TCP_ASSERT_HI(pxConnect != NULL);

      /* increment idle timer */
      pxConnect->wIdleTimer++;

      /* Check all timers */

      /* Close linger timer */
      if (pxConnect->wLingerTimer) {
        if (--pxConnect->wLingerTimer) {
          TCP_CHECKPOINT(g_dwSendRetx);
          /*TCP_DBGP(ERROR,"_TcpSlowTimeout: LingerTimer over, calling _TcpDrop\n");*/
          _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
          /* send callback to socket */
          _TcpConnClose(pxTcp, pxConn);
          TCP_CHECKPOINT(g_dwSendRetx);
          continue;
        }
      }

      /* FIN_WAIT2-TIME_WAIT timer:
       * Note: TIME_WAIT timer: uses same wFinwait2Timer as these cannot occur
       * simultaneously */
      if (pxConnect->wFinwait2Timer) {
        if (--pxConnect->wFinwait2Timer == 0) {
          TCP_CHECKPOINT(g_dwSendRetx);
          /* Aha, a TCB is in FIN_WAIT_2 or TIME_WAIT state
          * Check if it has been in FIN_WAIT_2 or TIME_WAIT for long */
          if(pxConn->eState == TCPCONN_STATE_FIN_WAIT_2
              || pxConn->eState == TCPCONN_STATE_TIME_WAIT){
            /* Waited too long! Time to clear this connection */
            TCP_CHECKPOINT(g_dwSendRetx);
            /*TCP_DBGP(NORMAL,"_TcpSlowTimeout:[%ld] Finwait2Timer over, closing\n",pxConn->lConnNo);*/
            /* send callback to socket */
            _TcpConnTimeout(pxTcp, pxConn);
            TCP_CHECKPOINT(g_dwSendRetx);
            /*printf("TCP_check_for_retransmit: clearing FIN_WAIT_2 timer \n"); */
            continue;
          }
        }
      }

      /* Connection Establishment-Keepalive timer */
      if (pxConnect->wConestabTimer) {
        if (--pxConnect->wConestabTimer == 0) {
          TCP_CHECKPOINT(g_dwSendRetx);
          /* First check if waiting for connection */
          if(pxConn->eState < TCPCONN_STATE_ESTABLISHED ) {
            /* send callback to socket */
            TCP_CHECKPOINT(g_dwSendRetx);
            /*TCP_DBGP(ERROR,"_TcpSlowTimeout: ConEstabTimer over, calling _TcpDrop\n");*/
            _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
            _TcpConnTimeout(pxTcp, pxConn);
            TCP_CHECKPOINT(g_dwSendRetx);
            continue;
          }
          else if(pxConn->eState < TCPCONN_STATE_CLOSE_WAIT ) {
            /* this is the keepalive timer */
            if (pxConnect->wIdleTimer >= pxTcp->wKeepAliveTimer + TCP_MAX_IDLE_TIMER) {
              /* send callback to socket */
              /*TCP_DBGP(ERROR,"_TcpSlowTimeout: KeepAliveTimer over, calling _TcpDrop\n");*/
              _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
              _TcpConnTimeout(pxTcp, pxConn);
              TCP_CHECKPOINT(g_dwSendRetx);
              continue;
            } else {
              _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwRcvNext,
                                pxConnect->dwSendUnacked-1, 0, TCP_NODATA);
              pxConnect->wConestabTimer = TCP_KEEPINTL_TIMER;
            }
          }
        }
      }

      /* Persist timer */
      if (pxConnect->wPersistTimer) {
        if (--pxConnect->wPersistTimer == 0) {
          TCP_CHECKPOINT(g_dwSendRetx);
          pxConnect->bForce1Byte = 1;
          _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext,
                            pxConnect->dwRcvNext, 0, TCP_DATAON);
          pxConnect->bForce1Byte = 0;
          if (pxConnect->oPersistCount < TCP_PER_MAXSHF)
            pxConnect->oPersistCount++;
          _TcpSetPersist(pxConnect);
        }
      }

      /* Reassembly timer */
      if (pxConnect->wReasmTimer) {
        if (--pxConnect->wReasmTimer == 0) {
          /* reasm timeout, send all to socket */
          _TcpRxFlush(pxTcp, pxConn, 0);
        }
      }
      /* Retransmission timer */
      _TcpCheckForRetransmit(pxTcp, pxConn, pxConnect);

      TCP_CHECKPOINT(g_dwSendRetx);
    }
    DLLIST_next(&pxTcp->dllConns);
    TCP_CHECKPOINT(g_dwSendRetx);
  }
#endif
}

/***************************************************************************
*  calculate the current Round Trip Time
*
*  par:  oParm1  parameter description
*
*  ret:  0  ret. val. description
****************************************************************************/
static void _TcpCalculateRto(TCPSTATE *pxTcp, TCPCONN_CONNECT *pxConnect,
                               DWORD dwTimestamp)
{
  TCP_CHECK_STATE(pxTcp);
  TCP_ASSERT_HI(pxConnect != NULL);

  /* pxTcp->dwTicks counts the number of timer ticks (each 10 ms)
   * multiply with 100 to avoid floating point calculation */
  pxConnect->dwSrtt = ( TCP_RTO_ALPHA * (pxConnect->dwSrtt) )
               + ((100-TCP_RTO_ALPHA) * (pxTcp->dwTicks - dwTimestamp));
  pxConnect->dwSrtt /= 100;
  pxConnect->dwRto = min(TCP_RTO_UBOUND, max(TCP_RTO_LBOUND,
                                      (TCP_RTO_BETA*pxConnect->dwSrtt)/100 ));
}

/***************************************************************************
*  this function is called when an ACK segment arrives; so check for data
*  being ACKed by the remote host, if so, remove the data from the retransmission
*  queue
*
*  par:  pxConn  ptr to the TCPCONN
*
*  ret:  void
****************************************************************************/
static void _TcpRefreshRetransmissionQueue(TCPSTATE *pxTcp, TCPCONN *pxConn)
{
  TCP_RTX_BUF *pxBuff;
  OCTET oFlagspace=0;
  TCPCONN_CONNECT *pxConnect;
#ifndef __TCP_OPT_ON__
  LONG        lMinReTxTime = pxTcp->dwTicks + (500) ;
  LONG        lMaxReTxTime = lMinReTxTime;
#endif

#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  MSTATUS status = OK;
#endif

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  pxConnect = pxConn->u.pxConnect;
  TCP_ASSERT_HI(pxConnect != NULL);

  /*there is no retransmission buffer*/
  if (DLLIST_count(&pxConnect->dllReTxBuff) == 0) {
    return;
  }


  DLLIST_head(&pxConnect->dllReTxBuff);

  while((pxBuff = DLLIST_read(&pxConnect->dllReTxBuff)) != NULL) {
    NETPACKET_CHECK(&pxBuff->xNetPacket);
#ifdef SEQNUM_ROLLOVER
    if(_TcpBefore(pxBuff->dwSequenceNbr, pxConnect->dwSendUnacked) &&
       _TcpAfter(pxBuff->dwSequenceNbr + pxBuff->xAccess.wLength,
                 pxConnect->dwSendUnacked))
#else
    if((pxBuff->dwSequenceNbr < pxConnect->dwSendUnacked ) &&
      ((pxBuff->dwSequenceNbr + pxBuff->xAccess.wLength) > pxConnect->dwSendUnacked ))
#endif
    {
        /*the segment is only partially ACKed*/
        /*TCP_DBGP(NORMAL,"_TcpRefreshRetransmissionQueue:[%ld] %p: segment paritally acked!\n",
          pxConn->lConnNo, pxConn);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpRefreshRetransmissionQueue:[",pxConn->lConnNo);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] segment partially acked :0x",(sbyte4)pxConn);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }
    }
    /*SYN and FIN ocoupy seq nbr space */
    oFlagspace=0;
    if (pxBuff->oFlags & TCPCONN_FLAGMASK_SYN) {
      oFlagspace++;
    }
    if (pxBuff->oFlags & TCPCONN_FLAGMASK_FIN) {
      oFlagspace++;
    }

    /* TCP_DBGP(REPETITIVE,"_TcpRefreshRetransmissionQueue:[%ld]: %ld+%d+%d <=> %ld \n",
        pxConn->lConnNo, pxBuff->dwSequenceNbr, pxBuff->xAccess.wLength,
        oFlagspace, pxConnect->dwSendUnacked); */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpRefreshRetransmissionQueue:[",pxConn->lConnNo);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"]: ",pxBuff->dwSequenceNbr);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"+",pxBuff->xAccess.wLength);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"+",oFlagspace);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," <=> ",pxConnect->dwSendUnacked);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
    }

#ifdef SEQNUM_ROLLOVER
    if( _TcpBefore(pxBuff->dwSequenceNbr + pxBuff->xAccess.wLength + oFlagspace,
          pxConnect->dwSendUnacked + 1) )
#else
    if( (pxBuff->dwSequenceNbr + pxBuff->xAccess.wLength + oFlagspace) <=
          pxConnect->dwSendUnacked )
#endif
    {
      /*TCP_DBGP(REPETITIVE,"_TcpRefreshRetransmissionQueue:[%ld]: checking for FIN \n", pxConn->lConnNo);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
      {
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpRefreshRetransmissionQueue:[",pxConn->lConnNo);
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] checking for FIN :0x",(sbyte4)pxConn);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }

      if (pxBuff->oFlags & TCPCONN_FLAGMASK_FIN) {
        /*TCP_DBGP(REPETITIVE,"_TcpRefreshRetransmissionQueue:[%ld] 0x%p: Ah, ack for FIN\n", pxConn->lConnNo, pxConn);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpRefreshRetransmissionQueue:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] Ah, ack for FIN :0x",(sbyte4)pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }
        pxConnect->bFinAcked = 1;
      }
      else
        pxConnect->bFinAcked = 0;

      /*segment has been fully ACKed*/
      /*determine the current rto */
      _TcpCalculateRto(pxTcp, pxConnect, pxBuff->dwTimeStamp);
      if ( (oFlagspace > 0) && (pxBuff->xAccess.wLength == 0) ) {
        /*there is nothing but flags in this segment ->data block is header/trailer only*/
/*       TCP_ASSERT_HI(pxBuff->xNetPacket.pxPayload->wSize ==
                pxBuff->xNetPacket.wHeaderLength + pxBuff->xNetPacket.wTrailerLength);
*/
        /* TCP_DBGP(REPETITIVE,"_TcpRefreshRetransmissionQueue:[%ld] 0x%p: DeleteChain: (flags only) 0x%p->DB:0x%p\n",
              pxConn->lConnNo, pxConn, pxBuff, &(pxBuff->xNetPacket)); */

        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpRefreshRetransmissionQueue:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": DeleteChain: (flags only) 0x",(sbyte4)pxBuff);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"->DB:0x",(sbyte4)&(pxBuff->xNetPacket));
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }
        NETPAYLOAD_DELUSER(pxBuff->xNetPacket.pxPayload);

        pxBuff = DLLIST_remove(&pxConnect->dllReTxBuff);
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
        pxBuff->hTcp = NULL;
        if(OK > (status = MEM_POOL_putPoolObject(&pxTcp->retransPool, (void **)(&pxBuff))))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpRefreshRetransmissionQueue: unable to put buffer within retransPool Status = %d\n", status);
#elif defined (__TCP_USE_MEMPOOL_PERF__)
        pxBuff->hTcp = NULL;
        if (OK > (status = MEM_POOL_putPoolObject(&pxConnect->retransPool, (void **)(&pxBuff))))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpRefreshRetransmissionQueue: unable to put buffer within retransPool Status = %d\n", status);
#else
        FREE(pxBuff);
#endif
        continue;
      }
      /*has the complete buffer been ACKed and does the user wish to delete this buffer ?*/
      /* TCP_DBGP(REPETITIVE,"_TcpRefreshRetransmissionQueue:[%ld] 0x%p:freeing pxPayload and data 0x%lx->DB:%lx\n",
              pxConn->lConnNo, pxConn,
              (DWORD)pxBuff->xNetPacket.pxPayload,
              (DWORD)pxBuff->xNetPacket.pxPayload->poPayload); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
      {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpRefreshRetransmissionQueue:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,":freeing pxPayload and data 0x",(sbyte4)(pxBuff->xNetPacket.pxPayload));
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"->DB:",(sbyte4)(pxBuff->xNetPacket.pxPayload->poPayload));
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }
      NETPAYLOAD_DELUSER(pxBuff->xNetPacket.pxPayload);

      pxConnect->wTxUsedSpace -= pxBuff->xAccess.wLength;
      if (pxConnect->wTxUsedSpace <= TCP_TX_RELSPACE
            && pxConnect->bTxNoSpace) {
        /* tx space has become available */
        /* send callback to socket */
        TCP_ASSERT_HI(pxConn->pfnCbk != NULL);
        (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                              (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                              TCPULINTERFACECBK_TXAVAILSPACE,
                              (H_NETDATA)(pxConnect->dwSendWindow + TCP_TX_MAXSPACE -
                                          pxConnect->wTxUsedSpace));
        /* The Cbk may return -1 if the socket has been closed
           in-between. Harmless => in its own time the connection
           will then be cleared up. */
        pxConnect->bTxNoSpace = 0;
      }

      /* TCP_DBGP(REPETITIVE,"_TcpRefreshRetransmissionQueue:[%ld] 0x%p DeleteChain:  pxBuff:0x%p\n",
            pxConn->lConnNo, pxConn,pxBuff);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
      {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpRefreshRetransmissionQueue:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," DeleteChain:  pxBuff:0x",(sbyte4)pxBuff);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
      }
      pxBuff = DLLIST_remove(&pxConnect->dllReTxBuff);
#ifdef __TCP_USE_MEMPOOL_NORMAL__
      pxBuff->hTcp = NULL;
      if(OK > (status = MEM_POOL_putPoolObject(&pxTcp->retransPool, (void **)(&pxBuff))))
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
        {
           DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpRefreshRetransmissionQueue: unable to put buffer within retransPool Status = %d\n", status);
        }
#elif defined (__TCP_USE_MEMPOOL_PERF__)
      pxBuff->hTcp = NULL;
      if (OK > (status = MEM_POOL_putPoolObject(&pxConnect->retransPool, (void **)(&pxBuff))))
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpRefreshRetransmissionQueue: unable to put buffer within retransPool Status = %d\n", status);
#else
      FREE(pxBuff);
#endif
    }
    else {
      DLLIST_next(&pxConnect->dllReTxBuff);
    }
  }

#ifndef __TCP_OPT_ON__
  /*there is no retransmission buffer*/
  if (DLLIST_count(&pxConnect->dllReTxBuff) == 0) {
    return;
  }

  DLLIST_head(&pxConnect->dllReTxBuff);

  while((pxBuff = DLLIST_read(&pxConnect->dllReTxBuff)) != NULL) {
      /* Calculate the Max Time that we can wait for the Retransmit Timer
         but minimum of dwTicks + 500 ms*/
      lMinReTxTime =  pxBuff->dwTimeStamp +   (1 << (pxBuff->oRetries
                      - 1)) * pxConnect->dwRto;
      if (_TcpBefore(lMinReTxTime , lMaxReTxTime))
        lMinReTxTime = lMaxReTxTime;
      DLLIST_next(&pxConnect->dllReTxBuff);
  }

  if (pxConnect->wRetransmitTimer)
      LIST_REMOVE(pxConn, retrans_link);

  pxConnect->wRetransmitTimer = lMinReTxTime;
  _TcpInsertOrderedList (&pxTcp->lRetransList,
                         pxConn,
                         TCP_TIMER_RETRANS);

#endif

}

/***************************************************************************
*  This function is called when new data on the TCP ports arrives, the data is put into the
*  reassembly buffer, which have no spcific order, the reassembly is done by _TcpReassembleInBuffer()
*
*  par:  pxConn    ptr to the TCPCONN
*    pxPayload  ptr to the COMPLETE segemt
*    datalen   OCTETs of payload
*
*  ret:  0  success
*      -1  error
****************************************************************************/
static LONG _TcpFillReassemblyBuffer(TCPCONN_CONNECT *pxConnect, NETPACKET *pxPacket, OCTET *poData, WORD wDatalen)
{
  TCP_RAS_BUF *pxBuff;
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  MSTATUS mStatus;
  TCPSTATE *pxTcp;
#elif defined(__TCP_USE_MEMPOOL_PERF__)
  MSTATUS mStatus;
#endif

  TCP_ASSERT_HI(pxConnect != NULL && poData != NULL);
  NETPACKET_CHECK(pxPacket);

  if (DLLIST_count(&pxConnect->dllReAsBuff) == 0) {
    pxConnect->dwLastUnpackedSequenceNbr = pxConnect->dwSegSequenceNumber-1;
  }

#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  pxTcp = (TCPSTATE *)pxConnect->hTcp;
  if(OK > (mStatus = MEM_POOL_getPoolObject(&pxTcp->reassemblePool, (void **) &pxBuff)))
#elif defined (__TCP_USE_MEMPOOL_PERF__)
  if(OK > (mStatus = MEM_POOL_getPoolObject(&pxConnect->reassemblePool, (void **) &pxBuff)))
#endif

#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  {
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: _TcpFillReassemblyBuffer: unable to allocate buffer");
    return -1;
  }
#else
  pxBuff = (TCP_RAS_BUF *) MALLOC(sizeof(TCP_RAS_BUF));
  if (pxBuff == NULL) {
    /*TCP_DBGP(ERROR, "_TcpFillReassemblyBuffer:calloc() failed\n");*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"_TcpFillReassemblyBuffer:calloc() failed");
    return -1;
  }
#endif
  MOC_MEMSET((ubyte *)pxBuff, 0, sizeof(TCP_RAS_BUF));

#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  pxBuff->hTcp = (H_NETINSTANCE)pxTcp;
#elif defined (__TCP_USE_MEMPOOL_PERF__)
  pxBuff->hTcp = (H_NETINSTANCE)pxConnect;
#endif

  DLLIST_append(&pxConnect->dllReAsBuff, pxBuff);

  pxBuff->xNetPacket=*pxPacket;
  pxBuff->poBegin=poData;
  pxBuff->wDatalen=wDatalen;
  pxBuff->dwSequenceNbr=pxConnect->dwSegSequenceNumber;

  pxConnect->wRxUsedSpace += wDatalen;

  /*signalize the reading function the push flag */
  pxBuff->bPushFlag = (pxConnect->oSegControl & TCPCONN_FLAGMASK_PSH) ? 1 : 0;
  /* TCP_DBGP(REPETITIVE,"_TcpFillReassemblyBuffer: (AL) pxConnect= %p pxBuff=%p\n"
            , pxConnect,pxBuff); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
  {
       DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpFillReassemblyBuffer: (AL) pxConnect= ",(sbyte4)pxConnect);
       DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," pxBuff=",(sbyte4)pxBuff);
       DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
  }


  return 0;
}



/***************************************************************************
*  send a packed TCP data block, using a buffer block for controling
*  sending and retransmission/delete
*
*  par:  pxConn  ptr to the TCPCONN
*      NETPACKET
*      NETPACKETACCESS
*
*
*  ret:  datalen    success
*        -1      error
****************************************************************************/
static WORD _TcpSend(TCPSTATE *pxTcp, TCPCONN *pxConn, NETPACKET *pxPacket,
                     NETPACKETACCESS *pxAccess, BOOL bFinStateAfterTransmit)
{
  TCP_SND_BLK *pxSendBlock;
  TCPCONN_CONNECT *pxConnect;
  NETPAYLOAD *pxPayload;
  OCTET *poPayload;
#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  MSTATUS mStatus;
#endif

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  pxConnect = pxConn->u.pxConnect;
  TCP_ASSERT_HI(pxConnect != NULL && pxAccess != NULL);
  NETPACKET_CHECK(pxPacket);

  pxPayload = pxPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  pxConnect->dwLastUsed=pxTcp->dwTicks;

  switch (pxConn->eState) {
  case TCPCONN_STATE_CLOSED:
     TCP_CHECKPOINT(g_dwSend);
    /* TCP_DBGP(ERROR,"_TcpSend:[%ld] 0x%p:  CLOSED-> return:\n", pxConn->lConnNo, pxConn);*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpSend:[",pxConn->lConnNo);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,":  CLOSED-> return:");
    }
    NETPAYLOAD_DELUSER(pxPacket->pxPayload); /* RS added */
    return -1;

  case TCPCONN_STATE_FIN_WAIT_1:
  case TCPCONN_STATE_FIN_WAIT_2:
  case TCPCONN_STATE_CLOSING:
  case TCPCONN_STATE_LAST_ACK:
  case TCPCONN_STATE_TIME_WAIT:
    TCP_CHECKPOINT(g_dwSend);
    /*TCP_DBGP(ERROR,"_TcpSend:[%ld] 0x%p: F2/CL/LA/TW (%d)->return:\n",
           pxConn->lConnNo, pxConn, pxConn->eState);*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpSend:[",pxConn->lConnNo);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": F2/CL/LA/TW (",pxConn->eState);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,")->return:");
    }
    NETPAYLOAD_DELUSER(pxPacket->pxPayload); /* RS added */
    return -1;

  case TCPCONN_STATE_LISTEN:
  case TCPCONN_STATE_SYNSENT:
  case TCPCONN_STATE_SYNRCVD:
    /*allocate an entry inb the sending buffer */
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
    if(OK > (mStatus = MEM_POOL_getPoolObject(&pxTcp->sendbuffPool, (void **) &pxSendBlock)))
#elif defined (__TCP_USE_MEMPOOL_PERF__)
    if(OK > (mStatus = MEM_POOL_getPoolObject(&pxConnect->sendbuffPool, (void **) &pxSendBlock)))
#endif

#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
    {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: _TcpSend: unable to allocate buffer");
      return -1;
    }
#else
    if((pxSendBlock = (TCP_SND_BLK *) MALLOC(sizeof(TCP_SND_BLK))) == NULL){
      TCP_CHECKPOINT(g_dwSend);
      /*TCP_DBGP(ERROR,"_TcpSend:[%ld] 0x%p: L/SS/SR(%d)->return: No Sending block!\n",
            pxConn->lConnNo, pxConn, pxConn->eState);
           TCP_DBGP(ERROR, "_TcpSend:calloc() failed\n"); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
      {
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpSend:[",pxConn->lConnNo);
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": L/SS/SR(",pxConn->eState);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4,")->return:");
          DEBUG_PRINTNL(DEBUG_MOC_IPV4,"_TcpSend:calloc() failed");
      }
      NETPAYLOAD_DELUSER(pxPacket->pxPayload); /* RS added */
      return -1;
    }
#endif

    MOC_MEMSET((ubyte *)pxSendBlock, 0, sizeof(TCP_SND_BLK));

#if defined (__TCP_USE_MEMPOOL_NORMAL__)
    pxSendBlock->hTcp = (H_NETINSTANCE)pxTcp;
#elif defined (__TCP_USE_MEMPOOL_PERF__)
    pxSendBlock->hTcp = (H_NETINSTANCE)pxConnect;
#endif

    DLLIST_append(&pxConnect->dllSendBuff, pxSendBlock);

    pxSendBlock->poNextToSendData = poPayload + pxAccess->wOffset;
    pxSendBlock->wDatalen=pxAccess->wLength;
    pxSendBlock->wSent = 0;
    /* having wOffset and wTrailer in NETPACKET saves one MOC_MEMCPY call*/
    MOC_MEMCPY((ubyte *)&pxSendBlock->xNetPacket,
                  (ubyte *)pxPacket,
                  sizeof(NETPACKET));

    MOC_MEMCPY((ubyte *)&pxSendBlock->xAccess,
                  (ubyte *)pxAccess,
                  sizeof(NETPACKETACCESS));
    pxSendBlock->bFinStateAfterTransmit = bFinStateAfterTransmit;
    TCP_CHECKPOINT(g_dwSend);
    /*TCP_DBGP(REPETITIVE,"_TcpSend:[%ld] 0x%p: L/SS/SR (%d)->return DATA len=%d:\n",
          pxConn->lConnNo, pxConn, pxConn->eState, pxAccess->wLength); */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpSend:[",pxConn->lConnNo);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": L/SS/SR(",pxConn->eState);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,")->return DATA len=",pxAccess->wLength);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,":");
    }
    /* TCP_DBGP(REPETITIVE,"_TcpSend:[%ld] 0x%p: adding to snd q @%d (AL)0x%lx->DB:0x%lx->D:0x%lx\n",
          pxConn->lConnNo, pxConn, __LINE__,(DWORD)pxSendBlock,(DWORD)pxPacket,(DWORD)pxPacket->pxPayload); */

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpSend:[",pxConn->lConnNo);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": adding to snd q @",__LINE__);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," (AL)0x",(sbyte4)pxSendBlock);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"->DB:0x",(sbyte4)pxPacket);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"->D:0x",(sbyte4)pxPacket->pxPayload);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
    }

    /*do not send in this state - queue this ! */
    return pxAccess->wLength;

  case TCPCONN_STATE_ESTABLISHED:
  case TCPCONN_STATE_CLOSE_WAIT:
    /*allocate an entry inb the sending buffer */
#if defined (__TCP_USE_MEMPOOL_NORMAL__)
    if(OK > (mStatus = MEM_POOL_getPoolObject(&pxTcp->sendbuffPool, (void **) &pxSendBlock)))
#elif defined (__TCP_USE_MEMPOOL_PERF__)
    if(OK > (mStatus = MEM_POOL_getPoolObject(&pxConnect->sendbuffPool, (void **) &pxSendBlock)))
#endif

#if defined(__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
    {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: _TcpSend: unable to allocate buffer");
      return -1;
    }
#else
    if((pxSendBlock = (TCP_SND_BLK *) MALLOC(sizeof(TCP_SND_BLK))) == NULL){
      TCP_CHECKPOINT(g_dwSend);
      /* TCP_DBGP(ERROR,"_TcpSend:[%ld] 0x%p E/CW (%d)->return: No Sending block!\n",
            pxConn->lConnNo, pxConn, pxConn->eState); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
      {
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpSend:[",pxConn->lConnNo);
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," E/CW (",pxConn->eState);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4,")->return: No Sending block!");
      }
      /* TCP_DBGP(ERROR, "_TcpSend:calloc() failed\n"); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: _TcpSend:calloc() failed\n");
      NETPAYLOAD_DELUSER(pxPacket->pxPayload); /* RS added */
      return -1;
    }
#endif
    MOC_MEMSET((ubyte *)pxSendBlock, 0, sizeof(TCP_SND_BLK));

#if defined (__TCP_USE_MEMPOOL_NORMAL__)
    pxSendBlock->hTcp = (H_NETINSTANCE)pxTcp;
#elif defined (__TCP_USE_MEMPOOL_PERF__)
    pxSendBlock->hTcp = (H_NETINSTANCE)pxConnect;
#endif

    DLLIST_append(&pxConnect->dllSendBuff, pxSendBlock);

    pxSendBlock->poNextToSendData=
      pxPacket->pxPayload->poPayload + pxAccess->wOffset;
    pxSendBlock->wDatalen=pxAccess->wLength;
    pxSendBlock->wSent = 0;
    /* having wOffset and wTrailer in NETPACKET saves one memcpy call*/
    MOC_MEMCPY((ubyte *)&pxSendBlock->xNetPacket,
                  (ubyte *)pxPacket,
                  sizeof(NETPACKET));

    MOC_MEMCPY((ubyte *)&pxSendBlock->xAccess,
                  (ubyte *)pxAccess,
                  sizeof(NETPACKETACCESS));

    pxSendBlock->bFinStateAfterTransmit = bFinStateAfterTransmit;
    TCP_CHECKPOINT(g_dwSend);
    /* TCP_DBGP(REPETITIVE,"_TcpSend:[%ld] 0x%p: E/CW (%d)->return DATA len=%d, Sending ACK:\n",
          pxConn->lConnNo, pxConn, pxConn->eState, pxAccess->wLength);*/

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpSend:[",pxConn->lConnNo);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": E/CW (",pxConn->eState);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,")->return DATA len=",pxAccess->wLength);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,", Sending ACK:");
    }

    /* TCP_DBGP(REPETITIVE,"_TcpSend:[%ld] 0x%p:adding (DATA) to snd q @%d (AL)0x%lx->DB:0x%lx->D:0x%lx\n",
          pxConn->lConnNo, pxConn, __LINE__,(DWORD)pxSendBlock,(DWORD)pxPacket,(DWORD)pxPacket->pxPayload); */

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpSend:[",pxConn->lConnNo);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,":adding (DATA) to snd q @",__LINE__);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," (AL)0x",(sbyte4)pxSendBlock);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"->DB:0x",(sbyte4)pxPacket);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"->D:0x",(sbyte4)pxPacket->pxPayload);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
    }

    /*sending an ACK with the first data */
    /* if (pxConnect->dwSendWindow == 0 ) */
    {
      /* Increment the txUsedValue as the ConnSend will not */
      pxConnect->wTxUsedSpace += pxAccess->wLength;
    }

    _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext,pxConnect->dwRcvNext,
          TCPCONN_FLAGMASK_ACK,TCP_DATAON);

    TCP_CHECKPOINT(g_dwSend);
    return pxAccess->wLength;

  default:
    break;
  }
  TCP_CHECKPOINT(g_dwSend);
  NETPAYLOAD_DELUSER(pxPacket->pxPayload); /* RS added */
  return -1;
}

/***************************************************************************
*  this function adds a FIN segment after the to send data segments in
*  the sending buffer, so the connection would be closed after sending
*  the last data
*
*  par:  pxConn  ptr to the TCPCONN
*
*  ret:  void
****************************************************************************/
static void _TcpCloseQueued(TCPSTATE *pxTcp, TCPCONN *pxConn)
{
  TCPCONN_CONNECT *pxConnect;
  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  pxConnect = pxConn->u.pxConnect;
  TCP_ASSERT_HI(pxConnect != NULL);

  /*TCP_DBGP(NORMAL,"_TcpCloseQueued: %ld entered pxConn %p\n",
    pxConn->lConnNo, pxConn);*/
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpClosedQueue:[",pxConn->lConnNo);
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] Enetered :0x",(sbyte4)pxConn);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," State :",pxConn->eState);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
  }

  if (pxConn->eState == TCPCONN_STATE_SYNSENT) {
   /*Close the State Page 60 RFC 793 Handling Close Calls */
    _TcpConnClose(pxTcp, pxConn);
    return;
   }
  /*proceed with normal 4 way FIN handshake.
       * generate an empty block */

  /* send out the data in buffer */
  while (DLLIST_count(&pxConnect->dllSendBuff) > 0) {
    _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext,
                        TCPCONN_FLAGMASK_ACK,TCP_DATAON);
  }

  _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext,
                      TCPCONN_FLAGMASK_ACK|TCPCONN_FLAGMASK_FIN,TCP_NODATA);

  pxConnect->dwSendNext += 1;
  switch (pxConn->eState) {
  case TCPCONN_STATE_CLOSE_WAIT:
    pxConn->eState = TCPCONN_STATE_LAST_ACK;
    break;
  case TCPCONN_STATE_ESTABLISHED:
    pxConn->eState = TCPCONN_STATE_FIN_WAIT_1;
    break;
  default:
    break;
  }
}

/***************************************************************************
*  this function processes TCP options - only MSS right now
*
*  ret:  void
****************************************************************************/
static ubyte  _TcpProcessOptions(OCTET *poOptions, WORD wOptLen, TCPCONN *pxConn)
{
  ubyte oReturnVal = 1;
  ubyte2 wOptActualLen = 0;

  while (wOptLen > 0) {
    switch (*poOptions) {
    case TCP_OPT_END:
      return oReturnVal;

    case TCP_OPT_NOOP:
      wOptLen--;
      poOptions++;
      break;

    case TCP_OPT_MSS:
      wOptActualLen = *(poOptions + 1);
      if ((wOptActualLen) && (wOptActualLen <= wOptLen))
      {
        wOptLen-=wOptActualLen;
        pxConn->wMss = ntohs(*((WORD *)(poOptions+2)));
        poOptions+=*(poOptions+1);
      }
      else
      {
        wOptLen = 0;
        oReturnVal = 0;
      }
      break;

    case TCP_OPT_WSF:
      wOptActualLen = *(poOptions + 1);
      if((wOptActualLen) && (wOptActualLen <= wOptLen ))
      {
        wOptLen-=wOptActualLen;
        poOptions+=*(poOptions+1);
      }
      else
      {
        wOptLen = 0;
        oReturnVal = 0;
      }
      break;

    case TCP_OPT_TMST:
      wOptActualLen = *(poOptions + 1);
      if((wOptActualLen) && (wOptActualLen <= wOptLen))
      {
        wOptLen-=wOptActualLen;
        poOptions+=*(poOptions+1);
      }
      else
      {
        wOptLen = 0;
        oReturnVal = 0;
      }
      break;

    default :
      wOptActualLen = *(poOptions + 1);
      if((wOptActualLen) && (wOptActualLen <= wOptLen))
      {
        wOptLen-=*(poOptions+1);
        poOptions+=*(poOptions+1);
      }
      else
      {
        wOptLen = 0;
        oReturnVal = 0;
      }
    }

  }
  return oReturnVal;

}

/*********************************************************************
 * _TcpSendRST
 *
 * Send a RST packet to an unconnected remote host (SYN failed)
 * New temporary TCPCONN and TCPCONN_CONNECT allocated for this purpose
 *
 * par: TCPSTATE *pxTcp             - TCP instance
 *      TRANSPORT2NETWORKID *pxIpSD - Source/dest ID
 *      TCPHDR *pxTcpHeader         - Header of incoming packet
 *      WORD wLength                - length of incoming packet
 * ret: none
 *
 * Note that this procedure is used to send a packet while in LISTEN
 * state (this is the only procedure that does so). IP and port info
 * are taken from the incoming TRANSPORT2NETWORKID. The TCPCONN_CONNECT
 * structure is allocated to satisfy an ASSERT in _TcpConnSendSegment()
 * but is not otherwise accessed by that procedure.
 *
 *********************************************************************/
static void _TcpSendRST(TCPSTATE *pxTcp, TRANSPORT2NETWORKID *pxIpSD,
                        TCPHDR *pxTcpHeader, WORD wDatalen)
{
  TCPCONN xConn;
  TCPCONN_CONNECT xConnect;

  TCP_CHECK_STATE(pxTcp);
  TCP_ASSERT_HI(pxIpSD != NULL && pxTcpHeader != NULL);

  MOC_MEMSET((ubyte *)&xConn,0x00,sizeof(xConn));

  DEBUG(xConn.dwMagicCookie = TCPCONN_MAGIC_COOKIE);

  xConn.u.pxConnect = &xConnect;

  /*update last access */
  xConnect.dwLastUsed=pxTcp->dwTicks;

  {
    TRANSPORT2NETWORKID *pxNetId = &(xConn.xId.xNetId);
    MOC_MEMCPY((ubyte *)pxNetId,(ubyte *) pxIpSD, sizeof(TRANSPORT2NETWORKID));
    pxNetId->dwSrcIpAddr = pxIpSD->dwDstIpAddr;
    pxNetId->dwDstIpAddr = pxIpSD->dwSrcIpAddr;
    pxNetId->eDstAddrType  = IPADDRT_UNKNOWN;
    pxNetId->dwGatewayAddr = 0;
    xConn.xId.wDstPort = pxTcpHeader->wSrcPort;
    xConn.xId.wSrcPort = pxTcpHeader->wDstPort;
  }

  /*save incomming Header */
  _TcpSaveHeader(&xConnect, pxTcpHeader, wDatalen);

  if(xConnect.oSegControl & TCPCONN_FLAGMASK_ACK) {
    /* If ACK bit is set, copy ACK number as seq number */
    _TcpConnSendSegment(pxTcp, &xConn, xConnect.dwSegAckNumber, 0,
                        TCPCONN_FLAGMASK_RST , TCP_NODATA);
  }
  else {
    _TcpConnSendSegment(pxTcp, &xConn, 0,
                        xConnect.dwSegSequenceNumber + wDatalen + 1,
                        TCPCONN_FLAGMASK_RST | TCPCONN_FLAGMASK_ACK,
                        TCP_NODATA);
  }
}


/*#ifdef TCPDBG_HI*/
void _TcpPrintConnection(TCPSTATE *pxTcp)
{
  TCPCONN *pxTcpConn;
  RBLIST  *rbList;
  DWORD   timerStarted = 0;

  printf("**** TcpPrintConnection ****\n");

  DLLIST_head(&pxTcp->dllConns);
  while((pxTcpConn = DLLIST_read(&pxTcp->dllConns)) != NULL){
    printf("[%ld] 0x%p %s from %ld.%ld.%ld.%ld/%d to %ld.%ld.%ld.%ld/%d\n",
           pxTcpConn->lConnNo,
           pxTcpConn,
           _TcpStateToString(pxTcpConn->eState),
           IPADDRDISPLAY(pxTcpConn->xId.xNetId.dwSrcIpAddr),
           pxTcpConn->xId.wSrcPort,
           IPADDRDISPLAY(pxTcpConn->xId.xNetId.dwDstIpAddr),
           pxTcpConn->xId.wDstPort
           );
    DLLIST_next(&pxTcp->dllConns);
  }
#ifndef __TCP_OPT_ON__
  if ((rbList = rbopenlist(pxTcp->connTree)) == NULL)
  {
  /*out of memory */
    return ;
  }

  while ((pxTcpConn = (TCPCONN *)rbreadlist(rbList)))
  {
    if (pxTcpConn->u.pxConnect->wFinwait2Timer) /* FIN_WAIT_2 & 2MSL timer */
        timerStarted |= FINWAIT_2MSL_TIMER;
    if (pxTcpConn->u.pxConnect->wConestabTimer)  /* Conn. est. & keepalive timer */
        timerStarted |= CONESTAB_TIMER;
    if (pxTcpConn->u.pxConnect->wPersistTimer)   /* Persist timer */
        timerStarted |= PERSIST_TIMER;
    if (pxTcpConn->u.pxConnect->wLingerTimer)    /* Closing linger time */
        timerStarted |= LINGER_TIMER;
    if (pxTcpConn->u.pxConnect->wReasmTimer)     /* Reassembly timer */
        timerStarted |= REASM_TIMER;
    if (pxTcpConn->u.pxConnect->wRetransmitTimer) /* Retransmit Timer */
        timerStarted |= RETRANSMIT_TIMER;
    if (pxTcpConn->u.pxConnect->wFastackTimer)    /* Retransmit Timer */
        timerStarted |= FASTACK_TIMER;
    printf("[%ld] fd [%ld] 0x%p %s from %ld.%ld.%ld.%ld/%d to %ld.%ld.%ld.%ld/%d Timers Mask 0x%x\n",
           pxTcpConn->lConnNo,
           pxTcpConn->lFd,
           pxTcpConn,
           _TcpStateToString(pxTcpConn->eState),
           IPADDRDISPLAY(pxTcpConn->xId.xNetId.dwSrcIpAddr),
           pxTcpConn->xId.wSrcPort,
           IPADDRDISPLAY(pxTcpConn->xId.xNetId.dwDstIpAddr),
           pxTcpConn->xId.wDstPort,
           timerStarted
           );
  }

  rbcloselist(rbList);
#endif
}

CHAR* _TcpStateToString(E_TCPCONN_STATE eState)
{
  switch(eState){
  case  TCPCONN_STATE_CLOSED:
    return "TCPCONN_STATE_CLOSED";
    break;
  case TCPCONN_STATE_LISTEN:
    return "TCPCONN_STATE_LISTEN";
    break;
  case TCPCONN_STATE_SYNSENT:
    return "TCPCONN_STATE_SYNSENT";
    break;
  case TCPCONN_STATE_SYNRCVD:
    return "TCPCONN_STATE_SYNRCVD";
    break;
  case TCPCONN_STATE_ESTABLISHED:
    return "TCPCONN_STATE_ESTABLISHED";
    break;
  case TCPCONN_STATE_FIN_WAIT_1:
    return "TCPCONN_STATE_FIN_WAIT_1";
    break;
  case TCPCONN_STATE_FIN_WAIT_2:
    return "TCPCONN_STATE_FIN_WAIT_2";
    break;
  case TCPCONN_STATE_CLOSING:
    return "TCPCONN_STATE_CLOSING";
    break;
  case TCPCONN_STATE_TIME_WAIT:
    return "TCPCONN_STATE_TIME_WAIT";
    break;
  case TCPCONN_STATE_CLOSE_WAIT:
    return "TCPCONN_STATE_CLOSE_WAIT";
    break;
  case TCPCONN_STATE_LAST_ACK:
    return "TCPCONN_STATE_LAST_ACK";
    break;
  default :
    return "???";
  }
}
/*#endif */ /*#ifdef TCPDBG_HI*/

/*
 * TcpInstanceInterfaceShow
 *  Show TCP  Interfaces Available
 *
 *  Args:
 *   hTcp                       TCP instance
 *
 *  Return:
 *    void
 */
void TcpInstanceInterfaceShow(H_NETINSTANCE hTcp)
{
  TCPSTATE *pxTcp = (TCPSTATE *) hTcp;
  _TcpPrintConnection(pxTcp);

}

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * TcpInitialize
 *  Initialize the Tcp Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG TcpInitialize(void)
{
  /* Does nothing */

  /* Initialize the debug level to ERROR */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR);
  INET_DBG_LEVEL_SET(INET_DBG_MOD_SOCKET, INET_DBG_LEVEL_ERROR);


  return 0;
}

/*
 * TcpTerminate
 *  Terminate the Tcp Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG TcpTerminate(void)
{
  /* Does nothing */
  return 0;
}

/*
 * TcpInstanceCreate
 *  Creates a TCP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE TcpInstanceCreate(void)
{
  TCPSTATE *pxTcp;
#if defined (__TCP_USE_MEMPOOL__) || defined (__TCP_USE_MEMPOOL_NORMAL__)
  void*   pTempMemBuffer = NULL;
#endif
  LONG status ;

  pxTcp = (TCPSTATE *)MALLOC(sizeof(TCPSTATE));
  ASSERT(pxTcp != 0);
  MOC_MEMSET((ubyte *)pxTcp, 0, sizeof(TCPSTATE));

  /*Set the tcp magic cookie*/
  TCP_SET_COOKIE(pxTcp);

#ifndef __TCP_OPT_ON__

  LIST_INIT(&pxTcp->lPersistList);
  LIST_INIT(&pxTcp->lLingerList);
  LIST_INIT(&pxTcp->lFinwait2List);
  LIST_INIT(&pxTcp->lReasmList);
  LIST_INIT(&pxTcp->lRetransList);
  LIST_INIT(&pxTcp->lConestabList);
  LIST_INIT(&pxTcp->lFastackList);

  pxTcp->connTree = (rbtree_t *) rbinit (_TcpCompareRxConn,NULL,0);

  if (!pxTcp->connTree)
  {
      FREE(pxTcp);
      return NULL;
  }

  status = MBITMAP_createMap(&pxTcp->portNumbers, 1024, 65534);
  if (OK != status)
  {
      /*TCP_DBGP(ERROR,"_TcpState Init: Unable to Create Port Map Status = %d\n",
               status);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpState Init: Unable to Create Port Map Status = %d\n", status);
      FREE(pxTcp);
      return NULL;
  }
#endif

#ifdef __TCP_USE_MEMPOOL__
  pTempMemBuffer = MALLOC (sizeof(TCPCONN) * TCPDEFAULT_MAXCONNNECTION);

  if (OK > (status = MEM_POOL_initPool(&pxTcp->connPool, pTempMemBuffer, sizeof(TCPCONN) * TCPDEFAULT_MAXCONNNECTION, sizeof(TCPCONN))))
  {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpState Init: Unable to Create Conn MemPool Status = %d\n", status);
      FREE(pxTcp);
      return NULL;
  }
#endif

#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  /* Creation of mempool for Re-Transmission pool */
  pTempMemBuffer = MALLOC (sizeof(TCP_RTX_BUF) * TCP_RTX_BUF_MAX);

  if (OK > (status = MEM_POOL_initPool(&pxTcp->retransPool, pTempMemBuffer, sizeof(TCP_RTX_BUF) * TCP_RTX_BUF_MAX, sizeof(TCP_RTX_BUF))))
  {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpState Init: Unable to Create Re-Transmission MemPool Status = %d\n", status);
      FREE(pxTcp);
      return NULL;
  }

  /* Creation of mempool for Re-Assemble pool */
  pTempMemBuffer = MALLOC (sizeof(TCP_RAS_BUF) * TCP_RAS_BUF_MAX);

  if (OK > (status = MEM_POOL_initPool(&pxTcp->reassemblePool, pTempMemBuffer, sizeof(TCP_RAS_BUF) * TCP_RAS_BUF_MAX, sizeof(TCP_RAS_BUF))))
  {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpState Init: Unable to Create Re-Assemble MemPool Status = %d\n", status);
      FREE(pxTcp);
      return NULL;
  }

  /* Creation of mempool for Send pool */
  pTempMemBuffer = MALLOC (sizeof(TCP_SND_BLK) * TCP_SND_BLK_MAX);

  if (OK > (status = MEM_POOL_initPool(&pxTcp->sendbuffPool, pTempMemBuffer, sizeof(TCP_SND_BLK) * TCP_SND_BLK_MAX, sizeof(TCP_SND_BLK))))
  {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "_TcpState Init: Unable to Create Send Buffer MemPool Status = %d\n", status);
      FREE(pxTcp);
      return NULL;
  }
#endif

  /* default defines are seconds but slow timer is 500 msec */
  pxTcp->w2mslTimer = TCPDEFAULT_2MSLTIMER*2;
  pxTcp->wRttTimer = TCPDEFAULT_RTTTIMER*2;
  pxTcp->wPersistTimer = TCPDEFAULT_PERSISTIMER*2;
  pxTcp->wKeepAliveTimer = TCPDEFAULT_KEEPALIVETIMER*2;
  pxTcp->wMaxConn = TCPDEFAULT_MAXCONNNECTION;

  pxTcp->dwTicks = NetGetMsecTime();
  pxTcp->dwIss = 1;

  /* For snmp, add to the list of tcp instances */
    {
        TCPSTATE *pxTempTcpInstanceList;

        pxTempTcpInstanceList = (TCPSTATE *)MALLOC((oTcpInstances+1)*sizeof(TCPSTATE *));
        ASSERT(pxTempTcpInstanceList);
        MOC_MEMCPY((ubyte *)pxTempTcpInstanceList,(ubyte *)ppxTcpInstanceList,
            (oTcpInstances*sizeof(TCPSTATE *)));

        ++oTcpInstances;
        ppxTcpInstanceList = (TCPSTATE **)pxTempTcpInstanceList;
    }
  ppxTcpInstanceList[oTcpInstances-1] = pxTcp;

  SNMP(xTcpipData.tcpRtoMin = TCP_RTO_LBOUND);
  SNMP(xTcpipData.tcpRtoMax = TCP_RTO_UBOUND);
  SNMP(xTcpipData.tcpRtoAlgorithm = (DWORD)1); /*other=1, constant=2, rsre=3, vanj=4  */
  SNMP(xTcpipData.tcpMaxConn = (DWORD)TCPDEFAULT_MAXCONNNECTION);

  return (H_NETINSTANCE)pxTcp;
}

/*
 * TcpInstanceDestroy
 *  Destroy a TCP Instance
 *
 *  Args:
 *   hTcp                       TCP instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG TcpInstanceDestroy(H_NETINSTANCE hTcp)
{
  TCPSTATE *pxTcp = (TCPSTATE *)hTcp;
  WORD wCnt;
#ifndef __TCP_OPT_ON__
  RBLIST                 *rbList;
  TCPCONN * pxConn2 = NULL;
#endif
#if defined (__TCP_USE_MEMPOOL__) || defined (__TCP_USE_MEMPOOL_NORMAL__)
  void*   pTemp = NULL;
#endif

  TCP_CHECK_STATE(pxTcp);

  clear_DLLIST(&pxTcp->dllConns,_TcpConnFree);

#ifndef __TCP_OPT_ON__

  if ((rbList = rbopenlist(pxTcp->connTree)) == NULL)
  {
  /*out of memory */
    return 0;
  }

  while ((pxConn2 = (TCPCONN *)rbreadlist(rbList)))
  {
    _TcpConnFree(pxConn2);
  }

  rbcloselist(rbList);

  if (pxTcp->portNumbers)
  {
    MBITMAP_releaseMap(&pxTcp->portNumbers);
    pxTcp->portNumbers = NULL;
  }
  if(pxTcp->connTree)
  {
    rbdestroy(pxTcp->connTree);
    pxTcp->connTree = NULL;
  }

#endif

#ifdef __TCP_USE_MEMPOOL__
  if (OK <= MEM_POOL_uninitPool(&pxTcp->connPool, &pTemp))
        FREE(pTemp);
#endif

#if defined (__TCP_USE_MEMPOOL_NORMAL__)
  if (OK <= MEM_POOL_uninitPool(&pxTcp->retransPool, &pTemp))
        FREE(pTemp);
  if (OK <= MEM_POOL_uninitPool(&pxTcp->reassemblePool, &pTemp))
        FREE(pTemp);
  if (OK <= MEM_POOL_uninitPool(&pxTcp->sendbuffPool, &pTemp))
        FREE(pTemp);
#endif

  FREE (pxTcp);

  /* have to take pointer out of snmp list */
  wCnt = 0;
  while (wCnt < oTcpInstances) {
    if (ppxTcpInstanceList[wCnt] == pxTcp) break;
    wCnt++;
  }
  ASSERT(wCnt < oTcpInstances);

  oTcpInstances--;
  while (wCnt < oTcpInstances) {
    ppxTcpInstanceList[wCnt] = ppxTcpInstanceList[wCnt+1];
    wCnt++;
  }

    {
        TCPSTATE *pxTempTcpInstanceList;

        pxTempTcpInstanceList = (TCPSTATE *)MALLOC((oTcpInstances)*sizeof(TCPSTATE *));
        ASSERT(pxTempTcpInstanceList);
        MOC_MEMCPY((ubyte *)pxTempTcpInstanceList,(ubyte *)ppxTcpInstanceList,
            (oTcpInstances*sizeof(TCPSTATE *)));

        ppxTcpInstanceList = (TCPSTATE **)pxTempTcpInstanceList;
    }

  return 0;
}

/*
 * TcpInstanceSet
 *  Set a TCP Instance Option
 *
 *  Args:
 *   hTcp                       TCP instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG TcpInstanceSet(H_NETINSTANCE hTcp,OCTET oOption,
                    H_NETDATA hData)
{
  TCPSTATE *pxTcp = (TCPSTATE *)hTcp;
  LONG lReturn = NETERR_NOERR;

  TCP_CHECK_STATE(pxTcp);
  switch(oOption) {
  case NETOPTION_FREE:
    pxTcp->pfnNetFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_MALLOC:
    pxTcp->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    pxTcp->pxMutex = (pthread_mutex_t*)hData;
    break;
  case NETOPTION_OFFSET:/* Packet offset value */
    pxTcp->wOffset = (WORD)hData;
    break;

  case NETOPTION_TRAILER:/* Packet trailer value */
    pxTcp->wTrailer = (WORD)hData;
    break;

  case NETOPTION_NETCBK:
    pxTcp->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case TCPOPTION_2MSLTIMER:/* MSL Timer value, in ms. Default is 30 sec */
  case TCPOPTION_RTTIMER:  /* Retransmission Timer initial value in ms. Each
                              Connection will have its own freely evolving
                              copy. Default is 1000 ms */
  case TCPOPTION_PERSISTTIMER:/* Persist timer in ms. Default is 1.5 sec */
  case TCPOPTION_KEEPALIVETIMER: /* Keep Alive Timer. Default is 0 which
                                    means that it is not used */
    *((WORD *)(&pxTcp->wOffset + oOption)) = ((WORD) hData) / 500;

    /* Stored with a granularity of 500 ms */
    ASSERT(*((WORD *)(&pxTcp->wOffset + oOption))> 0);

    break;

  case TCPOPTION_NAGLE:    /* Uses Nagle algorithm. Default is No. Option
                              Data is a BOOL !!! NOT SUPPORTED YET !!!*/
  case TCPOPTION_MTUDISCOVERY:/* Uses MTU discovery. Default is No. Option
                                 data is a BOOL !!! NOT SUPPORTED YET !!!*/
    if ((BOOL)hData != FALSE) {
      ASSERT(0);
      lReturn = NETERR_UNSUPPORTED;
    }
    break;

  default:
    lReturn = NETERR_UNKNOWN;

  }

  return lReturn;
}

/*
 * TcpInstanceMsg
 *  Send a msg to a TCP instance
 *
 *  Args:
 *   hTcp                       TCP instance
 *   oMsg                       Msg. See netcommon.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG TcpInstanceMsg(H_NETINSTANCE hTcp,OCTET oMsg,
                    H_NETDATA hData)
{
  /* ignore it for now */
#ifdef NEW_ICMP_MSG_ADDED
  switch(oMsg)
  {
    case TCPMSG_ICMPERRORS:
    {
      TRANSPORTMSGDATA *pxTransportMsgData;
      NETPAYLOAD *pxPayload;
      NETPACKET *pxNetPacket;
      ubyte *poPayload;
      ubyte oErrNo;

      pxTransportMsgData = (TRANSPORTMSGDATA *)(hData);
      pxNetPacket        = pxTransportMsgData->pxNetPacket;
      pxPayload          = pxNetPacket->pxPayload;
      poPayload          = pxPayload->poPayload;
      oErrNo             = pxTransportMsgData->oCode;

      /*TCP_DBGP(NORMAL,"TcpInstanceMsg: icmp error message obtained with error code : %d\n", oErrNo);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
          DEBUG_ERROR(DEBUG_MOC_IPV4, "TcpInstanceMsg: icmp error message obtained with error code : ", (sbyte4)oErrNo);
      switch(oErrNo)
      {
        case ICMPERR_UNREACH_NET: break; /*As an example how UNREACH can be used in future*/
        default: ASSERT(0);
      }

      NETPAYLOAD_DELUSER(pxPayload);
      break;
    }
    default:
      break;
  }
#endif
  return 0;
}

/*
 * TcpInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer. It corresponds
 *  to a socket.
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hTcp                       TCP instance
 *
 *  Return:
 *   H_NETINTERFACE                Interface handle
 */
H_NETINTERFACE TcpInstanceULInterfaceCreate(H_NETINSTANCE hTcp)
{
  TCPSTATE *pxTcp = (TCPSTATE *) hTcp;
  TCPCONN *pxNewConn = NULL ;
  MSTATUS status;

  TCP_CHECK_STATE(pxTcp);

#ifdef __TCP_USE_MEMPOOL__
  if (OK > (status = MEM_POOL_getPoolObject(&pxTcp->connPool, (void **)&(pxNewConn))))
        goto exit;
#else
  pxNewConn = (TCPCONN *)MALLOC(sizeof(TCPCONN));
#endif
  ASSERT(pxNewConn != NULL);
  MOC_MEMSET((ubyte *)pxNewConn, 0, sizeof(TCPCONN));

  DEBUG(pxNewConn->dwMagicCookie = TCPCONN_MAGIC_COOKIE);


  pxNewConn->hTcp    = hTcp;
  /* use the ticker for the connection number*/
  pxNewConn->lConnNo = (LONG) (pxTcp->dwTicks/2);

  pxNewConn->wLocalMss = TCPULINTERFACEDEFAULT_MSS;
  pxNewConn->wMss = TCPULINTERFACEDEFAULT_MSS;
  pxNewConn->wWin = TCPULINTERFACEDEFAULT_WIN;
  pxNewConn->dwAppWinFactor = 100;

  /* set interface, VLAN to don't care */
  pxNewConn->xId.xNetId.oIfIdx = NETIFIDX_DEFAULT;
  /* If will be set by the socket on connecting */
  pxNewConn->xId.xNetId.wVlan = NETVLAN_DEFAULT;

  pxNewConn->bIsReuseAllowed = FALSE;

  DLLIST_append(&pxTcp->dllConns,pxNewConn);

exit:
  return (H_NETINTERFACE)pxNewConn;
}

/*
 * TcpInstanceULInterfaceDestroy
 *  Destroy a TCP UL interface
 *
 *  Args:
 *   hTcp                       TCP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG TcpInstanceULInterfaceDestroy(H_NETINSTANCE hTcp,
                                   H_NETINTERFACE hInterface)
{
  TCPSTATE *pxTcp = (TCPSTATE *)hTcp;
  TCPCONN *pxConn = (TCPCONN *)hInterface;
  TCPCONN *pxConnTmp = NULL;
  LONG lReturn = NETERR_NOERR;

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  if(NULL == pxConn)
  {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      DEBUG_PRINTNL(DEBUG_MOC_IPV4,"_TcpUlInterfaceDestroy: pxConn is NULL");
    return lReturn;
  }

  DLLIST_head(&pxTcp->dllConns);

  if ((pxConnTmp = DLLIST_find(&pxTcp->dllConns,(void *)pxConn,
                       _TcpFindItemByAddress))
      != NULL) {
    TCPCONN_CHECK(pxConn);
    /*TCP_DBGP(NORMAL,"_TcpUlInterfaceDestroy: dllConn removed %ld pxConn %p\n",
        pxConn->lConnNo, pxConn);*/
#ifndef __TCP_OPT_ON__
    if (1024 <= pxConn->xId.wSrcPort )
      lReturn = MBITMAP_clearIndex(pxTcp->portNumbers, pxConn->xId.wSrcPort);
#endif
   if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
   {
       DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpUlInterfaceDestroy:[",pxConn->lConnNo);
       DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] pxConn :0x",(sbyte4)pxConn);
       DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," Port #",pxConn->xId.wSrcPort);
       DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
   }
    DLLIST_remove(&pxTcp->dllConns);
    _TcpConnFree((void *)pxConn);
    return lReturn;
  }

#ifndef __TCP_OPT_ON__
  if (NULL == (pxConnTmp = (TCPCONN *)rbdelete (pxConn,pxTcp->connTree)))
  {
    ASSERT(0);
    lReturn = NETERR_BADHANDLE;
    return lReturn;
  }
  else
  {
    if (1024 <= pxConn->xId.wSrcPort )
      lReturn = MBITMAP_clearIndex(pxTcp->portNumbers, pxConn->xId.wSrcPort);
    /*TCP_DBGP(NORMAL,"_TcpUlInterfaceDestroy: connTree removed %ld pxConn %p srcport [%d]\n",
        pxConn->lConnNo, pxConn,pxConn->xId.wSrcPort);*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"_TcpUlInterfaceDestroy: connTree Removed [",pxConn->lConnNo);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] pxConn :0x",(sbyte4)pxConn);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," SrcPort [",pxConn->xId.wSrcPort);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"] ");
    }
    _TcpConnFree((void *)pxConn);
    return lReturn;
  }
#endif

  ASSERT(0);
  lReturn = NETERR_BADHANDLE;

  return lReturn;
}

/*
 * TcpInstanceULInterfaceIoctl
 *  TCP UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions for precisions
 *
 *  Args:
 *   hTcp                         Tcp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG TcpInstanceULInterfaceIoctl(H_NETINSTANCE hTcp,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  TCPSTATE *pxTcp = (TCPSTATE *)hTcp;
  TCPCONN *pxConn = (TCPCONN *)hULInterface;
  TCPCONN *pxConnTmp = NULL;
  TCPCONN_CONNECT *pxConnect = NULL;
  NETPACKET *pxPacket;
  NETPAYLOAD *pxPayload;
  BOOL bDropNow = 0;
  LONG lReturn = NETERR_NOERR;

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);

  if (pxConn != NULL) {
    TCPCONN_CHECK(pxConn);
    /* Found the Connection */
    /* If the Connection state is compatible with the
       ioctl, proceed. */
    if ((oIoctl != NETINTERFACEIOCTL_CLOSE) &&
        (oIoctl != TCPULINTERFACEIOCTL_SETWIN) &&
        (pxConn->eState >= TCPCONN_STATE_ESTABLISHED) &&
        ((oIoctl <= NETTRANSPORTULINTERFACEIOCTL_CONNECT) ||
         ((oIoctl >= TCPULINTERFACEIOCTL_SETMSS) &&
          (oIoctl < TCPULINTERFACEIOCTL_QUERYMSS)))) {
      /* The ioctl can't be handled in this state */
      ASSERT(0);
      lReturn = NETERR_BADVALUE;
    }
    else {
      TRANSPORT2NETWORKID *pxConnNetId;

      pxConnNetId = &(pxConn->xId.xNetId);
      ASSERT(pxConnNetId != NULL);

#ifndef NDEBUG
      /* Handle Ioctl ASSERTs to minimise codespace taken in debug build */
      switch(oIoctl) {
        case NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALIP:
        case NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT:
        case NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEIP:
        case NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEPORT:
        case NETTRANSPORTULINTERFACEIOCTL_QUERYTRANSPORTID:
        case TCPULINTERFACEIOCTL_QUERYMSS:
        case TCPULINTERFACEIOCTL_QUERYWIN:
        case TCPULINTERFACEIOCTL_QUERYHDRS:
        case TCPULINTERFACEIOCTL_QUERYREMOTEMSS:
          ASSERT(hData != (H_NETDATA) NULL);
          break;

        default:
         break;
      }
#endif

      /* Handle Ioctl */
      switch(oIoctl) {
      case NETTRANSPORTULINTERFACEIOCTL_SETLOCALIP:
        /* Set Local IP. Data is a DWORD. MANDATORY */
        pxConnNetId->dwSrcIpAddr = (DWORD) hData;
        break;

      case NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALIP:
        /* Query Local IP. Data is DWORD * */
        *((DWORD *)hData) = pxConnNetId->dwSrcIpAddr;
        break;

      case NETTRANSPORTULINTERFACEIOCTL_SETLOCALPORT:
        /* Set Local Port. Data is a WORD. Optional */
        if ((WORD) hData == 0) {
          /* get a new port number */
          return _TcpFindNewLocalPort(pxTcp, pxConn);
        }
        else {
          return _TcpSetLocalPort(pxTcp, pxConn, hData, pxConn->bIsReuseAllowed);
        }

      case NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT:/* Query Local Port.
                                                          Data is WORD * */
        *((WORD *)hData) = pxConn->xId.wSrcPort;
        break;

      case NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEIP:
        /* Query the Remote IP. Data is DWORD * */
        *((DWORD *)hData) = pxConnNetId->dwDstIpAddr;
        break;

      case NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEPORT:
        /* Query the Remote Port. Data is WORD **/
       *((WORD *)hData) = pxConn->xId.wDstPort;
        break;

      case NETTRANSPORTULINTERFACEIOCTL_SETIF:
        /* Set interface index. Data is OCTET **/
        pxConnNetId->oIfIdx = (OCTET)hData;
        break;

      case NETTRANSPORTULINTERFACEIOCTL_SETVLAN:
        /* Set VLAN reference. Data is WORD */
        pxConnNetId->wVlan = (WORD)hData;
        break;

      case NETTRANSPORTULINTERFACEIOCTL_QUERYTRANSPORTID:
        MOC_MEMCPY((ubyte *)hData,(ubyte *)&(pxConn->xId),sizeof(TRANSPORTID));
        break;

      case NETTRANSPORTULINTERFACEIOCTL_SETREUSEADDR: /* reuse addr option */
        pxConn->bIsReuseAllowed = (BOOL)hData;
        break;

#ifndef __TCP_OPT_ON__
      case TCPULINTERFACEIOCTL_SETFD:
        pxConn->lFd = (LONG)hData;
        break;
#endif
/*called from socket.c : 168 */
      case TCPULINTERFACEIOCTL_SETMSS:  /* Connection Maximum segment size.
                                           Default == 536 bytes (RFC 793).
                                           Option Data is a WORD */
        pxConn->wLocalMss = (WORD)hData;
        break;

      case TCPULINTERFACEIOCTL_QUERYMSS:/* Query the connection MSS.
                                           data is WORD * */
        *((WORD *)hData) = pxConn->wLocalMss;
        break;

      case TCPULINTERFACEIOCTL_QUERYREMOTEMSS:/* Query the connection REMOTE MSS.
                                           data is DWORD * */
        *((DWORD *)hData) = pxConn->wMss;
        break;
      case TCPULINTERFACEIOCTL_CHANGERXWIN:/* Change the Adversized Window % Ba
                                           based upon Applications Needs
                                           data is DWORD * */
        if ((*((DWORD *)hData) < 30) ||
            (*((DWORD *)hData) > 100 ))
        {
          lReturn = NETERR_BADVALUE;
          break;
        }

        pxConn->dwAppWinFactor = *((DWORD *)hData);

        break;
/*called from socket.c : 171 */
      case TCPULINTERFACEIOCTL_SETWIN:  /* Set Maximum Window size. Size of
                                           the reassembly buffer. Default is
                                           536. Option Data is a WORD */
        pxConn->wWin = (WORD) hData;
        break;

      case TCPULINTERFACEIOCTL_QUERYWIN:/* Query the connection window size */

        *((WORD *)hData) = pxConn->wWin;
        break;

      case TCPULINTERFACEIOCTL_QUERYHDRS:/* Query the header size. data
                                            is WORD * */
        *((WORD *)hData) = TCPDEFAULT_HDRSIZE;
        break;

      case TCPULINTERFACEIOCTL_LISTEN: /* Set the socket to the Listen Mode.
                                          Note this is not a Reversible
                                          setting. A listening socket will
                                          stay listening for ever. Data is
                                          the backlog (OCTET) */
        pxConn->oFlag |= TCPCONN_FLAGVALUE_MODELISTEN;

        ASSERT(pxConn->u.pxListen == NULL);
        pxConn->u.pxListen = (TCPCONN_LISTEN *)
        MALLOC(sizeof(TCPCONN_LISTEN));
        ASSERT(pxConn->u.pxListen != NULL);
        MOC_MEMSET((ubyte *)pxConn->u.pxListen, 0, sizeof(TCPCONN_LISTEN));

        break;

      case NETTRANSPORTULINTERFACEIOCTL_CONNECT:
        /* Set the Socket to be connecting. Data is transport Id*/
        {
          TRANSPORTID *pxNewId = (TRANSPORTID *)hData;

          ASSERT((pxNewId != NULL) &&
                ((pxConn->oFlag & TCPCONN_FLAGMASK_MODE) != TCPCONN_FLAGVALUE_MODELISTEN) &&
                 (pxConn->u.pxConnect == NULL));

          if(pxConn->u.pxConnect != NULL)
            return -1; /*ANVL 4.21 */
          pxConn->u.pxConnect = (TCPCONN_CONNECT *)
            MALLOC(sizeof(TCPCONN_CONNECT));
          ASSERT(pxConn->u.pxConnect != NULL);
          MOC_MEMSET((ubyte *)pxConn->u.pxConnect, 0, sizeof(TCPCONN_CONNECT));


          /* Set The TCP STATE */
          pxConn->u.pxConnect->hTcp = hTcp;
          /* Set The TCP CONN */
          pxConn->u.pxConnect->hConn = (H_NETINSTANCE)pxConn;
          /* Keep the port */
          pxNewId->wSrcPort = pxConn->xId.wSrcPort;

          /* Keep the original address, if set */
          if (pxConnNetId->dwSrcIpAddr != 0) {
            pxNewId->xNetId.dwSrcIpAddr = pxConnNetId->dwSrcIpAddr;
          }
          /* Keep the interface & vlan, if set */
          if (pxConnNetId->oIfIdx != NETIFIDX_ANY) {
            pxNewId->xNetId.oIfIdx = pxConnNetId->oIfIdx;
          }
          if (pxConnNetId->wVlan != NETVLAN_ANY) {
            pxNewId->xNetId.wVlan = pxConnNetId->wVlan;
          }
          MOC_MEMCPY((ubyte *)&(pxConn->xId),(ubyte *)pxNewId,sizeof(TRANSPORTID));
        }
        break;

      case NETINTERFACEIOCTL_SETHINST:
        pxConn->hUL = (H_NETINSTANCE)hData;
        break;

      case NETINTERFACEIOCTL_SETIF:
        pxConn->hIf = (H_NETINSTANCE)hData;
        break;


      case NETINTERFACEIOCTL_SETOUTPUTPFN:/* Set the Rx Call back. Data is
                                              PFN_NETWORKRXCBK */
        pxConn->pfnRxCbk = (PFN_NETRXCBK) hData;
        break;

      case TCPULINTERFACEIOCTL_SETMSGCBK:/* Set the interface Cbk function */

        pxConn->pfnCbk = (PFN_TCPULINTERFACECBK) hData;
        break;

      case NETINTERFACEIOCTL_OPEN:
        /* Open the interface, all needed configuration
           must be done. No Data */
        if (pxConn->xId.wSrcPort == 0) {
          /* if it is not set, set the local port */
          lReturn = _TcpFindNewLocalPort(pxTcp, pxConn);
          if (lReturn == -1) {
            ASSERT(0);
            break;
          }
        }
        /* If connect, check that the remote id has been set
           properly */
        if ((pxConn->oFlag & TCPCONN_FLAGMASK_MODE) ==
            TCPCONN_FLAGVALUE_MODECONNECT) {
          if ((pxConnNetId->dwDstIpAddr == 0) ||
              (pxConn->xId.wDstPort == 0)) {
            ASSERT(0);
            lReturn = NETERR_BADVALUE;
            break;
          }

          /* All checks passed : starts the Open */
          pxConnect = pxConn->u.pxConnect;
          ASSERT(pxConnect != NULL);

          _TcpInitConnect(pxTcp, pxConn, pxConnect);

#ifndef __TCP_OPT_ON__
          if ( pxConnect->wConestabTimer )
            LIST_REMOVE (pxConn, conestab_link);
#endif /* __TCP_OPT_ON__*/
          /*Set up timer*/
          pxConnect->wConestabTimer = TCP_CONESTAB_TIMER;
#ifndef __TCP_OPT_ON__
         /* Convert it to Actual  Ticks */
          pxConnect->wConestabTimer = pxConnect->wConestabTimer * 500 +  pxTcp->dwTicks;
          _TcpInsertOrderedList (&pxTcp->lConestabList,
                                 pxConn,
                                 TCP_TIMER_CONESTAB);
#endif /* __TCP_OPT_ON__*/

          /*send the first SYN segment*/
         /* TCP_DBGP(NORMAL,"TcpInstanceULInterfaceIoctl:msg = NETINTERFACEIOCTL_OPEN,pxConn=If=0x%x\n",
          (int)hULInterface); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
          {
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"TcpInstanceULInterfaceIoctl:msg = NETINTERFACEIOCTL_OPEN,pxConn=If=0x",(sbyte4)hULInterface);
               DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
          }
#ifndef __TCP_OPT_ON__
     /* Move the connection from the dllConn to rbtree here */
          pxConnTmp = (TCPCONN *) rbsearch (pxConn, pxTcp->connTree) ;
          if ((!pxConnTmp) || (pxConnTmp != pxConn))
          {
            /* TCP_DBGP(ERROR,"TcpInstanceUlInterfaceIoctlMsg:msg NETINTERFACEIOCTL_OPEN pxConn=If= 0x%p: Error While Inserting in Tree to ip=%lx, port=%d\n",
                   pxConn,
                   pxConn->xId.xNetId.dwDstIpAddr,
                   pxConn->xId.wDstPort);*/
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
            {
               DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"TcpInstanceUlInterfaceIoctlMsg:msg NETINTERFACEIOCTL_OPEN pxConn=If= 0x",(sbyte4)pxConn);
               DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,": Error While Inserting in Tree to ip=",(sbyte4)(pxConn->xId.xNetId.dwDstIpAddr));
               DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," port=",(int)hULInterface);
               DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
            }
            _TcpConnClose(pxTcp, pxConn);
            break;
          }

          DLLIST_head(&pxTcp->dllConns);
          if ((pxConnTmp = DLLIST_find(&pxTcp->dllConns,(void *)pxConn,
                       _TcpFindItemByAddress))
              != NULL) {
            TCPCONN_CHECK(pxConn);
            DLLIST_remove(&pxTcp->dllConns);
          }
          else
          {
           /* TCP_DBGP(ERROR,"TcpInstanceUlInterfaceIoctlMsg:msg NETINTERFACEIOCTL_OPEN pxConn=If= 0x%p: Error While Removing from DlList\n",
                   pxConn);*/
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
            {
               DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"TcpInstanceUlInterfaceIoctlMsg:msg NETINTERFACEIOCTL_OPEN pxConn=If= 0x",(sbyte4)pxConn);
               DEBUG_PRINTNL(DEBUG_MOC_IPV4,": Error While Removing from DlList");
            }
            _TcpConnClose(pxTcp, pxConn);
            break;
          }
#endif
          _TcpConnSendSegment(pxTcp,pxConn,
                              pxConnect->dwSendUnacked,(DWORD)0,
                              TCPCONN_FLAGMASK_SYN, TCP_NODATA);

          SNMP( xTcpipData.tcpActiveOpens++ );
          pxConn->eState=TCPCONN_STATE_SYNSENT;
        }
        else {
          /* Must be in listening mode */
          ASSERT((pxConn->oFlag & TCPCONN_FLAGMASK_MODE) ==
                 TCPCONN_FLAGVALUE_MODELISTEN);

          pxConn->eState=TCPCONN_STATE_LISTEN;
        }
        break;

      case TCPULINTERFACEIOCTL_ABORT:
        if (((WORD)hData) == 0) {
          bDropNow = 1;
        }
        /* drop through */
      case NETINTERFACEIOCTL_CLOSE:

        if ((pxConn->oFlag & TCPCONN_FLAGMASK_MODE) ==
            TCPCONN_FLAGVALUE_MODECONNECT)        {
          pxConnect=pxConn->u.pxConnect;

          if (pxConnect != NULL) {
            pxConnect->bCloseCalled = 1;
            /* tcp_close ist meant here stay in LISTEN state*/
            pxConnect->dwLastUsed=pxTcp->dwTicks;
          }
        }
        switch(pxConn->eState) {
        case TCPCONN_STATE_CLOSED:
        case TCPCONN_STATE_LISTEN:
            /* just report callback to socket */
          _TcpConnClose(pxTcp, pxConn);
          break;
        case TCPCONN_STATE_FIN_WAIT_1:
        case TCPCONN_STATE_FIN_WAIT_2:
        case TCPCONN_STATE_CLOSING:
        case TCPCONN_STATE_LAST_ACK:
        case TCPCONN_STATE_TIME_WAIT:
        /*case TCPCONN_STATE_SYNSENT:
        * - RS: app may have sent some data in connect callback.
        *       Flush it first */
        /*case TCPCONN_STATE_SYNRCVD: ANVL 1.19 */
          /* TCP_DBGP(REPETITIVE,"tcp_close: calling _TcpDrop\n"); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,"tcp_close: calling _TcpDrop");
          ASSERT(pxConnect != NULL);
          _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
          _TcpConnClose(pxTcp, pxConn);
          break;
        case TCPCONN_STATE_SYNRCVD: /* ANVL 1.19 */
          _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext,
                              TCPCONN_FLAGMASK_ACK|TCPCONN_FLAGMASK_FIN,TCP_NODATA);
          pxConn->eState = TCPCONN_STATE_FIN_WAIT_1; /* send FIN & move into FIN_WAIT_1 state */
          break;
        case TCPCONN_STATE_SYNSENT:
        /* - RS: app may have sent some data in connect callback.
        *       Flush it first */
        case TCPCONN_STATE_CLOSE_WAIT:
        case TCPCONN_STATE_ESTABLISHED:
          if (bDropNow) {
            /* drop right now */
            ASSERT(pxConnect != NULL);
            _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
            _TcpConnClose(pxTcp, pxConn);
          }
          else {
            if (oIoctl == NETINTERFACEIOCTL_CLOSE) {
              /*clear_DLLIST(&pxConnect->dllReTxBuff, _TcpClearRetransmissionBuffer); */
            }
            else {
#ifndef __TCP_OPT_ON__
              if ( pxConnect->wLingerTimer )
                LIST_REMOVE (pxConn, linger_link);
#endif /* __TCP_OPT_ON__*/
              /* ABORT - start linger timer */
              pxConnect->wLingerTimer = ((WORD)hData)/100;
#ifndef __TCP_OPT_ON__
             /* Convert it to Actual  Ticks */
              pxConnect->wLingerTimer = pxConnect->wLingerTimer * 500 +  pxTcp->dwTicks;
              _TcpInsertOrderedList (&pxTcp->lLingerList,
                                     pxConn,
                                     TCP_TIMER_LINGER);
#endif /* __TCP_OPT_ON__*/
            }
            _TcpCloseQueued(pxTcp, pxConn);
          }
        }

        break;

      case TCPULINTERFACEIOCTL_SETPUSH: /* All PDU will have the PUSH flag set
                                           according to the data BOOL
                                           (TRUE==PUSH), from then on */
        if ((BOOL)hData == TRUE) {
          pxConn->oFlag |= TCPCONN_FLAGMASK_PSH;
        }
        else {
          pxConn->oFlag &= ~TCPCONN_FLAGMASK_PSH;
        }
        break;

      case TCPULINTERFACEIOCTL_SETURG:  /* All PDU will have the URG flag set
                                           according to the data BOOL
                                           (TRUE==URG) */
        if ((BOOL)hData == TRUE) {
          pxConn->oFlag |= TCPCONN_FLAGMASK_URG;
        }
        else {
          pxConn->oFlag &= ~TCPCONN_FLAGMASK_URG;
        }
        break;

      case TCPULINTERFACEIOCTL_SHUTTX:
        _TcpCloseQueued(pxTcp, pxConn);
        break;

      case TCPULINTERFACEIOCTL_GETRXDATALENGTH:
        pxConnect = pxConn->u.pxConnect;
        ASSERT(pxConnect != NULL &&((WORD *)hData) != NULL);
        *((WORD *)hData) = _TcpReassembleCount(pxConnect);
        break;

      case TCPULINTERFACEIOCTL_GETRXDATA:
        pxPacket = (NETPACKET *)hData;
        ASSERT(pxPacket != NULL && pxPacket->pxPayload != NULL &&
               pxPacket->pxPayload->poPayload != NULL);
        lReturn = _TcpReassembleInBuffer(pxConn,
              pxPacket->pxPayload->poPayload, &pxPacket->pxPayload->wSize,
              NULL, NULL);
        break;

      case TCPULINTERFACEIOCTL_GETRXDATA_PAYLOAD:
        pxPacket = (NETPACKET *)hData;
        ASSERT(pxPacket != NULL && pxPacket->pxPayload != NULL &&
               pxPacket->pxPayload->poPayload != NULL);
        pxPayload = pxPacket->pxPayload; /* original */
        lReturn = _TcpReassembleInBuffer(pxConn, NULL,
              &pxPayload->wSize, (OCTET **)pxPayload->poPayload,
          &pxPacket->pxPayload);
#ifndef __TCP_USE_SEGMENTS__
        pxPacket->pxPayload->wSize = pxPayload->wSize;
#endif
        break;

      case TCPULINTERFACEIOCTL_GETTXAVAILSPACE:
        pxConnect = pxConn->u.pxConnect;
        ASSERT(pxConnect != NULL &&((DWORD *)hData) != NULL);
        /* JJ TODO  If the Send Window Size > TCP_TX_MAXSPACE , we shoudl be able to make use of it  rather than being limited by MAXSPACE. We shoudl compare against that too*/
        if (pxConnect->wTxUsedSpace < (TCP_TX_MAXSPACE + pxConnect->dwSendWindow))
        {
                *((DWORD *)hData) = pxConnect->dwSendWindow + TCP_TX_MAXSPACE - pxConnect->wTxUsedSpace;
        }
        else {
          *((DWORD *)hData) = 0;
          pxConnect->bTxNoSpace = 1;
        }
        break;

      case TCPULINTERFACEIOCTL_SETLRBLYU:/* Set least reasm size. Data is
                                              WORD */
        pxConn->wLrblyu = (WORD) hData;
        break;

      case TCPULINTERFACEIOCTL_SETRBLYTO:/* Set the reasm timeout. Data is
                                              WORD */
        pxConn->wReasmTimer = ((WORD) hData)/500; /* uses slow timeout */
        break;

      case NETTRANSPORTULINTERFACEIOCTL_QUERYSTATS:
    {
        mn_tcp_sock_stats_t *stats = (mn_tcp_sock_stats_t *)hData;
            pxConnect = pxConn->u.pxConnect;
            ASSERT(pxConnect != NULL && ((WORD *)hData) != NULL);

            stats->txAvailableSpace = pxConnect->dwSendWindow + TCP_TX_MAXSPACE - pxConnect->wTxUsedSpace;
            stats->txUsedSpace      = pxConnect->wTxUsedSpace;
        stats->txRetransSegs    = pxConn->wTxRetransSegs;
        stats->txMemCopies      = pxConn->wTxMemCopies;

            stats->rxAvailableSpace = TCP_RX_MAXSPACE - pxConnect->wRxUsedSpace;
            stats->rxUsedSpace      = pxConnect->wRxUsedSpace;
        stats->rxChecksumErrs   = pxConn->wRxChecksumErrs;
        stats->rxBadLenErrs        = pxConn->wRxBadLenErrs;
        stats->rxMemCopies      = pxConn->wRxMemCopies;

        stats->MSS                = pxConn->wLocalMss;
        stats->RMSS                = pxConn->wMss;
        stats->SRTT                = pxConnect->dwSrtt;
            stats->rxWindow         = pxConnect->dwRcvWindow;
            stats->txWindow         = pxConnect->dwSendWindow;
       }
       break;

      default:
        ASSERT(0);
        lReturn = NETERR_UNKNOWN;
      }
    }
  }
  else {
    ASSERT(0);
    lReturn = NETERR_BADHANDLE;
  }

  return lReturn;
}

/*
 * TcpInstanceWrite
 *  Tcp Instance Write function. Follows PFN_NETWORKWRITE
 *  typedef.
 *
 *  Args:
 *   hTcp                        Tcp Instance handle
 *   hIf                         UL interface handle (socket). The interface
 *                               must be of the CONNECT type, and fully defined
 *                               (Local IP, Destination IP and Port set)
 *   pxPacket                    Packet pointer
 *   pxAccess                    NETPACKETACCESS pointer
 *   hData                       Useless
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG TcpInstanceWrite(H_NETINSTANCE hTcp,
                      H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,
                      NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  TCPSTATE *pxTcp = (TCPSTATE *)hTcp;
  TCPCONN *pxConn = (TCPCONN *)hIf;
  TCPCONN_CONNECT *pxConnect;
  NETPACKET xPacket;
  NETPAYLOAD *pxPayload;

  TCP_CHECK_STATE(pxTcp);
  TCPCONN_CHECK(pxConn);
  ASSERT(pxConn->eState > TCPCONN_STATE_CLOSED);
  pxConnect = pxConn->u.pxConnect;
  ASSERT(pxConnect != NULL && pxAccess != NULL);
  NETPACKET_CHECK(pxPacket);

#if 0 /* RS: zero copy */
  /* can't keep the payload around so allocate a new one */
  pxPayload = _TcpGetPayload(pxTcp,pxPacket->pxPayload->wSize);
  if (pxPayload == NULL) {
    TCP_DBGP(ERROR, "TcpInstanceWrite:_TcpGetPayload() failed\n");
    return -1;
  }

  MOC_MEMCPY((ubyte *)pxPayload->poPayload,
          (ubyte *)pxPacket->pxPayload->poPayload,
          pxPayload->wSize);
  NETPAYLOAD_DELUSER(pxPacket->pxPayload);
  xPacket = *pxPacket;
  xPacket.pxPayload = pxPayload;

  return _TcpSend(pxTcp, pxConn, &xPacket, pxAccess, 0);
#endif
  return _TcpSend(pxTcp, pxConn, pxPacket, pxAccess, 0);
}

/*
 * TcpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hTcp                       TCP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE TcpInstanceLLInterfaceCreate(H_NETINSTANCE hTcp)
{
  /* The interface does not exist as a separate entity. It is included
     in the TCPSTATE structure */
  return (H_NETINTERFACE)TCPLLINTERFACEHANDLE;
}

/*
 * TcpInstanceLLInterfaceDestroy
 *  Destroy a TCP LL interface
 *
 *  Args:
 *   hTcp                       TCP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG TcpInstanceLLInterfaceDestroy(H_NETINSTANCE hTcp,
                                   H_NETINTERFACE hInterface)
{
  ASSERT(hInterface == TCPLLINTERFACEHANDLE);

  return 0;
}

/*
 * TcpInstanceLLInterfaceIoctl
 *  TCP LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions for precisions
 *
 *  Args:
 *   hTcp                         Tcp instance handle
 *   hLLInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG TcpInstanceLLInterfaceIoctl(H_NETINSTANCE hTcp,
                                 H_NETINTERFACE hLLInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  TCPSTATE *pxTcp = (TCPSTATE *)hTcp;
  LONG lReturn = NETERR_NOERR;

  ASSERT(hLLInterface == (H_NETINTERFACE) TCPLLINTERFACEHANDLE);

  switch (oIoctl) {
  case NETINTERFACEIOCTL_SETIF: /* Set the ID of TCP as understood by the
                                       lower protocol. */
    pxTcp->hTcpLLIf = (H_NETINTERFACE)hData;
    break;

  case NETINTERFACEIOCTL_SETHINST:

    pxTcp->hLL = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:/* Set the write function. Data is
                                         PFN_NETWORKWRITE; this function
                                         will be given the IP address of the
                                         remote end as the hDst */
    pxTcp->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_OPEN:  /* Open the interface */
    ASSERT(pxTcp->pfnLLWrite != NULL);
    break;

  case NETINTERFACEIOCTL_CLOSE: /* Close the interface */
    break;

  default:
    lReturn = NETERR_UNKNOWN;
  }

  return lReturn;
}


/*
 * TcpInstanceRcv
 *  Tcp Instance Rcv function
 *   Tcp Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hTcp                        Tcp Instance Handle
 *    hIf                         Interface Handle
 *    pxPacket                    packet
 *    pxAccess                    NETPACKETACCESS pointer
 *    hData                       must be a pointer to a 64 bits
 *                                field, big-endian, containing in
 *                                the 1st DWORD the source IP address
 *                                and in the 2nd the destination IP address
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG TcpInstanceRcv(H_NETINSTANCE hTcp,
                    H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,
                    NETPACKETACCESS *pxAccess,
                    H_NETDATA hData)
{
  TCPSTATE *pxTcp = (TCPSTATE *)hTcp;
  TRANSPORT2NETWORKID *pxIpSD = (TRANSPORT2NETWORKID *)hData;
  TCPCONN *pxConn = NULL;
  TCPCONN *pxConnTmp = NULL;
  TCPCONN xConnTmp;
  TCPCONN_CONNECT *pxConnect;
  TCPCONN_LISTEN *pxListen;
  TCPHDR *pxTcpHeader;
  TCPHDR xTcpHeader;
  TCPPSH *pxTcpPseudoHeader;
  NETPAYLOAD *pxPayload;
  NETPACKET xNewPacket;
  NETPAYLOAD *pxNewPayload;
  OCTET *poPayload;
  OCTET *poTcpData;
  OCTET *poTcpOptions;
  WORD wLength;
  WORD wDatalen;
  BOOL bPacketAccept;
  LONG lRc = 0;

  TCP_CHECK_STATE(pxTcp);
  ASSERT((DWORD) hIf == TCPLLINTERFACEHANDLE);
  NETPACKET_CHECK(pxPacket);
  ASSERT(pxAccess != NULL && pxIpSD != NULL);

  pxPayload = pxPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  ASSERT(pxAccess->wOffset >= sizeof(TCPPSH) && (pxAccess->wOffset % sizeof(int)) == 0);

  wLength = pxAccess->wLength;

  pxTcpHeader = (TCPHDR*)(poPayload + pxAccess->wOffset);
  pxTcpPseudoHeader =(TCPPSH*)((OCTET*)pxTcpHeader - sizeof(TCPPSH));
  pxTcpPseudoHeader->dwSrcIP = htonl(pxIpSD->dwSrcIpAddr);
  pxTcpPseudoHeader->dwDstIP = htonl(pxIpSD->dwDstIpAddr);
  pxTcpPseudoHeader->oNull = 0;
  pxTcpPseudoHeader->oProt = IPPROTO_TCP;
  pxTcpPseudoHeader->wLen = htons(wLength);
  xTcpHeader.wSrcPort = ntohs(pxTcpHeader->wSrcPort);
  xTcpHeader.wDstPort = ntohs(pxTcpHeader->wDstPort);
  xTcpHeader.dwSequencenumber = ntohl(pxTcpHeader->dwSequencenumber);
  xTcpHeader.dwAcknowledgenumber = ntohl(pxTcpHeader->dwAcknowledgenumber);
  xTcpHeader.oTcpHdrLen = pxTcpHeader->oTcpHdrLen>>4;
  xTcpHeader.oFlags = pxTcpHeader->oFlags;
  xTcpHeader.wWindowsize = ntohs(pxTcpHeader->wWindowsize);
  xTcpHeader.wUrgent = ntohs(pxTcpHeader->wUrgent);

 /* TCP_DBGP(REPETITIVE,
           "TcpInstanceRcv: from %ld.%ld.%ld.%ld/%d to %ld.%ld.%ld.%ld/%d, tcp len=%d, Seq=%lu, Ack=%lu, Flags=0x%x\n",
           IPADDRDISPLAY(pxIpSD->dwSrcIpAddr),
           xTcpHeader.wSrcPort,
           IPADDRDISPLAY(pxIpSD->dwDstIpAddr),
           xTcpHeader.wDstPort,
           wLength,
           xTcpHeader.dwSequencenumber,
           xTcpHeader.dwAcknowledgenumber,
           xTcpHeader.oFlags
           ); */

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
  {
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4,"TcpInstanceRcv: from ",pxIpSD->dwSrcIpAddr);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"/",xTcpHeader.wSrcPort);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4," to ",pxIpSD->dwDstIpAddr);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"/",xTcpHeader.wDstPort);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,", tcp len=",wLength);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,", Seq=",xTcpHeader.dwSequencenumber);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,", Ack=",xTcpHeader.dwAcknowledgenumber);
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,", Flags=0x",(sbyte4)xTcpHeader.oFlags);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
  }

  if ( (pxIpSD->dwSrcIpAddr == 0 ) ||
       (pxIpSD->dwSrcIpAddr == 0xffffffff ) ||
       (pxIpSD->dwSrcIpAddr == pxIpSD->dwDstIpAddr) ) /* ANVL 23.1 */
  {
    /* TCP_DBGP(ERROR, "TcpInstanceRcv: source invalid\n");*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,"TcpInstanceRcv: source invalid");
    NETPAYLOAD_DELUSER(pxPayload);
    return -1;
  }

  /*point to the real TCP data*/
  poTcpData = (OCTET*)pxTcpHeader + (xTcpHeader.oTcpHdrLen*4);
  wDatalen = pxAccess->wLength - (xTcpHeader.oTcpHdrLen*4);
  poTcpOptions = (OCTET*)pxTcpHeader + sizeof(xTcpHeader);


#ifndef __TCP_OPT_ON__
  xConnTmp.xId.xNetId.dwSrcIpAddr = pxIpSD->dwDstIpAddr;
  xConnTmp.xId.xNetId.dwDstIpAddr = pxIpSD->dwSrcIpAddr;
  xConnTmp.xId.wSrcPort = xTcpHeader.wDstPort;
  xConnTmp.xId.wDstPort = xTcpHeader.wSrcPort;
  xConnTmp.xId.xNetId.oIfIdx = pxIpSD->oIfIdx;
  xConnTmp.xId.xNetId.wVlan =  pxIpSD->wVlan;

  pxConn = (TCPCONN *) rbfind (&xConnTmp, pxTcp->connTree);
#endif

#ifndef __TCP_OPT_ON__
   /* The dllconn Will only Have Listening Sockets */
  if (NULL == pxConn)
#endif
    pxConn = _TcpCheckRxConn(pxTcp, pxIpSD, &xTcpHeader);
  /* Verify checksum */
#if 1
  if ( ((Checksum16((OCTET*)pxTcpPseudoHeader, wLength + sizeof(TCPPSH)))
        != 0) )
#else
  if ( pxConn && pxConn->eState == TCPCONN_STATE_ESTABLISHED ) /* just4fun ;)*/
#endif
  {
    /* TCP_DBGP(ERROR, "TcpInstanceRcv:Bad checksum\n"); */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,"TcpInstanceRcv: Bad checksum");

    NETPAYLOAD_DELUSER(pxPayload);
    if (pxConn)pxConn->wRxChecksumErrs++;
    _TcpCheckRxErrs(pxConn);
    return -1;
  }

  if ( (pxAccess->wLength < xTcpHeader.oTcpHdrLen*4)){

    /* TCP_DBGP(ERROR, "TcpInstanceRcv:Bad length\n"); */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,"TcpInstanceRcv: Bad length");
    NETPAYLOAD_DELUSER(pxPayload);
    if (pxConn)pxConn->wRxBadLenErrs++;
    _TcpCheckRxErrs(pxConn);
    return -1;
  }

  if (pxConn == NULL) {
    /* no connection */
    SNMP( xTcpipData.tcpInErrs++ );
   /* TCP_DBGP(ERROR,"TcpInstanceRcv: No existing TCB LISTENing or ESTABLISHED, ignore\n");*/
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,"TcpInstanceRcv: No existing TCB LISTENing or ESTABLISHED, ignore");

    /* Dont send a RST if you get a RST
       Dont send if contains ACK only */
#if 0
    if (!(xTcpHeader.oFlags & TCPCONN_FLAGMASK_RST) &&
        ((xTcpHeader.oFlags != TCPCONN_FLAGMASK_ACK) ||
         (wDatalen))) {/* If  its not a pure ack  JJ ANVL 4.1 s3.9 p65 rfc 793 */
      _TcpSendRST(pxTcp, pxIpSD, &xTcpHeader, wDatalen);
    }
#endif

    /* If  its not a pure ack  JJ ANVL 1.5 , 4.1 s3.9 p65 rfc 793 */
    if (!(xTcpHeader.oFlags & TCPCONN_FLAGMASK_RST))
      _TcpSendRST(pxTcp, pxIpSD, &xTcpHeader, wDatalen);

    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    CHECKPOINT(g_dwTcpInstanceRcv);
    return wLength;
  }

  CHECKPOINT(g_dwTcpInstanceRcv);

  /* look at LISTEN state first */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
  {
       DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"TcpInstanceRcv: TCB Found 0x", pxConn);
       DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," State is  0x", pxConn->eState);
  }
  switch (pxConn->eState) {/* switch level 0*/

  case TCPCONN_STATE_LISTEN:
    pxListen = pxConn->u.pxListen;
    ASSERT(pxListen != NULL);
    pxListen->dwLastUsed=pxTcp->dwTicks;

    if (xTcpHeader.oFlags & TCPCONN_FLAGMASK_RST) {
      /* send callback to socket */
      /*        _TcpConnRst(pxTcp, pxConn); */
     /* TCP_DBGP(ERROR,"TcpInstanceRcv:[%ld] 0x%p: LIS->free: rcvd RST\n",
      pxConn->lConnNo, pxConn);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
      {
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4,": LIS->free: rcvd RST");
      }
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      CHECKPOINT(g_dwTcpInstanceRcv);
      return wLength;
    }

    if (xTcpHeader.oFlags & TCPCONN_FLAGMASK_ACK) {
      /* _TcpConnSendSegment checks outbuf full, if full just returns */
      _TcpSendRST(pxTcp, pxIpSD, &xTcpHeader, wDatalen);
      /*TCP_DBGP(ERROR,"TcpInstanceRcv:[%ld] 0x%p: LIS->free: Rcvd Ack, sending RST 2, NODATA\n",
               pxConn->lConnNo, pxConn); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
      {
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4,": LIS->free: Rcvd Ack, sending RST 2, NODATA");
      }
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      CHECKPOINT(g_dwTcpInstanceRcv);
      return wLength;
    }

    if (xTcpHeader.oFlags & TCPCONN_FLAGMASK_SYN) {

      TCPCONN *pxNewConn;

      CHECKPOINT(g_dwTcpInstanceRcv);
      /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%lx\tsomeone wants to make a connection: \n",
               pxConn->lConnNo, (DWORD)pxConn);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\tsomeone wants to make a connection: ");
      }
      /* Someone wants to make a connection!
       * Create new TCPCONN & TCPCONN_CONNECT, gets inserted at head
       * of queue.  */

      /* send callback to socket.
         SB March 2002. Needs to be called before
         the state is set, as it issues ioctl not allowed
         in a non-CLOSED state */
      ASSERT(pxConn->pfnCbk != NULL);
      if (DLLIST_count(&pxTcp->dllConns) > pxTcp->wMaxConn) {
        TCPCONN *pxOldestConn = NULL;
        TCPCONN *pxCurrentConn;

        DLLIST_head(&pxTcp->dllConns);
        while ((pxCurrentConn = DLLIST_read(&pxTcp->dllConns)) != NULL) {
          if ((pxCurrentConn->eState == TCPCONN_STATE_FIN_WAIT_2 ||
               pxCurrentConn->eState == TCPCONN_STATE_TIME_WAIT) &&
              pxCurrentConn->u.pxConnect->wFinwait2Timer > 0) {
            if (pxOldestConn == NULL ||
                pxOldestConn->u.pxConnect->wFinwait2Timer >
                pxCurrentConn->u.pxConnect->wFinwait2Timer) {
              pxOldestConn = pxCurrentConn;
            }
          }
          DLLIST_next(&pxTcp->dllConns);
        }

        if (pxOldestConn != NULL) {
          /* Deleting the oldest connection in FIN_WAIT_2 state */
          /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%lx\tDeleting oldest connection in FIN_WAIT state\n",
                   pxOldestConn->lConnNo, (DWORD)pxOldestConn); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
          {
              DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxOldestConn);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\tDeleting oldest connection in FIN_WAIT state");
          }
          /* send callback to socket */
          _TcpConnTimeout(pxTcp, pxOldestConn);
        } else {
          lRc = TCPERR_FORKEDFAILED;
        }
      }

      if (lRc != TCPERR_FORKEDFAILED) {
#ifdef __TCP_USE_MEMPOOL__
        lRc = MEM_POOL_getPoolObject(&pxTcp->connPool, (void **)&(pxNewConn));
        if (OK > lRc)
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
              DEBUG_ERROR(DEBUG_MOC_IPV4,"Unable to Get Memory for New Connection",lRc);
#else
        pxNewConn = (TCPCONN *)MALLOC(sizeof(TCPCONN));
#endif
        ASSERT(pxNewConn != NULL);
        MOC_MEMSET((ubyte *)pxNewConn, 0, sizeof(TCPCONN));
        DEBUG(pxNewConn->dwMagicCookie = TCPCONN_MAGIC_COOKIE);

        pxConnect = (TCPCONN_CONNECT *)MALLOC(sizeof(TCPCONN_CONNECT));
        ASSERT(pxConnect != NULL);
        MOC_MEMSET((ubyte *)pxConnect, 0, sizeof(TCPCONN_CONNECT));
        pxNewConn->u.pxConnect = pxConnect;

        pxNewConn->hTcp = hTcp; /* Set the TCPSTATE */

        /* copy characteristics of original listen socket and incoming
           packet */
        MOC_MEMCPY((ubyte *)&(pxNewConn->xId.xNetId),
                (ubyte *)pxIpSD,sizeof(TRANSPORT2NETWORKID));
        pxNewConn->xId.xNetId.dwSrcIpAddr = pxIpSD->dwDstIpAddr;
        pxNewConn->xId.xNetId.dwDstIpAddr = pxIpSD->dwSrcIpAddr;
        pxNewConn->xId.wSrcPort = pxConn->xId.wSrcPort;
        pxNewConn->xId.wDstPort = xTcpHeader.wSrcPort;
          /* Set The TCP STATE */
        pxNewConn->u.pxConnect->hTcp = (H_NETINSTANCE)pxTcp;
          /* Set The TCP CONN */
        pxNewConn->u.pxConnect->hConn = (H_NETINSTANCE)pxNewConn;
        pxNewConn->dwAppWinFactor = 100;


#ifdef IPSEC
        pxNewConn->xId.xNetId.dwSecurityPolicy = (DWORD)
          IPSecGetSP(pxNewConn->xId.xNetId.dwDstIpAddr,
                     pxNewConn->xId.wDstPort,
                     pxNewConn->xId.xNetId.dwSrcIpAddr,
                     pxNewConn->xId.wSrcPort,
                     IPPROTO_TCP, 1);
        pxNewConn->xId.xNetId.wIpSecHdrLength =
          IPSecGetHdrLen((void *)pxNewConn->xId.xNetId.dwSecurityPolicy);
        pxNewConn->xId.xNetId.wIpSecTrailLength =
          IPSecGetTrailLen((void *)pxNewConn->xId.xNetId.dwSecurityPolicy,
                           TCPDEFAULT_HDRSIZE);

#endif

        /* set the Dst addr type and gateway once and for all */
        {
          ROUTEENTRY xRoute;

          xRoute.oIfIdx = pxIpSD->oIfIdx;
          xRoute.wVlan = pxIpSD->wVlan;
#ifdef _RADIX_ROUTING_ON_
          xRoute.xRouteNodes->RadixNodeKey  = pxIpSD->dwSrcIpAddr;
          xRoute.xRouteNodes->RadixNodeMask = 0;
#else
          xRoute.dwDstAddr = pxIpSD->dwSrcIpAddr;
#endif
          xRoute.eDstAddrType = IPADDRT_UNKNOWN;

          /* No return value check: we assume it will always work
             here */
          RoutingTableMsg(ROUTINGTABLEMSG_FINDROUTE,(H_NETDATA)&xRoute);
          pxNewConn->xId.xNetId.eDstAddrType = xRoute.eDstAddrType;
          pxNewConn->xId.xNetId.dwGatewayAddr = xRoute.dwGateway;
        }

        /* use the ticker for the connection number*/
        pxNewConn->lConnNo = (LONG) (pxTcp->dwTicks/2);

        pxNewConn->wMss = pxConn->wMss;
        pxNewConn->wLocalMss = pxConn->wLocalMss;
        pxNewConn->wWin = pxConn->wWin;

        pxConnect->dwLastUsed = pxListen->dwLastUsed;

        _TcpSaveHeader(pxConnect, &xTcpHeader, wDatalen);

        /* Prepare to send ack */
        /*Security check skipped !!*/

        _TcpInitConnect(pxTcp, pxConn, pxConnect);

        pxConnect->dwRcvNext = pxConnect->dwSegSequenceNumber+1;
        pxConnect->dwRcvIrs = pxConnect->dwSegSequenceNumber;

        pxNewConn->eState = TCPCONN_STATE_SYNRCVD;

        if (lRc >= 0) {
          /* fork has succeeded - send ACK,FIN */
#ifndef __TCP_OPT_ON__
          /* We should Move this connection to the rbtree now. Its in an
             established state */
          pxConnTmp = (TCPCONN *) rbsearch (pxNewConn, pxTcp->connTree);
          if ((!pxConnTmp) || (pxConnTmp != pxNewConn))
          {
            /* TCP_DBGP(ERROR,"TcpInstanceRcv:[%ld] 0x%p: LIS->SYN_RCVD: Error While Inserting in Tree to ip=%lx, port=%d\n",
                   pxNewConn->lConnNo, pxNewConn,
                   pxNewConn->xId.xNetId.dwDstIpAddr,
                   pxNewConn->xId.wDstPort);*/
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
            {
                DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxNewConn->lConnNo);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxNewConn);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,": LIS->SYN_RCVD: Error While Inserting in Tree to ip=",(sbyte4)pxNewConn->xId.xNetId.dwDstIpAddr);
                DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,", port=",pxNewConn->xId.wDstPort);
                DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
            }
            _TcpDrop(pxTcp, pxNewConn, pxConnect->dwSendIss, pxConnect->dwRcvNext);
            _TcpConnFree((void *)pxNewConn);
            lRc =  -1;
            goto result;
          }
         /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: LIS->SYN_RCVD: Inserted in Tree to ip=%lx, port=%d\n",
                   pxNewConn->lConnNo, pxNewConn,
                   pxNewConn->xId.xNetId.dwDstIpAddr,
                   pxNewConn->xId.wDstPort);*/
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxNewConn->lConnNo);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxNewConn);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,": LIS->SYN_RCVD: Inserted in Tree to ip=",(sbyte4)pxNewConn->xId.xNetId.dwDstIpAddr);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,", port=",pxNewConn->xId.wDstPort);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
          }
#else
          DLLIST_prepend(&pxTcp->dllConns, pxNewConn);
#endif
          SNMP( xTcpipData.tcpPassiveOpens++ );

          if ((4*xTcpHeader.oTcpHdrLen) > sizeof(xTcpHeader)) {
            /* we have options */
            if (0 == _TcpProcessOptions(poTcpOptions,
                                        4*xTcpHeader.oTcpHdrLen - sizeof(xTcpHeader),
                                        pxNewConn))
            {
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"options not properly obtained, options =  0x", *poTcpOptions);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4, " dropping connection.");
              _TcpDrop(pxTcp, pxNewConn, pxConnect->dwSendIss, pxConnect->dwRcvNext);
              pxConn = pxNewConn;
              lRc = -1; /* call the interface destroy using the pxNewConn. */
              goto result;
            }
          }
#ifndef __TCP_OPT_ON__
         lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                                 (H_NETINTERFACE)pxConn->hIf,
                                 (LONG)pxConn->lFd,
                                 TCPULINTERFACECBK_FORKED,(H_NETDATA)pxNewConn);
#else
         lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                                 (H_NETINTERFACE)pxConn->hIf,
                                 TCPULINTERFACECBK_FORKED,(H_NETDATA)pxNewConn);
#endif
          if(lRc < 0)
          {
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
            {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxNewConn->lConnNo);
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxNewConn);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": unable to create corresponding socket layer, error is ", lRc);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
            }
            _TcpDrop(pxTcp, pxNewConn, pxConnect->dwSendIss, pxConnect->dwRcvNext);
            pxConn = pxNewConn;
            lRc = -1; /* call the interface destroy using the pxNewConn. */
            goto result;
          }
          else
          {
            pxConnect->oPassiveOpen |= TCPCONN_FLAGMASK_PASOPEN;
            /* Buf full checked before */
            _TcpConnSendSegment(pxTcp, pxNewConn, pxConnect->dwSendIss,
                              pxConnect->dwRcvNext,
                              TCPCONN_FLAGMASK_SYN | TCPCONN_FLAGMASK_ACK,
                              TCP_NODATA);
          /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: LIS->SYN_RCVD: sending SYN | ACK 1 to ip=%lx, port=%d\n",
                   pxNewConn->lConnNo, pxNewConn,
                   pxNewConn->xId.xNetId.dwDstIpAddr,
                   pxNewConn->xId.wDstPort);*/
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
            {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxNewConn->lConnNo);
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxNewConn);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,":LIS->SYN_RCVD: sending SYN | ACK 1 to ip=",(sbyte4)pxNewConn->xId.xNetId.dwDstIpAddr);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,", port=",pxNewConn->xId.wDstPort);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
            }
          }
        } else {
          /* fork has failed - send RST */
          _TcpDrop(pxTcp, pxNewConn, pxConnect->dwSendIss, pxConnect->dwRcvNext);
          _TcpConnFree((void *)pxNewConn);
        }
      } /* end fork OK */

#ifndef __TCP_OPT_ON__
result:
#endif

      if (lRc < 0 && lRc != TCPERR_FORKEDFAILED) {
        /* delete parent too */
        lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                            (H_NETINTERFACE) pxConn);
      }
    } /* end SYN */

    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    CHECKPOINT(g_dwTcpInstanceRcv);
    return wLength;


  case TCPCONN_STATE_SYNSENT:
    pxConnect = pxConn->u.pxConnect;
    ASSERT(pxConnect != NULL);
#ifndef __TCP_OPT_ON__
    pxConnect->wIdleTimer = pxTcp->dwTicks;
#else
    pxConnect->wIdleTimer = 0;
#endif
    /* save incoming Header */
    _TcpSaveHeader(pxConnect, &xTcpHeader, wDatalen);

    CHECKPOINT(g_dwTcpInstanceRcv);

      /* s3.9 Pg 66 RFC 793
       If the ACK bit is set

          If SEG.ACK =< ISS, or SEG.ACK > SND.NXT, send a reset (unless
          the RST bit is set, if so drop the segment and return)

            <SEQ=SEG.ACK><CTL=RST>

          and discard the segment.  Return.

          If SND.UNA =< SEG.ACK =< SND.NXT then the ACK is acceptable.
      */
    if(pxConnect->oSegControl & TCPCONN_FLAGMASK_ACK) {
      /*Is the acknowledge number outside of iss and dwSendNext ?*/
#ifdef SEQNUM_ROLLOVER
      if(_TcpBefore(pxConnect->dwSegAckNumber, pxConnect->dwSendIss+1) ||
     _TcpAfter(pxConnect->dwSegAckNumber, pxConnect->dwSendNext))
#else
      /* AR: do byte order conversion before checking the numbers */
      if((pxConnect->dwSegAckNumber <= pxConnect->dwSendIss) ||
     (pxConnect->dwSegAckNumber > pxConnect->dwSendNext))
#endif
      {
        if(pxConnect->oSegControl & TCPCONN_FLAGMASK_RST) {
/*                        SNMP( xTcpipData.tcpAttemptFails++ ); */
          /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: SYN_SENT->free: rcvd RST & ACK\n",
                pxConn->lConnNo, pxConn); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,": SYN_SENT->free: rcvd RST & Unacceptable ACK");
          }
        }
        else {
          /* _TcpConnSendSegment checks outbuf full, if full just returns */
          _TcpDrop(pxTcp, pxConn, pxConnect->dwSegAckNumber, 0);
          /* send callback to socket */
          _TcpConnRst(pxTcp, pxConn); /*RFC 793 s3.9 p66 ANVL 8.17 JJ  */
          TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: SYN_SENT->free: rcvd UnAcceptable ACK : sending RST \n",
                   pxConn->lConnNo, pxConn);
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,": SYN_SENT->free: rcvd Unacceptable Ack : sending RST 3");
          }
        }
        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        CHECKPOINT(g_dwTcpInstanceRcv);
        return wLength;
      }

      /*Is the acknowledge number outside snd_una and dwSendNext ?*/
#ifdef SEQNUM_ROLLOVER
      if( !(_TcpBefore(pxConnect->dwSendUnacked, pxConnect->dwSegAckNumber+1) &&
            _TcpBefore(pxConnect->dwSegAckNumber, pxConnect->dwSendNext+1)
           )
        )
#else
      if( !(pxConnect->dwSendUnacked <= pxConnect->dwSegAckNumber) &&
          (pxConnect->dwSegAckNumber <= pxConnect->dwSendNext))
#endif
      {
        /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: SYN_SENT->free: Ack no. outside range\n",
              pxConn->lConnNo, pxConn);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,": SYN_SENT->free: Ack no. outside range");
        }
        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        CHECKPOINT(g_dwTcpInstanceRcv);
        return wLength;
      }
    }
    /*If we come to here; the ACK is acceptable or not present*/
    /* s 3.9 Page 67 RFC 793 RST Bit processing
    If the RST bit is set

          If the ACK was acceptable then signal the user "error:
          connection reset", drop the segment, enter CLOSED state,
          delete TCB, and return.  Otherwise (no ACK) drop the segment
          and return.
    */

    if (pxConnect->oSegControl & TCPCONN_FLAGMASK_RST) {
      /* TCP_DBGP(ERROR,"TcpInstanceRcv: rcvd RST in SYN_SENT state\n");*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
          DEBUG_PRINTNL(DEBUG_MOC_IPV4,"TcpInstanceRcv: rcvd RST in SYN_SENT state");

      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      CHECKPOINT(g_dwTcpInstanceRcv);
      /* If Its a Pure RST , just drop the Segment Else Disconnect and goto Closed State */
      if (pxConnect->oSegControl != TCPCONN_FLAGMASK_RST) {
          /* TCP_DBGP(ERROR,"TcpInstanceRcv: is RST, connection closed\n");*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
          DEBUG_PRINTNL(DEBUG_MOC_IPV4,"TcpInstanceRcv: is RST, connection closed");
          /* send callback to socket */
          _TcpDrop(pxTcp, pxConn, pxConnect->dwSegAckNumber, 0);
          _TcpConnRst(pxTcp, pxConn);
      }
      CHECKPOINT(g_dwTcpInstanceRcv);
      return wLength;
    }

    /*security check skipped*/
    if(pxConnect->oSegControl & TCPCONN_FLAGMASK_SYN) {
      pxConnect->dwRcvNext=pxConnect->dwSegSequenceNumber+1;
      pxConnect->dwRcvIrs=pxConnect->dwSegSequenceNumber;

      /*Is the SYN coupled with an ACK?*/
      if(pxConnect->oSegControl & TCPCONN_FLAGMASK_ACK) {
        pxConnect->dwSendUnacked = pxConnect->dwSegAckNumber;
        _TcpRefreshRetransmissionQueue(pxTcp, pxConn);
      }
#ifdef SEQNUM_ROLLOVER
      if (_TcpAfter(pxConnect->dwSendUnacked, pxConnect->dwSendIss))
#else
      if (pxConnect->dwSendUnacked > pxConnect->dwSendIss)
#endif
      {
#ifndef __TCP_OPT_ON__
        if ( pxConnect->wConestabTimer )
          LIST_REMOVE (pxConn, conestab_link);
#endif /* __TCP_OPT_ON__*/
        /* turn off conestab timer & turn on keepalive (if set) */
        pxConnect->wConestabTimer = pxTcp->wKeepAliveTimer;
#ifndef __TCP_OPT_ON__
       /* Convert it to Actual  Ticks */
        if (pxTcp->wKeepAliveTimer)
        {
            pxConnect->wConestabTimer = pxConnect->wConestabTimer * 500 +  pxTcp->dwTicks;
            _TcpInsertOrderedList (&pxTcp->lConestabList,
                                   pxConn,
                                   TCP_TIMER_CONESTAB);
        }
#endif /* __TCP_OPT_ON__*/
        /* set up receive window */
        pxConnect->dwRcvWindow = pxConn->wWin;

        /* send callback to socket */
        ASSERT(pxConn->pfnCbk != NULL);
        lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                                (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                                TCPULINTERFACECBK_OPENED, (H_NETDATA) 0);

        if (lRc < 0) {
          /* socket has refused open - send RST */
          _TcpDrop(pxTcp, pxConn, pxConnect->dwSendIss, pxConnect->dwRcvNext);
          lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                              (H_NETINTERFACE) pxConn);
          NETPAYLOAD_DELUSER(pxPacket->pxPayload);
          return wLength;
        } /* end refused */


    /* RS: app may have cloed in its callback from socket. Dont' proceed */
        if ( pxConn->eState==TCPCONN_STATE_CLOSED){
          NETPAYLOAD_DELUSER(pxPacket->pxPayload);
          return wLength;
    }
    /* RS: done */

        if ((4*xTcpHeader.oTcpHdrLen) > sizeof(xTcpHeader)) {
          /* we have options */
          /*_TcpProcessOptions(poTcpOptions,
                            4*xTcpHeader.oTcpHdrLen - sizeof(xTcpHeader),
                            pxConn);*/
          if (0 == _TcpProcessOptions(poTcpOptions,
                                      4*xTcpHeader.oTcpHdrLen - sizeof(xTcpHeader),
                                      pxConn))
          {
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"options not properly obtained, options =  0x", *poTcpOptions);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, " dropping connection.");
            _TcpDrop(pxTcp, pxConn, pxConnect->dwSendIss, pxConnect->dwRcvNext);
            lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                                (H_NETINTERFACE) pxConn);
            NETPAYLOAD_DELUSER(pxPacket->pxPayload);
            return wLength;
          }
        }

        /*our SYN has been acknowleged*/
        pxConn->eState=TCPCONN_STATE_ESTABLISHED;
        /* BufFul checked before */
        _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext,
              TCPCONN_FLAGMASK_ACK,TCP_DATAON);
        TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: SYN_SENT->EST: sending ACK 1, DATAON, waking thrds\n",
              pxConn->lConnNo, pxConn);
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,": SYN_SENT->EST: sending ACK 1, DATAON, waking thrds");
        }

        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        CHECKPOINT(g_dwTcpInstanceRcv);
        return wLength;
      }
      else {
        /*If there was no ACK, the SYN will be interpreted an a request so enter SYN_RECEIVED state*/
        pxConn->eState=TCPCONN_STATE_SYNRCVD;
        /* Buf Full checked before */
        _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendIss, pxConnect->dwRcvNext,
              TCPCONN_FLAGMASK_SYN | TCPCONN_FLAGMASK_ACK,TCP_NODATA);
        /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: SYN_SENT->SYN_RCVD: Rcvd SYN: sending SYN | ACK 2\n",
              pxConn->lConnNo, pxConn);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4," SYN_SENT->SYN_RCVD: Rcvd SYN: sending SYN | ACK 2");
        }
        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        CHECKPOINT(g_dwTcpInstanceRcv);
        return wLength;
      }
    }
    /* --> Neither SYN nor RST*/
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    CHECKPOINT(g_dwTcpInstanceRcv);
    return wLength;
    /*-------------------------------------------------------- */

  case TCPCONN_STATE_SYNRCVD:
  case TCPCONN_STATE_ESTABLISHED:
  case TCPCONN_STATE_FIN_WAIT_1:
  case TCPCONN_STATE_FIN_WAIT_2:
  case TCPCONN_STATE_CLOSE_WAIT:
  case TCPCONN_STATE_CLOSING:
  case TCPCONN_STATE_LAST_ACK:
  case TCPCONN_STATE_TIME_WAIT:

    CHECKPOINT(g_dwTcpInstanceRcv);
    pxConnect = pxConn->u.pxConnect;
    ASSERT(pxConnect != NULL);
    pxConnect->dwLastUsed=pxTcp->dwTicks;
#ifndef __TCP_OPT_ON__
    pxConnect->wIdleTimer = pxTcp->dwTicks;
#else
    pxConnect->wIdleTimer = 0;
#endif
    /* save incoming Header */
    _TcpSaveHeader(pxConnect, &xTcpHeader, wDatalen);

    /*first - check sequence number*/
    bPacketAccept=1;
    if (pxConnect->dwSegLength == 0 && pxConnect->dwRcvWindow == 0) {
      if ( !(pxConnect->dwSegSequenceNumber == pxConnect->dwRcvNext)) {
        bPacketAccept=0;
      }
    }
    CHECKPOINT(g_dwTcpInstanceRcv);
    if (pxConnect->dwSegLength > 0 && pxConnect->dwRcvWindow == 0) {
      bPacketAccept=0;
    }
    CHECKPOINT(g_dwTcpInstanceRcv);
    /*accept segemnets containing RST or ACK or URG even when dwRcvWindow ==0*/
    if (pxConnect->dwRcvWindow==0 && (pxConnect->oSegControl &
          (TCPCONN_FLAGMASK_RST | TCPCONN_FLAGMASK_ACK | TCPCONN_FLAGMASK_URG)) ) {
      bPacketAccept=1;
    }
    CHECKPOINT(g_dwTcpInstanceRcv);
    if (pxConnect->dwSegLength == 0 && pxConnect->dwRcvWindow > 0) {
      /*accept segment, when dwSegSequenceNumber lies between dwRcvNext and dwRcvNext+dwRcvWindow*/
#ifdef SEQNUM_ROLLOVER
      if ( ! _TcpBetween(pxConnect->dwSegSequenceNumber, pxConnect->dwRcvNext,
             pxConnect->dwRcvNext+pxConnect->dwRcvWindow - 1) )
#else
      if ( ! ((pxConnect->dwRcvNext <= pxConnect->dwSegSequenceNumber) &&
              (pxConnect->dwSegSequenceNumber < pxConnect->dwRcvNext+pxConnect->dwRcvWindow)) )
#endif
      {
        bPacketAccept=0;
      }
    }
    CHECKPOINT(g_dwTcpInstanceRcv);
    if (pxConnect->dwSegLength > 0 && pxConnect->dwRcvWindow > 0) {
      /*lies anything of the current segment between dwRcvNext and dwRcvNext+dwRcvWindow? - if so accept packet*/
#ifdef SEQNUM_ROLLOVER
      if ( ! (_TcpBetween(pxConnect->dwSegSequenceNumber, pxConnect->dwRcvNext,
             pxConnect->dwRcvNext+pxConnect->dwRcvWindow - 1) ||
              _TcpBetween(
                    pxConnect->dwSegSequenceNumber + pxConnect->dwSegLength - 1,
                    pxConnect->dwRcvNext,
            pxConnect->dwRcvNext+pxConnect->dwRcvWindow - 1)
             )
        )
#else
      if (!(((pxConnect->dwRcvNext <= pxConnect->dwSegSequenceNumber) &&
        (pxConnect->dwSegSequenceNumber < pxConnect->dwRcvNext+pxConnect->dwRcvWindow)) ||
        ((pxConnect->dwRcvNext <= pxConnect->dwSegSequenceNumber+pxConnect->dwSegLength-1)&&
        (pxConnect->dwSegSequenceNumber+pxConnect->dwSegLength-1 <
            pxConnect->dwRcvNext+pxConnect->dwRcvWindow))))
#endif
      {
        bPacketAccept=0;
      }
    }
    CHECKPOINT(g_dwTcpInstanceRcv);

#ifdef TCPSECURE /* draft-ietf-tcpm-tcpsecure-04.txt */

    if (pxConnect->oSegControl & TCPCONN_FLAGMASK_RST) { /* reset bit set */
    /* offset to ending seq # */
    DWORD dwOffset = (pxConnect->dwSegLength > 0 ) ?
                 pxConnect->dwSegLength - 1 : 0;

        if ( ! (_TcpBetween(pxConnect->dwSegSequenceNumber,pxConnect->dwRcvNext,
             pxConnect->dwRcvNext+pxConnect->dwRcvWindow - 1) ||
               _TcpBetween(
                    pxConnect->dwSegSequenceNumber + dwOffset,
                    pxConnect->dwRcvNext,
            pxConnect->dwRcvNext + pxConnect->dwRcvWindow - 1)
               )
           )
        {
       /* 1) seq # outside the rcv window */
           /* TCP_DBGP(REPETITIVE,
            "TcpInstanceRcv:[%ld] 0x%p: SR/E/F1/F2/CW/CL/LA/TW(%d): "
                    "dropping out-of-window RST\n",
                     pxConn->lConnNo, pxConn, pxConn->eState); */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": SR/E/F1/F2/CW/CL/LA/TW(",pxConn->eState);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,"): dropping out-of-window RST");
        }

           NETPAYLOAD_DELUSER(pxPacket->pxPayload);
           CHECKPOINT(g_dwTcpInstanceRcv);
           return wLength;
    }else if ( pxConnect->dwSegSequenceNumber == pxConnect->dwRcvNext ) {
       /* 2) seq # exactly matches the next expected seq # */
           bPacketAccept = 1; /* accept */
    }else{
       /* 3) seq # is not the next expected, but within window. send ACK */
           /* TCP_DBGP(REPETITIVE,
            "TcpInstanceRcv:[%ld] 0x%p: SR/E/F1/F2/CW/CL/LA/TW(%d): "
                    "ACKing suspicious RST and dropping\n",
                     pxConn->lConnNo, pxConn, pxConn->eState); */
           if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
           {
               DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
               DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
               DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": SR/E/F1/F2/CW/CL/LA/TW(",pxConn->eState);
               DEBUG_PRINTNL(DEBUG_MOC_IPV4,"): ACKing suspicious RST and dropping");
           }
           _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext,
                       pxConnect->dwRcvNext, TCPCONN_FLAGMASK_ACK, TCP_NODATA);
           NETPAYLOAD_DELUSER(pxPacket->pxPayload);
           CHECKPOINT(g_dwTcpInstanceRcv);
           return wLength;
    }

    } /* reset bit set */

    if (pxConnect->oSegControl & TCPCONN_FLAGMASK_SYN) { /* SYN bit set */
       /* A) SYN rcvd in synchronized state. send ACK */
           /* TCP_DBGP(REPETITIVE,
            "TcpInstanceRcv:[%ld] 0x%p: SR/E/F1/F2/CW/CL/LA/TW(%d): "
                    "ACKing suspicious SYN and dropping\n",
                     pxConn->lConnNo, pxConn, pxConn->eState); */
           if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
           {
               DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
               DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
               DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": SR/E/F1/F2/CW/CL/LA/TW(",pxConn->eState);
               DEBUG_PRINTNL(DEBUG_MOC_IPV4,"): ACKing suspicious SYN and dropping");
           }
           _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext,
                       pxConnect->dwRcvNext, TCPCONN_FLAGMASK_ACK, TCP_NODATA);
           NETPAYLOAD_DELUSER(pxPacket->pxPayload);
           CHECKPOINT(g_dwTcpInstanceRcv);
           return wLength;
    } /* SYN bit set */

    /* No need to implement "Blind data injection check" as we only
     * check (below) for SND.UNA <= SEG.ACK <= SND.NXT and not
     * for (SND.UNA - 2^31 - 1) <= SEG.ACK <= SND.NXT and not
     */
    CHECKPOINT(g_dwTcpInstanceRcv);
#endif /* ifdef TCPSECURE */

    if (!bPacketAccept) {
      /*this is only an ACK for the incomming segment, not for the
       * invalid sequence number space nothing is ACKed by sending
       * dwRcvNext */
      /* _TcpConnSendSegment checks outbuf full, if full just returns */
      if (!(pxConnect->oSegControl & TCPCONN_FLAGMASK_RST)) {
        /* RST serves as response to segment; no need to ACK the RST */
        if(TCPCONN_STATE_TIME_WAIT == pxConn->eState)
        {
          /* RFC 793 section 3.9, page 73 Event Processing*/
          /* Check if we are in the timed wait state, FIN obtained  ,restrart the fun_wait2 timer */
          if(pxConnect->oSegControl & TCPCONN_FLAGMASK_FIN)
          {
            /* Send an ACK back */
            _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext,
                                TCPCONN_FLAGMASK_ACK, TCP_NODATA);
#ifndef __TCP_OPT_ON__
            if ( pxConnect->wFinwait2Timer )
              LIST_REMOVE (pxConn, finack2_link);
#endif /* __TCP_OPT_ON__*/
            /* Start TIME_WAIT Timer, Uses Finwait2Timer */
            pxConnect->wFinwait2Timer = pxTcp->w2mslTimer;
#ifndef __TCP_OPT_ON__
            /* Convert it to Actual  Ticks */
            pxConnect->wFinwait2Timer = pxConnect->wFinwait2Timer * 500 +  pxTcp->dwTicks;
            _TcpInsertOrderedList (&pxTcp->lFinwait2List,
                                   pxConn,
                                   TCP_TIMER_FINWAIT2);
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
            {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "TcpInstanceRcv:[", pxConn->lConnNo);
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": SR/E/F1/F2/CW/CL/LA/TW(",pxConn->eState);
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"): restarting ticks of lFinwait2Timer to :", pxConnect->wFinwait2Timer);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
            }
#endif /* __TCP_OPT_ON__*/
          }
          else
            /* Send a RST message */
            _TcpSendRST(pxTcp, pxIpSD, &xTcpHeader, wDatalen);
        }
        else
          _TcpConnSendSegment(pxTcp, pxConn, pxConnect->dwSendNext,pxConnect->dwRcvNext,
                            TCPCONN_FLAGMASK_ACK,TCP_NODATA);
      }
      /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p: SR/E/F1/F2/CW/CL/LA/TW(%d)->free: sending ACK 2\n",
               pxConn->lConnNo, pxConn, pxConn->eState); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
      {
           DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
           DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
           DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": SR/E/F1/F2/CW/CL/LA/TW(",pxConn->eState);
           DEBUG_PRINTNL(DEBUG_MOC_IPV4,")->free: sending ACK 2");
      }
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      CHECKPOINT(g_dwTcpInstanceRcv);
      return wLength;
    }
    CHECKPOINT(g_dwTcpInstanceRcv);
    if ( !(pxConnect->dwSegSequenceNumber==pxConnect->dwRcvNext)) {
      /*if this warning occurs, additional opteration relative to tailoring segements has to be done*/
    }
    CHECKPOINT(g_dwTcpInstanceRcv);


    /*We come to here, when the acknowledge of the sequencenumber(s) is acceptable*/
    if(pxConnect->oSegControl & TCPCONN_FLAGMASK_RST) { /* trim check mg */
      switch(pxConn->eState) { /* switch level 1 */
      case TCPCONN_STATE_SYNRCVD:
        /* TCP_DBGP(ERROR,"TcpInstanceRcv:[%ld] 0x%p: SYN_RCVD-> free: rcvd RST\n",
              pxConn->lConnNo, pxConn); */
        if(pxConnect->oPassiveOpen & TCPCONN_FLAGMASK_PASOPEN)
          _TcpPassiveConnClose(pxTcp, pxConn);
        /*_TcpConnClose(pxTcp, pxConn); *//* ANVL 3 */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,": SYN_RCVD-> free: rcvd RST");
        }
        SNMP( xTcpipData.tcpAttemptFails++ );
        break;

      case TCPCONN_STATE_ESTABLISHED:
        /* Added support for read after RESET */

      case TCPCONN_STATE_CLOSE_WAIT:
        SNMP( xTcpipData.tcpEstabResets++ );

      case TCPCONN_STATE_FIN_WAIT_1:
      case TCPCONN_STATE_FIN_WAIT_2:
        /* TCP_DBGP(ERROR,"TcpInstanceRcv:[%ld] 0x%p: E/F1/F2/CW (%d)-> free: rcvd RST\n",
              pxConn->lConnNo, pxConn, pxConn->eState); */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": E/F1/F2/CW (",pxConn->eState);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,")-> free: rcvd RST");
        }
        pxConn->eState = TCPCONN_STATE_CLOSED;
      /*  JJ RFC  s3.9 page 70 send callback to socket */
       _TcpConnRst(pxTcp, pxConn);
      /* RST Cleans it up _TcpConnClose(pxTcp, pxConn);*/
        break;

      case TCPCONN_STATE_CLOSING:
      case TCPCONN_STATE_LAST_ACK:
      case TCPCONN_STATE_TIME_WAIT:
        /* TCP_DBGP(ERROR,"TcpInstanceRcv:[%ld] 0x%p: tcp_rcv: CL/LA/TW (%d)-> free: rcvd RST\n",
              pxConn->lConnNo, pxConn, pxConn->eState); */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": tcp_rcv: CL/LA/TW (",pxConn->eState);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,")-> free: rcvd RST");
        }
        /* JJ RFC s3.9 page 70  Dealing with RST */
        pxConn->eState = TCPCONN_STATE_CLOSED;
        _TcpConnClose(pxTcp, pxConn);
        break;
      default:
        break;
      } /* end switch level 1 */
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      return wLength;
    }
    CHECKPOINT(g_dwTcpInstanceRcv);
    /*security check skipped*/
    if(pxConnect->oSegControl & TCPCONN_FLAGMASK_SYN) {
      /* _TcpConnSendSegment checks outbuf full, if full just returns */
      /* TCP_DBGP(ERROR,"TcpInstanceRcv:[%ld] 0x%p: SR/E/F1/F2/CW/CL/LA/TW(%d)->free: Rcvd SYN: sending RST 4\n",
            pxConn->lConnNo, pxConn, pxConn->eState);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_ERROR))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": SR/E/F1/F2/CW/CL/LA/TW(",pxConn->eState);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,")-> free: Rcvd SYN: sending RST 4");
        }
      _TcpDrop(pxTcp, pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext);
      _TcpConnRst(pxTcp, pxConn);
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      CHECKPOINT(g_dwTcpInstanceRcv);
      return wLength;
    }
    CHECKPOINT(g_dwTcpInstanceRcv);
    if( ! pxConnect->oSegControl & TCPCONN_FLAGMASK_ACK) {
      CHECKPOINT(g_dwTcpInstanceRcv);
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      CHECKPOINT(g_dwTcpInstanceRcv);
      return wLength;
    }
    else {
      CHECKPOINT(g_dwTcpInstanceRcv);
      /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p: Rcvd an ... Ack ...  \n",
            pxConn->lConnNo, pxConn); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,": Rcvd an ... Ack ...  ");
        }
      switch(pxConn->eState) { /* switch level 1 */
      case TCPCONN_STATE_SYNRCVD:
        CHECKPOINT(g_dwTcpInstanceRcv);
#ifdef SEQNUM_ROLLOVER
        if(_TcpBefore(pxConnect->dwSendUnacked, pxConnect->dwSegAckNumber+1) &&
           _TcpBefore(pxConnect->dwSegAckNumber, pxConnect->dwSendNext+1))
#else
        if((pxConnect->dwSendUnacked <= pxConnect->dwSegAckNumber) &&
          (pxConnect->dwSegAckNumber <= pxConnect->dwSendNext))
#endif
        {
          pxConn->eState=TCPCONN_STATE_ESTABLISHED;
#ifndef __TCP_OPT_ON__
          if ( pxConnect->wConestabTimer )
            LIST_REMOVE (pxConn, conestab_link);
#endif /* __TCP_OPT_ON__*/
          /* turn off conestab timer & turn on keepalive (if set) */
          pxConnect->wConestabTimer = pxTcp->wKeepAliveTimer;
#ifndef __TCP_OPT_ON__
         /* Convert it to Actual  Ticks */
          if (pxTcp->wKeepAliveTimer)
          {
            pxConnect->wConestabTimer = pxConnect->wConestabTimer * 500 +  pxTcp->dwTicks;
            _TcpInsertOrderedList (&pxTcp->lConestabList,
                                   pxConn,
                                   TCP_TIMER_CONESTAB);
          }
#endif /* __TCP_OPT_ON__*/
          /* set up receive window */
          pxConnect->dwRcvWindow = pxConn->wWin;
          /* send callback to socket */
          ASSERT(pxConn->pfnCbk != NULL);
          lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                                  (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                                  TCPULINTERFACECBK_OPENED, (H_NETDATA) 0);

          if (lRc < 0) {
            /* socket has refused open - send RST */
            _TcpDrop(pxTcp, pxConn, pxConnect->dwSendIss, pxConnect->dwRcvNext);
            lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                                (H_NETINTERFACE) pxConn);
            NETPAYLOAD_DELUSER(pxPacket->pxPayload);
            return wLength;
          } /* end refused */
        }
      /* theres is no break; processing will be continued*/
      case TCPCONN_STATE_ESTABLISHED:
      case TCPCONN_STATE_CLOSE_WAIT:
      case TCPCONN_STATE_FIN_WAIT_1:
      case TCPCONN_STATE_FIN_WAIT_2:
      case TCPCONN_STATE_CLOSING:
        CHECKPOINT(g_dwTcpInstanceRcv);
        TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p: rcvd data --- \n",
              pxConn->lConnNo, pxConn);
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,": rcvd data --- ");
        }
#ifdef SEQNUM_ROLLOVER
        if(_TcpBefore(pxConnect->dwSendUnacked, pxConnect->dwSegAckNumber) &&
           _TcpBefore(pxConnect->dwSegAckNumber, pxConnect->dwSendNext+1))
#else
        if((pxConnect->dwSendUnacked < pxConnect->dwSegAckNumber) &&
            (pxConnect->dwSegAckNumber<= pxConnect->dwSendNext))
#endif
        {
          TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p refreshing retransmission queue on ACK (%ld)\n",
                pxConn->lConnNo, pxConn, pxConnect->dwSegAckNumber - pxConnect->dwSendUnacked);
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," refreshing retransmission queue on ACK (",
                  (pxConnect->dwSegAckNumber - pxConnect->dwSendUnacked));
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,")");
          }
          pxConnect->dwSendUnacked=pxConnect->dwSegAckNumber;
          CHECKPOINT(g_dwTcpInstanceRcv);
          _TcpRefreshRetransmissionQueue(pxTcp, pxConn);
          CHECKPOINT(g_dwTcpInstanceRcv);
        }
#ifdef SEQNUM_ROLLOVER
        if (_TcpAfter(pxConnect->dwSegAckNumber, pxConnect->dwSendNext))
#else
        if (pxConnect->dwSegAckNumber > pxConnect->dwSendNext)
#endif
        {
          CHECKPOINT(g_dwTcpInstanceRcv);
#ifndef __TCP_OPT_ON__
          if ( pxConnect->bDelayedAck )
            LIST_REMOVE (pxConn, fastack_link);
#endif /* __TCP_OPT_ON__*/
          /* Buf Full checked before */
          pxConnect->bDelayedAck = 1;
#ifndef __TCP_OPT_ON__
         /* Convert it to Actual  Ticks */
          pxConnect->wFastackTimer = 200 +  pxTcp->dwTicks;
          _TcpInsertOrderedList (&pxTcp->lFastackList,
                                 pxConn,
                                 TCP_TIMER_FASTACK);
#endif /* __TCP_OPT_ON__*/
          /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p: Delayed ACK: E/CW/F1/F2/CL(%d):->free: sendng ACK 3,NODATA segack=%ld,sndnxt=%ld\n",
                pxConn->lConnNo, pxConn, pxConn->eState, pxConnect->dwSegAckNumber, pxConnect->dwSegAckNumber);*/
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": Delayed ACK: E/CW/F1/F2/CL(",pxConn->eState);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"):->free: sendng ACK 3,NODATA segack=",pxConnect->dwSegAckNumber);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,",sndnxt=",pxConnect->dwSendNext);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
          }
          CHECKPOINT(g_dwTcpInstanceRcv);
          NETPAYLOAD_DELUSER(pxPacket->pxPayload);
          CHECKPOINT(g_dwTcpInstanceRcv);
          return wLength;
        }

        /*TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p: segUnacked =%lu, segack=%lu,sndnxt=%lu\n",
                pxConn->lConnNo, pxConn, pxConnect->dwSegAckNumber, pxConnect->dwSendNext);*/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,", segack=",pxConnect->dwSegAckNumber);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,", sndnxt=",pxConnect->dwSendNext);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
          }
        /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p: SegWindow= %lu\n",
            pxConn->lConnNo, pxConn,pxConnect->dwSegWindow); */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,",: SegWindow= ",pxConnect->dwSegWindow);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
          }
#ifdef SEQNUM_ROLLOVER
        if(_TcpBefore(pxConnect->dwSendUnacked, pxConnect->dwSegAckNumber+1) &&
           _TcpBefore(pxConnect->dwSegAckNumber, pxConnect->dwSendNext+1) )
#else
        if((pxConnect->dwSendUnacked <= pxConnect->dwSegAckNumber) &&
            (pxConnect->dwSegAckNumber <= pxConnect->dwSendNext) )
#endif
        {
            /* JJ Initialize this or else it wont take in - numbers */
#if 1
            /* To be done once during init */
            if (0 == pxConnect->dwSendWl1)
                pxConnect->dwSendWl1 = pxConnect->dwSegSequenceNumber;
            if (0 == pxConnect->dwSendWl2)
                pxConnect->dwSendWl2 = pxConnect->dwSegAckNumber;
#endif
          /*update the sending window*/
             /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p: SendWl1 =%lu SeqNum %lu SendWl2 =%lu SegAck= %lu\n",
                pxConn->lConnNo, pxConn, pxConnect->dwSendWl1, pxConnect->dwSegSequenceNumber, pxConnect->dwSendWl2,pxConnect->dwSegAckNumber); */
             if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
             {
                 DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
                 DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
                 DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": SendWl1 =",pxConnect->dwSendWl1);
                 DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"  SeqNum  =",pxConnect->dwSendWl1);
                 DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"  SendWl2 =",pxConnect->dwSendWl2);
                 DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"  SegAck =",pxConnect->dwSegAckNumber);
                 DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
             }
#ifdef SEQNUM_ROLLOVER
          if(_TcpBefore(pxConnect->dwSendWl1, pxConnect->dwSegSequenceNumber) ||
             ((pxConnect->dwSendWl1==pxConnect->dwSegSequenceNumber ) &&
               _TcpBefore(pxConnect->dwSendWl2, pxConnect->dwSegAckNumber+1)
             )
            )
#else
          if((pxConnect->dwSendWl1 < pxConnect->dwSegSequenceNumber) ||
             ((pxConnect->dwSendWl1==pxConnect->dwSegSequenceNumber ) &&
              (pxConnect->dwSendWl2 <= pxConnect->dwSegAckNumber ) ))
#endif
          {
            pxConnect->dwSendWindow = pxConnect->dwSegWindow;
            pxConnect->dwSendWl1 = pxConnect->dwSegSequenceNumber;
            pxConnect->dwSendWl2 = pxConnect->dwSegAckNumber;
          }
        }

        CHECKPOINT(g_dwTcpInstanceRcv);
        switch(pxConn->eState) { /* switch level 2 */

        case TCPCONN_STATE_FIN_WAIT_1:
          if(pxConnect->bFinAcked) {
            /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: Rcvd ACK: F1-->F2\n" ,
                  pxConn->lConnNo, pxConn); */
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
             {
                 DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
                 DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
                 DEBUG_PRINTNL(DEBUG_MOC_IPV4,": Rcvd ACK: F1-->F2");
             }
            pxConn->eState=TCPCONN_STATE_FIN_WAIT_2;

            /* Start FIN_WAIT_2 Timer only if close() was called.
             * Do not call timer if shutdown() was called. */
            if(pxConnect->bCloseCalled) {
#ifndef __TCP_OPT_ON__
              if ( pxConnect->wFinwait2Timer )
                LIST_REMOVE (pxConn, finack2_link);
#endif /* __TCP_OPT_ON__*/
              pxConnect->wFinwait2Timer = TCP_FINWAIT2_TIMER;
#ifndef __TCP_OPT_ON__
              /* Convert it to Actual  Ticks */
              pxConnect->wFinwait2Timer = pxConnect->wFinwait2Timer * 500 +  pxTcp->dwTicks;
              _TcpInsertOrderedList (&pxTcp->lFinwait2List,
                                     pxConn,
                                     TCP_TIMER_FINWAIT2);
#endif /* __TCP_OPT_ON__*/
            }
            CHECKPOINT(g_dwTcpInstanceRcv);
          }

          break;

        case TCPCONN_STATE_CLOSING:
          if(pxConnect->bFinAcked) {
            /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: Rcvd ACK: CLOSING->TIME_WAIT\n",
                  pxConn->lConnNo, pxConn); */
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
             {
                 DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
                 DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
                 DEBUG_PRINTNL(DEBUG_MOC_IPV4,": Rcvd ACK: CLOSING->TIME_WAIT");
             }
            pxConn->eState=TCPCONN_STATE_TIME_WAIT;
#ifndef __TCP_OPT_ON__
            if ( pxConnect->wFinwait2Timer )
              LIST_REMOVE (pxConn, finack2_link);
#endif /* __TCP_OPT_ON__*/
              /* Start TIME_WAIT Timer, Uses Finwait2Timer */
            pxConnect->wFinwait2Timer = pxTcp->w2mslTimer;
#ifndef __TCP_OPT_ON__
            /* Convert it to Actual  Ticks */
            pxConnect->wFinwait2Timer = pxConnect->wFinwait2Timer * 500 +  pxTcp->dwTicks;
            _TcpInsertOrderedList (&pxTcp->lFinwait2List,
                                   pxConn,
                                   TCP_TIMER_FINWAIT2);
#endif /* __TCP_OPT_ON__*/

            CHECKPOINT(g_dwTcpInstanceRcv);
          }
          break;

        default:
        break;
        } /* end switch level 2 */
        break;

      case TCPCONN_STATE_LAST_ACK:
        /*if(pxConnect->bFinAcked) {
          Fix this. check if ack is for fin mg */
        /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: Rcvd ACK: LA->free\n",
                 pxConn->lConnNo, pxConn); */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,": Rcvd ACK: LA->free");
        }
        _TcpConnClose(pxTcp, pxConn);
        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        CHECKPOINT(g_dwTcpInstanceRcv);
        return wLength;


      case TCPCONN_STATE_TIME_WAIT:
        /* _TcpConnSendSegment checks outbuf full, if full just returns */
        /* ignore segment if URG bit is set , RFC 793, sec 3.9, page 73*/
        /* ignore all messages except for FIN , RFC 793, sec 3.2 page 23, ANVL 1.27*/
        if((xTcpHeader.oFlags & TCPCONN_FLAGMASK_FIN))
        {
          _TcpConnSendSegment(pxTcp,pxConn,pxConnect->dwSendNext,pxConnect->dwRcvNext,
                              TCPCONN_FLAGMASK_ACK,TCP_NODATA);
          /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: Rcvd ACK: TW-> : sending ACK 4, NODATA\n",
                 pxConn->lConnNo, pxConn); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_NORMAL))
          {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,": Rcvd ACK: TW-> : sending ACK 4, NODATA");
          }
        }
        CHECKPOINT(g_dwTcpInstanceRcv);
        break;

      default:
        break;
      } /* end switch level 1 */

#if TRIM_CODE
      /* Special processing for urgent data TBD here */
      if (pxConnect->oSegControl & TCPCONN_FLAGMASK_URG) {
        CHECKPOINT(g_dwTcpInstanceRcv);
        switch(pxConn->eState) { /* switch level 2 */

        case TCPCONN_STATE_ESTABLISHED:
        case TCPCONN_STATE_FIN_WAIT_1:
        case TCPCONN_STATE_FIN_WAIT_2:
          CHECKPOINT(g_dwTcpInstanceRcv);
          break;

        case TCPCONN_STATE_CLOSE_WAIT:
        case TCPCONN_STATE_CLOSING:
        case TCPCONN_STATE_LAST_ACK:
        case TCPCONN_STATE_TIME_WAIT:
          CHECKPOINT(g_dwTcpInstanceRcv);
          break;

        default:
          break;
        } /* end switch level 2 */
      }
#endif

      CHECKPOINT(g_dwTcpInstanceRcv);
      /* processing text in the segment */
      switch(pxConn->eState) {/* switch level 2 */

      case TCPCONN_STATE_ESTABLISHED:
      case TCPCONN_STATE_FIN_WAIT_1:
      case TCPCONN_STATE_FIN_WAIT_2:
      case TCPCONN_STATE_CLOSING:
        CHECKPOINT(g_dwTcpInstanceRcv);
        TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] Processing text in segment datalen = %d\n",
              pxConn->lConnNo, wDatalen);
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"] Processing text in segment datalen = ",wDatalen);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
          }

        CHECKPOINT(g_dwTcpInstanceRcv);

        /*
        * If the incoming packet's sequence number does
        * not match the acknowledgement number maintained
        * internally, drop the packet. This avoids loss of
        * synchronization when the tx end sends multiple
        * packets without waiting for an ACK and one or
        * more of the packets other than the last one get
        * lost.
        */
        if (pxConnect->dwSegSequenceNumber != pxConnect->dwRcvNext) {
          /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:Missing Packet  Seq# in packet = %ld  Exp. Seq# = %ld\n",
              pxConnect->dwSegSequenceNumber,
              pxConnect->dwRcvNext); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:Missing Packet  Seq# in packet = ",pxConnect->dwSegSequenceNumber);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"  Exp. Seq# = ",pxConnect->dwRcvNext);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
          }
          NETPAYLOAD_DELUSER(pxPacket->pxPayload);
          return wLength;
        }

        if (wDatalen > 0) {
#if 0 /* zero-copy */
          /* to eliminate holding problems, get a new payload for now */
          MOC_MEMCPY((ubyte *)&xNewPacket, (ubyte *)pxPacket, sizeof(NETPACKET));

          pxNewPayload = _TcpGetPayload(pxTcp, wDatalen);
          ASSERT(pxNewPayload != NULL);

          MOC_MEMCPY((ubyte *)pxNewPayload->poPayload, (ubyte *)poTcpData, wDatalen);
          xNewPacket.pxPayload = pxNewPayload;
          CHECKPOINT(g_dwTcpInstanceRcv);
          lRc = _TcpFillReassemblyBuffer(pxConnect, &xNewPacket,
                                         pxNewPayload->poPayload, wDatalen);
#else
          lRc = _TcpFillReassemblyBuffer(pxConnect, pxPacket,
                                         poTcpData, wDatalen);
#endif
          ASSERT(lRc >= 0);

          pxConnect->dwRcvNext+=wDatalen;

          /*adjust Window size*/
          if (pxConnect->wRxUsedSpace >= TCP_RX_MAXSPACE) {
            /* close the receive window */
            pxConnect->dwRcvWindow=0;
          }
        }

#if 1 /* zero-copy  JJ Did it Over riding RS code */
        if (! wDatalen) {
        /* free rx packet, no longer needed */
          NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        }
#endif

        if (((pxConnect->oSegControl & TCPCONN_FLAGMASK_PSH) || wDatalen) &&
            (pxConn->eState == TCPCONN_STATE_ESTABLISHED ||
             pxConn->eState == TCPCONN_STATE_CLOSE_WAIT)) {
          /* PUSH flag set or date is avaliable, send all to socket */
          (*pxConn->pfnRxCbk)(pxConn->hUL, pxConn->hIf, NULL, NULL, 0);
        }

        /* if the incomming segment carries data:
          send an ack, when
          - data waits to be send
          send a delayed ack, when
          - no data to send */

        CHECKPOINT(g_dwTcpInstanceRcv);
        if(wDatalen>0) {
          if (DLLIST_count(&pxConnect->dllSendBuff)>0) {
            /* Buf Ful checked before */
            /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p:  Rcvd ACK+DATA: E/F1/F2(%d)-> : snding ACK FOR DATA len=%d\n",
                    pxConn->lConnNo, pxConn, pxConn->eState, wDatalen); */
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
            {
                DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
                DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,":  Rcvd ACK+DATA: E/F1/F2(",pxConn->eState);
                DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,")-> : snding ACK FOR DATA len=",wDatalen);
                DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
            }

            _TcpConnSendSegment(pxTcp,pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext,
                                TCPCONN_FLAGMASK_ACK,TCP_DATAON);
          }
          else {
#ifndef __TCP_OPT_ON__
            if ( pxConnect->bDelayedAck )
              LIST_REMOVE (pxConn, fastack_link);
#endif /* __TCP_OPT_ON__*/
            pxConnect->bDelayedAck = 1;
#ifndef __TCP_OPT_ON__
           /* Convert it to Actual  Ticks */
            pxConnect->wFastackTimer = 200 +  pxTcp->dwTicks;
            _TcpInsertOrderedList (&pxTcp->lFastackList,
                                   pxConn,
                                   TCP_TIMER_FASTACK);
#endif /* __TCP_OPT_ON__*/
          }
        }
    /* RS: added following to send pending data even when there is no
           incoming data along with ACK */
    else if ((DLLIST_count(&pxConnect->dllSendBuff)>0) && (pxConnect->dwSendWindow !=0 )) {
            /* Buf Ful checked before */
            /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p:  Rcvd ACK: E/F1/F2(%d)-> : snding pending DATA\n",
                    pxConn->lConnNo, pxConn, pxConn->eState); */
            if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
            {
                DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
                DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,":  Rcvd ACK: E/F1/F2(",pxConn->eState);
                DEBUG_PRINTNL(DEBUG_MOC_IPV4,")-> : snding pending DATA");
            }
            _TcpConnSendSegment(pxTcp,pxConn, pxConnect->dwSendNext, pxConnect->dwRcvNext,
                                0,TCP_DATAON);
    }
    /* RS: done */

        /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p::(After recing datalen=%d) \n",
                 pxConn->lConnNo, pxConn, wDatalen); */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
             DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,":(After recing datalen=",wDatalen);
             DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }
        CHECKPOINT(g_dwTcpInstanceRcv);

        break;

      case TCPCONN_STATE_CLOSE_WAIT:
      case TCPCONN_STATE_LAST_ACK:
      case TCPCONN_STATE_TIME_WAIT:
        /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: Rcvd ACK+DATA: CL/CW/LA/TW(%d)->free : DATA len=%d\n",
                 pxConn->lConnNo, pxConn, pxConn->eState, wDatalen); */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
             DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": Rcvd ACK+DATA: CL/CW/LA/TW(",pxConn->eState);
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,")->free : DATA len=",wDatalen);
             DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }
        NETPAYLOAD_DELUSER(pxPacket->pxPayload);
        CHECKPOINT(g_dwTcpInstanceRcv);
        return wLength;

      default:
          break;
      } /* end switch level 2 */

      if(pxConnect->oSegControl & TCPCONN_FLAGMASK_FIN) {
        /*check for a FIN flag, for advancing the dwRcvNext_nbr*/
        TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] 0x%p: SR/E/F1/F2/CW/CL/LA/TW(%d)->"
                 ": recd FIN advancing dwRcvNext_nbr\n",
                 pxConn->lConnNo, pxConn, pxConn->eState);
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
        {
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
             DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": SR/E/F1/F2/CW/CL/LA/TW(",pxConn->eState);
             DEBUG_PRINTNL(DEBUG_MOC_IPV4," ");
        }
        pxConnect->dwRcvNext+=1;

        switch(pxConn->eState) { /* switch level 2 */

        case TCPCONN_STATE_CLOSED:
        case TCPCONN_STATE_LISTEN:
        case TCPCONN_STATE_SYNSENT:
          /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: Rcvd ACK+FIN: CLOSED/LIS/SYN_SENT(%d)->free:\n",
                   pxConn->lConnNo, pxConn, pxConn->eState); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
             DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": Rcvd ACK+FIN: CLOSED/LIS/SYN_SENT(",pxConn->eState);
             DEBUG_PRINTNL(DEBUG_MOC_IPV4,")->free:");
          }
          NETPAYLOAD_DELUSER(pxPacket->pxPayload);
          CHECKPOINT(g_dwTcpInstanceRcv);
          return wLength;

        default:
          break;
        }/* end switch level 2 */
        /* oBufFull checked before */
        _TcpConnSendSegment(pxTcp,pxConn,pxConnect->dwSendNext,pxConnect->dwRcvNext,
                            TCPCONN_FLAGMASK_ACK,TCP_NODATA);

        switch(pxConn->eState) {/* switch level 2 */

        case TCPCONN_STATE_SYNRCVD:
        case TCPCONN_STATE_ESTABLISHED:
          /* TCP_DBGP(REPETITIVE,"TcpInstanceRcv:[%ld] %p: Rcvd ACK+FIN: EST/SYN_RECVD(%d)-> CLOSE_WAIT: ACK Sent\n",
                   pxConn->lConnNo, pxConn, pxConn->eState); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
             DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": Rcvd ACK+FIN: EST/SYN_RECVD(",pxConn->eState);
             DEBUG_PRINTNL(DEBUG_MOC_IPV4,")-> CLOSE_WAIT: ACK Sent");
          }

          /* App will find out the change in state and take appropriate action */
          pxConn->eState=TCPCONN_STATE_CLOSE_WAIT;
          /* send callback to socket */
          ASSERT(pxConn->pfnCbk != NULL);
          lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                                  (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                                  TCPULINTERFACECBK_HALFCLOSED,(H_NETDATA)0);

          if (lRc < 0) {
            /* callback fail - destroy connection */
            lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                          (H_NETINTERFACE) pxConn);
          }

          /* Note:
           * If socket has not been accepted() and it was not an active
           * open (otherwise, in both cases apps know about socket
           * number and should initiate close), it will get closed when
           * close on the listen socket is called. */
          CHECKPOINT(g_dwTcpInstanceRcv);
          break;

        case TCPCONN_STATE_FIN_WAIT_1:
          TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: Rcvd ACK+FIN: F1->CLOSING: ACK Sent\n",
                   pxConn->lConnNo, pxConn);
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
             DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,": Rcvd ACK+FIN: F1->Closing (",pxConn->eState);
             DEBUG_PRINTNL(DEBUG_MOC_IPV4," ACK Sent");
          }
          pxConn->eState=TCPCONN_STATE_CLOSING;
          ASSERT(pxConn->pfnCbk != NULL);
          lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                                  (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                                  TCPULINTERFACECBK_RST,(H_NETDATA)0);

          if (lRc < 0) {
            /* callback fail - destroy connection */
            lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                          (H_NETINTERFACE) pxConn);
          }
          CHECKPOINT(g_dwTcpInstanceRcv);
          break;

        case TCPCONN_STATE_FIN_WAIT_2:
          /* TCP_DBGP(NORMAL,"TcpInstanceRcv:[%ld] 0x%p: Rcvd ACK+FIN: F2->TIME_WAIT: ACK Sent\n",
                   pxConn->lConnNo, pxConn); */
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_TCP, INET_DBG_LEVEL_REPETITIVE))
          {
             DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"TcpInstanceRcv:[",pxConn->lConnNo);
             DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"] 0x",(sbyte4)pxConn);
             DEBUG_PRINTNL(DEBUG_MOC_IPV4,": Rcvd ACK+FIN: F2->TIME_WAIT: ACK Sent");
          }
          pxConn->eState=TCPCONN_STATE_TIME_WAIT;
#ifndef __TCP_OPT_ON__
          if ( pxConnect->wFinwait2Timer )
            LIST_REMOVE (pxConn, finack2_link);
#endif /* __TCP_OPT_ON__*/
          /* Start TIME_WAIT Timer */
          pxConnect->wFinwait2Timer = pxTcp->w2mslTimer;
#ifndef __TCP_OPT_ON__
          /* Convert it to Actual  Ticks */
          pxConnect->wFinwait2Timer = pxConnect->wFinwait2Timer * 500 +  pxTcp->dwTicks;
          _TcpInsertOrderedList (&pxTcp->lFinwait2List,
                                     pxConn,
                                     TCP_TIMER_FINWAIT2);
#endif /* __TCP_OPT_ON__*/
          ASSERT(pxConn->pfnCbk != NULL);
          lRc = (*pxConn->pfnCbk)((H_NETINSTANCE)pxConn->hUL,
                                  (H_NETINTERFACE)pxConn->hIf,
#ifndef __TCP_OPT_ON__
                                (LONG)pxConn->lFd,
#endif
                                  TCPULINTERFACECBK_RST,(H_NETDATA)0);

          if (lRc < 0) {
            /* callback fail - destroy connection */
            lRc = TcpInstanceULInterfaceDestroy((H_NETINSTANCE) pxTcp,
                                          (H_NETINTERFACE) pxConn);
          }
          CHECKPOINT(g_dwTcpInstanceRcv);
          break;

        default:
          break;
        }/* end switch level 2 */
      } /* end if FIN */

      return wLength;
    }
    break;
    /*---------------------------------------------------------*/
  default:
    CHECKPOINT(g_dwTcpInstanceRcv);
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    return wLength;
  }
  CHECKPOINT(g_dwTcpInstanceRcv);
  NETPAYLOAD_DELUSER(pxPacket->pxPayload);
  CHECKPOINT(g_dwTcpInstanceRcv);
  ASSERT(0);

  return -1;
}

/*
 * TcpInstanceProcess
 *  Do the instance necessary processing
 *  Called every 10 ms
 *
 *  Args:
 *   hTcp                        Tcp Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 5 ms)
 */
LONG TcpInstanceProcess(H_NETINSTANCE hTcp)
{
  TCPSTATE *pxTcp = (TCPSTATE *)hTcp;

  TCP_CHECK_STATE(pxTcp);

  #ifdef TCPDBG_HI
  if(gbTcpPrintConnection == TRUE){
    _TcpPrintConnection(pxTcp);
    gbTcpPrintConnection = FALSE;
  }
  #endif

  pxTcp->dwTicks = (DWORD)NetGetMsecTime();

  /* check fast timer  - 200 ms */
  if (_TcpAfter((pxTcp->dwTicks - pxTcp->dwTcpFastTimeoutLastCalled) , 200)) {
    _TcpFastTimeout(pxTcp);
    pxTcp->dwTcpFastTimeoutLastCalled = pxTcp->dwTicks;
  }else{
    /*TCP_DBGP(REPETITIVE, */
        /*"TcpInstanceProcess: fast timer not expired %u - %u\n", */
        /*pxTcp->dwTicks, pxTcp->dwTcpFastTimeoutLastCalled); */
  }

  /* check slow timer  - 500 ms */
  if (_TcpAfter((pxTcp->dwTicks - pxTcp->dwTcpSlowTimeoutLastCalled) , 500)) {
    _TcpSlowTimeout(pxTcp);
    pxTcp->dwTcpSlowTimeoutLastCalled = pxTcp->dwTicks;
  }

  return 20;
}
