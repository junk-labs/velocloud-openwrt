/*
 * eaptlsclient.c
 *
 * EAPTLS (Challenge Handshake Authentification Protocol) client
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"

#include "eaptlsclient_flavor.h"
#include "string.h"
#include "stdlib.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h> /* ntoh macros */
#include <netinet/in.h> /* ntoh macros on Linux/Solaris */
#include <pthread.h>
/* #include <mqueue.h> */
#include <stdio.h>
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"
#include "cryptcommon.h"
#include "md5.h"
#include "eaptlsclient.h"

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * EapTlsInstanceQuery
 *   Query EAPTLS options
 *
 *   Args:
 *     hEapTls           Handle to the instance to destroy
 *     oOptio          Option code
 *     phData          data handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsInstanceQuery(H_NETINSTANCE hEapTls,OCTET oOption,H_NETDATA * phData)
{
  /* Nothing for now */
  return NETERR_NOERR;
}

