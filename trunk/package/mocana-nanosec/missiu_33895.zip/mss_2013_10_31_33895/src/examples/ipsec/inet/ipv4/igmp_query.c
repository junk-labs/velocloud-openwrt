/*
 * igmp_query.c
 *
 * IGMP module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "igmp_defs.h"

#ifdef STACK_MULTICAST_ROUTER

/*****************************************************************************
 * Function:
 *   IgmpProxySendQuery()
 * Description:
 *   Sends an IGMP query (general or specific) to all hosts on the
 *   LAN interface
 *
 *****************************************************************************/
void IgmpProxySendQuery(IGMPSTATE *pxIgmp,
                        DWORD dwMastIpAddr,
                        OCTET oMaxResponseTime)
{
  LONG lRv;
  IPMCASTREQ xIpMreq;
  DWORD dwDstAddr = ntohl((DWORD)inet_addr(MULTICAST_ALLHOSTS_GROUP));

  xIpMreq.dwMulticastAddr = dwMastIpAddr;
  xIpMreq.oPhyIf = pxIgmp->oProxyIfIndex;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IGMP_DBGP(REPETITIVE,"IgmpProxySendQuery: Sending %s query: %ld.%ld.%ld.%ld\n",
            dwMastIpAddr == (DWORD)0 ? "general" : "specific",
            IPADDRDISPLAY(dwMastIpAddr));*/
    DEBUG_PRINT2(DEBUG_MOC_IPV4, "IgmpProxySendQuery: Sending ",
                 (dwMastIpAddr == (DWORD)0 ? "general" : "specific"));
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " query: ", dwMastIpAddr);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  lRv = IgmpSendPacket(pxIgmp,
                       &xIpMreq,
                       dwDstAddr,
                       IGMP_MEMBERSHIP_QUERY,
                       oMaxResponseTime,
                       1,
                       NULL,
                       0);
  /* ASSERT(lRv > 0); - RS commented out. There may not be any interfaces yet */
}

#endif /* #ifdef STACK_MULTICAST_ROUTER */
