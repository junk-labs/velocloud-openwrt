#ifndef _LIBSOCK_SERVER_H_
#define _LIBSOCK_SERVER_H_
#define ERR_LIBSOCK_SELECT_TIMEOUT -9999
MOC_EXTERN sbyte4 
SOCKSERVER_connectReply(ubyte *ipc_req, sbyte4 callStat);
MOC_EXTERN sbyte4 
SOCKSERVER_acceptReply(ubyte *ipc_req, sbyte4 childFd, struct sockaddr *sockAddr, socklen_t addrLen);
MOC_EXTERN sbyte4 
SOCKSERVER_recvReply(ubyte *ipc_req, sbyte4 sockfd, ubyte * buff, sbyte4 bufSize,struct sockaddr *sockAddr, socklen_t addrLen);
MOC_EXTERN sbyte4 
SOCKSERVER_selectReply(ubyte *ipc_req, int numSet);
MOC_EXTERN sbyte4 
SOCKSERVER_plainReply(ubyte *ipc_req);
#endif
