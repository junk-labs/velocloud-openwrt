/*
 * ntpint.h
 *
 * Ntp internal header file. Contains packet structure
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*! \file ntp.h Embedded NTP %client interface header.
This header file contains definitions, enumerations, structures, and function
declarations used by the Embedded NTP %client interface.

\since 3.06
\version 3.06 and later

! Flags
There are no flag dependencies in this header file.

\todo Reformat DoxyS comments when NTP is added to the API Ref.

*/

#ifndef __NTP_H__
#define __NTP_H__

#ifdef __cplusplus
extern "C" {
#endif

/* macro for filling li_vn_mode */
#define   PKT_LI_VN_MODE(li, vn, md) \
    ((ubyte)((((li) << 6) & 0xc0) | (((vn) << 3) & 0x38) | ((md) & 0x7)))

/*
 * NTP protocol parameters.
 */
#define    NTP_VERSION        ((ubyte)3) /* current version number */
#define    NTP_LEAP_INDICATOR ((ubyte)0) /* Leap Indicator*/
#define    NTP_PORT           123    /* included for sake of non-unix machines*/

/*
 * Values for mode
 */
#define    MODE_UNSPEC        0    /* unspecified (probably old NTP version) */
#define    MODE_ACTIVE        1    /* symmetric active */
#define    MODE_PASSIVE       2    /* symmetric passive */
#define    NTP_MODE_CLIENT    3    /* client mode */
#define    MODE_SERVER        4    /* server mode */
#define    MODE_BROADCAST     5    /* broadcast mode */
#define    MODE_CONTROL       6    /* control mode packet */
#define    MODE_PRIVATE       7    /* implementation defined function */
#define    MODE_BCLIENT       8    /* a pseudo mode, used internally */
#define    MODE_MCLIENT       9    /* multicast mode, used internally */

#define NTP_REQ_TIMEOUT_INTERVAL_MS    (2  * 1000)

#define NTP_INSTANCE_ID_START      1
#define NTP_INSTANCE_ID_END        64

#define NTP_SERVER_DOWN            0
#define NTP_SERVER_UP              1

/*------------------------------------------------------------------*/
/*
 * NTP uses two fixed point formats.  The first (NtpTime) is the "long" format
 * and is 64 bits long with the decimal between bits 31 and 32.  This
 * is used for time stamps in the NTP packet header (in network byte
 * order) and for internal computations of offsets (in local host byte
 * order).  We use the same structure for both signed and unsigned values,
 * which is a big hack but saves rewriting all the operators twice.  Just
 * to confuse this, we also sometimes just carry the fractional part in
 * calculations, in both signed and unsigned forms.  Anyway, an NtpTime looks
 * like:
 *
 *    0              1              2              3
 *    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *   |                   Integral Part                 |
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *   |                   Fractional Part                 |
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 */

typedef struct NtpTime
{
    ubyte4 t_secs;      /* contains the Integral Part */
    ubyte4 t_msecs;     /* contains the Fractional Part */
} NtpTime;

typedef struct NtpPacket
{
    ubyte   li_vn_mode;     /* contains leap indicator, version and mode */
    ubyte   stratum;        /* peer's stratum */
    ubyte   ppoll;          /* the peer polling interval */
    ubyte   precision;      /* peer clock precision */
    sbyte4  rootdelay;      /* distance to primary clock */
    ubyte4  rootdispersion; /* clock dispersion */
    ubyte4  refid;          /* reference clock ID */
    NtpTime reftime;        /* time peer clock was last updated */
    NtpTime org;            /* originate time stamp */
    NtpTime rec;            /* receive time stamp */
    NtpTime xmt;            /* transmit time stamp */
} NtpPacket;

#define NTP_PKT_LEN sizeof(NtpPacket)

typedef enum
{
    NTP_FOUND        = 0,
    NTP_NOT_FOUND    = 1,
    NTP_REQ_TIMEOUT  = 2,
    NTP_ERROR        = -1
} NTP_RESULT;

typedef enum
{
    NTP_RESP_ATTRIB_SVR_TX_TIME = 0, /* Time at which NTP Server SENT response */
    NTP_RESP_ATTRIB_SVR_RX_TIME = 1, /* Time at which NTP Server RECVD request */
    NTP_RESP_ATTRIB_ORG_TX_TIME = 2, /* Time at which NTP Client SENT request */

    NTP_RESP_ATTRIB_MAX
} NTP_RESP_ATTRIBUTE;

typedef struct NTP_Globals
{
    rbtree_t      *instanceTree;
    ubyte         *instanceIdMap;
    RTOS_MUTEX    instanceTreeMutex;
    ubyte4        numInstances;

} NTP_Globals;

typedef struct
{
    ubyte4  txPacket;
    ubyte4  txFails;
    ubyte4  txRetries;

    ubyte4  rxGoodPacket;
    ubyte4  rxBadCode;
    ubyte4  rxBadLength;
    ubyte4  rxBadAttributes;
} NTP_Counters;


typedef struct NTP_RqstRecord
{
    intBoolean  inUse;
    ubyte4      timestamp;
    sbyte4      serverID;
    sbyte4      serverSrcPortNum;
    void*       userCookie;
    NtpPacket   ntpPacket;

} NTP_RqstRecord;

/*! Configuration settings and callback function pointers for NTP clients.
This structure is used for NTP %client configuration. Each callback function
should be customized for your application and then registered by assigning it to
the appropriate structure function pointer(s).

\since 3.06
\version 3.06 and later

! Flags
No flag definitions are required to use this structure.

*/
typedef struct NTP_Config
{
/*! Initialize a UDP connection.
This callback initializes a UDP connection to the specified NTP server, and
returns a unique cookie (through the $ppUDPCookie$ parameter) containing the
platform-specific data necessary to communicate with the %server. This function
should be called once for each NTP %server to which your NTP %client will
connect.

\since 3.06
\version 3.06 and later

||Name||Type||Description
|$srcAddress$|$MOC_IP_ADDRESS$|IP address to use as the source identifier when sending a UDP datagram.
|$pServerIPAddress$|$sbyte *$|String representation of the NTP server's IP address.
|$serverPort$|$ubyte2$|Listen port of the NTP %server.
|$ppUDPCookie$|$void **$|On return, pointer to cookie containing the platform-specific data necessary to communicate with the NTP %server.
|&nbsp;|&nbsp;|&nbsp;
||Return value|$sbyte4$|$OK$ (0) if successful; otherwise a negative number
error code definition from merrors.h. To retrieve a string containing an
English text error identifier corresponding to the function's returned error
status, use the $DISPLAY_ERROR$ macro.

! Flags
No flag definitions are required to use this callback.

*/
    sbyte4 (*funcPtrBindUDP)(MOC_IP_ADDRESS srcAddress,
                             sbyte *pServerIPAdress,
                             ubyte2 serverPort,
                             void **ppUDPCookie);

/*! Send data.
This callback sends the data to the %server associated with the specified cookie ($pUDPCookie$).

\since 3.06
\version 3.06 and later

||Name||Type||Description
|$pUDPCookie$|$void *$|Cookie containing the desired server's connection information.
|$pData$|$ubyte *$|Pointer to data to send.
|$dataLength$|$ubyte4$|Number of bytes of data to send ($pData$).
|&nbsp;|&nbsp;|&nbsp;
||Return value|$sbyte4$|$OK$ (0) if successful; otherwise a negative number
error code definition from merrors.h. To retrieve a string containing an
English text error identifier corresponding to the function's returned error
status, use the $DISPLAY_ERROR$ macro.

! Flags
No flag definitions are required to use this callback.

*/
    sbyte4 (*funcPtrSendUDP)(void *pUDPCookie,
                             ubyte *pData,
                             ubyte4 dataLength);

/*! Close the server connection and free memory.
This callback closes the connection to the %server associated with the specified
cookie ($pUDPCookie$) and then free any memory allocated for the original bind.
It should be called once for each NTP %server.

\since 3.06
\version 3.06 and later

||Name||Type||Description
|$ppUDPCookie$|$void **$|Pointer to the address of the cookie containing the desired %server's connection information.
|&nbsp;|&nbsp;|&nbsp;
||Return value|$sbyte4$|$OK$ (0) if successful; otherwise a negative number
error code definition from merrors.h. To retrieve a string containing an
English text error identifier corresponding to the function's returned error
status, use the $DISPLAY_ERROR$ macro.

! Flags
No flag definitions are required to use this structure.

*/
    sbyte4 (*funcPtrUnBindUDP)(void **ppUDPCookie);

/*
    sbyte4 (*funcPtrNTPInd)(ubyte *pUserCookie,
                            NTP_RESULT result,
                            NTP_RqstRecord *pRqst);
*/

/*! Alert the user to failed retransmission.
This callback alerts the user to a failed retransmission. Typical usage is to
inform an application that an NTP send request has timed out.

\since 3.06
\version 3.06 and later

||Name||Type||Description
|$\<pUserCookie\>$|$ubyte$|User-specific cookie data; set by calling NTP_setRequestUserCookie.
|$\<result\>$|$NTP_RESULT$|Reason for the failure: one of the $NTP_RESULT$ enumerated values (defined in ntp.h).
|$\<pRqst\>$|$NTP_RqstRecord *$|Pointer to NTP request for which this callback has been invoked.
|&nbsp;|&nbsp;|&nbsp;
||Return value|$sbyte4$|$OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

! Flags
No flag definitions are required to use this callback.

*/
    sbyte4 (*funcPtrNtpInd)(ubyte *pUserCookie,
                               NTP_RESULT result,
                               NTP_RqstRecord *pRqst);

/*! Number of milliseconds the %client waits for a server response before timing out.
(Default = NTP_REQ_TIMEOUT_INTERVAL_MS) Number of milliseconds the %client waits for a server response before timing out.
*/
    ubyte4 ntpReqTimeoutIntervalMS;  /* default NTP_REQ_TIMEOUT_INTERVAL_MS */

/*! Number of servers associated with this NTP %client instance.
Number of servers associated with this NTP %client instance.
*/
    ubyte  numServers; /* Number of servers associated with this instance */

} NTP_Config;

typedef struct NTP_ServerRecord
{
    sbyte*                   pServerName;
    MOC_IP_ADDRESS           srcAddr;
    MOC_IP_ADDRESS           serverAddress;
    sbyte4                   port;
    NTP_Counters             counters;
    sbyte4                   serverStatus;
    const NTP_Config*        cfgPtr;
    sbyte4                   ntpInstanceId;
    void*                    udpCookie;
    ubyte2                   srcPort;
    NTP_RqstRecord           *pRequest;

} NTP_ServerRecord;

typedef struct NTP_Instance
{
    sbyte4           instanceId;
    ubyte4           instRef;
    NTP_Config       config;
    ubyte*           reqTimeout;
    rbtree_t*        serverTree;

} NTP_Instance;


/*------------------------------------------------------------------*/

/* Initializes the NTP internal data structures */
MOC_EXTERN MSTATUS
NTP_init();

/* Creates a new NTP  client Instance as per the configuration set in
 * the CONFIG struct and returns an unique "instanceId" for each instance.
 * Registers the callbacks for send, recv, error indication etc. as
 * defined in the CONFIG structure.  */
MOC_EXTERN MSTATUS
NTP_addInstance(sbyte4 *instanceId, const NTP_Config *config);

/* Adds a NTP server to the instance and returns an unique "retID" for
 * each server. Also does a "connect" of the Client IP/port with
 * Server IP/port */
MOC_EXTERN MSTATUS
NTP_addServer(sbyte4 instanceId, MOC_IP_ADDRESS srcAddr,
                 sbyte *serverIPAddress, sbyte4 port, sbyte4 *retID);


MOC_EXTERN MSTATUS
NTP_releaseServer(sbyte4 serverID);

MOC_EXTERN void
NTP_requestRelease(NTP_RqstRecord *pRqst);

/* Creates a new NTP Client request to be sent to the NTP server
 * specified by "serverID" */
MOC_EXTERN MSTATUS
NTP_requestNew(NTP_RqstRecord **ppRequest, sbyte4 serverID);


/* Sets an application specific "cookie" for each request.
 * This "cookie" is returned as a part of the response for the
 * application to use it as required. */
MOC_EXTERN MSTATUS
NTP_setRequestUserCookie(NTP_RqstRecord *pRequest, void *pCookie);

/* Sends a created NTP request */
MOC_EXTERN MSTATUS
NTP_requestSend(NTP_RqstRecord *pRequest);

MOC_EXTERN MSTATUS
NTP_getInstancePtrFromId(sbyte4 instanceId, NTP_Instance **instPtr);

MOC_EXTERN MSTATUS
NTP_getUDPCookieFromServerID(sbyte4 serverID, void **ppUDPCookie);

MOC_EXTERN MSTATUS
NTP_getServerRecordFromID(sbyte4 serverID, NTP_ServerRecord **ppServer);

MOC_EXTERN MSTATUS
NTP_getServerIDFromAddrPort(sbyte4 instanceId,
                MOC_IP_ADDRESS serverAddress, ubyte2 serverPort,
                MOC_IP_ADDRESS srcAddr, sbyte4 *serverID);


/* Delete an NTP Instance */
MOC_EXTERN MSTATUS
NTP_deleteInstance(sbyte4 instanceId);

/* Shutdown and cleanup NTP instance */
MOC_EXTERN void
NTP_shutdown(void);

/* Validate a NTP Packet for correctness */
MOC_EXTERN MSTATUS
NTP_pktValidate(NtpPacket *pPkt, ubyte4 pktLen);

/* Validates the received NTP packet , processes the packet and
 * depending on the response from the server returns the result. */
MOC_EXTERN MSTATUS
NTP_responseCallback(sbyte4 serverID, ubyte2 srcPort,
                ubyte *pBuffer ,ubyte4 buflen,
                NtpPacket **pRqst, NTP_RESULT* pResult );


/* Returns various timestamps from the successful NTP response.
 * The possible Attributes that can be useful are ORIGINATOR timestamp,
 * SERVER Received timestamp, SERVER Transmit timestamp */

MOC_EXTERN MSTATUS
NTP_getAttribute(NtpPacket *pPkt, NTP_RESP_ATTRIBUTE attr, NtpTime *ntpTime);

/* Periodically tickle the Timer to check if any events are queued */
MOC_EXTERN MSTATUS
NTP_periodic(sbyte4 instanceId);


#ifdef __cplusplus
}
#endif

#endif /* __NTP_H__*/
