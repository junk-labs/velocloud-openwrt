/*
 * radix.h
 *
 * Radix module, with PATRICIA trees implementation
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _RADIX_H_
#define _RADIX_H_

#include "NNstyle.h"
#include "../../utils/queue.h"

typedef struct RADIXNODE
{
  struct RADIXMASK *pxMaskLst;    /* list of masks contained in subtree */
  struct RADIXNODE *pxParent;     /* parent pointer */
  sbyte2     wBitOffset;          /* bit offset */
  sbyte      oBMask;              /* node: mask for bit test */
  ubyte      oNodeFlag;           /* indicates the state of the node: ACTIVE, NORMAL, ROOT */
#define RAD_NORMAL 1
#define RAD_ROOT   2
#define RAD_ACTIVE 4
  union
  {
    struct  /* Node : Leaf, only wBitOffset < 0 */
    {

      ubyte4 dwKey;                   /* object of search */
      ubyte4 dwMask;                  /* netmask, if present */
      struct RADIXNODE *pxDupedKey;   /* duplicate keys, having different masks */
    } RADIXNODE_LEAF;
    struct  /* Node : Node, only wBitOffset >= 0 */
    {
      sbyte4 dwOffset;                 /* where to start comparison */
      struct RADIXNODE *pxLeftNode;    /* Left Node */
      struct RADIXNODE *pxRightNode;   /* Right Node */
    } RADIXNODE_NODE;
  } uNodeType;

  LIST_ENTRY(RADIXNODE) xRadixNodeLink;/* holds all the relevant leafs, except for masks that are leafs */
} RADIXNODE;

/*Hash defines to make life a bit easier*/
#define RadixNodeKey        uNodeType.RADIXNODE_LEAF.dwKey
#define RadixNodeMask       uNodeType.RADIXNODE_LEAF.dwMask
#define RadixNodeDupedKey   uNodeType.RADIXNODE_LEAF.pxDupedKey
#define RadixNodeLeft       uNodeType.RADIXNODE_NODE.pxLeftNode
#define RadixNodeRight      uNodeType.RADIXNODE_NODE.pxRightNode
#define RadixNodeOffset     uNodeType.RADIXNODE_NODE.dwOffset

/*
 * structure pointed to by both top node of the tree and the leaf for the default route.
 * list at the top node of the tree is used for back tracking.
 * list within internal node specifies the masks that apply to subtrees starting at that node.
 * list also appears with the leafs in case of duplicate keys.
 * list : pxMaskLst within RadixNode structure.
 */
typedef struct RADIXMASK
{
  sbyte2 wBitOffset;
  sbyte  oUnUsed;
  ubyte  oNodeFlag;
  struct RADIXMASK *pxMaskLst;
  union
  {
    ubyte4 dwMask;
    struct RADIXNODE *pxLeaf;
  } urm_rmu;
  sbyte4 dwReferences; /* references of this structure.*/
} RADIXMASK;

/*Hash defines to make life easier */
#define RadixMaskLeaf urm_rmu.pxLeaf
#define RadixMaskMask urm_rmu.dwMask

typedef LIST_HEAD(RADIXNODE_LIST, RADIXNODE) RADIXNODE_LIST;

typedef struct RADIXNODEHEAD
{
  struct RADIXNODE *pxTreeTop;  /* always points to the top of the tree, i.e: xNode[1] */
  struct RADIXNODE xNodes[3];   /* top and end nodes, end nodes : 0.0.0.0(left) 255.255.255.255(right) */
  RADIXNODE_LIST xRadixNodeList;/* holds all the leafs present within this data structure
                                   masks that are added as leafs are not pushed in within the list*/
} RADIXNODEHEAD;


/*
 * Initialising the radix tree. Calls RadixInitHead which initialises the xNodes
 * variable. The left and the right nodes are set with 0.0.0.0 & 255.255.255.255
 */
RADIXNODEHEAD* RadixInit(void);

/*
 * Adding a leaf & node within the radix ( provided all the relevant conditions are met )
 * The offset (dwOffset) are calculated which enables the node to directly jump to offset for an ip address.
 * The wBitOffset value is also calculated for determining the bit position to look out for (basically the position
 * at which 1 -> 0), for nodes wBitOffset >= 0, leafs it is < 0.
 * The oBMask value is also calculated which is applied on the appropriate dwOffset position.
 */
RADIXNODE* RadixAddRoute(ubyte4 dwIpAddr,
                         ubyte4 dwNetmask,
                         RADIXNODEHEAD *pxHead,
                         RADIXNODE xTreeNodes[2]);

/*
 * Removes the leaf and the associated node within the tree.
 * If the leaf is a duplicated leaf, it is removed all the duplicated leafs for that node are re-arranged.
 */
RADIXNODE* RadixDelete(ubyte4 dwIpAddress,
                       ubyte4 dwNetmask,
                       RADIXNODEHEAD *pxHead);

/*
 * Looks up at the tree with an given key and mask values.
 */
RADIXNODE* RadixLookUp(ubyte4 dwIpAddr,
                       ubyte4 dwNetmask,
                       RADIXNODEHEAD *pxHead);

/*
 * Prints the entire tree, with the association of a leaf with an node.
 * Should be used for debugging
 */
sbyte2 printRadixTree(RADIXNODEHEAD *pxRadNodeHead);

/*
 * Prints the contents of the RadixNode that is passed.
 * Details of the Node/Leaf is printed.
 * Should be used for debugging
 */
void printRadixElement(RADIXNODE *pxRadixNode);

/*
 * Frees/Flush all the internal nodes and the leafs within the radix tree.
 * Call back method should be registered and is called when the radix tree has done its
 * clean up. User has to basically do it's clean up routines for that node out here.
 */
void FreeRadixTree(RADIXNODEHEAD *pxRadixNodeHead,
                   void (*RadixTreeFreeLeaf)(RADIXNODE **ppxRadixNodeLeaf));

//#endif /* end of __PATRICIA_DS__ */
#endif /* end of _RADIX_H_*/
