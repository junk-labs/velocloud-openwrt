#include <string.h>
#include "mapping.h"

OCTET *
MappingNum2Str(const MAPPING_ENTRY_STRING *pTable, 
               DWORD dwTableSize, 
               LONG lNumber)
{
  void *pTableEnd = (OCTET *) pTable + dwTableSize;

  while ((void*)pTable < pTableEnd) {
    if (pTable->lNumber == lNumber)
      return pTable->pchString;
    pTable++;
  }
  return NULL;
}


LONG
MappingStr2Num(const MAPPING_ENTRY_STRING *pTable,  
               DWORD dwTableSize, 
               CHAR *pcString,
               LONG *plNumber)
{
  void *pTableEnd = (OCTET *) pTable + dwTableSize;
  
  if (pcString && strlen(pcString)) {
    while ((void*)pTable < pTableEnd) {
      if (!strcmp(pTable->pchString, pcString)) {
        *plNumber = pTable->lNumber;
        return 0;
      }
      pTable++;
    }
  }
  return -1;
}


LONG
MappingOct2Oct(const MAPPING_ENTRY_OCTET *pTable, 
               DWORD dwTableSize, 
               OCTET oFrom, OCTET *poTo, BOOL bReverse)
{
  void *pTableEnd = (OCTET *) pTable + dwTableSize;

  if (!bReverse) {
    while ((void*)pTable < pTableEnd) {
      if (pTable->oFrom == oFrom) {
        *poTo = pTable->oTo;
        return 0;
      }
      pTable++;
    }
  } else {
    while ((void*)pTable < pTableEnd) {
      if (pTable->oTo == oFrom) {
        *poTo = pTable->oFrom;
        return 0;
      }
      pTable++;
    }
  }
  return -1;
}     

