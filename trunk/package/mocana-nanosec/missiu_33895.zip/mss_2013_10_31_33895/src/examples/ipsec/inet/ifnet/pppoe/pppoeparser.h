/*
 * pppoeparser.h
 *
 * PPPoE parsing library
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPPOEPARSER_H_
#define _PPPOEPARSER_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/


/*
 * PPPoE codes
 */
#define PPPOECODE_PADI                0x09    /* Discovery        */
#define PPPOECODE_PADO                0x07    /* Offer            */
#define PPPOECODE_PADR                0x19    /* Request          */
#define PPPOECODE_PADS                0x65    /* Confirmation     */
#define PPPOECODE_PADT                0xa7    /* Termination      */
#define PPPOECODE_SESSION             0x00    /* Session          */

/*
 * PPPoE Tag index
 */
#define PPPOETAGIDX_SERVICENAME         0
#define PPPOETAGIDX_ACNAME              1
#define PPPOETAGIDX_HOSTUNIQ            2
#define PPPOETAGIDX_ACCOOKIE            3
#define PPPOETAGIDX_VENDORSPECIFIC      4
#define PPPOETAGIDX_RELAYSESSIONID      5
#define PPPOETAGIDX_SERVICENAMEERROR    6
#define PPPOETAGIDX_ACSYSTEMERROR       7
#define PPPOETAGIDX_GENERICERROR        8

#define PPPOETAGIDX_ENDOFLIST           9
#define PPPOETAGIDX_UNKNOWN             10

#define PPPOETAGIDX_MAX                 11


/*
 * Default ver-tag field
 */
#define PPPOEDEFAULT_VERTYPE      0x11


/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * Header structure
 */
typedef struct {
  OCTET oVersionType;
  OCTET oCode;
  WORD  wSessionId;
  WORD  wLength;
} PPPOEHDR;

/*
 * Tag item
 */
typedef struct {
  OCTET wLength;
  OCTET *poData;
} PPPOETAGITEM;

/*
 * Tag
 */
typedef struct {
  WORD wItemNum;
  PPPOETAGITEM *pxItemList;
} PPPOETAG;

typedef PPPOETAG A_PPPOETAGTABLE [PPPOETAGIDX_MAX];

/*****************************************************************************
 *
 * API function
 *
 *****************************************************************************/

/*
 * PppoEDecode
 *  Decode a PPPoE packet
 *
 *  Args:
 *   poPDU               PPPoE PDU
 *   pxHdr               Header-to be filled in
 *   aTagTable           Tag Table-to be filled in
 *
 *  Return:
 *   >=0 successfull parsing
 *   -1 Parsing error
 *   -PPPOETAGTIDX_XXXERROR if an error tag has been found
 */
LONG PppoEDecode(OCTET *poPDU,PPPOEHDR *pxHdr,A_PPPOETAGTABLE aTagTable);

/*
 * PppoEEncode
 *  Encode a PPPoE PDU
 *
 *  Args:
 *   poPDU              Must point to the begginning of the PDU
 *                      Must be of the right length
 *   pxHdr              PPPoE Hdr. The length field must be correct
 *   aTagTable          Tag Table
 *
 * Return:
 *  >=0
 */
LONG PppoEEncode(OCTET *poPDU,PPPOEHDR *pxHdr,A_PPPOETAGTABLE aTagTable);

/*
 * PppoETagTableMove
 *
 *  Args:
 *   axDst                Destination tag table
 *   axSrc                Source tag table
 *
 *  Return:
 *   0
 */
LONG PppoETagTableMove(A_PPPOETAGTABLE axDst,A_PPPOETAGTABLE axSrc);

/*
 * PppoETagTableClear
 *
 *  Args:
 *   axTable          Table to clear
 *
 *  Return:
 *   0
 */
LONG PppoETagTableClear(A_PPPOETAGTABLE axTable);

/*
 * PppoETagMatch
 *
 *  Args:
 *   axTable          Table to search
 *   oTagIdx          Tag index
 *   pxMatch          tag to match. If the poData is NULL, it is
 *                    not used for the comparison
 *
 *  Return:
 *   1st match index or NETERR_UNKNOWN (no match)
 */
LONG PppoETagTableMatch(A_PPPOETAGTABLE axTable,OCTET oTagIdx,
                        PPPOETAGITEM *pxMatch);

/*
 * PppoETagTablePayloadLength
 *  Calculates the necessary length for all the tags in the table
 *
 *  Args:
 *   axTable                 Table
 *
 *  Return:
 *   payload length
 */
LONG PppoETagTablePayloadLength(A_PPPOETAGTABLE axTable);

/*
 * PppoETagTableDeleteTag
 *  Free ressources of a pppoe tag
 *
 *  Args:
 *   axTable                 Table
 *   oTagIdx                 Tag index
 */
void PppoETagTableDeleteTag(A_PPPOETAGTABLE axTable,OCTET oTagIdx);

/*
 * PppoETagTableDeleteRedundantTags
 *  Remove all but one entry for a particular tag
 *
 *  Args:
 *   axTable                 Table
 *   oTagIdx                 Tag index
 */
void PppoETagTableDeleteRedundantTags(A_PPPOETAGTABLE axTable, OCTET oTagIdx);

#ifndef NDEBUG
void PppoEPrintTagTable(A_PPPOETAGTABLE axTable);
#endif /*#ifndef NDEBUG*/

#endif /* _PPPOEPARSER_H_ */
