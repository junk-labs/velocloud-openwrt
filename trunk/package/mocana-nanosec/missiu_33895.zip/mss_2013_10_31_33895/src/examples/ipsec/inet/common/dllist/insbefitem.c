#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

DLLIST_ITEM *DLLIST_insert_before_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem)
{
  DLLIST_ITEM *tmp2;

  if (dllist->cur == NULL) {
    return DLLIST_prepend_ITEM(dllist, dllitem);
  }
  
  tmp2 = dllist->cur;
  dllist->cur = dllitem;
  
  dllitem->prev = tmp2->prev;
  tmp2->prev = dllitem;
  dllitem->next = tmp2;
  if (dllitem->prev == NULL) {
    dllist->head = dllitem;
  } else {
    dllitem->prev->next = dllitem;
  }
  dllist->count++;
  return(dllitem);
}

