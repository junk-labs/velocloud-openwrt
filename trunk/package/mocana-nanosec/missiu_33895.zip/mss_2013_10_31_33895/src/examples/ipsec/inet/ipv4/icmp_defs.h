/*
 * icmp_defs.h
 *
 * icmp module definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __ICMP_DEFS_H__
#define    __ICMP_DEFS_H__

/*****************************************************************************
 *
 * include
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "icmp_flavor.h"
#include "dllist.h"
#include "../include/in.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "netutils.h"
#include "netnetwork.h"
#include "netsnmp.h"
#include "ecc.h"     /* Checksum16 */
#include "icmp.h"
#include "icmp_dbg.h"
#include "ip.h"
#include "snmp_tcpip_data.h"
#ifdef IPSEC
#include "ipsec.h"
#endif /* IPSEC */

/*****************************************************************************
 *
 * defines
 *
 *****************************************************************************/
#define ICMP_SHORTHEADERLENGTH 4 /*oType + oCode + wChecksum*/
#define ICMP_ECHOREPLY_MAXSIZE 2000
#define ICMP_NULL_PAYLOAD_LENGTH 4
#define ICMP_PAYLOAD_LENGTH 8
/*****************************************************************************
 *
 * structures
 *
 *****************************************************************************/
#ifdef NEW_ICMP_MSG_ADDED
typedef struct
{
  union
  {
    struct
    {
      ubyte4 wOtime;  /*Originiate time stamp*/
      ubyte4 wRxtime; /*Receive time stamp*/
      ubyte4 wTtime;  /*Transmit time stamp*/
    } icmp_ts; /*Time stamps for Time stamp query*/
    struct
    {
      IPHDR xIpHdr;
    } icmp_ip; /*Ip Header present within the Icmp data portion
                 Options are not taken care of over here*/
    ubyte4 wMask; /*For Mask Request and Reply*/
  } u_icmp_data;

} ICMP_DATA;
#endif

/*
 * ICMP instance main structure
 */
typedef struct {

  /*Magic cookie*/
  #ifndef NDEBUG
  DWORD dwMagicCookie;
  #endif

  /*offset and trailer*/
  WORD wOffset;
  WORD wTrailer;

  PFN_NETMALLOC pfnNetMalloc;
  PFN_NETFREE   pfnNetFree;
  PFN_NETCBK pfnNetCbk;

  RTOS_MUTEX pxMutex;

  WORD wDontReplyToPing; /* each bit is an interface */


  /* Lower layer interface */
  PFN_NETWRITE pfnLLWrite;
  H_NETINSTANCE hLLInst;
  H_NETINTERFACE hLLIf;

} ICMP_STATE;



/*****************************************************************************
 *
 * structures
 *
 *****************************************************************************/

/*icmp_utils.h*/
LONG IcmpSendPacket(ICMP_STATE *pxIcmp,
                    OCTET oType,
                    OCTET oCode,
                    ICMPMSGDATA *pxIcmpMsgData);
#ifdef NEW_ICMP_MSG_ADDED
/*icmp_errors.c*/
void
reportIcmpErrorsToUL(ubyte oErrNo,
                     NETPACKET *pxNetPacket,
                     NETPACKETACCESS *pxNetPacketAccess,
                     sbyte oSkip);

void
handleIcmpRedirectErrors(ICMPCBKDATA *pxIcmpCbkData);
#endif

#ifdef _RADIX_ROUTING_ON_
void
handleIcmpInstanceMsgToUL(ubyte oErrNo,
                          ICMPMSGDATA *pxIcmpMsgData);
#endif

#endif  /* __ICMP_DEFS_H__ */
