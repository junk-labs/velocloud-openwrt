/*
 * NetFree.c
 *
 * Implements NetFree function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "netutils.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * NetFree
 *  Network Free function
 *  Encapsulates the stdlib free
 *
 *  Args:
 *   px                   pointer to free
 *
 *  Return:
 */
void NetFree(void *px)
{
#ifdef __INET_USE_PAYLOAD_MEMPOOL__
  if(px)
    NetFreePayload(px);
#else
  if(px)
   FREE(px);
#endif
}
