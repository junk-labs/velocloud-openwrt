/*
 * ipfrag_defs.h
 *
 * IP fragmentation module common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __IPFRAG_DEFS_H__
#define __IPFRAG_DEFS_H__

/*****************************************************************************
 *
 * include
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "dllist.h"
#include "ipfrag_flavor.h"
#include "netutils.h"
#include "nettime.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netnetwork.h"
#include "ipfrag.h"
#include "ipfrag_dbg.h"
#include "netsnmp.h"
#include "ip.h"
#include "ecc.h"
#include "../include/in.h"
#include "../include/socket.h"
#include "../include/socket.h"
#include "snmp_tcpip_data.h"
#include "icmp.h"
#include "iptable.h"

/*****************************************************************************
 *
 * define
 *
 *****************************************************************************/

#define MAX_LEG (8+IFNUMMAX)  /*Maximum number of legs : 8 wan legs and IFNUMMAX lan leg*/

/*
 * IP fragmentation option default values
 *  See option type definition for details
 */
#define IPFRAG_DEFAULT_MDS               8192   /* Maximum IP payload size */
#define IPFRAG_DEFAULT_TO                1500   /* Reassembly Time out in ms */


/*
 * Memory management constants
 */
#define IPFRAG_MAX_NUM_DGRAMS     64      /* Maximum number of pending IP dgrams */
#define IPFRAG_MAX_NUM_PACKETS    18      /* Maximum number of packets per IP dgrams, 8192/512 */
#define IPFRAG_IPSIZEMAX   1500   /* Maximum size of the reassembled IP datagram */


/*****************************************************************************
 *
 * Structures & Typedefs
 *
 *****************************************************************************/
/*
 * IP fragmentation instance structure
 */
typedef struct {
  /* Basic structure override protection */
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif
  /* generic options */
  PFN_NETMALLOC pfnNetMalloc;
  PFN_NETFREE   pfnNetFree;
  PFN_NETCBK pfnNetCbk;
  RTOS_MUTEX pxMutex;
  WORD wOffset;
  WORD wTrailer;

  /* specific option*/
  WORD wMD;        /* Maximum Datagram Size */
  DWORD dwTO;      /* Reassembly Time out   */

  WORD wDatagramId;           /* Datagram Id*/

  DLLIST dllPending;  /* Pending Datagram structure */

  /* UL stuff */
  OCTET oULNumberIf;
  H_NETINSTANCE hULInst;
  H_NETINTERFACE hULIf;
  PFN_NETRXCBK pfnRxCbk;

  /* LL stuff */
  OCTET oLLNumberIf;
  H_NETINSTANCE hLLInst;
  PFN_NETWRITE  pfnLLWrite;
  H_NETINTERFACE hLLIf;

  WORD awMtu[MAX_LEG];
#ifdef __IPFRAG_USE_MEMPOOL__
  poolHeaderDescr fragDatagramPool; /*Pool for holding all the Fragmented Datagrams*/
  poolHeaderDescr fragPacketPool;   /*Pool for holding all the fragmented packet within a datagram */
#endif
} IPFRAGSTATE;

/*
 * FRAG_PACKET structure.
 *  Incoming packets are store in such structure.
 */
typedef struct {
  NETPAYLOAD *pxNetPayload;
  WORD wFragOffset; /* Fragment offset, data will be copied to this offset, in byte */
  WORD wFragLength; /* Fragment length, in byte */
  WORD wOffset;     /* Original fragment payload Offset, data will be copied from this offset, in byte*/
#ifdef __IPFRAG_USE_MEMPOOL__
  IPFRAGSTATE *pxIpFragState;
#endif
} FRAG_PACKET;

/*
 * FRAG_DATAGRAM
 *  Datagram reassembly structure
 */
typedef struct {
  H_NETINTERFACE hLLIf;  /* Handle on which the datagram is received */
  DWORD dwDstIP;         /* Destination Id */
  DWORD dwSrcIP;         /* Destination Id */
  WORD wAccLength;       /* Length accumulated so far */
  WORD wDgramLength;     /*Datagram Length */
  NETPACKET xNetPacket;  /*copy of the first NETPACKET*/
  NETWORKID xNetworkId;  /*copy of the first NETWORKID*/
  DWORD dwTimer;         /* Time since last received packet */
  DLLIST dllPacket;      /* List of packets received */
  WORD wId;              /* Identification in Ip Header */
  OCTET oProtId;         /* Protocol Id in Ip Header */
#ifdef __IPFRAG_USE_MEMPOOL__
  IPFRAGSTATE *pxIpFragState;
#endif
} FRAG_DATAGRAM;

/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/

/*
 * IpFragFreeDgram
 *  Free a Datagram structure memory
 *
 *  Args:
 *   px                   pointer to the datagram structure
 *
 *  Return;
 */
void IpFragFreeDgram(void *px);

#endif /* #ifndef __IPFRAG_DEFS_H__ */
