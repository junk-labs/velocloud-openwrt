/*
 * if.h
 *
 * public if definitions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _MOC_NET_IF_H_
#define _MOC_NET_IF_H_

/*
 * Interface flags
 */
#define IFF_DOWN             0x0     /* Link is down */
#define IFF_UP               0x1     /* Link is up */
#define IFF_IPUP             0x2     /* IP is up */
#define IFF_PP               0x4     /* Point to Point */
#define IFF_DYNAMIC          0x8     /* Dynamic address */
#define IFF_PHYUP            0x10    /* Phy is Up */
#define IFF_CLOSED_BY_PEER   0x20    /* The If has been closed by the peer*/
#define IFF_PP_IPCP_FAIL     0x40    /* The If negotiation has had a failure */
#ifdef LINK_AGGREGATION
#define IFF_LOGICAL          0x8000  /* interface is logical */
#endif

#ifdef LINK_AGGREGATION
 #define NETIF_SETFLAG(wFlags,wValue)   ((wFlags) |= (WORD)(wValue))
 #define NETIF_UNSETFLAG(wFlags,wValue) ((wFlags) &= (WORD)~(wValue))
#else
 #define NETIF_SETFLAG(oFlags,oValue)   ((oFlags) |= (OCTET)(oValue))
 #define NETIF_UNSETFLAG(oFlags,oValue) ((oFlags) &= (OCTET)~(oValue))
#endif

/*
 * DHCP client error codes
 */
#define IF_DHCP_TIMEOUT        0x1   /* Timeout during DISCOVER */
#define IF_DHCP_LEASE_EXPIRED  0x2   /* Lease has expired */
#define IF_DHCP_NACK           0x3   /* We received a NACK */
#ifdef DHCP_CUSTOM_OPTIONS
#define IF_DHCP_OPT_CHK_COMPLETE 0x4   /* Finished checking for custom options
                                        * Not an error but makes use of error
                                        * callback
                                        */
#endif /*DHCP_CUSTOM_OPTIONS  */

/*
 * Ethernet Bridge interface status
 */
typedef enum {
  BRIF_DISABLED = 0,
  BRIF_LISTENING,
  BRIF_LEARNING,
  BRIF_FORWARDING,
  BRIF_BLOCKING
} E_ETHBRIFSTAT;


/*
 * ATM interface encapsulation mode
 */
#define IF_ATM_MODE_LLCSNAP         0x0
#define IF_ATM_MODE_VCMUX           0x1


/*
 * ATM interface latency mode
 */
#define IF_ATM_LATENCY_FAST         0x0
#define IF_ATM_LATENCY_INTERLEAVED  0x1

#define    IFNAMSIZ    25
#define    IF_NAMESIZE    IFNAMSIZ

/*
 * Interface request structure used for socket
 * ioctl's.  All interface ioctl's must have parameter
 * definitions which begin with ifr_name.  The
 * remainder may be interface specific.
 */
struct    ifreq {
  char ifr_name[IFNAMSIZ];        /* if name, e.g. "en0" */
  union {
    struct sockaddr ifru_addr;
    struct sockaddr ifru_dstaddr;
    struct sockaddr ifru_broadaddr;
    int ifru_mtu;
    int ifru_flags;
    sbyte *    ifru_data;
    int ifru_type;
    int ifru_tos;
    int ifru_value;
  } ifr_ifru;
#define    ifr_addr    ifr_ifru.ifru_addr    /* address */
#define    ifr_dstaddr    ifr_ifru.ifru_dstaddr    /* other end of p-to-p link */
#define    ifr_broadaddr    ifr_ifru.ifru_broadaddr    /* broadcast address */
#define    ifr_metric    ifr_ifru.ifru_metric    /* metric */
#define    ifr_mtu        ifr_ifru.ifru_mtu    /* mtu */
#define ifr_flags       ifr_ifru.ifru_flags     /* flags (status ) */
#define ifr_phys    ifr_ifru.ifru_phys    /* physical wire */
#define ifr_media    ifr_ifru.ifru_media    /* physical media */
#define    ifr_data    ifr_ifru.ifru_data    /* for use by interface */
#define ifr_type        ifr_ifru.ifru_type    /* interface type */
#define ifr_array       ifr_ifru.ifru_array     /* char array */
#define ifr_tos         ifr_ifru.ifru_tos       /* tos value */
#define ifr_value       ifr_ifru.ifru_value     /* generic value */
};

#define    _SIZEOF_ADDR_IFREQ(ifr) \
    ((ifr).ifr_addr.sa_len > sizeof(struct sockaddr) ? \
     (sizeof(struct ifreq) - sizeof(struct sockaddr) + \
      (ifr).ifr_addr.sa_len) : sizeof(struct ifreq))

/*
 * Structure used in SIOCGIFCONF request.
 * Used to retrieve interface configuration
 * for machine (useful for programs which
 * must know all networks accessible).
 */
struct    ifconf {
    int    ifc_len;        /* size of associated buffer */
    union {
        sbyte *    ifcu_buf;
        struct    ifreq *ifcu_req;
    } ifc_ifcu;
#define    ifc_buf    ifc_ifcu.ifcu_buf    /* buffer address */
#define    ifc_req    ifc_ifcu.ifcu_req    /* array of structures returned */
};

/*
 * Interface and dhcp timeout call back functions.
 */
typedef void (*NETIF_CBK)(OCTET);
typedef void (*NETIF_DHCPERROR_CBK)(OCTET, OCTET);
typedef void (*NETIF_LINKSTATUS_CBK)(OCTET, BOOL);

#endif
