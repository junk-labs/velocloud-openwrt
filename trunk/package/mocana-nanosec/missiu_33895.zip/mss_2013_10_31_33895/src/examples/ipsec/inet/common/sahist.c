/*
 * sahist.c
 *
 * implement Self-Adjusting Histograms
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

#include "NNstyle.h"
#include "sahist.h"


/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

#define SAHIST_DW_WRAP    0xFFFF0000


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Typedefs
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Global Variables
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Static Variables
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Static Function Declarations
 *
 ********************************************************************/

static void SaHist8Collapse(SA_HIST8 *pHist8);


/********************************************************************
 *
 * Static Functions
 *
 ********************************************************************/

/*
 * SaHist8Collapse
 *     collapses the sahist by merging bucket contents and
 *    expanding the range
 *
 * Arguments:
 *      pHist8        the 8 bucket histogram to collapse
 * Returns:
 *      none
 */
static void SaHist8Collapse(SA_HIST8 *pHist8)
{
  register SA_HIST8 *pHist = pHist8;
  register int i;
  register DWORD dw1, dw2, dw3;

  /* each bucket in the 1st half of buckets gets the sum of 2 buckets */
  for (i = 0; i < 4; i++) {
    dw1 = pHist->adwBkt[2 * i];
    dw2 = pHist->adwBkt[1 + 2 * i];
    dw3 = dw1 + dw2;

    /* if the sum did not wrap then save it, otherwise save wrap value */
    if ((dw3 >= dw1) && (dw3 >= dw2))
      pHist->adwBkt[i] = dw3;
    else
      pHist->adwBkt[i] = SAHIST_DW_WRAP;
  }

  /* each bucket in the 2nd half of buckets gets 0 */
  for (; i < 8; i++) {
    pHist->adwBkt[i] = 0;
  }

  /* now increment the shift in order to double the range for a bucket */
  pHist->wRangeShift++;
  pHist->dwLimit *= 2;
}



/********************************************************************
 *
 * Public Functions
 *
 ********************************************************************/

/*
 * SaHist8
 *     account for another value in the histogram
 *
 * Arguments:
 *      pHist8        the 8 bucket histogram
 *      dwValue        the value to account for
 * Returns:
 *      none
 */
void SaHist8(SA_HIST8 *pHist8, DWORD dwValue)
{
  register SA_HIST8 *pHist = pHist8;
  register DWORD dwCnt, dwIndex;

  /* initialize the histogram if necessary */
  if ((pHist->dwLimit == 0) && (pHist->wRangeShift == 0)) {
    pHist->dwLimit = 8;
  }

  /* as long as the new value is beyond the limit,    */
  /*  collapse the buckets and expand the limit        */
  while (dwValue >= pHist->dwLimit) {

    /* a zero limit (after init) means that the range is maximized */
    if (0 == pHist->dwLimit) {
      break;
    }

    /* otherwise, collapse the histogram to double its range */
    SaHist8Collapse(pHist);

  }

  /* account for the new value */
  dwIndex = dwValue >> pHist->wRangeShift;
  ASSERT(8 > dwIndex);
  dwCnt = 1 + pHist->adwBkt[dwIndex];
  if (0 == dwCnt)
    dwCnt = SAHIST_DW_WRAP;
  pHist->adwBkt[dwIndex] = dwCnt;
}



/*
 * SaHist8Clear
 *     clear the histogram
 *
 * Arguments:
 *      pHist8        the 8 bucket histogram
 * Returns:
 *      none
 */
void SaHist8Clear(SA_HIST8 *pHist8)
{
  register SA_HIST8 *pHist = pHist8;
  register DWORD dwIndex;

  pHist->dwLimit = 8;
  pHist->wRangeShift = 0;
  for (dwIndex = 0; dwIndex < 8; dwIndex++)
    pHist->adwBkt[dwIndex] = 0;
}




