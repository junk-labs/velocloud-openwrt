/*
 * srvquery.c
 *
 * DSN service query functions of Domain Name Server client
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "NNstyle.h"
#include "dns_flavor.h"
#include <sys/ioctl.h>
#include "sys/socket_inet.h"
#include <sys/socket.h> /* sockaddr */
#include "netinet/in.h" /* sockaddr_in */
#include "nettime.h"
#include <sys/select.h> /* FD_xxx */
#include <sys/sockio.h>
#include <net/if.h>
#include <arpa/inet.h>
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdb.h"
#include "sockapi.h"
#include "dnsdbg.h"
#include "dnsapi.h"
#include "dns.h"


/****************************************************************************
 *
 * Global variables
 *
 ****************************************************************************/
pthread_mutex_t xDnsServiceMutex  = PTHREAD_MUTEX_INITIALIZER;

/*
 * DnsGetItByName
 *  Clear hostlist for DNS running on current process.
 *
 *  Args:
 *   wType                  ???
 *   szServiceName
 *   pxQuerySet
 *   iLen
 *
 *  Return:
 *   Ptr to host entry pxHostEnt passed in as 1st argument
 */
int
DnsGetItByName(WORD          wType,
               const char    *szServiceName,
               DNS_QUERY_SET *pxQuerySet,
               int           iLen)
{
  OCTET *poTmpRes;
  int   i;

  if (NETERR_NOERR != DnsWaitForInit()) {
    mn_errno = EDNSSERVERNOTSET;
    DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "Failed mn_errno = %d\n", mn_errno);
    return NETERR_UNKNOWN;
  }

  poTmpRes=MALLOC(SRVNAME_SIZE);
  ASSERT(poTmpRes);
  MOC_MEMSET((ubyte *)poTmpRes, 0, sizeof(SRVNAME_SIZE));

  for (i=0; i<xDNSState.oDnsNum; i++) {
    if (wType == DNSTXT) {
      /* Just lookup the domain name for the TXT Query */
      strcpy(poTmpRes, xDNSState.pxDnsControl[i].szDomainName);
      pxQuerySet->pxHostEnt = DnsGetHostByEither(xDNSState.pxDnsControl + i,
                         poTmpRes, DNS_LOOKUP_TXT);
    } else {
      ASSERT(strlen(szServiceName) +
             strlen(xDNSState.pxDnsControl[i].szDomainName) + 2 <
             SRVNAME_SIZE);
      strcpy(poTmpRes, szServiceName);
      strcat(poTmpRes, ".");
      strcat(poTmpRes, xDNSState.pxDnsControl[i].szDomainName);
      pxQuerySet->pxHostEnt = DnsGetHostByEither(xDNSState.pxDnsControl + i,
                         poTmpRes, DNS_LOOKUP_SRV);
    }
    if (pxQuerySet->pxHostEnt != NULL) {
      break;
    }
    MOC_MEMSET((ubyte *)poTmpRes, 0x00, SRVNAME_SIZE);
  }

  FREE(poTmpRes);
  if (pxQuerySet->pxHostEnt == NULL) {
    return NETERR_UNKNOWN;
  }

  return NETERR_NOERR;
}


/*
 * DnsOpenQuery
 *  Open up a DNS query
 *
 *  Args:
 *   service_name               pointer to name to resolve
 *   wType                      query type (SRV,TXT)
 *   pwCount                    Number of valid returned record
 *
 * Return value:
 *   OCTET *                    Query handle
 */
OCTET *DnsOpenQuery(const OCTET* service_name, WORD wType, WORD *pwCount)
{
  DNS_QUERY_SET *pxQuerySet;    /*Holds info about current Service requested. */
  INT i;
  INT bval=0;
  OCTET *poTmp, *poTmpRes, *poTmpAli;

  if (NETERR_NOERR != DnsWaitForInit()) {
    return NULL;
  }

  RTOS_mutexWait((RTOS_MUTEX)&(xDnsServiceMutex));
  poTmp = MALLOC(248);  /*tmp buffer */
  ASSERT(poTmp);
  MOC_MEMSET((ubyte *)poTmp, 0, 248);
  pxQuerySet = (DNS_QUERY_SET *)MALLOC(sizeof(DNS_QUERY_SET));
  ASSERT(pxQuerySet);
  MOC_MEMSET((ubyte *)pxQuerySet, 0, sizeof(DNS_QUERY_SET));
  strncpy(pxQuerySet->szService, service_name, sizeof(pxQuerySet->szService));
  DNS_SET_COOKIE(pxQuerySet);
  pxQuerySet->wType = wType;

  *pwCount=0;

  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsOpenQuery pxQuerySet->szService: %s %p \n",
       pxQuerySet->szService, pxQuerySet);

  bval = DnsGetItByName(wType, service_name, pxQuerySet, 248);


  if (bval == FAIL) {
    FREE(poTmp);
    FREE(pxQuerySet);
    DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsOpenQuery  %d szHostName  %s  \n" , wType, service_name);
    RTOS_mutexRelease((RTOS_MUTEX)&(xDnsServiceMutex));
    return ((void *)NULL);
  }


  /* Search through Records to find Records of Matching Service required. */
  i=0;  bval=0;
  poTmpAli = pxQuerySet->pxHostEnt->h_name;
  while (poTmpAli) {

    if (wType==DNSSRV) {
      pxQuerySet->oListRecs[i+1]=1;
      bval++;
    }

    if (wType == DNSTXT) {
      DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsOpenQuery valid bval %d\n", bval);
      strcpy(poTmp, poTmpAli);
      DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsOpenQuery 3 TXT sname ::%s::%s:: \n", poTmp, service_name);
      poTmpRes = strchr(poTmp, ' ');
      if (poTmpRes) {
    *poTmpRes=0;
      }
      if(!MOC_STRCMP((sbyte *)poTmp,(sbyte *)service_name)) {
        DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsOpenQuery 4 TXT sname ::%s::%s:: i=%d \n",
                 poTmp, service_name, i);
        pxQuerySet->oListRecs[i+1]=1;             /*oListRecs[0] holds number of valid records */
        bval++;
      }
    }

    if (i>MAX_RECORDS) {
      /*Safety Net no more than Max records allowed   */
      break;
    }
    poTmpAli = pxQuerySet->pxHostEnt->h_aliases[i];
    i++;
  }
  /*oListRecs[0] holds number of valid records */
  pxQuerySet->oListRecs[0] = (OCTET)bval;

  DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsOpenQuery bval %d lisy0_0x%x i=%d\n",
           bval, pxQuerySet->oListRecs[0], i);
  DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsOpenQuery TXT szHostName %s\n",
           pxQuerySet->pxHostEnt->h_name);

  FREE(poTmp);
  DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsOpenQuery bval %d\n", bval);
  *pwCount=bval; /*Number of valid returned records */
  RTOS_mutexRelease((RTOS_MUTEX)&(xDnsServiceMutex));
  return (OCTET *)pxQuerySet;
}


/*
 * DnsReadQuery
 *  Read up a DNS query (must be opened)
 *
 *  Args:
 *   hporesult                  Query handle
 *   pxDnsRec                   Records to be filled up
 *   wCount                     Number of records to read
 *
 * Return value:
 */
void
DnsReadQuery(OCTET          *hporesult,
             DNS_SRV_RECORD *pxDnsDisc,
             WORD           wCount)
{
  DNS_SRV         *pxSrvReply;
  DNS_QUERY_SET   *pxQuerySet;
  DNS_SRV_RECORD  *pxDnsDiscOrig;
  char            *pcTmpRes, *pcString, *pcTmpAli;
  INT             i=0, iCnt=(INT)wCount;

  if (!hporesult) {
    return;
  }

  if (NETERR_NOERR != DnsWaitForInit()) {
    mn_errno = EDNSSERVERNOTSET;
    DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsWaitForInit() failed mn_errno = %d\n", mn_errno);
    return ;
  }

  RTOS_mutexWait((RTOS_MUTEX)&(xDnsServiceMutex));
  pxDnsDiscOrig = pxDnsDisc; /* Keep a copy of ptr. */
  pxQuerySet = (DNS_QUERY_SET *)hporesult;
  ASSERT(pxQuerySet);   /* Holds info about current Service requested. */
  ASSERT(pxDnsDisc);  /* User supplied buffer. */
  DNS_CHECK_STATE(pxQuerySet);
  /*empty struct */
  MOC_MEMSET((ubyte *)pxDnsDisc, 0, wCount*sizeof(DNS_SRV_RECORD));
  DNS_DBG(DNS_DBGLVL_ERROR_RARE, pcString=NULL);
  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "Ptr pxDnsDisc %p list0x%x \n" , pxDnsDisc,
           pxQuerySet->oListRecs[0]);
  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "+++-----Ptr %p \n" , pxDnsDisc);
  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "+++---- List %x %x \n", pxQuerySet->oListRecs[i],
           pxQuerySet->oListRecs[i+1]);

  pcTmpAli = pxQuerySet->pxHostEnt->h_name;
  while (pcTmpAli) {
    DNS_DBGP(DNS_DBGLVL_REPETITIVE, "+++ i== %d \n" ,i);
    if (pxQuerySet->oListRecs[i+1]==1) {
      if (--iCnt<0) {
    break;
      }
      if (pxQuerySet->wType==DNSSRV){
        ASSERT(pcTmpAli);
        pxSrvReply = (DNS_SRV *)(pcTmpAli);
        pxDnsDisc->wPriority = pxSrvReply->wPriority;
        pxDnsDisc->wWeight   = pxSrvReply->wWeight;
        pxDnsDisc->nPort     = pxSrvReply->wPort;
        pxDnsDisc->wType     = pxQuerySet->wType;

        pcString = (OCTET *)(pcTmpAli)+sizeof(DNS_SRV); /*point to Domain name */
        ASSERT(strlen(pcString) < 248 );
        if (pcString != NULL){
          strcpy(pxDnsDisc->szServStringID, pcString);
        }
        DNS_DBGP(DNS_DBGLVL_REPETITIVE,"DnsReadQuery SRV szServStringID %s\n", pcString);
        DNS_DBGP(DNS_DBGLVL_REPETITIVE,"DnsReadQuery SRV  %hu\n", pxSrvReply->wPriority);
        DNS_DBGP(DNS_DBGLVL_REPETITIVE,"DnsReadQuery SRV  %hu\n", pxSrvReply->wPort);
      }

      if (pxQuerySet->wType == DNSTXT) {
        ASSERT(pcTmpAli);
        pcString = strdup( (OCTET *)(pcTmpAli) ); /*points to string in result */
        ASSERT(strlen(pcString) < 248 );
        pxDnsDisc->wType  = pxQuerySet->wType;
        /*find first ":" after Service */
        pcTmpRes = strchr(pcString, ':');
        if (pcTmpRes != NULL) {
          pcTmpRes = strchr(pcTmpRes, ' ');
          if (pcTmpRes != NULL) {
            sscanf(pcTmpRes, "%hu", (WORD *)(&pxDnsDisc->wPriority));
            *pcTmpRes = '\0'; /*Cut string after ":port" number  */
            DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsReadQuery Pri ::%u::\n",
                     pxDnsDisc->wPriority);
          }
        }

        /*find first space after Service */
        pcTmpRes = strchr(pcString, ' ');
        if (pcTmpRes != NULL) {
          strcpy(pxDnsDisc->szServStringID , pcTmpRes+1 );
          DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsReadQuery z::%s::%s::%s::  \n",
           pcString, pcTmpRes, pxQuerySet->pxHostEnt->h_name);
        }
        FREE(pcString);
      }
      /*pxDnsDisc = (pxDnsDisc+1); */
      pxDnsDisc++;
    } /*if Valid list */
    pcTmpAli = pxQuerySet->pxHostEnt->h_aliases[i];
    i++;
  } /*while */

  DNS_CHECK_STATE(pxQuerySet);
  RTOS_mutexRelease((RTOS_MUTEX)&(xDnsServiceMutex));
}


/*
 * DnsCloseQuery
 *  Close a DNS query
 *
 *  Args:
 *   hporesult                  Query handle
 *
 *  Return:
 */
void DnsCloseQuery(OCTET* hporesult)
{
  DNS_QUERY_SET *pxQuerySet;

  if (!hporesult) {
    return;
  }
  RTOS_mutexWait((RTOS_MUTEX)&(xDnsServiceMutex));
  pxQuerySet = (DNS_QUERY_SET *)hporesult;
  DNS_CHECK_STATE(pxQuerySet);
  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsCloseQuery: %p\n", hporesult);
  FREE(hporesult);
  RTOS_mutexRelease((RTOS_MUTEX)&(xDnsServiceMutex));
}

