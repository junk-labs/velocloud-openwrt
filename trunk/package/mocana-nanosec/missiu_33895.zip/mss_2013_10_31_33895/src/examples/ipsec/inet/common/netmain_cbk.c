/*
 * netmain_cbk.c
 *
 * Network Wrapper Callback
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include <mqueue.h>
#include "netdb.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/if_types.h"

#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "nettime.h"
#include "iptable.h"
#include "netconfig.h"
#include "sockapi.h"
#include "nettransport.h"
#include "tcp.h"
#include "udp.h"
#include "netnetwork.h"
#include "ip.h"
#include "ip2eth.h"
#include "ethernet.h"
#include "arp.h"
#include "icmp.h"
#include "igmp.h"
#include "ip1ton.h"
#include "netmain.h"
#include "linkconf.h"
#include "netif.h"
#include "snmp_tcpip_data.h"
#include "routing_table.h"
#include "dnsapi.h"
#include "ping.h"

#ifdef ROUTER
  #include "router.h"
#endif /*#ifdef ROUTER*/
#ifdef NAT
  #include "nat.h"
#endif /*#ifdef NAT*/
#ifdef IPFRAG
#include "ipfrag.h"
#endif /*#ifdef IPFRAG*/
#ifdef AAL5
  #include "aal5devapi.h"
#endif /*#ifdef AAL5*/
#ifdef IPSEC
#include "ipsec.h"
#endif /*#ifdef IPSEC*/

/****************************************************************************
 *
 * Callback function
 *
 ****************************************************************************/
/*
 * NetAdminCommonCbk
 *  Network wrapper general Callback. Does nothing at this
 *  stage. Follows PFN_NETCBK type
 */
LONG NetAdminCommonCbk(H_NETINSTANCE hInst,OCTET oCbk,
                       H_NETDATA hData)
{
  NETMAIN_ASSERT(oCbk < NETCBK_MODULESPECIFICBEGIN);
  /* !!! SB Sep 2001 Do nothing for now !!!*/

  return 0;
}

/*
 * NetAdminArpCbk
 *  Network wrapper Arp Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminArpCbk(H_NETINSTANCE hInst,
                    OCTET oCbk,
                    H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;
  OCTET oIfIdx = (int)hInst;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  NETMAIN_ASSERT(oIfIdx < pxNetWrapper->oIfNumber);

  pxIfConf     = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState    = NETGETIFSTATE(pxIfConf);

  NETMAIN_ASSERT(hData != 0);

  if (oCbk < NETCBK_MODULESPECIFICBEGIN) {
    NetAdminCommonCbk(hInst,oCbk,hData);
  }
  else {
    ARPREQUEST *pxArpRequest = (ARPREQUEST *)hData;
    H_NETINSTANCE hIp2Eth;

    NETMAIN_ASSERT(pxArpRequest != NULL);

    hIp2Eth = NETGETINST_IP2ETH;

    switch(oCbk) {
    case ARPCBK_RESOLVED:
      Ip2EthInstanceMsg(hIp2Eth,IP2ETHMSG_ARPRESOLVED,(H_NETDATA)pxArpRequest);
      break;

    case ARPCBK_FAILURE:
      Ip2EthInstanceMsg(hIp2Eth,IP2ETHMSG_ARPFAILED,(H_NETDATA)pxArpRequest);
      break;

    default:
      NETMAIN_ASSERT(0);
    }
  }

  return 0;
}

/*
 * NetAdminUdpCbk
 *  Network wrapper UDP Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminUdpCbk(H_NETINSTANCE hInst,
                    OCTET oCbk,
                    H_NETDATA hData)
{
  NETMAIN_ASSERT(hData != 0);

  if (oCbk < NETCBK_MODULESPECIFICBEGIN) {
    NetAdminCommonCbk(hInst,oCbk,hData);
  }
  else {

    switch(oCbk){
    case UDPCBK_DSTUNREACHABLE:
      {
        ICMPMSGDATA xIcmpMsgData;
        UDPCBKDATA *pxUdpData = (UDPCBKDATA *)hData;
        H_NETINSTANCE hIcmpInst;

        xIcmpMsgData.pxNetPacket = pxUdpData->pxNetPacket;
        xIcmpMsgData.pxNetPacketAccess = pxUdpData->pxNetPacketAccess;
        xIcmpMsgData.dwSrcAddr = pxUdpData->xId.xNetId.dwDstIpAddr;
        xIcmpMsgData.dwDstAddr = pxUdpData->xId.xNetId.dwSrcIpAddr;
        xIcmpMsgData.wVlan = pxUdpData->xId.xNetId.wVlan;
        xIcmpMsgData.oIfIdx = pxUdpData->xId.xNetId.oIfIdx;

        hIcmpInst = NETGETINST_ICMP;

        IcmpInstanceMsg(hIcmpInst,
                        ICMPMSG_SENDPORTUNREACH,
                        (H_NETDATA)(&xIcmpMsgData));

      }
      break;
    default:
      NETMAIN_ASSERT(0);
    }
  }

  return NETERR_NOERR;
}


/*
 * NetAdminIcmpCbk
 *  Network wrapper UDP Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminIcmpCbk(H_NETINSTANCE hInst,
                      OCTET oCbk,
                      H_NETDATA hData)
{
  NETMAIN_ASSERT(hData != 0);

  if (oCbk < NETCBK_MODULESPECIFICBEGIN) {
    NetAdminCommonCbk(hInst,oCbk,hData);
  }
  else {
    ICMPCBKDATA *pxData = (ICMPCBKDATA *)hData;
#ifdef NEW_ICMP_MSG_ADDED
    ubyte oCode;
    ubyte oErrNo;
    sbyte oSkip = 0;

    oCode = pxData->pxIcmpHdr->oCode;
#endif

    NETMAIN_ASSERT(pxData != NULL);

    switch(oCbk) {
    case ICMPCBK_ECHOREPLY:
      {
        int i;

        for (i=0;i<NETPINGTABLE_SIZE;i++) {
          if (adwPingReplyIpAddrTable[i] ==
              pxData->pxNetworkId->dwSrcAddr) {
            /* Address already in the table, no need to add it
               again */
            break;
          }
        }

        if (NETPINGTABLE_SIZE == i) {
          for (i=0;i<NETPINGTABLE_SIZE;i++) {
            if (adwPingReplyIpAddrTable[i] == 0) {
              /* Empty entry: use it and break */
              adwPingReplyIpAddrTable[i] =
                pxData->pxNetworkId->dwSrcAddr;
              break;
            }
          }
        }
      }
      break;

    case ICMPCBK_DESTUNREACHABLE:
      {
#ifdef NEW_ICMP_MSG_ADDED
        ubyte oSendMsgToUl = 1;
        switch(oCode)
        {
          case ICMP_NET_UNREACH : oErrNo = ICMPERR_UNREACH_NET;      break;
          case ICMP_HOST_UNREACH: oErrNo = ICMPERR_UNREACH_HOST;     break;
          case ICMP_PROT_UNREACH: oErrNo = ICMPERR_UNREACH_PROTOCOL; break;
          case ICMP_PORT_UNREACH: oErrNo = ICMPERR_UNREACH_PORT;     break;
          case ICMP_FRAG_NEEDED : oErrNo = ICMPERR_MSGSIZE;          break;
          case ICMP_NET_UNKNOWN : oErrNo = ICMPERR_UNREACH_NET;      break;
          case ICMP_HOST_UNKNOWN: oErrNo = ICMPERR_UNREACH_HOST;     break;
          default:
            /*Code is unsupported, or it is a bad code.*/
            oSendMsgToUl = 0;
        }
        if(oSendMsgToUl)
           reportIcmpErrorsToUL(oErrNo, pxData->pxNetPacket, pxData->pxNetPacketAccess, oSkip);
#endif
        break;
      }

#ifdef ICMP_NEW_MSG_ADDED
    case ICMPCBK_TIME_EXCEEDED :
      {
        if (oCode < 1)
        {
          /*Set the "Error Code" for future references*/
          oErrNo = ICMPERR_TIMEXCEEDED;
          reportIcmpErrorsToUL(oErrNo, pxData->pxNetPacket, pxData->pxNetPacketAccess, oSkip);
        }
        else
          NETMAIN_ASSERT(0);
        break;
      }
    case ICMPCBK_PARAMETER_PROBLEM :
      {
        if(oCode < 1)
        {
          /*Set the "Error Code" for future references*/
          oErrNo = ICMPERR_PARAMPROB;
          reportIcmpErrorsToUL(oErrNo, pxData->pxNetPacket, pxData->pxNetPacketAccess, oSkip);
        }
        else
          NETMAIN_ASSERT(0);
        break;
      }
    case ICMPCBK_SOURCE_QUENCH :
      {
        if (oCode)
          NETMAIN_ASSERT(0);
        else
        {
          oErrNo = ICMPERR_QUENCH;
          reportIcmpErrorsToUL(oErrNo, pxData->pxNetPacket, pxData->pxNetPacketAccess, oSkip);
        }
        break;
      }
#endif

    case ICMPCBK_REDIRECT:
      {
#ifdef NEW_ICMP_MSG_ADDED
        handleIcmpRedirectErrors(pxData);
#endif
        break;
      }

    default:
      NETMAIN_ASSERT(0);
    }
    NETPAYLOAD_DELUSER(pxData->pxNetPacket->pxPayload);
  }

  return NETERR_NOERR;
}

#ifdef NEW_ICMP_MSG_ADDED
LONG NetAdminTcpCbk(H_NETINSTANCE hInst,
                    OCTET oCbk,
                    H_NETDATA hData)
{
  NETMAIN_ASSERT(hData != 0);

  if (oCbk < NETCBK_MODULESPECIFICBEGIN) {
    NetAdminCommonCbk(hInst,oCbk,hData);
  }
  else {
    switch(oCbk){
    case TCPCBK_DSTUNREACHABLE:
      {
        ICMPMSGDATA xIcmpMsgData;
        TCPCBKDATA *pxTcpData = (TCPCBKDATA *)hData;
        H_NETINSTANCE hIcmpInst;

        xIcmpMsgData.pxNetPacket = pxTcpData->pxNetPacket;
        xIcmpMsgData.pxNetPacketAccess = pxTcpData->pxNetPacketAccess;
        xIcmpMsgData.dwSrcAddr = pxTcpData->xId.xNetId.dwDstIpAddr;
        xIcmpMsgData.dwDstAddr = pxTcpData->xId.xNetId.dwSrcIpAddr;
        xIcmpMsgData.wVlan = pxTcpData->xId.xNetId.wVlan;
        xIcmpMsgData.oIfIdx = pxTcpData->xId.xNetId.oIfIdx;

        hIcmpInst = NETGETINST_ICMP;

        IcmpInstanceMsg(hIcmpInst,
                        ICMPMSG_SENDPORTUNREACH,
                        (H_NETDATA)(&xIcmpMsgData));

      }
      break;

    default:
      NETMAIN_ASSERT(0);
    }

  }
  return NETERR_NOERR;
}

LONG NetAdminIpCbk(H_NETINSTANCE hInst,
                   OCTET oCbk,
                   H_NETDATA hData)
{
  if( oCbk < NETCBK_MODULESPECIFICBEGIN)
  {
    (LONG)NetAdminCommonCbk(hInst, oCbk, hData);
  }
  else
  {
    switch(oCbk)
    {
      case IPMSG_PROTOCOLUNREACHABLE:
      {
         ICMPMSGDATA *pxIcmpMsgData = (ICMPMSGDATA*) hData;
         H_NETINSTANCE hIcmpInst;
         hIcmpInst = NETGETINST_ICMP;
         /*If we have a better mechanism, then adopt. Looks very clumsy to fire this straight away*/
         (LONG)IcmpInstanceMsg(hIcmpInst, IPMSG_PROTOCOLUNREACHABLE, (H_NETDATA) pxIcmpMsgData);
         break;
      }
      default:
      {
        ASSERT(0);
      }
    }
  }
}
#endif

#ifdef IPFRAG

typedef struct {
  OCTET oIcmpMsg;
} IPFRAGCBK2ICMPMSG;

LONG NetAdminIpFragCbk(H_NETINSTANCE hInst,
                       OCTET oCbk,
                       H_NETDATA hData)
{
  IPFRAGCBK2ICMPMSG axIpFragCbk2IcmpMsg[2] = {{ICMPMSG_SENDTIMEEXCEEDEDFRAGTIME},
                                              {ICMPMSG_SENDFRAGNEEDED}};
  NETMAIN_ASSERT(hData != 0);

  if (oCbk < NETCBK_MODULESPECIFICBEGIN) {
    (LONG)NetAdminCommonCbk(hInst,oCbk,hData);
  }
  else {

    switch(oCbk){
    case IPFRAGCBK_TIME_EXCEEDED_FRAGTIME:
    case IPFRAGCBK_FRAG_NEEDED:
      {
        ICMPMSGDATA* pxIcmpMsgData = (ICMPMSGDATA*)hData;
        H_NETINSTANCE hIcmpInst;

        hIcmpInst = NETGETINST_ICMP;

        (LONG)IcmpInstanceMsg(hIcmpInst,
                              axIpFragCbk2IcmpMsg[oCbk - NETCBK_MODULESPECIFICBEGIN].oIcmpMsg,
                              (H_NETDATA)pxIcmpMsgData);

      }
      break;
    default:
      NETMAIN_ASSERT(0);
    }
  }

  return NETERR_NOERR;

}
#endif /*#ifdef IPFRAG*/


#ifdef ROUTER

typedef struct {
  OCTET oIcmpMsg;
} RROUTERCBK2ICMPMSG;

LONG NetAdminRouterCbk(H_NETINSTANCE hInst,
                       OCTET oCbk,
                       H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxIfConf;
  OCTET oIfIdx;
#ifdef _RADIX_ROUTING_ON_
  IPFRAGCBK2ICMPMSG axRouterCbk2IcmpMsg[4] = {{ICMPMSG_SENDNETUNREACH},
#else
  IPFRAGCBK2ICMPMSG axRouterCbk2IcmpMsg[3] = {{ICMPMSG_SENDNETUNREACH},
#endif
                                              {ICMPMSG_SENDFRAGNEEDED},
                                              {ICMPMSG_SENDTIMEEXCEEDEDTTL}
#ifdef _RADIX_ROUTING_ON_
                                             , {NETMSG_LOWERLAYERDOWN}
#endif
                                             };
  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  for(oIfIdx = 0; oIfIdx < pxNetWrapper->oIfNumber; oIfIdx++){
    pxIfConf  = NETGETIFCONF(pxNetWrapper,oIfIdx);
    NETMAIN_ASSERT(pxIfConf != NULL);
    if(pxIfConf->oFlags & IFF_CLOSED_BY_PEER){
      /* NETMAIN_DBGP(NORMAL,"NetAdminRouterCbk: wake up ppp link for oIfIdx = %d\n",oIfIdx); */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
      {
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,
                     "NetAdminRouterCbk: wake up ppp link for oIfIdx =", oIfIdx);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
      }
      NetIfOpen(pxNetWrapper,oIfIdx);
      break;
    }
  }

  NETMAIN_ASSERT(hData != 0);

  if (oCbk < NETCBK_MODULESPECIFICBEGIN) {
    (LONG)NetAdminCommonCbk(hInst,oCbk,hData);
  }
  else {

    switch(oCbk){
    case ROUTERCBK_DEST_UNREACH_NET_UNREACH:
    case ROUTERCBK_DEST_UNREACH_FRAG_NEEDED:
    case ROUTERCBK_TIME_EXCEEDED_TTL_EXPIRED:
#ifdef _RADIX_ROUTING_ON_
    case ROUTERCBK_LINK_DOWN:
#endif
      {
        ICMPMSGDATA* pxIcmpMsgData = (ICMPMSGDATA*)hData;
        H_NETINSTANCE hIcmpInst = NETGETINST_ICMP;

        (LONG)IcmpInstanceMsg(hIcmpInst,
                              axRouterCbk2IcmpMsg[oCbk - NETCBK_MODULESPECIFICBEGIN].oIcmpMsg,
                              (H_NETDATA)pxIcmpMsgData);

      }
      break;
    default:
      NETMAIN_ASSERT(0);
    }
  }

  return NETERR_NOERR;

}
#endif /*#ifdef ROUTER*/
