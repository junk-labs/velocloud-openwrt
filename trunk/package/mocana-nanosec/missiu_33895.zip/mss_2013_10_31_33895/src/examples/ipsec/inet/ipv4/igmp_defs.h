/*
 * igmp_defs.h
 *
 * Definitions for the IGMP module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __IGMP_DEFS_H__
#define __IGMP_DEFS_H__

#include "NNstyle.h"
#include "igmp_flavor.h"
#include "dllist.h"
#include "../include/in.h"
#include "../include/inet.h"
#include "netutils.h"
#include "netsnmp.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netnetwork.h"
#include "iptable.h"
#include "igmp.h"
#include "igmp_dbg.h"
#include "ecc.h"
#include "routing_table.h"
#ifdef IPSEC
#include "ipsec.h"
#endif /* IPSEC */

/***************************************************************************
 * Typedefs
 **************************************************************************/
typedef struct igmp_pkt {
  OCTET oType;        /* version & type of IGMP message */
  OCTET oMaxRespTime; /* Maximum response time, used in igmp query only */
  WORD  wChecksum;    /* IP-style checksum */
  DWORD dwGroupAddr;  /* group address being reported */
} IGMP_PKT;

typedef struct ip_mcast IP_MCAST;

typedef void(*PFN_IGMPRCV)(IP_MCAST*,IGMP_PKT*);

struct ip_mcast {
  DWORD dwTimeResponse;
  PFN_IGMPRCV fpIgmpRcv;
  IPMCASTREQ xIpMreq;
  BOOL bJoinFromSocket;
  BOOL bJoinFromProxy;
  OCTET oNumMemberships;
};

typedef enum {
  IGMP_PROXY_STATE_STARTUP,
  IGMP_PROXY_STATE_QUERIER,
  IGMP_PROXY_STATE_NON_QUERIER,
} E_IGMP_PROXY_STATE;

typedef enum {
  IGMP_GROUP_STATE_MEMBERS_PRESENT,
  IGMP_GROUP_STATE_V1_MEMBERS_PRESENT,
  IGMP_GROUP_STATE_CHECKING_MEMBERSHIP,
} E_IGMP_GROUP_STATE;


typedef struct {
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

  WORD wOffset;
  WORD wTrailer;

  OCTET oTos;            /*Type of service */

  PFN_NETCBK pfnNetCbk;
  PFN_NETMALLOC pfnNetMalloc;
  PFN_NETFREE pfnNetFree;

  DLLIST dllIpMcast;     /* Link list of Multicast IP address */

  OCTET oReportVersion;  /* IGMP V1 or V2*/
  DWORD dwTimeIgmpV1;    /* time when an igmp query V1 is received */

#ifdef STACK_MULTICAST_ROUTER
  DLLIST dllMcastGroups;
  DWORD dwProxyNonQuerierTimer;
  DWORD dwProxyGeneralQueryTimer;
  DWORD dwProxyStartupQueryCount;
  E_IGMP_PROXY_STATE eProxyState;
  OCTET oProxyIfIndex;
#endif /* #ifdef STACK_MULTICAST_ROUTER */

  RTOS_MUTEX pxMutex;

  /* LL interface */
  H_NETINSTANCE hLL;
  H_NETINTERFACE hLLIf;
  PFN_NETWRITE pfnLLWrite;

} IGMPSTATE;


/***************************************************************************
 * Constants
 **************************************************************************/

/*
 * MSTATE states (as defined in  RFC 1112)
 */
#define MSTATE_NONMEMBER  0
#define MSTATE_DELAYING   1
#define MSTATE_IDLE       2

#define IGMP_PROTOCOL     0x02


#define IGMP_MEMBERSHIP_QUERY      0x11
#define IGMP_V1_MEMBERSHIP_REPORT  0x12
#define IGMP_V2_MEMBERSHIP_REPORT  0x16
#define IGMP_LEAVE_MEMBERSHIP      0x17

#define IGMP_MAX_RESPONSE_TIME     100    /* 10 sec, RFC 2236 8.3 */
#define IGMP_V1_ROUTER_TIMEOUT     400000 /* 400 sec, RFC 2236 8.11 */

#ifdef STACK_MULTICAST_ROUTER
  #define MAX_JOINS                  2
#else
  #define MAX_JOINS                  1
#endif

#define UNSOLICITED_REPORT_INTERVAL     10000   /* 10 sec, RFC 2236 8.10 */
#define MULTI_ALL_SYSTEMS               0xE0000001

#define IGMP_PROCESS_NEXT_CALL          500     /* 500 ms */

/***************************************************************************
 * Macros
 **************************************************************************/

/***************************************************************************
 * Externs
 **************************************************************************/

IGMP_DBG_VAR(MOC_EXTERN DWORD g_dwIgmpDebugLevel);

/***************************************************************************
 * Functions
 **************************************************************************/

/* igmp.c */

LONG IgmpMsgJoin(IGMPSTATE *pxIgmp,IPMCASTREQ *pxIpMreq,BOOL bJoinedFromSocket);
LONG IgmpMsgLeave(IGMPSTATE *pxIgmp,IPMCASTREQ *pxIpMreq,BOOL bJoinedFromSocket);

/* igmp_rcv.c */

void IgmpRcvStateIdle(IP_MCAST *pMcast,IGMP_PKT *pxIgmpPkt);
void IgmpRcvStateDelay(IP_MCAST *pMcast,IGMP_PKT *pxIgmpPkt);

/* igmp_xmt.c */

void IgmpXmt(IGMPSTATE *pxIgmp);

/* igmp_report.c */

void IgmpSendReport(IGMPSTATE *pxIgmp,
                    IPMCASTREQ *pxIpMreq,
                    OCTET oType);

/* igmp_utils.c */

LONG IgmpSendPacket(IGMPSTATE *pxIgmp,
                    IPMCASTREQ *pxIpMreq,
                    DWORD dwDstAddr,
                    OCTET oType,
                    OCTET oMaxRespTime,
                    OCTET oTtl,
                    OCTET *poIpOption,
                    OCTET oIpOptionLen);

IP_MCAST* IgmpIpMcastLookup(IGMPSTATE *pxIgmp,IPMCASTREQ *pxIpMreq);
IP_MCAST* IgmpIpMcastInit(BOOL bJoinFromSocket,IPMCASTREQ *pxIpMreq);

#ifdef IGMPDBG_HI
CHAR* IgmpTypeToString(OCTET oType);
void  IgmpPrintMcastGroup(IGMPSTATE *pxIgmp);
#endif /* #ifndef NDEBUG */

#endif /* __IGMP_DEFS_H__ */
