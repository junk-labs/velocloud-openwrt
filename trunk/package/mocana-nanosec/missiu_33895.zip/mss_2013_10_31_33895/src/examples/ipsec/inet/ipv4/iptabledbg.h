/*
 * iptabledbg.h
 *
 * IP table debug defines
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _IPTABLEDBG_H_
#define _IPTABLEDBG_H_

#ifndef NDEBUG

  #ifdef NETDBG_HI
    #ifndef IPTABLEDBG_HI
      #define IPTABLEDBG_HI
    #endif
  #endif

#else

  #ifdef IPTABLEDBG_HI
    #undef IPTABLEDBG_HI
  #endif
  #ifdef NETDBG_HI
    #undef NETDBG_HI
  #endif
#endif

#include "netdbg.h"

/*
 * Constants
 */
#define IPTABLE_MAGIC_COOKIE 0x69707462 /*"iptb" = 0x69707462*/


/*
 * Debug macros
 */
/*#ifdef IPTABLEDBG_HI*/
#if defined(IPTABLEDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define IPTABLE_DBGP(level, fmt, args...) do { \
    if (level <= g_dwIpTableDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define IPTABLE_DBG(level, x) do {  \
    if (level <= g_dwIpTableDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define IPTABLE_DBG_VAR(x)  x

  #define CHECKPOINT(A) A = __LINE__
#else
#if defined (__VXWORKS_RTOS__)
  #define IPTABLE_DBGP
#else
  #define IPTABLE_DBGP(level, fmt, args...)
#endif
  #define IPTABLE_DBG(level, x)
  #define IPTABLE_DBG_VAR(x)
  #define CHECKPOINT(A)
#endif

IPTABLE_DBG_VAR(MOC_EXTERN DWORD g_dwIpTableDebugLevel);

/*
 * Debug levels
 */
#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _IPTABLEDBG_H_ */
