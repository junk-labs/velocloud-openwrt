/*
 * dns.h
 *
 * Defines and data structures for domain name server routines.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef DNSAPI_H
#define DNSAPI_H

/*************************************************************************
 *
 * Typedefs
 *
 *************************************************************************/

/*
 * DNS_SET
 */
typedef struct {
  WORD  wRetryInterval;       /* milliseconds to wait before retry        */
  WORD  wSleepTime;           /* sleep time while waiting for DNS reply   */
  OCTET oNumRetries;          /* # of retries before failing              */
  OCTET oRecurse;             /* Use server recursion if supported        */
} DNS_SET;

/*************************************************************************
 *
 * Dns Lin Msgs
 *
 *************************************************************************/
#define DNSMSG_IFENABLE    0  /* Enable Dns on a If. Data is OCTET.
                                 (If index) */
#define DNSMSG_IFDISABLE   1  /* Disable Dns on a If. Data is OCTET.
                                  (If index) */
#define DNSMSG_IFUPDATE    2  /* Update Dns settings on a If. Data is OCTET.
                                  (If index) */

/*************************************************************************
 *
 * API functions
 *
 *************************************************************************/

/*
 * DnsInit
 *  Initialize the Dns library
 *
 *  Args:
 *
 *  Return:
 *   >=0 for success
 */
int DnsInit(void);

/*
 * DnsTerm
 *  Terminates the Dns library
 *
 *  Args:
 *
 *  Return:
 */
void DnsTerm(void);

/*
 * DnsMsg
 *  Dns message function
 *
 *  Args:
 *   oMsg              Message code. see DNSMSG_XXX definition
 *
 *  Return:
 *   >=0 for success
 */
LONG DnsMsg(OCTET oMsg,DWORD dwData);

#endif

