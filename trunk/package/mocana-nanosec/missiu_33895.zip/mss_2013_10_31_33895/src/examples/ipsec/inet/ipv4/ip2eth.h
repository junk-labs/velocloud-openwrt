/*
 * ip2eth.h
 *
 * IP to Ethernet module (using ARP) API
 *  The UL module of Ip2Eth MUST implement the IP module API as
 *  defined in edev/sw/src/os/NNOS/net/network/ip/include/ip.h
 *  The LL module of Ip2Eth MUST implement the ethernet module API as
 *  defined in edev/sw/src/os/NNOS/net/link/ethernet/include/ethernet.h
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IP2ETH_H_
#define _IP2ETH_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * Ip2Eth UL Ioctls
 *  All needed UL Ioctls are provided in netcommon.h
 *  Note: NETINTERFACEIOCTL_SETOUTPUTPFN is useless as
 *  Ip2Eth assumes that the UL interface is plugged into IP.
 */

/*
 * Ip2Eth options
 */

#define IP2ETHOPTION_SETARPINSTANCE \
  (NETOPTION_MODULESPECIFICBEGIN )

#define IP2ETHOPTION_MAX \
  (NETOPTION_MODULESPECIFICBEGIN + 1)

/*
 * Ip2Eth specific message
 */
#define IP2ETHMSG_ARPRESOLVED  \
  (NETMSG_MODULESPECIFICBEGIN)  /* An IP address has been successfully
                                       resolved in a Eth address. Data
                                       is (ARPREQUEST*) */
#define IP2ETHMSG_ARPFAILED  \
  (NETMSG_MODULESPECIFICBEGIN + 1) /* Can't resolve the IP address
                                          data is (ARPREQUEST*), the arp_pa
                                          member indicating which IP address
                                          can't be resolved */
#define IP2ETHMSG_MAX \
  (NETMSG_MODULESPECIFICBEGIN + 2)


/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/


/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * Ip2EthInitialize
 *  Initialize the Ip2Eth Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG Ip2EthInitialize(void);

/*
 * Ip2EthTerminate
 *  Terminate the Ip2Eth Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG Ip2EthTerminate(void);

/*
 * Ip2EthInstanceCreate
 *  Creates a Ip2Eth Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE Ip2EthInstanceCreate(void);

/*
 * Ip2EthInstanceDestroy
 *  Destroy a Ip2Eth Instance
 *
 *  Args:
 *   hIp2Eth                       Ip2Eth instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip2EthInstanceDestroy(H_NETINSTANCE hIp2Eth);

/*
 * Ip2EthInstanceSet
 *  Set a Ip2Eth Instance Option
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip2EthInstanceSet(H_NETINSTANCE hIp2Eth,
                       OCTET oOption,
                       H_NETDATA hData);

/*
 * Ip2EthInstanceQuery
 *  Query a Ip2Eth Instance Option
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG Ip2EthInstanceQuery(H_NETINSTANCE hIp2Eth,
                         OCTET oOption,
                         H_NETDATA *phData);

/*
 * Ip2EthInstanceMsg
 *  Send a msg to a Ip2Eth instance
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *   oMsg                       Msg. See netcommon.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG Ip2EthInstanceMsg(H_NETINSTANCE hIp2Eth,OCTET oMsg,
                       H_NETDATA hData);


/*
 * Ip2EthInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer : IP.
 *  Only 1 interface can be created
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE Ip2EthInstanceULInterfaceCreate(H_NETINSTANCE hIp2Eth);

/*
 * Ip2EthInstanceULInterfaceDestroy
 *  Destroy a ETH UL interface
 *
 *  Args:
 *   hIp2Eth                    ETH instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG Ip2EthInstanceULInterfaceDestroy(H_NETINSTANCE hIp2Eth,
                                      H_NETINTERFACE hInterface);

/*
 * Ip2EthInstanceULInterfaceIoctl
 *  Ip2Eth UL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h
 *
 *  Args:
 *   hIp2Eth                      Ip2Eth instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG Ip2EthInstanceULInterfaceIoctl(H_NETINSTANCE hIp2Eth,
                                    H_NETINTERFACE hULInterface,
                                    OCTET oIoctl,
                                    H_NETDATA hData);

/*
 * Ip2EthInstanceWrite
 *  Ip2Eth Instance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hIp2Eth                     Ip2Eth Instance handle
 *   hIf                         Interface handle
 *   pxPacket                    Packet pointer
 *   pxAccess                    Access info
 *   hData                       Dest IP address (DWORD)
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG Ip2EthInstanceWrite(H_NETINSTANCE hIp2Eth,
                         H_NETINTERFACE hIf,
                         NETPACKET *pxPacket,
                         NETPACKETACCESS *pxAccess,
                         H_NETDATA hDst);

/*
 * Ip2EthInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer (ethernet) Only one
 *  interface is supported
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE Ip2EthInstanceLLInterfaceCreate(H_NETINSTANCE hIp2Eth);

/*
 * Ip2EthInstanceLLInterfaceDestroy
 *  Destroy a Ip2Eth LL interface
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG Ip2EthInstanceLLInterfaceDestroy(H_NETINSTANCE hIp2Eth,
                                      H_NETINTERFACE hInterface);


/*
 * Ip2EthInstanceLLInterfaceIoctl
 *  Ip2Eth LL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h
 *
 *  Args:
 *   hIp2Eth                      Ip2Eth instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG Ip2EthInstanceLLInterfaceIoctl(H_NETINSTANCE hIp2Eth,
                                    H_NETINTERFACE hLLInterface,
                                    OCTET oIoctl,
                                    H_NETDATA hData);


/*
 * Ip2EthInstanceRcv
 *  Ip2Eth Instance Rcv function
 *   Ip2Eth Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIp2Eth                    Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    pxAccess                   access info
 *    wOffset                    IP PDU offset.
 *    hData                      unused
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG Ip2EthInstanceRcv(H_NETINSTANCE hIp2Eth,
                       H_NETINTERFACE hIf,
                       NETPACKET *pxPacket,
                       NETPACKETACCESS *pxAccess,
                       H_NETDATA hData);


/*
 * Ip2EthCbk
 *  Administrative Callback provided to the ARP instance
 *  Follows PFN_NETWORKCBK type (see netcommon.h)
 */

LONG Ip2EthCbk(H_NETINSTANCE hInst,
               OCTET oCbk,
               H_NETDATA hData);

/*
 * Ip2EthInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hIp2Eth                     Eth Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 5 ms)
 */
LONG Ip2EthInstanceProcess(H_NETINSTANCE hIp2Eth);

#endif /* #ifndef _IP2ETH_H_ */







