/*
 * igmp_instancequery.c
 *
 * IGMP module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "igmp_defs.h"
#include "igmp_proxy_defs.h"

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/ /*
 * IgmpInstanceQuery
 *  Query a IGMP Instance Option
 *
 *  Args:
 *   hIgmp                      instance handle
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */

LONG IgmpInstanceQuery(H_NETINSTANCE hIgmp,
                       OCTET oOption,
                       H_NETDATA *phData)
{
  IGMPSTATE *pxIgmp;
  LONG lReturn = NETERR_NOERR;

  pxIgmp = (IGMPSTATE *)hIgmp;
  IGMP_CHECK_STATE(pxIgmp);

  switch(oOption) {

  case NETOPTION_PAYLOADMUTEX:
    *phData = (H_NETDATA)pxIgmp->pxMutex;
    break;

  case NETOPTION_OFFSET:
    *phData = (H_NETDATA)pxIgmp->wOffset;
    break;

  case NETOPTION_TRAILER:
    *phData = (H_NETDATA)pxIgmp->wTrailer;
    break;

  case NETOPTION_NETCBK:
    *phData = (H_NETDATA)pxIgmp->pfnNetCbk;
    break;

  case IGMPOPTION_SETTOS:
    *phData = (H_NETDATA)pxIgmp->oTos;
    break;

  default:
    lReturn = NETERR_BADVALUE;
    ASSERT(0);
  }

  return lReturn;
}


