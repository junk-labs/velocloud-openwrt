/*
 * dhcpclient.h
 *
 * DHCP Client module API header file
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _DHCPCLIENT_H_
#define _DHCPCLIENT_H_


/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * DHCP Client message options
 */
#define DHCPCLIENTMSG_ENABLE       1
#define DHCPCLIENTMSG_DISABLE      2

#define DHCP_OK                    0
#define DHCP_TIMEOUT              -1
#define DHCP_NACK_ERROR           -2
#define DHCP_LEASE_EXPIRED        -3
#ifdef DHCP_CUSTOM_OPTIONS
#define DHCP_OPT_CHK_COMPLETE     -4
#endif /* DHCP_CUSTOM_OPTIONS */


#ifdef DHCP_CUSTOM_OPTIONS

/* arbitrary maximum response length for custom DHCP options */
#define MAX_CUSTOM_RESPONSE_LEN 100

/* octet bit field, packet type to send custom dhcp option */
#define DHCP_CPT_NONE      ((OCTET) 0)
#define DHCP_CPT_DISCOVERY ((OCTET) 0x1)
#define DHCP_CPT_REQUEST   ((OCTET) 0x2)

/* call back on incoming option only - this option cannot be combined with other options... */
#define DHCP_CPT_REPORT_ONLY ((OCTET) 0x8)

#endif /* DHCP_CUSTOM_OPTIONS */


/*****************************************************************************
 *
 * Data types
 *
 *****************************************************************************/

#ifdef DHCP_CUSTOM_OPTIONS

typedef void (*DHCP_CUSTOM_CBK)(OCTET oOption, OCTET* poResponseBuffer, OCTET oResponseSize);

typedef struct {
  OCTET oPktType;
  OCTET oCustomOption;
  OCTET* poCustomOptionBuf;
  OCTET oBufSize;
  DHCP_CUSTOM_CBK pfnCB;  /* NOTE: maybe replace with single CBK per interface at some point */
} DHCP_CUSTOM_OPTION;

#endif /* DHCP_CUSTOM_OPTIONS */


/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/
/*
 * DHCPClientInstanceCreate
 *  Creates a DHCP Client instance
 *
 *  Args:
 *   None
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE DHCPClientInstanceCreate(void);


/*
 * DHCPClientInstanceDestroy
 *  Destroys a DHCP Client instance
 *
 *  Args:
 *   hDhcpClient            Handle to the instance
 *
 *  Return:
 *   0
 */
LONG DHCPClientInstanceDestroy(H_NETINSTANCE hDhcpClient);


/*
 * DHCPClientInstanceMsg
 *  Send a message to a DHCP Client
 *
 *  Args:
 *   hDhcpClient            Handle to the instance
 *   oMsg                   Msg code. See netcommon.h for definition
 *   hData                  Option data
 *
 *  Return:
 *   >=0   Success
 *   <=-1  Failure
 */
LONG DHCPClientInstanceMsg(H_NETINSTANCE hDhcpClient,
                           OCTET oMsg,
                           H_NETDATA hData);


/*
 * DHCPClientInstanceProcess
 *  DHCP Client instance processing function
 *  (can be called infrequently - e.g. every 500ms)
 *
 *  Args:
 *   hDhcpClient             Handle on the instance
 *
 *  Return:
 *   DHCP_OK              - no error
 *   DHCP_TIMEOUT         - timeout has occurred
 *   DHCP_LEASE_EXPIRED   - the lease has expired
 *   DHCP_NACK_ERROR      - we received a NACK
 */
LONG DHCPClientInstanceProcess(H_NETINSTANCE hDhcpClient);



#endif /* #ifndef _DHCPCLIENT_H_ */







