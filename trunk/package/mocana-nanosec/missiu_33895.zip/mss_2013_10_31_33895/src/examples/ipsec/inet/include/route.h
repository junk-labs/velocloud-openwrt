/*
 * route.h
 *
 * public router specific definitions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NET_ROUTE_H_
#define _NET_ROUTE_H_

/***********************************************************************
 *
 * Constants
 *
 **********************************************************************/
#define RTF_STATIC      0x1
#define RTF_DYNAMIC     0x2
#define RTF_DEFAULT     0x4


/***********************************************************************
 *
 * Structures & Typedefs
 *
 **********************************************************************/
/*
 * This structure gets passed by the SIOCADDRT and SIOCDELRT calls.
 */
struct rtentry {
  struct sockaddr rt_dst;             /* Target address.  */
  struct sockaddr rt_gateway;         /* Gateway addr. */
  struct sockaddr rt_genmask;         /* Target network mask (IP). */
  unsigned char   rt_tos;
  short int       rt_metric;          /* route metric */
  unsigned char   rt_ifindex;          /* interface to the gateway */
  unsigned short  rt_flags;
};

#endif /* __NET_ROUTE_H__ */
