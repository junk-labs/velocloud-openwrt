/*
 * routing_table.c
 *
 * Implements the routing table
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/

#include "router.h"
#include "routing_table_defs.h"

/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/
void RoutingTableDisplay(ROUTINGTABLESTATE *pxRoutingTable, ubyte *poSbuf, ubyte4 *pdwSbufWritten);

ROUTINGTABLE_DBG_VAR(DWORD g_dwRoutingTableDebugLevel = 3);


/*****************************************************************************
 *
 * static variables
 *
 *****************************************************************************/
static ROUTINGTABLESTATE xRoutingTable;
ROUTINGTABLESTATE *pxSnmpRoutingTable = &xRoutingTable;


/*****************************************************************************
 *
 * local function
 *
 *****************************************************************************/

static LONG _RoutingTableAddRoute(ROUTINGTABLESTATE *pxRoutingTable,
                                  ROUTEENTRY        *pxRouteEntry,
                                  DWORD             dwType,
                                  ROUTEENTRY*       *ppxAddedRoute);

static LONG _RoutingTableDelRoute(ROUTINGTABLESTATE *pxRoutingTable,
                                  ROUTEENTRY        *pxRouteEntry);

static LONG _RoutingTableFindRoute(ROUTINGTABLESTATE *pxRoutingTable,
                                   ROUTEENTRY        *pxRouteEntry);

/*#ifdef ROUTINGTABLE_BESTDEFAULTROUTE*/
/*Function defined only if ROUTINGTABLE_BESTDEFAULTROUTE and _RADIX_ROUTING_ON_ is not defined*/
#if (defined( ROUTINGTABLE_BESTDEFAULTROUTE ) && !defined( _RADIX_ROUTING_ON_ ))
static LONG _RoutingTableUpdateBestDefaultRoute(ROUTINGTABLESTATE *pxRoutingTable);
#else
#undef ROUTINGTABLE_BESTDEFAULTROUTE  /*Unset ROUTINGTABLE_BESTDEFAULTROUTE*/
#endif

#ifdef ROUTINGTABLE_STATIC
static LONG _RoutingTableSetStaticRoute(ROUTINGTABLESTATE *pxRoutingTable,
                                        STATICROUTEENTRY  *pxStaticRouteEntry);
#endif

#ifdef ROUTINGTABLE_RETRIEVE
static LONG _RoutingTableGetRouteEntry(ROUTINGTABLESTATE *pxRoutingTable,
                                       ROUTEGETROUTE     *pxRouteGetRoute);
#endif

#ifdef ROUTINGTABLE_BESTDEFAULTROUTE
static ROUTEENTRY* _RoutingTableFindDefaultRouteOnIf(ROUTINGTABLESTATE *pxRoutingTable,
                                                     OCTET             oIfIdx);
#endif

static LONG _RoutingTableGetDefaultIdx(ROUTINGTABLESTATE *pxRoutingTable);

#ifdef _RADIX_ROUTING_ON_
static void _FreeRouteEntry(RADIXNODE **ppxRadixNodeEntry);
#endif
/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * RoutingTableInitialize
 *  Initialize the Routing Table library
 *
 *  Args:
 *
 *  Return:
 *   NETERR_NOERR : success
 */
LONG RoutingTableInitialize(void)
{
  MOC_MEMSET((ubyte *)&xRoutingTable,0x00,sizeof(ROUTINGTABLESTATE));

  ROUTINGTABLE_SET_COOKIE(&xRoutingTable);

#ifdef _RADIX_ROUTING_ON_
  xRoutingTable.pxRadixTree = RadixInit();
#endif

  /* Initialise the DEBUG symbol to ERROR */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_ERROR);
  return NETERR_NOERR;
}

/*
 * RoutingTableTerminate
 *  Terminate the Routing Table library
 *
 *  Args:
 *
 *  Return:
 *   NETERR_NOERR : success
 */
LONG RoutingTableTerminate(void)
{
  ROUTINGTABLE_CHECK_STATE((&xRoutingTable));

#ifdef _RADIX_ROUTING_ON_
  /*Clean up all the nodes within the tree.*/
  if(xRoutingTable.pxRadixTree)
  {
    FreeRadixTree(xRoutingTable.pxRadixTree, _FreeRouteEntry);
    MOC_FREE((void**) &(xRoutingTable.pxRadixTree));
  }
#else
  /* Clear the route dll*/
  clear_DLLIST(&(xRoutingTable.dllRoute),NetFree);
#endif

  /* Unset the cookie*/
  ROUTINGTABLE_UNSET_COOKIE((&xRoutingTable));
  return NETERR_NOERR;
}

/*
 * RoutingTableMsg
 *  Send a msg to a Routing Table instance
 *
 *  Args:
 *   hRoutingTable              Routing Table instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG RoutingTableMsg(OCTET oMsg,H_NETDATA hData)
{
  ROUTINGTABLESTATE *pxRoutingTable = &xRoutingTable;

  LONG lRv = NETERR_NOERR;

  ROUTINGTABLE_CHECK_STATE(pxRoutingTable);

  switch (oMsg) {

  case ROUTINGTABLEMSG_ADDROUTE:
    lRv =  _RoutingTableAddRoute(pxRoutingTable,(ROUTEENTRY*)hData,
                                 RTF_DYNAMIC, NULL);
    break;

  case ROUTINGTABLEMSG_DELROUTE:
    lRv =  _RoutingTableDelRoute(pxRoutingTable,(ROUTEENTRY*)hData);
    break;

  case ROUTINGTABLEMSG_FINDROUTE:
    lRv =  _RoutingTableFindRoute(pxRoutingTable,(ROUTEENTRY*)hData);
    break;

#ifdef ROUTINGTABLE_STATIC
  case ROUTINGTABLEMSG_SETSTATICROUTE:
    lRv =  _RoutingTableSetStaticRoute(pxRoutingTable,(STATICROUTEENTRY*) hData);
    break;
#endif

#ifdef ROUTINGTABLE_RETRIEVE
  case ROUTINGTABLEMSG_GETNUMROUTE:
#ifdef _RADIX_ROUTING_ON_
    {
      ubyte4 dwNumLeafs = 0;
      RADIXNODE *pxRadNodeRoute = NULL;
      LIST_FOREACH(pxRadNodeRoute, &(pxRoutingTable->pxRadixTree->xRadixNodeList), xRadixNodeLink)
        dwNumLeafs++;
      *((ubyte4 *) hData) = dwNumLeafs;
    }
#else
    *((DWORD*) hData) = DLLIST_count(&pxRoutingTable->dllRoute);
#endif /* end of _RADIX_ROUTING_ON_*/
    break;

  case ROUTINGTABLEMSG_GETROUTE:
    lRv =  _RoutingTableGetRouteEntry(pxRoutingTable, (ROUTEGETROUTE*) hData);
    break;
#endif
  case ROUTINGTABLEMSG_GETDEFAULTIDX:
    lRv =  _RoutingTableGetDefaultIdx(pxRoutingTable);
    break;

  case ROUTINGTABLEMSG_SETBRIDGEDIDX:
  {
    ROUTESETBRIDGEDIDX *pxRouteSetBridgedIdx = (ROUTESETBRIDGEDIDX*)hData;

    if (pxRouteSetBridgedIdx->bBridged) {
      pxRoutingTable->dwfBridgedIdx |= (DWORD)1 << pxRouteSetBridgedIdx->oIfIdx;
    } else {
      pxRoutingTable->dwfBridgedIdx &= ~((DWORD)1 << pxRouteSetBridgedIdx->oIfIdx);
    }
  }
  break;

  case ROUTINGTABLEMSG_SETLINKSTATUS: /* RS added link status */
    {
      ROUTINGTABLESETLINKSTATUS* pxRoutingTableSetLinkStatus =
        (ROUTINGTABLESETLINKSTATUS*) hData;
      pxRoutingTable->abIsLinkUp[pxRoutingTableSetLinkStatus->oIfIdx] =
        pxRoutingTableSetLinkStatus->bIsLinkUp;
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_REPETITIVE))
      {
        /*ROUTINGTABLE_DBGP(REPETITIVE,
         "Routing table Link message:  %d  %d\n",
              pxRoutingTableSetLinkStatus->oIfIdx,
              pxRoutingTableSetLinkStatus->bIsLinkUp);*/
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "Routing table Link message: ",
                            pxRoutingTableSetLinkStatus->oIfIdx, " ", pxRoutingTableSetLinkStatus->bIsLinkUp);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }
    }
    break;

#ifndef NDEBUG
  case NETMSG_OPEN:
  case NETMSG_CLOSE:
    break;

  default:
    lRv = NETERR_UNKNOWN;
    ASSERT(0);
#endif

#ifdef __MOC_CLI__
  case ROUTINGTABLEMSG_CLI_GETALLROUTES:
    {
      ROUTINGTABLECLIGET *pxRoutingTableCliGet = (ROUTINGTABLECLIGET *)(hData);
      RoutingTableDisplay(pxRoutingTable, pxRoutingTableCliGet->poSbuf,
                          &(pxRoutingTableCliGet->dwSbufLen));
      break;
    }
#endif
  }
  return lRv;
}

/*****************************************************************************
 *
 * _RoutingTableAddRoute
 *
 *****************************************************************************/
static LONG _RoutingTableAddRoute(ROUTINGTABLESTATE *pxRoutingTable,
                                         ROUTEENTRY        *pxRouteEntry,
                                         DWORD             dwType,
                                         ROUTEENTRY*       *ppxAddedRoute)
{
  LONG lRv = NETERR_NOERR;
  ROUTEENTRY *pxRoute = NULL;
#ifdef _RADIX_ROUTING_ON_
  RADIXNODE *pxRadNode = NULL;
  MSTATUS xReturn = OK;
#endif
  if (ppxAddedRoute) {
    *ppxAddedRoute = NULL;
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_NORMAL))
  {
    /*ROUTINGTABLE_DBGP(NORMAL,
                    "_RoutingTableAddRoute:DstAddr=%ld.%ld.%ld.%ld,Subnet=%ld.%ld.%ld.%ld,Gateway=%ld.%ld.%ld.%ld,If:%d\n",
                    IPADDRDISPLAY(pxRouteEntry->dwDstAddr),
                    IPADDRDISPLAY(pxRouteEntry->dwSubnetMask),
                    IPADDRDISPLAY(pxRouteEntry->dwGateway),
                    pxRouteEntry->oIfIdx);*/
#ifdef _RADIX_ROUTING_ON_
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_RoutingTableAddRoute:DstAddr = ", pxRouteEntry->xRouteNodes->RadixNodeKey);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Subnet = ", pxRouteEntry->xRouteNodes->RadixNodeMask);
#else
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_RoutingTableAddRoute:DstAddr = ", pxRouteEntry->dwDstAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Subnet = ", pxRouteEntry->dwSubnetMask);
#endif
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Gateway = ", pxRouteEntry->dwGateway);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", If : ", pxRouteEntry->oIfIdx);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", eDstAddrType : ", pxRouteEntry->eDstAddrType);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /* routes must have a specified interface !!!*/
  /* gateway cannot be 0x0 */
  if ((pxRouteEntry->dwGateway == 0x0) || (pxRouteEntry->oIfIdx == NETIFIDX_ANY)) {
    return NETERR_BADVALUE;
  }
#ifdef _RADIX_ROUTING_ON_
  /*pxRoute = (ROUTEENTRY*)MALLOC(sizeof(ROUTEENTRY));*/
  xReturn = MOC_MALLOC((void **)&pxRoute, sizeof(ROUTEENTRY));
  if(xReturn != OK)
  {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_ERROR))
    {
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_RoutingTableAddRoute : allocation failed for ROUTEENTRY");
    }
    return NETERR_BADVALUE; /*Need to change this ?????*/
  }
  ASSERT(pxRoute != NULL);
  MOC_MEMSET((ubyte *)pxRoute, 0, sizeof(ROUTEENTRY));
  pxRadNode = RadixAddRoute(pxRouteEntry->xRouteNodes->RadixNodeKey, pxRouteEntry->xRouteNodes->RadixNodeMask,
                                  pxRoutingTable->pxRadixTree, pxRoute->xRouteNodes);
  if(pxRadNode == NULL)
  {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_ERROR))
    {
      /*ROUTINGTABLE_DBGP(ERROR,"!! _RoutingTableAddRoute : route already exists, overwrite it\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "!! _RoutingTableAddRoute : route already exists, ignoring entry ");
    }
    MOC_FREE((void **)&pxRoute);
    return NETERR_BADVALUE;
  }
  else
  {
    pxRoute->dwGateway    = pxRouteEntry->dwGateway;
    pxRoute->wTOS         = pxRouteEntry->wTOS;
    pxRoute->wMetric      = pxRouteEntry->wMetric ;
    pxRoute->wVlan        = pxRouteEntry->wVlan;
    pxRoute->oIfIdx       = pxRouteEntry->oIfIdx;
    pxRoute->oType        = dwType;
    pxRoute->eDstAddrType = pxRouteEntry->eDstAddrType;
  }
#else
  /* Check if we got enough space to add the route*/
  if (DLLIST_count_inline(&pxRoutingTable->dllRoute) >= ROUTINGTABLE_MAX_NUM_ROUTES) {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_ERROR))
    {
      /*ROUTINGTABLE_DBGP(ERROR,"!! _RoutingTableAddRoute : too many routes\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "!! _RoutingTableAddRoute : too many routes");
    }
    /*TODO check if the snmp variable is correct*/
    SNMP( xTcpipData.ipRoutingDiscards++ );
    return NETERR_BADVALUE;
  }

  /* Check for duplicated entry*/
  DLLIST_head(&pxRoutingTable->dllRoute);

  while( (pxRoute = DLLIST_read(&pxRoutingTable->dllRoute)) != NULL){

#if 0          /* uncomment this to overwrite the default gateway */
    if ((pxRouteEntry->dwDstAddr == 0) && (pxRoute->dwDstAddr == 0)) {
      /*overwrite the default gateway*/
      break;
    }
#endif         /* uncomment this to overwrite the default gateway */

    if ((pxRoute->dwDstAddr == pxRouteEntry->dwDstAddr) &&
        (pxRoute->dwGateway == pxRouteEntry->dwGateway) &&
        /* oIfIdx must be defined and match */
        (pxRoute->oIfIdx == pxRouteEntry->oIfIdx) &&
        /* Vlam must be "any" or match */
        ((pxRoute->wVlan == NETVLAN_ANY) ||
         (pxRouteEntry->wVlan == NETVLAN_ANY) ||
         ((pxRouteEntry->wVlan & NETVLAN_VIDMASK) ==
            (pxRoute->wVlan & NETVLAN_VIDMASK)))) {
      /* The route has been found */
      /* The most generic Vlan overwrites the other */
      if (pxRouteEntry->wVlan == NETVLAN_ANY) {
        pxRoute->wVlan = NETVLAN_ANY;
      }
      break;
    }
    else {
      DLLIST_next(&pxRoutingTable->dllRoute);
    }
  }

  if(pxRoute == NULL){
    /*There is no duplicated entry, it's a new one*/
    /*Allocate memory for a ROUTEENTRY structure*/
    pxRoute = (ROUTEENTRY*)MALLOC(sizeof(ROUTEENTRY));
    ASSERT(pxRoute != NULL);
    MOC_MEMSET((ubyte *)pxRoute, 0, sizeof(ROUTEENTRY));
    /* Add the route into the dll*/
    if(pxRouteEntry->dwDstAddr != (DWORD)0){
      (void*)DLLIST_prepend(&pxRoutingTable->dllRoute,(void*)pxRoute);
    } else {
      (void*)DLLIST_append(&pxRoutingTable->dllRoute,(void*)pxRoute);
    }
  } else {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_ERROR))
    {
      /*ROUTINGTABLE_DBGP(ERROR,"!! _RoutingTableAddRoute : route already exists, overwrite it\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "!! _RoutingTableAddRoute : route already exists");
    }
  }

  /* Copy the ROUTEENTRY structure*/
  MOC_MEMCPY((ubyte *)pxRoute,(ubyte *)pxRouteEntry,sizeof(ROUTEENTRY));

  pxRoute->oType = (OCTET) dwType;

#endif /*end of _RADIX_ROUTING_ON_*/

#ifdef _RADIX_ROUTING_ON_
  if ((pxRouteEntry->xRouteNodes->RadixNodeKey == ROUTINGTABLE_DEFAULT_DESTINATION) ||
      (pxRouteEntry->xRouteNodes->RadixNodeMask == ROUTINGTABLE_DEFAULT_SUBNETMASK))
#else
  if ((pxRouteEntry->dwDstAddr == ROUTINGTABLE_DEFAULT_DESTINATION) ||
      (pxRouteEntry->dwSubnetMask == ROUTINGTABLE_DEFAULT_SUBNETMASK))
#endif
  {
    pxRoute->oType |= RTF_DEFAULT;
#ifdef _RADIX_ROUTING_ON_
    pxRoutingTable->pxBestDefaultGw = pxRoute;
#else
#ifdef ROUTINGTABLE_BESTDEFAULTROUTE
    _RoutingTableUpdateBestDefaultRoute(pxRoutingTable);
#else
    pxRoutingTable->pxBestDefaultGw = pxRoute;
#endif
#endif /*end of _RADIX_ROUTING_ON_*/
  }


  if (ppxAddedRoute) {
    *ppxAddedRoute = pxRoute;
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ROUTINGTABLE_DBG(REPETITIVE,RoutingTableDisplay(pxRoutingTable));*/
    RoutingTableDisplay(pxRoutingTable, NULL, NULL);
  }

  return lRv;
}

/*****************************************************************************
 *
 * _RoutingTableDelRoute
 *
 *****************************************************************************/
static LONG _RoutingTableDelRoute(ROUTINGTABLESTATE *pxRoutingTable,
                                         ROUTEENTRY        *pxRouteEntry)
{
  LONG lRv = NETERR_NOERR;
  ROUTEENTRY *pxRoute;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_NORMAL))
  {
    /*ROUTINGTABLE_DBGP(NORMAL,
                    "_RoutingTableDelRoute:DstAddr=%ld.%ld.%ld.%ld,Subnet=%ld.%ld.%ld.%ld,Gateway=%ld.%ld.%ld.%ld,If:%d\n",
                    IPADDRDISPLAY(pxRouteEntry->dwDstAddr),
                    IPADDRDISPLAY(pxRouteEntry->dwSubnetMask),
                    IPADDRDISPLAY(pxRouteEntry->dwGateway),
                    pxRouteEntry->oIfIdx);*/
#ifdef _RADIX_ROUTING_ON_
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_RoutingTableDelRoute:DstAddr = ", pxRouteEntry->xRouteNodes->RadixNodeKey);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Subnet = ", pxRouteEntry->xRouteNodes->RadixNodeMask);
#else
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_RoutingTableDelRoute:DstAddr = ", pxRouteEntry->dwDstAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Subnet = ", pxRouteEntry->dwSubnetMask);
#endif
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Gateway = ", pxRouteEntry->dwGateway);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", If : ", pxRouteEntry->oIfIdx);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

#ifdef _RADIX_ROUTING_ON_
  /*Add code for deletion*/
  pxRoute = (ROUTEENTRY *)(RadixDelete(pxRouteEntry->xRouteNodes->RadixNodeKey, pxRouteEntry->xRouteNodes->RadixNodeMask, pxRoutingTable->pxRadixTree));
#else
  /*Check if there is at least one route to delete*/
  if (DLLIST_count_inline(&pxRoutingTable->dllRoute) == 0) {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_ERROR))
    {
      /*ROUTINGTABLE_DBGP(ERROR,"!! _RoutingTableDelRoute : there is no route to delete\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "!! _RoutingTableDelRoute : there is no route to delete");
    }
    return NETERR_BADVALUE;
  }

  /* Remove given entry from the dll */
  DLLIST_head(&pxRoutingTable->dllRoute);

  while( (pxRoute = DLLIST_read(&pxRoutingTable->dllRoute)) != NULL){

    if ((pxRoute->dwDstAddr == pxRouteEntry->dwDstAddr) &&
        (pxRoute->dwGateway == pxRouteEntry->dwGateway) &&
        (pxRoute->oIfIdx == pxRouteEntry->oIfIdx) &&
        /* Vlan: only matches if the proposed VLAN is ANY
           or ==. in other words: a specific VLAN can not remove
           a ANY one */
        ((pxRouteEntry->wVlan == NETVLAN_ANY) ||
         ((pxRouteEntry->wVlan & NETVLAN_VIDMASK) ==
            (pxRoute->wVlan & NETVLAN_VIDMASK)))) {

        /* The route has been found */
        (void*)DLLIST_remove(&pxRoutingTable->dllRoute);
        FREE(pxRoute);
        break;
    } else {
      DLLIST_next(&pxRoutingTable->dllRoute);

    }
  }

#endif /*end of _RADIX_ROUTING_ON_*/

  if(pxRoute == NULL){
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_ERROR))
    {
      /*ROUTINGTABLE_DBGP(ERROR,"!! _RoutingTableDelRoute : can't find the route to delete\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "!! _RoutingTableDelRoute : can't find the route to delete");
    }
    lRv = NETERR_BADVALUE;
  }
#ifdef _RADIX_ROUTING_ON_
  else
  {
    MOC_FREE((void**) &pxRoute);
  }
#endif

#ifndef _RADIX_ROUTING_ON_
  if (pxRoute == pxRoutingTable->pxBestDefaultGw) {
    pxRoutingTable->pxBestDefaultGw = NULL;
#ifdef ROUTINGTABLE_BESTDEFAULTROUTE
    _RoutingTableUpdateBestDefaultRoute(pxRoutingTable);
#endif
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ROUTINGTABLE_DBG(REPETITIVE,RoutingTableDisplay(pxRoutingTable));*/
    RoutingTableDisplay(pxRoutingTable, NULL, NULL);
  }
#endif /*end of ifndef _RADIX_ROUTING_ON_*/

   return lRv;
}

/*****************************************************************************
 *
 * _RoutingTableFindRoute
 *
 *****************************************************************************/
static LONG _RoutingTableFindRoute(ROUTINGTABLESTATE *pxRoutingTable,
                                   ROUTEENTRY        *pxRouteEntry)
{
  LONG lRv = NETERR_NOERR;
  ROUTEENTRY *pxRoute = NULL;
  DWORD dwSubnetMaskTempRt = 0x0, dwSubnetMaskTempBr = 0x0;
  ROUTEENTRY *pxNetRouteTempRt = NULL, *pxNetRouteTempBr = NULL;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ROUTINGTABLE_DBGP(REPETITIVE,
                      "_RoutingTableFindRoute=>DstAddr=%ld.%ld.%ld.%ld,Subnet=%ld.%ld.%ld.%ld,Gateway=%ld.%ld.%ld.%ld,If:%d\n",
                      IPADDRDISPLAY(pxRouteEntry->dwDstAddr),
                      IPADDRDISPLAY(pxRouteEntry->dwSubnetMask),
                      IPADDRDISPLAY(pxRouteEntry->dwGateway),
                      pxRouteEntry->oIfIdx);*/
#ifdef _RADIX_ROUTING_ON_
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_RoutingTableFindRoute=>DstAddr = ", pxRouteEntry->xRouteNodes->RadixNodeKey);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Subnet = ", pxRouteEntry->xRouteNodes->RadixNodeMask);
#else
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_RoutingTableFindRoute=>DstAddr = ", pxRouteEntry->dwDstAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Subnet = ", pxRouteEntry->dwSubnetMask);
#endif
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Gateway = ", pxRouteEntry->dwGateway);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", If : ", pxRouteEntry->oIfIdx);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }
#if _RADIX_ROUTING_ON_
  pxRoute = (ROUTEENTRY *) RadixLookUp(pxRouteEntry->xRouteNodes->RadixNodeKey,
                                       pxRouteEntry->xRouteNodes->RadixNodeMask,
                                       pxRoutingTable->pxRadixTree);
  /* Check if we got an entry */
  if(NULL == pxRoute)
      return -1;
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_REPETITIVE))
  {
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_RoutingTableFindRoute<=DstAddr = ", htonl(pxRoute->xRouteNodes->RadixNodeKey));
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Subnet = ", htonl(pxRoute->xRouteNodes->RadixNodeMask));
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Gateway = ", pxRoute->dwGateway);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", If : ", pxRoute->oIfIdx);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", DstAddrType : ", pxRoute->eDstAddrType);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }
  pxRouteEntry->dwGateway    = pxRoute->dwGateway;
  pxRouteEntry->oIfIdx       = pxRoute->oIfIdx;
  pxRouteEntry->eDstAddrType = pxRoute->eDstAddrType;
#else
  /*
   * If the Dst Addr type has not been set, set it here
   */
  if (pxRouteEntry->eDstAddrType == IPADDRT_UNKNOWN) {
    IPTABLEENTRY xIpEntry;
    xIpEntry.dwAddr = pxRouteEntry->dwDstAddr;
    xIpEntry.oIfIdx = pxRouteEntry->oIfIdx;
    xIpEntry.wDefaultVlan = pxRouteEntry->wVlan;

    pxRouteEntry->eDstAddrType =
      IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry);
  }

  /*
   * Find the route.
   */
  switch (pxRouteEntry->eDstAddrType) {

    case IPADDRT_LOOPBACK:
      pxRouteEntry->dwGateway = pxRouteEntry->dwDstAddr;
      return lRv;

    case IPADDRT_MYADDR:
    case IPADDRT_MYSUBNET:
    case IPADDRT_PPPPEER:
    case IPADDRT_BROADCAST:
      /*
       * Find the correct interface pertaining to the address.
       */
      pxRouteEntry->dwGateway = pxRouteEntry->dwDstAddr;

      if (pxRouteEntry->oIfIdx == NETIFIDX_ANY) {
        IPTABLEENTRY xIpEntry;

        xIpEntry.dwAddr = pxRouteEntry->dwGateway;
        xIpEntry.eAddrType = pxRouteEntry->eDstAddrType;
        xIpEntry.oIfIdx = pxRouteEntry->oIfIdx;

        pxRouteEntry->oIfIdx =
          (OCTET) IpTableMsg(IPTABLEMSG_GETIFIDX, (H_NETDATA)&xIpEntry);
        if (pxRouteEntry->oIfIdx == NETIFIDX_ANY) {
          pxRouteEntry->dwGateway = 0x0;
          pxRouteEntry->oIfIdx = NETIFIDX_ANY;
          lRv = -1;
        }
      }
      return lRv;


    case IPADDRT_UNKNOWN:
      /*
       * Just send it to the default gateway.
       */
      break;

    case IPADDRT_MULTICAST:
    case IPADDRT_MULTICASTJOINED:
      /*
       * If the interface is not provided, just send it to the default gateway.
       */
      if (pxRouteEntry->oIfIdx != NETIFIDX_ANY) {
        pxRouteEntry->dwGateway = pxRouteEntry->dwDstAddr;
        return lRv;
      }
      break;

    case IPADDRT_OUTSIDE:
    case IPADDRT_MULTICASTJOINEDPROXY:
    case IPADDRT_MULTICASTJOINEDSOCKPROXY:
      DLLIST_head(&pxRoutingTable->dllRoute);

      while( (pxRoute = DLLIST_read(&pxRoutingTable->dllRoute)) != NULL){

        if (((pxRouteEntry->oIfIdx == NETIFIDX_ANY) ||
             (pxRouteEntry->oIfIdx == pxRoute->oIfIdx))
            /* The stored route will have its interface set:
               no need to check for IDX_ANY */
            &&
            ((pxRouteEntry->wVlan == NETVLAN_ANY) ||
             (pxRoute->wVlan == NETVLAN_ANY) ||
             ((pxRouteEntry->wVlan & NETVLAN_VIDMASK) ==
                (pxRoute->wVlan & NETVLAN_VIDMASK)))) {
          /* If the interface indexes/Vlan are compatible */
          /*
           * Look for host specific route
           */
          if (pxRoute->dwSubnetMask == 0xFFFFFFFF) {
            if (pxRouteEntry->dwDstAddr == pxRoute->dwDstAddr) {
              /* The route has been found */
              break;
            }
          }

          /*
           * Track network specific route. Will be used
           * in case host specific route is not found.
           * Track bridged and routed idxs separately
           */
          if (((pxRouteEntry->dwDstAddr ^ pxRoute->dwDstAddr)
                & pxRoute->dwSubnetMask) == 0) {
            if ((pxRoutingTable->dwfBridgedIdx & ((DWORD)1 << pxRoute->oIfIdx))&&
                (pxRoute->dwSubnetMask > dwSubnetMaskTempBr)) {
              pxNetRouteTempBr = pxRoute;
              dwSubnetMaskTempBr = pxRoute->dwSubnetMask;
            }
#if 0 /* RS modified this condition to handle first case and link down */
            else if (pxRoute->dwSubnetMask > dwSubnetMaskTempRt)
#else
            else if ((pxNetRouteTempRt == NULL ||
                      pxRoute->dwSubnetMask > dwSubnetMaskTempRt) &&
                     pxRoutingTable->abIsLinkUp[pxRoute->oIfIdx] == TRUE)
#endif
            {
                pxNetRouteTempRt = pxRoute;
                dwSubnetMaskTempRt = pxRoute->dwSubnetMask;
            }
          }

        }
        DLLIST_next(&pxRoutingTable->dllRoute);
      }
      break;

    default:
      ASSERT(0);
      return -1;
  }



  /*
   * Use the network specific route if no host specific route was
   * found.  Use routes on routed idxs in preference to bridged idxs
   */
  if (pxRoute == NULL) {
    pxRoute = pxNetRouteTempRt;
  }

  if (pxRoute == NULL) {
    pxRoute = pxNetRouteTempBr;
  }


  if (pxRoute == NULL) {
#ifdef ROUTINGTABLE_BESTDEFAULTROUTE
    /*
     * Check if there is a default gateway which can be reached thru' the
     * given interface.
     */
    if (pxRouteEntry->oIfIdx != NETIFIDX_ANY) {
      pxRoute = _RoutingTableFindDefaultRouteOnIf(pxRoutingTable, pxRouteEntry->oIfIdx);
    }
#endif
  }


  if (pxRoute == NULL) {
    /*
     * Use the best default gateway if no specific routes were
     * found.
     */
    if (pxRoutingTable->pxBestDefaultGw == NULL) {

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_ERROR))
      {
        /*ROUTINGTABLE_DBGP(ERROR,
                        "!! _RoutingTableFindRoute: can't find a gateway for dwDstAddr=%ld.%ld.%ld.%ld\n",
                        IPADDRDISPLAY(pxRouteEntry->dwDstAddr));*/
        DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "!! _RoutingTableFindRoute: can't find a gateway for dwDstAddr = ", pxRouteEntry->dwDstAddr);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }
      /*Set the route to 0*/
      MOC_MEMSET((ubyte *)pxRouteEntry,0x00,sizeof(ROUTEENTRY));

      lRv = -1;

    } else {

      pxRoute = pxRoutingTable->pxBestDefaultGw;

    }
  }


  if (pxRoute != NULL) {
    OCTET eDstAddrType = pxRouteEntry->eDstAddrType;
    MOC_MEMCPY((ubyte *)pxRouteEntry, (ubyte *)pxRoute, sizeof(ROUTEENTRY));
    pxRouteEntry->eDstAddrType = eDstAddrType;

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTINGTABLE, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ROUTINGTABLE_DBGP(REPETITIVE,
                      "_RoutingTableFindRoute<=DstAddr=%ld.%ld.%ld.%ld,Subnet=%ld.%ld.%ld.%ld,Gateway=%ld.%ld.%ld.%ld,If:%d\n",
                      IPADDRDISPLAY(pxRouteEntry->dwDstAddr),
                      IPADDRDISPLAY(pxRouteEntry->dwSubnetMask),
                      IPADDRDISPLAY(pxRouteEntry->dwGateway),
                      pxRouteEntry->oIfIdx);*/
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_RoutingTableFindRoute<=DstAddr = ", pxRouteEntry->dwDstAddr);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Subnet = ", pxRouteEntry->dwSubnetMask);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Gateway = ", pxRouteEntry->dwGateway);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", If : ", pxRouteEntry->oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
  }
#endif /*end of _RADIX_ROUTING_ON_*/
  return lRv;
}

#ifdef ROUTINGTABLE_BESTDEFAULTROUTE
/*****************************************************************************
 *
 * _RoutingTableUpdateBestDefaultRoute
 *
 *****************************************************************************/
static LONG _RoutingTableUpdateBestDefaultRoute(ROUTINGTABLESTATE *pxRoutingTable)
{
  LONG lRv = NETERR_NOERR;
  ROUTEENTRY *pxRoute;
  ROUTEENTRY *pxBestDefaultGwRt = NULL, *pxBestDefaultGwBr = NULL;

  DLLIST_head(&pxRoutingTable->dllRoute);

  while( (pxRoute = DLLIST_read(&pxRoutingTable->dllRoute)) != NULL){

    if ((pxRoute->dwDstAddr == ROUTINGTABLE_DEFAULT_DESTINATION) ||
        (pxRoute->dwSubnetMask == ROUTINGTABLE_DEFAULT_DESTINATION)) {

      if (pxRoutingTable->dwfBridgedIdx & ((DWORD)1 << pxRoute->oIfIdx)) {
        if (pxBestDefaultGwBr == NULL) {
          pxBestDefaultGwBr = pxRoute;
        } else if (pxRoute->wMetric < pxBestDefaultGwBr->wMetric) {
          pxBestDefaultGwBr = pxRoute;
        }
      } else {
        if (pxBestDefaultGwRt == NULL) {
          pxBestDefaultGwRt = pxRoute;
        } else if (pxRoute->wMetric < pxBestDefaultGwRt->wMetric) {
          pxBestDefaultGwRt = pxRoute;
        }
      }
    }

    DLLIST_next(&pxRoutingTable->dllRoute);
  }

  if (pxBestDefaultGwRt != NULL) {
    pxRoutingTable->pxBestDefaultGw = pxBestDefaultGwRt;
  } else if (pxBestDefaultGwBr != NULL) {
    pxRoutingTable->pxBestDefaultGw = pxBestDefaultGwBr;
  }

  return lRv;
}
#endif /* ROUTINGTABLE_BESTDEFAULTROUTE */


#ifdef ROUTINGTABLE_BESTDEFAULTROUTE
/*****************************************************************************
 *
 * _RoutingTableFindDefaultRouteOnIf
 *
 *****************************************************************************/
static ROUTEENTRY* _RoutingTableFindDefaultRouteOnIf(ROUTINGTABLESTATE *pxRoutingTable,
                                                     OCTET             oIfIdx)
{
  ROUTEENTRY* pxRoute = NULL;

  DLLIST_head(&pxRoutingTable->dllRoute);

  while((pxRoute = DLLIST_read(&pxRoutingTable->dllRoute)) != NULL) {

    if (((pxRoute->dwDstAddr == ROUTINGTABLE_DEFAULT_DESTINATION) ||
         (pxRoute->dwSubnetMask == ROUTINGTABLE_DEFAULT_DESTINATION)) &&
        (pxRoute->oIfIdx == oIfIdx)) {
      break;
    }

    DLLIST_next(&pxRoutingTable->dllRoute);
  }

  return pxRoute;
}
#endif /* ROUTINGTABLE_BESTDEFAULTROUTE */




#ifdef ROUTINGTABLE_STATIC
/*****************************************************************************
 *
 * _RoutingTableSetStaticRoute
 *
 *****************************************************************************/
static LONG _RoutingTableSetStaticRoute(ROUTINGTABLESTATE *pxRoutingTable,
                                               STATICROUTEENTRY  *pxStaticRouteEntry)
{
  LONG lRv = NETERR_NOERR;
  DWORD dwIdx = pxStaticRouteEntry->dwIndex;
  ROUTEENTRY *pxRoute;
  ROUTEENTRY xRouteEntry;
  struct rtentry* pxRtEntry;

#ifndef _RADIX_ROUTING_ON_
  ASSERT(dwIdx < ROUTINGTABLE_MAX_NUM_STATIC_ROUTES);

  /*
   * Search and remove the existing static route entry.
   */
  if (pxRoutingTable->apxStaticRoutes[dwIdx] != NULL) {
    DLLIST_head(&pxRoutingTable->dllRoute);

    pxRoute = DLLIST_find(&pxRoutingTable->dllRoute,
                          pxRoutingTable->apxStaticRoutes[dwIdx],
                          NULL);
    ASSERT(pxRoute);
    _RoutingTableDelRoute(pxRoutingTable, pxRoute);
  }

  pxRoutingTable->apxStaticRoutes[dwIdx] = NULL;

  if (pxStaticRouteEntry->bNullifyEntry == TRUE) {
    return lRv;
  }
#endif /*end of _RADIX_ROUTING_ON_*/

  /*
   * Add new route
   * TODO: Need to work out the details of routes with
   *       a better metric and how dynamic/static routes
   *       advertised in such a case.
   */
  pxRtEntry = pxStaticRouteEntry->pxRtEntry;
#ifdef _RADIX_ROUTING_ON_
  /*return lRv;  Skipping addition of static routes. Would be opened up
                 once the configuration code comes in*/
  xRouteEntry.xRouteNodes->RadixNodeKey =
    ((struct sockaddr_in*) &pxRtEntry->rt_dst)->sin_addr.s_addr;
  xRouteEntry.xRouteNodes->RadixNodeMask =
    ((struct sockaddr_in*) &pxRtEntry->rt_genmask)->sin_addr.s_addr;
#else
  xRouteEntry.dwDstAddr =
    ((struct sockaddr_in*) &pxRtEntry->rt_dst)->sin_addr.s_addr;
  xRouteEntry.dwSubnetMask =
    ((struct sockaddr_in*) &pxRtEntry->rt_genmask)->sin_addr.s_addr;
#endif
  xRouteEntry.dwGateway =
    ((struct sockaddr_in*) &pxRtEntry->rt_gateway)->sin_addr.s_addr;
  xRouteEntry.wMetric = pxRtEntry->rt_metric;
  xRouteEntry.oIfIdx = pxRtEntry->rt_ifindex;
  xRouteEntry.wVlan = NETVLAN_ANY;
  xRouteEntry.wTOS = 0;

  {
    IPTABLEENTRY xIpEntry;

#ifdef _RADIX_ROUTING_ON_
    xIpEntry.dwAddr = xRouteEntry.xRouteNodes->RadixNodeKey;
#else
    xIpEntry.dwAddr = xRouteEntry.dwDstAddr;
#endif
    xIpEntry.oIfIdx = xRouteEntry.oIfIdx;
    xIpEntry.wDefaultVlan = xRouteEntry.wVlan;

    xRouteEntry.eDstAddrType = IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry);
  }

  _RoutingTableAddRoute(pxRoutingTable,
                        &xRouteEntry,
                        RTF_STATIC,
                        &pxRoute);
#ifndef _RADIX_ROUTING_ON_
  pxRoutingTable->apxStaticRoutes[dwIdx] = pxRoute;
#endif
  return lRv;
}
#endif /* ROUTINGTABLE_STATIC */


#ifdef ROUTINGTABLE_RETRIEVE
/*****************************************************************************
 *
 * _RoutingTableGetRouteEntry
 *
 *****************************************************************************/
static LONG _RoutingTableGetRouteEntry(ROUTINGTABLESTATE *pxRoutingTable,
                                              ROUTEGETROUTE *pxRouteGetRoute)
{
  LONG lRv = NETERR_NOERR;
  ROUTEENTRY *pxRoute;
  DWORD dwRtCnt = 0;
  DWORD dwBufSize = pxRouteGetRoute->dwBufSize;
  struct rtentry* pxRtEntry;
#ifdef _RADIX_ROUTING_ON_
  RADIXNODE *pxRadixNodeRoute = NULL;
#endif

#ifdef _RADIX_ROUTING_ON_
  LIST_FOREACH(pxRadixNodeRoute, &(pxRoutingTable->pxRadixTree->xRadixNodeList), xRadixNodeLink)
#else
  DLLIST_head(&pxRoutingTable->dllRoute);
  while (((pxRoute = DLLIST_read(&pxRoutingTable->dllRoute)) != NULL) &&
         dwBufSize)
#endif /*end of _RADIX_ROUTING_ON_ */
  {
#ifdef _RADIX_ROUTING_ON_
    pxRoute = (ROUTEENTRY *)pxRadixNodeRoute;
    ((struct sockaddr_in*) &pxRtEntry->rt_dst)->sin_addr.s_addr =
      ntohl(pxRoute->xRouteNodes->RadixNodeKey);
    ((struct sockaddr_in*) &pxRtEntry->rt_genmask)->sin_addr.s_addr =
      ntohl(pxRoute->xRouteNodes->RadixNodeMask);
#else
    pxRtEntry = &pxRouteGetRoute->pxRtEntries[dwRtCnt];
    ((struct sockaddr_in*) &pxRtEntry->rt_dst)->sin_addr.s_addr =
      pxRoute->dwDstAddr;
    ((struct sockaddr_in*) &pxRtEntry->rt_genmask)->sin_addr.s_addr =
      pxRoute->dwSubnetMask;
#endif /*end of _RADIX_ROUTING_ON_*/
    ((struct sockaddr_in*) &pxRtEntry->rt_gateway)->sin_addr.s_addr =
      pxRoute->dwGateway;
    pxRtEntry->rt_metric = pxRoute->wMetric;
    pxRtEntry->rt_ifindex = pxRoute->oIfIdx;
    pxRtEntry->rt_flags = pxRoute->oType;

    dwRtCnt ++;
    dwBufSize --;

#ifndef _RADIX_ROUTING_ON_
    DLLIST_next(&pxRoutingTable->dllRoute);
#endif
  }

#ifndef _RADIX_ROUTING_ON_
  DEBUG(if (dwBufSize == 0) {
    ASSERT(dwRtCnt == DLLIST_count(&pxRoutingTable->dllRoute));
  });
#endif /*end of _RADIX_ROUTING_ON_*/

  *pxRouteGetRoute->pdwOutSize = dwRtCnt;

  return lRv;
}
#endif /* ROUTINGTABLE_RETRIEVE */

static LONG _RoutingTableGetDefaultIdx(ROUTINGTABLESTATE *pxRoutingTable)
{
  int iDx = 0;
  ROUTEENTRY *pxRoute;

#ifdef _RADIX_ROUTING_ON_
  ROUTEENTRY xRoute;
  ubyte4 dwIfIdx = 0;
  xRoute.xRouteNodes->RadixNodeKey  = ROUTINGTABLE_DEFAULT_DESTINATION;
  xRoute.xRouteNodes->RadixNodeMask = ROUTINGTABLE_DEFAULT_DESTINATION;
  dwIfIdx = _RoutingTableFindRoute(pxRoutingTable, &xRoute);
  if(dwIfIdx == NETERR_NOERR)
    dwIfIdx = xRoute.oIfIdx;
  else
    dwIfIdx = 0;
  return dwIfIdx;
#else
  DLLIST_head(&pxRoutingTable->dllRoute);

  while((pxRoute = DLLIST_read(&pxRoutingTable->dllRoute)) != NULL) {

    if ((pxRoute->dwDstAddr == ROUTINGTABLE_DEFAULT_DESTINATION) &&
        (pxRoute->dwSubnetMask == ROUTINGTABLE_DEFAULT_DESTINATION)) {
      return pxRoute->oIfIdx;
    }
    iDx++;
    DLLIST_next(&pxRoutingTable->dllRoute);
  }

  return (LONG)0;
#endif /*end of _RADIX_ROUTING_ON_*/
}


void RoutingTableDisplay(ROUTINGTABLESTATE *pxRoutingTable, ubyte *poSbuf, ubyte4 *pdwSbufWritten)
{
  ROUTEENTRY *pxRoute;
  struct in_addr xInAddr;
  if(poSbuf)
  {
#ifdef __MOC_CLI__
    ubyte4 dwNumCharWritten = 0;
    ubyte *poOrig = poSbuf;
#ifdef _RADIX_ROUTING_ON_
    RADIXNODE *pxRadixIter = NULL;
#endif

    dwNumCharWritten = sprintf(poSbuf, " Routing Table:\n");
    poSbuf += dwNumCharWritten + 1;
    dwNumCharWritten = sprintf(poSbuf, "%s - %s - %s - %s - %s - %s - %s - %s\n",
                               "Destination",
                               "Subnet Mask",
                               "Gateway",
                               "Type",
                               "TOS",
                               "Metric",
                               "Interface",
                               "Vlan");
    poSbuf += dwNumCharWritten + 1;

#ifdef _RADIX_ROUTING_ON_
    LIST_FOREACH(pxRadixIter, &(pxRoutingTable->pxRadixTree->xRadixNodeList), xRadixNodeLink)
    {
      pxRoute = (ROUTEENTRY *)(pxRadixIter);

      xInAddr.s_addr = (in_addr_t)pxRoute->xRouteNodes->RadixNodeKey;
      dwNumCharWritten = sprintf(poSbuf, "%s - ", inet_ntoa(xInAddr));
      poSbuf += dwNumCharWritten + 1;

      xInAddr.s_addr = (in_addr_t)pxRoute->xRouteNodes->RadixNodeMask;
      dwNumCharWritten = sprintf(poSbuf, "%s - ", inet_ntoa(xInAddr));
      poSbuf += dwNumCharWritten + 1;

      xInAddr.s_addr = (in_addr_t)(htonl(pxRoute->dwGateway));
      dwNumCharWritten = sprintf(poSbuf, "%s - ", inet_ntoa(xInAddr));
      poSbuf += dwNumCharWritten + 1;

      dwNumCharWritten = sprintf(poSbuf, "%d - %d - %d - %d - %d\n",
                                 pxRoute->oType,
                                 pxRoute->wTOS,
                                 pxRoute->wMetric,
                                 pxRoute->oIfIdx,
                                 pxRoute->wVlan);

      poSbuf += dwNumCharWritten;
      *pdwSbufWritten = (poSbuf - poOrig);
    }
#endif /*end of _RADIX_ROUTING_ON_*/

#endif /*end of __MOC_CLI__*/
  }
  else
  {
#ifdef _RADIX_ROUTING_ON_
    /*Ajit get the printing enabled : this is done, but has prints in it...*/
#else
    printf("Routing Table:\n");
    printf("%15s\t%15s\t%15s\t%4s\t%3s\t%6s\t%9s\t%4s\n",
           "Destination",
           "Subnet Mask",
           "Gateway",
           "Type",
           "TOS",
           "Metric",
           "Interface",
           "Vlan");
    printf("%15s\t%15s\t%15s\t%4s\t%3s\t%6s\t%9s\t%4s\n",
           "---------------",
           "---------------",
           "---------------",
           "----",
           "---",
           "------",
           "---------",
           "----");


    DLLIST_head(&pxRoutingTable->dllRoute);

    while( (pxRoute = DLLIST_read(&pxRoutingTable->dllRoute)) != NULL){
      xInAddr.s_addr = (in_addr_t)pxRoute->dwDstAddr;
      printf("%15s\t", inet_ntoa(xInAddr));

      xInAddr.s_addr = (in_addr_t)pxRoute->dwSubnetMask;
      printf("%15s\t", inet_ntoa(xInAddr));

      xInAddr.s_addr = (in_addr_t)pxRoute->dwGateway;
      printf("%15s\t", inet_ntoa(xInAddr));

      printf("%4d\t%3d\t%6d\t%9d\t%4d\n",
             pxRoute->oType,
             pxRoute->wTOS,
             pxRoute->wMetric,
             pxRoute->oIfIdx,
             pxRoute->wVlan);

      DLLIST_next(&pxRoutingTable->dllRoute);
    }
#endif
  }
}

#ifdef _RADIX_ROUTING_ON_
static void _FreeRouteEntry(RADIXNODE **ppxRadixNodeEntry)
{
  ROUTEENTRY *pxRoute = (ROUTEENTRY *)(*ppxRadixNodeEntry);
  MOC_FREE((void **) &pxRoute);
}
#endif
