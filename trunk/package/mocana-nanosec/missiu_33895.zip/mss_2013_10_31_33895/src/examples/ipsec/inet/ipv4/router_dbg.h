/*
 * router_dbg.h
 *
 * Router module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ROUTER_DBG_H_
#define _ROUTER_DBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef ROUTERDBG_HI
   #define ROUTERDBG_HI
  #endif
 #endif

#else
 #ifdef ROUTERDBG_HI
  #undef ROUTERDBG_HI
 #endif
#endif

#include "netdbg.h"

#define ROUTER_MAGIC_COOKIE 0x726f7574 /*"rout" = 0x726f7574*/


/*#ifdef ROUTERDBG_HI*/
#if defined(ROUTERDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define ROUTER_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == ROUTER_MAGIC_COOKIE));

  #define ROUTER_SET_COOKIE(x) (x)->dwMagicCookie = ROUTER_MAGIC_COOKIE
  #define ROUTER_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define ROUTER_DBGP(level, fmt, args...) do { \
    if (level <= g_dwRouterDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define ROUTER_DBG(level, x) do {  \
    if (level <= g_dwRouterDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define ROUTER_DBG_VAR(x)  x
#else
  #define ROUTER_CHECK_STATE(x)
  #define ROUTER_SET_COOKIE(x)
  #define ROUTER_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define ROUTER_DBGP
#else
  #define ROUTER_DBGP(level, fmt, args...)
#endif
  #define ROUTER_DBG(level, x)
  #define ROUTER_DBG_VAR(x)
#endif

ROUTER_DBG_VAR(MOC_EXTERN DWORD g_dwRouterDebugLevel);

#define DBGLVL_ERROR_RARE 1
#define DBGLVL_NORMAL     2
#define DBGLVL_REPETITIVE 3

#endif /* #ifndef _ROUTER_DBG_H_ */
