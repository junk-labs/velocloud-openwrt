/*///////////////////////////////////////////////////////////////////////////
//
// ntpapi.h
//
// API header file for the NTP library
//
///////////////////////////////////////////////////////////////////////////*/
#ifndef __NTPAPI_H__
#define __NTPAPI_H__

#include "NNstyle.h"
#include "time.h"

/* NtpInit. Initializes Ntp module and starts acquisition of NTP time. */
/* dwIPaddress specifies NTP server (0 means use current selection) */
void NtpInit(DWORD dwIPAddress);

/* NtpTerm. Terminates Ntp module and release and resources */
void NtpTerm();

/* NtpGet. Retrieves the NTP time. Return value is TRUE if NTP time */
/* is good. FALSE if it is incorrect (unsynced) */
/* (NTP=Network Time Protocol since Jan 1, 1900 in units of ~200 pico secs. */
/* See RFC1305) */
int NtpGet(DWORD *upper, DWORD *lower);

/* NtpGetAtp. Retrieves the ATP time. Return value is TRUE */
/* if the time is good, FALSE if it is incorrect (unsynced) */
/* (ATP= Ancient Time Protocol since Oct 15, 1582 in units of ~100 nano secs) */
int NtpGetAtp(DWORD *upper, DWORD *lower);

/* NtpGetLocaltime. Returns the local (timezone/dst corrected) time.
Return value is TRUE id time is valid (NTP time valid, and conversion
succesfull), FLASE otherwise. lTimeZone is minutes difference from GMT. */

int NtpGetLocaltime(struct tm *pTmTime, LONG lTimeZone, BOOL bDSTObserved);

#endif /* __NTPAPI_H__*/

