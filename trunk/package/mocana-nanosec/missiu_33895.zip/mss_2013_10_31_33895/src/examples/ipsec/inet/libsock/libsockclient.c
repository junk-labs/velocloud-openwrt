
#include "NNstyle.h"
#include "sys/socket.h"
#include "netinet/in.h"
#include "arpa/inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "../common/moc_ip.h"

#include "../utils/mocinclude.h"
#include "libsock.h"
#include "../utils/ipc.h"
#include "../utils/modules.h"
/*---------------------------------------------------------------------------*/


void
SOCKCLIENT_receiveMsg(_ipc_msg_t *ipc_req)
{


}

/*---------------------------------------------------------------------------*/
extern MSTATUS
SOCKCLIENT_init()
{
    MSTATUS status = OK;

    status = IPC_registerModule (LIBSOCK_MOD_ID, SOCKCLIENT_receiveMsg );

    return status;
}

/*---------------------------------------------------------------------------*/

extern sbyte4 
socket(sbyte4 family, sbyte4 type, sbyte4 protocol)
{


    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    status = IPC_alloc(sizeof(*sockMsg),&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    if (OK > status)
        goto exit;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_SOCKET;
    sockMsg->msg.socketcmd.family = family;
    sockMsg->msg.socketcmd.type = type;
    sockMsg->msg.socketcmd.protocol = protocol;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }

    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    /* Verify that the sockMsg packet is socket Reply */;
    if (MN_SOCKET_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    fd = sockMsg->msg.socketcmdreply.sockfd; 

exit:
     
    if (ipc_req)
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    if (OK > status)
        return status; 
    else
        return fd; 
}

/*---------------------------------------------------------------------------*/

extern sbyte4 
bind(sbyte4 sockfd, const struct sockaddr *sockAddr,ubyte4 sockAddrLen)
{
    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!sockAddr) || (!sockAddrLen))
    {
        status =  ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    status = IPC_alloc(sizeof(*sockMsg),&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_BIND;
    sockMsg->msg.bindcmd.sockfd = sockfd;
    MOC_MEMCPY((ubyte*)&sockMsg->msg.bindcmd.sockAddr,(ubyte*)sockAddr,sockAddrLen);
    sockMsg->msg.bindcmd.szSockAddr = sockAddrLen;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }
    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    /* Verify that the sockMsg packet is socket Reply */;
    if (MN_BIND_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 
}

/*---------------------------------------------------------------------------*/

extern sbyte4 
listen(sbyte4 sockfd, ubyte4 backlog)
{
    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!backlog))
    {
        status = ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    status = IPC_alloc(sizeof(*sockMsg),&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_LISTEN;
    sockMsg->msg.listencmd.sockfd = sockfd;
    sockMsg->msg.listencmd.backlog = backlog;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }
    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    /* Verify that the sockMsg packet is socket Reply */;
    if (MN_LISTEN_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;

exit:
     
    if (ipc_req)
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 
}
extern sbyte4
connect(sbyte4 sockfd, const struct sockaddr *servAddr, socklen_t addrLen,
		mn_sock_connect_cb_t cb, void *cbarg) 
{
    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!servAddr) || (!addrLen))
    {
        status =  ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    status = IPC_alloc(sizeof(*sockMsg),&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_CONNECT;
    sockMsg->msg.connectcmd.sockfd = sockfd;
    MOC_MEMCPY((ubyte*)&sockMsg->msg.connectcmd.sockAddr,(ubyte*)servAddr,addrLen);
    sockMsg->msg.connectcmd.szSockAddr = addrLen;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }
    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    if (MN_CONNECT_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 
}

/*---------------------------------------------------------------------------*/

extern sbyte4
send(sbyte4 sockfd, ubyte *buff, ubyte4 nbytes, sbyte4 iFlags)
{

    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!buff) || (!nbytes))
    {
        status =  ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    status = IPC_alloc(sizeof(*sockMsg) + nbytes,&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg) + nbytes) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_SEND;
    sockMsg->msg.sendcmd.sockfd = sockfd;
    sockMsg->msg.sendcmd.bufSize = nbytes;
    sockMsg->msg.sendcmd.flags = iFlags;
    MOC_MEMCPY((ubyte *)sockMsg->msg.sendcmd.buff , buff, nbytes);

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }
    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    if (MN_SEND_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 

}

/*---------------------------------------------------------------------------*/
ssize_t sendto(int lsockfd, void *buff, size_t nbytes, int iFlags, 
               const struct sockaddr *to, socklen_t addrlen)
{

    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!buff) || (!nbytes))
    {
        status =  ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    status = IPC_alloc(sizeof(*sockMsg) + nbytes,&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg) + nbytes) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_SENDTO;
    sockMsg->msg.sendtocmd.sockfd = lsockfd;
    sockMsg->msg.sendtocmd.bufSize = nbytes;
    sockMsg->msg.sendtocmd.flags = iFlags;
    MOC_MEMCPY((ubyte*)&sockMsg->msg.sendtocmd.sockAddr,(ubyte*)to,addrlen);
    sockMsg->msg.sendtocmd.szSockAddr = addrlen;
    MOC_MEMCPY((ubyte *)sockMsg->msg.sendtocmd.buff , buff, nbytes);

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }

    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    if (MN_SENDTO_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 

}

/*---------------------------------------------------------------------------*/

extern sbyte4
getsockopt(sbyte4 lSockfd, sbyte4 level, sbyte4 optname, ubyte *optval,
              socklen_t *optlen)
{

    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!optlen) || (!(*optlen)) || (!optval))
        return -1;

    status = IPC_alloc(sizeof(*sockMsg) ,&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_GETSOCKOPT;
    sockMsg->msg.getsockoptcmd.sockfd = lSockfd;
    sockMsg->msg.getsockoptcmd.level = level;
    sockMsg->msg.getsockoptcmd.optname = optname;
    sockMsg->msg.getsockoptcmd.optlen = *optlen;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }
    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    if (MN_GETSOCKOPT_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;

    if (OK != status)
    {
        *optlen = sockMsg->msg.getsockoptcmd.optlen;
        if (*optlen)
            MOC_MEMCPY(optval, sockMsg->msg.getsockoptcmd.buff,sockMsg->msg.getsockoptcmd.optlen);
    }

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 

}

/*---------------------------------------------------------------------------*/

#ifndef __MOCANA_ASYNC_API__
int accept(int sockfd, struct sockaddr *from, socklen_t *addrlen
           ,mn_sock_accept_cb_t cb, void *cbarg)
#else
int accept(int sockfd, struct sockaddr *from, socklen_t *addrlen)
#endif
{

    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    status = IPC_alloc(sizeof(*sockMsg) ,&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_ACCEPT;
    sockMsg->msg.acceptcmd.sockfd = sockfd;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }

    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    if (MN_ACCEPT_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    *addrlen = sockMsg->msg.acceptreplycmd.addrLen ;
    if (*addrlen)
        MOC_MEMCPY((ubyte *)from,(ubyte*)&sockMsg->msg.acceptreplycmd.sockAddr,*addrlen);
    if ( OK != sockMsg->errno)
        status = -1;
    else
        status = sockMsg->msg.acceptreplycmd.childfd ;

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 

}

/*---------------------------------------------------------------------------*/

extern sbyte4
recv(sbyte4 sockfd, ubyte *buff, ubyte4 nbytes, sbyte4 iFlags)
{

    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!buff) || (!nbytes))
    {
        status =  ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    status = IPC_alloc(sizeof(*sockMsg) ,&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_RECV;
    sockMsg->msg.recvcmd.sockfd = sockfd;
    sockMsg->msg.recvcmd.bufSize = nbytes;
    sockMsg->msg.recvcmd.flags = iFlags;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }
    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) < sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    if (MN_RECV_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;
    if (OK != status)
        goto exit;

    status = sockMsg->msg.recvcmd.bufSize;

    MOC_MEMCPY(buff, sockMsg->msg.recvcmd.buff,status);

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 

}

/*---------------------------------------------------------------------------*/
ssize_t recvfrom(int lsockfd, void *buff, size_t nbytes, int iFlags, 
               struct sockaddr *from, socklen_t *addrlen)
{

    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!buff) || (!nbytes) || (!from) || (!addrlen))
    {
        status =  ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    status = IPC_alloc(sizeof(*sockMsg) ,&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_RECVFROM;
    sockMsg->msg.recvfromcmd.sockfd = lsockfd;
    sockMsg->msg.recvfromcmd.bufSize = nbytes;
    sockMsg->msg.recvfromcmd.flags = iFlags;
    sockMsg->msg.recvfromcmd.szSockAddr = *addrlen;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }

    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) < sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    if (MN_RECVFROM_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;
    if (OK != status)
        goto exit;

    status = sockMsg->msg.recvfromcmd.bufSize;

    MOC_MEMCPY(buff, sockMsg->msg.recvfromcmd.buff,status);
    *addrlen  = sockMsg->msg.recvfromcmd.szSockAddr ;
    MOC_MEMCPY((ubyte*)from,(ubyte *)&sockMsg->msg.recvfromcmd.sockAddr,*addrlen) ;

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 

}

/*---------------------------------------------------------------------------*/

extern int 
select(int iMaxFdP1, fd_set *pxFdSetRead, fd_set *pxFdSetWrite,
           fd_set *pxFdSetExcept,  struct timeval *pxTvTimeOut)

{
    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    sbyte4     fd = -1;
    MSTATUS  status = OK;

    if ((!pxFdSetRead) && (!pxFdSetWrite) && (!pxFdSetExcept))
    {
        status =  ERR_SOCKET_NULL_PARAMS;
        goto exit;
    }

    status = IPC_alloc(sizeof(*sockMsg) ,&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_SELECT;
    sockMsg->msg.selectcmd.maxSet = iMaxFdP1;
    sockMsg->msg.selectcmd.setMask  = 0;

    if (pxFdSetRead)
    {
        MOC_MEMCPY((ubyte *) &sockMsg->msg.selectcmd.read_set,(ubyte *)pxFdSetRead,sizeof(fd_set));
        sockMsg->msg.selectcmd.setMask  |= READ_SET_SET;
    }
    if (pxFdSetWrite)
    {
        MOC_MEMCPY((ubyte *)&sockMsg->msg.selectcmd.write_set,(ubyte *)pxFdSetWrite,sizeof(fd_set));
        sockMsg->msg.selectcmd.setMask  |= WRITE_SET_SET;
    }
    if (pxFdSetExcept)
    {
        MOC_MEMCPY((ubyte *)&sockMsg->msg.selectcmd.except_set,(ubyte *)pxFdSetExcept,sizeof(fd_set));
        sockMsg->msg.selectcmd.setMask  |= EXCEPT_SET_SET;
    }

    if (pxTvTimeOut)
    {
        MOC_MEMCPY((ubyte *)&sockMsg->msg.selectcmd.timeVal,(ubyte *)pxTvTimeOut,sizeof(struct timeval));
        sockMsg->msg.selectcmd.setMask  |= TIMEVAL_SET;
    }

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }

    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    if (MN_SELECT_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;
    if (OK != status)
        goto exit;

    status = sockMsg->msg.selectreplycmd.numSet;

    if (pxFdSetRead)
        MOC_MEMCPY((ubyte *)pxFdSetRead, (ubyte *)&sockMsg->msg.selectreplycmd.read_set,sizeof(fd_set));
    if (pxFdSetWrite)
        MOC_MEMCPY((ubyte *)pxFdSetWrite, (ubyte *)&sockMsg->msg.selectreplycmd.write_set,sizeof(fd_set));
    if (pxFdSetExcept)
        MOC_MEMCPY((ubyte *)pxFdSetExcept, (ubyte *)&sockMsg->msg.selectreplycmd.except_set,sizeof(fd_set));

exit:
     
    if (ipc_req) 
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 

}
/*---------------------------------------------------------------------------*/

extern sbyte4 
shutdown(sbyte4 sockfd, sbyte4 howto)
{


    _ipc_msg_t *ipc_req = NULL;
    _ipc_msg_t *ipc_reply = NULL;
    ubyte4     timeout = 0;
    sockMsg_t  *sockMsg = NULL;
    MSTATUS  status = OK;

    status = IPC_alloc(sizeof(*sockMsg),&ipc_req);

    if (!ipc_req)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    status = IPC_setMsgHdr(ipc_req,LIBSOCK_CODE_CMD,
                           LIBSOCK_MOD_ID, IP_PROC_ID, 
                           IP_DEFAULT_INST_ID, IP_DEFAULT_NODE_ID, 
                           LIBSOCKSERVER_MOD_ID);
    _IPC_MSG_SET_TOTAL_LEN(ipc_req,sizeof(*sockMsg)) ;

    if (OK > status)
        goto exit;

    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_req); 
    sockMsg->libsockcmd = MN_SHUTDOWN;
    sockMsg->msg.shutdowncmd.sockfd = sockfd;
    sockMsg->msg.shutdowncmd.howto = howto;

    status = IPC_sendSync(ipc_req,timeout,&ipc_reply);

     
    if (OK > status)
    {
        ipc_req = NULL;
        goto exit;
    }

    if (!ipc_reply)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    
    sockMsg = (sockMsg_t *)_IPC_PAYLOAD(ipc_reply); 
    /* Verify that the length of the packet is SockMsg */;
    if (!sockMsg)
    {
        status = ERR_SOCKET_NULL_REPLY;
        goto exit;
    }

    if(_IPC_MSG_PAYLOAD_LEN(ipc_reply) != sizeof(*sockMsg))
    {
        status = ERR_SOCKET_INVALID_LEN;
        goto exit;
    }

    
    /* Verify that the sockMsg packet is socket Reply */;
    if (MN_SHUTDOWN_REPLY != sockMsg->libsockcmd )
    {
        status = ERR_SOCKET_INVALID_MSG;
        goto exit;
    }

    status = sockMsg->errno;

exit:
     
    if (ipc_req)
        IPC_free(ipc_req);
    if (ipc_reply) 
        IPC_free(ipc_reply);

    return status; 
}

/*---------------------------------------------------------------------------*/
