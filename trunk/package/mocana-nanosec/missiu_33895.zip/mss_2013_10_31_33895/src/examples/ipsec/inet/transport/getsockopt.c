/*
 * getsockopt.c
 *
 * implement the getsockopt function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/in.h"
#include "mqueue.h"
#include "dllist.h"
#include "../include/ioctl.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "igmp.h"
#include "netdefs.h"
#include "netutils.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "ethernet.h"


/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * getsockopt
 *  Get options for a socket
 *
 *  Args:
 *   lSockfd                       The socket returned by the socket function.
 *   level                        level at which the option is interpreted.
 *                                Should be SOL_SOCKET. IPPROTO_IP ,
 *                                IP_PROTO_TCP : Future implementation.
 *   optname                      The name of the option itself.
 *                                See table 1.1 below.
 *   optval                       Pointer to a variable into which the current
 *                                value of the option is stored.
 *   optlen                       Pointer to the size of the data stored in
 *                                'optval'.
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int mn_getsockopt(int lSockfd, int level, int optname, void *optval,
               socklen_t *optlen)
{
  SOCKET *pxSock;
  NETWORKID *pxNetId;
  LONG lReturn = -1;

#ifdef STRICT_POSIX
  /* If length of the option is too big, return error */
  if (*optlen > MLEN) {
    mn_errno = MO_EBADARG;
    return -1;
  }

  /* If pointer is NULL, return error */
  if (optval == 0 ) {
    mn_errno = MO_EFAULT;
    return -1;
  }
#else
  ASSERT((*optlen <=  MLEN) && (optval != 0 ));
#endif

  SOCKET_CHECKFD(lSockfd);

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  if ((pxSock = RETRIEVE_SOCKET(lSockfd)) == NULL) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  pxNetId = (NETWORKID *) &(pxSock->xTransportId.xNetId);

  switch(level) {
  case SOL_SOCKET:
    switch(optname) {
    case SO_LINGER:
      /* check struct linger len etc */
      *optlen = sizeof(struct linger);
      if (pxSock->lType == SOCK_STREAM) {
    ((struct linger *) optval)->l_linger = pxSock->dwLingerTimeOut;
    ((struct linger *) optval)->l_onoff = pxSock->dwSockOptions &
          SO_LINGER;
      }
      lReturn = 0;
      *optlen = sizeof(struct linger);
      break;
      /* Boolean options */
#if TRIM_CODE
    case SO_DEBUG:
    case SO_KEEPALIVE:
    case SO_DONTROUTE:
    case SO_USELOOPBACK:
    case SO_BROADCAST:
    case SO_REUSEADDR:
    case SO_OOBINLINE:
      if (pPCBPtr->nSockOptions & optname) *((int *) optval) = 1;
      else *((int *) optval) = 0;
      lReturn = 0;
      *optlen = sizeof(int);
      break;

    case SO_SNDBUF:
    case SO_RCVBUF:
    case SO_SNDLOWAT:
    case SO_RCVLOWAT:
    case SO_SNDTIMEO:
    case SO_RCVTIMEO:
      mn_errno = MO_EINVAL;
      /* Not implemented */
      break;
#endif
    case SO_ERROR:
      /* temporary setting */
      *((int *) optval) = 0;
      lReturn=0;
    break;

    case SO_VLAN:
      /* Get the VLAN of this socket */
      /* check struct length */
      if (*optlen != sizeof(struct vlan)) {
        lReturn = -1;
          mn_errno = EBADARG;
          break;
      }
      ((struct vlan *) optval)->bVlanOnOff =
          (pxSock->oBoundFlag & SOCKETBOUNDFLAG_VLAN);
      ((struct vlan *) optval)->wVlanProto = VLAN_TYPE;
      if (pxNetId->wVlan == NETVLAN_DEFAULT){
        ((struct vlan *) optval)->wVlanTCI = 0;
      } else {
        ((struct vlan *) optval)->wVlanTCI = pxNetId->wVlan;
      }
      lReturn = 0;
      break;

    default:
      mn_errno = MO_ENOPROTOOPT;
      break;
    }
    break;
  case IPPROTO_TCP:
  case IPPROTO_IP:
    switch(optname) {
    case IP_TOS:
      *((int *) optval) = pxNetId->oToS;
      lReturn = 0;
      *optlen = sizeof(int);
      break;
    }
    break;

  default:
    mn_errno = MO_ENOPROTOOPT;
    break;
  }

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return lReturn;
}
