#ifndef __FLAVOR_H__
#define __FLAVOR_H__

/* Map the build flavor into more meaningful constants internal
 * to the library.  The constant _FLAVOR_myflavor where myflavor is
 * the build flavor will be defined by the build environment.
 *
 * Be sure to check that a valid build flavor is defined.
 *
 * This file should be included by all source files.
*/

#if defined(_FLAVOR_gn)
/* original
  #define SOCK_EP1
  #define IFNUMMAX 1
*/
  #define SOCK_EP1
  #define IFNUMMAX NUM_IFS
  #define SOCK_MULTIF
#elif defined (_FLAVOR_ep0u) || defined (_FLAVOR_ep0)
  #define SOCK_EP0
  #define IFNUMMAX 1
#elif defined (_FLAVOR_ep0d)
  #define SOCK_EP0
  #define IFNUMMAX 1
#elif defined (_FLAVOR_ep1u) || defined (_FLAVOR_ep1)
  #define SOCK_EP1
  #define IPSEC
  #define SOCK_PPP
  #define IFNUMMAX 1
#elif defined (_FLAVOR_ep1d)
  #define SOCK_EP1
  #define IPSEC
  #define SOCK_PPP
  #define IFNUMMAX 1
#elif defined (_FLAVOR_br)
  #define SOCK_BR
  #define MAC_DRIVER_NO_FILTERING
  #define SOCK_MULTIF
  #define IPSEC
  #define SOCK_PPP
  #define IFNUMMAX 2
#elif defined (_FLAVOR_rt)
  #define SOCK_RT
  #define SOCK_BR
  #define MAC_DRIVER_NO_FILTERING
  #define SOCK_MULTIF
  #define IPSEC
  #define SOCK_PPP
  #define IFNUMMAX 2
  #define SOCK_IPTABLEMCAST
#elif defined (_FLAVOR_dslrt)
  #define SOCK_RT
  #define SOCK_BR
  #define MAC_DRIVER_NO_FILTERING
  #define SOCK_MULTIF
  #define IPSEC
  #define SOCK_PPP
  #define SOCK_ATM
  #define IFNUMMAX 9
  #define SOCK_IPTABLEMCAST
#elif defined (_FLAVOR_dslvrt)
  #define SOCK_RT
  #define SOCK_BR
  #define MAC_DRIVER_NO_FILTERING
  #define SOCK_MULTIF
  #define IPSEC
  #define SOCK_PPP
  #define SOCK_ATM
  #define IFNUMMAX 3
  #define SOCK_IPTABLEMCAST
#else
  #error "unknown build flavor"
#endif

#endif

