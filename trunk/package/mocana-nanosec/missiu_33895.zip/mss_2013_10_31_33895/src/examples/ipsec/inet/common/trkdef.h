/*
 * trkdef.h
 *
 * defs for the tracking data, needed for trk data analysis tools
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __TRKDEF_H
#define __TREDEF_H


#include "NNstyle.h"


/*
 * allowed Tracking Users
 *
 * WARNING: dont change any value, just add values... otherwise someone's
 *        tracker tokens file will be no good
 */
typedef enum {
  TRKUSER_DUPLICATE    = 0x00,    /* place holder for duplicate users         */

  TRKUSER_SCHEDULER    = 0x01,    /* System Scheduler                 */

  TRKUSER_VIDENCVP    = 0x02,    /* Video Encode VP Instantiation         */
  TRKUSER_VIDENCHUFF    = 0x03,    /* Video Encode Huffman                 */

  TRKUSER_VIDDECVP    = 0x04,    /* Video Decode VP                 */
  TRKUSER_VIDDECHUFF    = 0x05,    /* Video Decode Huffman                 */

  TRKUSER_CAPTURE    = 0x06,    /* Video Capture process             */

  TRKUSER_DISPLAY    = 0x07,    /* Video Display process             */

  TRKUSER_VIDENCVP2    = 0x08,    /* Video Encode VP Instantiation         */
  TRKUSER_VIDENCVP3    = 0x09,    /* Video Encode VP Instantiation         */
  TRKUSER_VIDENCVP4    = 0x0A,    /* Video Encode VP Instantiation         */

  TRKUSER_ENUMMAX        /* *** must be LAST in enum ***             */
} E_TRK_USER;


/*
 * alternate or main tracking
 *
 * can be used as flags or values
 */
typedef enum {
  TRK_MAIN =    0x00000001,
  TRK_ALT =    0x00000002
} E_TRK_ALT_OR_MAIN;


/******************
 *
 *   CONSTANTS
 *
 *****************/

                    /*    check for the end!)    */

#define TRK_MARK    0xDBDBDBDBL
#define TRK_MARK_NBITS    8
#define TRK_MARK_SHIFT    (32 - TRK_MARK_NBITS)
#define TRK_USER_NBITS    8
#define TRK_USER_SHIFT    (32 - TRK_MARK_NBITS - TRK_USER_NBITS)
#define TRK_USER_MAX    ((1 << TRK_USER_NBITS) - 1)
#define TRK_TID_NBITS    8
#define TRK_TID_SHIFT    (32 - TRK_MARK_NBITS - TRK_USER_NBITS - TRK_TID_NBITS)
#define TRK_TID_MAX    ((1 << TRK_TID_NBITS) - 1)
#define TRK_LEN_NBITS    8
#define TRK_LEN_MAX    ((1 << TRK_LEN_NBITS) - 1)

#define TRK_SENTINEL    0xAAAAAAAAL    /* buffer sentinels        */
#define TRK_AVAIL    0xBBBBBBBBL    /* available buffer space    */
                    /*  (also marks pdwTrkNext)    */
#define TRK_WRAPPED    0xCCCCCCCCL    /* wrap location             */
#define TRK_VOID    0xDDDDDDDDL    /* voided entry              */

#define TRK_ENDIAN    0x000000FFL
#define TRK_SW_ENDIAN    0xFF000000L

#define TRK_MEMW_EXT    0xDBDBDBFFL    /* marks wrap for TRK_MEMW    */


#if (8 != TRK_MARK_NBITS)
#error "only 8 bit marker currently supported (in trk and tracker)"
#endif

#if (8 != TRK_USER_NBITS)
#error "only 8 bit user number currently supported (in trk and tracker)"
#endif

#if (8 != TRK_TID_NBITS)
#error "only 8 bit tagid currently supported (in trk and tracker)"
#endif

#if (8 != TRK_LEN_NBITS)
#error "only 8 bit len currently supported (in trk and tracker)"
#endif



/**************************************************************************
 *
 *   TYPEDEFS
 *
 *************************************************************************/


typedef struct {
  DWORD dwMark;
  DWORD *pdwTop;        /* addr of 1st data entry        */
  DWORD *pdwBot;        /* addr past last data entry        */
  DWORD *pdwNext;
  DWORD *pdwWrapTo;
  DWORD dwSkip;            /* # enabled track entries to skip plus 1  */
  DWORD fTrkOn;
  DWORD dwSentinel;
  DWORD dwAvail;
  DWORD dwWrapped;
  DWORD dwVoid;
  DWORD dwDataLen;        /* #bytes of track data            */
  DWORD dwEndian;        /* shows Endian used            */
  WORD  wMarkBits;        /* # bits in marker field        */
  WORD  wUserBits;        /* # bits in user field            */
  WORD  wTidBits;        /* # bits in tagid field        */
  WORD  wLenBits;        /* # bits in length field        */
  DWORD dwPad[1];        /* bring up to 2**n struct size        */
                /* data immediately follows TRKVARS    */
} TRKVARS, *PTRKVARS;

#endif
