/*
 * socket.c
 *
 * Provides functions for basic socket API.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"

#ifdef IPSEC
#include "ipsec.h"
#if 0 /* IPSEC is not configed by us */
#include "ipsec_api.h"
#endif
#endif /* IPSEC */

#ifdef SOCK_RT
  #include "router.h"
  #include "nat.h"
#endif

#ifdef SOCK_BR
  #include "ethernet.h"
#endif

/****************************************************************************
 *
 * Debug
 *
 ****************************************************************************/

SOCKET_DBG_VAR(DWORD g_dwSocketDebugLevel = REPETITIVE);

/****************************************************************************
 *
 * Global variable
 *
 ****************************************************************************/
SOCKET_REPOSITORY xSocketRep;


/****************************************************************************
 *
 * Local functions
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Socket API functions
 *
 ****************************************************************************/

/*
 * socket
 *  Creates a socket.
 *  Remarks:Default is blocking socket. Non-blocking will be implemented
 *   first.
 *
 *  Args:
 *   family                      The address protocol family
 *                               Should be AF_INET: Internet Protocols.
 *   type                        The type for the socket.
 *                               Should be one of
 *                                 SOCK_STREAM: Stream Socket (TCP/IP)
 *                                 SOCK_DGRAM : Datagram Socket (UDP/IP)
 *   protocol                    Should be set to 0.
 *
 * Return:
 *  0 or more: successful socket (sockfd)
 *  -1       : error
 */
int mn_socket(int lFamily, int lType, int lProtocol)
{
  int iReturn = -1;
  mnIoctlArgList_t mnIoctlArgList;

  /* Early checks */
#ifdef STRICT_POSIX
  if(lFamily != AF_INET) {
    mn_errno = MO_EAFNOSUPPORT;
    return -1;
  }

  if(lProtocol != 0) {
    mn_errno = MO_EPROTONOSUPPORT;
    return -1;
  }
  if(lType != SOCK_DGRAM && lType != SOCK_STREAM) {
    mn_errno = MO_EPROTOTYPE;
    return -1;
  }
#else
  ASSERT((AF_INET == lFamily) && (0 == lProtocol) &&
         (lType == SOCK_DGRAM || lType == SOCK_STREAM));
#endif

  if ((iReturn = mn_open((lType == SOCK_DGRAM) ? "/dev/socket/udp":
                      "/dev/socket/tcp", O_RDWR)) > 0) {
    /*RTOS_recursiveMutexWait(&(xNetWrapper.xMutex)); */
    mnIoctlArgList.lFd     = iReturn;
    mnIoctlArgList.lFamily = lFamily;
    mnIoctlArgList.lType   = lType;
    mnIoctlArgList.lProtocol = lProtocol;
    if (ioctl(iReturn,MO_SIOCOPEN, &mnIoctlArgList) < 0) {
      ASSERT(0);
      mn_errno = MO_ENFILE;
      iReturn = -1;
    }
    /*RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex)); */
  }
  else {
    ASSERT(0);
    mn_errno = MO_ENOBUFS;
    iReturn = -1;
  }

  return iReturn;
}


/*
 * mn_register_sock_event_cb
 *  Registers application callback to receive socket events
 *
 *  Args:
 *   lsockfd                       The socket returned by the socket function.
 *   cb                            Callback routine to handle socket event.
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int mn_register_sock_event_cb(int lSockfd, mn_sock_event_cb_t cb, void *pvCbArg)
{
  SOCKET *pxSock;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(lSockfd);

  if (pxSock == NULL) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  pxSock->pfEventCb = cb;
  pxSock->pvEventCbArg = pvCbArg;

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
  return 0;
}

/*
 * mn_sock_stats
 *  Retrieve socket TCP/UDP statistics
 *
 *  Args:
 *   lsockfd     The socket returned by the socket function.
 *   stats       Pointer to mn_tcp_sock_stats_t or mn_udp_sock_stats_t
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int mn_sock_stats(int lSockfd, void *stats)
{
  SOCKET *pxSock;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(lSockfd);

  if (pxSock == NULL) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }
  if (pxSock->lType == SOCK_STREAM) {
    TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                                pxSock->hLL,
                                NETTRANSPORTULINTERFACEIOCTL_QUERYSTATS,
                                (H_NETDATA)stats);
  }else{
    TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[UDP_INDEX].hInst,
                                pxSock->hLL,
                                NETTRANSPORTULINTERFACEIOCTL_QUERYSTATS,
                                (H_NETDATA)stats);
  }
  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
  return 0;
}

/* MN_sockTcpGetRemoteMss(int lSockfd, int *mss)
 *     Retrieve  the Remote MSS for a connected TCP Socket
 *  Args:
 *   lsockfd     The socket returned by the socket function.
 *   mss         Pointer to int . Value will contain Remote MSS
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */

int MN_sockTcpGetRemoteMss(int lSockfd, int *mss)
{
  SOCKET *pxSock;
  MSTATUS lRv = 0;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(lSockfd);

  if (pxSock == NULL) {
    mn_errno = MO_EBADF;
    lRv = -1;
    goto exit;
  }

  if (pxSock->lType == SOCK_STREAM) {
    lRv = TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                                pxSock->hLL,
                                TCPULINTERFACEIOCTL_QUERYREMOTEMSS,
                                (H_NETDATA)mss);

  }else{
    mn_errno = MO_EBADF;
    lRv = -1;
    goto exit;
  }

exit:
  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
  return lRv;
}

/* MN_sockTcpChangeRxWin(int lSockfd, int win)
 *     Change the Rx Window Size of the connection based upon
 *     Applications Processing capabilities.. 100 / 75/ 50/ 25/ 0
 *  Args:
 *   lsockfd     The socket returned by the socket function.
 *   win         Value will contain win size (30 to 100)
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */

int MN_sockTcpChangeRxWin(int lSockfd, int win)
{
  SOCKET *pxSock;
  MSTATUS lRv = 0;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(lSockfd);

  if (pxSock == NULL) {
    mn_errno = MO_EBADF;
    lRv = -1;
    goto exit;
  }

  if (pxSock->lType == SOCK_STREAM) {
    lRv = TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                                pxSock->hLL,
                                TCPULINTERFACEIOCTL_CHANGERXWIN,
                                (H_NETDATA)&win);

  }else{
    mn_errno = MO_EBADF;
    lRv = -1;
    goto exit;
  }

exit:
  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
  return lRv;
}
