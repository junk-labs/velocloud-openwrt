/*
 * inet_ntop.c
 *
 * implement the inet_ntop function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/in.h"
#include "mqueue.h"
#include "dllist.h"
#include "../include/ioctl.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "igmp.h"
#include "netdefs.h"
#include "netutils.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "ethernet.h"

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/
/*
 * inet_ntop
 *  convert binary IP address to representation (ASCCI dot separated)
 *  frmat.
 *
 *  Arg:
 *   lFamily                      AF_INET or AF_INET6 (IPV6)
 *   addrptr                      address in binary format
 *   strptr                       buffer for conversion result
 *   len                          buffer size
 *
 *  Return:
 *   pointer to result if OK. NULL if not
 */
const char *inet_ntop(int lFamily,const void *addrptr,char *strptr,ubyte4 len)
{
  const unsigned char *p = (const unsigned char *) addrptr;

  if(lFamily == AF_INET) {
    char oTemp[16];
    in_addr_t s_addr = ntohl(((struct in_addr *)addrptr)->s_addr);
    sprintf(oTemp, "%d.%d.%d.%d", ((OCTET *) &s_addr)[0],
         ((OCTET *)&s_addr)[1],
         ((OCTET *)&s_addr)[2],
         ((OCTET *)&s_addr)[3]);
    if(strlen(oTemp) >= len) {
      mn_errno = MO_ENOSPC;
      return NULL;
    }
    MOC_STRCBCPY((sbyte *)strptr, len,(sbyte *)oTemp);
    return (strptr);
  }

  mn_errno = MO_EAFNOSUPPORT;

  return NULL;
}

