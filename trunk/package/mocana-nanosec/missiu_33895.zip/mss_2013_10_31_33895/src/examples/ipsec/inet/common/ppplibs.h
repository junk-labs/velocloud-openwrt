/*
 * ppplibs.h
 *
 * ppp librabry header file
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPPLIBS_H_
#define _PPPLIBS_H_

/****************************************************************************
 *
 * Defines
 *
 ****************************************************************************/

/* Library indexes in the Link Library template */
#define PPPLIBIDX_PPP                  0
  #define PPPULIFIDX_IP                   0
  #define PPPULIFIDX_IPCP                 1
  #define PPPULIFIDX_CHAP                 2
  #define PPPULIFIDX_PAP                  3
#ifdef EAP_TLS
  #define PPPULIFIDX_EAPTLS               4
#endif

#define PPPLIBIDX_IPCP                 1
#define PPPLIBIDX_CHAP                 2
#define PPPLIBIDX_PAP                  3
#ifdef EAP_TLS
#define PPPLIBIDX_EAPTLS               4
#endif

#ifdef EAP_TLS
#define PPPLIBIDX_MAX                  5
#else
#define PPPLIBIDX_MAX                  4
#endif

#define LINKLIBIDXMIDDLE_PPPOE                0

#define NETGETCONFINST_PPP(pxIfState)   &(pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_PPP];
#define NETGETCONFINST_PPPOE(pxIfState) &(pxIfState)->xNetConfLinkMiddle.pxNetConfInstance[LINKLIBIDXMIDDLE_PPPOE];

#define NETGETNETCONF_PPP(pxIfState)    &(pxIfState)->xNetConfLinkTop;
#define NETGETNETCONF_PPPOE(pxIfState)  &(pxIfState)->xNetConfLinkMiddle;

#define NETGETINST_PPP(pxIfState)   (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_PPP].hInst;
#define NETGETINST_IPCP(pxIfState)  (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_IPCP].hInst;
#define NETGETINST_CHAP(pxIfState)  (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_CHAP].hInst;
#ifdef EAP_TLS
#define NETGETINST_EAPTLS(pxIfState)  (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_EAPTLS].hInst;
#endif
#define NETGETINST_PAP(pxIfState)   (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_PAP].hInst;
#define NETGETINST_PPPOE(pxIfState) (pxIfState)->xNetConfLinkMiddle.pxNetConfInstance[LINKLIBIDXMIDDLE_PPPOE].hInst;

#define NETGETNEXTCALLTIME_PPP(pxIfState)   (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_PPP].dwNextCallTime
#define NETGETNEXTCALLTIME_IPCP(pxIfState)  (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_IPCP].dwNextCallTime
#define NETGETNEXTCALLTIME_CHAP(pxIfState)  (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_CHAP].dwNextCallTime
#ifdef EAP_TLS
#define NETGETNEXTCALLTIME_EAPTLS(pxIfState)  (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_EAPTLS].dwNextCallTime
#endif
#define NETGETNEXTCALLTIME_PAP(pxIfState)   (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_PAP].dwNextCallTime
#define NETGETNEXTCALLTIME_PPPOE(pxIfState) (pxIfState)->xNetConfLinkMiddle.pxNetConfInstance[LINKLIBIDXMIDDLE_PPPOE].dwNextCallTime

#define NETGETIF_PPPOEUL(pxIfState)   (pxIfState)->xNetConfLinkMiddle.pxNetConfInstance[LINKLIBIDXMIDDLE_PPPOE].phULIf[0]
#define NETGETIF_PPPLL(pxIfState)     (pxIfState)->xNetConfLinkTop.pxNetConfInstance[PPPLIBIDX_PPP].phLLIf[0]

#define NETGETIF_ETHULPPPOE(pxIfState)        (pxIfState)->hEthUlIfPppoE
#define NETGETIF_ETHULPPPOESESSION(pxIfState) (pxIfState)->hEthUlIfSession

#define NETSETIF_ETHULPPPOE(pxIfState,hIf)        (pxIfState)->hEthUlIfPppoE = (hIf)
#define NETSETIF_ETHULPPPOESESSION(pxIfState,hIf) (pxIfState)->hEthUlIfSession = (hIf)

/****************************************************************************
 *
 * extern
 *
 ****************************************************************************/

MOC_EXTERN const NETCONFLIBRARYTEMPLATE *apxPppLibTemplate[PPPLIBIDX_MAX];
MOC_EXTERN const NETCONFLIBRARYTEMPLATE *apxPppoELibTemplate[1];

#endif /*#ifndef _PPPLIBS_H_*/
