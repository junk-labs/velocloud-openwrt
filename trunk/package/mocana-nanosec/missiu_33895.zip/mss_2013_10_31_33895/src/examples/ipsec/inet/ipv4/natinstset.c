/*
 * natinstset.c
 *
 * Implements NAT
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/

#include "nat.h"
#include "nat_defs.h"

/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * NatInstanceSet
 *  Set a NAT Instance Option
 *
 *  Args:
 *   hNat                   NAT instance
 *   oOption                Option
 *   hData                  Option data
 *
 *  Return:
 *   NETERR_NOERR : success
 *   NETERR_UNKNOWN : error
 */
LONG NatInstanceSet(H_NETINSTANCE hNat,
                    OCTET oOption,
                    H_NETDATA hData)
{
  NATSTATE *pxNat = (NATSTATE *)hNat;
  LONG lReturn = NETERR_NOERR;

  NAT_CHECK_STATE(pxNat);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_ERROR))
  {
    /*NAT_DBGP(DBGLVL_ERROR_RARE,"NatInstanceSet: Option: %x\n", oOption);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NatInstanceSet: Option: ", oOption);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oOption) {

  case NETOPTION_FREE:
    pxNat->pfnNetFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_MALLOC:
    pxNat->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT((void*)hData != NULL));
    pxNat->pxMutex = (RTOS_MUTEX)hData;
    break;

  case NETOPTION_OFFSET:
    pxNat->wOffset = (WORD)hData;
    break;

  case NETOPTION_TRAILER:
    pxNat->wTrailer = (WORD)hData;
    break;

  case NETOPTION_NETCBK:
    pxNat->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
  }

  return lReturn;
}
