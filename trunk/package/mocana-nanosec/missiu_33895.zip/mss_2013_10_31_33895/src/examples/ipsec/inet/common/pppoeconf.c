/*
 * pppoeconf.c
 *
 * PppoE link configuration code
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "netmain_flavor.h"
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "stdio.h"
#include "pthread.h"
#include <mqueue.h>
#include "netdb.h"
#include "sys/socket.h"
#include "net/if.h"
#include "limits.h"
#include "net/if_types.h"
#include "errno.h"

#include "netcommon.h"
#include "netconfig.h"
#include "nettime.h"
#include "netdefs.h"
#include "netmain.h"
#include "dnsapi.h"
#include "linkconf.h"
#include "netif.h"
#include "ethernet.h"
#include "arp.h"
#include "pppoecommon.h"
#include "pppoeclient.h"
#include "pppoeconf.h"
#include "ppp.h"
#include "ipcp.h"
#include "ethlink.h"
#include "iptable.h"
#include "cryptcommon.h"
#include "md5.h"
#include "chapclient.h"
#include "papclient.h"
#include "ppplibs.h"

/****************************************************************************
 *
 * debug
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Local functions
 *
 ****************************************************************************/

/****************************************************************************
 *
 * API function
 *
 ****************************************************************************/

/*
 * NetAdminPppoECbk
 *  Network wrapper PppoE Callback.
 *   Follows PFN_NETCBK type
 *
 */
LONG NetAdminPppoECbk(H_NETINSTANCE hInst,
                      OCTET oCbk,
                      H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;
  OCTET oIfIdx = (OCTET)hInst;

  pxNetWrapper = NETGETWRAPPER;
  pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);
  pxIfState = NETGETIFSTATE(pxIfConf);

  switch(oCbk) {
  case NETCBK_TLU:
    PppInstanceMsg(pxIfState->hTopLinkInst,NETMSG_LOWERLAYERUP,(H_NETDATA)0);
    break;

  case NETCBK_TLD:
    PppInstanceMsg(pxIfState->hTopLinkInst,NETMSG_LOWERLAYERDOWN,(H_NETDATA)TRUE);
    break;

  case NETCBK_TLF:
    NetMainMsg(NETMAINMSG_IFCLOSE,(H_NETDATA)oIfIdx);
    break;

  case NETCBK_TLS:
    break;

  case PPPOECLIENTCBK_COUNTEREXPIRED:
    NETMAIN_DBGP(ERROR,"NetAdminPppoECbk:no response from any pppoe server\n");
    break;

  case NETCBK_NEEDPROCESSING:
    NETGETNEXTCALLTIME_PPPOE(pxIfState) = NetGlobalTimerGet() + (DWORD)hData;
    break;

  default:
    break;
  }

  return NETERR_NOERR;
}


/*
 * PppoEConfSetup
 *  Specific setup for straight PPPoE interfaces
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   NETLINKLEG
 */
LONG PppoEConfSetup(NETIFCONF *pxIfConf,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;
  H_NETINSTANCE hPppoE,hEth;
  NETCONFINSTANCE *pxPppoEInst;
  H_NETINTERFACE hPppoELlIf,hEthUlIfPppoE,hEthUlIfSession,hEthLlIf;
  ETHIFTOLL xEthIfToLL;
  ETHID xId;

  NETMAIN_DBGP(NORMAL,"PppoEConfSetup:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  pxNetConf = NETGETNETCONF_PPPOE(pxIfState);

  pxNetConf->eState = NETCONFSTATE_INIT;
  pxNetConf->ppxLibTemplate = (NETCONFLIBRARYTEMPLATE**)apxPppoELibTemplate;
  pxNetConf->dwLibNum = 1;

  /* Setup all instances */
  NetConfSetup(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_SETUP);

  LibConfSetOffsetAndTrailer(pxNetConf,NETRXOFFSET,NETRXTRAILER);

  hEth = NETGETINST_ETH;
  hPppoE = NETGETINST_PPPOE(pxIfState);
  pxPppoEInst = NETGETCONFINST_PPPOE(pxIfState);
  hPppoELlIf = pxPppoEInst->phLLIf[0];

  /* PppoE specific settings */
  PppoEClientInstanceSet(hPppoE,NETOPTION_NETCBKHINST,
                         (H_NETDATA)oIfIdx);
  PppoEClientInstanceSet(hPppoE,PPPOEOPTION_PHYIF,
                         (H_NETDATA)oIfIdx);

#if 0
  PppoEClientInstanceSet(hPppoE,PPPOEOPTION_VLAN,
                         (H_NETDATA)(pxIfConf->wVlan));
  if (pxIfConf->xPppConf.pcPppoESrv != NULL) {
    PppoEClientInstanceSet(hPppoE,PPPOECLIENTOPTION_SERVICENAME,
                           (H_NETDATA)(pxIfConf->xPppConf.pcPppoESrv));
  }
  if (pxIfConf->xPppConf.pcPppoEAC != NULL) {
    PppoEClientInstanceSet(hPppoE,PPPOECLIENTOPTION_ACNAME,
                           (H_NETDATA)(pxIfConf->xPppConf.pcPppoEAC));
  }
#endif

  /* Eth UL interface to PPPoE */
  hEthUlIfPppoE = EthInstanceULInterfaceCreate(hEth);
  NETSETIF_ETHULPPPOE(pxIfState,hEthUlIfPppoE);

  /* Eth UL interface to PPPoE-Session */
  hEthUlIfSession = EthInstanceULInterfaceCreate(hEth);
  NETSETIF_ETHULPPPOESESSION(pxIfState,hEthUlIfSession);

  hEthLlIf   = EthInstanceLLInterfaceCreate(hEth);
  NETSETIF_ETHLL(pxIfState,hEthLlIf);

  /* Ethernet configuration */
  xEthIfToLL.oIfIdx = oIfIdx;
  xEthIfToLL.hLlIf  = hEthLlIf;
  EthInstanceSet(hEth,ETHOPTION_IFTOLLMAP,(H_NETDATA)&xEthIfToLL);

  xId.oIfIdx = oIfIdx;

  /* PppoE Ll interface */
  PppoEClientInstanceLLInterfaceIoctl(hPppoE,hPppoELlIf,
                                      NETINTERFACEIOCTL_SETHINST,
                                      (H_NETDATA)hEth);
  PppoEClientInstanceLLInterfaceIoctl(hPppoE,hPppoELlIf,
                                      NETINTERFACEIOCTL_SETIF,
                                      (H_NETDATA)hEthUlIfPppoE);
  PppoEClientInstanceLLInterfaceIoctl(hPppoE,hPppoELlIf,
                                      PPPOELLINTERFACEIOCTL_SETSESSIONIF,
                                      (H_NETDATA)hEthUlIfSession);
  PppoEClientInstanceLLInterfaceIoctl(hPppoE,hPppoELlIf,
                                      NETINTERFACEIOCTL_SETOUTPUTPFN,
                                      (H_NETDATA)EthInstanceWrite);

  /* Discovery interface */
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfPppoE,
                              NETINTERFACEIOCTL_SETROUTINGID,
                              (H_NETDATA)ETHID_PPPOEDISCOVERY);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfPppoE,
                              ETHULINTERFACEIOCTL_SETIFIDX,
                              (H_NETDATA)oIfIdx);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfPppoE,NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hPppoE);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfPppoE,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hPppoELlIf);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfPppoE,
                              NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)PppoEClientInstanceRcv);

  /* PppoE session interface */
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfSession,
                              NETINTERFACEIOCTL_SETROUTINGID,
                              (H_NETDATA)ETHID_PPPOESESSION);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfSession,
                              ETHULINTERFACEIOCTL_SETIFIDX,
                              (H_NETDATA)oIfIdx);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfSession,
                              NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hPppoE);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfSession,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hPppoELlIf);
  EthInstanceULInterfaceIoctl(hEth,hEthUlIfSession,
                              NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)PppoEClientInstanceRcv);

  return NETERR_NOERR;
}


/*
 * PppoEConfOpen
 *  Specific openings for straight PPPoE interfaces
 *
 *  Args:
 *   pxIfConf           interface conf structure
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG PppoEConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;
  H_NETINSTANCE hPppoE,hEth;
  ETHID xId;

  NETMAIN_DBGP(NORMAL,"PppoEConfOpen:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  hEth = NETGETINST_ETH;
  hPppoE = NETGETINST_PPPOE(pxIfState);


  pxNetConf = NETGETNETCONF_PPPOE(pxIfState);
  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_SETUP);

  /* Set dynamically changeable PPPoE options here */
  PppoEClientInstanceSet(hPppoE,PPPOEOPTION_VLAN,
                         (H_NETDATA)(pxIfConf->wVlan));
  if (pxIfConf->xPppConf.pcPppoESrv != NULL) {
    PppoEClientInstanceSet(hPppoE,PPPOECLIENTOPTION_SERVICENAME,
                           (H_NETDATA)(pxIfConf->xPppConf.pcPppoESrv));
  }
  if (pxIfConf->xPppConf.pcPppoEAC != NULL) {
    PppoEClientInstanceSet(hPppoE,PPPOECLIENTOPTION_ACNAME,
                           (H_NETDATA)(pxIfConf->xPppConf.pcPppoEAC));
  }

  xId.oIfIdx = oIfIdx;
  xId.wVlan = pxIfConf->wVlan;
  EthInstanceMsg(hEth,ETHMSG_SETLLDEFAULTVLAN,(H_NETDATA)&xId);

  memcpy(xId.aoAddr, pxIfConf->aoHWAddr, ETHADDRESS_LEN);
  EthInstanceSet(hEth,ETHOPTION_MACADDR,(H_NETDATA)&xId);

#ifdef NET_BR
  /* Inform the eth module of the bridged LL interfaces */
  {
    OCTET oMsg;
    if (pxIfConf->xEthConf.obBridge == TRUE) {
      oMsg = ETHMSG_ENABLEBRIDGE;
    }
    else {
      oMsg = ETHMSG_DISABLEBRIDGE;
    }
    EthInstanceMsg(hEth,oMsg,(H_NETDATA)oIfIdx);
  }

  /* Set the eth module Broadcast and Multicast limits on this if */
  {
    ETHIFLIMIT xEthLimit;
    xEthLimit.oIfIdx = oIfIdx;
    xEthLimit.oPercent = pxIfConf->xEthConf.oBcastLimit;
    EthInstanceMsg(hEth,ETHMSG_SETIFBCASTLIMIT,(H_NETDATA)&xEthLimit);
    xEthLimit.oPercent = pxIfConf->xEthConf.oMcastLimit;
    EthInstanceMsg(hEth,ETHMSG_SETIFMCASTLIMIT,(H_NETDATA)&xEthLimit);
  }
#endif /*#ifdef NET_BR*/

  NetConfOpen(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_OPENED);

  /* Open Eth interfaces */
  EthInstanceULInterfaceIoctl(hEth,NETGETIF_ETHULPPPOE(pxIfState),
                              NETINTERFACEIOCTL_OPEN,(H_NETDATA)0);
  EthInstanceULInterfaceIoctl(hEth,NETGETIF_ETHULPPPOESESSION(pxIfState),
                              NETINTERFACEIOCTL_OPEN,(H_NETDATA)0);
  EthInstanceLLInterfaceIoctl(hEth,NETGETIF_ETHLL(pxIfState),
                              NETINTERFACEIOCTL_OPEN,(H_NETDATA)0);
  return NETERR_NOERR;
}

/*
 * PppoEConfProcess
 *  straight PPPoE link processing
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG PppoEConfProcess(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_PPPOE(pxIfState);
  NETMAIN_ASSERT(pxNetConf->eState != NETCONFSTATE_INIT);

  NetConfProcess(pxNetConf);

  return NETERR_NOERR;
}

/*
 * PppoEConfClose
 *  PPPoE specific if close
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return 0
 */
LONG PppoEConfClose(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;
  H_NETINSTANCE hEth; /*,hPppoEInst; */

  NETMAIN_DBGP(NORMAL,"PppoEConfClose:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_PPPOE(pxIfState);

  NETMAIN_ASSERT(pxNetConf != NULL);

  if(pxNetConf->eState == NETCONFSTATE_CLOSED){
    return -1;
  }

#if 0

/* mike addition */
  hPppoEInst = NETGETINST_PPPOE(pxIfState);
  PppoEClientInstanceProcess(hPppoEInst); /* Ensure PADI gets sent before NetConfClose */
#endif
/*MAYBE*/  /*PppoEClientInstanceMsg(hPppoE, NETMSG_CLOSE, (H_NETDATA)NULL);*/
  NetConfClose(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_CLOSED);

  hEth = NETGETINST_ETH;

  /* Close interface if */
  EthInstanceLLInterfaceIoctl(hEth,NETGETIF_ETHLL(pxIfState),
                              NETINTERFACEIOCTL_CLOSE,(H_NETDATA)0);
  EthInstanceULInterfaceIoctl(hEth,
                              NETGETIF_ETHULPPPOE(pxIfState),
                              NETINTERFACEIOCTL_CLOSE,(H_NETDATA)0);
  EthInstanceULInterfaceIoctl(hEth,
                              NETGETIF_ETHULPPPOESESSION(pxIfState),
                              NETINTERFACEIOCTL_CLOSE,(H_NETDATA)0);

  return NETERR_NOERR;

}

/*
 * PppoEConfDestroy
 *  PPPoE specific if destroy
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG PppoEConfDestroy(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;
  H_NETINSTANCE hEth;

  NETMAIN_DBGP(NORMAL,"PppoEConfDestroy:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_PPPOE(pxIfState);
  NETMAIN_ASSERT((pxNetConf != NULL) && (pxNetConf->eState == NETCONFSTATE_SETUP));

  hEth = NETGETINST_ETH;

  EthInstanceLLInterfaceDestroy(hEth,NETGETIF_ETHLL(pxIfState));
  EthInstanceULInterfaceDestroy(hEth,NETGETIF_ETHULPPPOE(pxIfState));
  EthInstanceULInterfaceDestroy(hEth,NETGETIF_ETHULPPPOESESSION(pxIfState));

  /* Setup all instances */
  NetConfTearDown(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_INIT);

  return 0;
}

/*
 * PppoEPlumbing
 *  Args:
 *   pxIfConf           Interface conf structue
 *
 *  Return:
 *   0
 */
LONG PppoEPlumbing(NETIFCONF *pxIfConf)
{
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hEthInst,hPppoEInst,hPppInst;
  H_NETINTERFACE hEthLlIf,hPppoEUlIf,hPppLlIf;

  NETMAIN_DBGP(NORMAL,"PppoEPlumbing:pxIfConf=0x%p\n",pxIfConf);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  hEthInst   = NETGETINST_ETH;
  hPppoEInst = NETGETINST_PPPOE(pxIfState);
  hPppInst   = NETGETINST_PPP(pxIfState);

  hEthLlIf   = NETGETIF_ETHLL(pxIfState);
  hPppoEUlIf = NETGETIF_PPPOEUL(pxIfState);
  hPppLlIf   = NETGETIF_PPPLL(pxIfState);

  PppInstanceLLInterfaceIoctl(hPppInst,hPppLlIf,NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hPppoEInst);
  PppInstanceLLInterfaceIoctl(hPppInst,hPppLlIf,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hPppoEUlIf);
  PppInstanceLLInterfaceIoctl(hPppInst,hPppLlIf,NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)PppoEClientInstanceWrite);

  PppoEClientInstanceULInterfaceIoctl(hPppoEInst,hPppoEUlIf,NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hPppInst);
  PppoEClientInstanceULInterfaceIoctl(hPppoEInst,hPppoEUlIf,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hPppLlIf);
  PppoEClientInstanceULInterfaceIoctl(hPppoEInst,hPppoEUlIf,NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)PppInstanceRcv);

  return 0;
}
