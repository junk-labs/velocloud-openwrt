/*
 * netsnmp.h
 *
 * Network SNMP library API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETSNMP_H_
#define _NETSNMP_H_

/****************************************************************************
 *
 * Macros
 *
 ****************************************************************************/
#define SNMP(X)  X

/****************************************************************************
 *
 * Externs
 *
 ****************************************************************************/

#endif /* _NETSNMP_H_ */
