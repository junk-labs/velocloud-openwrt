/*
 * netconfprocess.c
 *
 * Implements NetConfProcess
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "utils_flavor.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "netdbg.h"
#include "nettime.h"
#include "netconfig.h"

/****************************************************************************
 *
 * Debug
 *
 *****************************************************************************/

/****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * NetConfProcess
 *  Calls the process functions of all registered instances
 *  which need it
 *
 *  Args:
 *   pxNetConf
 *
 *  Return:
 *   delay (in msec) till next needed call
 */
LONG NetConfProcess(NETCONF *pxNetConf)
{
  NETCONFINSTANCE *pxNetConfInstance = NULL;
  NETCONFLIBRARYTEMPLATE **ppxLibTemplate = NULL;
  LONG lReturn = 0x7FFFFFFF;
  LONG lCurrentTime;
  int i;

  /* Assert on the state. No NDEBUG check on it, to save
     cycles */
  NETDBG_ASSERT((pxNetConf != NULL) &&
                (pxNetConf->eState != NETCONFSTATE_INIT));

  if (pxNetConf->eState != NETCONFSTATE_OPENED) {
    return lReturn;
  }

  lCurrentTime = NetGlobalTimerGet();

  ppxLibTemplate    = pxNetConf->ppxLibTemplate;
  pxNetConfInstance = pxNetConf->pxNetConfInstance;


  for (i = 0; i < pxNetConf->dwLibNum; i++) {
    const NETCONFLIBRARYTEMPLATE  *pxLibTemplate  = ppxLibTemplate[i];
    NETCONFINSTANCE         *pxInst         = &pxNetConfInstance[i];
    const NETCONFINSTANCETEMPLATE *pxInstTemplate;
    PFN_NETINSTANCEPROCESS pfnProcess;

    NETDBG_ASSERT((pxLibTemplate != NULL) && (pxInst != NULL));

    pxInstTemplate = pxLibTemplate->pxInstanceTemplate;
    NETDBG_ASSERT(pxInstTemplate != NULL);

    pfnProcess = pxLibTemplate->pfnInstanceProcess;

    if (pfnProcess != NULL) {
      if (lCurrentTime >= pxInst->dwNextCallTime) {

#if 0
        pxInst->dwNextCallTime += pfnProcess(pxInst->hInst);
#else
        pxInst->dwNextCallTime = lCurrentTime + pfnProcess(pxInst->hInst);
#endif

        /* This will force the next call to happen a little
           earlier, as we use the former calculated Call Time
           instead of the current time as the base to the next
           calling time. Otherwise, a drift might happen */
        if (pxInst->dwNextCallTime < lReturn) {
          lReturn = pxInst->dwNextCallTime;
        }
        }
    }
  }

  lCurrentTime = NetGetMsecTime();

  if (lReturn > lCurrentTime) {
    lReturn = lReturn - lCurrentTime;
  }
  else {
    lReturn = 0;
  }

  return lReturn;
}




