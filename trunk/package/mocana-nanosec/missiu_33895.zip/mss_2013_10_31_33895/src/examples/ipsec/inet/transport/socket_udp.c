/*
 * socket_udp.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"

#ifdef IPSEC
#include "ipsec.h"
#if 0 /* IPSEC is not configed by us */
#include "ipsec_api.h"
#endif
#endif /* IPSEC */

#ifdef SOCK_RT
  #include "router.h"
  #include "nat.h"
#endif

#ifdef SOCK_BR
  #include "ethernet.h"
#endif
#include "../libsock/libsockserver.h"

/*
 * SocketUdpCreateConn
 *  Create a UDP Conn for this socket, and do Udp specific
 *  configuration
 *
 *  Arg:
 *   pxSock                           Socket structure
 *
 *  Return:
 *   0 success, -1 failure
 */
LONG SocketUdpCreateConn(SOCKET *pxSock)
{
#ifdef __SOCKET_USE_MEMPOOL__
  MSTATUS status = OK;
#endif

  SOCKET_CHECK_STATE(pxSock);

  /* Create the UDP member */
#ifdef __SOCKET_USE_MEMPOOL__
  if(OK > (status = MEM_POOL_getPoolObject(&xSocketRep.udpSockConnPool, (void **) &pxSock->u.pxUdp)))
  {
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: SocketTcpCreateConn: unable to allocate udp socket");
    return -1;
  }
#else
  pxSock->u.pxUdp = (UDPSOCKET *)MALLOC(sizeof(UDPSOCKET));
#endif

  SOCKET_ASSERT(pxSock->u.pxUdp != NULL);
  MOC_MEMSET((ubyte *)(pxSock->u.pxUdp), 0, sizeof(UDPSOCKET));

  /* Initialize the Rx packet DLLIST. If the socket is never used
     in as rcv, it's a bit of a waste. But otherwise, this would have
     to be done in 3 different places, recvfrom, bind and connect, with
     checks for pre-allocation.
     In anycase, DLLIST may end up being to slow, and this may change.
     */
  pxSock->u.pxUdp->pDllPackets = new_DLLIST();


  {
    H_NETINSTANCE hUdp;

    hUdp = xSocketRep.axProtocols[UDP_INDEX].hInst;
    /* Create the corresponding UDP UL interface */

    pxSock->hLL = UdpInstanceULInterfaceCreate(hUdp);

    UdpInstanceULInterfaceIoctl(hUdp,pxSock->hLL,
                                NETINTERFACEIOCTL_SETOUTPUTPFN,
                                (H_NETDATA)UdpRxCbk);

  }

  return 0;
}

/*
 * SocketUdpConnectConn
 *  Performs a Connect on a UDP socket.
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxSock                     Socket structure
 *   servaddr_in                server address
 *
 *  Return:
 *   0 if successfull
 */
LONG SocketUdpConnectConn(SOCKET *pxSock, mn_sock_connect_cb_t cb, void *cbarg, void  *ipc_req )
{
  SOCKET_CHECK_STATE(pxSock);

  pxSock->dwSockState |= SS_ISCONNECTED;

#ifdef __MOCANA_IPC_LIBSOCK__
  if (ipc_req)
      SOCKSERVER_connectReply(ipc_req,0);
#endif

  return 0;
}

/*
 * SocketUdpDestroy
 *  UDP specific socket destroy
 *
 *  Args:
 *   pxSock                         Socket
 *
 *  Return:
 *   >=0 if successfull
 */
LONG SocketUdpDestroy(SOCKET *pxSock)
{
#ifdef __SOCKET_USE_MEMPOOL__
  MSTATUS status = OK;
#endif

  SOCKET_CHECK_STATE(pxSock);

  {
    H_NETINSTANCE hUdp;

    hUdp = xSocketRep.axProtocols[UDP_INDEX].hInst;

    UdpInstanceULInterfaceIoctl(hUdp,pxSock->hLL,NETINTERFACEIOCTL_CLOSE,0);
    UdpInstanceULInterfaceDestroy(hUdp,pxSock->hLL);
  }

  SOCKET_ASSERT(pxSock->u.pxUdp->pDllPackets != NULL);
  del_DLLIST(pxSock->u.pxUdp->pDllPackets,
             NetFree);

#ifdef __SOCKET_USE_MEMPOOL__
  if (OK > (status = MEM_POOL_putPoolObject(&xSocketRep.udpSockConnPool, (void **)(&pxSock->u.pxUdp))))
    DEBUG_ERROR(DEBUG_MOC_IPV4, "SocketUdpDestroy: unable to release udp socket  within udpSockConnPool Status = %d\n", status);
#else
  FREE(pxSock->u.pxUdp);
#endif

  return 0;
}
