/*
 * chap_dbg.h
 *
 * chap module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _CHAP_DBG_H_
#define _CHAP_DBG_H_

#ifndef NDEBUG

  #ifdef NETDBG_HI
    #ifndef CHAPDBG_HI
      #define CHAPDBG_HI
    #endif
  #endif

#else

  #ifdef CHAPDBG_HI
    #undef CHAPDBG_HI
  #endif

#endif

#include "netdbg.h"


/*
 * Constants
 */
#define CHAP_MAGIC_COOKIE 0x63686170 /*"chap" = 0x63686170*/


/*
 * Debug macros
 */
/*#ifdef CHAPDBG_HI*/
#if defined(CHAPDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define CHAP_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == CHAP_MAGIC_COOKIE));

  #define CHAP_SET_COOKIE(x) (x)->dwMagicCookie = CHAP_MAGIC_COOKIE
  #define CHAP_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define CHAP_DBGP(level, fmt, args...) do { \
    if (level <= g_dwChapDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define CHAP_DBG(level, x) do {  \
    if (level <= g_dwChapDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define CHAP_DBG_VAR(x)  x
#else
  #define CHAP_CHECK_STATE(x)
  #define CHAP_SET_COOKIE(x)
  #define CHAP_UNSET_COOKIE(x)
  #define CHAP_DBGP(level, fmt, args...)
  #define CHAP_DBG(level, x)
  #define CHAP_DBG_VAR(x)
#endif

CHAP_DBG_VAR(MOC_EXTERN DWORD g_dwChapDebugLevel);

/*
 * Debug levels
 */
#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _CHAP_DBG_H_ */
