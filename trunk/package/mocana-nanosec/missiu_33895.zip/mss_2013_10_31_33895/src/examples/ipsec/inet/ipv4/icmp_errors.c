/*
 * icmp_errors.c
 *
 *
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#ifdef NEW_ICMP_MSG_ADDED
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/if_types.h"

#include "netmain.h"
#include "routing_table.h"
#include "tcp.h"
#include "udp.h"
#include "icmp_dbg.h"
#include "icmp_defs.h"

extern DWORD g_dwIcmpDebugLevel;

/***************************************************************************
 *
 * Handle errors
 *
 ***************************************************************************/
void
reportIcmpErrorsToUL(ubyte oErrNo,
                     NETPACKET *pxNetPacket,
                     NETPACKETACCESS *pxNetPacketAccess,
                     sbyte oSkip)
{
  NETPAYLOAD *pxPayload;
  ubyte *poPayload;
  ubyte oMsg = 0;
  ubyte2 wOffset;
  IPHDR *pxIpHdr;
  H_NETINSTANCE hInst;
  PFN_NETMSG pfnInstanceMsg;
  TRANSPORTMSGDATA transportMsgData;

  pxPayload = pxNetPacket->pxPayload;
  poPayload = pxPayload->poPayload;
  wOffset   = pxNetPacketAccess->wOffset;

  if(!oSkip)
    wOffset += sizeof(ICMP_HDR);

  pxIpHdr = (IPHDR *)(poPayload + wOffset);

  switch (pxIpHdr->oProtocol)
  {
    case IPPROTO_TCP:
    {
      hInst = NETGETINST_TCP;
      pfnInstanceMsg = apxMainTrunkLibTemplate[MAINTRUNKLIBIDX_TCP]->pfnInstanceMsg;
      oMsg = TCPMSG_ICMPERRORS;
      break;
    }
    case IPPROTO_UDP:
    {
      hInst = NETGETINST_UDP;
      pfnInstanceMsg = apxMainTrunkLibTemplate[MAINTRUNKLIBIDX_UDP]->pfnInstanceMsg;
      oMsg = UDPMSG_ICMPERRORS;
      break;
    }
    default:
    {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ICMP, INET_DBG_LEVEL_ERROR))
      {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "reportIcmpErrorsToUL: unknown protocol type", pxIpHdr->oProtocol);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
      }
      return;
    }
  }

  transportMsgData.pxNetPacket       = pxNetPacket;
  transportMsgData.pxNetPacketAccess = pxNetPacketAccess;
  transportMsgData.oCode             = oErrNo;

  if(!oSkip)
  {
    /*Execute when oSkip is not set (NetAdminIcmpCbk) , Increment the offset, till the pay load*/
    transportMsgData.pxNetPacketAccess->wOffset += ICMP_SHORTHEADERLENGTH + ICMP_NULL_PAYLOAD_LENGTH;
    transportMsgData.pxNetPacketAccess->wLength -= (ICMP_SHORTHEADERLENGTH + ICMP_NULL_PAYLOAD_LENGTH);
    transportMsgData.oCode = oErrNo;
  }

  /*Send this packet to the respective instance msg*/
  ASSERT (pfnInstanceMsg != NULL);
  NETPAYLOAD_ADDUSER(transportMsgData.pxNetPacket->pxPayload);
  pfnInstanceMsg(hInst,
                 oMsg,
                 (H_NETDATA)(&transportMsgData));
}

/*
 * Handling for redirects, only suitable for hosts.
 */
void
handleIcmpRedirectErrors(ICMPCBKDATA *pxIcmpCbkData)
{
  NETPAYLOAD *pxPayload;
  ubyte *poPayload;
  WORD wOffset;
  IPHDR *pxIpHdr;
  NETWORKID *pxNetworkId;
  ROUTEENTRY xRoute;
  IPTABLEENTRY xIpEntry;
  ubyte oNewGatewayAddrType;
  ubyte oDestAddrType;
  ubyte oCode;
  ubyte oNewGatewayIdx;

  pxNetworkId = pxIcmpCbkData->pxNetworkId;
  pxPayload   = pxIcmpCbkData->pxNetPacket->pxPayload;
  poPayload   = pxPayload->poPayload;
  oCode       = pxIcmpCbkData->pxIcmpHdr->oCode;
  wOffset     = pxIcmpCbkData->pxNetPacketAccess->wOffset;
  pxIpHdr     = (IPHDR*)(poPayload + wOffset + sizeof(ICMP_HDR));

  switch(oCode)
  {
    case ICMP_REDIR_NET:
    case ICMP_REDIR_HOST:
    case ICMP_REDIR_NETTOS:
    case ICMP_REDIR_HOSTTOS:
    {
      IpTablePrint();

      xIpEntry.dwAddr       = htonl(pxIcmpCbkData->pxIcmpHdr->u.dwGateway);
      xIpEntry.oIfIdx       = NETIFIDX_ANY;
      xIpEntry.wDefaultVlan = NETVLAN_ANY;

      /*
       * - Check if the gateway is directly connected.
       * - Obtaining the address type of the incoming re-direct address
       * - Checking the incoming redirect addr is present within our IpTable.
       */
      oNewGatewayAddrType = IpTableMsg(IPTABLEMSG_GETTYPE, (H_NETDATA)&xIpEntry);
      if((IPADDRT_MYSUBNET != oNewGatewayAddrType) ||
          (IpTableMsg(IPTABLEMSG_GETDEFAULT, (H_NETDATA)&xIpEntry) != NETERR_UNKNOWN))
      {
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ICMP, INET_DBG_LEVEL_REPETITIVE))
        {
          /*ICMP_DBGP(REPETITIVE, "handleIcmpRedirectErrors, REDIRECT gateway's address %ld.%ld.%ld.%ld, type : %d, is in-valid. \n",
                  IPADDRDISPLAY(pxIcmpCbkData->pxIcmpHdr->u.dwGateway),
                  oNewGatewayAddrType);*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_handleIcmpRedirectErrors, redirect gateway's address ",
                                    pxIcmpCbkData->pxIcmpHdr->u.dwGateway);
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", type : ", oNewGatewayAddrType);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, ", is in-valid. ");
        }
        return;
      }
      oNewGatewayIdx = IpTableMsg(IPTABLEMSG_GETIFIDX, (H_NETDATA)&xIpEntry);

      /* Get the address type of the destination address within the icmp message*/
      xIpEntry.dwAddr = htonl(pxIpHdr->dwDstAddr);
      oDestAddrType = IpTableMsg(IPTABLEMSG_GETTYPE, (H_NETDATA)&xIpEntry);
      if((oDestAddrType == IPADDRT_MYADDR) ||
         (oDestAddrType == IPADDRT_MYSUBNET))
      {
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ICMP, INET_DBG_LEVEL_REPETITIVE))
        {
          /*ICMP_DBGP(REPETITIVE, "handleIcmpRedirectErrors, REDIRECT destination address %ld.%ld.%ld.%ld, type : %d, is in-valid. \n",
                  IPADDRDISPLAY(pxIcmpCbkData->pxIcmpHdr->u.dwGateway),
                  oNewGatewayAddrType);*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_handleIcmpRedirectErrors, REDIRECT destination address ",
                                    pxIcmpCbkData->pxIcmpHdr->u.dwGateway);
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", type : ", oNewGatewayAddrType);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, ", is in-valid. ");
        }
        return;
      }

      /* Create off a Route Entry */
#ifdef _RADIX_ROUTING_ON_
      xRoute.xRouteNodes->RadixNodeKey = htonl(pxIpHdr->dwDstAddr);
      xRoute.xRouteNodes->RadixNodeMask = 0;
#else
      xRoute.dwDstAddr     = htonl(pxIpHdr->dwDstAddr); /*Indicates the final destination, for which the packet was destined*/
      xRoute.dwSubnetMask  = 0;
#endif
      xRoute.wVlan         = NETVLAN_ANY;
      xRoute.oIfIdx        = NETIFIDX_ANY;
      xRoute.eDstAddrType  = oDestAddrType;
      if( (RoutingTableMsg(ROUTINGTABLEMSG_FINDROUTE, (H_NETDATA)&xRoute)) < 0 )
      {
        /*Indicates that we did not get a route with the destination ip*/
        return;
      }
      else
      {
        /* Check if the source addr is equal to the gateway for the destination.
         * - i.e: Redirect is from the current router for that destination.
         */
        if(pxNetworkId->dwSrcAddr == xRoute.dwGateway)
        {
#ifdef _RADIX_ROUTING_ON_
          if(xRoute.xRouteNodes->RadixNodeKey != 0)
#else
          if(xRoute.dwDstAddr != 0)
#endif
          {
            /* Deleting the Route as now we are sure about it*/
            RoutingTableMsg(ROUTINGTABLEMSG_DELROUTE, (H_NETDATA) &xRoute);
          }
#ifdef _RADIX_ROUTING_ON_
          xRoute.xRouteNodes->RadixNodeMask = 0;
          xRoute.xRouteNodes->RadixNodeKey  = htonl(pxIpHdr->dwDstAddr); /*Indicates the final destination, for which the packet was destined*/
#else
          xRoute.dwDstAddr     = htonl(pxIpHdr->dwDstAddr); /*Indicates the final destination, for which the packet was destined*/
          xRoute.dwSubnetMask  = 0;
#endif
          xRoute.dwGateway     = htonl(pxIcmpCbkData->pxIcmpHdr->u.dwGateway);
          xRoute.wVlan         = NETVLAN_ANY;
          xRoute.oIfIdx        = oNewGatewayIdx;
          xRoute.eDstAddrType  = oDestAddrType;
          xRoute.wTOS          = 0;
          xRoute.wMetric       = 0;
          RoutingTableMsg(ROUTINGTABLEMSG_ADDROUTE, (H_NETDATA)&xRoute);
        }
        else
        {
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ICMP, INET_DBG_LEVEL_REPETITIVE))
          {
            /*ICMP_DBGP(REPETITIVE, "handleIcmpRedirectErrors, REDIRECT not coming from a valid  gateway %ld.%ld.%ld.%ld, to host. \n",
              IPADDRDISPLAY(pxIcmpCbkData->pxIcmpHdr->u.dwGateway));*/
            DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "handleIcmpRedirectErrors, REDIRECT not coming from a valid  gateway ",
                                      pxIcmpCbkData->pxIcmpHdr->u.dwGateway);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, ", to host.");
          }
          return;
        }
      }

      break;
    }
    default:
      ASSERT(0);
  }
}

#ifdef _RADIX_ROUTING_ON_
void
handleIcmpInstanceMsgToUL(ubyte oErrNo,
                          ICMPMSGDATA *pxIcmpMsgData)
{
  /*
   * Did we bargain for this.... add the IPHDR infront of the data ( TCP/UDP)
   * within the NETPAYLOAD structure. Dont forget to increment the length and decrement
   * wOffset within NETPACKETACCESS
   */
  NETPACKET *pxNetPacket = pxIcmpMsgData->pxNetPacket;
  NETPACKETACCESS *pxNetPacketAccess = pxIcmpMsgData->pxNetPacketAccess;
  NETPAYLOAD *pxPayload = pxNetPacket->pxPayload;
  ubyte *poPayload = pxPayload->poPayload;
  ubyte2 wOffset = pxNetPacketAccess->wOffset;
  ubyte2 wLength = pxNetPacketAccess->wLength;
  IPHDR *pxIpHdr = NULL;
  ubyte oAllZero = 0x00;
  sbyte oSkip = 1;

  wOffset -= IPDEFAULT_HDRSIZE;
  poPayload += wOffset;

  pxIpHdr = (IPHDR*)poPayload;
  MOC_MEMSET((ubyte*) pxIpHdr, oAllZero, sizeof(IPHDR));

  pxIpHdr->oProtocol = pxIcmpMsgData->oProtocol;
  pxIpHdr->dwSrcAddr = pxIcmpMsgData->dwSrcAddr;
  pxIpHdr->dwDstAddr = pxIcmpMsgData->dwDstAddr;
  wLength += sizeof(IPHDR);

  pxNetPacketAccess->wOffset = wOffset;
  pxNetPacketAccess->wLength = wLength;

  reportIcmpErrorsToUL(oErrNo, pxNetPacket, pxNetPacketAccess, oSkip);
}
#endif /*end of _RADIX_ROUTING_ON_*/

#endif
