/*
 * ipfrag.c
 *
 * Implements the IP fragmentation
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/

#include "ipfrag_defs.h"

/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/

IPFRAG_DBG_VAR(DWORD g_dwIpFragDebugLevel = 0);


/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * IpFragInitialize
 *  Initialize the IP fragmentation library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpFragInitialize(void)
{
  /* Initialise DEBUG symbol to ERROR*/
  INET_DBG_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_ERROR);
  return 0;
}

/*
 * IpFragTerminate
 *  Terminate the IP fragmentation library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpFragTerminate(void)
{

  return 0;
}

/*
 * IpFragInstanceCreate
 *  Creates a IP fragmentation Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IpFragInstanceCreate(void)
{
  IPFRAGSTATE *pxIpFrag;
#ifdef __IPFRAG_USE_MEMPOOL__
  ubyte *poMemBuffer = NULL;
  MSTATUS status;
#endif
  /*Allocate memory for the the ip fragmentation state*/
  pxIpFrag = (IPFRAGSTATE *)MALLOC(sizeof(IPFRAGSTATE));
  ASSERT(pxIpFrag != NULL);
  MOC_MEMSET((ubyte *)pxIpFrag, 0, sizeof(IPFRAGSTATE));

  pxIpFrag->wMD = IPFRAG_DEFAULT_MDS;
  pxIpFrag->dwTO = IPFRAG_DEFAULT_TO;

  SNMP(xTcpipData.ipReasmTimeout = IPFRAG_DEFAULT_TO/1000); /* in sec */

  /*set the magic cookie*/
  IPFRAG_SET_COOKIE(pxIpFrag);

#ifdef __IPFRAG_USE_MEMPOOL__
  poMemBuffer = MALLOC(sizeof(FRAG_DATAGRAM) * IPFRAG_MAX_NUM_DGRAMS);
  if(!poMemBuffer)
  {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_ERROR))
    {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpFragRcv: unable to create buffer for datagram mempool of size: ", (sizeof(FRAG_DATAGRAM) * IPFRAG_MAX_NUM_DGRAMS));
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
    }
    return NULL;
  }
  /* Initialize MEMPOOL for FRAG_DATAGRAM structure */
  if (OK > (status = MEM_POOL_initPool(&pxIpFrag->fragDatagramPool, poMemBuffer, sizeof(FRAG_DATAGRAM) * IPFRAG_MAX_NUM_DGRAMS, sizeof(FRAG_DATAGRAM))))
    if( status < 0)
    {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_ERROR))
      {
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IpFragRcv: unable to initialise fragment datagram memory pool.");
      }
      return NULL;
    }

  poMemBuffer = MALLOC(sizeof(FRAG_PACKET) * IPFRAG_MAX_NUM_PACKETS);
  if(!poMemBuffer)
  {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_ERROR))
    {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpFragRcv: unable to create buffer for packet mempool of size: ", (sizeof(FRAG_PACKET) * IPFRAG_MAX_NUM_PACKETS));
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
    }
    return NULL;
  }
  /* Initialize MEMPOOL for FRAG_PACKET structure */
  if (OK > (status = MEM_POOL_initPool(&pxIpFrag->fragPacketPool, poMemBuffer, sizeof(FRAG_PACKET) * IPFRAG_MAX_NUM_PACKETS, sizeof(FRAG_PACKET))))
    if( status < 0)
    {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_ERROR))
      {
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IpFragRcv: unable to initialise fragment datagram memory pool.");
      }
      return NULL;
    }
#endif

  return (H_NETINSTANCE)pxIpFrag;
}

/*
 * IpFragInstanceDestroy
 *  Destroy a IP fragmentation Instance
 *
 *  Args:
 *   hIpFrag                       IP fragmentation instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpFragInstanceDestroy(H_NETINSTANCE hIpFrag)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
#ifdef __IPFRAG_USE_MEMPOOL__
  void *pTemp = NULL;
#endif

  IPFRAG_CHECK_STATE(pxIpFrag);
  clear_DLLIST(&pxIpFrag->dllPending,IpFragFreeDgram);

#ifdef __IPFRAG_USE_MEMPOOL__
  if (OK <= MEM_POOL_uninitPool(&pxIpFrag->fragPacketPool, &pTemp))
    FREE(pTemp);
  if (OK <= MEM_POOL_uninitPool(&pxIpFrag->fragDatagramPool, &pTemp))
    FREE(pTemp);
#endif

  IPFRAG_UNSET_COOKIE(pxIpFrag);
  FREE(pxIpFrag);

  return 0;
}

/*
 * IpFragInstanceSet
 *  Set a IP fragmentation Instance Option
 *
 *  Args:
 *   hIpFrag                   IP fragmentation instance
 *   oOption                   Option
 *   hData                     Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpFragInstanceSet(H_NETINSTANCE hIpFrag,
                       OCTET oOption,
                       H_NETDATA hData)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
  LONG lReturn = 0;

  IPFRAG_CHECK_STATE(pxIpFrag);
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_NORMAL))
  {
    /*IPFRAG_DBGP(NORMAL,"IpFragInstanceSet: Option: %x\n", oOption);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpFragInstanceSet: Option: ", oOption);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oOption) {

  case NETOPTION_FREE:
    pxIpFrag->pfnNetFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_MALLOC:
    pxIpFrag->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    ASSERT((void*)hData != NULL);
    pxIpFrag->pxMutex = (RTOS_MUTEX)hData;
    break;

  case NETOPTION_OFFSET:
    pxIpFrag->wOffset = (WORD)hData;
    break;

  case NETOPTION_TRAILER:
    pxIpFrag->wTrailer = (WORD)hData;
    break;

  case NETOPTION_NETCBK:
    pxIpFrag->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case IPFRAGOPTION_MD:
    pxIpFrag->wMD = (WORD)hData;
    break;

  case IPFRAGOPTION_TO:
    pxIpFrag->dwTO = (DWORD)hData;
    SNMP(xTcpipData.ipReasmTimeout = pxIpFrag->dwTO/1000); /* in sec */
    break;

  case IPFRAGOPTION_MTU:
  {
    MTUREQUEST* pxMtuRequest = (MTUREQUEST*)hData;
    ASSERT(pxMtuRequest->oIfIndex < MAX_LEG);
    pxIpFrag->awMtu[pxMtuRequest->oIfIndex] = pxMtuRequest->wMtu;
    break;
  }
  default:
    lReturn = -1;
    ASSERT(0);
  }

  return lReturn;
}


/*
 * IpFragInstanceMsg
 *  Send a msg to a IP instance
 *
 *  Args:
 *   hIpFrag                    IP fragmentation instance
 *   oMsg                       Msg. See netcommon.h and ipfrag.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpFragInstanceMsg(H_NETINSTANCE hIpFrag,
                       OCTET oMsg,
                       H_NETDATA hData)
{
  LONG lReturn = NETERR_NOERR;

  IPFRAG_CHECK_STATE((IPFRAGSTATE*) hIpFrag);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_NORMAL))
  {
    /*IPFRAG_DBGP(NORMAL, "IpFragInstanceMsg: oMsg: %x\n", oMsg);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpFragInstanceMsg: Option: ", oMsg);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oMsg) {
  case NETMSG_OPEN:
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    break;
  default:
    lReturn = -1;
    ASSERT(0);
  }
  return lReturn;
}

/*
 * IpFragInstanceULInterfaceCreate
 *
 *  Args:
 *   hIpFrag                       IP fragmentation instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IpFragInstanceULInterfaceCreate(H_NETINSTANCE hIpFrag)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
  IPFRAG_CHECK_STATE(pxIpFrag);

  ASSERT(pxIpFrag->oULNumberIf == 0);

  pxIpFrag->oULNumberIf = 1;

  return (H_NETINTERFACE)1;
}

/*
 * IpFragInstanceULInterfaceDestroy
 *  Destroy a IP fragmentation UL interface
 *
 *  Args:
 *   hIp                       IP fragmentation instance
 *   hULIf                     Interface handle
 *
 *  Return:
 *   >= 0 if successful
 */
LONG IpFragInstanceULInterfaceDestroy(H_NETINSTANCE hIpFrag,
                                      H_NETINTERFACE hULIf)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
  IPFRAG_CHECK_STATE(pxIpFrag);

  ASSERT( (pxIpFrag->oULNumberIf == 1) && ((H_NETINTERFACE)hULIf == 1));

  pxIpFrag->oULNumberIf = 0;

  return NETERR_NOERR;
}

/*
 * IpFragInstanceULInterfaceIoctl
 *  IpFrag UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and nettransport.h
 *  for precisions
 *
 *  Args:
 *   hIpFrag                      IP fragmentation instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IpFragInstanceULInterfaceIoctl(H_NETINSTANCE hIpFrag,
                                    H_NETINTERFACE hULIf,
                                    OCTET oIoctl,
                                    H_NETDATA hData)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
  LONG lReturn = NETERR_NOERR;

  IPFRAG_CHECK_STATE(pxIpFrag);

  /*check if the interface is out of range*/
  ASSERT((OCTET)hULIf == pxIpFrag->oULNumberIf);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_NORMAL))
  {
    /*IPFRAG_DBGP(NORMAL, "IpFragInstanceULInterfaceIoctl: oIoctl: %x\n", oIoctl);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpFragInstanceULInterfaceIoctl: oIoctl: ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* ignore those */
    break;
  case NETINTERFACEIOCTL_SETHINST:
    pxIpFrag->hULInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIpFrag->pfnRxCbk = (PFN_NETRXCBK)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIpFrag->hULIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = -1;
    ASSERT(0);
  }


  return lReturn;
}




/*
 * IpFragInstanceLLInterfaceCreate
 *
 *  Args:
 *   hIpFrag                       IP fragmentation instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IpFragInstanceLLInterfaceCreate(H_NETINSTANCE hIpFrag)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
  IPFRAG_CHECK_STATE(pxIpFrag);

  ASSERT(pxIpFrag->oLLNumberIf == 0);

  pxIpFrag->oLLNumberIf = 1;

  return (H_NETINTERFACE)1;
}

/*
 * IpFragInstanceLLInterfaceDestroy
 *  Destroy a IP fragmentation LL interface
 *
 *  Args:
 *   hIp                       IP fragmentation instance
 *   hLLIf                     Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG IpFragInstanceLLInterfaceDestroy(H_NETINSTANCE hIpFrag,
                                      H_NETINTERFACE hLLIf)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;

  IPFRAG_CHECK_STATE(pxIpFrag);

  ASSERT( (pxIpFrag->oLLNumberIf == 1) && ( (H_NETINTERFACE)hLLIf == 1));

  pxIpFrag->oLLNumberIf = 0;

  return NETERR_NOERR;
}

/*
 * IpFragInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hIpFrag                      Ip fragmentation instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IpFragInstanceLLInterfaceIoctl(H_NETINSTANCE hIpFrag,
                                 H_NETINTERFACE hLLIf,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
  LONG lReturn = NETERR_NOERR;

  IPFRAG_CHECK_STATE(pxIpFrag);

  /*Check if the LL Interface is valid*/
  ASSERT( (int)hLLIf == 1);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_NORMAL))
  {
    /*IPFRAG_DBGP(NORMAL, "IpFragInstanceLLInterfaceIoctl: oIoctl: %x\n", oIoctl);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpFragInstanceLLInterfaceIoctl: oIoctl: ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oIoctl) {

  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* Ignore these */
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxIpFrag->hLLInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIpFrag->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIpFrag->hLLIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}



