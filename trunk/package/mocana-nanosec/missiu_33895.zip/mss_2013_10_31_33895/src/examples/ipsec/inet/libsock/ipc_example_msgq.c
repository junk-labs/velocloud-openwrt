
/*
 * ipc_example_msgq.c
 *
 * IPC   Example using MSGQ as Transport Layer
 * This code should work fine for Linux, Windows and VxWorks
 *
 * Copyright Mocana Corp 2003-2006. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/* Add to your makefile */

#include "NNstyle.h"
/*
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "sys/types.h"
#include "sys/socket.h"
#include "netinet/in.h"
#include "arpa/inet.h"
#include "pthread.h"
*/
#include "netcommon.h"

#ifdef __RTOS_LINUX__
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#endif

#include "../common/moc_ip.h"
#include "../utils/mocinclude.h"
#include "libsock.h"

/*------------------------------------------------------------------*/
static MSTATUS IPC_EXAMPLE_MSGQ_startClient(_ipc_entity_t  *myipcEntity);
static sbyte4 msgq_sessionIdCompare (const void *p1, const void *p2, const void *config);
/*------------------------------------------------------------------*/

#define  IPC_MAX_BUF_SIZE  8192

static rbtree_t *sessionTree;
static sbyte4   myMsgqid;
static sbyte4   myMsgType ;

struct msgbuf
{
    long mtype;     /* message type, must be > 0 */
    char mtext[IPC_MAX_BUF_SIZE];  /* message data */
};

typedef struct
{
    struct rbnode       node;
    ubyte4          msgtype ;
    sbyte4          msgqid ;
    ubyte*          ipcHdl;
} msgq_t;

static MSTATUS funcPtrOpenConnection(ubyte **connHdl,ubyte *params,
                              ipc_params_t ipc_params,ubyte *ipcHdl)
{
    MSTATUS status = OK;
    _ipc_conn_params_t *connParams = (_ipc_conn_params_t *)params;

    ubyte4 key = (connParams->instance_id  & 0xFF ) << 16 |
                 (connParams->node_id  & 0xFF) << 8       |
                 (connParams->proc_id & 0xFF)             ;
    msgq_t*        msgq = NULL;
    msgq_t*        tMsgq = NULL;


    msgq = MALLOC(sizeof(msgq_t));
    if (!msgq)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    msgq->ipcHdl = ipcHdl;
    msgq->msgtype  = key;

    msgq->msgqid = msgget(key,IPC_CREAT | 0666);


    tMsgq = (msgq_t *)rbsearch (msgq,sessionTree);

    if (!tMsgq)
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    if (tMsgq != msgq)
    {
        FREE(msgq);
        msgq = tMsgq;
    }

    *connHdl = (ubyte *)msgq;

    printf("The Conn Key Created is %x",key);
exit:
    if (OK > status)
    {
        if (msgq)
            FREE(msgq);
    }

    return status;
}


static MSTATUS
funcPtrCloseConnection(ubyte *connHdl)
{

    MSTATUS         status = 0;
    msgq_t*        msgq = (msgq_t *)connHdl;

    msgctl(msgq->msgqid, IPC_RMID, NULL);
    rbdelete (msgq,sessionTree);
    FREE(msgq);

exit:
    return status;
}

static MSTATUS
funcPtrSendData(ubyte *connHdl,ubyte *pPkt,ubyte4 pktLen,ubyte4 *wrote_bytes)
{

    MSTATUS        status = 0;
    msgq_t*        msgq = (msgq_t *)connHdl;
    struct msgbuf  msg;

    msg.mtype = myMsgType;
    MOC_MEMCPY((ubyte *)msg.mtext,pPkt,pktLen);
    DEBUG_ERROR(DEBUG_IPC_MESSAGE,"Sending Mtype Value is ",msg.mtype);
    status =  msgsnd(msgq->msgqid, (ubyte *)&msg, pktLen , IPC_NOWAIT);
    if (OK == status)
        *wrote_bytes = pktLen;
    else
    {
        msgq->msgqid = msgget(msgq->msgtype,IPC_CREAT | 0666);
    }
    printf("Wrote %d",pktLen);
exit:
    if (OK > status)
        perror("Send Error\n");
    return status;

}

static MSTATUS
funcPtrReadData(ubyte *connHdl,ubyte *pPkt,ubyte4 pktLen,ubyte4 *readLen)
{

    MSTATUS         status = 0;
    msgq_t*        msgq = (msgq_t *)connHdl;
    struct msgbuf  msg;
    sbyte4 pLen;

    pLen = msgrcv(msgq->msgqid,&msg,IPC_MAX_BUF_SIZE,msgq->msgtype,IPC_NOWAIT);

    if ( 0 <= pLen)
    {
        *readLen = pLen;
        if (pLen)
        {
            MOC_MEMCPY(pPkt,msg.mtext,pLen);
        }
    }
    else
        status = pLen;
exit:
    return status;
}

extern  void
IPC_EXAMPLE_MSGQ_main(sbyte4 arg)
{
    MSTATUS status = OK;
    gMocanaAppsRunning++;
    sbyte4 key;
    _ipc_entity_t  *myipcEntity  = (_ipc_entity_t *)arg;

    IPC_EXAMPLE_MSGQ_startClient(myipcEntity);

    sessionTree = (rbtree_t *) rbinit (msgq_sessionIdCompare,NULL,0);

    key = ((myipcEntity->instance_id  & 0xFF ) << 16) |
           (myipcEntity->node_id  & 0xFF) << 8       |
           (myipcEntity->proc_id & 0xFF)             ;

    DEBUG_ERROR(DEBUG_IPC_MESSAGE,"Key Value is ",key);
    printf("Key Value is 0x%x\n",key);


    myMsgType =  key;

    myMsgqid = msgget(key,IPC_CREAT | 0666);
    /* Clean it up */
    msgctl(myMsgqid, IPC_RMID, NULL);
    /* Start it again */
    myMsgqid = msgget(key,IPC_CREAT | 0666);

#ifdef __RTOS_LINUX__
    while (1)
    {

        _ipc_entity_t  ipcEntity;
        int status = 0,i;
        msgq_t * msgq = NULL;
        msgq_t  tMsgq ;
        sbyte4 pktLen = 0;
        struct msgbuf pPkt;
        ipc_params_t ipc_params;
        _ipc_conn_params_t connParams ;

        IPC_checkTimer();

        RTOS_sleepMS(50);
        pktLen = msgrcv(myMsgqid,&pPkt,IPC_MAX_BUF_SIZE,0,IPC_NOWAIT);
        if (pktLen <= 0)
        {
            if (OK > pktLen)
                perror("rcv Error\n");
            continue;
        }
        tMsgq.msgtype = pPkt.mtype;
        msgq = (msgq_t *)rbfind(&tMsgq,sessionTree);

        if (!msgq)
        {
            /* Create a msgq struct */
            /* Open Session Indication */
            connParams.instance_id  = (tMsgq.msgtype >> 16) & 0XFF;
            connParams.node_id  = (tMsgq.msgtype >> 8) & 0XFF;
            connParams.proc_id  = (tMsgq.msgtype ) & 0XFF;

            status =  funcPtrOpenConnection((ubyte **)&msgq,(ubyte *)&connParams, ipc_params,NULL);
            if (OK > status)
                continue;
            ipcEntity.node_id     = connParams.node_id;
            ipcEntity.proc_id     = connParams.proc_id;
            ipcEntity.instance_id = connParams.instance_id;

            status = IPC_openConnectionInd((ubyte **)&msgq->ipcHdl,(ubyte *)msgq,ipcEntity);
            if (OK > status  )
            {
                funcPtrCloseConnection((void *)msgq);
                continue;
            }
        }

        /* Pass the message up */
        IPC_RecvDataInd(msgq->ipcHdl,pPkt.mtext,pktLen);

    }
#endif

exit:
    return;
}


static MSTATUS
IPC_EXAMPLE_MSGQ_startClient(_ipc_entity_t  *myipcEntity)
{
    MSTATUS         status = 0;
    sbyte4  tid;
    ipc_init_params init_params;

    init_params.funcPtrOpenConnection = funcPtrOpenConnection;

    init_params.funcPtrCloseConnection =  funcPtrCloseConnection;
    init_params.funcPtrSendData  = funcPtrSendData;
    init_params.funcPtrReadData =  funcPtrReadData;

    status = IPC_init (myipcEntity->proc_id, myipcEntity->node_id,myipcEntity->instance_id ,init_params );

exit:
    return status;
}

/*------------------------------------------------------------------*/

static void
ipc_receive_cb(_ipc_msg_t *recv_msg)
{
    /* Process The Message and Send Reply or Drop it if its One way */
    printf("Receoved MOdule Callback \n");
    /* Process The Message and Send Reply or Drop it if its One way */
    printf("Received IPC Message yeay Yeah \n");
    IPC_reply(recv_msg,recv_msg);
}

static void (_ipc_response_cb)(MSTATUS e, _ipc_msg_t *sent_msg,
                                     _ipc_msg_t *recv_msg, void *arg)
{
    printf("Receoved Reply to our Async Request \n");
#ifdef __ENABLE_MOCANA_DEBUG_MEMORY__
            /* dbg_dump(); */
            /* exit(0); */
#endif

}
static _module_id_t module_id = 10;
extern MSTATUS SOCKCLIENT_init();

extern void
IPC_EXAMPLE_MSGQ_startModClient(sbyte4 arg)
{

    _ipc_msg_t * ipc_msg = NULL;
    _ipc_msg_t * recvMsg = NULL;
    ubyte2 req = 1;
    MSTATUS status = IPC_registerModule (module_id, ipc_receive_cb );
    SOCKCLIENT_init();
    ubyte2 x = 0;

    while (1)
    {
        RTOS_sleepMS(50);
        IPC_loop();

    }
}


void
do_sockopt()
{

    printf("**************Sending Sync Request   \n");
    DEBUG_UPTIME(DEBUG_EAP_MESSAGE);
    socket(AF_INET,SOCK_DGRAM,0);
    DEBUG_UPTIME(DEBUG_EAP_MESSAGE);
    printf("**************Received Reply to our Sync Request \n");

}
/*------------------------------------------------------------------*/

static sbyte4
msgq_sessionIdCompare (const void *p1,
                      const void *p2,
                      const void *config)
{
    msgq_t* a = (msgq_t *)p1;
    msgq_t* b = (msgq_t *)p2;
    sbyte4          compareResults = 0;
    MOC_UNUSED(config);

    if (a->msgtype < b->msgtype)
        compareResults = -1;
    else if (a->msgtype > b->msgtype)
        compareResults = 1;
    return compareResults;
}

/*------------------------------------------------------------------*/
