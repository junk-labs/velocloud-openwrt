/*
 * tcpdefs.h
 *
 * TCP module common definitions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef __TCPDEFS_H__
#define __TCPDEFS_H__

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "nettransport.h"
#ifndef __MOCANA_LIBSOCK__
#include "../../utils/mocinclude.h"
#endif

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/
#define min3(a,b,c) min(min(a,b),c)

#define TCP_USRPORT   1024
#ifndef __TCP_OPT_ON__
#define TCP_MAXPORT   50000
#else
#define TCP_MAXPORT   5000
#endif
#define TCP_ISSINCR   2500

/*
 * Connection related constants
 */

/* We use the Octet Flag to code the mode (listen, connect)
   as well as the standard TCP flags */
#define TCPCONN_FLAGMASK_MODE           0x40
#define TCPCONN_FLAGVALUE_MODELISTEN    0x40
#define TCPCONN_FLAGVALUE_MODECONNECT   0x00

/* Flow control constants */
#define TCP_TX_MAXSPACE (2*TCPULINTERFACEDEFAULT_MSS)
/* #define TCP_TX_MAXSPACE (MAX_TCP_WINDOW_SIZE) */
#define TCP_TX_RELSPACE (TCPULINTERFACEDEFAULT_MSS)

#define TCP_RX_MAXSPACE (2*TCPULINTERFACEDEFAULT_WIN)
/* #define TCP_RX_MAXSPACE (MAX_TCP_WINDOW_SIZE) */
#define TCP_RX_RELSPACE (TCPULINTERFACEDEFAULT_WIN)


/*
 * Constants from previous tcp.h
 */

/*Used for enabling/disabling datatransfer in call to function tcp_send_segment*/
#define TCP_DATAON      1
#define TCP_NODATA      0

/*signalize an active/passive tcp_open */
#define TCP_ACTIVEOPEN  1
#define TCP_PASSIVEOPEN 0

/*signalize to read only pushed/all data by tcp_get() */
#define TCP_PUSHED_DATA 1
#define TCP_NO_PUSH     0

/*sending a FIN with the last data segement on/off */
#define TCP_FIN_ON      1
#define TCP_NO_FIN      0

/*used for building the SRTT (multiplied with 100 to avoid floating point calc*/
#define TCP_RTO_ALPHA   85                      /*0.85*/
#define TCP_RTO_BETA    165             /*1.65*/

/*upper und lower bound for the RTO */
/*counted in 1 ms dwTicks*/
#define TCP_RTO_UBOUND  60000            /* 1 min*/
#define TCP_RTO_LBOUND  3000             /* 3 sec*/

/*nbr of retries (for retransmit) before purging a connection */
#define TCP_MAX_RETRIES        6

/*upper und lower bound for the persist timer */
/*counted in 500 ms slow ticks*/
#define TCP_PER_UBOUND  120             /* 1 min*/
#define TCP_PER_LBOUND  10              /* 5 sec*/
#define TCP_PER_MAXSHF  12

/*non-configurable timers */
#define TCP_FINWAIT2_TIMER  (60*2)
#define TCP_CONESTAB_TIMER  (75*2)
#define TCP_KEEPINTL_TIMER  (75*2)
#define TCP_MAX_IDLE_TIMER  (600*2)

/*TCP options */
#define TCP_OPT_END  0
#define TCP_OPT_NOOP 1
#define TCP_OPT_MSS  2
#define TCP_OPT_WSF  3
#define TCP_OPT_TMST 8
#define TCP_OPT_ON   1
#define TCP_OPT_OFF  0

/* RX, TX event limits */
#define TCP_RX_ERRS_THRESHOLD        4
#define TCP_TX_ERRS_THRESHOLD        4

#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
#define TCP_RTX_BUF_MAX         25000 /* we need to think upon a value - Ajit*/
#define TCP_RAS_BUF_MAX         25000 /* - Ajit - */
#define TCP_SND_BLK_MAX         25000 /* - Ajit - */
#endif

  /* Timers Mask */
#define  FINWAIT_2MSL_TIMER 0x1  /* FIN_WAIT_2 & 2MSL timer */
#define  CONESTAB_TIMER     0x2 /* Conn. est. & keepalive timer */
#define  PERSIST_TIMER      0x4   /* Persist timer */
#define  LINGER_TIMER       0x8    /* Closing linger time */
#define  REASM_TIMER        0x10    /* Reassembly timer */
#define  RETRANSMIT_TIMER   0x20 /* Retransmit Timer */
#define  FASTACK_TIMER      0x40 /* Retransmit Timer */
/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/

typedef enum {
  TCPCONN_STATE_CLOSED = 0,
  TCPCONN_STATE_LISTEN,
  TCPCONN_STATE_SYNSENT,
  TCPCONN_STATE_SYNRCVD,
  TCPCONN_STATE_ESTABLISHED,
  TCPCONN_STATE_FIN_WAIT_1,
  TCPCONN_STATE_FIN_WAIT_2,
  TCPCONN_STATE_CLOSING,
  TCPCONN_STATE_TIME_WAIT,
  TCPCONN_STATE_CLOSE_WAIT,
  TCPCONN_STATE_LAST_ACK
} E_TCPCONN_STATE;

typedef struct {

  /* timeout info */
  DWORD dwLastUsed;

} TCPCONN_LISTEN;

typedef struct {

  DLLIST dllReTxBuff;
  DLLIST dllReAsBuff;
  DLLIST dllSendBuff;

#ifdef __TCP_USE_MEMPOOL_PERF__
  poolHeaderDescr                 retransPool;    /* Re-Transmission pool*/
  poolHeaderDescr                 reassemblePool; /* Re-Assemble pool */
  poolHeaderDescr                 sendbuffPool;   /* Send pool*/
#endif

  /* Tx */
  DWORD dwSendUnacked;
  DWORD dwSendNext;
  DWORD dwSendWindow;
  DWORD dwSendWl1;
  DWORD dwSendWl2;
  DWORD dwSendIss;
#ifdef TCPSECURE
  DWORD dwMaxSendWindowSize;
#endif

  /* Rx */
  DWORD dwRcvNext;
  DWORD dwRcvWindow;
  DWORD dwRcvIrs;

  /* Segment */
  DWORD dwSegSequenceNumber; /* Sequence number of the 1st unacked
                                packet (== 1st packet in the
                                retransmission list */

  /* Flow control information */
  WORD wRxUsedSpace;
  WORD wTxUsedSpace;
  BOOL bTxNoSpace;

  OCTET oSegControl;     /* Segment control */
  BOOL  bFinAcked;       /* FIN acked */
  BOOL  bCloseCalled;    /* Close called on this socket */
  BOOL  bDelayedAck;     /* Waiting for delayed ACK */
  BOOL  bForce1Byte;     /* Force one byte for persist timer */
  OCTET oPersistCount;   /* Persist count */
  DWORD dwSegAckNumber;  /* Acknowledgement number */
  DWORD dwSegLength;     /* Segment length */
  DWORD dwSegWindow;     /* Segment window */
  OCTET oPassiveOpen;    /* Identify a Passive Open */

  /* Timers */
  DWORD wFinwait2Timer;  /* FIN_WAIT_2 & 2MSL timer */
  DWORD wConestabTimer;  /* Conn. est. & keepalive timer */
  DWORD wPersistTimer;   /* Persist timer */
  DWORD wIdleTimer;      /* Idle timer */
  DWORD wLingerTimer;    /* Closing linger time */
  DWORD wReasmTimer;     /* Reassembly timer */
  DWORD dwLastUsed;      /* Last time control block accessed */
  DWORD wRetransmitTimer; /* Retransmit Timer */
  DWORD wFastackTimer;    /* Retransmit Timer */

  /* RTO data */
  DWORD dwSrtt;
  DWORD dwRto;

  /* info on rx data */
  DWORD dwLastUnpackedSequenceNbr;

  /* The Current TCPSTATE to which this connection belongs  */
  H_NETINSTANCE hTcp;
  /* The Current TCPCONN to which this connection belongs  */
  H_NETINSTANCE hConn;

} TCPCONN_CONNECT;

#ifndef __TCP_OPT_ON__

struct tcpConn_s;

typedef LIST_HEAD(TCP_TIMER_LIST, tcpConn_s)   TCP_TIMER_LIST;

#endif

typedef struct tcpConn_s {

#ifndef __TCP_OPT_ON__
  struct rbnode            connnode;
  LIST_ENTRY(tcpConn_s)    persist_link;
  LIST_ENTRY(tcpConn_s)    linger_link;
  LIST_ENTRY(tcpConn_s)    finack2_link;
  LIST_ENTRY(tcpConn_s)    reasm_link;
  LIST_ENTRY(tcpConn_s)    conestab_link;
  LIST_ENTRY(tcpConn_s)    retrans_link;
  LIST_ENTRY(tcpConn_s)    fastack_link;
  LONG  lFd;
#endif

#ifndef NDEBUG
  DWORD dwMagicCookie; /* Must be TCP_MAGICCOOKIE if valid */
#endif
  LONG  lConnNo;

  E_TCPCONN_STATE eState;

  H_NETINSTANCE hUL;
  H_NETDATA hIf;
  TRANSPORTID xId;
  WORD wMss;
  WORD wLocalMss;
  WORD wWin;
  WORD dwAppWinFactor;
  WORD wRxChecksumErrs;
  WORD wRxBadLenErrs;
  WORD wTxRetransSegs;
  WORD wTxMemCopies;
  WORD wRxMemCopies;

  WORD wLrblyu;
  WORD wReasmTimer;

  PFN_NETRXCBK pfnRxCbk;
  PFN_TCPULINTERFACECBK pfnCbk;

  OCTET oFlag;
  BOOL bIsReuseAllowed;


  H_NETINSTANCE hTcp;/* This Conns TCPSTATE Struct */

  union {
    TCPCONN_LISTEN *pxListen;
    TCPCONN_CONNECT *pxConnect;
  }u;

} TCPCONN;

#ifndef __TCP_OPT_ON__

typedef enum TCP_TIMER_TYPE
{
    TCP_TIMER_PERSIST  = 1,
    TCP_TIMER_LINGER   = 2,
    TCP_TIMER_FINWAIT2 = 3,
    TCP_TIMER_CONESTAB = 4,
    TCP_TIMER_REASM    = 5,
    TCP_TIMER_RETRANS  = 6,
    TCP_TIMER_FASTACK  = 7,
} TCP_TIMER_TYPE;

#endif

typedef struct
{

    DWORD dwNumCreated;
    DWORD dwNumCurrent;
    DWORD dwNumListening;
    DWORD dwNumConnected;
    DWORD dwNumConnectedHW;
    DWORD dwNumAccepted;
    DWORD dwNumRecvSyncOnConnected;
    DWORD dwNumAcceptErrors;
    DWORD dwNumConnectErrors;
    DWORD dwNumRecvErrors;
    DWORD dwNumNoSocketErrors;
    DWORD dwNumPortErrors;

} TCPSTATS;

typedef struct {

  /*
   * TCP instance options
   *  !!! They must be stored here in the exact same order as the E_TCPOPTION
   *  enum !!! as the query and set functions use it as an index to access
   *  them (which also implies that their type can't be changed without
   *  changing these functions !)
   */

#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif
  WORD wOffset;
  WORD wTrailer;
  WORD w2mslTimer;
  WORD wRttTimer;
  WORD wPersistTimer;
  WORD wKeepAliveTimer;
  WORD wMaxConn;
  /* END instance Options */

  /* Clock variables */
  DWORD dwTicks;
  DWORD dwTcpFastTimeoutLastCalled;
  DWORD dwTcpSlowTimeoutLastCalled;
  DWORD dwIss;

  /* Network Callback */
  PFN_NETCBK pfnNetCbk;
  PFN_NETMALLOC pfnNetMalloc;
  PFN_NETFREE pfnNetFree;

  pthread_mutex_t *pxMutex;

  /* Connections Link.
     This needs to be organized so that it is simple to
     find a connection from both the IP addresses and the
     port. SB : probably a 4 dimensionnal array of link lists
     (x= Local IP address, y = Local IP port, z = Remote IP
     w = Remote port) Depends on the average number of connections
     we expect
     Do that later : for now 1 linklist.
     We use the Dll library as this is not time critical */
  DLLIST dllConns;
#ifndef __TCP_OPT_ON__
  /* Rbtree for the Connections */
  rbtree_t          *connTree;
  /* BitMAP for the TCP Port Numbers Needs to be per Interface */
  /* JJ  As of now Lets assume that there is only 1 Bitmap for all the
     interfaces.. We will add the vlan and multiple interfaces support
     later on */
  void       *portNumbers;
  /* Ordered List for all the connection timers */

  TCP_TIMER_LIST  lPersistList;
  TCP_TIMER_LIST  lLingerList;
  TCP_TIMER_LIST  lFinwait2List;
  TCP_TIMER_LIST  lConestabList;
  TCP_TIMER_LIST  lReasmList;
  TCP_TIMER_LIST  lRetransList;
  TCP_TIMER_LIST  lFastackList;

#endif

  /* Lower interface */
  H_NETDATA hTcpLLIf;
  H_NETINSTANCE hLL;
  PFN_NETWRITE pfnLLWrite;
  TCPSTATS  hTcpStats;

#ifdef __TCP_USE_MEMPOOL__
  poolHeaderDescr                 connPool;
#endif

#ifdef __TCP_USE_MEMPOOL_NORMAL__
  poolHeaderDescr                 retransPool;    /* Re-Transmission pool*/
  poolHeaderDescr                 reassemblePool; /* Re-Assemble pool */
  poolHeaderDescr                 sendbuffPool;   /* Send pool*/
#endif

} TCPSTATE;

/*control struct for sending data*/
typedef struct {
  OCTET *poNextToSendData;
  WORD wDatalen;
  WORD wSent;
  NETPACKET xNetPacket;
  NETPACKETACCESS xAccess;
  OCTET oRetries;
  OCTET oFlags;
  BOOL bFinStateAfterTransmit;
#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  H_NETINSTANCE hTcp; /* Holds the TCPSTATE(__TCP_USE_MEMPOOL_NORMAL__) OR TCPCONN_CONNECT (__TCP_USE_MEMPOOL_PERF__), used while clearing entry within the list */
#endif
} TCP_SND_BLK;

/*This Buffer stores the the data of segments sent until ACK is received*/
/*chained list structure*/
typedef struct {
  DWORD dwSequenceNbr; /*Sequence Number of the first Byte in this Buffer*/
  DWORD dwTimeStamp;
  OCTET oFlags;
  OCTET oRetries;
  NETPACKET xNetPacket;
  NETPACKETACCESS xAccess;
#if defined (__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  H_NETINSTANCE hTcp; /* Holds the TCPSTATE(__TCP_USE_MEMPOOL_NORMAL__) OR TCPCONN_CONNECT (__TCP_USE_MEMPOOL_PERF__), used while clearing entry within the list */
#endif
} TCP_RTX_BUF;

/*This buffer is for the incomming data to be queued for reassmebly (reorder) after the receive user call*/
typedef struct {
  OCTET *poBegin;
  NETPACKET xNetPacket;
  WORD wDatalen;
  BOOL bPushFlag;
  DWORD dwSequenceNbr; /*Sequence Number of the first Byte in this Buffer*/
#if defined(__TCP_USE_MEMPOOL_NORMAL__) || defined (__TCP_USE_MEMPOOL_PERF__)
  H_NETINSTANCE hTcp; /* Holds the TCPSTATE(__TCP_USE_MEMPOOL_NORMAL__) OR TCPCONN_CONNECT(__TCP_USE_MEMPOOL_PERF__), used while clearing entry within the list */
#endif
} TCP_RAS_BUF;


#endif /* #ifndef __TCPDEFS_H__*/
