/*
 * routerinstquery.c
 *
 * Implements the router
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/
#include "router.h"
#include "router_defs.h"

/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * RouterInstanceQuery
 *  Query a Router Instance Option
 *
 *  Args:
 *   hRouter                   Router instance
 *   oOption                   Option
 *   phData                    Option data pointer (to fill up)
 *
 *  Return:
 *   NETERR_NOERR success
 *   NETERR_UNKNOWN error
 */
LONG RouterInstanceQuery(H_NETINSTANCE hRouter,
                         OCTET oOption,
                         H_NETDATA *phData)
{
  ROUTERSTATE *pxRouter = (ROUTERSTATE *)hRouter;
  LONG lReturn = NETERR_NOERR;

  ROUTER_CHECK_STATE(pxRouter);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_ERROR))
  {
    /*ROUTER_DBGP(DBGLVL_ERROR_RARE, "RouterInstanceQuery: Option: %x\n", oOption);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceQuery: Option: ", oOption);
    DEBUG_PRINT(DEBUG_MOC_IPV4, NULL);
  }

  switch(oOption) {
  case NETOPTION_FREE:
  case NETOPTION_MALLOC:
    break;
  case NETOPTION_PAYLOADMUTEX:
    *phData = (H_NETDATA)pxRouter->pxMutex;
    break;

  case NETOPTION_OFFSET:
    *phData = (H_NETDATA)pxRouter->wOffset;
    break;

  case NETOPTION_TRAILER:
    *phData = (H_NETDATA)pxRouter->wTrailer;
    break;

  case NETOPTION_NETCBK:
    *phData = (H_NETDATA)pxRouter->pfnNetCbk;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    NETDBG_ASSERT(0);
  }

  return lReturn;
}
