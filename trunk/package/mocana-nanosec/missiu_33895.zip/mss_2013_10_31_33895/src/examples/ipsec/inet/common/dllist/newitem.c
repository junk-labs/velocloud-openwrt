#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

extern poolHeaderDescr gDLLIST_ITEM_pool;
extern unsigned long gDLLIST_ITEM_poolCount;


DLLIST_ITEM *new_DLLIST_ITEM_fl(DLLIST *dllist, char *pFile, int nLine)
{
  DLLIST_ITEM *tmp1;
  MSTATUS status = OK;

  if (dllist->free) 
  {
    tmp1 = dllist->free;
    dllist->free = tmp1->next;
  
  }
  else 
  { 
    //tmp1 = (DLLIST_ITEM *) malloc_fl(sizeof(DLLIST_ITEM), pFile, nLine);
    if(OK > (status =
             MEM_POOL_getPoolObject(&gDLLIST_ITEM_pool, (void **)&tmp1)))
    {
        /* Out of mempool */
        return(NULL); 
    }
    gDLLIST_ITEM_poolCount++;
  }
  
  return(tmp1);
}


void reserve_free_items_DLLIST_fl(DLLIST *pdllist, int n, 
                                  char *pFile, int nLine)
{
  DLLIST_ITEM **ppItem;
  MSTATUS status ;
  
  /* count n items on free list */
  ppItem = &(pdllist->free);
  while (n > 0) {
    /* if not one there, then malloc it */
    if (NULL == *ppItem) {
      //*ppItem = (DLLIST_ITEM *) malloc_fl(sizeof(DLLIST_ITEM), pFile, nLine);
      if(OK > (status =
             MEM_POOL_getPoolObject(&gDLLIST_ITEM_pool, (void **)(ppItem))))
      {
        /* Out of mempool */
        printf("Out of DLLIST ITEM Mempool\n");
        return; 
      }
      gDLLIST_ITEM_poolCount++;
      (*ppItem)->next = NULL;
    }

    /* next item */
    ppItem = &((*ppItem)->next);
    n--;
  }
} 
