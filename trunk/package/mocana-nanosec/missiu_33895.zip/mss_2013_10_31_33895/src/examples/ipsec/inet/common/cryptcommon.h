/*
 * cryptcommon.h
 *
 * encryption algorithm common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/*****************************************************************************
 *
 * typedefs
 *
 *****************************************************************************/

/*
 * Encryption Context holder
 */
typedef DWORD H_CRYPT;

/*
 * Crypt Initialisation function
 *  Creates the context holder
 */
typedef H_CRYPT (*PFN_CRYPT_INIT) (void);

/*
 * Crypt Update function
 */
typedef void (*PFN_CRYPT_UPDATE) (H_CRYPT hCrypt,OCTET *poInput,DWORD dwInputLength);

/*
 * Crypt Finish function.
 *  Writes the output. The output is already allocated
 *  as a digest algorithm advertises its hash size.
 *  Free the context
 */
typedef void (*PFN_CRYPT_FINISH) (H_CRYPT hCrypt,OCTET *poOutput);



