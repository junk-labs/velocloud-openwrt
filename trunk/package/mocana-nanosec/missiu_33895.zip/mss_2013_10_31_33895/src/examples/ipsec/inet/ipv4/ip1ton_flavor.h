#ifndef __FLAVOR_H__
#define __FLAVOR_H__

/* Map the build flavor into more meaningful constants internal
 * to the library.  The constant _FLAVOR_myflavor where myflavor is
 * the build flavor will be defined by the build environment.
 *
 * Be sure to check that a valid build flavor is defined.
 *
 * This file should be included by all source files.
*/

#if defined(_FLAVOR_gn)
#define IP1TON_MAXIF            NUM_IFS
#elif defined(_FLAVOR_gn1)
#define IP1TON_MAXIF            1
#elif defined(_FLAVOR_gn2)
#define IP1TON_MAXIF            2
#elif defined(_FLAVOR_gn3)
#define IP1TON_MAXIF            3
#elif defined(_FLAVOR_gn4)
#define IP1TON_MAXIF            4
#elif defined(_FLAVOR_gn5)
#define IP1TON_MAXIF            5
#elif defined(_FLAVOR_gn6)
#define IP1TON_MAXIF            6
#elif defined(_FLAVOR_gn7)
#define IP1TON_MAXIF            7
#elif defined(_FLAVOR_gn8)
#define IP1TON_MAXIF            8
#elif defined(_FLAVOR_gn9)
#define IP1TON_MAXIF            9
#elif defined(_FLAVOR_gn10)
#define IP1TON_MAXIF            10
#elif defined(_FLAVOR_gn11)
#define IP1TON_MAXIF            11
#elif defined(_FLAVOR_gn12)
#define IP1TON_MAXIF            12
#elif defined(_FLAVOR_gn13)
#define IP1TON_MAXIF            13
#elif defined(_FLAVOR_gn14)
#define IP1TON_MAXIF            14
#elif defined(_FLAVOR_gn15)
#define IP1TON_MAXIF            15
#elif defined(_FLAVOR_gn16)
#define IP1TON_MAXIF            16
#else
#  error Unknown Build Flavor
#endif

#endif
