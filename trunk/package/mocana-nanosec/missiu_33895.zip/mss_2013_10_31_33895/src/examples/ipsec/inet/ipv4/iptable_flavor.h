#ifndef __FLAVOR_H__
#define __FLAVOR_H__

/* Map the build flavor into more meaningful constants internal
 * to the library.  The constant _FLAVOR_myflavor where myflavor is
 * the build flavor will be defined by the build environment.
 *
 * Be sure to check that a valid build flavor is defined.
 *
 * This file should be included by all source files.
*/

#if defined(_FLAVOR_gn) || defined (_FLAVOR_ep0u) || defined (_FLAVOR_ep0) || \
    defined (_FLAVOR_dslep0) || defined (_FLAVOR_ep0d)
  /*#define IPTABLE_SINGLEIF - RS commented out */
#elif defined (_FLAVOR_ep1u) || defined (_FLAVOR_ep1) || \
      defined (_FLAVOR_ep1d) || defined (_FLAVOR_br)
  #define IPTABLE_PPP
  #define IPTABLE_SINGLEIF
#elif defined (_FLAVOR_rt) || defined (_FLAVOR_dslrt)
  #define IPTABLE_PPP
  #define IPTABLE_MCAST
#else
  #error "unknown build flavor"
#endif

/* Define following if currently unused features are required */
/* #define IPTABLE_UNUSED */

#endif // __FLAVOR_H__
