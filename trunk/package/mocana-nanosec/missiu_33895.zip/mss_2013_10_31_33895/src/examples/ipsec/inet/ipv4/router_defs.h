/*
 * router_defs.h
 *
 * router module common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __ROUTER_DEFS_H__
#define __ROUTER_DEFS_H__

/*****************************************************************************
 *
 * include
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "router_flavor.h"
#include "../include/socket.h"
#include "netcommon.h"
#include "netutils.h"
#include "netdefs.h"
#include "netcommon.h"
#include "netnetwork.h"
#include "router.h"
#include "router_dbg.h"
#include "netsnmp.h"
#include "ip.h"
#include "udp.h"
#include "tcp.h"
#include "../include/in.h"
#include "snmp_tcpip_data.h"
#include "ipfrag.h"
#include "iptable.h"
#include "routing_table.h"
#include "icmp.h"
#include "ipsec.h"

/*****************************************************************************
 *
 * define
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Structures & Typedefs
 *
 *****************************************************************************/
#ifdef IP_FILTERING
/*
 * IP filtering information.
 */
typedef struct {
  BOOL bInUse;
  WORD wFlags;
  DWORD dwIp;
} IP_FILTERING_ENTRY;
#endif

/*
 * Router instance structure
 */
typedef struct {
  /* Basic structure override protection */
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

  PFN_NETMALLOC pfnNetMalloc;
  PFN_NETFREE   pfnNetFree;
  PFN_NETCBK    pfnNetCbk;

  /* Options */
  WORD wOffset;
  WORD wTrailer;

  /* UL module */
  H_NETINSTANCE  hULInst;
  H_NETINTERFACE hULIf;
  PFN_NETRXCBK   pfnRxCbk;

  /* LL module */
  H_NETINSTANCE  hLLInst;
  H_NETINTERFACE hLLIf;
  PFN_NETWRITE   pfnLLWrite;

  OCTET oIfIdxLan;      /* holds the oIfIdx corresponding to the LAN */

  WORD awMtu[ROUTER_MAXNUM_IF];           /* MTU of all available interfaces */
  BOOL abRoutingDisabled[ROUTER_MAXNUM_IF];
  BOOL abIsLinkUp[ROUTER_MAXNUM_IF];

  RTOS_MUTEX pxMutex;

#ifdef IP_FILTERING
  OCTET oNumIpFilteringEntries;
  IP_FILTERING_ENTRY axIpFilteringTable[IP_FILTERING_TABLE_SIZE];
#endif

} ROUTERSTATE;

/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/
/*
 * RouterCheckFrag
 *  Utility to check if fragmentation is needed. Also sends
 *  ICMP message to the originating host if necessary.
 *
 * Args:
 *  hRouter                    router Instance handle
 *  pxNetPacket                Packet pointer
 *  pxNetPacketAccess          Packet access parameters
 *  hData                      pointer to a NETWORKID structure
 *  oSrcIfIdx                  Interface whose IP address to be used as source address.
 *  wSrcVlan                   Src Vlan
 *
 * Return:
 *  0                          no fragmentation needed
 *                             (or) packet can be fragmented.
 *  -1                         packet needs fragmentation, but
 *                             cannot be fragmented.
 */
LONG RouterCheckFrag(H_NETINSTANCE    hRouter,
                     NETPACKET        *pxNetPacket,
                     NETPACKETACCESS  *pxNetPacketAccess,
                     H_NETDATA        hData,
                     OCTET            oSrcIfIdx,
                     WORD             wSrcVlan);


/*
 * RouterSendIcmpMsg
 *  Sends ICMP message to the originating host if the
 * destination network is unreachable.
 *
 * Args:
 *  hRouter                    router Instance handle
 *  pxNetPacket                Packet pointer
 *  pxNetPacketAccess          Packet access parameters
 *  hData                      Pointer to a NETWORKID structure
 *  oSrcIfIdx                  Interface whose IP address to be used as source address.
 *  wSrcVlan                   Src Vlan
 *  oCbkMsg                    Callback message type.
 *
 * Return:
 *  None
 */
void RouterSendIcmpMsg(H_NETINSTANCE    hRouter,
                       NETPACKET        *pxNetPacket,
                       NETPACKETACCESS  *pxNetPacketAccess,
                       H_NETDATA        hData,
                       OCTET            oSrcIfIdx,
                       WORD             wSrcVlan,
                       OCTET            oCbkMsg);


#ifdef ROUTERDBG_HI
/*
 * RouterGetProtoName
 *  Returns the protocol name in human readable form.
 *
 * Args:
 *  oProtocol                  Protocol ID
 *
 * Return:
 *  Protocol name string.
 */
CHAR* RouterGetProtoName(OCTET oProtocol);
#endif

#ifdef IP_FILTERING
/**********************************************************************************
Function:
        RouterConfigIpFiltering()
Description:
        Configures an IP filtering entry.
Arguments:
        ROUTERSTATE*            pxRouter                Router instance handle.
        ROUTERCFG_IPFILTERING*  pxRouterCfgIpFiltering  IP Filtering configuration.
Outputs:
        None
Returns:
        None
Revisions:
        10-Jan-2003                                     Initial
**********************************************************************************/
void RouterConfigIpFiltering(ROUTERSTATE* pxRouter,
                             ROUTERCFG_IPFILTERING* pxRouterCfgIpFiltering);

/*****************************************************************************
Function:
        RouterIsIpAddrFiltered()
Description:
        Checks if the given IP address is part of the filtered
        addresses list.
Arguments:
        ROUTERSTATE*    pxRouter        Router instance handle.
        DWORD           dwIP            IP address to be checked.
        OCTET           oProtocol       Protocol in the received packet.
Outputs:
        None
Returns:
        BOOL            TRUE            If IP address should be
                                        filtered.
                        FALSE           Otherwise.
Revisions:
        03-Jan-2003                     Initial
*****************************************************************************/
BOOL RouterIsIpAddrFiltered(ROUTERSTATE* pxRouter, DWORD dwIp, OCTET oProtocol);

#endif /* IP_FILTERING */

#endif /* #ifndef __ROUTER_DEFS_H__ */
