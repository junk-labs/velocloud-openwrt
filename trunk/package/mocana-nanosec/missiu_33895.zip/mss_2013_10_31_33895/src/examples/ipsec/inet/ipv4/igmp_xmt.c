/*
 * igmp_xmt.c
 *
 * IGMP module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "igmp_defs.h"
#include "igmp_proxy_defs.h"


/*****************************************************************************
Function:
        igmp_proxy_xmt()
Description:
        This function is called periodically to send any pending IGMP
        client membership reports, and to process the IGMP client proxy
        state machine(s)
Arguments:
        pxIgmp            IGMP instance
Outputs:
        None
Returns:
        None
*****************************************************************************/
void IgmpXmt(IGMPSTATE *pxIgmp)
{
  LONG lCurrentTime = NetGetMsecTime();
  IP_MCAST *pMcast;

  IGMP_CHECK_STATE(pxIgmp);

  /*
   * IGMP HOST state machine
   */
  if ((pxIgmp->oReportVersion == (OCTET)IGMP_V1_MEMBERSHIP_REPORT) &&
      ((lCurrentTime - (LONG)pxIgmp->dwTimeIgmpV1) > IGMP_V1_ROUTER_TIMEOUT)) {
    /* IGMPv1 query was not heard in the last [Version 1 Router Timeout] msec */
    pxIgmp->oReportVersion = (OCTET)IGMP_V2_MEMBERSHIP_REPORT;
  }

  DLLIST_head(&pxIgmp->dllIpMcast);
  while ((pMcast = (IP_MCAST*)DLLIST_read(&pxIgmp->dllIpMcast)) != NULL) {

    if (pMcast->fpIgmpRcv == IgmpRcvStateDelay) {
      LONG lTimeDiff = (LONG)pMcast->dwTimeResponse - lCurrentTime;

      if (lTimeDiff < 0) {

        if(pMcast->xIpMreq.dwMulticastAddr != (DWORD)MULTI_ALL_SYSTEMS) {
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_NORMAL))
          {
            /*IGMP_DBGP(NORMAL,"IgmpXmt:Timer Expired:dwMcastAddr:%ld.%ld.%ld.%ld,CurrentTime:%ld,ResponseTime:%ld,lTimeDiff:%ld\n",
                    IPADDRDISPLAY(pMcast->xIpMreq.dwMulticastAddr),
                    lCurrentTime,
                    pMcast->dwTimeResponse,
                    lTimeDiff); */
            DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IgmpXmt:Timer Expired:dwMcastAddr:", pMcast->xIpMreq.dwMulticastAddr);
            DEBUG_PRINT(DEBUG_MOC_IPV4, "CurrentTime:");
            DEBUG_UINT(DEBUG_MOC_IPV4, lCurrentTime);
            DEBUG_PRINT(DEBUG_MOC_IPV4, ",ResponseTime:");
            DEBUG_UINT(DEBUG_MOC_IPV4, pMcast->dwTimeResponse);
            DEBUG_PRINT(DEBUG_MOC_IPV4, ",lTimeDiff:");
            DEBUG_UINT(DEBUG_MOC_IPV4, lTimeDiff);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
          }

          IgmpSendReport(pxIgmp,
                         &pMcast->xIpMreq,
                         IGMP_V2_MEMBERSHIP_REPORT);

          pMcast->fpIgmpRcv = IgmpRcvStateIdle;
          if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_NORMAL))
          {
            /*IGMP_DBGP(NORMAL,"IgmpXmt: sent igmp report: state change to idle\n");*/
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IgmpXmt: sent igmp report: state change to idle");
          }
        }
      }
    }
    DLLIST_next(&pxIgmp->dllIpMcast);
  }
}


#ifdef STACK_MULTICAST_ROUTER

/*****************************************************************************
Function:
        igmp_proxy_xmt()
Description:
        Must be called regularly to process the IGMP proxy state machine and
        group membership state machines for all groups registered on the
        downstream interface(s)
Arguments:
        pxIgmp               IGMP proxy instance
Outputs:
        None
Returns:
        None
Revisions:
        13-Oct-2001                     Initial
*****************************************************************************/
void IgmpProxyXmt(IGMPSTATE *pxIgmp)
{
  DWORD dwCurrentTime = (DWORD)NetGetMsecTime();
  MCAST_GROUP *pMcastGroup = NULL;

  IGMP_CHECK_STATE(pxIgmp);

  /*
   * IGMP PROXY state machine
   */
  switch(pxIgmp->eProxyState){
  case IGMP_PROXY_STATE_NON_QUERIER:
    if (dwCurrentTime > pxIgmp->dwProxyNonQuerierTimer) {
      /* We are the querier again! */
      pxIgmp->eProxyState = IGMP_PROXY_STATE_STARTUP;
      IgmpProxySendQuery(pxIgmp,0, (OCTET)QUERY_RESPONSE_INTERVAL/100);
      pxIgmp->dwProxyGeneralQueryTimer = dwCurrentTime + STARTUP_QUERY_INTERVAL;
      pxIgmp->dwProxyStartupQueryCount = 0;
    }

  case IGMP_PROXY_STATE_STARTUP:
    if (pxIgmp->dwProxyGeneralQueryTimer == 0) {
      pxIgmp->dwProxyGeneralQueryTimer = dwCurrentTime + STARTUP_INITIALIZATION_DELAY;
    }
    else {
      if (dwCurrentTime > pxIgmp->dwProxyGeneralQueryTimer) {
        IgmpProxySendQuery(pxIgmp,0, (OCTET)QUERY_RESPONSE_INTERVAL/100);
        pxIgmp->dwProxyGeneralQueryTimer = dwCurrentTime + STARTUP_QUERY_INTERVAL;
        if (++pxIgmp->dwProxyStartupQueryCount == STARTUP_QUERY_COUNT) {
          pxIgmp->eProxyState = IGMP_PROXY_STATE_QUERIER;
          pxIgmp->dwProxyGeneralQueryTimer = dwCurrentTime + QUERY_INTERVAL;
        }
      }
    }

  case IGMP_PROXY_STATE_QUERIER:
    if (dwCurrentTime > pxIgmp->dwProxyGeneralQueryTimer) {
      IgmpProxySendQuery(pxIgmp,0, (OCTET)QUERY_RESPONSE_INTERVAL/100);
      pxIgmp->dwProxyGeneralQueryTimer = dwCurrentTime + QUERY_INTERVAL;
    }
  }

  /*
   * IGMP group state machines
   */
  DLLIST_head(&pxIgmp->dllMcastGroups);
  while ((pMcastGroup = DLLIST_read(&pxIgmp->dllMcastGroups)) != NULL) {

    if (dwCurrentTime > pMcastGroup->dwGroupTimer) {
      /* Group is dead (no reports received in required duration) */
      IPMCASTREQ xIpMreq;
      xIpMreq.dwMulticastAddr = pMcastGroup->dwGroupIPAddress;
      xIpMreq.oPhyIf = NETIFIDX_ANY;

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_NORMAL))
      {
        /*IGMP_DBGP(NORMAL,"IgmpProxyXmt: Group %ld.%ld.%ld.%ld removed - assumed dead\n",
          IPADDRDISPLAY(pMcastGroup->dwGroupIPAddress));*/
        DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IgmpProxyXmt: Group ", pMcastGroup->dwGroupIPAddress);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, " removed - assumed dead");
      }

      DLLIST_remove(&pxIgmp->dllMcastGroups);
      FREE(pMcastGroup);

      if (IgmpMsgLeave(pxIgmp,&xIpMreq,FALSE) != 0) {
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_NORMAL))
        {
          /*IGMP_DBGP(NORMAL,"IgmpProxyXmt: IgmpMsgLeave failed for %ld.%ld.%ld.%ld on If %d\n",
                  IPADDRDISPLAY(xIpMreq.dwMulticastAddr),
                  xIpMreq.oPhyIf);*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IgmpMsgLeave failed for ", xIpMreq.dwMulticastAddr);
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " on If ", xIpMreq.oPhyIf);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }
        ASSERT(0);
      }

#ifdef IGMP_IPTABLEMCAST
      {
        /*
         * Remove multicast address from the repository.
         */
        IPTABLEENTRY xEntry;
        ROUTEENTRY xRouteEntry;

        xEntry.oIfIdx = xIpMreq.oPhyIf;
        xEntry.dwAddr = xIpMreq.dwMulticastAddr;
        xEntry.wDefaultVlan = NETVLAN_ANY;
        xEntry.eAddrType = IPADDRT_MULTICASTJOINEDPROXY;
        IpTableMsg(IPTABLEMSG_DELENTRY, (H_NETDATA)&xEntry);

        xRouteEntry.dwGateway    = xIpMreq.dwMulticastAddr;
        xRouteEntry.dwSubnetMask = 0xffffffff;
        xRouteEntry.dwDstAddr    = xIpMreq.dwMulticastAddr;
        xRouteEntry.wMetric      = 1;
        xRouteEntry.wTOS         = 0;
        xRouteEntry.oIfIdx       = pxIgmp->oProxyIfIndex;
        xRouteEntry.wVlan        = NETVLAN_ANY;

        RoutingTableMsg(ROUTINGTABLEMSG_DELROUTE,(H_NETDATA)&xRouteEntry);
      }

#endif

      continue;
    }

    switch (pMcastGroup->eGroupState) {
    case IGMP_GROUP_STATE_V1_MEMBERS_PRESENT:
      if (dwCurrentTime > pMcastGroup->dwV1HostTimer) {
        /* Assume no more V1 hosts in group */
        pMcastGroup->eGroupState = IGMP_GROUP_STATE_MEMBERS_PRESENT;
      }
      break;

    case IGMP_GROUP_STATE_CHECKING_MEMBERSHIP:
      if (dwCurrentTime > pMcastGroup->dwRTXTimer) {
        pMcastGroup->dwRTXTimer = dwCurrentTime + LAST_MEMBER_QUERY_INTERVAL;
        IgmpProxySendQuery(pxIgmp,pMcastGroup->dwGroupIPAddress,
                           (OCTET)LAST_MEMBER_QUERY_INTERVAL/100);
      }
      break;

    case IGMP_GROUP_STATE_MEMBERS_PRESENT:
      break;

    default:
      ASSERT(0);
    }


    DLLIST_next(&pxIgmp->dllMcastGroups);
  }
}


#endif /* #ifdef STACK_MULTICAST_ROUTER */
