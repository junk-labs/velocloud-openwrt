/*
 * trk.c
 *
 * code and vars for tracking
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



#if !defined(TRK_ON)
#  define TRK_ON
#endif

#if !defined(NDEBUG)
#include <stdio.h>
#endif
/*#include <stdio.h> */

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "NNstyle.h"
#include "dbg.h"
#include "eventmgr.h"
#include "errmgr.h"

#include <trk.h>


PTRKVARS pTrkVars = NULL;

H_TRK_USER hTrkUserError;


/* one bit per possible user, bit is on if user has registered */
#define NUM_REG_DWORDS ((1 << TRK_USER_NBITS) >> 5)
DWORD afTrkUserRegister[NUM_REG_DWORDS];


void TrkVerifyHandle(H_TRK_USER);

#if defined(NDEBUG)
#define TRK_ERR_MAP NULL
#else
ERR_NAME_MAP aTrkErrMap;
#define TRK_ERR_MAP &aTrkErrMap
void TrkFillErrNames(void);
#endif

H_ERR hTrkErr;

H_EVENT_CLASS hTrkEvent;


/*************************
 *
 *  init and registration
 *
 *************************/

/*
 * initialize Tracking
 *
 * parms:
 *    eTrkStorage    storage to use for tracking data
 *    vaParm        data type determined by the value of eTrkStorage:
 *      eTrkStorage      vaParm data type    description
 *      -----------      ----------------    -----------
 *    TRK_STORAGE_MBUF        DWORD        size of tracking buffer
 *                          (in DWORDs) to malloc
 *    TRK_STORAGE_FILE       char *        name of the file to open/write
 *    TRK_STORAGE_STRM        WORD         VCPXI streamid to open/write
 *
 */
void Trk0Initialize(E_TRK_STORAGE eTrkStorage, ...)
{
  va_list ap;
  DWORD dwSize;
  DWORD dwDataLen, dwHdrLen, dwTotalLen;
  PTRKVARS pT = NULL;
  int i;

  va_start(ap, eTrkStorage);    /* initialize the variable arg list    */
  ASSERT(TRK_STORAGE_FILE != eTrkStorage);    /* not yet supported    */
  ASSERT(TRK_STORAGE_STRM != eTrkStorage);    /* not yet supported    */
  dwSize = va_arg(ap, DWORD);

  /* register with the event mgr    */
  hTrkEvent = EventRegisterClass(EVENTCLASS_TRK, TRK_EVENT_ENUMMAX);

  /* register with the error mgr    */
#ifndef NDEBUG
  TrkFillErrNames();
#endif
  hTrkErr = ErrRegisterUser(ERRTYPE_TRK, TRK_ERR_ENUMMAX, TRK_ERR_MAP,
                ERR_AUTOEVENT_VALUE_MATCH);

  /* clear registration map    */
  for (i = 0; i < NUM_REG_DWORDS; i ++) {
    afTrkUserRegister[i] = 0;
  }

  /* check for multiple inits */
  if (NULL != pTrkVars) {
    ErrUserSet(hTrkErr, TRK_ERR_MULTPILE_INIT);
    abort();
  }

  /* allocate the buffer and its header */
  dwHdrLen = sizeof(TRKVARS);
  dwDataLen = 4 * (dwSize + 2);        /* +2 for 2 sentinals    */
  dwTotalLen = dwHdrLen + dwDataLen;
  pT = (PTRKVARS) MALLOC((ubyte4) dwTotalLen);
  if (NULL == pT) {
    ErrUserSet(hTrkErr, TRK_ERR_MEM);
    abort();
  }
  pTrkVars = pT;

  /* fill in the header */
  pT->dwMark = TRK_MARK;
  pT->dwDataLen = dwDataLen;
  pT->pdwTop = (DWORD *) (dwHdrLen + (DWORD) pT);
  pT->fTrkOn = TRK_MAIN + TRK_ALT;
  pT->dwSentinel = TRK_SENTINEL;
  pT->dwAvail = TRK_AVAIL;
  pT->dwWrapped = TRK_WRAPPED;
  pT->dwVoid = TRK_VOID;
  pT->dwEndian = TRK_ENDIAN;
  *pT->pdwTop++ = pT->dwSentinel;
  pT->pdwBot = pT->pdwTop + dwSize;
  /*  printf("bot 0x%08X, top 0x%08X, size 0x%08X\n",
     (DWORD) pT->pdwBot, (DWORD) pT->pdwTop, (DWORD) dwSize);*/
  *pT->pdwBot = pT->dwSentinel;
  pT->pdwWrapTo = pT->pdwTop + 1;
  pT->dwSkip = 0;
  pT->pdwNext = pT->pdwTop;
  while (pT->pdwNext < pT->pdwBot)
    *pT->pdwNext++ = pT->dwAvail;
  pT->pdwNext = pT->pdwTop;
  pT->wMarkBits = TRK_MARK_NBITS;
  pT->wUserBits = TRK_USER_NBITS;
  pT->wTidBits = TRK_TID_NBITS;
  pT->wLenBits = TRK_LEN_NBITS;

  va_end(ap);
}


/*
 * Register a User for Tracking
 *
 * parms:
 *    eTrkUser    user to register
 *
 * returns:
 *    hTk    Tracking User handle
 */
H_TRK_USER Trk0RegisterUser(E_TRK_USER eTrkUser)
{
  int nRegisterIndex;
  DWORD dwRegisterMask;

  /* check that User is in range    */
  if ((DWORD) eTrkUser >= (1 << TRK_USER_NBITS)) {
    hTrkUserError = eTrkUser;
    ErrUserSet(hTrkErr, TRK_ERR_USER);
    abort();
  }

  /* get Registration array position    */
  nRegisterIndex = eTrkUser >> 8;
  dwRegisterMask = ((DWORD) 1 << (eTrkUser & 0xFF));

  /* check that User is not yet registered    */
  if (afTrkUserRegister[nRegisterIndex] & dwRegisterMask) {
    hTrkUserError = eTrkUser;
    ErrUserSet(hTrkErr, TRK_ERR_DUPL_USER);
    abort();
  }

  /* register the user and return the user handle as the tracking handle */
  afTrkUserRegister[nRegisterIndex] |= dwRegisterMask;
  return (H_TRK_USER) eTrkUser;
}

/*
 * implementation note:
 *
 *    The Tag Mark (0xDB), hTk, xTagId and xLen
 * make a DWORD (in current tracking.h) and each one is a byte field
 * (again in current tracking.h), however we could redivide the DWORD
 * tag to give more bits to the xTagId (256 tagids per user seems
 * too small). I think: keep tag mark as 0xDB, make hTk 6
 * bits (for 64 different users) and xTagId 10 bits (for 1024
 * tagids per user), keep xLen as 8 bits... In fact, the length
 * of these fields could be a compile option so it can be
 * tailored.
 *
 *    Another option is to increase the tag size from 1 DWORD to
 * 2 DWORDs.
 */



/*
 * Unregister a User for Tracking
 *
 * parm:
 *    hTk    Tracking User handle
 */
void Trk0UnregisterUser(H_TRK_USER hTk)
{
  E_TRK_USER eTrkUser;
  int nRegisterIndex;
  DWORD dwRegisterMask;

  /* verify user is valid and registered    */
  TrkVerifyHandle(hTk);

  /* get Registration array position    */
  eTrkUser = (E_TRK_USER) hTk;
  nRegisterIndex = eTrkUser >> 8;
  dwRegisterMask = ((DWORD) 1 << (eTrkUser & 0xFF));

  /* unregister the user    */
  afTrkUserRegister[nRegisterIndex] &= ~dwRegisterMask;

}



/*
 * terminate the Tracking
 */
void Trk0Terminate(void)
{
  if (pTrkVars != NULL) {
    FREE(pTrkVars);
  }

  ErrUnregisterUser(hTrkErr);

  EventUnregisterClass(hTrkEvent);
}






/******************************
*
*  Runtime Controls & Queries
*
*******************************/

/*
 * Set Skip amount
 *
 * parms:
 *    dwSkip        # tags to skip
 *
 * related events:
 *    TRK_EVENT_SKIP_DONE
 */
void Trk0SetSkip(DWORD dwSkip)
{
  register PTRKVARS pT = pTrkVars;

  /*
   * (NOTE: the value stored is actually one greater than # to skip)
   */
  pT->dwSkip = dwSkip;
  if (pT->dwSkip != (DWORD) -1)
    pT->dwSkip++;
}

/*
 * query # tags yet to skip
 *
 * returns:
 *    # tags yet to skip
 */
DWORD Trk0QuerySkip(void)
{
  register PTRKVARS pT = pTrkVars;

  /*
   * (NOTE: the value stored is actually one greater than # to skip)
   */
  return (0 == pT->dwSkip) ? 0 : (pT->dwSkip - 1);
}


/*
 * set the wrap target for TRK_STORAGE_MBUF tracking
 *
 * parms:
 *    dwWrapTo    # DWORDs into buffer to wrap to when the circular
 *             buffer wraps
 *
 * related events:
 *    TRK_EVENT_WRAP
 */
void Trk0SetWrapTo(DWORD dwWrapTo)
{
  register PTRKVARS pT = pTrkVars;

  ASSERT((pT->pdwTop + dwWrapTo) < pT->pdwBot);
  if ((pT->pdwTop + dwWrapTo) >= pT->pdwBot) {
    dwWrapTo = 0;
  }
  pT->pdwWrapTo = pT->pdwTop + dwWrapTo;
}


/*
 * query the wrap-to location for circular buffer tracking
 *
 * returns:
 *     # DWORDs into buffer to wrap to when a circular buffer wraps
 */
DWORD Trk0QueryWrapTo(void)
{
  register PTRKVARS pT = pTrkVars;

  return (pT->pdwWrapTo - pT->pdwTop);
}


/*
 * clear the circular tracking buffer and start over at the beginning
 *
 * related events:
 *    TRK_EVENT_RESET
 */
void Trk0Reset(void)
{
  PTRKVARS pT = pTrkVars;

  ASSERT(NULL != pT);
  ASSERT(NULL != pT->pdwTop);
  TRK_SUPPRESS_LONG;
  *(pT->pdwNext) = pT->dwVoid;
  pT->pdwNext = pT->pdwTop;
  TRK_SUPPRESS_LONG;
  *pT->pdwNext = pT->dwAvail;
  *(pT->pdwWrapTo - 1) = pT->dwVoid;

  /* reset all errors */
  ErrResetMask(ERRTYPE_TRK, (1 << TRK_ERR_ENUMMAX) - 1);

  /* post the event    */
  EventPost(hTrkEvent, TRK_EVENT_RESET, NULL, EVENT_MATCH_ANY);

}


/*
 * suspend tracking from track functions
 *
 * parms:
 *    eAltOrMain    which of alt or main to suspend
 *
 * related events:
 *    TRK_EVENT_STARTSTOP
 */
void Trk0Suspend(E_TRK_ALT_OR_MAIN eAltOrMain)
{
  register PTRKVARS pT = pTrkVars;

  pT->fTrkOn &= ~(DWORD) eAltOrMain;
  EventPost(hTrkEvent, TRK_EVENT_STARTSTOP, &(pT->fTrkOn),
        EVENT_MATCH_KEY, (void *) eAltOrMain);
}


/*
 * resume tracking from track functions
 *
 * parms:
 *    eAltOrMain    which of alt or main to resume
 *
 * related events:
 *    TRK_EVENT_STARTSTOP
 */
void Trk0Resume(E_TRK_ALT_OR_MAIN eAltOrMain)
{
  register PTRKVARS pT = pTrkVars;

  pT->fTrkOn |= eAltOrMain;
  EventPost(hTrkEvent, TRK_EVENT_STARTSTOP, &(pT->fTrkOn),
        EVENT_MATCH_KEY, (void *) eAltOrMain);
}



/*
 * query which of alt and/or main are active
 *
 * returns:
 *    fAltOrMain    which of alt or main (or both) are active
 */
E_TRK_ALT_OR_MAIN Trk0QueryActive(void)
{
  register PTRKVARS pT = pTrkVars;

  return pT->fTrkOn;
}







/**************************
*
*  General Tracking Calls
*
***************************/


/*
 * write the given track tag (1 DWORD long) into the tracking buffer
 *
 * called by:
 *    TrkTag() macro
 *    Trk2Tag() macro
 *
 * parms:
 *    fTrk        which track, 1->main 2->alt
 *    hTk        registered User handle
 *    xTagId        tag identifier (to distinguish between different
 *             tags for the same user)
 *    xLen        # DWORDs of data to track (by subsequent, non-tag
 *             tracking calls), -1 -> unspecified length
 *
 * NOTE: we could make a version with a 2 DWORD size tag
 *     0xDBDBuuuu 0xiiiillll to provide 65K users (the "uuuu") with 65K
 *     tag ids (the "iiii") and a max specified len of 65K (the "llll")
 *     rather than the current 1 DWORD tag
 */
void Trk0Tag(DWORD fTrk, DWORD hTk, DWORD xTagId, DWORD xLen)
{
  DWORD dwData;

  DEBUG(TrkVerifyHandle((H_TRK_USER) hTk));
  ASSERT(xTagId <= TRK_TID_MAX);
  ASSERT((xLen <= TRK_LEN_MAX) || ((DWORD) -1 == xLen));

  /* if this track (main or alt) is not enabled then return    */
  if (!(pTrkVars->fTrkOn & fTrk))
    return;

  /* decriment skip count and return if still skipping        */
  TRK_SUPPRESS_LONG;
  if (pTrkVars->dwSkip > 0) {
    pTrkVars->dwSkip--;
    if (0 == pTrkVars->dwSkip)
      EventPost(hTrkEvent, TRK_EVENT_SKIP_DONE, NULL, EVENT_MATCH_ANY);
  }
  if (pTrkVars->dwSkip != 0) {
    return;
  }

  /* build the tag and write it into buffer    */
  dwData = (TRK_MARK << TRK_MARK_SHIFT) |
       (hTk << TRK_USER_SHIFT) |
       (xTagId << TRK_TID_SHIFT) |
       (xLen & TRK_LEN_MAX);
  Trk0(fTrk, dwData);
}


/*
 * write the data into the next DWORD of the tracking buffer
 *
 * called by:
 *    Trk0Tag() function
 *    Trk0MemW() function
 *    Trk() macro
 *    Trk2() macro
 *
 * parms:
 *    fTrk    which track, 1->main 2->alt
 *    data    data to write (no type specified, but cannot be
 *         larger than DWORD)
 */
void Trk0(DWORD fTrk, DWORD dw)
{
  PTRKVARS pT = pTrkVars;

  ASSERT(NULL != pT);
  ASSERT(NULL != pT->pdwTop);

  /* if this track (main or alt) is not enabled then return    */
  if (!(pT->fTrkOn & fTrk))
    return;

  /* return if still skipping        */
  if (pT->dwSkip != 0) {
    return;
  }

  TRK_SUPPRESS_LONG;
  *(pT->pdwNext++) = (DWORD) dw;
  TRK_SUPPRESS_LONG;
  if (pT->pdwNext >= pT->pdwBot) {
    pT->pdwNext = pT->pdwWrapTo;
    TRK_SUPPRESS_LONG;
    *(pT->pdwNext - 1) = pT->dwWrapped;
    EventPost(hTrkEvent, TRK_EVENT_WRAP, NULL, EVENT_MATCH_ANY);
  }
  *pT->pdwNext = pT->dwAvail;

}


/*
 * write the bytes starting at the given addr into the next DWORDs of the
 * tracking buffer
 *
 * called by:
 *    Trk0MemW() function
 *    TrkMem() macro
 *    Trk2Mem() macro
 *
 * parms:
 *    fTrk    which track, 1->main 2->alt
 *    po    pointer to start of data
 *    nLen    # bytes to write (is rounded up to multiple of 4 since
 *         the tracking buffer is filled in multiples of DWORDs)
 */
void Trk0Mem(DWORD fTrk, OCTET *po, int nLen)
{
  PTRKVARS pT = pTrkVars;
  DWORD dw;

  ASSERT(NULL != pT);

  /* if this track (main or alt) is not enabled then return    */
  if (!(pT->fTrkOn & fTrk))
    return;

  /* return if still skipping        */
  if (pT->dwSkip != 0) {
    return;
  }

  while (nLen > 0) {
    dw  = ((DWORD) *((OCTET *) (po) + 0)) << 24;
    dw |= ((DWORD) *((OCTET *) (po) + 1)) << 16;
    dw |= ((DWORD) *((OCTET *) (po) + 2)) <<  8;
    dw |= ((DWORD) *((OCTET *) (po) + 3));
    Trk0(fTrk, dw);
    po += 4;
    nLen -= 4;
  }
}


/*
 * write the bytes starting at the given addr within a circular buffer
 * (so the data may WRAP in the src buffer) into the next DWORDs of the
 * tracking buffer
 *
 * called by:
 *    TrkMemW() macro
 *    Trk2MemW() macro
 *
 * parms:
 *    fTrk    which track, 1->main 2->alt
 *    po    pointer to start of data
 *    nLen    # bytes to write (is rounded up to multiple of 4 since
 *         the tracking buffer is filled in multiples of DWORDs)
 *    pTop    pointer to the top of the data buffer
 *    pBot    pointer to the bottom of the data buffer
 */
void Trk0MemW(DWORD fTrk, OCTET *po, int nLen, OCTET *poT, OCTET *poB)
{
  PTRKVARS pT = pTrkVars;
  int nLenToBot;

  ASSERT(NULL != pT);

  /* if this track (main or alt) is not enabled then return    */
  if (!(pT->fTrkOn & fTrk))
    return;

  /* return if still skipping        */
  if (pT->dwSkip != 0) {
    return;
  }

  nLenToBot = poB - po;
  if (nLen > nLenToBot) {
    Trk0Mem(fTrk, po, nLenToBot);
    nLen -= nLenToBot;
    po = poT;
    Trk0(fTrk, TRK_MEMW_EXT);
  }
  Trk0Mem(fTrk, po, nLen);
}






/*************************
 *
 *  error handling
 *
 *************************/


/*
 * check if tracking handle valid and registered
 *
 * parms:
 *    hTk    tracking handle
 *
 * posts error and aborts if out-of-range or not registered
 */
void TrkVerifyHandle(H_TRK_USER hTk)
{
  int nRegisterIndex;
  DWORD dwRegisterMask;
  E_TRK_USER eTrkUser;

  /* check that User is in range    */
  if ((DWORD) hTk >= (1 << TRK_USER_NBITS)) {
    hTrkUserError = hTk;
    ErrUserSet(hTrkErr, TRK_ERR_USER_HANDLE);
    abort();
  }
  eTrkUser = (E_TRK_USER) hTk;

  /* get Registration array position    */
  nRegisterIndex = eTrkUser >> 8;
  dwRegisterMask = ((DWORD) 1 << (eTrkUser & 0xFF));

  /* check that User is registered    */
  if (!(afTrkUserRegister[nRegisterIndex] & dwRegisterMask)) {
    hTrkUserError = hTk;
    ErrUserSet(hTrkErr, TRK_ERR_USER_HANDLE);
    abort();
  }
}



#if !defined(NDEBUG)
/*
 * build names of errors and states for debug
 */
void TrkFillErrNames(void)
{
  FILL_ERR_NAME_MAP(TRK_ERR_OVERFLOW, aTrkErrMap);
  FILL_ERR_NAME_MAP(TRK_ERR_MULTPILE_INIT, aTrkErrMap);
  FILL_ERR_NAME_MAP(TRK_ERR_MEM, aTrkErrMap);
  FILL_ERR_NAME_MAP(TRK_ERR_DUPL_USER, aTrkErrMap);
  FILL_ERR_NAME_MAP(TRK_ERR_USER_HANDLE, aTrkErrMap);
  FILL_ERR_NAME_MAP(TRK_ERR_USER, aTrkErrMap);
  FILL_ERR_NAME_MAP(TRK_ERR_TAGID, aTrkErrMap);
  FILL_ERR_NAME_MAP(TRK_ERR_LEN, aTrkErrMap);
  FILL_ERR_NAME_MAP(TRK_ERR_EVENT_INVALID, aTrkErrMap);
  FILL_ERR_NAME_MAP(TRK_ERR_EVENT_MEM, aTrkErrMap);
}

#endif
