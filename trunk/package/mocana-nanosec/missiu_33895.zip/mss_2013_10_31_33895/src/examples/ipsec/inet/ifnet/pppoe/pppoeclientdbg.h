/*
 * pppoeclientdbg.h
 *
 * PPPoE common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPPOECLIENTDBG_H_
#define _PPPOECLIENTDBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef PPPOECLIENTDBG_HI
   #define PPPOECLIENTDBG_HI
  #endif
 #endif

#else
 #ifdef PPPOECLIENTDBG_HI
  #undef PPPOECLIENTDBG_HI
 #endif
#endif

#include "netdbg.h"


#define PPPOECLIENT_MAGICCOOKIE 0x506F4543 /* "PoEC" */

/*#ifdef PPPOECLIENTDBG_HI*/
#if defined(PPPOECLIENTDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

#define PPPOECLIENT_CHECKSTATE(x) \
  ASSERT((x != NULL) && (x->dwMagicCookie == PPPOECLIENT_MAGICCOOKIE));

#define PPPOECLIENT_SETCOOKIE(x) (x)->dwMagicCookie = PPPOECLIENT_MAGICCOOKIE

#define PPPOECLIENT_UNSETCOOKIE(x) (x)->dwMagicCookie = 0

#define PPPOECLIENT_DBGP(level,fmt,args...)  do { \
  if (level <= g_dwPppoEClientDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

#define PPPOECLIENT_DBG(level, x) do {  \
    if (level <= g_dwPppoEClientDebugLevel) {  \
      x;      \
    }       \
  } while (0)

#define PPPOECLIENT_DBGVAR(x) x

#else
  #define PPPOECLIENT_CHECKSTATE(x)
  #define PPPOECLIENT_SETCOOKIE(x)
  #define PPPOECLIENT_UNSETCOOKIE(x)
  #define PPPOECLIENT_DBGP(level, fmt, args...)
  #define PPPOECLIENT_DBG(level, x)
  #define PPPOECLIENT_DBGVAR(x)

#endif


PPPOECLIENT_DBGVAR(MOC_EXTERN DWORD g_dwPppoEClientDebugLevel);

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _PPPOECLIENTDBG_H_ */
