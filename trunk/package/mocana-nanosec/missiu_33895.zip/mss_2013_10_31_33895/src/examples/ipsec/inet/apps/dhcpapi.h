/*
 * dhcpapi.h
 *
 * DHCP server API header file
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _DHCPAPI_H_
#define _DHCPAPI_H_

#ifdef JJ
#include "configapi.h"
#include "httpapi.h"
#endif

/**************************************************************************
 * DHCP SERVER DEFINITIONS
 **************************************************************************/
typedef enum {
  DHCP_SUCCESS,
  DHCP_BADCALL_FAIL,
  DHCP_MEM_FAIL,
  DHCP_THR_FAIL,
  DHCP_NTWK_FAIL
} E_RETURN;


/**************************************************************************
 * DHCP SERVER API FUNCTIONS
 **************************************************************************/
/**************************************************************************
 * Create, initialize, and allocate resources for the DHCP server
 *   Does NOT start it.
 *   Must be called before DHCPServerStart
 *     dwDHCPServerIP - IP Address of the DHCP server
 **************************************************************************/
LONG DHCPServerCreate(DWORD dwDHCPServerIP);

/**************************************************************************
 * (Re)Enable the DHCP server - Starts running it
 **************************************************************************/
LONG DHCPServerStart(void);

/**************************************************************************
 * Disable the DHCP server
 *   Does not completely disable the DHCP server
 *   Lease timers will still be decremented, but socket will be closed
 *   and no clients will be responded to
 **************************************************************************/
LONG DHCPServerStop(void);

/**************************************************************************
 * Terminate the DHCP server and free all allocated resources
 **************************************************************************/
LONG DHCPServerTerminate(void);

/**************************************************************************
 * Clear the DHCP Server's binding table
 *   ALL bindings will be deleted
 **************************************************************************/
LONG DHCPServerClearBindingTable(void);

/**************************************************************************
 * Initializes the DHCP server client binding table for binding extraction
 * IMPORTANT: This function will lock the server until function
 *            DHCPServerEndBindingTableQuery() is called. This is to ensure
 *            that the client binding table does not change during
 *            client binding extraction (by successively calling function
 *            DHCPServerGetNextBinding())
 **************************************************************************/
LONG DHCPServerInitBindingTableQuery(void);

/**************************************************************************
 * Notify that no more client binding information is required.
 * Unlock the server to allow binding table updates.
 **************************************************************************/
LONG DHCPServerEndBindingTableQuery(void);

/**************************************************************************
 * Returns next client binding information to the calling application
 **************************************************************************/
LONG DHCPServerGetNextBinding(DWORD *pdwIPAddress,
                              char** pcName,
                              OCTET** poClientID,
                              OCTET *poClientIDLength);

/**************************************************************************
 * Update the static assignments in the client binding table
 **************************************************************************/
LONG DHCPServerUpdateStaticAssignments(void);

/**************************************************************************
 * DHCPServerWebSubstCallBack
 *   To substitute non-config file variables into html files
 **************************************************************************/
#ifdef JJ
int DHCPServerWebSubstCallBack(SubstParam* sp);

/**************************************************************************
 * DHCPServerWebPostCallBack
 *   To intercept and act on certain DHCP web config settings
 **************************************************************************/
int DHCPServerWebPostCallBack(PostParam* pp);
#endif


#endif  /*_DHCPAPI_H_ */

/**************************************************************************/
/*********************** END OF FILE **************************************/
/**************************************************************************/
