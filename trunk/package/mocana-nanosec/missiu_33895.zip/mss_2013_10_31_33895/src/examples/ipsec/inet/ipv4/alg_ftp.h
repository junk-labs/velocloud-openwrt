/*
 * alg_ftp.h
 *
 * Header file for FTP ALG
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __ALG_FTP_H__
#define    __ALG_FTP_H__

#include <NNstyle.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "nat.h"
#include "nat_defs.h"
#include "nat_dbg.h"

LONG AlgFtp(NATSTATE* pxNat,
            NETPACKET *pxNetPacket,
        NETPACKETACCESS *pxNetPacketAccess,
        H_NETDATA hData,
            void *pvProtocolHdr,
            NAT_ENTRY* pxNatEntry,
            WORD wLanPort,
            E_NAT_DIRECTION eDirection);

#endif    /* __ALG_FTP_H__ */
