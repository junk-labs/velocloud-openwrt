/*
 * router_rcv.c
 *
 * router Rx function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/
#include "router.h"
#include "router_defs.h"
#include "iptable.h"
#include "../include/ioctl.h"
#include "../include/sockio.h"

/*****************************************************************************
 *
 * Debug
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Local Function
 *
 *****************************************************************************/



/*****************************************************************************
 *
 * API function
 *
 *****************************************************************************/
/*
 * RouterInstanceRcv
 *  Router Instance Rcv function
 *   Router Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hRouter            Instance Handle
 *    hIf            Interface handle
 *    pxNetPacket        packet
 *    pxNetPacketAccess        Packet info
 *    hData            cast to NETWORKID
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG RouterInstanceRcv(H_NETINSTANCE    hRouter,
                       H_NETINTERFACE   hIf,
                       NETPACKET        *pxNetPacket,
                       NETPACKETACCESS  *pxNetPacketAccess,
                       H_NETDATA        hData)
{
  ROUTERSTATE     *pxRouter = (ROUTERSTATE *)hRouter;
  NETWORKID       *pxNetworkId = (NETWORKID*) hData;
  E_ADDRTYPE      eDstAddrType;
  ROUTER_CHECK_STATE(pxRouter);
  NETPACKET_CHECK(pxNetPacket);
  ASSERT((pxNetPacketAccess != NULL) &&
         (pxNetworkId != NULL) &&
         (pxRouter->pfnRxCbk != NULL) &&
         ((int)hIf == 1));

  eDstAddrType = pxNetworkId->eDstAddrType;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ROUTER_DBGP(DBGLVL_REPETITIVE,"RouterInstanceRcv():oIfIdx=%d,%ld.%ld.%ld.%ld ==> %ld.%ld.%ld.%ld: prot=%s, length=%d, type=%s\n",
              pxNetworkId->oIfIdx,
              IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
              IPADDRDISPLAY(pxNetworkId->dwDstAddr),
              IpProtoToString(pxNetworkId->oProtocol),
              pxNetworkId->wTotalLen,
              IpAddressTypeToString(eDstAddrType));*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceRcv(): oIfIdx = ", pxNetworkId->oIfIdx);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", ", pxNetworkId->dwSrcAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " ==> ", pxNetworkId->dwDstAddr);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, ": prot = ", IpProtoToString(pxNetworkId->oProtocol));
    DEBUG_PRINTSTR1INT1 (DEBUG_MOC_IPV4, ", length = ", pxNetworkId->wTotalLen);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, ", type = ", IpAddressTypeToString(eDstAddrType));
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(eDstAddrType){

    case IPADDRT_MULTICASTJOINEDPROXY:
    case IPADDRT_MULTICASTJOINEDSOCKPROXY:
      {
        if(pxNetworkId->oProtocol == IPID_UDP){
          NETPACKET       xNetPacket;
          NETPACKETACCESS xNetPacketAccess;

          NetPacketDuplicate(&xNetPacket,pxNetPacket,pxRouter->pxMutex);

          MOC_MEMCPY((ubyte *)&xNetPacketAccess,
                        (ubyte *)pxNetPacketAccess,
                        sizeof(NETPACKETACCESS));
          ASSERT(xNetPacketAccess.wLength >= pxNetworkId->oIpHdrLen);
          xNetPacketAccess.wOffset += (WORD) pxNetworkId->oIpHdrLen;
          xNetPacketAccess.wLength -= (WORD) pxNetworkId->oIpHdrLen;

          RouterInstanceWrite(hRouter,
                              hIf,
                              &xNetPacket,
                              &xNetPacketAccess,
                              (H_NETDATA)pxNetworkId);
        }
      }

    /* fall thru */
    case IPADDRT_LOOPBACK:
    case IPADDRT_MYADDR:
    case IPADDRT_BROADCAST:
    case IPADDRT_MULTICAST:
    case IPADDRT_MULTICASTJOINED:
      return pxRouter->pfnRxCbk(pxRouter->hULInst,
                                pxRouter->hULIf,
                                pxNetPacket,
                                pxNetPacketAccess,
                                hData);
      break;


    case IPADDRT_OUTSIDE:
    SNMP(xTcpipData.ipForwDatagrams++);
    case IPADDRT_MYSUBNET:
    case IPADDRT_PPPPEER:
#ifdef IP_FILTERING
      /*********************************************************
       * Check for IP address Filtering
       ********************************************************/
      if (pxRouter->oIfIdxLan == pxNetworkId->oIfIdx) {

        /*************************************************************
         * IP Address filtering.
         * IP Address filtering blocks out certain machines on the
         * LAN from accessing the WAN. Check the source address
         * of the packet for a match in the list of filtered
         * addresses. Drop the packet if there is a match.
         * Note that packets from the filtered address intended
         * for the CPE will still make it up the CPE stack.
         ************************************************************/
        if (RouterIsIpAddrFiltered(pxRouter, pxNetworkId->dwSrcAddr, pxNetworkId->oProtocol)) {
          NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
          return (LONG)-1;
          /* TODO: Should we send any kind of ICMP packet here? */
        }
      }
#endif


      if ((TRUE == pxRouter->abRoutingDisabled[pxNetworkId->oIfIdx]) &&
          (pxRouter->oIfIdxLan != pxNetworkId->oIfIdx)) {
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
        {
          /*ROUTER_DBGP(DBGLVL_REPETITIVE,
             "RouterInstanceRcv(): Routing disabled on interface %d, hence dropping packet\n",
             pxNetworkId->oIfIdx);*/
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceRcv(): Routing disabled on interface ", pxNetworkId->oIfIdx);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, ",  hence dropping packet.");
        }
        NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
        SNMP( xTcpipData.ipOutNoroutes++ );
        return (LONG)-1;
      }
      ASSERT(pxNetPacketAccess->wLength >= pxNetworkId->oIpHdrLen);
      pxNetPacketAccess->wOffset += (WORD) pxNetworkId->oIpHdrLen;
      pxNetPacketAccess->wLength -= (WORD) pxNetworkId->oIpHdrLen;


#ifdef IPSEC
      /*
       * Add security policy info for packets going out from LAN to WAN
       */
      if ((pxNetworkId->oIfIdx == pxRouter->oIfIdxLan) &&
          ((pxNetworkId->dwSecurityPolicy = (DWORD)
                           IPSecGetSP(pxNetworkId->dwDstAddr, 0,
                                      pxNetworkId->dwSrcAddr, 0,
                                      IPPROTO_ICMP, 1)))) {
        pxNetworkId->wIpSecHdrLength =
                       IPSecGetHdrLen((void*)pxNetworkId->dwSecurityPolicy);
        pxNetworkId->wIpSecTrailLength =
                       IPSecGetTrailLen((void*)pxNetworkId->dwSecurityPolicy,
                                        pxNetPacketAccess->wLength);

        /* Need to remove padding before applying IPSec */
        pxNetPacketAccess->wLength = pxNetworkId->wTotalLen -
                                   (WORD) pxNetworkId->oIpHdrLen;

      }
#endif

      RouterInstanceWrite(hRouter,
                          hIf,
                          pxNetPacket,
                          pxNetPacketAccess,
                          hData);
      return (LONG) pxNetPacketAccess->wLength;
      break;


    case IPADDRT_UNKNOWN:
    case IPADDRT_INVBCAST:
    case IPADDRT_ANY:
      NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
      SNMP( xTcpipData.ipOutNoroutes++ );
      return (LONG)-1;
      break;

    default:
      ASSERT(0);
  }

  NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
  return (LONG)-1;
}
