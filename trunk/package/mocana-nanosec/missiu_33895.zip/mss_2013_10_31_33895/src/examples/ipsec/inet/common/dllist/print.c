#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void DLLIST_print(DLLIST *dllist, OCTET *prefixstr, void (*print_item)())
{
  DWORD count=0;

  printf("%sdbl_link_list(0x%08lx) : \n",prefixstr,(DWORD) dllist);
  dllist->cur = dllist->head;
  while(dllist->cur != NULL) {
    OCTET extrastr[256];
    sprintf((char *) extrastr,"%s	<%2ld> ",(char *) prefixstr,count++);
    if (print_item == NULL) {
      printf("%s0x%08lx\n",extrastr,(DWORD) dllist->cur->item);
    } else {
      print_item(extrastr,dllist->cur->item);
    }
    dllist->cur = dllist->cur->next;
  }
  if (count != dllist->count) {
    OCTET pstr[256];
    sprintf((char *)pstr,"count(0x%lx) != dllist->count(0x%lx)",count,dllist->count);
#if 0
    fprintf(stderr,(char *) pstr);
#endif /* TBD */
  }
}

