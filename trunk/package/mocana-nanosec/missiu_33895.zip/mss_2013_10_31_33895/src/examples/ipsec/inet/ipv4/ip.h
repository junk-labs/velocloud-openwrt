/*
 * ip.h
 *
 * IP module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IP_H_
#define _IP_H_


/*
 * IP wide default
 */
#define IPDEFAULT_HDRSIZE         20

/*
 * IP UL ioctls
 *  are covered by the defines in netcommon.h
 *   o NETWORKINTERFACEIOCTL_SETID: The id must be the octet identifying
 *     the UL protocol, as defined in "Assigned Number RFC". defines are given
 *     below as IP_ID_XXX (XXX <={TCP,UDP,ICMP,IGMP})
 */

/*
 * IP UL protocol Ids supported
 *  given to IpInstanceWrite, and used by IP to
 *  identify the higher level interface tp send Rx data to
 */
#define IPID_ICMP     IPPROTO_ICMP  /* Internet Control Message Protocol    */
#define IPID_IGMP     IPPROTO_IGMP  /* Internet Group Management Protocol   */
#define IPID_TCP      IPPROTO_TCP   /* Transmission Control Protocol        */
#define IPID_EGP      IPPROTO_EGP   /* Exterior Gateway Protocol            */
#define IPID_PUP      IPPROTO_PUP   /* PUP protocol                         */
#define IPID_UDP      IPPROTO_UDP   /* User Datagram Protocol               */
#define IPID_IDP      IPPROTO_IDP   /* XNS IDP protocol                     */
#define IPID_ESP      IPPROTO_ESP   /* IPSec Encapsulating Security Protocol*/
#define IPID_AH       IPPROTO_AH    /* IPSec Authentication header          */
#define IPID_RAW      IPPROTO_RAW   /* Raw IP packets                       */


/*
 * IP UL Ioctls
 *  All are covered in netcommon.h (LIBNETCOMMON)
 */

/*
 * IP LL Ioctls
 *  o All are covered in netcommon.h
 *  o The PFN_NETWRITE function provided for NETWORKINTERFACEIOCTL_SETWRITE
 *    will be given the remote IP address (a DWORD) as hDst argument
 */
#ifdef NEW_ICMP_MSG_ADDED
#define IPMSG_BEGIN \
          (NETNETWORKMSG_MODULESPECIFICBEGIN)
#define IPMSG_PROTOCOLUNREACHABLE \
          (IPMSG_BEGIN) + 8             /* Indication of protocol unsupported, need to check if this ever works */
#endif

/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/

typedef struct {
#if defined (MOC_LITTLE_ENDIAN)
  OCTET  oIpHdrLen:4,
          oVersion:4;
#elif defined (MOC_BIG_ENDIAN)
  OCTET   oVersion:4,
         oIpHdrLen:4;
#endif

  OCTET  oToS;
  WORD   wTotalLen;
  WORD   wDatagramId;
  WORD   wFragOffset;
  OCTET  oTtL;
  OCTET  oProtocol;
  WORD   wCheck;
  DWORD  dwSrcAddr;
  DWORD  dwDstAddr;

  /*The options start here. */
} IPHDR;

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * IpInitialize
 *  Initialize the IP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpInitialize(void);

/*
 * IpTerminate
 *  Terminate the IP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpTerminate(void);

/*
 * IpInstanceCreate
 *  Creates a IP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IpInstanceCreate(void);

/*
 * IpInstanceDestroy
 *  Destroy a IP Instance
 *
 *  Args:
 *   hIp                       IP instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpInstanceDestroy(H_NETINSTANCE hIp);

/*
 * IpInstanceSet
 *  Set a IP Instance Option
 *
 *  Args:
 *   hIp                       IP instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpInstanceSet(H_NETINSTANCE hIp,OCTET oOption,
                   H_NETDATA hData);

/*
 * IpInstanceQuery
 *  Query a IP Instance Option
 *
 *  Args:
 *   hIp                       IP instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpInstanceQuery(H_NETINSTANCE hIp,OCTET oOption,
                      H_NETDATA *phData);

/*
 * IpInstanceMsg
 *  Send a msg to a IP instance
 *
 *  Args:
 *   hIp                       IP instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpInstanceMsg(H_NETINSTANCE hIp,OCTET oMsg,
                    H_NETDATA hData);


/*
 * IpInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer : UDP,TCP,ICMP,IGMP, etc
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hIp                       IP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IpInstanceULInterfaceCreate(H_NETINSTANCE hIp);

/*
 * IpInstanceULInterfaceDestroy
 *  Destroy a IP UL interface
 *
 *  Args:
 *   hIp                       IP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG IpInstanceULInterfaceDestroy(H_NETINSTANCE hIp,
                                   H_NETINTERFACE hInterface);

/*
 * IpInstanceULInterfaceIoctl
 *  Ip UL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h and ip.h
 *  for precisions
 *
 *  Args:
 *   hIp                         IP instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IpInstanceULInterfaceIoctl(H_NETINSTANCE hIp,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData);

/*
 * IpInstanceWrite
 *  Ip Instance Write function. Follows PFN_NETWORKWRITE
 *  typedef.
 *
 *  Args:
 *   hIp                        Ip Instance handle
 *   hIf                        Interface handle
 *   pxPacket                   Packet pointer
 *   wOffset                    Ip PDU offset
 *   hData                      pointer to a net_dst structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG IpInstanceWrite(H_NETINSTANCE hIp,
                     H_NETINTERFACE hIf,
                     NETPACKET *pxPacket,
                     NETPACKETACCESS *pxPktAccess,
                     H_NETDATA hData);
/* Condenses IPWrite RouteWrite/IPFragWrite and IP1toNWrite */
LONG IpInstanceWriteFast(H_NETINSTANCE hIp,
                     H_NETINTERFACE hIf,
                     NETPACKET *pxPacket,
                     NETPACKETACCESS *pxPktAccess,
                     H_NETDATA hData);

/*
 * IpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIp                       IP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IpInstanceLLInterfaceCreate(H_NETINSTANCE hIp);

/*
 * IpInstanceLLInterfaceDestroy
 *  Destroy a IP LL interface
 *
 *  Args:
 *   hIp                       IP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG IpInstanceLLInterfaceDestroy(H_NETINSTANCE hIp,
                                   H_NETINTERFACE hInterface);

/*
 * IpInstanceLLInterfaceIoctl
 *  IP LL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h
 *  for precisions
 *
 *  Args:
 *   hIp                         Ip instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IpInstanceLLInterfaceIoctl(H_NETINSTANCE hIp,
                                H_NETINTERFACE hLLInterface,
                                OCTET oIoctl,
                                H_NETDATA hData);


/*
 * IpInstanceRcv
 *  Ip Instance Rcv function
 *   Ip Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIp                        Ud Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    wOffset                    Ip PDU offset.
 *    hData                      unused
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG IpInstanceRcv(H_NETINSTANCE hIp,
                   H_NETINTERFACE hIf,
                   NETPACKET *pxPacket,
                   NETPACKETACCESS *pxPktAccess,
                   H_NETDATA hData);

#ifdef NETDBG_HI
/*
 * IpInstanceProcess
 *  Used for IpTable stat printing. No real processing
 *
 *  Args:
 *   hIp                        Ip Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG IpInstanceProcess(H_NETINSTANCE hIp);
#endif

#endif /* #ifndef _IP_H_ */







