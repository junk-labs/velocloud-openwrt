/*
 * netmain.h
 *
 * netmain internal API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _NETMAIN_H_
#define _NETMAIN_H_

/****************************************************************************
 *
 * includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "dllist.h"
#include "netmain_flavor.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "etherdrv.h"

/****************************************************************************
 *
 * debug
 *
 ****************************************************************************/
#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef NETMAINDBG_HI
   #define NETMAINDBG_HI
  #endif
 #endif

#else
 #ifdef NETMAINDBG_HI
  #undef NETMAINDBG_HI
 #endif
 #ifdef NETDBG_HI
   #undef NETDBG_HI
 #endif
#endif

#include "netdbg.h"

/*#ifdef NETMAINDBG_HI*/
#if defined(NETMAINDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

#define NETMAIN_DBGP(level,fmt,args...)  do { \
  if (level <= g_dwNetmainDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

#define NETMAIN_DBG(level, x) do {  \
    if (level <= g_dwNetmainDebugLevel) {  \
      x;      \
    }       \
  } while (0)

#define NETMAIN_DBG_VAR(x) x

#define NETMAIN_CHECKPOINT(x) (x = __LINE__)

#define NETMAIN_ASSERT(x) ASSERT(x)
#else
#if defined (__VXWORKS_RTOS__)
#define NETMAIN_DBGP(level, fmt, args)
#else
#define NETMAIN_DBGP(level, fmt, args...)
#endif
#define NETMAIN_DBG(level, x)
#define NETMAIN_DBG_VAR(x)
#define NETMAIN_CHECKPOINT(x)
#define NETMAIN_ASSERT(x)
#endif

#ifdef __TCP_SEND_SEGMENT__
/* MEM Pool Types for SEND Buffer */

#define MAX_TXBUFFER_50_POOL    1000
#define MAX_TXBUFFER_250_POOL   1000
#define MAX_TXBUFFER_600_POOL   1000
#define MAX_TXBUFFER_1100_POOL  1000
#define MAX_TXBUFFER_1600_POOL  1000

#define MAX_TXBUFFER_POOL       5 /* Has to match whats defined in netsegment.h*/

#define MAX_TXSEND_BUFFER  MAX_TXBUFFER_50_POOL +   \
                           MAX_TXBUFFER_250_POOL +  \
                           MAX_TXBUFFER_600_POOL +  \
                           MAX_TXBUFFER_1100_POOL + \
                           MAX_TXBUFFER_1600_POOL

#define MAX_TXBUFFER_OFFSET    128
#define MAX_TXBUFFER_TRAILER   32
#define MAX_TXBUFFER_50_POOL_SIZE     50 + MAX_TXBUFFER_OFFSET + MAX_TXBUFFER_TRAILER
#define MAX_TXBUFFER_250_POOL_SIZE    250 + MAX_TXBUFFER_OFFSET + MAX_TXBUFFER_TRAILER
#define MAX_TXBUFFER_600_POOL_SIZE    600 + MAX_TXBUFFER_OFFSET + MAX_TXBUFFER_TRAILER
#define MAX_TXBUFFER_1100_POOL_SIZE   1100 + MAX_TXBUFFER_OFFSET + MAX_TXBUFFER_TRAILER
#define MAX_TXBUFFER_1600_POOL_SIZE   1600 + MAX_TXBUFFER_OFFSET + MAX_TXBUFFER_TRAILER

typedef struct xNetSendBufferPool
{
  poolHeaderDescr   poolId;
  DWORD             offset;
  DWORD             lengthOfSegment;
  DWORD             segmentsFree;
}xNetSendBufferPool;

#endif /*__TCP_SEND_SEGMENT__ */

/* #ifdef __INET_USE_MEMPOOL__ */

#define MAX_NETPAYLOAD_POOL       20000
#define MAX_NETPACKET_POOL        20000
#define MAX_NET_DRV_BUFFER_POOL   20000

/* #endif */ /* __INET_USE_MEMPOOL__ */


NETMAIN_DBG_VAR(MOC_EXTERN DWORD g_dwNetmainDebugLevel);
#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3
#define XREPETITIVE 4

/****************************************************************************
 *
 * defines
 *
 ****************************************************************************/

/*
 * Main trunk libraries indexes
 */
enum _maintrunklib_idx_t{
    MAINTRUNKLIBIDX_UDP,
    MAINTRUNKLIBIDX_TCP,
    MAINTRUNKLIBIDX_ICMP,
    MAINTRUNKLIBIDX_IGMP,
    MAINTRUNKLIBIDX_IP,
    MAINTRUNKLIBIDX_ETH,
    MAINTRUNKLIBIDX_ARP,
    MAINTRUNKLIBIDX_IP2ETH,
    MAINTRUNKLIBIDX_IP1TON,
#ifdef ROUTER
    MAINTRUNKLIBIDX_ROUTER,
#endif
#ifdef NAT
    MAINTRUNKLIBIDX_NAT,
#endif
#ifdef IPSEC
    MAINTRUNKLIBIDX_IPSEC,
#endif
#ifdef IPFRAG /* always required with ROUTER */
    MAINTRUNKLIBIDX_IPFRAG,
#endif
    MAINTRUNKLIBIDX_MAX,
};

/* IP UL interfaces indexes */
  #define IPULIFIDX_UDP                       0
  #define IPULIFIDX_TCP                       1
  #define IPULIFIDX_ICMP                      2
  #define IPULIFIDX_IGMP                      3

/* eth common UL interface */
  #define ETHULIFIDX_ARP                      0
  #define ETHULIFIDX_RARP                     1
  #define ETHULIFIDX_IP2ETH                   2
  #define ETHULIFIDX_MAX                      3

/*
 * Driver offset
 */
#ifdef NET_ETHONLY
#define NETRXOFFSET                         (ETHHEADER_LEN + ETHVLAN_LEN + 2)
#define NETRXTRAILER                        0 /* only for DSL build really */
#else
/* The following IPSec header and trail length are derived when using 256 bit */
/* message digest and 64 bit block cipher */
/* If 512 bit message digest, such as SHA-512, is used, these number should be */
/* changed to 116(for header) and 72(for trailer), respectively. */
#define NETIPSECHDR                         84 /* max IPSec header length */
#define NETIPSECTRAIL                       40 /* max IPSec trail length */
/* Memory space should be reserved for IPSec header and trailer addition */
/* for a incoming packet from LAN to be sent out through IPSec tunnel */
/*TODO: optimize this value*/
#define NETRXOFFSET                         (40 + (NETIPSECHDR))
#define NETRXTRAILER                        (47+8+8 + (NETIPSECTRAIL))
#endif

#define NETGETCONFINST_UDP     &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_UDP]
#define NETGETCONFINST_TCP     &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_TCP]
#define NETGETCONFINST_IP      &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IP]
#define NETGETCONFINST_ICMP    &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_ICMP]
#define NETGETCONFINST_IGMP    &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IGMP]
#define NETGETCONFINST_IP1TON  &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IP1TON]
#define NETGETCONFINST_ROUTER  &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_ROUTER]
#define NETGETCONFINST_NAT     &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_NAT]
#define NETGETCONFINST_IPFRAG  &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IPFRAG]
#define NETGETCONFINST_IPSEC   &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IPSEC]
#define NETGETCONFINST_ETH     &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_ETH]
#define NETGETCONFINST_ARP     &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_ARP]
#define NETGETCONFINST_IP2ETH  &xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IP2ETH]

#define NETGETINST_UDP     xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_UDP].hInst
#define NETGETINST_TCP     xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_TCP].hInst
#define NETGETINST_IP      xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IP].hInst
#define NETGETINST_ICMP    xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_ICMP].hInst
#define NETGETINST_IGMP    xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IGMP].hInst
#define NETGETINST_IP1TON  xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IP1TON].hInst
#define NETGETINST_ROUTER  xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_ROUTER].hInst
#define NETGETINST_NAT     xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_NAT].hInst
#define NETGETINST_IPFRAG  xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IPFRAG].hInst
#define NETGETINST_IPSEC   xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IPSEC].hInst
#define NETGETINST_ETH     xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_ETH].hInst
#define NETGETINST_ARP     xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_ARP].hInst
#define NETGETINST_IP2ETH  xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IP2ETH].hInst

#define NETGETIF_IP2ETHLL  xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IP2ETH].phLLIf[0]
#define NETGETIF_IP2ETHUL  xNetWrapper.xNetConf.pxNetConfInstance[MAINTRUNKLIBIDX_IP2ETH].phULIf[0]

#define NETGETWRAPPER &xNetWrapper
#define NETGETIFCONF(pxWrapper,oIfIdx) &((pxWrapper)->pxIfConf[(oIfIdx)])
#define NETGETIFSTATE(pxIfConf)        (NETIFSTATE *)(pxIfConf)->pxNetIfState
#define NETGETWRAPPERSTATE(pxNetWrapper)  (NETWRAPPERSTATE *)(pxNetWrapper)->hState
#define NETSETWRAPPERSTATE(pxNetWrapper,pxWrapperState) (pxNetWrapper)->hState = (H_NETINSTANCE)pxWrapperState
#define NETSETIFSTATE(pxIfConf,pxIfState) \
                      (pxIfConf)->pxNetIfState = (pxIfState)
#define NETGETLIMITER(pxNetWrapper)  &(pxNetWrapper)->xNetIfLimiter


/****************************************************************************
 *
 * Typedefs
 *
 ****************************************************************************/

/*
 * NETWRAPPERSTATE
 *  what's hidden behing the NETWRAPPER hState member
 */
typedef struct {
  int iSocket; /* Socket used for configuration */

  /* members identifying the bottom net library */
  H_NETINSTANCE hNetBottomInst;

  /* Driver link lists ... that may change */
  DLLIST dllTxBuf;
  DLLIST dllRxBuf;
  NET_DRV_BUFFER xndbTxPacket;
  DLLIST dllNetPacketRx;
  /* Atm*/
#ifdef NET_DSL
  DRIVERBUFFER xDriverBufferTx;
  OCTET oAtmUp;
#endif
#if 0
  pthread_t xThread;
#else
  sbyte4 xThread;
#endif
  OCTET obDone;
#ifdef __TCP_SEND_SEGMENT__
  poolHeaderDescr    txSegmentPoolId;
  xNetSendBufferPool xSendBufferPools[MAX_TXBUFFER_POOL];
#endif
#ifdef __INET_USE_MEMPOOL__
  poolHeaderDescr    netPayloadPool;
  ubyte4             netPayloadPoolUsed;
#endif /* __INET_USE_MEMPOOL__ */
#ifdef __INET_USE_PKT_MEMPOOL__
  poolHeaderDescr    netPacketPool;
  ubyte4             netPacketPoolUsed;
#endif /* __INET_USE_PKT_MEMPOOL__ */
#ifdef __INET_USE_NET_BUF_MEMPOOL__
  poolHeaderDescr    netDrvBufPool;
  ubyte4             netDrvBufPoolUsed;
#endif /* __INET_USE_NET_BUF_MEMPOOL__ */

} NETWRAPPERSTATE;

/* For the NetDriver To Send packet To Us */
MOC_EXTERN poolHeaderDescr    netPayloadPool;
MOC_EXTERN ubyte4             netPayloadPoolUsed;

#ifdef __INET_USE_PAYLOAD_MEMPOOL__
  MOC_EXTERN poolHeaderDescr    netPoPayloadPool_1536;
  MOC_EXTERN ubyte4             netPoPayloadPoolUsed_1536;
  MOC_EXTERN RTOS_MUTEX         poPayloadMutex_1536;
  MOC_EXTERN poolHeaderDescr    netPoPayloadPool_512;
  MOC_EXTERN ubyte4             netPoPayloadPoolUsed_512;
  MOC_EXTERN RTOS_MUTEX         poPayloadMutex_512;
#endif /* __INET_USE_PAYLOAD_MEMPOOL__ */

/****************************************************************************
 *
 * externs
 *
 ****************************************************************************/
MOC_EXTERN const NETCONFLIBRARYTEMPLATE *apxMainTrunkLibTemplate[MAINTRUNKLIBIDX_MAX];
MOC_EXTERN const NETCONFSETTING axNetSettings[NETOPTION_MODULESPECIFICBEGIN];

MOC_EXTERN const NETCONFINSTANCETEMPLATE axIp2EthInstTemplate[1];

MOC_EXTERN unsigned long gEthPhyFramesEnqueued;
MOC_EXTERN unsigned long gMotEthPhyFramesEnqueued;


/****************************************************************************
 *
 * API function
 *
 ****************************************************************************/
LONG NetAdminArpCbk(H_NETINSTANCE hInst, OCTET oCbk, H_NETDATA hData);
LONG NetAdminIcmpCbk(H_NETINSTANCE hInst, OCTET oCbk, H_NETDATA hData);
LONG NetAdminIpFragCbk(H_NETINSTANCE hInst, OCTET oCbk, H_NETDATA hData);
LONG NetAdminUdpCbk(H_NETINSTANCE hInst, OCTET oCbk, H_NETDATA hData);
LONG NetAdminRouterCbk(H_NETINSTANCE hInst, OCTET oCbk, H_NETDATA hData);
LONG NetAdminCommonCbk(H_NETINSTANCE hInst,OCTET oCbk,H_NETDATA hData);
#ifdef NEW_ICMP_MSG_ADDED
LONG NetAdminIpCbk(H_NETINSTANCE hInst,OCTET oCbk,H_NETDATA hData);
LONG NetAdminTcpCbk(H_NETINSTANCE hInst,OCTET oCbk,H_NETDATA hData);
#endif

/*
 * MainTrunkSetNetOffset
 *  Set the offset information for the interface
 *  in main trunk modules
 *
 *  Args:
 *   oIfIdx                interface index
 *   wOffset               Net layer offset
 *
 *  Return:
 *   0
 */
LONG MainTrunkSetNetOffset(WORD wOffset);

/*
 * MainTrunkSetNetTrailer
 *  Set the offset information for the interface
 *  in main trunk modules
 *
 *  Args:
 *   oIfIdx                interface index
 *   wOffset               Net layer offset
 *
 *  Return:
 *   0
 */
LONG MainTrunkSetNetTrailer(WORD wTrailer);

/*
 * NetMutexUnlockLock
 *   It unlock and lock the mutex if there is any
 *   thread waiting on pthread_mutex_lock
 *
 *  Args: pxMutex
 *
 */
void NetMutexUnlockLock(RTOS_MUTEX pxMutex);

#endif /* #ifndef _NETMAIN_H_ */
