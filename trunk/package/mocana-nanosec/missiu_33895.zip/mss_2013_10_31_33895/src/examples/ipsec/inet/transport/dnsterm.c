/*
 * dnsterm.c
 *
 * Termination  of DNS client.
 *  In seperate file as may not be called in release build
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "NNstyle.h"
#include "dns_flavor.h"
#include <sys/ioctl.h>
#include "sys/socket_inet.h"
#include <sys/socket.h> /* sockaddr */
#include "netinet/in.h" /* sockaddr_in */
#include "nettime.h"
#include <sys/select.h> /* FD_xxx */
#include <sys/sockio.h>
#include <net/if.h>
#include <arpa/inet.h>
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdb.h"
#include "sockapi.h"
#include "dnsdbg.h"
#include "dnsapi.h"
#include "dns.h"

extern pthread_mutex_t xDnsMutex;

/*
 * DnsTerm
 *  Frees all dynamically allocated buffers.
 *
 *  Args:
 *   None
 *
 *  Return:
 *   None
 */
void DnsTerm(void)
{
  int                 i;
  HOSTENT_LIST        *pxHel, *pxHel2;
  STRUCTDNSCONTROL  *pxDnsControlLocal;

  RTOS_mutexWait((RTOS_MUTEX)&xDnsMutex);

  pxDnsControlLocal = xDNSState.pxDnsControl;

  for (i=0; i<xDNSState.oDnsNum; i++) {
    pxHel = pxDnsControlLocal->pxHostEntList;
    while (pxHel) {
      pxHel2 = pxHel->pxNext;
      DnsFreeHostEntMembers(&(pxHel->xHostEnt));
      FREE(pxHel);
      pxHel = pxHel2;
    }
    pxDnsControlLocal->pxHostEntList = NULL;
    FREE(pxDnsControlLocal->szDomainName);
    pxDnsControlLocal->szDomainName = NULL;
    pxDnsControlLocal++;
  }

  FREE(xDNSState.pxDnsControl);
  MOC_MEMSET((ubyte *)&xDNSState,0x00,sizeof(xDNSState));
  RTOS_mutexRelease((RTOS_MUTEX)&xDnsMutex);

}

