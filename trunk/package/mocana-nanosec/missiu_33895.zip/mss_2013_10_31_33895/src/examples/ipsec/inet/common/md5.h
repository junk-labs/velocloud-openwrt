/*
 * md5.h
 *
 * md5 algorithm API. derived from the RSA Data Security, Inc. Message-Digest Algorithm
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _MD5_H_
#define _MD5_H_



/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

#define MD5_HASH_SIZE 16

/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/

/*
 * MD5 context.
 */
typedef struct {
  DWORD adwState[4];                                   /* state (ABCD) */
  DWORD adwCount[2];        /* number of bits, modulo 2^64 (lsb first) */
  OCTET aoBuffer[64];                         /* input buffer */
} MD5_CTX;

/*****************************************************************************
 *
 * Function prototypes
 *
 *****************************************************************************/

/*
 * MD5Init
 *  MD5 initialization. Begins an MD5 operation, creating a new context
 *
 *  Args:
 *
 *  Return:
 *    H_CRYPT          Context handle
 */
H_CRYPT MD5Init (void);


/*
 * MD5Update
 *  MD5 block update operation. Continues an MD5 message-digest
 *  operation, processing another message block, and updating the
 *  context.
 *
 *  Args:
 *    hCrypt                Context handle
 *    poInput               input block
 *    dwInputLen            length of input block
 *
 *  Return:
 */
void MD5Update (H_CRYPT hCrypt, OCTET *poInput, DWORD dwInputLen);


/*
 * MD5Final
 *  MD5 finalization. Ends an MD5 message-digest operation, writing the
 *  the message digest and zeroizing the context.
 *
 *  Args:
 *   hCrypt               Context handle
 *   pOutput              Must be allocated and of length MD5_HASH_SIZE
 *
 *  Return:
 */
void MD5Final (H_CRYPT hCrypt,OCTET *poDigest);


#endif /* _MD5_H_ */
