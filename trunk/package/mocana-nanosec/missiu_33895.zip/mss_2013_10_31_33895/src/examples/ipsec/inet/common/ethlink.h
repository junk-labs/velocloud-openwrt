/*
 * ethlink.h
 *
 * ethernet link handling API shields any ethernet specific link issues
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _ETHDRIVER_H
#define _ETHDRIVER_H

#ifdef MHX
  #define ETHERNET_DRIVERNAME0 "/dev/ether/locallink"
  #define ETHERNET_DRIVERNAME1 "/dev/ether/uplink"
#else
  #define ETHERNET_DRIVERNAME0 "/dev/ether/uplink"
#endif

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * EthLinkSetup
 *  ethernet specific driver opening setups
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   >=0 for success
 */
LONG EthLinkSetup(NETIFCONF *pxIfConf, OCTET oIfIdx);

#endif

