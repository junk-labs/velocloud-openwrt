/*
 * trkoff.h
 *
 * locally disabling tracking, making all tracking calls compile
 *    into nothing.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __TRKOFF_H
#define __TRKOFF_H


/*
 * allow next include of trk.h to expand
 */
#ifdef __TRK_H
#undef __TRK_H
#endif


#ifdef TrkTag
#undef TrkTag
#endif
#define TrkTag(u, i, l)

#ifdef Trk
#undef Trk
#endif
#define Trk(dw)

#ifdef TrkMem
#undef TrkMem
#endif
#define TrkMem(po,l)

#ifdef TrkMemW
#undef TrkMemW
#endif
#define TrkMemW(po,l, poT, poB)

#ifdef Trk2Tag
#undef Trk2Tag
#endif
#define Trk2Tag(u, i, l)

#ifdef Trk2
#undef Trk2
#endif
#define Trk2(dw)

#ifdef Trk2Mem
#undef Trk2Mem
#endif
#define Trk2Mem(po,l)

#ifdef Trk2MemW
#undef Trk2MemW
#endif
#define Trk2MemW(po,l, poT, poB)

#ifdef TrkFastTag
#undef TrkFastTag
#endif
#define TrkFastTag(u, i, l)

#ifdef TrkFast
#undef TrkFast
#endif
#define TrkFast(dw)

#ifdef TrkfSetup
#undef TrkfSetup
#endif
#define TrkfSetup(hTk, bFa, bFp, bFt)

#ifdef TrkfCall
#undef TrkfCall
#endif
#define TrkfCall(tagid)

#ifdef TrkfParm
#undef TrkfParm
#endif
#define TrkfParm(parm)

#ifdef TrkfParmMem
#undef TrkfParmMem
#endif
#define TrkfParmMem(addr, len)

#ifdef TrkfReturn
#undef TrkfReturn
#endif
#define TrkfReturn(tagid)

#ifdef TrkfReturnValue
#undef TrkfReturnValue
#endif
#define TrkfReturnValue(tagid, value)

#ifdef TrkfReturnAddr
#undef TrkfReturnAddr
#endif
#define TrkfReturnAddr(tagid, addr, len)

#ifdef TrksSetup
#undef TrksSetup
#endif
#define TrksSetup(hTk, fsmid, et, lt, bSe, bSl, bSt)

#ifdef TrksEnter
#undef TrksEnter
#endif
#define TrksEnter(fsmid, state)

#ifdef TrksLeave
#undef TrksLeave
#endif
#define TrksLeave(fsmid)






#endif /* __TRKOFF_H */
