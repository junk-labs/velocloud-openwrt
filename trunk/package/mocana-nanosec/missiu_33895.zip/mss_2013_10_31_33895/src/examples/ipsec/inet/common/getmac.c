
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcfg.h"
#include "setupnet.h"
#include "ecc.h"

extern BOOL g_bForceMacTo0090a0ffffff;

/*
 * SetupNetGetMacAddress
 *  Get the MAC address from the config file
 *
 *  Args:
 *   poMac                Pointer to array of 6 octets
 *
 *  Return:
 *   SetupNetReturn
 */
SetupNetReturn SetupNetGetMacAddress(OCTET* poMac)
{
  unsigned char ucData[8];
  int iFd;
  SetupNetReturn snReturn=SETUPNET_MACMISSING;
  
  if (g_bForceMacTo0090a0ffffff) {
    /* force mac address */
    poMac[0]=0x00; poMac[1]=0x00; poMac[2]=0x86; 
    poMac[3]=0x48; poMac[4]=0x0b; poMac[5]=0xe6;
    snReturn=SETUPNET_OK;
  } else {
#if 0 
    iFd=open("mac",O_RDONLY);
    if (iFd>=0) {
      if (read(iFd,ucData,8)==8) {
        WORD wCrc;
        snReturn=SETUPNET_BADMACECC;
        wCrc=EccCrc16(0,ucData,6);
        if (wCrc==*((WORD*)(ucData+6))) {
          MOC_MEMCPY((ubyte *)poMac,(ubyte *)ucData,6);
#if 0 

          SYSLOG(LOG_DEBUG,"MAC address is %02x:%02x:%02x:%02x:%02x:%02x\n",
                 poMac[0],poMac[1],poMac[2],
                 poMac[3],poMac[4],poMac[5]);
#endif
          snReturn=SETUPNET_OK;
        }
        else {
#if 0 

          SYSLOG(LOG_DEBUG,"MAC address CRC check failed\n");
#endif
          /* ASSERT(0); */
        }
      }
      close(iFd);
    }
    else {
      ASSERT(0);
    }
#endif  /* TBD */
  }
  
  return snReturn; 
}
