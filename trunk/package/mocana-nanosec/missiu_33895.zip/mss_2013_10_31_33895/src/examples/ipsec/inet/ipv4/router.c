/*
 * router.c
 *
 * Implements the router
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/
#include "router.h"
#include "router_defs.h"

/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/
ROUTER_DBG_VAR(DWORD g_dwRouterDebugLevel = DBGLVL_REPETITIVE);


/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * RouterInitialize
 *  Initialize the Router library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG RouterInitialize(void)
{
  /* Initialise the DEBUG symbol to ERROR */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_ERROR);
  return NETERR_NOERR;
}



/*
 * RouterTerminate
 *  Terminate the Router library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG RouterTerminate(void)
{
  return NETERR_NOERR;
}



/*
 * RouterInstanceCreate
 *  Creates a Router Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE RouterInstanceCreate(void)
{
  ROUTERSTATE *pxRouter;

  /*Allocate memory for the the router state*/
  pxRouter = (ROUTERSTATE *)MALLOC(sizeof(ROUTERSTATE));
  if(pxRouter == NULL){
    NETDBG_ASSERT(0);
    return (H_NETINSTANCE)NULL;
  }
  MOC_MEMSET((ubyte *)pxRouter, 0, sizeof(ROUTERSTATE));

  /*set the magic cookie*/
  ROUTER_SET_COOKIE(pxRouter);

  return (H_NETINSTANCE)pxRouter;
}



/*
 * RouterInstanceDestroy
 *  Destroy a Router Instance
 *
 *  Args:
 *   hRouter                       Router instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG RouterInstanceDestroy(H_NETINSTANCE hRouter)
{
  ROUTERSTATE *pxRouter = (ROUTERSTATE *)hRouter;
  ROUTER_CHECK_STATE(pxRouter);

  ROUTER_UNSET_COOKIE(pxRouter);

  FREE(pxRouter);

  return 0;
}

/*
 * RouterInstanceSet
 *  Set a Router Instance Option
 *
 *  Args:
 *   hRouter                   Router instance
 *   oOption                   Option
 *   hData                     Option data
 *
 *  Return:
 *   NETERR_NOERR : success
 *   NETERR_UNKNOWN : error
 */
LONG RouterInstanceSet(H_NETINSTANCE hRouter,
                       OCTET oOption,
                       H_NETDATA hData)
{
  ROUTERSTATE *pxRouter = (ROUTERSTATE *)hRouter;
  LONG lReturn = NETERR_NOERR;

  ROUTER_CHECK_STATE(pxRouter);
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ROUTER_DBGP(DBGLVL_REPETITIVE,"RouterInstanceSet: Option: %x\n", oOption);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceSet: Option : ", oOption);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oOption) {

  case NETOPTION_FREE:
    pxRouter->pfnNetFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_MALLOC:
    pxRouter->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    NETDBG_ASSERT((void*)hData != NULL);
    pxRouter->pxMutex = (RTOS_MUTEX)hData;
    break;

  case NETOPTION_OFFSET:
    pxRouter->wOffset = (WORD)hData;
    break;

  case NETOPTION_TRAILER:
    pxRouter->wTrailer = (WORD)hData;
    break;

  case NETOPTION_NETCBK:
    pxRouter->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    NETDBG_ASSERT(0);
  }

  return lReturn;
}

/*
 * RouterInstanceMsg
 *  Send a msg to a router instance
 *
 *  Args:
 *   hRouter                    Router instance
 *   oMsg                       Msg. See netcommon.h and ipfrag.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   NETERR_NOERR: success
 *   <-1 error
 */
LONG RouterInstanceMsg(H_NETINSTANCE hRouter,
                       OCTET oMsg,
                       H_NETDATA hData)
{
  ROUTERSTATE *pxRouter = (ROUTERSTATE *)hRouter;

  LONG lReturn = NETERR_NOERR;

  ROUTER_CHECK_STATE(pxRouter);
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ROUTER_DBGP(DBGLVL_REPETITIVE, "RouterInstanceMsg: oMsg: %x\n", oMsg);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceMsg: oMsg : ", oMsg);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oMsg) {
  case NETMSG_OPEN:
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ROUTER_DBGP(DBGLVL_REPETITIVE, "Nothing to do in Router for msg: %x\n", oMsg);*/
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "Nothing to do in Router for msg: ", oMsg);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
    break;

  case ROUTERMSG_SETIFIDXLAN:
    pxRouter->oIfIdxLan = (OCTET) hData;
    break;

  case ROUTERMSG_SETIFMTU:
    {
      ROUTERSETIFMTU* pxRouterSetIfMtu = (ROUTERSETIFMTU*) hData;
      pxRouter->awMtu[pxRouterSetIfMtu->oIfIdx] = pxRouterSetIfMtu->wMtu;
    }
    break;

  case ROUTERMSG_SETROUTINGSTATUS:
    {
      ROUTERSETROUTINGSTATUS* pxRouterSetRoutingStatus = (ROUTERSETROUTINGSTATUS*) hData;
      pxRouter->abRoutingDisabled[pxRouterSetRoutingStatus->oIfIdx] = pxRouterSetRoutingStatus->bDisabled;
    }
    break;

  case ROUTERMSG_SETLINKSTATUS:
    {
      ROUTERSETLINKSTATUS* pxRouterSetLinkStatus =
        (ROUTERSETLINKSTATUS*) hData;
      pxRouter->abIsLinkUp[pxRouterSetLinkStatus->oIfIdx] =
        pxRouterSetLinkStatus->bIsLinkUp;
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
      {
        /*ROUTER_DBGP(DBGLVL_REPETITIVE, "Router Link message:  %d  %d\n",
          pxRouterSetLinkStatus->oIfIdx, pxRouterSetLinkStatus->bIsLinkUp);*/
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "Router Link message: ", pxRouterSetLinkStatus->oIfIdx,
                            "  ", pxRouterSetLinkStatus->bIsLinkUp);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }
    }
    break;

#ifdef IP_FILTERING
  case ROUTERMSG_CFGIPFILTERING:
    RouterConfigIpFiltering(pxRouter, (ROUTERCFG_IPFILTERING*) hData);
    break;
#endif

  default:
    lReturn = NETERR_UNKNOWN;
    NETDBG_ASSERT(0);
  }
  return lReturn;
}

/*
 * RouterInstanceULInterfaceCreate
 *
 *  Args:
 *   hRouter                Router instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE RouterInstanceULInterfaceCreate(H_NETINSTANCE hRouter)
{
  ROUTER_CHECK_STATE((ROUTERSTATE*) hRouter);

  return (H_NETINTERFACE)1;
}

/*
 * RouterInstanceULInterfaceDestroy
 *  Destroy a Router UL interface
 *
 *  Args:
 *   hRouter                       Router instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successful
 */
LONG RouterInstanceULInterfaceDestroy(H_NETINSTANCE hRouter,
                                      H_NETINTERFACE hInterface)
{
  ROUTER_CHECK_STATE((ROUTERSTATE*) hRouter);

  if((OCTET)hInterface != 1){
    /*check if the interface is out of range*/
    NETDBG_ASSERT(0);
    return NETERR_BADVALUE;
  }

  return NETERR_NOERR;
}

/*
 * RouterInstanceULInterfaceIoctl
 *  Router UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and nettransport.h
 *  for precisions
 *
 *  Args:
 *   hRouter                      Router instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG RouterInstanceULInterfaceIoctl(H_NETINSTANCE hRouter,
                                    H_NETINTERFACE hULIf,
                                    OCTET oIoctl,
                                    H_NETDATA hData)
{
  ROUTERSTATE *pxRouter = (ROUTERSTATE *)hRouter;
  LONG lReturn = 0;

  ROUTER_CHECK_STATE(pxRouter);

  if((OCTET)hULIf != 1){
    /*check if the interface is out of range*/
    NETDBG_ASSERT(0);
    return NETERR_BADVALUE;
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ROUTER_DBGP(DBGLVL_REPETITIVE, "RouterInstanceULInterfaceIoctl: oIoctl: %x\n", oIoctl);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceULInterfaceIoctl: oIoctl: ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* ignore those */
    break;
  case NETINTERFACEIOCTL_SETHINST:
    pxRouter->hULInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxRouter->pfnRxCbk = (PFN_NETRXCBK)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxRouter->hULIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = -1;
    NETDBG_ASSERT(0);
  }


  return lReturn;
}




/*
 * RouterInstanceLLInterfaceCreate
 *
 *  Args:
 *   hRouter                Router instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE RouterInstanceLLInterfaceCreate(H_NETINSTANCE hRouter)
{
  ROUTER_CHECK_STATE((ROUTERSTATE*) hRouter);

  return (H_NETINTERFACE)1;
}

/*
 * RouterInstanceLLInterfaceDestroy
 *  Destroy a Router LL interface
 *
 *  Args:
 *   hRouter                    Router instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG RouterInstanceLLInterfaceDestroy(H_NETINSTANCE hRouter,
                                      H_NETINTERFACE hInterface)
{
  ROUTER_CHECK_STATE((ROUTERSTATE*) hRouter);

  if((OCTET)hInterface != 1){
    /*check if the interface is out of range*/
    NETDBG_ASSERT(0);
    return NETERR_BADVALUE;
  }

  return NETERR_NOERR;
}

/*
 * RouterInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hRouter                      Router instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG RouterInstanceLLInterfaceIoctl(H_NETINSTANCE hRouter,
                                 H_NETINTERFACE hLLIf,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  ROUTERSTATE *pxRouter = (ROUTERSTATE *)hRouter;
  LONG lReturn = NETERR_NOERR;

  ROUTER_CHECK_STATE(pxRouter);

  /*
   * Check if the LL Interface is valid
   */
  if((OCTET)hLLIf != 1){
    /*check if the interface is out of range*/
    NETDBG_ASSERT(0);
    return NETERR_BADVALUE;
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ROUTER, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ROUTER_DBGP(DBGLVL_REPETITIVE, "RouterInstanceLLInterfaceIoctl: oIoctl: %x\n", oIoctl);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "RouterInstanceLLInterfaceIoctl: oIoctl: ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oIoctl) {

  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* Ignore these */
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxRouter->hLLInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxRouter->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxRouter->hLLIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = -1;
    NETDBG_ASSERT(0);
  }

  return lReturn;
}
