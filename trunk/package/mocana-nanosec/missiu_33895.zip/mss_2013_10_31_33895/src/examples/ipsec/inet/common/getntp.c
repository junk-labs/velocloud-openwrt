
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcfg.h"
#include "setupnet.h"

/*
 * SetupNetGetIfNTPIPAddr
 *  Get the NTP address of an interface
 *
 *  Args:
 *   oIfIdx               Interface index
 *   pdwAddr              IP address to be filled up
 *
 *  Return:
 *   SetupNetReturn
 */
SetupNetReturn SetupNetGetIfNTPIPAddr(OCTET oIfIdx,
                                      DWORD *pdwAddr)
{
  int iSocket;
  struct ifreq xIfReq;
  mnIoctlArgList_t mnIoctlArgList;      
  
  xIfReq.ifr_name[0] = oIfIdx;
  
  if ((iSocket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  mnIoctlArgList.ifreq = (void *)&xIfReq;
  if (0 > ioctl(iSocket,MO_SIOCGIFINTP,&mnIoctlArgList)) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  close(iSocket);
  
  *pdwAddr = ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr;
  
  return SETUPNET_OK; 
}
