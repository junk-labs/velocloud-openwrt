/*
 * sockterminate.c
 *
 * implement the SocketLibraryTerminate function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"

#ifdef IPSEC
#include "ipsec.h"
#endif /* IPSEC */

#ifdef SOCK_RT
  #include "nat.h"
#endif

#ifdef SOCK_BR
  #include "ethernet.h"
#endif

/****************************************************************************
 *
 * Network internal  API functions
 *
 ****************************************************************************/
/*
 * SocketLibraryTerminate
 *  Terminate TCP-UDP/IP sockets. Unregister the devices
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG SocketLibraryTerminate(void)
{
  int i;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
  /* Destroy all existing sockets, as cleanly as possible */
  {
    SOCKET *pxSock;
    /* Destroy all socket */
    for (i=0;i<MAX_FD;i++) {
      pxSock = RETRIEVE_SOCKET(i);
      if (pxSock != NULL) {
        SOCKET_CHECK_STATE(pxSock);
        if (pxSock->lType == SOCK_STREAM) {
          SocketTcpForceTypeToAbortNBIO(pxSock);
        }
        close(pxSock->lFd);
      }
    }
  }
  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

#if 0
  /* Unregister the device */
  unregister_chrdev(DEVICE_MAJOR_SCK, "sck");
#endif

  return 0;
}







