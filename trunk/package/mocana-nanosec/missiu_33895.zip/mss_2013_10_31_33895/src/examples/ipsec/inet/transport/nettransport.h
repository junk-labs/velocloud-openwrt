/*
 * nettransport.h
 *
 * Network transport layer libraries (now UDP and TCP) common definitions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETTRANSPORT_H_
#define _NETTRANSPORT_H_

/*****************************************************************************
 *
 * defines
 *
 *****************************************************************************/

/* Transport UL interface ioctls */
#define NETTRANSPORTULINTERFACEIOCTL_SETLOCALIP \
  NETINTERFACEIOCTL_MODULESPECIFICBEGIN            /* Set the Local IP.
                                                          Data is DWORD */
#define NETTRANSPORTULINTERFACEIOCTL_SETLOCALPORT \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 1)      /* Set the local port.
                                                          data is WORD. if
                                                          port is 0, it will be
                                                          set automatically */
#define NETTRANSPORTULINTERFACEIOCTL_CONNECT \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 2)      /* performs a connect
                                                      Data is TRANSPORT_ID**/
#define NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALIP  \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 3)      /* Query the local
                                                      IP. data is DWORD *
                                                      */
#define NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT  \
     (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 4)      /* Query the local
                                                      port. data is WORD *
                                                      */
#define NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEIP  \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 5)      /* Query the remote IP
                                                      Data is DWORD * */
#define NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEPORT \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 6)     /* Query the remote
                                                         port. Data is
                                                         WORD * */
#define NETTRANSPORTULINTERFACEIOCTL_SETIF \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 7)     /* Set the If index. Data
                                                     is OCTET. 0xFF means
                                                     "don't care"*/

#define NETTRANSPORTULINTERFACEIOCTL_SETVLAN \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 8)     /* Set VLAN tag. Equivalent to
                                                     the TAG CONTROL INFORMATION
                                                     specified in 802.1Q
                                                     Default value: NETVLAN_DEFAULT
                                                     (see common/include/netcommon.h) */

#define NETTRANSPORTULINTERFACEIOCTL_QUERYTRANSPORTID \
   (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 9)    /* Query the transport id
                                                     of the connection. Data
                                                     is TRANSPORTID * */

#define NETTRANSPORTULINTERFACEIOCTL_SETREUSEADDR \
   (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 10)    /* Set the reuse address option,
                                                      propogated from the socket
                                                      setting. Data is BOOL */

/* Tranasport specific statistics
 *  TCP - mn_tcp_sock_stats_t
 *  UDP - mn_udp_sock_stats_t
 */
#define NETTRANSPORTULINTERFACEIOCTL_QUERYSTATS \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 11)

#define NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 12)

/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/

typedef struct {
  DWORD dwSrcIpAddr;
  DWORD dwDstIpAddr;
  E_ADDRTYPE eDstAddrType;
  OCTET oIfIdx;
  WORD  wVlan;
  DWORD dwGatewayAddr;
  DWORD dwSecurityPolicy;
  WORD wIpSecHdrLength;
  WORD wIpSecTrailLength;

  OCTET aoUnused[20]; /* Adjust the size so that it is as big
                         as a NETWORKID */
}TRANSPORT2NETWORKID;

/*
 * Transport Id structure
 */
typedef struct {
  WORD wSrcPort;
  WORD wDstPort;

  TRANSPORT2NETWORKID xNetId;
} TRANSPORTID;


#endif /* #ifndef _NETTRANSPORT_H_ */
