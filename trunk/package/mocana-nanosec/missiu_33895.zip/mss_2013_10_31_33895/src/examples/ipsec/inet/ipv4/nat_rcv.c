/*
 * nat_rcv.c
 *
 * NAT Rx function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/
#include "nat.h"
#include "nat_defs.h"

/*****************************************************************************
 *
 * Debug
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Local Function
 *
 *****************************************************************************/



/*****************************************************************************
 *
 * API function
 *
 *****************************************************************************/
/*
 * NatInstanceRcv
 *   NAT Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hNat                    NAT Instance Handle
 *    hIf                     Interface handle
 *    pxNetPacket             packet
 *    pxNetPacketAccess       info about packet
 *    hData                   pointer to a NETWORKID structure
 *
 *   Return:
 *    Number of bytes received or -1(error)
 */
LONG NatInstanceRcv(H_NETINSTANCE    hNat,
                    H_NETINTERFACE   hIf,
                    NETPACKET        *pxNetPacket,
                    NETPACKETACCESS  *pxNetPacketAccess,
                    H_NETDATA        hData)
{
  NATSTATE           *pxNat = (NATSTATE *)hNat;
  NETPAYLOAD         *pxPayload;
  NETWORKID          *pxNetworkId = (NETWORKID*) hData;
  void               *pvProtocolHdr = NULL;
  E_NAT_RETURN_VALUE eNatRv = NAT_PACKET_UNKNOWN;

  NAT_CHECK_STATE(pxNat);
  NETPACKET_CHECK(pxNetPacket);
  ASSERT((pxNetPacketAccess != NULL) &&
         (pxNetworkId != NULL) &&
         (pxNat->pfnRxCbk != NULL) &&
         ((int)hIf == 1));

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
  {
    /*NAT_DBGP(DBGLVL_REPETITIVE, "NatInstanceRcv():oIfIdx = %d, %ld.%ld.%ld.%ld ==> %ld.%ld.%ld.%ld  %s  length=%d, DstAddrType=%s\n",
                        pxNetworkId->oIfIdx,
                        IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
                        IPADDRDISPLAY(pxNetworkId->dwDstAddr),
                        IpProtoToString(pxNetworkId->oProtocol),
                        pxNetPacketAccess->wLength,
                        IpAddressTypeToString(pxNetworkId->eDstAddrType));*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NatInstanceRcv():oIfIdx = ", pxNetworkId->oIfIdx);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", ", pxNetworkId->dwSrcAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " ==> ", pxNetworkId->dwDstAddr);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, " ", IpProtoToString(pxNetworkId->oProtocol));
    DEBUG_PRINTSTR1INT1(DEBIG_MOC_IPV4, "length = ", pxNetPacketAccess->wLength);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, ", DstAddrType = ", IpAddressTypeToString(pxNetworkId->eDstAddrType));
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }


  pxPayload = pxNetPacket->pxPayload;

  pvProtocolHdr = (void*) (pxPayload->poPayload +
                           pxNetPacketAccess->wOffset +
                           pxNetworkId->oIpHdrLen);
  ASSERT(((DWORD) pvProtocolHdr & 0x3) == 0);


  /*******************************************************
   *
   * If the received data is on the LAN leg, do nothing.
   * Just pass it up. The data is also passed up if the
   * packet was IPSEC tunnelled.
   *
   ******************************************************/
  if ((pxNetworkId->oIfIdx == pxNat->oIfIdxLan) ||
      ((pxNetworkId->eDstAddrType == IPADDRT_MYSUBNET) && (pxNetworkId->bTunnelled == TRUE))) {

#ifdef /*NATDBG_HI*/ TOTO
    /*
     * Check that the IPSEC tunnelled packet is intended for the
     * LAN.
     */
    if ((IPADDRT_MYSUBNET == pxNetworkId->eDstAddrType) &&
        (pxNetworkId->oIfIdx != pxNat->oIfIdxLan)) {
      IPTABLEENTRY xIpEntry;

      xIpEntry.dwAddr = pxNetworkId->dwDstAddr;
      xIpEntry.wDefaultVlan = NETVLAN_ANY;
      xIpEntry.oIfIdx = pxNat->oIfIdxLan;

      ASSERT(IPADDRT_MYSUBNET == IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry));
    }
#endif


    /*
     * Check for blocked ports on LAN
     */
    if (pxNetworkId->eDstAddrType == IPADDRT_MYADDR) {
      if (TRUE == NatIsPortBlockedLanToCpe(pxNat,
                                           (WORD) TRANSPORT_GET_DST_PORT(pvProtocolHdr),
                                            pxNetworkId->oProtocol)) {
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE,"\nNatInstanceRcv(): dropping LAN packet to CPE as port is blocked\n");*/
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "NatInstanceRcv(): dropping LAN packet to CPE as port is blocked ");
        }
        NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
        return (LONG)-1;
      }
    }

    return pxNat->pfnRxCbk(pxNat->hULInst,
                           pxNat->hULIf,
                           pxNetPacket,
                           pxNetPacketAccess,
                           hData);
  }


  /****************************************************************
   * DMZ Host forwarding.
   * DMZ host is setup to allow all connection requests to
   * be routed to one host on the LAN. All the ports will
   * be forwarded to one host.
   * This is taken care of in the transport layer specific
   * (TCP/UDP/ICMP) handlers.
   ****************************************************************/

  ASSERT(pxNetworkId->eDstAddrType != IPADDRT_UNKNOWN);
  if (pxNetworkId->eDstAddrType == IPADDRT_MYADDR) {

    switch (pxNetworkId->oProtocol) {

      case IPPROTO_UDP:
      case IPPROTO_TCP:
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "SrcP %d, DstP %d\n",
                         TRANSPORT_GET_SRC_PORT(pvProtocolHdr),
                         TRANSPORT_GET_DST_PORT(pvProtocolHdr));*/
          DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "SrcP : ", TRANSPORT_GET_SRC_PORT(pvProtocolHdr).
                              ", DstP : ", TRANSPORT_GET_DST_PORT(pvProtocolHdr));
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }

        eNatRv = NatHandleTURx(pxNat,
                               pxNetPacket,
                               pxNetPacketAccess,
                               hData,
                               pvProtocolHdr);
        break;

      case IPPROTO_ICMP:
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "\n");*/
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }
        eNatRv = NatHandleIcmpRx(pxNat,
                                 pxNetPacket,
                                 pxNetPacketAccess,
                                 hData,
                                 pvProtocolHdr);
        break;

      default:
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "\n");*/
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }
        break;
    }


    switch (eNatRv) {

      case NAT_DO_NOTHING:
        break;

      case NAT_TO_CPE:
        /*
         * Pass it up the stack.
         */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "NatInstanceRcv(): Directing received packet to CPE %ld.%ld.%ld.%ld ==> %ld.%ld.%ld.%ld\n",
                        IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
                        IPADDRDISPLAY(pxNetworkId->dwDstAddr));*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "NatInstanceRcv(): Directing received packet to CPE ", (pxNetworkId->dwSrcAddr));;
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " ==> ", pxNetworkId->dwDstAddr);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }

        return pxNat->pfnRxCbk(pxNat->hULInst,
                               pxNat->hULIf,
                               pxNetPacket,
                               pxNetPacketAccess,
                               hData);
        break;


      case NAT_PACKET_UNKNOWN:
      case NAT_OUT_OF_RESOURCE:
        NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
        return (LONG)-1;


      default:
        /*******************************************************
         * Give address/port translated packet to
         * upper layer. It will take care of
         * sending the data down the appropriate leg.
         ******************************************************/
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "NatInstanceRcv(): Directing received packet to LAN %ld.%ld.%ld.%ld ==> %ld.%ld.%ld.%ld\n",
                        IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
                        IPADDRDISPLAY(pxNetworkId->dwDstAddr));*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "NatInstanceRcv(): Directing received packet to LAN ", pxNetworkId->dwSrcAddr);
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " ==> ", pxNetworkId->dwDstAddr);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        }

        /*
         * Only packets going to the LAN should go thru' this path.
         */
#ifndef NDEBUG
        {
          IPTABLEENTRY xIpEntry;

          xIpEntry.dwAddr = pxNetworkId->dwDstAddr;
          xIpEntry.wDefaultVlan = NETVLAN_ANY;
          xIpEntry.oIfIdx = pxNat->oIfIdxLan;

          ASSERT(IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry) == IPADDRT_MYSUBNET);
        }
#endif
        pxNetworkId->eDstAddrType = IPADDRT_MYSUBNET;

        return pxNat->pfnRxCbk(pxNat->hULInst,
                               pxNat->hULIf,
                               pxNetPacket,
                               pxNetPacketAccess,
                               hData);
        break;
    }

  } else if ((pxNetworkId->eDstAddrType == IPADDRT_BROADCAST) ||
             (pxNetworkId->eDstAddrType == IPADDRT_MULTICAST) ||
             (pxNetworkId->eDstAddrType == IPADDRT_MULTICASTJOINED) ||
             (pxNetworkId->eDstAddrType == IPADDRT_MULTICASTJOINEDPROXY) ||
             (pxNetworkId->eDstAddrType == IPADDRT_MULTICASTJOINEDSOCKPROXY)) {
    /*********************************************************
     * Just pass the broadcast and multicast packets up
     * the stack. The upper layer should take care of
     * routing the packets to the appropriate destination.
     ********************************************************/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE,"\nNatInstanceRcv():broadcast or multicast packet\n");*/
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "NatInstanceRcv(): broadcast or multicast packet");
      }
      return pxNat->pfnRxCbk(pxNat->hULInst,
                             pxNat->hULIf,
                             pxNetPacket,
                             pxNetPacketAccess,
                             hData);

  } else {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
    {
      /*NAT_DBGP(DBGLVL_REPETITIVE,"\nNatInstanceRcv():binning packet\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "NatInstanceRcv(): binning packet");
    }
    /*
     *  drop the unwelcome packet.
     */
    NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
    return (LONG)-1;

  }


  return (LONG)pxNetPacketAccess->wLength;
}
