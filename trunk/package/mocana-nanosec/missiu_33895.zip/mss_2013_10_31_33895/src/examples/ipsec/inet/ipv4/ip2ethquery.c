/*
 * ip2ethquery.c
 *
 * IP2ETH query function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "ip2eth_defs.h"

/*
 * Ip2EthInstanceQuery
 *  Query a Ip2Eth Instance Option
 *
 *  Args:
 *   hIp2Eth                    Ip2Eth instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG Ip2EthInstanceQuery(H_NETINSTANCE hIp2Eth,
                         OCTET oOption,
                         H_NETDATA *phData)
{
  return NETERR_NOERR;
}
