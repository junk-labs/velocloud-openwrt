/*
 * ntp.c
 *
 * Network Time functions
 *
 * Copyright Mocana Corp 2007. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*! \file ntp.c NTP API.
This file contains NTP API functions.

\since 3.06
\version 3.06 and later

! Flags
To build products using this header file, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT$

! External Functions
This file contains the following public ($extern$) functions:
- NTP_addInstance
- NTP_addServer
- NTP_deleteInstance
- NTP_getAttribute
- NTP_getInstancePtrFromId
- NTP_getServerIDFromAddrPort
- NTP_getServerRecordFromID
- NTP_getUDPCookieFromServerID
- NTP_init
- NTP_periodic
- NTP_releaseServer
- NTP_requestNew
- NTP_requestRelease
- NTP_requestSend
- NTP_responseCallback
- NTP_setRequestUserCookie
- NTP_shutdown

*/

#include "../common/moptions.h"
#if defined(__ENABLE_MOCANA_NTP_CLIENT__)

#include "../common/mtypes.h"
#include "../common/mocana.h"
#include "../common/mdefs.h"
#include "../common/merrors.h"
#include "../common/mrtos.h"
#include "../common/mstdlib.h"
#include "../common/mudp.h"
#include "../common/mbitmap.h"
#include "../utils/search.h"
#include "../utils/redblack.h"
#include "../utils/timer.h"
#include "../common/debug_console.h"

#include "ntp.h"

/*------------------------------------------------------------------*/

NTP_Globals gNTP_globals;

/*------------------------------------------------------------------*/
static sbyte4 ntp_serverCompare (const void *p1, const void *p2, const void *config);

static void ntp_releaseRequestsForServer(sbyte4 serverId);

static MSTATUS
ntp_checkConfig(const NTP_Config *config);

static void
ntp_serverDelete(sbyte4 serverID, NTP_Instance *pInst);

static void
ntp_releaseRequestsForServer(sbyte4 serverId);

static void
ntp_requestDelete(NTP_RqstRecord *pRequest, NTP_Instance *pInst);

static sbyte4
ntp_instanceDelete(NTP_Instance *pInst);

static sbyte4
ntp_serverCompare (const void *p1,
                   const void *p2,
                   const void *config);

static sbyte4
ntp_instanceCompare(const void *p1,
                    const void *p2,
                    const void *config);

static void
ntp_timerCallBack(void *request, ubyte *type);

static MSTATUS
ntp_pktValidate(NtpPacket *pPkt, ubyte4 pktLen);


/*------------------------------------------------------------------*/
/*! Initialize NTP internal data structures.
This function initializes the NTP internal data structures.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_init()
{
    MSTATUS status = OK;
    /* Create a Instance Map for NTP Instances */
    status = MBITMAP_createMap((bitmapDescr**)&gNTP_globals.instanceIdMap,NTP_INSTANCE_ID_START, NTP_INSTANCE_ID_END);
     if (OK >  status)
    {
        DEBUG_ERROR(DEBUG_CUSTOM,
                "NTP_init(): MBITMAP_createMap() failed, status = ", status);
        goto exit;
    }


    if (OK > (status = RTOS_mutexCreate(&gNTP_globals.instanceTreeMutex, 0, 1)))
    {
        DEBUG_ERROR(NTP_ERROR, "NTP_init(): RTOS_mutexCreate failed, status = ", status);
        goto exit;
    }

    gNTP_globals.instanceTree = rbinit (ntp_instanceCompare,NULL,0);

    if (NULL ==  gNTP_globals.instanceTree)
    {
        status = ERR_RBTREE_CREATE_FAILED;
        goto exit;
    }
    gNTP_globals.numInstances = 0;


exit:
    if (OK > status)
    {
        status = RTOS_mutexFree(&gNTP_globals.instanceTreeMutex);

        if (gNTP_globals.instanceIdMap)
            MBITMAP_releaseMap((bitmapDescr**)&gNTP_globals.instanceIdMap);
    }

    return status;
}


/*------------------------------------------------------------------*/

static MSTATUS
ntp_checkConfig(const NTP_Config *config)
{
    MSTATUS status = OK;
    if ((NULL == config->funcPtrBindUDP) || (NULL == config->funcPtrSendUDP) ||
        (NULL == config->funcPtrUnBindUDP))
    {
        status = ERR_NTP_BAD_CONFIG;
    }
    return status;
}


/*------------------------------------------------------------------*/
/*! Add an NTP %client instance.
This function adds an NTP %client virtual instance, using the specified
configuration parameters.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param instanceId   On return, pointer to virtual instance ID.
\param config       Pointer to desired %client configuration settings and
callback function pointers.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_addInstance(sbyte4 *instanceId, const NTP_Config *config)
{
    NTP_Instance    *pInst, *pTInst;
    MSTATUS            status = OK;

    if (NULL == (pInst = MALLOC(sizeof(NTP_Instance))))
    {
        status = ERR_MEM_ALLOC_FAIL;
        DEBUG_ERROR(DEBUG_CUSTOM, "NTP_addInstance: malloc() failed, status =", status);
        goto exit;
    }

    /* Validate the Configuration Infomation */
    if (OK > (status = ntp_checkConfig(config)))
    {
        DEBUG_ERROR(DEBUG_CUSTOM, "NTP_addInstance(): config check failed with  status = ", status);
        goto exit;
    }

    /* initialise the timer module */
    if (OK > (status = TIMER_initTimer()))
    {
        goto exit;
    }

    if (OK > (status = RTOS_mutexWait(gNTP_globals.instanceTreeMutex)))
    {
        DEBUG_ERROR(DEBUG_CUSTOM, "NTP_addInstance(): failed to acquire mutex status = ", status);
        FREE(pInst);
        goto exit;
    }

    /* Create a request timeout Timer */
    if (OK > (status = TIMER_createTimer(ntp_timerCallBack,
                                        &pInst->reqTimeout)))
    {
        RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);
        FREE(pInst);
        goto exit;
    }

    pInst->serverTree = rbinit(ntp_serverCompare,NULL,0);

    if (NULL == pInst->serverTree)
    {
        status = ERR_RBTREE_CREATE_FAILED;
        RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);
        FREE(pInst);
        goto exit;
    }

    /* Get a Server handle */
    status = MBITMAP_findVacantIndex((bitmapDescr*)gNTP_globals.instanceIdMap, &pInst->instanceId);

    if (OK != status)
    {
        RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);
        FREE(pInst);
        goto exit;
    }

    pTInst = (NTP_Instance *) rbsearch(pInst, gNTP_globals.instanceTree);

    if (pInst != pTInst)
    {
        MBITMAP_clearIndex((bitmapDescr*)gNTP_globals.instanceIdMap,
                           pInst->instanceId);
        RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);
        FREE(pInst);
        status = ERR_RBTREE_INSERT_FAILED;
        goto exit;
    }

    MOC_MEMCPY((ubyte*)&pInst->config,(const ubyte *)config,
               sizeof(NTP_Config));

    if ( 0 >= pInst->config.ntpReqTimeoutIntervalMS )
        pInst->config.ntpReqTimeoutIntervalMS = NTP_REQ_TIMEOUT_INTERVAL_MS;

    pInst->instRef = 0;

    *instanceId = pInst->instanceId;
    gNTP_globals.numInstances++;
    RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);

exit:
    return status;
}


/*------------------------------------------------------------------*/
/*! Register a server for the NTP %client to query or to send accounting data to.
This function registers a server for the NTP %client to query or to send
accounting data to, and connects the NTP %client IP/port and NTP %server IP/port.
This function should be called for every server before using the server in
an NTP_init function call.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param instanceId           Instance ID returned from an _initInstance call.
\param srcAddr              IP address to use as the source identifier when
sending a UDP datagram.
\param serverIPAddress      String representation of the RADIUS server's IP
address.
\param port                 UDP listen port of the RADIUS %server.
\param retID                On return, ID of the RADIUS %server.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_addServer(sbyte4 instanceId, MOC_IP_ADDRESS srcAddr,
                 sbyte *serverIPAddress, sbyte4 port, sbyte4 *retID)
{
    NTP_ServerRecord*           pServer = NULL, *pTServer;
    ubyte*                      p;
    ubyte*                      pSS;
    ubyte4                      strSz;
    MSTATUS                     status = ERR_NTP;
    NTP_Instance                tInst, *pInst;
    ubyte                       workingOnInstance = FALSE;
    MOC_IP_ADDRESS              ipAddr;

    *retID = ERR_NTP_INVALID_SERVER_ID;

    tInst.instanceId = instanceId;
    if (OK > (status = RTOS_mutexWait(gNTP_globals.instanceTreeMutex)))
    {
        DEBUG_ERROR(DEBUG_CUSTOM, "NTP_addServer:Failed to acquire mutex, status = ", status);
        goto exit;
    }
    pInst = (NTP_Instance*) rbfind(&tInst,gNTP_globals.instanceTree);
    if (NULL == pInst)
    {
        status = ERR_NTP_INSTANCE_ID_NOT_FOUND;
        RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);
        goto exit;
    }
    workingOnInstance = TRUE;
    pInst->instRef++;
    RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);

    if (NULL == (pServer = MALLOC(sizeof(NTP_ServerRecord))))
    {
        status = ERR_MEM_ALLOC_FAIL;
        DEBUG_ERROR(DEBUG_CUSTOM,"NTP_addServer: malloc() failed, status = ", status);
        goto exit;
    }
    strSz = MOC_STRLEN(serverIPAddress) + 1;

    if (NULL == (p = MALLOC(strSz)))
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }
    MOC_MEMCPY(p, (ubyte *)serverIPAddress, strSz);
    pServer->pServerName = (sbyte *)p;
    /* copy over IP address */
    MOC_MEMCPY((ubyte *)&(pServer->srcAddr), (ubyte *)&srcAddr,
            sizeof(MOC_IP_ADDRESS));

    /* get the IP address of the server  */
    status = UDP_getAddrOfHost(pServer->pServerName,
                               &pServer->serverAddress);
    if (OK > status)
    {
        FREE(p);
        FREE(pSS);
        FREE(pServer);
        goto exit;
    }

    pServer->port = port;

    pTServer = (NTP_ServerRecord *) rbfind(pServer, pInst->serverTree);

    if (pTServer != NULL)
    {
        status = ERR_NTP_SERVER_EXISTS;
        DEBUG_ERROR(DEBUG_CUSTOM, "NTP Server exists. Use NTP_server \
         add instance to add an instance, status = ", status);
        FREE(p);
        FREE(pSS);
        FREE(pServer);
        return status;
    }

    /* server not found. adding new server first time */
    MOC_MEMSET((ubyte *)&pServer->counters, 0, sizeof(pServer->counters));

    pServer->serverStatus = NTP_SERVER_UP;
    pServer->cfgPtr = &pInst->config;
    pServer->ntpInstanceId = instanceId;

    /* Add to the rbtree */
    pTServer = (NTP_ServerRecord *) rbsearch(pServer, pInst->serverTree);

    if (pTServer != pServer)
    {
        status = ERR_RBTREE_INSERT_FAILED;
        goto exit;
    }

    /* start the UDP connection here */
    if (OK > ( status =
          pServer->cfgPtr->funcPtrBindUDP(pServer->srcAddr,
                               pServer->pServerName,
                               pServer->port,
                               &pServer->udpCookie)))
    {
        status = ERR_NTP_SERVER_BIND_FAIL;
        goto exit;
    }

#if defined(__RTOS_LINUX__) || defined(__RTOS_WIN32__) || defined(__RTOS_CYGWIN__) || defined(__RTOS_OSX__)
    status = UDP_getSrcPortAddr(pServer->udpCookie,
                        &pServer->srcPort,
                        &ipAddr);
    if (OK > status)
    {
        status = ERR_NTP_GET_PORT_ADDR_FAIL;
        goto exit;
    }
#endif

    status = OK;
    *retID = (sbyte4)pServer;

exit:
    if (TRUE == workingOnInstance)
    {
        sbyte4 mutexStatus = OK;
        mutexStatus = RTOS_mutexWait(gNTP_globals.instanceTreeMutex);
        if (OK == mutexStatus)
        {
            workingOnInstance = FALSE;
            pInst->instRef--;
            RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);
        }
        else
        {
            status = mutexStatus;
        }
    }

    if (OK > status)
        NTP_releaseServer((sbyte4)pServer);

    return status;
}


/*------------------------------------------------------------------*/
/*! Discontinue communication with an NTP server.
This function discontinues communication with the specified NTP server by
removing it from the NTP client's list of registered servers. To reestablish
contact after calling this function, call NTP_shutdown, NTP_addServer, and
NTP_init (in that order).

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param serverID ID of the NTP server (returned by NTP_addServer) to
remove from server-%client communication.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_releaseServer(sbyte4 serverID)
{
    NTP_ServerRecord     *pServer = (NTP_ServerRecord *)serverID;
    NTP_Instance         tInst, *pInst = NULL;
    sbyte4                  status;

    if (NULL == pServer )
    {
        status = ERR_NTP_INVALID_SERVER_ID;
        goto exit;
    }

    tInst.instanceId = pServer->ntpInstanceId;

    if (OK > (status = RTOS_mutexWait(gNTP_globals.instanceTreeMutex)))
    {
        goto exit;
    }

    pInst = (NTP_Instance*) rbfind(&tInst, gNTP_globals.instanceTree);
    RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);

    if (NULL == pInst)
    {
        status = ERR_NTP_INSTANCE_ID_NOT_FOUND;
        goto exit;
    }

    ntp_serverDelete(serverID,pInst);

exit:
    return status;
}

/*------------------------------------------------------------------*/

static void
ntp_releaseRequestsForServer(sbyte4 serverId)
{
    NTP_RqstRecord      *pRqst;
    NTP_ServerRecord    *pServer = (NTP_ServerRecord *)serverId;

    if(pServer)
    {
        pRqst = pServer->pRequest;
        if(pRqst)
            NTP_requestRelease(pRqst);
    }
}


/*------------------------------------------------------------------*/
/*! Free memory used by a previous request/response.
This function frees the memory used by a previous request/response, including
all the data to which they point. You should call this for every
request/response once it has been fully processed.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param pRqst    Pointer to the request whose memory you want to release.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern void
NTP_requestRelease(NTP_RqstRecord *pRqst)
{
    NTP_Instance    *pInst;
    NTP_ServerRecord    *pSrvr = (NTP_ServerRecord *) pRqst->serverID;
    if (OK > NTP_getInstancePtrFromId(pSrvr->ntpInstanceId, &pInst))
    {
        goto exit;
    }

    ntp_requestDelete(pRqst, pInst);

exit:
    return;
}


/*------------------------------------------------------------------*/
static void
ntp_requestDelete(NTP_RqstRecord *pRequest, NTP_Instance *pInst)
{

    if (NULL == pRequest)
    {
        DEBUG_ERROR(DEBUG_CUSTOM,"null request passed to ntp_requestDelete ",0);
        goto exit;
    }

    TIMER_unTimer((void *)pRequest, pInst->reqTimeout);

    pRequest->inUse = FALSE; /* marks as unused */

    FREE(pRequest);

exit:
    return;
}


/*------------------------------------------------------------------*/
/*! Generate a new request.
This function generates a new NTP %client request, returning it through the
$ppRequest$ pointer. (To send the request to the NTP server, call NTP_requestSend.)

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param ppRequest    On return, pointer to a new descriptor for an NTP %client request.
\param serverID     ID of the NTP server (returned by NTP_addServer).

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_requestNew(NTP_RqstRecord **ppRequest, sbyte4 serverID)
{
    NTP_RqstRecord*      pRqst;
    ubyte4               curTicks = RTOS_getUpTimeInMS();
    MSTATUS              status = ERR_NTP_TOO_MANY_REQUESTS;
    NTP_ServerRecord*    pServer = (NTP_ServerRecord *)serverID;

    DEBUG_ERROR(DEBUG_CUSTOM, "newRequestRecord : srcPort = ", pServer->srcPort);

    *ppRequest = NULL;

    /* allocate NTP Request */
    if (NULL == (pRqst = MALLOC(sizeof(NTP_RqstRecord))))
    {
        status = ERR_MEM_ALLOC_FAIL;
        goto exit;
    }

    MOC_MEMSET((ubyte *)pRqst, 0x00, sizeof(NTP_RqstRecord));

    pRqst->serverID = serverID;
    pRqst->timestamp = curTicks;
    pRqst->inUse = TRUE;
    pRqst->serverSrcPortNum = pServer->srcPort;
    pRqst->userCookie = NULL;

    /* Set the NTP Header for NTP Versiona and Mode */
    pRqst->ntpPacket.li_vn_mode = PKT_LI_VN_MODE(NTP_LEAP_INDICATOR, NTP_VERSION, NTP_MODE_CLIENT);

    *ppRequest = pRqst;
    status = OK;
    return status;

exit:
    if (NULL != pRqst)
        NTP_requestRelease(pRqst);

    return status;
}


/*------------------------------------------------------------------*/
/*! Save and associate data with a specific request.
This function saves any data you want to associate with a specific request; the
data can be retrieved from the response.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param pRequest Descriptor for an NTP request.
\param pCookie  Pointer to the data to save as the cookie associated with the
specified request.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_setRequestUserCookie(NTP_RqstRecord *pRequest, void *pCookie)
{
    if (NULL == pRequest)
        return ERR_NULL_POINTER;

    /* set Cookie */
    ((NTP_RqstRecord*)pRequest)->userCookie = pCookie;

    return OK;
}


/*------------------------------------------------------------------*/
/*! Send a request.
This function sends (transmits) the specified request. (The request contains the
destination %server.)

This function automatically manages retries, although you can change the timeout
value during initial NTP %client code integration by changing the
NTP_Config::ntpReqTimeoutIntervalMS value.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param pRequest Descriptor for an NTP request.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_requestSend(NTP_RqstRecord *pRequest)
{
    NTP_ServerRecord     *pServer;
    NTP_Instance         *pInst;
    MSTATUS              status;

    if (NULL == pRequest)
    {
        status = NTP_ERROR;
        goto exit;
    }

    /* Get Server instance */
    if (OK > (status = NTP_getServerRecordFromID(pRequest->serverID, &pServer)))
        goto exit;

    /* Get NTP instance */
    if (OK > (status = NTP_getInstancePtrFromId(pServer->ntpInstanceId,
                                                  &pInst)))
    {
        goto exit;
    }

    if (NTP_SERVER_DOWN == pServer->serverStatus)
    {
        status = ERR_NTP_SERVER_NOT_ACTIVE;
        goto exit;
    }

    /* Send NTP Request over UDP */
    if (OK == (status =
               pServer->cfgPtr->funcPtrSendUDP(pServer->udpCookie,
                                              (ubyte*)&pRequest->ntpPacket,
                                              NTP_PKT_LEN)))
    {
        pServer->counters.txPacket++;

        pServer->pRequest = pRequest;

        DEBUG_PRINTSTR1INT1(DEBUG_CUSTOM, "ntp_requestSend(): Queue timer of ",
                           (pServer->cfgPtr->ntpReqTimeoutIntervalMS/1000));
        DEBUG_PRINTNL(DEBUG_CUSTOM, " seconds");

        /* Queue Request Timeout Timer */
        if( (OK > (status = TIMER_queueTimer((void *)pRequest, pInst->reqTimeout,
                            pServer->cfgPtr->ntpReqTimeoutIntervalMS/1000, 0))))
        {
            DEBUG_ERROR(DEBUG_CUSTOM, "ntp_requestSend(): Unable to queue timer for request: ", pRequest);
            goto exit;
        }
    }
    else
    {
        pServer->counters.txFails++;
    }

exit:
    return status;
}


/*------------------------------------------------------------------*/
/*! Get an instance pointer for a given NTP %client instance ID.
This function retrieves an instance pointer for a given NTP %client
instance ID (returned by a previous call to NTP_addInstance).

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param instanceId   ID of the NTP %client virtual instance (returned by a
previous call to NTP_addInstance) you need an instance pointer for.
\param instPtr      On return, pointer to desired instance record.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_getInstancePtrFromId(sbyte4 instanceId, NTP_Instance **instPtr)
{
    MSTATUS            status = OK;
    NTP_Instance    tInst, *pInst;
    *instPtr = NULL;
    tInst.instanceId = instanceId;
    if (OK > (status = RTOS_mutexWait(gNTP_globals.instanceTreeMutex)))
    {
        goto exit;
    }
    /* Find the NTP Instance */
    pInst = (NTP_Instance *)rbfind(&tInst, gNTP_globals.instanceTree);
    RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);
    if (NULL == pInst)
    {
        status = ERR_NTP_INSTANCE_ID_NOT_FOUND;
        goto exit;
    }
    *instPtr = pInst;
exit:
    return status;
}


/*------------------------------------------------------------------*/
/*! Get a server's UDP cookie.
This function retrieves information about the specified server from its server
record UDP cookie.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\note Most NTP %client implementations do not need to access this data outside
of the UDP abstraction layer code.

\param serverID     ID of the NTP server (returned by NTP_addServer) of interest.
\param ppUDPCookie  On return, pointer to the server record's UDP cookie, which
was created by the NTP_Config::funcPtrBindUDP upcall.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_getUDPCookieFromServerID(sbyte4 serverID, void **ppUDPCookie)
{
    MSTATUS              status;
    NTP_ServerRecord*    pServer;

    *ppUDPCookie = NULL;

    if (0 > (status = NTP_getServerRecordFromID(serverID, &pServer)))
        goto exit;

    *ppUDPCookie = pServer->udpCookie;

exit:
    return status;
}


/*------------------------------------------------------------------*/
/*! Get a server's information record.
This function retrieves information about the specified server from its server
record.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param serverID     ID of the NTP server (returned by NTP_addServer) of interest.
\param ppServer     On return, pointer to address of server's associated server record.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_getServerRecordFromID(sbyte4 serverID, NTP_ServerRecord **ppServer)
{
    MSTATUS status = OK;

    *ppServer = NULL;

    *ppServer = (NTP_ServerRecord*)serverID;

    return status;
}


/*------------------------------------------------------------------*/
/*! Retrieve the ID of the NTP server that sent a specific packet.
This function retrieves the ID of the NTP server that sent a specific packet.
First the UDP source port and address is extracted, and then the configured
server ID is determined.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param instanceId       Virtual instance ID to which this interface belongs;
previously returned from NTP_addInstance.
\param serverAddress    IP address of the NTP server from which the response arrived.
\param serverPort       UDP source port on which the response arrived.
\param srcAddr          Local interface address on which the packet was received.
\param serverID         On return, pointer to desired NTP server ID.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_getServerIDFromAddrPort(sbyte4 instanceId,
                MOC_IP_ADDRESS serverAddress, ubyte2 serverPort,
                MOC_IP_ADDRESS srcAddr, sbyte4 *serverID)
{
    MSTATUS              status = OK;
    NTP_ServerRecord     server;
    NTP_ServerRecord     *pServer = NULL;
    NTP_Instance         tInst,*pInst;

    tInst.instanceId = instanceId;

    if (OK > (status = RTOS_mutexWait(gNTP_globals.instanceTreeMutex)))
    {
        goto exit;
    }
    /* Find the NTP Instance */
    pInst = (NTP_Instance *) rbfind(&tInst, gNTP_globals.instanceTree);
    RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);

    if (NULL == pInst)
    {
        status = ERR_NTP_INSTANCE_ID_NOT_FOUND;
        goto exit;
    }

    server.serverAddress = serverAddress;
    server.port          = serverPort;
    server.srcAddr       = srcAddr;

    /* Find Server Record */
    pServer = (NTP_ServerRecord *)rbfind(&server,pInst->serverTree);

    if (NULL == pServer)
    {
        status = ERR_NTP_SERVER_NOT_FOUND;
        goto exit;
    }

    *serverID = (sbyte4)pServer;
    status = OK;
exit:
    return status;
}


/*------------------------------------------------------------------*/
static void
ntp_serverDelete(sbyte4 serverID, NTP_Instance *pInst)
{
    NTP_ServerRecord     *pServer = (NTP_ServerRecord *)serverID;
    NTP_ServerRecord     *pTServer = NULL;

    if (NULL != pServer->pServerName)
    {
        FREE(pServer->pServerName);
        pServer->pServerName = NULL;
    }

    /* Remove any pending requests */
    ntp_releaseRequestsForServer(serverID);
    if (pServer->udpCookie)
    {
         (pServer->cfgPtr->funcPtrUnBindUDP)(&pServer->udpCookie);
    }

    /* Remove from the Tree */
    pTServer = (NTP_ServerRecord *) rbdelete (pServer,pInst->serverTree);

    pServer->serverAddress = 0;
    pServer->port = 0;
    FREE(pServer);
}


/*------------------------------------------------------------------*/
static sbyte4
ntp_instanceDelete(NTP_Instance *pInst)
{
    NTP_ServerRecord*    pServer;
    RBLIST*                 rbList;
    MSTATUS                 status = OK;



    if (pInst->instRef > 0)
    {
        status = ERR_NTP_INSTANCE_REF_NOT_ZERO;
        goto exit;
    }
    /* Delete NTP Instance */
    pInst = (NTP_Instance *)rbdelete(pInst, gNTP_globals.instanceTree);

    if (pInst->serverTree)
    {
        if ((rbList = rbopenlist(pInst->serverTree)) == NULL)
        {
            status = ERR_MEM_ALLOC_FAIL;
            goto exit;
        }
        /* Delete all Attached servers */
        while ((pServer = (NTP_ServerRecord *)rbreadlist(rbList)))
        {
            ntp_serverDelete((sbyte4)pServer, pInst);
        }
        rbcloselist(rbList);
        rbdestroy(pInst->serverTree);
    }

    if(OK > (status = TIMER_destroyTimer(&pInst->reqTimeout)))
    {
        DEBUG_ERROR(DEBUG_CUSTOM, "NTP_deleleInstance: TIMER_destroyTimer() failed, status = ", status);
    }

    if (OK > (status = MBITMAP_clearIndex((bitmapDescr*)gNTP_globals.instanceIdMap, pInst->instanceId)))
    {
        DEBUG_ERROR(DEBUG_CUSTOM, "NTP_deleteInstance: MBITMAP_clearIndex fialed, status = ", status);
    }

    FREE(pInst);
    gNTP_globals.numInstances--;

exit:
    return status;
}


/*------------------------------------------------------------------*/
/*! Delete a virtual NTP %client instance.
This function deletes a virtual NTP %client instance (an instance previously
created by NTP_addInstance), including freeing all its resources.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param instanceId   Virtual instance ID previously returned by NTP_addInstance.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_deleteInstance(sbyte4 instanceId)
{
    MSTATUS status = OK;
    NTP_Instance *pInst;
    if(OK > (status = NTP_getInstancePtrFromId(instanceId, &pInst)))
    {
        return status;
    }
    return ntp_instanceDelete(pInst);

}


/*------------------------------------------------------------------*/
/*! Shut down the NTP stack and release memory associated with the NTP %client.
This function shuts down the NTP stack and releases all memory associated
with the NTP Client.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

*/
extern void
NTP_shutdown(void)
{
    NTP_Instance*    pInst;
    RBLIST*             rbList;

    RTOS_mutexWait(gNTP_globals.instanceTreeMutex);

    if (gNTP_globals.instanceTree)
    {

        if ((rbList = rbopenlist(gNTP_globals.instanceTree)) == NULL)
        {
            return;
        }
        /* Free all instances */
        while ((pInst = (NTP_Instance *)rbreadlist(rbList)))
        {
            pInst->instRef = 0;
            ntp_instanceDelete(pInst);
        }

        rbcloselist(rbList);
        rbdestroy(gNTP_globals.instanceTree);
    }

    /* Cleanup */
    MBITMAP_releaseMap((bitmapDescr**)&gNTP_globals.instanceIdMap);
    RTOS_mutexRelease(gNTP_globals.instanceTreeMutex);
    RTOS_mutexFree(&gNTP_globals.instanceTreeMutex);
}


/*----------------------------------------------------------------- */
static sbyte4
ntp_serverCompare (const void *p1,
                      const void *p2,
                      const void *config)
{
    NTP_ServerRecord* a = (NTP_ServerRecord *)p1;
    NTP_ServerRecord* b = (NTP_ServerRecord *)p2;
    sbyte4          compareResults = 0;
    MOC_UNUSED(config);

    if (a->serverAddress < b->serverAddress)
        compareResults = -1;
    else if (a->serverAddress > b->serverAddress)
        compareResults = 1;

    if (a->port < b->port)
        compareResults = -1;
    else if (a->port > b->port)
        compareResults = 1;

    /* If we have the Src addr Bound to the default Interface Ignore the
       Specific Interface */
    if (0 != b->srcAddr)
    {
        if (a->srcAddr < b->srcAddr)
            compareResults = -1;
        else if (a->srcAddr > b->srcAddr)
            compareResults = 1;
    }

    return compareResults;
}


/*------------------------------------------------------------------*/
static sbyte4
ntp_instanceCompare(const void *p1,
                       const void *p2,
                       const void *config)
{
    NTP_Instance    *inst1 = (NTP_Instance*)p1;
    NTP_Instance    *inst2 = (NTP_Instance*)p2;
    sbyte4             compareResults = 0;
    MOC_UNUSED(config);

    if (inst1->instanceId < inst2->instanceId)
        compareResults = -1;
    else if (inst1->instanceId > inst2->instanceId)
        compareResults = 1;

    return compareResults;
}


/*------------------------------------------------------------------*/
/* Verify that a packet contains a properly formatted NTP request.
This function verifies that a packet contains a properly formatted NTP
request, as specified by RFC&nbsp;1305.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param pPkt     Pointer to packet to verify.
\param pktLen   Number of bytes in pPkt.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
static MSTATUS
ntp_pktValidate(NtpPacket *pPkt, ubyte4 pktLen)
{
    MSTATUS status = ERR_NTP_BAD_RESPONSE;

    /* below, if fails, the worst is that the stats won't get incremented. */
    if (NTP_PKT_LEN != pktLen )
        goto exit;

    /* Check if the Xmit timestamp is not NULL */
    if(0 == pPkt->xmt.t_secs)
        goto exit;

    /* Make sure that the recv time is not 0 */
    if(0 == pPkt->rec.t_secs)
        goto exit;

    status = OK;

exit:
    return status;
}


/*------------------------------------------------------------------*/
/*! Validate a response message and return the corresponding original request.
This function validates a response message and returns the response's
corresponding original request.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param serverID ID of NTP server (returned by NTP_addServer).
\param srcPort  Response's UDP listen port field value.
\param pBuffer  Pointer to response data.
\param buflen   Number of bytes of response data ($pBuffer$).
\param pPkt     On return, pointer to response record containing the original
request and the validated response.
\param pResult  On return, pointer to one of the following $NTP_RESULT$ values:
$NTP_NOT_FOUND$ or $NTP_FOUND$. (None of the other $NTP_RESULT$ enumerated
values will be returned.)

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_responseCallback(sbyte4 serverID, ubyte2 srcPort,
                ubyte *pBuffer ,ubyte4 buflen,
                NtpPacket **pPkt, NTP_RESULT* pResult )
{
    NTP_RESULT               result = NTP_NOT_FOUND;
    NTP_ServerRecord*        pServer = NULL;
    MSTATUS                  status = OK;

    if (OK > (status = NTP_getServerRecordFromID(serverID, &pServer)))
        goto exit;

    if (0 < buflen)
    {
        if(NULL == pBuffer)
            goto exit;

        /* Get the reponse BUffer */
        *pPkt = (NtpPacket *)pBuffer;

        /* Validate to check if it is a VALID NTP packet */
        if (OK > (status = ntp_pktValidate(*pPkt, buflen)))
            goto exit;

        pServer->counters.rxGoodPacket++;

        result = NTP_FOUND;
   }

exit:
    *pResult = result;
    return status;
}


/*------------------------------------------------------------------*/
/*! Get the specified timestamp from an NTP response.
This function retrieves the specified timestamp from an NTP response; for
example, the originator timestamp, the server received timestamp, or the
server transmit timestamp.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param pPkt     Pointer to packet containing desired response.
\param attr     Type of timestamp to retrieve (an $NTP_RESP_ATTRIBUTE$
enumerated value, defined in ntp.h).
\param ntpTime  On return, pointer to desired timestamp.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_getAttribute(NtpPacket *pPkt, NTP_RESP_ATTRIBUTE attr, NtpTime *ntpTime)
{
    MSTATUS status = ERR_NTP_RESP_ATTRIB_NOT_FOUND;

    if((NULL != pPkt) && (NTP_RESP_ATTRIB_MAX <= attr))
        goto exit;

    switch(attr)
    {
        /* Get the Server Transmit Time */
        case NTP_RESP_ATTRIB_SVR_TX_TIME:
        {
            ntpTime->t_secs = pPkt->xmt.t_secs;
            ntpTime->t_msecs = pPkt->xmt.t_msecs;

            status = OK;
            break;
        }
         /* Time at which the NTP Server RECEIVED NTP Request */
        case NTP_RESP_ATTRIB_SVR_RX_TIME:
        {
            ntpTime->t_secs = pPkt->rec.t_secs;
            ntpTime->t_msecs = pPkt->rec.t_msecs;

            status = OK;
            break;
        }
        /* Time at which the NTP CLIENT Sent a NTP Request */
        case NTP_RESP_ATTRIB_ORG_TX_TIME:
        {
            ntpTime->t_secs = pPkt->org.t_secs;
            ntpTime->t_msecs = pPkt->org.t_msecs;

            status = OK;
            break;
        }
        default:
            break;
    }
exit:
    return status;
}


/*------------------------------------------------------------------*/
static void
ntp_timerCallBack(void *request, ubyte *type)
{
    NTP_RqstRecord   *pRqst  = (NTP_RqstRecord *) request;
    NTP_ServerRecord *pSrvr  = NULL;
    NTP_RqstRecord   *pTRqst = NULL;

    if (!pRqst)
    {
        goto exit;
    }

    pSrvr = (NTP_ServerRecord *)pRqst->serverID;

    if (!pSrvr)
    {
        goto exit;
    }

    pTRqst = pSrvr->pRequest;

    if (!pTRqst)
         goto exit;
    /* Looks like Timeout has expired. Send Indication to application */
    pSrvr->cfgPtr->funcPtrNtpInd(pTRqst->userCookie,
                             NTP_REQ_TIMEOUT,
                             pTRqst);
exit:
    return;
}


/*------------------------------------------------------------------*/
/*! Check an NTP client's timer to provide time to the NTP stack.
This function checks an NTP client's timer. Your application should call
this function on every clock tick (every 300 to 500 milliseconds) to provide
time to the NTP stack.

\since 3.06
\version 3.06 and later

! Flags
To enable this function, the following flag must be defined in moptions.h:
- $__ENABLE_MOCANA_NTP_CLIENT__$

#Include %file:#&nbsp;&nbsp;ntp.h

\param instanceId   Virtual instance ID previously returned by NTP_addInstance.

\return $OK$ (0) if successful; otherwise a negative number error code
definition from merrors.h. To retrieve a string containing an English text
error identifier corresponding to the function's returned error status, use the
$DISPLAY_ERROR$ macro.

*/
extern MSTATUS
NTP_periodic(sbyte4 instanceId)
{
    MSTATUS status = OK;
    NTP_Instance *pInst;

    if(OK == NTP_getInstancePtrFromId(instanceId, &pInst))
    {
        /* Tickle the Timer queue */
        TIMER_checkTimer(pInst->reqTimeout);
    }
    return status;
}

#endif /* __ENABLE_MOCANA_NTP_CLIENT__ */
