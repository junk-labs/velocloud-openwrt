#ifndef __FLAVOR_H__
#define __FLAVOR_H__

/* Map the build flavor into more meaningful constants internal
 * to the library.  The constant _FLAVOR_myflavor where myflavor is
 * the build flavor will be defined by the build environment.
 *
 * Be sure to check that a valid build flavor is defined.
 *
 * This file should be included by all source files.
*/

/* send an ARP request when entry times out */
#define ARP_REQ_ON_TIMEOUT
#define ARP_TIME_RETRY /*Descision to be made on if we want to push these flags into makefile or not*/
/*#define ARP_CACHE_32 , ucomment if Arp module wants to be compiled on a smaller foot print*/

#if defined(_FLAVOR_gn)
#define ARPMAX_IFNUM            NUM_IFS
#elif defined(_FLAVOR_gn1)
#define ARPMAX_IFNUM            1
#elif defined(_FLAVOR_gn2)
#define ARPMAX_IFNUM            2
#elif defined(_FLAVOR_gn3)
#define ARPMAX_IFNUM            3
#elif defined(_FLAVOR_gn4)
#define ARPMAX_IFNUM            4
#elif defined(_FLAVOR_gn5)
#define ARPMAX_IFNUM            5
#elif defined(_FLAVOR_gn6)
#define ARPMAX_IFNUM            6
#elif defined(_FLAVOR_gn7)
#define ARPMAX_IFNUM            7
#elif defined(_FLAVOR_gn8)
#define ARPMAX_IFNUM            8
#elif defined(_FLAVOR_gn9)
#define ARPMAX_IFNUM            9
#elif defined(_FLAVOR_gn10)
#define ARPMAX_IFNUM            10
#elif defined(_FLAVOR_gn11)
#define ARPMAX_IFNUM            11
#elif defined(_FLAVOR_gn12)
#define ARPMAX_IFNUM            12
#elif defined(_FLAVOR_gn13)
#define ARPMAX_IFNUM            13
#elif defined(_FLAVOR_gn14)
#define ARPMAX_IFNUM            14
#elif defined(_FLAVOR_gn15)
#define ARPMAX_IFNUM            15
#elif defined(_FLAVOR_gn16)
#define ARPMAX_IFNUM            16
#else
#  error Unknown Build Flavor
#endif

#endif
