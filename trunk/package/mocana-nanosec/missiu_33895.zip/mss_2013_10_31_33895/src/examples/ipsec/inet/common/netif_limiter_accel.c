/*
 * netif_limiter_accel.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netif_limiter.h"
#include "ethernet.h"
#include "ip.h"
#include "transportparser.h"

 /*
  * LONG NetIfLimiter(NETIFLIMITER *pxNetIfLimiter,DLLIST *pdllNetPacket)
  *
  * This function reordered and filters packet based on their priority
  *
  */

DWORD gdwNetIfLimiterLPPacketLost;
DWORD gdwNetIfLimiterPacketLost;
DWORD gdwNetIfLimiterPacketIn;
DWORD gdwNetIfLimiterHPPacketLost;
DWORD gdwNetIfLimiterVlanHP;
DWORD gdwNetIfLimiterToSHP;
DWORD gdwNetIfLimiterPortHP;

LONG NetIfLimiter(NETIFLIMITER *pxNetIfLimiter,DLLIST *pdllNetPacket)
{
  LONG lRv = 0;
  NETPACKET *pxNetPacket;
  E_PRIORITY ePriority;
  DLLIST *pdllNetPacketTmp = NULL;
  int i;
#ifdef __INET_USE_PKT_MEMPOOL__
   NETWRAPPERSTATE *pxNetWrapperState = NETGETWRAPPERSTATE(&xNetWrapper);
#endif

  ASSERT((pxNetIfLimiter != NULL) &&
         (pdllNetPacket != NULL) &&
         (pxNetIfLimiter->pfnNetPacketSortingMethod != NULL) &&
         (pxNetIfLimiter->dwPacketRx == 0) &&
         (pxNetIfLimiter->dwPacketRxMax != 0) &&
         (DLLIST_count_inline(&pxNetIfLimiter->dllNetPacketHP) == 0) &&
         (DLLIST_count_inline(&pxNetIfLimiter->dllNetPacketLP) == 0));

  DLLIST_head(pdllNetPacket);

  while((pxNetPacket = DLLIST_remove(pdllNetPacket)) != NULL){
    gdwNetIfLimiterPacketIn++;
    pxNetIfLimiter->dwPacketRx++;
    ePriority = pxNetIfLimiter->pfnNetPacketSortingMethod(pxNetPacket);
    switch(ePriority){
      case LOW_PRIORITY:
        pxNetIfLimiter->dwPacketRxLP++;
        if(pxNetIfLimiter->dwPacketRx > pxNetIfLimiter->dwPacketRxMax){
          /*When bHit is TRUE, netmain will stop reading packets for this run to let other process to run*/
          pxNetIfLimiter->bHit = TRUE;
          /*The packet is low priority AND the queue is full => bin it*/
          gdwNetIfLimiterLPPacketLost++;
          gdwNetIfLimiterPacketLost++;
          pxNetIfLimiter->dwPacketRx--;
          NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
#ifdef __INET_USE_PKT_MEMPOOL__
            /* printf("Release from NetPacketPool: pointer -> %x - NumUsed = %d\n", *pxNetPacket,
                  --(pxNetWrapperState->netPacketPoolUsed)); */

          pxNetWrapperState->netPacketPoolUsed--;
          MEM_POOL_putPoolObject(&pxNetWrapperState->netPacketPool, (void **)(&pxNetPacket));
#else
          FREE(pxNetPacket);
#endif
        } else {
          /*The packet is low priority AND the queue is not full => Add it to the LP queue*/
          DLLIST_append(&pxNetIfLimiter->dllNetPacketLP,pxNetPacket);
        }
        break;

      case HIGH_PRIORITY:
        pxNetIfLimiter->dwPacketRxHP++;

        if(pxNetIfLimiter->dwPacketRx > pxNetIfLimiter->dwPacketRxMax){
          /*The packet is high priority AND the queue is full :
            Remove LP packet if any and add the HP one, otherwise remove the HP packet*/
          pxNetIfLimiter->bHit = TRUE;
          if(DLLIST_count_inline(&pxNetIfLimiter->dllNetPacketLP) > 0){
            /*There is one LP packet to delete*/
            NETPACKET *pxNetPacketLP;
            DLLIST_head(&pxNetIfLimiter->dllNetPacketLP);
            pxNetPacketLP = DLLIST_remove(&pxNetIfLimiter->dllNetPacketLP);
            ASSERT(pxNetPacketLP != NULL);
            gdwNetIfLimiterLPPacketLost++;
            gdwNetIfLimiterPacketLost++;
            NETPAYLOAD_DELUSER(pxNetPacketLP->pxPayload);

#ifdef __INET_USE_PKT_MEMPOOL__
            /*printf("Release from NetPacketPool: pointer -> %x - NumUsed = %d\n", *pxNetPacketLP,
                  --(pxNetWrapperState->netPacketPoolUsed)); */
            pxNetWrapperState->netPacketPoolUsed--;
            MEM_POOL_putPoolObject(&pxNetWrapperState->netPacketPool, (void **)(&pxNetPacketLP));
#else
            FREE(pxNetPacketLP);
#endif
          }

        }
        /* Always pass high priority packets. */
        /* This leaves us vulnerable to attacks using packets marked */
        /* as high priority. We may need to revert to the old practice of */
        /* tossing HP packets when we reach the packet limit. */
        DLLIST_append(&pxNetIfLimiter->dllNetPacketHP,pxNetPacket);

        break;

      default:
        ASSERT(0);
    }
  }

  /*Remove any remaining packet */
  while ((pxNetPacket = DLLIST_remove(pdllNetPacket)) != NULL){
    gdwNetIfLimiterPacketIn++;
    gdwNetIfLimiterPacketLost++;
    NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
#ifdef __INET_USE_PKT_MEMPOOL__
    /* printf("Release from NetPacketPool: pointer -> %x - NumUsed = %d\n", *pxNetPacket,
                       --(pxNetWrapperState->netPacketPoolUsed)); */
    pxNetWrapperState->netPacketPoolUsed--;
    MEM_POOL_putPoolObject(&pxNetWrapperState->netPacketPool, (void **)(&pxNetPacket));
#else
    FREE(pxNetPacket);
#endif
  }

  ASSERT(DLLIST_count_inline(pdllNetPacket) == 0);

  for(i = 0; i < 2; i++){
    i == 0 ? (pdllNetPacketTmp = &pxNetIfLimiter->dllNetPacketHP) :
             (pdllNetPacketTmp = &pxNetIfLimiter->dllNetPacketLP);

    DLLIST_head(pdllNetPacketTmp);
    while ((pxNetPacket = DLLIST_remove(pdllNetPacketTmp)) != NULL){
      DLLIST_append(pdllNetPacket,(pxNetPacket));
    }
  }

  pxNetIfLimiter->dwPacketRx   = 0;

  return lRv;
}

/*
 *
 * E_PRIORITY NetPacketSortByVlan(NETPACKET *pxNetPacket)
 *
 * Depending on the Vlan priority, it return either HIGH_PRIORITY or LOW_PRIORITY
 */

E_PRIORITY NetPacketDefaultSortingMethod(NETPACKET *pxNetPacket)
{
  NETWRAPPER      *pxWrapper = NETGETWRAPPER;
  NETIFLIMITER    *pxNetIfLimiter;
  WORD             wOffset;
  ETH_VLAN_HEADER *pxEthVlanHeader;
  IPHDR           *pxIpHdr;
  /*void            *pvTransportHdr; */
  E_PRIORITY      ePriority = LOW_PRIORITY;
  OCTET           *poPayload;

  NETMAIN_ASSERT(pxWrapper != NULL);
  NETPACKET_CHECK(pxNetPacket);

  pxNetIfLimiter = NETGETLIMITER(pxWrapper);
  NETMAIN_ASSERT(pxNetIfLimiter != NULL);

  /* Set offset to point to the beginning of the ethernet header*/
  poPayload       = pxNetPacket->pxPayload->poPayload;
  wOffset         = pxNetPacket->wOffset;
  pxEthVlanHeader = (ETH_VLAN_HEADER*)(poPayload + wOffset);

  /*
   * Vlan filtering
   */

  if(pxNetIfLimiter->bVlan == TRUE){
    if((pxEthVlanHeader->wVlanType == ETHID_VLAN) &&
       ((OCTET)(pxEthVlanHeader->wVlan & ETHPRI_MASK >> ETHPRI_SHIFT) >
        pxNetIfLimiter->oVlanValue)){
      gdwNetIfLimiterVlanHP++;
      pxNetPacket->oPriority = HIGH_PRIORITY;
      return HIGH_PRIORITY;
    }
  }

  /* Ajust offset to point to the beginning of the ip header*/
  pxEthVlanHeader->wVlanType == ETHID_VLAN ?
    (wOffset += sizeof(ETH_VLAN_HEADER)) : (wOffset += sizeof(ETH_HEADER));
  pxIpHdr = (IPHDR*)((poPayload + wOffset));

  /*
   * ToS filtering
   */

  if(pxNetIfLimiter->bToS == TRUE){
    if((pxEthVlanHeader->wVlanType == ETHID_IP) ||
       ((pxEthVlanHeader->wVlanType == ETHID_VLAN) && (pxEthVlanHeader->wType == ETHID_IP))){
      if(pxIpHdr->oToS & pxNetIfLimiter->oToSMask){
        gdwNetIfLimiterToSHP++;
        pxNetPacket->oPriority = HIGH_PRIORITY;
        return HIGH_PRIORITY;
      }
    }
  }

  /*
   * Port Filtering
   */
  #if 0

  if(pxNetIfLimiter->bPortRange == TRUE){
    WORD wDstPort;
    PORT_RANGE *pxPortRange;

    pvTransportHdr = (void*)((OCTET*)pxIpHdr + ((pxIpHdr->oIpHdrLen & 0x0F)<<2));
    wDstPort = TRANSPORT_GET_DST_PORT(pvTransportHdr);

    DLLIST_head(&pxNetIfLimiter->dllPortRange);
    while((pxPortRange = DLLIST_read(&pxNetIfLimiter->dllPortRange)) != NULL){
      if((wDstPort >= pxPortRange->wPortMin) && (wDstPort <= pxPortRange->wPortMax)){
        gdwNetIfLimiterPortHP++;
        pxNetPacket->oPriority = HIGH_PRIORITY;
        return HIGH_PRIORITY;
      }
      DLLIST_next(&pxNetIfLimiter->dllPortRange);
    }
  }
  #endif
  return ePriority;

}

