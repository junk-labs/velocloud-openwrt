#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void *DLLIST_read(DLLIST *pdllist)
{
  ASSERT(pdllist != NULL);
  
  if((pdllist != NULL) && (pdllist->cur != NULL)){
    return(pdllist->cur->item);
  } else {
   return(NULL);
  }
}

