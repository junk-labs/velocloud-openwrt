#ifndef __PROTUTIL_H__
#define __PROTUTIL_H__
#include <dllist.h>
typedef unsigned char H_PROTOCOL_INSTANCE 

#endif
