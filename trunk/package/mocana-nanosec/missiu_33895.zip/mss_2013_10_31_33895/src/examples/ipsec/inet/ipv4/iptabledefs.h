/*
 * iptabledefs.h
 *
 * IP table internal API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _IPTABLEDEFS_H_
#define _IPTABLEDEFS_H_

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/


typedef struct {
  /* Entries. flatly organized.
     We may want to hash them at one point for efficiency, if
     that proves critical */

  IPTABLEREPOSITORY xIpRepository;

#ifdef IPTABLE_MCAST
  /* No multicast support here - filtering in UDP */
  IPTABLEREPOSITORY xMcastRepository;
#endif

#ifdef IPTABLE_PPP
  IPTABLEREPOSITORY xPppRepository;
#endif
} IPTABLESTATE;


/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/


/*
 * IpTableMatch
 *  returns TRUE if the entries match, FALSE otherwise
 *
 *  Args:
 *   pxEntry1                 1st entry
 *   pxEntry2                 2nd entry
 *
 *  Return:
 *   TRUE==match. FALSE==don't match
 */
BOOL IpTableMatch(IPTABLEENTRY *pxEntry1,IPTABLEENTRY *pxEntry2);


/*
 * IpTableRepositoryFindDefault
 *  Find the default entry corresponding to the template
 *
 *  Args:
 *   pxRepository           repository
 *   pxTemplate             entry template
 *
 *  Return:
 *   pointer to the entry in the table
 */
IPTABLEENTRY *IpTableRepositoryFindDefault(IPTABLEREPOSITORY *pxRepository,
                                           IPTABLEENTRY *pxTemplate);

/*
 * IpTableGetAddrType
 *  Returns the entry addr type as defined in IPADDR_
 *
 *  Args:
 *   pxEntry                  entry
 *
 *  Return:
 *   IPADDR_ type
 */
LONG IpTableGetAddrType(IPTABLEENTRY *pxEntry);



#ifndef IPTABLE_SINGLEIF
/*
 * IpTableGetIfIdx
 *  Returns the interface index corresponding to the given
 *  address.
 *
 *  Args:
 *   pxEntry                  entry
 *
 *  Return:
 *   Interface index.
 */
LONG IpTableGetIfIdx(IPTABLEENTRY *pxEntry);

#endif /* #ifndef IPTABLE_SINGLEIF */

/*****************************************************************************
 *
 * MOC_EXTERN variables
 *
 *****************************************************************************/

/*
 * Ip Table
 */
MOC_EXTERN IPTABLESTATE xIpTable;


#endif /* #ifndef _IPTABLEDEFS_H_ */

