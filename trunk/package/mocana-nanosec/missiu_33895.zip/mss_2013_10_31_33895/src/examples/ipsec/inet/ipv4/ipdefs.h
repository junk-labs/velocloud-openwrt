/*
 * ipdefs.h
 *
 * IP module common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __IPDEFS_H__
#define __IPDEFS_H__

#define N_MAXNETINTERFACES 9 /* Should be pan net define */

/*****************************************************************************
 *
 * Structures & Typedefs
 *
 *****************************************************************************/

typedef struct {
  WORD wRoutingId;
  H_NETINSTANCE hUL;
  H_NETINTERFACE hIf;

  PFN_NETRXCBK pfnRxCbk;

} IP_UL;

/*
 * IP instance structure
 */
typedef struct {
  /* Basic structure override protection */
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

  /* Network callback */
  PFN_NETCBK pfnNetCbk;

  /* UL modules */
  IP_UL *pxUl;
  OCTET oUlNumber;

  /* LL interface stuff */
  H_NETINSTANCE hLL;
  PFN_NETWRITE  pfnLLWrite;
  H_NETINTERFACE hIPLLIf;

} IPSTATE;


#endif /* #ifndef __IPDEFS_H__ */
