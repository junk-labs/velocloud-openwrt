/*
 * ipdbg.h
 *
 * IP module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IPDBG_H_
#define _IPDBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef IPDBG_HI
   #define IPDBG_HI
  #endif
 #endif

#else
 #ifdef IPDBG_HI
  #undef IPDBG_HI
 #endif
 #ifdef NETDBG_HI
   #undef NETDBG_HI
 #endif
#endif

#include "netdbg.h"

#define IP_MAGIC_COOKIE 0x69700000 /*"ip" = 0x69700000*/

/*#ifdef IPDBG_HI*/
#if defined(IPDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define IP_CHECK_STATE(x) \
            ASSERT((x) && ((x)->dwMagicCookie == IP_MAGIC_COOKIE));

  #define IP_SET_COOKIE(x) (x)->dwMagicCookie = IP_MAGIC_COOKIE
  #define IP_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define IP_DBGP(level, fmt, args...) do { \
    if (level <= g_dwIpDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define IP_DBG(level, x) do {  \
    if (level <= g_dwIpDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define IP_DBG_VAR(x)  x

  #define IP_CHECKPOINT(x) (x = __LINE__)
#else
  #define IP_CHECK_STATE(x)
  #define IP_SET_COOKIE(x)
  #define IP_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define IP_DBGP
#else
  #define IP_DBGP(level, fmt, args...)
#endif
  #define IP_DBG(level, x)
  #define IP_DBG_VAR(x)
  #define IP_CHECKPOINT(x)
#endif

IP_DBG_VAR(MOC_EXTERN DWORD g_dwIpDebugLevel);

#define ERROR 1
#define NORMAL 2
#define REPETITIVE 3

#endif /* #ifndef _IPDBG_H_ */
