#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void *DLLIST_remove(DLLIST *dllist)
{
  DLLIST_ITEM *tmp;
  tmp = DLLIST_remove_ITEM(dllist, dllist->cur);
  if (tmp == NULL)
    return tmp;
  else
    return tmp->item;
}

