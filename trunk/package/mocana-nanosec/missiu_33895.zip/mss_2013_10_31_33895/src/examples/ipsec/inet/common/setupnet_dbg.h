/*
 * setupnet_dbg.h
 *
 * setupnet module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _SETUPNETDBG_H_
#define _SETUPNETDBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef SETUPNETDBG_HI
   #define SETUPNETDBG_HI
  #endif
 #endif

#else
 #ifdef SETUPNETDBG_HI
  #undef SETUPNETDBG_HI
 #endif
#endif

#include "netdbg.h"


/*#ifdef SETUPNETDBG_HI*/
#if defined(SETUPNETDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define SETUPNET_DBGP(level, fmt, args...) do { \
    if (level <= g_dwSetupNetDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define SETUPNET_DBG(level, x) do {  \
    if (level <= g_dwSetupNetDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define SETUPNET_DBG_VAR(x)  x

#else
#if defined (__VXWORKS_RTOS__)
  #define SETUPNET_DBGP
#else
  #define SETUPNET_DBGP(level, fmt, args...)
#endif
  #define SETUPNET_DBG(level, x)
  #define SETUPNET_DBG_VAR(x)
#endif

SETUPNET_DBG_VAR(MOC_EXTERN DWORD g_dwSetupNetDebugLevel);

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _SETUPNETDBG_H_ */
