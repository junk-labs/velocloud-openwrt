/*
 * icmp_dbg.h
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __ICMP_DBG_H__
#define __ICMP_DBG_H__

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef ICMPDBG_HI
   #define ICMPDBG_HI
  #endif
 #endif

#else
 #ifdef ICMPDBG_HI
  #undef ICMPDBG_HI
 #endif
#endif

#include "netdbg.h"

#define ICMP_MAGIC_COOKIE 0x69676d70 /*"icmp" = 0x69636d70*/

/*#ifdef ICMPDBG_HI*/
#if defined(ICMPDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define ICMP_CHECK_STATE(x) \
            ASSERT((x) && ((x)->dwMagicCookie == ICMP_MAGIC_COOKIE));

  #define ICMP_SET_COOKIE(x) (x)->dwMagicCookie = ICMP_MAGIC_COOKIE
  #define ICMP_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define ICMP_DBGP(level, fmt, args...)    do {    \
    if (level <= g_dwIcmpDebugLevel) {        \
      printf(fmt, ##args);                \
    }                            \
  } while (0)

  #define ICMP_DBG(level, x)    do {        \
    if (level <= g_dwIcmpDebugLevel) {        \
      x;                        \
    }                            \
  } while (0)

  #define ICMP_DBG_VAR(x)  x

#else
  #define ICMP_CHECK_STATE(x)
  #define ICMP_SET_COOKIE(x)
  #define ICMP_UNSET_COOKIE(x)
#if defined (__RTOS_VXWORKS__)
  #define ICMP_DBGP
#else
  #define ICMP_DBGP(level, fmt, args...)
#endif
  #define ICMP_DBG(level, x)
  #define ICMP_DBG_VAR(x)
#endif

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /*#ifndef __ICMP_DBG_H__*/
