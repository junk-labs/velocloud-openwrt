/*
 * netif_limiter_accel.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netif_limiter.h"

/****************************************************************************
 *
 * Localfunction
 *
 ****************************************************************************/

LONG _NetIfLimiterFindPortRange(void *pvPortRange, void *pvPortRangeToMacth);

/****************************************************************************
 *
 * NetIfLimiterInitialize
 *
 ****************************************************************************/

LONG NetIfLimiterInitialize(NETIFLIMITER *pxNetIfLimiter)
{
  NETMAIN_ASSERT(pxNetIfLimiter != NULL);

  MOC_MEMSET((ubyte *)pxNetIfLimiter,0,sizeof(NETIFLIMITER));

  pxNetIfLimiter->pfnNetPacketSortingMethod = NetPacketDefaultSortingMethod;
  pxNetIfLimiter->dwPacketRxMax = PACKET_RX_MAX;
  pxNetIfLimiter->bVlan = FALSE;
  pxNetIfLimiter->bToS  = FALSE;
  pxNetIfLimiter->bPortRange = TRUE;
  pxNetIfLimiter->oVlanValue = NETVLAN_PRIORITY_LIMIT;
  pxNetIfLimiter->oToSMask   = NETTOS_PRIORITY_MASK;

  return 0;
}

/****************************************************************************
 *
 * NetIfLimiterTerminate
 *
 ****************************************************************************/

LONG NetIfLimiterTerminate(NETIFLIMITER *pxNetIfLimiter)
{
  NETMAIN_ASSERT(pxNetIfLimiter != NULL);

  clear_DLLIST(&pxNetIfLimiter->dllPortRange,NetFree);
  return 0;
}

/****************************************************************************
 *
 * NetIfLimiterSet
 *
 ****************************************************************************/

LONG NetIfLimiterSet(OCTET oOption,H_NETDATA hData)
{
  LONG lRv = 0;
  NETWRAPPER   *pxWrapper = NETGETWRAPPER;
  NETIFLIMITER *pxNetIfLimiter;

  NETMAIN_ASSERT(pxWrapper != NULL);

  pxNetIfLimiter = NETGETLIMITER(pxWrapper);
  NETMAIN_ASSERT(pxNetIfLimiter != NULL);

  /* NETMAIN_DBGP(NORMAL,"NetIfLimiterSet option = %d, value = %d\n",
                                oOption,(int)hData); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,
                            "NetIfLimiterSet option = ",oOption,
                            ", value = ",(int)hData);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  switch(oOption) {
   case NETIFLIMITEROPTION_VLAN_ENABLE:
     pxNetIfLimiter->bVlan      = (BOOL)hData;
     break;
   case NETIFLIMITEROPTION_VLAN_VALUE:
     pxNetIfLimiter->oVlanValue = (OCTET)hData;
     break;
   case NETIFLIMITEROPTION_TOS_ENABLE:
     pxNetIfLimiter->bToS       = (BOOL)hData;
     break;
   case NETIFLIMITEROPTION_TOS_MASK:
     pxNetIfLimiter->oToSMask   = (OCTET)hData;
     break;
   case NETIFLIMITEROPTION_PORT_ENABLE:
     pxNetIfLimiter->bPortRange = (BOOL)hData;
     break;
   case NETIFLIMITEROPTION_PORT_ADD:
     {
       PORT_RANGE *pxPortRange = (PORT_RANGE *)MALLOC(sizeof(PORT_RANGE));
       NETMAIN_ASSERT(pxPortRange != NULL);
       MOC_MEMCPY((ubyte *)pxPortRange,(ubyte *)hData,sizeof(PORT_RANGE));
       (void*)DLLIST_append(&pxNetIfLimiter->dllPortRange,(void*)pxPortRange);
       break;
     }
   case NETIFLIMITEROPTION_PORT_REMOVE:
     {
       PORT_RANGE *pxPortRange;
       pxPortRange = DLLIST_find(&pxNetIfLimiter->dllPortRange,
                                 (void*)hData,
                                 _NetIfLimiterFindPortRange);
       if(pxPortRange != NULL){
         DLLIST_remove(&pxNetIfLimiter->dllPortRange);
         FREE(pxPortRange);
       } else {
         ASSERT(0);
         lRv = -1;
       }
       break;
     }
   default:
     NETMAIN_ASSERT(0);
     lRv = -1;
  }

  return lRv;
}

/****************************************************************************
 *
 * NetIfLimiterProcess(NETIFLIMITER *pxNetIfLimiter)
 *
 ****************************************************************************/

LONG NetIfLimiterProcess(NETIFLIMITER *pxNetIfLimiter)
{
  NETMAIN_ASSERT(pxNetIfLimiter != NULL);

  /*Limit the number of packet that can be sent up*/
  if(pxNetIfLimiter->dwPacketRxHP == 0){
    if(pxNetIfLimiter->dwPacketRxMax != PACKET_RX_MAX){
      /*No HP packet has been received => increment the oNoPacketHPRx counter*/
      pxNetIfLimiter->oNoPacketHPRx++;
      if(pxNetIfLimiter->oNoPacketHPRx > 100){
        /*No HP packet has been received for 500 ms => limit the number of packet to PACKET_RX_MAX*/
          /*printf("NetMain: no high priority packet has been reveived for 100ms\n"); */
          pxNetIfLimiter->dwPacketRxMax = PACKET_RX_MAX;
      }
    }
  } else {
    /*HP packet has been received => limit the number of packet to PACKET_RX_MIN*/
    pxNetIfLimiter->oNoPacketHPRx = 0;
    if(pxNetIfLimiter->dwPacketRxMax != PACKET_RX_MIN){
      /*printf("NetMain: received high priority packet\n"); */
      pxNetIfLimiter->dwPacketRxMax = PACKET_RX_MIN;

    }
  }

  pxNetIfLimiter->dwPacketRxHP = 0;
  pxNetIfLimiter->bHit = FALSE;

  return (LONG)0;
}


/****************************************************************************
 *
 * NetIfLimiterFindPortRange
 *
 ****************************************************************************/

LONG _NetIfLimiterFindPortRange(void *pvPortRange, void *pvPortRangeToMatch)
{
  PORT_RANGE *pxPortRange = (PORT_RANGE*)pvPortRange;
  PORT_RANGE *pxPortRangeToMatch = (PORT_RANGE*)pvPortRangeToMatch;

  if((pxPortRange->wPortMin == pxPortRangeToMatch->wPortMin) &&
     (pxPortRange->wPortMax == pxPortRangeToMatch->wPortMax)){
    return 0;
  } else {
    return -1;
  }
}
