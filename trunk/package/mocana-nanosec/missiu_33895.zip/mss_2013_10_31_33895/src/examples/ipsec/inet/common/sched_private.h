/*
 * sched_private.h
 *
 * scheduler stuff (internal)
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __SCHED_PRIVATE_H__
#define __SCHED_PRIVATE_H__




/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

#include "NNstyle.h"
#include "cllist.h"
#include "xstat.h"
#include "scheduler.h"


/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Typedefs
 *
 ********************************************************************/

#if defined(SCHED_STATS)
/*
 * Priority Change record
 */
#define MAX_PRIORITY_CHANGE_ENTRIES 16    /* this may need to be larger */
typedef struct {
  DWORD dwLine;        /* line # of SchedSetPriority() call */
  OCTET *pFile;        /* ptr to filename containing SchedSetPriority() call*/
  E_SCHED_PRIORITY ePriority;    /* the priority in SchedSetPriority() call */
  DWORD dwTotal;    /* total # of this priority change made */
  DWORD adwLastHistogram[MAX_PRIORITY_CHANGE_ENTRIES];
            /* histogram of the previous priority change index */
} PRIORITY_CHANGE;

/*
 * Priority change history
 */
#define NO_LAST_PRIORITY ((DWORD) -1)    /* for use in dwLast */
typedef struct {
  PRIORITY_CHANGE axChange[MAX_PRIORITY_CHANGE_ENTRIES];
  DWORD dwLast;            /* index of most recent priority change entry */
} PRIORITY_CHANGE_HISTORY;



/*
 * Process Resource Stats
 */
typedef struct {
  /* registration info */
  DWORD dwNumReasons;            /* # of return reasons              */
  CHAR **pszReasonNames;        /* reason name array              */
  DWORD dwNumResources;            /* # of resources              */
  CHAR **pszResourceNames;        /* resource name array              */
  DWORD *adwMaxResourceLevels;        /* max level array              */

  /* process entry stats */
  XSTAT *axEntryResourceStats;        /* resource lvl stats (malloc)        */

  /* process return stats */
  DWORD dwTotalReturns;            /* total # of returns              */
  XSTAT *axReturnResourceStats;        /* resource lvl stats (malloc)        */
  DWORD *adwReasonHistogram;        /* return reason histogram (malloc)   */
} PROCESS_RESOURCE_STATS;

#endif


/*
 * schedule user structure
 */
typedef struct SCHED_USER {
  struct SCHEDULER *pScheduler;        /* scheduler instance        */
  struct SCHED_USER *pNext;        /* next schedule        */
  struct SCHED_USER *pPrev;        /* prev schedule        */
  E_SCHED_PRIORITY ePriority;        /* OFF = disabled        */
  DWORD dwDelayStart;            /* clock at delay start        */
  DWORD dwDelay;            /* # ticks from start to delay    */
  DWORD fFlags;                /* flags            */
  void *hInstance;            /* user' handle            */
  SCHED_PROCESS Process;        /* user Process() to call    */
  DWORD dwMagic;            /* magic # for valid schedules    */
#if defined(SCHED_STATS)
  CHAR *szName;                /* name of the sched user    */
  XSTAT xInProcess;            /* Process() calling stats    */
  PRIORITY_CHANGE_HISTORY xPriorityHistory; /* history of pri changed   */
  PROCESS_RESOURCE_STATS xProcResourceStats; /* process resource stats    */
#endif
} SCHED_USER;

#define SCHED_USER_MAGIC 0x12345678

/* fFlags definitions */
#define SCHED_USER_DELAY    0x00000001    /* delay not yet expired      */
#define SCHED_USER_CAN_RELEASE    0x00000002    /* can release               */
#define SCHED_USER_DO_RELEASE    0x00000004    /* do release               */

/* circular list of scheduler users     */
typedef CLLIST(SCHED_USER) L_SCHED_USERS;



/*
 * scheduler structure
 */
typedef struct SCHEDULER {
  struct SCHEDULER *pNext;        /* next scheduler instance    */
  struct SCHEDULER *pPrev;        /* prev scheduler instance    */
  L_SCHED_USERS lstUsers;        /* scheduler users list        */
  SCHED_USER *pActiveUser;        /* current running user        */
  H_SCHED_USER hSuperSchedUser;        /* this schedulers user handle    */
                    /*  if nested in a super schedlr*/
  DWORD dwDelayThreshold;        /* return threshold for delays    */
  DWORD fFlags;                /* flags            */
  E_SCHED_PRIORITY eCurrPriority;    /* currently active priority    */
  OCTET aoPriorityCnt[SCHED_PRIORITY_ENUMMAX];
                    /* # users at each priority    */
  DWORD dwMagic;            /* magic # for valid schedulers    */
#if defined(SCHED_STATS)
  XSTAT xSchedOverhead;            /* time in this sched but not     */
                    /*  in user process        */
#endif
} SCHEDULER;

#define SCHEDULER_MAGIC 0x81234567

/* fFlags definitions */
#define SCHEDULER_RAISED_PRIORITY    0x00000001    /* some user paniced  */
#define SCHEDULER_SWEEP_ABORT        0x00000002    /* not full sweep     */
#define SCHEDULER_SWEEP_PRIORITY_OFF    0x00000004    /* all OFF in sweep   */


/* circular list of schedulers     */
typedef CLLIST(SCHEDULER) L_SCHEDULER;



/********************************************************************
 *
 * globals
 *
 ********************************************************************/

/* none */




#endif    /* __SCHED_PRIVATE_H__ */
