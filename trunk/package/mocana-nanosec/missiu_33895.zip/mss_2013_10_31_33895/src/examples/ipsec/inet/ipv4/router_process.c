/*
 * router_process.c
 *
 * router Rx Process function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/
#include "router.h"
#include "router_defs.h"

/*****************************************************************************
 *
 * debug
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * RouterInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hRouter                 Router Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG RouterInstanceProcess(H_NETINSTANCE hRouter)
{
  ROUTER_CHECK_STATE((ROUTERSTATE*) hRouter);

  /* Nothing to do here - indicate as such */
  return 0x7FFFFFFF;
}

