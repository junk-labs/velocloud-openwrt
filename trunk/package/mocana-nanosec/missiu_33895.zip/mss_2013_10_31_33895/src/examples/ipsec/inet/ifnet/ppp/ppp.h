/*
 * ppp.h
 *
 * PPP main API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _PPP_H_
#define _PPP_H_

/*****************************************************************************
 *
 * defines
 *
 *****************************************************************************/

/*
 * PPP header length
 */
#define PPPDEFAULT_HDRLEN       2
#define PPPPPTP_HDRLEN          4

/*
 * PPP tunnel modes
 */
#define PPPTUNNELMODE_NONE        0
#define PPPTUNNELMODE_PPTP        1

/*
 * PPP Protocol Ids
 */
#define PPPID_NONE              0x0000
#define PPPID_LCP               0xC021
#define PPPID_IPCP              0x8021
#define PPPID_IP                0x21
#define PPPID_CHAP              0xC223
#define PPPID_PAP               0xC023
#define PPPID_EAPTLS            0xC227


/*
 * PPP option default values
 */
#define PPPDEFAULT_MRU       1500
#define PPPDEFAULT_AP        PPPID_NONE
#define PPPDEFAULT_LQP       PPPID_NONE
#define PPPDEFAULT_MN        FALSE
#define PPPDEFAULT_ACFC      FALSE
#define PPPDEFAULT_PFC       FALSE

#define PPPDEFAULT_TUNNELMODE PPPTUNNELMODE_NONE

#define PPPDEFAULT_IDLETO              3600000   /* 1h in ms */
#define PPPIDLETO_NONE                 0         /* 0 means no timeout */

#define PPPDEFAULT_ECHOTO              60000     /* 60s in ms */
#define PPPECHOTO_NONE                 0         /* 0 means no timeout */
#define PPPECHOTO_COUNT                3         /* Close after 3x no response */


/*
 * PPP specific options
 *  Note: the chosen local and remote AP (authentification Protocol)
 *  and LQP (Link Quality protocol) should be set here and registered
 *  as UL interfaces.
 *  If the local AP is set, it is not negociable. The remote one will
 *  be negociable amongst the registered ULs. LQPs are always
 *  negociable amongst the registered UL
 */
#define PPPOPTION_LOCALMRU \
 (NETOPTION_MODULESPECIFICBEGIN)       /* local MTU size. data is WORD */
#define PPPOPTION_REMOTEMRU \
  (NETOPTION_MODULESPECIFICBEGIN +1)   /* remote MTU size. data is WORD */

#define PPPOPTION_LOCALAP \
 (NETOPTION_MODULESPECIFICBEGIN +2)    /* local AP. data is WORD
                                          (protocol Id) */
#define PPPOPTION_REMOTEAP \
 (NETOPTION_MODULESPECIFICBEGIN +3)    /* local. data is WORD
                                          (protocol Id) */

#define PPPOPTION_LOCALLQP \
 (NETOPTION_MODULESPECIFICBEGIN +4)    /* local. data is WORD
                                          (protocol Id) */
#define PPPOPTION_REMOTELQP \
 (NETOPTION_MODULESPECIFICBEGIN +5)    /* local. data is WORD
                                          (protocol Id) */

#define PPPOPTION_LOCALMAGICNUMBER \
 (NETOPTION_MODULESPECIFICBEGIN + 6)   /* local Magic Number. Data is BOOL */
#define PPPOPTION_REMOTEMAGICNUMBER \
 (NETOPTION_MODULESPECIFICBEGIN + 7)   /* local Magic Number. Data is BOOL */

#define PPPOPTION_LOCALACFC \
 (NETOPTION_MODULESPECIFICBEGIN + 8)   /* Address Field Compression. Data
                                          is  BOOL */
#define PPPOPTION_REMOTEACFC \
 (NETOPTION_MODULESPECIFICBEGIN + 9)   /* Address Field Compression. Data
                                          is  BOOL */
#define PPPOPTION_LOCALPFC \
 (NETOPTION_MODULESPECIFICBEGIN + 10)   /* Protocol Field Compression. Data is
                                           BOOL */
#define PPPOPTION_REMOTEPFC \
 (NETOPTION_MODULESPECIFICBEGIN + 11)   /* Protocol Field Compression. Data is
                                           BOOL */

#define PPPOPTION_TUNNELMODE \
 (NETOPTION_MODULESPECIFICBEGIN + 12)   /* Tunneling mode */
#define PPPOPTION_IFIDX \
 (NETOPTION_MODULESPECIFICBEGIN + 13)   /* phy if idx. data is octet */
#define PPPOPTION_VLAN \
 (NETOPTION_MODULESPECIFICBEGIN + 14)   /* VLAN. data is WORD */
#define PPPOPTION_RETRANSMISSIONTIMER \
 (NETOPTION_MODULESPECIFICBEGIN + 15)   /* Passed to LCP. Data is DWORD */
#define PPPOPTION_MAXCONFRETRIES \
 (NETOPTION_MODULESPECIFICBEGIN + 16)   /* Passed to LCP. Data is OCTET */
#define PPPOPTION_MAXTERMRETRIES \
 (NETOPTION_MODULESPECIFICBEGIN + 17)   /* Passed to LCP. Data is OCTET */
#define PPPOPTION_IDLETO         \
  (NETOPTION_MODULESPECIFICBEGIN + 18)  /* Idle TO value, in ms. data is
                                           a DWORD */
#define PPPOPTION_ECHOTO         \
  (NETOPTION_MODULESPECIFICBEGIN + 19)  /* Echo TO value, in ms. data is
                                           a DWORD */
#define PPPOPTION_ECHOCOUNT      \
  (NETOPTION_MODULESPECIFICBEGIN + 20)  /* Echo count value, data is
                                           a DWORD */
#define PPPOPTIONMAX 21

/*
 * PPP specific messages
 */
#define PPPMSG_AUTHSUCCESS \
 (NETMSG_MODULESPECIFICBEGIN)        /* Authentification success */
#define PPPMSG_AUTHFAILURE \
 (NETMSG_MODULESPECIFICBEGIN + 1)    /* Authentification failure */

/*
 * PPP specific callbacks
 */
#define PPPCBK_IDLETO               \
 (NETCBK_MODULESPECIFICBEGIN)              /* No traffic has been received
                                              for the given TO. The client
                                              stays open: it is up to
                                              the management to close it */
#define PPPCBK_TRAFFICDETECTED     \
 (NETCBK_MODULESPECIFICBEGIN +1)           /* Traffic has been detected,
                                              but the client is closed.  */
#define PPPCBK_AUTHENTICATECONF    \
 (NETCBK_MODULESPECIFICBEGIN +2)           /* Rx Authentification conf.
                                              Data is PPPOPTIONFIELD *. <0
                                              return code will be interpreted
                                              as a rejection */
#define PPPCBK_AUTHENTICATE        \
 (NETCBK_MODULESPECIFICBEGIN +3)           /* Need authentification.
                                              data is WORD (protocol id */

#define PPPCBK_CHANGEMTU        \
 (NETCBK_MODULESPECIFICBEGIN +4)           /* Need to change MTU.
                                              data is WORD (size) */

#define PPPCBK_ECHOTO        \
 (NETCBK_MODULESPECIFICBEGIN +5)           /* No echo responses have been received
                                              for the given TO. Up to the manager
                                              to close it. */
#define PPPCBKMAX 6
/*
 * PPP UL Ioctls
 *  Are covered in netcommon.h. the OPEN ioctl effectively starts
 *  the traffic for a UL interface.
 *  In particular, in the IP case: IPCP should be opened to allow
 *  any negociation, and the IP one should be opened when IPCP
 *  succeeds. PPP itself has no knowledge of the IP/IPCP control
 *  relationship.
 */
/***************************************************************************
 *
 * extern
 *
 ***************************************************************************/
#ifndef NDEBUG
MOC_EXTERN const OCTET *apoPppCbkString[PPPCBKMAX];
#endif
/***************************************************************************
 *
 * Typedefs
 *
 ***************************************************************************/

typedef struct {
  WORD wProtocolId;
  WORD wFieldLength;
  OCTET *poField;
} PPPOPTIONFIELD;

/***************************************************************************
 *
 * API functions
 *
 ***************************************************************************/

/*
 * PppInitialize
 *   PPP main library initialization.
 *
 *   Args:
 *
 *   Return:
 *     >=0
 */
LONG PppInitialize(void);

/*
 * PppTerminate
 *   Terminate the PPP main library
 *
 *   Args:
 *
 *   Return:
 *
 */
LONG PppTerminate(void);

/*
 * PppInstanceCreate
 *  Creates a PPP instance
 *
 *  Args:
 *
 *  Return:
 *   handle to the instance
 */
H_NETINSTANCE PppInstanceCreate(void);

/*
 * PppInstanceDestroy
 *  Destroy a PPP instance
 *
 *  Args:
 *   hPpp                  Handle of the instance to destroy
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceDestroy(H_NETINSTANCE hPpp);

/*
 * PppInstanceSet
 *  Set an instance option
 *
 *  Args:
 *   hPpp                  Handle of the instance to destroy
 *   oOption               option code
 *   hData                 data handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceSet(H_NETINSTANCE hPpp,OCTET oOption,H_NETDATA hData);

/*
 * PppInstanceQuery
 *  Set an instance option
 *
 *  Args:
 *   hPpp                  Handle of the instance to destroy
 *   oOption               option code
 *   phData                 data handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceQuery(H_NETINSTANCE hPpp,OCTET oOption,H_NETDATA *phData);

/*
 * PppInstanceMsg
 *  Instance Msg function
 *
 *  Args:
 *   hPpp                  Handle of the instance to destroy
 *   oOption               option code
 *   hData                 data handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceMsg(H_NETINSTANCE hPpp,OCTET oMsg,H_NETDATA hData);

/*
 * PppInstanceULInterfaceCreate
 *  Creates a UL interface on the instance
 *
 *  Args:
 *   hPpp              instance handle
 *
 *  Return:
 *   Interface handle
 */
H_NETINTERFACE PppInstanceULInterfaceCreate(H_NETINSTANCE hPpp);

/*
 * PppInstanceULInterfaceDestroy
 *  Creates a UL interface on the instance
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceULInterfaceDestroy(H_NETINSTANCE hPpp,H_NETINTERFACE hIf);

/*
 * PppInstanceULInterfaceIoctl
 *  UL interface ioctl function
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *   oIoctl            ioctl code
 *   hData             data handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppInstanceULInterfaceIoctl(H_NETINSTANCE hPpp,H_NETINTERFACE hIf,
                                 OCTET oIoctl,H_NETDATA hData);

/*
 * PppInstanceLLInterfaceCreate
 *  Creates the Ppp LL interface
 *
 *  Args:
 *   hPpp              instance handle
 *
 *  Return:
 *   Interface handle
 */
H_NETINTERFACE PppInstanceLLInterfaceCreate(H_NETINSTANCE hPpp);

/*
 * PppInstanceLLInterfaceDestroy
 *  Destroy the Ppp LL interface
 *
 *  Args:
 *   hPpp              instance handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceLLInterfaceDestroy(H_NETINSTANCE hPpp,H_NETINTERFACE hIf);

/*
 * PppInstanceLLInterfaceIoctl
 *  LL interface ioctl
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *   oIoctl            ioctl code
 *   hData             data handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceLLInterfaceIoctl(H_NETINSTANCE hPpp,H_NETINTERFACE hIf,
                                 OCTET oIoctl,H_NETDATA hData);

/*
 * PppInstanceWrite
 *  Ppp instance write function
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *   pxPacket          packet pointer
 *   pxAccess          access info
 *   hData             NETIFID *
 *
 *  Return:
 *   length written
 */
LONG PppInstanceWrite(H_NETINSTANCE hPpp,H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                      H_NETDATA hData);

/*
 * PppInstanceRcv
 *  PppInstanceRcv function
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *   pxPacket          packet pointer
 *   pxAccess          access info
 *   hData             NETIFID *
 *
 *  Return:
 *   length written
 */
LONG PppInstanceRcv(H_NETINSTANCE hPpp,H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                    H_NETDATA hData);

/*
 * PppInstanceProcess
 *  Ppp Process function
 *
 *  Args:
 *   hPpp              instance handle
 *
 *  Return:
 *   delay till next call
 */
LONG PppInstanceProcess(H_NETINSTANCE hPpp);


#endif /* #ifndef _PPP_H_ */

