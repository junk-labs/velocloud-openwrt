/*
 * pppdefs.h
 *
 * PPP internal API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPPDEFS_H_
#define _PPPDEFS_H_


#include "NNstyle.h"

#include "ppp_flavor.h"
#include "string.h"
#include "stdlib.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h> /* ntoh macros */
#include <netinet/in.h> /* ntoh macros on Linux/Solaris */
#include <pthread.h>
#include <mqueue.h>
#include <stdio.h>
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"
#include "pppcp.h"
#include "ppp.h"
#include "ppp_dbg.h"

/*****************************************************************************
 *
 * Constants
 *
 *****************************************************************************/

#define PPPPROTIDX_NONE    0xFFFF

#define PPTP_HDRLEN           2
#define PPPID_PPTP            0xFF03
#define PPPPPTP_HDRMSB        0xFF
#define PPPPPTP_HDRLSB        0x03
#define PPPPPTPSET_HDR(poPacket) do { \
 *((OCTET *)poPacket) = PPPPPTP_HDRMSB; \
 *((OCTET *)poPacket + 1) = PPPPPTP_HDRMSB; \
 } while(0)

#define PPPSET_HDR(poPacket,wProtocolId) do { \
 WORD wnProtocolId = htons(wProtocolId); \
 *((OCTET *)poPacket) = (OCTET)((wnProtocolId) >> 8) & 0xFF; \
 *((OCTET *)poPacket + 1) = (OCTET)(wnProtocolId & 0xFF); \
 } while(0)
#define PPPGET_HDR(poPacket) \
 ntohs( (((WORD)(*((OCTET *)poPacket))) << 8) + \
        *(((OCTET *)poPacket) + 1))
#define PPPHDR_UNPFC(A)   A  /* Uncompress Header. Does nothing for now
                                as it is not supported*/

/*
 * Link protocol type
 *  Used internally
 */
#define PPPLINKPROTTYPE_LCP             0
#define PPPLINKPROTTYPE_AP              1
#define PPPLINKPROTTYPE_LQP             2

/*************************************************
 *
 * LCP parsing macros
 *
 *************************************************/

/*
 * LCP specific commands
 */

#define PPPLCP_HLEN                      2

/* Echo reply */
#define PPPLCPCOMMAND_ECHOREPLY          10
#define PPPLCPCOMMANDLENGTH_ECHOREPLY    8

/* Echo request */
#define PPPLCPCOMMAND_ECHOREQUEST          9
#define PPPLCPCOMMANDLENGTH_ECHOREQUEST    8

#define PPPLCPOFFSET_COMMAND 0
#define PPPLCPGET_COMMAND(poPacket) (*(poPacket + PPPLCPOFFSET_COMMAND))
#define PPPLCPSET_COMMAND(poPacket,oCommand) do {                       \
    (*(poPacket + PPPLCPOFFSET_COMMAND)) = oCommand;                   \
  } while(0)

#define PPPLCPOFFSET_ID             1
#define PPPLCPGET_ID(poPacket)       ((OCTET) *(poPacket + PPPLCPOFFSET_ID))
#define PPPLCPSET_ID(poPacket,oId) do {                                 \
    (*(poPacket + PPPLCPOFFSET_ID)) = oId;                             \
  } while(0)

#define PPPLCPOFFSET_LENGTH         2
#define PPPLCPGET_LENGTH(poPacket)                                      \
    ((WORD) ntohs(((*(poPacket + PPPLCPOFFSET_LENGTH)) << 8) |         \
                  ((*(poPacket + PPPLCPOFFSET_LENGTH + 1)))))
#define PPPLCPSET_LENGTH(poPacket,wLength) do {                         \
      *(poPacket + PPPLCPOFFSET_LENGTH) =                              \
      (ntohs(wLength) & 0xFF00) >> 8;                                   \
      *(poPacket + PPPLCPOFFSET_LENGTH + 1) =                          \
      (ntohs(wLength) & 0xFF);                                          \
  } while(0)

#define PPPLCPOFFSET_DATA           PPPLCP_HLEN
#define PPPLCPGET_DATAPOINTER(poPacket)                                 \
  ((OCTET *)(poPacket + PPPLCPOFFSET_DATA))


/*
 * Options
 */

/* Option Code */
#define PPPLCPOPTIONOFFSET_TYPE         0
#define PPPLCPOPTIONGET_TYPE(poPayload) LcpOptionGetType(poPayload)
#define PPPLCPOPTIONSET_TYPE(poPacket,eType) do {                  \
 *(poPacket + PPPLCPOPTIONOFFSET_TYPE) =                           \
    aoLcpOptionToCode[eType];                                      \
 } while(0)

/* Option Type Codes */
#define PPPLCPOPTIONCODE_MRU       1
#define PPPLCPOPTIONCODE_AP        3
#define PPPLCPOPTIONCODE_LQP       4
#define PPPLCPOPTIONCODE_MN        5
#define PPPLCPOPTIONCODE_PFC       7
#define PPPLCPOPTIONCODE_ACFC      8

#define PPPLCPOPTIONCODE_MAX PPPLCPOPTIONCODE_ACFC

/* Option length */
#define PPPLCPOPTIONOFFSET_LENGTH     1
#define PPPLCPOPTIONGET_LENGTH(poPacket)                              \
 ((OCTET) *(poPacket + PPPLCPOPTIONOFFSET_LENGTH))
#define PPPLCPOPTIONSET_LENGTH(poPacket,oLength) do {                 \
  *(poPacket + PPPLCPOPTIONOFFSET_LENGTH) = oLength;                  \
 } while(0)
/* Nominal length of the different option fields */
#define PPPLCPOPTIONLENGTH_MRU         4
#define PPPLCPOPTIONLENGTH_AP          4
#define PPPLCPOPTIONLENGTH_LQP         4
#define PPPLCPOPTIONLENGTH_MN          6
#define PPPLCPOPTIONLENGTH_PFC         2
#define PPPLCPOPTIONLENGTH_ACFC        2


/* Option data */
#define PPPLCPOPTIONOFFSET_DATA       2
#define PPPLCPOPTIONGET_DATAPOINTER(poPacket) \
 ((OCTET *)poPacket +  PPPLCPOPTIONOFFSET_DATA)

/* MRU */
#define PPPLCPOPTIONGET_MRU(poPacket)                                 \
  ((WORD) ntohs(((*(poPacket + PPPLCPOPTIONOFFSET_DATA)) << 8) |     \
                ((*(poPacket + PPPLCPOPTIONOFFSET_DATA + 1)))))
#define PPPLCPOPTIONSET_MRU(poPacket,dwValue) do {                    \
  *(poPacket + PPPLCPOPTIONOFFSET_DATA) =                            \
    (ntohs(dwValue) & 0xFF00) >> 8;                                    \
  *(poPacket + PPPLCPOPTIONOFFSET_DATA + 1) =                        \
    (ntohs(dwValue) & 0xFF);                                           \
  } while(0)

/* PROT */
#define PPPLCPOPTIONGET_PROT(poPacket)                                 \
  ((WORD) ntohs(((*(poPacket + PPPLCPOPTIONOFFSET_DATA)) << 8) |     \
                ((*(poPacket + PPPLCPOPTIONOFFSET_DATA + 1)))))
#define PPPLCPOPTIONSET_PROT(poPacket,dwValue) do {                    \
  *(poPacket + PPPLCPOPTIONOFFSET_DATA) =                            \
    (ntohs(dwValue) & 0xFF00) >> 8;                                    \
  *(poPacket + PPPLCPOPTIONOFFSET_DATA + 1) =                        \
    (ntohs(dwValue) & 0xFF);                                           \
  } while(0)
#define PPPLCPOPTIONGET_PROTDATAPOINTER(poPacket) \
 (poPacket + PPPLCPOPTIONOFFSET_DATA + 2)
#define PPPLCPOPTION_GETPROTDATALENGTH(wPacketLength) \
  (wPacketLength - PPPLCPOPTIONOFFSET_DATA - 2)

/* Magic Number */
#define PPPLCPOPTIONGET_MN(poPacket)                                  \
  ((DWORD) ntohl(((*(poPacket + PPPLCPOPTIONOFFSET_DATA)) << 24) |    \
                 ((*(poPacket + PPPLCPOPTIONOFFSET_DATA + 1)) << 16) |\
                 ((*(poPacket + PPPLCPOPTIONOFFSET_DATA + 2)) << 8) | \
                 ((*(poPacket + PPPLCPOPTIONOFFSET_DATA + 3)))))
#define PPPLCPOPTIONSET_MN(poPacket,dwMagicNumber) do {               \
    *(poPacket + PPPLCPOPTIONOFFSET_DATA) =                          \
    (ntohl(dwMagicNumber) & 0xFF000000) >> 24;                         \
    *(poPacket + PPPLCPOPTIONOFFSET_DATA + 1) =                      \
    (ntohl(dwMagicNumber) & 0x00FF0000) >> 16;                         \
    *(poPacket + PPPLCPOPTIONOFFSET_DATA + 2) =                      \
    (ntohl(dwMagicNumber) & 0x0000FF00) >> 8;                          \
    *(poPacket + PPPLCPOPTIONOFFSET_DATA + 3) =                      \
    (ntohl(dwMagicNumber) & 0x000000FF);                               \
  } while(0);


/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * PPP protocol option
 */
typedef enum {
  PPPLCPOPTION_MRU =0,    /* Maximum Receive Unit. Value is WORD */
  PPPLCPOPTION_AP,        /* Authentification Protocol. value is OCTET index
                              into the Ap Table */
  PPPLCPOPTION_LQP,       /* Link Quality Protocol. value is OCTET index
                              into the lqp table*/
  PPPLCPOPTION_MN,        /* Magic Number. value is BOOL */
  PPPLCPOPTION_ACFC,      /* Address Field Compression. Value is BOOL */
  PPPLCPOPTION_PFC,       /* Protocol Field Compression. Value is BOOL */
  PPPLCPOPTION_ENUMMAX
} E_PPPLCPOPTION;


/*
 * PPP stack phase
 */
typedef enum {
  PPPPHASE_DEAD,
  PPPPHASE_ESTABLISH,
  PPPPHASE_AUTHENTICATE,
  PPPPHASE_NETWORK,
  PPPPHASE_TERMINATE,
  PPPPHASE_ENUMMAX
} E_PPPPHASE;

/*
 * PPP Ul interface
 */
typedef struct {
  WORD wProtocolId;
  OCTET obUp;
  H_NETINSTANCE hUl;
  H_NETINTERFACE hUlIf;
  PFN_NETRXCBK pfnRxCbk;
} PPPULIF;


typedef struct {
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

  E_PPPPHASE ePhase;

  /* UL Interfaces */
  H_NETINSTANCE hCp;
  H_NETINTERFACE hCpIf;

  PPPULIF *pxUlTable;    /*Uls protocol. Note: this is
                           a flat scheme: no prioritization
                           is done */
  WORD wUlTableSize;

  /* LL interfaces */
  OCTET oLLNumber;
  H_NETINSTANCE hLl;
  H_NETINTERFACE hLlIf;
  PFN_NETWRITE pfnNetWrite;

  /* Cbk */
  PFN_NETCBK pfnNetCbk;
  H_NETINSTANCE hNetCbk;

  /* Ppp protocol Options */
  H_NETDATA ahLcpLocalOption[PPPLCPOPTION_ENUMMAX];
  H_NETDATA ahLcpRemoteOption[PPPLCPOPTION_ENUMMAX];


  /* Misc */
  OCTET oTunnelMode;
  OCTET oApNum;
  OCTET oLqpNum;
  DWORD dwCurrentMN;
  WORD wOffset;
  WORD wTrailer;
  pthread_mutex_t *pxMutex;

  DWORD dwNextIdleTO;
  DWORD dwIdleTOCurrent;
  DWORD dwIdleTO;

  /* LCP Echo handling */
  DWORD dwNextEchoTO;
  DWORD dwEchoTOCurrent;
  DWORD dwEchoTO;
  DWORD dwEchoCount;

} PPPSTATE;

typedef LONG (*PFN_LCPREMOTEOPTIONCHECK) (PPPSTATE *,H_NETDATA *,
                                          OCTET *,OCTET ,
                                          OCTET **,WORD *,
                                          OCTET **,WORD *);
/*
 * Lcp Local Option Check function table
 */
typedef LONG (* PFN_LCPLOCALOPTIONCHECK)(PPPSTATE *,H_NETDATA *,
                                         OCTET *,OCTET);

/***************************************************************************
 *
 * extern
 *
 ***************************************************************************/

MOC_EXTERN const H_NETDATA ahLcpOptionDefault[PPPLCPOPTION_ENUMMAX];
MOC_EXTERN const OCTET aoLcpOptionToCode[PPPLCPOPTION_ENUMMAX];
MOC_EXTERN const SHORT aoLcpCodeToOption[PPPLCPOPTIONCODE_MAX + 1];
MOC_EXTERN const OCTET aoLcpOptionToLength[PPPLCPOPTION_ENUMMAX];
MOC_EXTERN const PFN_LCPREMOTEOPTIONCHECK apfnPppInstanceLcpCheckRemoteOption[PPPLCPOPTION_ENUMMAX];
MOC_EXTERN const PFN_LCPLOCALOPTIONCHECK apfnPppInstanceLcpCheckLocalOption [PPPLCPOPTION_ENUMMAX];

#ifdef PPPDBG_HI
MOC_EXTERN const OCTET *apoPppOptionString[PPPOPTIONMAX];
MOC_EXTERN const OCTET *apoPppMsgString[2];
#endif /*#ifdef PPPDBG_HI*/
/***************************************************************************
 *
 * Local Prototypes
 *
 ***************************************************************************/

OCTET LcpOptionLength(E_PPPLCPOPTION eOption,H_NETDATA hData);
LONG PppInstanceLcpOptionSetValue(PPPSTATE *pxState,
                                  E_PPPLCPOPTION eOption,
                                  H_NETDATA hData,OCTET *poField);
LONG LcpSetFieldFromOriginal(OCTET **ppoField,WORD *pwFieldLength,
                             OCTET *poOrig,WORD wOrigLength);
LONG PppInstanceLcpSetOptionField(PPPSTATE *pxState,OCTET **ppoField,
                                  WORD *pwFieldLength,E_PPPLCPOPTION eOption,
                                  H_NETDATA hData);
LONG PppInstanceRemoteMruCheck(PPPSTATE *pxState,H_NETDATA *phData,
                               OCTET *poData,OCTET oDataLength,
                               OCTET **ppoRej,WORD *pwRejLength,
                               OCTET **ppoNak,WORD *pwNakLength);
LONG PppInstanceRemoteLinkProtCheck(PPPSTATE *pxState,OCTET oLinkType,
                                    H_NETDATA *phData,
                                    OCTET *poData,OCTET oDataLength,
                                    OCTET **ppoRej,WORD *pwRejLength,
                                    OCTET **ppoNak,WORD *pwNakLength);
LONG PppInstanceRemoteApCheck(PPPSTATE *pxState,H_NETDATA *phData,
                              OCTET *poData,OCTET oDataLength,
                              OCTET **ppoRej,WORD *pwRejLength,
                              OCTET **ppoNak,WORD *pwNakLength);
LONG PppInstanceRemoteLqpCheck(PPPSTATE *pxState,H_NETDATA *phData,
                               OCTET *poData,OCTET oDataLength,
                               OCTET **ppoRej,WORD *pwRejLength,
                               OCTET **ppoNak,WORD *pwNakLength);
LONG PppInstanceRemoteMnCheck(PPPSTATE *pxState,H_NETDATA *phData,
                              OCTET *poData,OCTET oDataLength,
                              OCTET **ppoRej,WORD *pwRejLength,
                              OCTET **ppoNak,WORD *pwNakLength);
LONG PppInstanceRemoteAcfcCheck(PPPSTATE *pxState,H_NETDATA *phData,
                                OCTET *poData,OCTET oDataLength,
                                OCTET **ppoRej,WORD *pwRejLength,
                                OCTET **ppoNak,WORD *pwNakLength);
LONG PppInstanceRemotePfcCheck(PPPSTATE *pxState,H_NETDATA *phData,
                               OCTET *poData,OCTET oDataLength,
                               OCTET **ppoRej,WORD *pwRejLength,
                               OCTET **ppoNak,WORD *pwNakLength);
LONG PppInstanceLocalMruCheck(PPPSTATE *pxState,H_NETDATA *phData,
                              OCTET *poData,OCTET oDataLength);
LONG PppInstanceLocalLinkProtCheck(PPPSTATE *pxState,OCTET oLinkType,
                                   H_NETDATA *phData,OCTET *poData,
                                   OCTET oDataLength);
LONG PppInstanceLocalApCheck(PPPSTATE *pxState,H_NETDATA *phData,
                             OCTET *poData,OCTET oDataLength);
LONG PppInstanceLocalLqpCheck(PPPSTATE *pxState,H_NETDATA *phData,
                             OCTET *poData,OCTET oDataLength);
LONG PppInstanceLocalMnCheck(PPPSTATE *pxState,H_NETDATA *phData,
                             OCTET *poData,OCTET oDataLength);
LONG PppInstanceLocalAcfcCheck(PPPSTATE *pxState,H_NETDATA *phData,
                               OCTET *poData,OCTET oDataLength);
LONG PppInstanceLocalPfcCheck(PPPSTATE *pxState,H_NETDATA *phData,
                              OCTET *poData,OCTET oDataLength);
SHORT LcpOptionGetType(OCTET *poPayload);
LONG PppInstanceLcpConfReq(PPPSTATE *pxState,PPPCPOPTIONFIELDS *pxOptions);
LONG PppInstanceLcpConfNak(PPPSTATE *pxState,PPPCPOPTIONFIELDS *pxOptions);
LONG PppInstanceLcpConfRej(PPPSTATE *pxState,PPPCPOPTIONFIELDS *pxOptions);
LONG PppInstanceLcpOptionCode(PPPSTATE *pxState,PPPCPOPTIONFIELDS *pxOptions);
LONG PppInstanceLcpUnknownCode(PPPSTATE *pxState,PPPCPPACKET *pxPacket);
LONG PppInstanceLcpCbk(H_NETINSTANCE hPpp, OCTET oCbk, H_NETDATA hData);
LONG PppInstanceOptionResetDefault(PPPSTATE *pxState);
/*
 * PppInstanceFindUlIdxFromProtocolId
 *  Finds the index in the Ul Table, based on the Protocol Field
 *
 *  Args:
 *   pxState               instance pointer
 *   wProtocolId           Protocol Id
 *
 *  Return:
 *   index or NETERR_UNKNOWN
 */
LONG PppInstanceFindUlIdxFromProtocolId(PPPSTATE *pxState,WORD wProtocolId);

#endif /* #ifndef _PPPDEFS_H_ */
