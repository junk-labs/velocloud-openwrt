/*
 * arp.c
 *
 * ARP module implementation
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "arpdefs.h"

/*****************************************************************************
 *
 * debug
 *
 *****************************************************************************/

ARP_DBG_VAR(DWORD g_dwArpDebugLevel = 3);
ARP_DBG_VAR(DWORD dbg_dwArpRxCbkLine = 0);
ARP_DBG_VAR(DWORD dbg_dwArpRefreshLine = 0);
ARP_DBG_VAR(DWORD dbg_dwArpPrintTable = 0);
ARP_DBG_VAR(DWORD dbg_dwArpPrintHash = 0);
ARP_DBG_VAR(DWORD dbg_dwArpNumCurrentEntries = 0);
ARP_DBG_VAR(DWORD dbg_dwArpMaxEntries = 0);

/*****************************************************************************
 *
 * Local Function prototypes
 *
 *****************************************************************************/
static LONG _ArpSendRequest(ARPSTATE *pxArp, ARPREQUEST *pxArpRequest);
static LONG _ArpFindPending(void *pxItem,void *pxKey);
static void _ArpTableCreate(ARPSTATE *pxArp);
static void _ArpTableDestroy(ARPSTATE *pxArp);

static LONG _ArpRcv(H_NETINSTANCE hArp,
                           H_NETINTERFACE hIf,
                           NETPACKET *pxPacket,
                           NETPACKETACCESS *pxAccess,
                           H_NETDATA hData);
/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/

ARPSTATE  *pxArpInstance = NULL;
/*****************************************************************************
 *
 * API Implementation
 *
 *****************************************************************************/

/*
 * ArpInitialize
 *  Initialize the ARP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG ArpInitialize(void)
{
  /* nothing to do */

  INET_DBG_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_ERROR);
  return (LONG)NETERR_NOERR;
}

/*
 * ArpTerminate
 *  Terminate the ARP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG ArpTerminate(void)
{
  /* nothing to do */

  return (LONG)NETERR_NOERR;
}

/*
 * ArpInstanceCreate
 *  Creates a ARP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE ArpInstanceCreate(void)
{
  ARPSTATE *pxArp;

  pxArp = (ARPSTATE *)MALLOC(sizeof(ARPSTATE));
  ARP_DBG_ASSERT(pxArp != NULL);
  MOC_MEMSET((ubyte *)pxArp, 0, sizeof(ARPSTATE));

  /*Set the magic cookie*/
  ARP_SET_COOKIE(pxArp);

  /* For now, only deal with IP over ethernet */
  /* N.B. Network byte order */
  pxArp->aoArpHeader[0] = 0x00;
  pxArp->aoArpHeader[1] = 0x01; /* Hardware address type. eth==1*/
  pxArp->aoArpHeader[2] = 0x08;
  pxArp->aoArpHeader[3] = 0x00; /* Protocol type. IP == 0x0800 */
  pxArp->aoArpHeader[4] = ARP_ETHLEN; /* Size of hardware address */
  pxArp->aoArpHeader[5] = ARP_IPLEN;  /* Size of protocol address */

  /* Default MAC broadcast address */
  MOC_MEMSET((ubyte *)pxArp->aoBcastEthAddr, 0xFF, ARP_ETHLEN);

  pxArp->dwLastArpRefreshTime = (DWORD)NetGetMsecTime();

#ifdef ARP_CACHE_32
  pxArp->oArpTableSize = ARPDEFAULT_MAXENTRIES;
  pxArp->oArpHashSize = ARPDEFAULT_MAXENTRIES/2;
#else
  pxArp->wArpHashSize = ARP_CACHE_TABLE_SIZE;
#endif

#ifdef ARP_TIME_RETRY
  pxArp->dwArpRetryTime = ARPTIME_RETRY * 3;
  pxArp->dwArpLastRetryTime = (DWORD)NetGetMsecTime();
#endif

  _ArpTableCreate(pxArp);

  /* For snmp, add to the list of arp instances */
  ASSERT(pxArpInstance == NULL);
  pxArpInstance = pxArp;

  return (H_NETINSTANCE)pxArp;
}

/*
 * ArpInstanceDestroy
 *  Destroy a ARP Instance
 *
 *  Args:
 *   hArp                       ARP instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG ArpInstanceDestroy(H_NETINSTANCE hArp)
{
  ARPSTATE *pxArp = (ARPSTATE *)hArp;
  ARP_CHECK_STATE(pxArp);

  /* have to take pointer out of snmp list */
  pxArpInstance = NULL;

  clear_DLLIST(&pxArp->dllPending,NetFree);

  _ArpTableDestroy(pxArp);

  /*Unset the magic cookie*/
  ARP_UNSET_COOKIE(pxArp);

  FREE(pxArp);

  return (LONG)NETERR_NOERR;
}

/*
 * ArpInstanceSet
 *  Set a ARP Instance Option
 *
 *  Args:
 *   hArp                       ARP instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG ArpInstanceSet(H_NETINSTANCE hArp, OCTET oOption,
                    H_NETDATA hData)
{
  ARPSTATE *pxArp = (ARPSTATE *)hArp;
  LONG lReturn = (LONG)NETERR_NOERR;

  ARP_CHECK_STATE(pxArp);

  switch(oOption) {

  case NETOPTION_MALLOC:
    ARP_DBG_ASSERT((void*)hData != NULL);
    pxArp->pfnMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_FREE:
    ARP_DBG_ASSERT((void*)hData != NULL);
    pxArp->pfnFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    ARP_DBG_ASSERT((void*)hData != NULL);
    pxArp->pxMutex = (RTOS_MUTEX)hData;
    break;

  case NETOPTION_OFFSET:
  case NETOPTION_TRAILER:
    {
      WORD wSrc, *pwDst;
      pwDst = (oOption == NETOPTION_OFFSET) ? &(pxArp->wOffset) :
        &(pxArp->wTrailer);
      wSrc = ((DWORD)hData & 0xFFFF);
      if (wSrc > *pwDst) {
        /* Just take the largest across all interfaces */
        *pwDst = wSrc;
      }
    }
    break;


  case NETOPTION_NETCBK:
    pxArp->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case NETOPTION_NETCBKHINST:
    pxArp->hNetCbk = (H_NETINSTANCE)hData;

  case ARPOPTION_CACHESIZE:
#ifdef ARP_CACHE_32
    pxArp->oArpTableSize = (OCTET)hData;
#else
/*Ajit: I might have to add somethign out here*/
#endif
    break;

  case ARPOPTION_ETHADDRESS:
    {
      ARPETHDATA *pxEthData;

      pxEthData = (ARPETHDATA*)hData;
      ASSERT(pxEthData->oIfIdx < ARPMAX_IFNUM);

      MOC_MEMCPY((ubyte *)pxArp->aaoIfEthAddr[pxEthData->oIfIdx],
             (ubyte *)pxEthData->aoEthAddr, ARP_ETHLEN);
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_NORMAL))
      {
        /*ARP_DBGP(DBGLVL_NORMAL,
               "ArpInstanceSet - ARPOPTION_ETHADDRESS %02x:%02x:%02x:%02x:%02x:%02x\n",
               HWADDRDISPLAY(pxEthData->aoEthAddr));*/
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "ArpInstanceSet - ARPOPTION_ETHADDRESS", pxEthData->aoEthAddr[0],
                            ":", pxEthData->aoEthAddr[1]);
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ":", pxEthData->aoEthAddr[2],
                            ":", pxEthData->aoEthAddr[3]);
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ":", pxEthData->aoEthAddr[4],
                            ":", pxEthData->aoEthAddr[5]);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }
    }
  break;

  default:
    lReturn = (LONG)NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}


/*
 * ArpInstanceMsg
 *  Send a msg to a ARP instance
 *
 *  Args:
 *   hArp                       ARP instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG ArpInstanceMsg(H_NETINSTANCE hArp,OCTET oMsg,
                    H_NETDATA hData)
{
  ARPSTATE *pxArp = (ARPSTATE *)hArp;
  LONG lReturn;

  ARP_CHECK_STATE(pxArp);

  lReturn = (LONG)NETERR_NOERR;

  switch(oMsg) {
  case NETMSG_OPEN:
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    break;

  case ARPMSG_REACQUIRE:
  case ARPMSG_RESOLVE:
    {
      ARPREQUEST *pxArpRequest = (ARPREQUEST*)hData;
      DWORD dwOriginalIpAddr;
      OCTET obUseGateway = FALSE;
      OCTET oDstIpAddrType;
      IPTABLEENTRY xIpEntry;

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
      {
        /*ARP_DBGP(DBGLVL_REPETITIVE,"ArpInstanceMsg: ARPMSG_RESOLVE %ld.%ld.%ld.%ld (oIfIdx %d)\n",
               IPADDRDISPLAY(pxArpRequest->xEntry.dwIpAddr),
               pxArpRequest->xEntry.oIfIdx);*/
        DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "ArpInstanceMsg: ARPMSG_RESOLVE ", pxArpRequest->xEntry.dwIpAddr);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " (oIfIdx ", pxArpRequest->xEntry.oIfIdx);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, " )");
      }

      xIpEntry.oIfIdx = pxArpRequest->xEntry.oIfIdx;
      xIpEntry.wDefaultVlan = pxArpRequest->xEntry.wVlan;
      xIpEntry.dwAddr = pxArpRequest->xEntry.dwIpAddr;
      oDstIpAddrType = IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry);

      switch (oDstIpAddrType) {
      case IPADDRT_LOOPBACK:
      case IPADDRT_MYADDR:
        /* Use our own ethernet address */
        MOC_MEMCPY((ubyte *)pxArpRequest->xEntry.aoEthAddr,
               (ubyte *)pxArp->aaoIfEthAddr[pxArpRequest->xEntry.oIfIdx],
               ARP_ETHLEN);
        break;

      case IPADDRT_BROADCAST:
        MOC_MEMCPY((ubyte *)pxArpRequest->xEntry.aoEthAddr,
               (ubyte *)pxArp->aoBcastEthAddr, ARP_ETHLEN);
        break;

      case IPADDRT_MULTICAST:
      case IPADDRT_MULTICASTJOINED:
      case IPADDRT_MULTICASTJOINEDPROXY:
      case IPADDRT_MULTICASTJOINEDSOCKPROXY:
        IpBuildMCastEthAddr(pxArpRequest->xEntry.aoEthAddr,
                            pxArpRequest->xEntry.dwIpAddr);
        break;

      case IPADDRT_OUTSIDE:
        obUseGateway = TRUE;
        /* Fall through */

      case IPADDRT_MYSUBNET:
      case IPADDRT_UNKNOWN:

        dwOriginalIpAddr = pxArpRequest->xEntry.dwIpAddr;
        if (obUseGateway == TRUE) {
          pxArpRequest->xEntry.dwIpAddr = pxArpRequest->dwGatewayAddr;
          ASSERT(pxArpRequest->dwGatewayAddr);
        }

        if ((INT)0 != ArpFind(pxArp, &(pxArpRequest->xEntry), (ARPMSG_REACQUIRE == oMsg))) {
          /* Not found */
          lReturn = (LONG)ARPRCODE_RESOLVING;
          /* Is it already being resolved? */
          DLLIST_head(&pxArp->dllPending);
          if (NULL == DLLIST_find(&pxArp->dllPending,
                                  (void *)&(pxArpRequest->xEntry),
                                 _ArpFindPending)) {
            /* We don't already have the request. */
            if (DLLIST_count_inline(&pxArp->dllPending) <
                (DWORD)ARP_MAX_PENDING_ITEMS) {
              if ((LONG)0 == _ArpSendRequest(pxArp, pxArpRequest)) {
                ARPPEND *pxArpPend;
                pxArpPend = MALLOC(sizeof(ARPPEND));
                ARP_DBG_ASSERT(pxArpPend);
                /* Transfer the request */
                pxArpPend->xRequest = *pxArpRequest;
                pxArpPend->dwOriginalIpAddr = dwOriginalIpAddr;
                /*pxArpPend->dwTime = (DWORD)NetGlobalTimerGet();*/
                pxArpPend->dwTime = (DWORD)NetGetMsecTime();
                pxArpPend->oTries = 1;
                DLLIST_append(&pxArp->dllPending, pxArpPend);
              } else {
                lReturn = (LONG)NETERR_ARPSENDREQUESTFAILED;
              }
            } else {
              lReturn = (LONG)NETERR_ARPREQUESTQUEUEFULL;
            }
          }
        }
        break;

      default:
        lReturn = (LONG)NETERR_BADVALUE;
        /*        ARP_DBG_ASSERT(0);*/
      }
    }
    break;

  case ARPMSG_ADD:
  {
    ARPENTRY *pxArpEntry = (ARPENTRY *)hData;
    INT nIpAddrType;
    IPTABLEENTRY xIpEntry;

    /* It is not legal to add an Arp entry without specifying
       the interface */
    ARP_DBG_ASSERT(pxArpEntry->oIfIdx != NETIFIDX_ANY);

    xIpEntry.dwAddr = pxArpEntry->dwIpAddr;
    xIpEntry.oIfIdx = pxArpEntry->oIfIdx;
    xIpEntry.wDefaultVlan = pxArpEntry->wVlan;
    xIpEntry.u.dwIpNetMask = IpAddrGetMask(xIpEntry.dwAddr);

    nIpAddrType = IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry);

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
    {
      /*
      ARP_DBGP(DBGLVL_REPETITIVE,"ArpInstanceMsg: ARPMSG_ADD %ld.%ld.%ld.%ld (oIfIdx %d)\n",
               IPADDRDISPLAY(pxArpEntry->dwIpAddr),
               pxArpEntry->oIfIdx);
      */
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "ArpInstanceMsg: ARPMSG_ADD ", pxArpEntry->dwIpAddr);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " (oIfIdx ", pxArpEntry->oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " )");
    }

    /* Only add addresses if it is within our subnet */
    if (IPADDRT_MYSUBNET != nIpAddrType) {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
      {
        /*ARP_DBGP(DBGLVL_REPETITIVE," - FAIL, address type: %d (not MYSUBNET)\n", nIpAddrType);*/
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " - FAIL, address type: ", nIpAddrType);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, " (not MYSUBNET)");
      }
      lReturn = (LONG)NETERR_BADVALUE;
      break;
    }

    ArpAdd(pxArp, pxArpEntry);
  }
  break;

#ifdef __MOC_CLI__
  case ARPMSG_CLI_SHOW:
  {
    ARPCLIGET *pxArpCliGet = (ARPCLIGET *)(hData);
    pxArpCliGet->dwSbufLen = ArpPrintTableforCli(pxArp, pxArpCliGet->poSbuf);
    break;
  }
#endif

  default:
    lReturn = (LONG)NETERR_UNKNOWN;
    ARP_DBG_ASSERT(0);
    break;
  }

  return lReturn;
}

/*
 * ArpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hArp                       ARP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE ArpInstanceLLInterfaceCreate(H_NETINSTANCE hArp)
{
  return (H_NETINTERFACE)1;
}

/*
 * ArpInstanceLLInterfaceDestroy
 *  Destroy a ARP LL interface
 *
 *  Args:
 *   hArp                       ARP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG ArpInstanceLLInterfaceDestroy(H_NETINSTANCE hArp,
                                   H_NETINTERFACE hInterface)
{
  ASSERT((H_NETINTERFACE)1 == hInterface);

  return NETERR_NOERR;
}

/*
 * ArpInstanceLLInterfaceIoctl
 *  ARP LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and netransport.h
 *  for precisions
 *
 *  Args:
 *   hArp                         Arp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG ArpInstanceLLInterfaceIoctl(H_NETINSTANCE hArp,
                                H_NETINTERFACE hInterface,
                                OCTET oIoctl,
                                H_NETDATA hData)
{
  ARPSTATE *pxArp = (ARPSTATE *)hArp;

  ARP_CHECK_STATE(pxArp);
  ARP_DBG_ASSERT(hInterface == (H_NETINTERFACE)1);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* Ignore these */
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxArp->hLL = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxArp->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxArp->hLLIf = (H_NETINTERFACE)hData;
    break;

  case ARPLLINTERFACEIOCTL_SETRARPIF:
    pxArp->hRarpLLIf = (H_NETINTERFACE)hData;
    break;

  default:
    ASSERT(0);
    break;
  }

  return NETERR_NOERR;
}

/*
 * _ArpRcv
 *  Arp Rcv function
 *   Follows PFN_NETRXCBK def.
 *
 *   Args:
 *    hArp                       Instance Handle
 *    hIf                        LL interface handle as provided by
 *                               ArpInstanceLLInterfaceCreate
 *    pxPacket                   packet
 *    pxAccess                   NETPACKETACCESS pointer
 *    hData                      NETIFID pointer
 *
 *   Return:
 *    Number of bytes received or a <0 error code
 */
LONG _ArpRcv(H_NETINSTANCE hArp,
             H_NETINTERFACE hIf,
             NETPACKET *pxPacket,
             NETPACKETACCESS *pxAccess,
             H_NETDATA hData)
{
  ARPSTATE *pxArp;
  NETPAYLOAD *pxPayload;
  ETHID *pxEthId;
  LONG lReturn;
  WORD wOffset;
  OCTET *poArp;
  DWORD  dwSrcIpAddr, dwDstIpAddr; /* sender and destination IP-address */
  OCTET oDstIpAddrType;
  OCTET oSrcIpAddrType;
  ARPENTRYSTATE *pxArpEntryState;
  IPTABLEENTRY xIpEntry;
  WORD wOpCode;
  sbyte4 cmpResult;

  pxArp = (ARPSTATE *)hArp;
  ARP_CHECK_STATE(pxArp);
  ASSERT(hData != 0);
  pxEthId = (ETHID*)hData;

  pxPayload = pxPacket->pxPayload;
  lReturn = (LONG)pxAccess->wLength;
  wOffset = pxAccess->wOffset;

  ARP_CHECKPOINT(dbg_dwArpRxCbkLine);

  do {
    /* Set the pointer to the start of the op code */
    poArp = (pxPayload->poPayload) + wOffset + ARP_HRDLEN;
    ARP_CHECKPOINT(dbg_dwArpRxCbkLine);

    /* Get the op code */
    MOC_MEMCPY((ubyte *)&wOpCode,(ubyte *) poArp, (ubyte4)ARP_OPLEN);
    wOpCode = ntohs(wOpCode);

    ASSERT((WORD)ARPOP_ARPREPLY == wOpCode ||
           (WORD)ARPOP_ARPREQUEST == wOpCode ||
           (WORD)ARPOP_RARPREQUEST == wOpCode);

    poArp += ARP_OPLEN;
    /* NB: poArp points to the source ethernet address in the arp packet */

    /* Only accept requests with our ethernet address as the destination
     * for RARP requests */
     MOC_MEMCMP((ubyte *)pxArp->aaoIfEthAddr[pxEthId->oIfIdx],
                (ubyte *)(poArp + ARP_ETHLEN + ARP_IPLEN),
                (ubyte4)ARP_ETHLEN, &cmpResult);
    if ((WORD)ARPOP_RARPREQUEST == wOpCode && ( 0!= cmpResult)) {
      NETPAYLOAD_DELUSER(pxPayload);
      break;
    }

    /* fetch the sender's IP address from the ARP header */
    MOC_MEMCPY((ubyte *)&dwSrcIpAddr, (ubyte *)(poArp + ARP_ETHLEN), (ubyte4)ARP_IPLEN);
    MOC_MEMCPY((ubyte *)&dwDstIpAddr, (ubyte *)(poArp + (ARP_ETHLEN * 2) + ARP_IPLEN), (ubyte4)ARP_IPLEN);

    dwSrcIpAddr = ntohl(dwSrcIpAddr);
    dwDstIpAddr = ntohl(dwDstIpAddr);

    xIpEntry.dwAddr = dwDstIpAddr;
    xIpEntry.oIfIdx = pxEthId->oIfIdx;
    xIpEntry.wDefaultVlan = pxEthId->wVlan;

    oDstIpAddrType = IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry);

    xIpEntry.dwAddr = dwSrcIpAddr;
    oSrcIpAddrType = IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry);

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
    {
      /*ARP_DBGP(DBGLVL_REPETITIVE,
             "_ArpRcv: Opcode %d SrcAddr "IPFORM" DestAddr "IPFORM" oIfIDx %d\n",
             wOpCode,
             IPADDRDISPLAY(dwSrcIpAddr),
             IPADDRDISPLAY(dwDstIpAddr),
             pxEthId->oIfIdx);*/
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "_ArpRcv: Opcode ", wOpCode);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " SrcAddr ", dwSrcIpAddr);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " DestAddr ", dwDstIpAddr);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " oIfIDx ", pxEthId->oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }

    pxArpEntryState = ArpLookup(pxArp, dwSrcIpAddr,pxEthId->oIfIdx,
                                pxEthId->wVlan);
    if (NULL != pxArpEntryState) {
      /*pxArpEntryState->dwLastUsed = (DWORD)NetGlobalTimerGet();*/
      pxArpEntryState->dwLastUsed = (DWORD)NetGetMsecTime();

#ifdef ARP_REQ_ON_TIMEOUT
      /* ARP resolution now re-acquired */
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
      {
        /*ARP_DBGP(DBGLVL_REPETITIVE,
               "_ArpRcv: ARP re-acquired "IPFORM"\n",
               IPADDRDISPLAY(pxArpEntryState->xEntry.dwIpAddr));*/
        DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_ArpRcv: ARP re-acquired ", pxArpEntryState->xEntry.dwIpAddr);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
     }

      pxArpEntryState->eState = ARPENTRY_REFRESHED;
#endif

      MOC_MEMCPY((ubyte *)pxArpEntryState->xEntry.aoEthAddr,(ubyte *) poArp, (ubyte4)ARP_ETHLEN);
    } else {
      /* create ARP cache entry if we are the destination address */
      if (
          (IPADDRT_OUTSIDE == oSrcIpAddrType) ||
          ((IPADDRT_MYADDR != oDstIpAddrType) &&
           (IPADDRT_LOOPBACK != oDstIpAddrType)) ) {
        ARP_CHECKPOINT(dbg_dwArpRxCbkLine);

        NETPAYLOAD_DELUSER(pxPayload);
        break;
      }

      if ((pxArpEntryState =
           ArpCreate(pxArp, dwSrcIpAddr, poArp,pxEthId->oIfIdx,
                     pxEthId->wVlan, E_ARPDYNAMIC)) != NULL) {
        ARPPEND *pxArpPend;

        /* If it is an arp reply - check if we asked for it */
        if ((WORD)ARPOP_ARPREPLY == wOpCode) {
          DLLIST_head(&pxArp->dllPending);
          pxArpPend = DLLIST_find(&pxArp->dllPending,
                                  (void *)&(pxArpEntryState->xEntry),
                                  _ArpFindPending);
          ARP_CHECKPOINT(dbg_dwArpRxCbkLine);
          if (NULL != pxArpPend) {
            ARPREQUEST xArpRequest;
            /* The IP is found in the pending list */

            /* Copy the pending entry ... */
            xArpRequest.xEntry = pxArpPend->xRequest.xEntry;
            /* ... But use  the original IP address JJ Wrong..
                 in Ip2EthInstanceMsg Its checking the resolved IP address...*/
           /* xArpRequest.xEntry.dwIpAddr = pxArpPend->dwOriginalIpAddr;*/
           xArpRequest.xEntry.dwIpAddr = dwSrcIpAddr;
            /* ... And the found  ethernet address. */
            MOC_MEMCPY((ubyte *)xArpRequest.xEntry.aoEthAddr,(ubyte *) poArp, (ubyte4)ARP_ETHLEN);

            /* Delete the item */
            (void)DLLIST_remove(&pxArp->dllPending);
            FREE(pxArpPend);

            /* signals resolution */
            ASSERT(pxArp->pfnNetCbk);
            pxArp->pfnNetCbk(pxArp->hNetCbk,(OCTET)ARPCBK_RESOLVED,
                             (H_NETDATA)&xArpRequest);
            ARP_CHECKPOINT(dbg_dwArpRxCbkLine);
          }
          NETPAYLOAD_DELUSER(pxPayload);
          break;
        }
      } else {
        ARP_CHECKPOINT(dbg_dwArpRxCbkLine);
        NETPAYLOAD_DELUSER(pxPayload);
        break;
      }
    }

    SNMP( xTcpipData.ifNum[(pxEthId->oIfIdx == 0) ? 0 : 1].ifInNUcastPkts++ );

    /* Now check if the request was an ARP REQUEST for one of our own
       addresses.. */
    if ((WORD)ARPOP_ARPREQUEST != wOpCode &&
        (WORD)ARPOP_RARPREQUEST != wOpCode) {
      ARP_CHECKPOINT(dbg_dwArpRxCbkLine);
      NETPAYLOAD_DELUSER(pxPayload);
      break;
    }

    ARP_CHECKPOINT(dbg_dwArpRxCbkLine);

    /* ignore requests not destined to us (including broadcast ones) */
    if (
        (IPADDRT_OUTSIDE == oSrcIpAddrType) ||
        ((IPADDRT_MYADDR != oDstIpAddrType) &&
         (IPADDRT_LOOPBACK != oDstIpAddrType))) {
      ARP_CHECKPOINT(dbg_dwArpRxCbkLine);
      NETPAYLOAD_DELUSER(pxPayload);
      break;
    }

    /* Check that the ethernet header source address and arp packet
       source address are the same */
    MOC_MEMCMP(poArp, pxEthId->aoAddr, (ubyte4)ARP_ETHLEN, &cmpResult);
    if (0 != cmpResult) {
      ARP_CHECKPOINT(dbg_dwArpRxCbkLine);
      NETPAYLOAD_DELUSER(pxPayload);
      break;
    }

    ARP_CHECKPOINT(dbg_dwArpRxCbkLine);

    /*
     *The request is valid so create the reply packet - use the same pxPayload.
     */
    {
      ETHID xEthId;
      DWORD dwTemp;
      WORD wTemp;

      /* Get the source eth address to use for the dest */
      MOC_MEMCPY((ubyte *)xEthId.aoAddr,(ubyte *) poArp, (ubyte4)ARP_ETHLEN);

      /* Copy in the op code */
      if ((WORD)ARPOP_ARPREQUEST == wOpCode) {
        wTemp = htons((WORD)ARPOP_ARPREPLY);
      } else {
        wTemp = htons((WORD)ARPOP_RARPREPLY);
      }
      MOC_MEMCPY((ubyte *)poArp-ARP_OPLEN, (ubyte *)&wTemp, (ubyte4)ARP_OPLEN);

      /* Copy the src eth addr to the dest eth addr */
      MOC_MEMCPY((ubyte *)(poArp+ARP_ETHLEN+ARP_IPLEN),(ubyte *) poArp, (ubyte4)ARP_ETHLEN);

      /* Copy in our ethernet address. */
      MOC_MEMCPY((ubyte *)poArp,(ubyte *) pxArp->aaoIfEthAddr[pxEthId->oIfIdx],
             (ubyte4)ARP_ETHLEN);

      /*  Copy in our IP address (the previous dest address) */
      dwTemp = htonl(dwDstIpAddr);
      MOC_MEMCPY((ubyte *)(poArp+ARP_ETHLEN), (ubyte *)&dwTemp,
              (ubyte4)ARP_IPLEN);

      /*   Copy in the dest IP address (the previous src address) */
      dwTemp = htonl(dwSrcIpAddr);
      MOC_MEMCPY((ubyte *)(poArp+(ARP_ETHLEN*2)+ARP_IPLEN), (ubyte *)&dwTemp,
              (ubyte4)ARP_IPLEN);

      /*copy info from ETHID to ETHID*/
      xEthId.oIfIdx = pxEthId->oIfIdx;
      xEthId.wVlan = pxEthId->wVlan;

      /* Enforce the size of the packet (to eliminate 1 extra byte) */
      pxAccess->wLength = ARPPACKET_MINSIZE;

      /*send the packet*/
      ASSERT(pxArp->pfnLLWrite != NULL);
      if ((WORD)ARPOP_ARPREQUEST == wOpCode) {
        pxArp->pfnLLWrite(pxArp->hLL,pxArp->hLLIf,pxPacket,pxAccess,
                          (H_NETDATA)&xEthId);
      } else {
        pxArp->pfnLLWrite(pxArp->hLL,pxArp->hRarpLLIf,pxPacket,pxAccess,
                          (H_NETDATA)&xEthId);
      }
    }
  } while(0);

  return lReturn;
}

/*
 * ArpInstanceRcv
 *  Arp Instance Rcv function
 *   Follows PFN_NETRXCBK def.
 *
 *   Args:
 *    hArp                       Instance Handle
 *    hIf                        LL interface handle as provided by
 *                               ArpInstanceLLInterfaceCreate
 *    pxPacket                   packet
 *    pxAccess                   NETPACKETACCESS pointer
 *    hData                      NETIFID pointer
 *
 *   Return:
 *    Number of bytes received or a <0 error code
 */
LONG ArpInstanceRcv(H_NETINSTANCE hArp,
                    H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,
                    NETPACKETACCESS *pxAccess,
                    H_NETDATA hData)
{
  ARPSTATE *pxArp;
  LONG lReturn;
  OCTET *poArp;
  WORD wOpCode;
  ETHID *pxEthId;
  sbyte4 cmpResult;

  pxArp = (ARPSTATE *)hArp;
  ARP_CHECK_STATE(pxArp);
  ASSERT(hData != 0);

  pxEthId = (ETHID*)hData;

  lReturn = (LONG)pxAccess->wLength;

  ARP_CHECKPOINT(dbg_dwArpRxCbkLine);

  /* Set the pointer to the start of the header */
  poArp = (pxPacket->pxPayload->poPayload) + pxAccess->wOffset;
  ARP_CHECKPOINT(dbg_dwArpRxCbkLine);

  /* Check for Ethernet address length, hardware type */
  /* IP protocol type, and protocol address length */
  MOC_MEMCMP(poArp, pxArp->aoArpHeader, (ubyte4)ARP_HRDLEN, &cmpResult);
  if (0 != cmpResult) {
    SNMP( xTcpipData.ifNum[(pxEthId->oIfIdx == 0) ? 0 : 1].ifInErrors++ );
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    ARP_CHECKPOINT(dbg_dwArpRxCbkLine);
    return (LONG)NETERR_BADVALUE;
  }
  ARP_CHECKPOINT(dbg_dwArpRxCbkLine);

  /* Get the op code */
  poArp += ARP_HRDLEN;
  MOC_MEMCPY((ubyte *)&wOpCode, (ubyte *)poArp, (ubyte4)ARP_OPLEN);
  wOpCode = ntohs(wOpCode);
  poArp += ARP_OPLEN;
  /* NB: poArp points to the source ethernet address in the arp packet */

  /* Only accept arp requests, arp replies and rarp requests */
  if ((WORD)ARPOP_ARPREPLY != wOpCode &&
      (WORD)ARPOP_ARPREQUEST != wOpCode &&
      (WORD)ARPOP_RARPREQUEST != wOpCode) {
    ARP_CHECKPOINT(dbg_dwArpRxCbkLine);
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    return lReturn;
  }

  lReturn = _ArpRcv(hArp, hIf, pxPacket, pxAccess, hData);

  return lReturn;
}



/*
 * ArpInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hArp                        Arp Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG ArpInstanceProcess(H_NETINSTANCE hArp)
{
  ARPSTATE *pxArp;
  ARPPEND *pxArpPend;
  DWORD dwTime;
  ARPREQUEST *pxArpRequest;
  DWORD dwArpRefreshTime = 0;
  DWORD dwMinimumWaitTime = (DWORD)ARPTIME_MAXPROCESS;

  DWORD temp = 0; /*Remove after testing*/

  pxArp = (ARPSTATE *)hArp;
  ARP_CHECK_STATE(pxArp);

  /*dwTime = (DWORD)NetGlobalTimerGet();*/
  dwTime = (DWORD)NetGetMsecTime();
  dwArpRefreshTime = pxArp->dwLastArpRefreshTime;

#ifdef ARP_TIME_RETRY
  if((dwTime - pxArp->dwArpLastRetryTime) >= pxArp->dwArpRetryTime) {
#endif
    DLLIST_head(&pxArp->dllPending);
    while ((pxArpPend = DLLIST_read(&pxArp->dllPending)) != NULL) {
#ifdef ARP_TIME_RETRY
#else
      if (pxArpPend->dwTime >= (DWORD)ARPTIME_RETRY ) {
#endif
        /* Copy the Arp Request address */
        pxArpRequest = &(pxArpPend->xRequest);

        if ((INT)0 == ArpFind(pxArp, &(pxArpRequest->xEntry), TRUE)) {
          /* The dest address has been resolved - delete the item */
          (void)DLLIST_remove(&pxArp->dllPending);
          FREE(pxArpPend);
        }
        else if (pxArpPend->oTries >= ARPTRIES_MAX) {
          pxArpRequest->xEntry.dwIpAddr = pxArpPend->dwOriginalIpAddr;

          /* Delete the item */
          pxArpPend = DLLIST_remove(&pxArp->dllPending);

#ifdef ARP_REQ_ON_TIMEOUT
          /* remove entry from ARP table as was not re-acquired */
          ArpDeleteIfExist(pxArp, (ARPENTRY *)&(pxArpRequest->xEntry));
#endif

          /* Inform the registered instance using the callback fn */
          ASSERT(pxArp->pfnNetCbk);
          pxArp->pfnNetCbk(pxArp->hNetCbk,
                           (OCTET)ARPCBK_FAILURE,
                           (H_NETDATA)pxArpRequest);

          FREE(pxArpPend);
        }
        else {
          /* Send another request */
          if ((LONG)0 == _ArpSendRequest(pxArp, pxArpRequest)) {
            (pxArpPend->oTries)++;
            pxArpPend->dwTime = dwTime;
          }
          DLLIST_next(&pxArp->dllPending);
        }
#ifdef ARP_TIME_RETRY
#else
      } /*end of if (pxArpPend->dwTime >= (DWORD)ARPTIME_RETRY )*/
      else {
        ASSERT((dwTime > pxArpPend->dwTime) &&
               (ARPTIME_RETRY > (dwTime > pxArpPend->dwTime)));
        if (dwMinimumWaitTime > ARPTIME_RETRY - (dwTime - (pxArpPend->dwTime))) {
          dwMinimumWaitTime = ARPTIME_RETRY - (dwTime - (pxArpPend->dwTime));
        }
        DLLIST_next(&pxArp->dllPending);
      }
#endif
    } /*end of while((pxArpPend = DLLIST_read(&pxArp->dllPending)) != NULL)*/
#ifdef ARP_TIME_RETRY
    pxArp->dwArpLastRetryTime = dwTime; /*Set the previous time to the current time*/
  } /* end of if*/
#endif

  ASSERT(dwTime > dwArpRefreshTime);
  if (dwTime - dwArpRefreshTime >= (DWORD)ARPTIME_REFRESHTABLE) {
    ArpRefreshTable(pxArp);
    pxArp->dwLastArpRefreshTime = dwArpRefreshTime = dwTime;

    ARP_DBG_VAR({
      if (dbg_dwArpPrintTable) {
        dbgArpPrintTable(pxArp);
        dbg_dwArpPrintTable = 0;
      }
      if (dbg_dwArpPrintHash) {
        dbgArpPrintHash(pxArp);
        dbg_dwArpPrintHash = 0;
      }
    });
  }

#ifdef ARP_TIME_RETRY
#else
  if (dwMinimumWaitTime > ARPTIME_REFRESHTABLE - (dwTime - dwArpRefreshTime)) {
    dwMinimumWaitTime = ARPTIME_REFRESHTABLE - (dwTime - dwArpRefreshTime);
  }
  ASSERT(dwMinimumWaitTime <= ARPTIME_MAXPROCESS);
  if (dwMinimumWaitTime < ARPTIME_MINPROCESS) {
    dwMinimumWaitTime = ARPTIME_MINPROCESS;
  }
#endif
  return (LONG)dwMinimumWaitTime;
}


/*****************************************************************************
 *
 * Local Function Implementation
 *
 *****************************************************************************/

/***************************************************************************
*  Create and send an ARP REQUEST packet.
*
*  par: dst_IP   - destination IP address
*
*  ret: 0 == sucess, < 0 == error
****************************************************************************/
LONG _ArpSendRequest(ARPSTATE *pxArp, ARPREQUEST *pxArpRequest)
{
  NETPACKET xPacket;
  NETPACKETACCESS xNetPktAccess;
  OCTET *poPayload;
  WORD wPacketLength;
  LONG lReturn;
  WORD wTemp;
  ETHID xEthId;
  ARPENTRY *pxEntry;
  DWORD ipaddr;

  ARP_CHECK_STATE(pxArp);
  ASSERT(pxArpRequest);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ARP_DBGP(DBGLVL_REPETITIVE,"_ArpSendRequest: who has %ld.%ld.%ld.%ld ?  oIfIdx %d\n",
                              IPADDRDISPLAY(pxArpRequest->xEntry.dwIpAddr),
                              pxArpRequest->xEntry.oIfIdx);*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_ArpSendRequest: who has ", pxArpRequest->xEntry.dwIpAddr);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, " ?  oIfIdx ", pxArpRequest->xEntry.oIfIdx);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  lReturn = (LONG)0;

  pxEntry = &(pxArpRequest->xEntry);

  /*
   *payload creation and allocation
   */
  wPacketLength = (WORD)(pxArp->wOffset +
                         ETH_MINLEN + /*ARPPACKET_MINSIZE +*/
                         pxArp->wTrailer);

  xNetPktAccess.wOffset = pxArp->wOffset;
  xNetPktAccess.wLength = ARPPACKET_MINSIZE;

  ASSERT(pxArp->pfnMalloc && pxArp->pfnFree);
  poPayload = (OCTET*) pxArp->pfnMalloc(wPacketLength);
  ASSERT(poPayload);

/*MG  MOC_MEMSET((ubyte *)poPayload,0xbb,wPacketLength);*/

  NETPAYLOAD_CREATE((&(xPacket.pxPayload)),pxArp->pfnFree,pxArp->pxMutex,
                    poPayload,wPacketLength);
  if(NULL == xPacket.pxPayload)
  {
      lReturn = -1;
      DEBUG_ERROR(DEBUG_MOC_IPV4, "Error:_ArpSendGRequest - NETPAYLOAD_CREATE failed : %d",lReturn);
      pxArp->pfnFree(poPayload);
      return lReturn;;
  }
  /*
   * Fill in the request.
   */
  poPayload += pxArp->wOffset;
  /* Copy in the header */
  MOC_MEMCPY((ubyte *)poPayload, (ubyte *)pxArp->aoArpHeader, (ubyte4)ARP_HRDLEN);
  poPayload += ARP_HRDLEN;
  /* Copy in the op code */
  wTemp = htons((WORD)ARPOP_ARPREQUEST);
  MOC_MEMCPY((ubyte *)poPayload, (ubyte *)&wTemp, (ubyte4)ARP_OPLEN);
  poPayload += ARP_OPLEN;
  /* Copy in our ethernet address. */
  MOC_MEMCPY((ubyte *)poPayload, (ubyte *)pxArp->aaoIfEthAddr[pxArpRequest->xEntry.oIfIdx],
         (ubyte4)ARP_ETHLEN);
  poPayload += ARP_ETHLEN;
  /* Copy in our IP address */
  {
    IPTABLEENTRY xIpEntry;

    xIpEntry.oIfIdx = pxArpRequest->xEntry.oIfIdx;
    xIpEntry.wDefaultVlan = pxArpRequest->xEntry.wVlan;
    xIpEntry.eAddrType = IPADDRT_ANY;
    xIpEntry.dwAddr = (DWORD)0;

    IpTableMsg(IPTABLEMSG_GETDEFAULT,(H_NETDATA)&xIpEntry);
    /* Delete the packet if no IP address found.
     * e.g. This can happen when when changing the
     * configuration of an interface */
    if (xIpEntry.dwAddr == 0) {
      NETPAYLOAD_DELUSER(xPacket.pxPayload);
      return -1;
    }
    ipaddr = htonl(xIpEntry.dwAddr);
    MOC_MEMCPY((ubyte *)poPayload, (ubyte *)&(ipaddr),(ubyte4)ARP_IPLEN);
  }
  poPayload += ARP_IPLEN;
  /* Set the target eth address to 0 */
  MOC_MEMSET((ubyte *)poPayload, (OCTET)0, (ubyte4)ARP_ETHLEN);
  poPayload += ARP_ETHLEN;

  /* Copy in the target IP address */
  ipaddr = htonl(pxEntry->dwIpAddr);
  MOC_MEMCPY((ubyte *)poPayload, (ubyte *)&(ipaddr),(ubyte4)ARP_IPLEN);

  /* Get the broadcast eth address to use for the dest */
  MOC_MEMCPY((ubyte *)xEthId.aoAddr, (ubyte *)pxArp->aoBcastEthAddr, (ubyte4)ARP_ETHLEN);
  /* Copy the interface data */
  xEthId.oIfIdx = pxEntry->oIfIdx;
  xEthId.wVlan = pxEntry->wVlan;

  /*send the packet*/
  ASSERT(pxArp->pfnLLWrite != NULL);
  pxArp->pfnLLWrite(pxArp->hLL,pxArp->hLLIf,&xPacket,&xNetPktAccess,
                    (H_NETDATA)&xEthId);
  return lReturn;
}


/*
 * _ArpFindPending
 *  Return 0 if the IP addr is found
 *
 *  Args:
 *   pxItem             ARPPEND pointer
 *   pxKey              DWORD IP address
 *
 *  Return:
 *   0 if identification
 *  -1 if error
 */
LONG _ArpFindPending(void *pxItem,void *pxKey)
{
  ARPENTRY *pxKeyEntry = (ARPENTRY *)pxKey;
  ARPENTRY *pxEntry = &(((ARPPEND *)pxItem)->xRequest.xEntry);

  if ((pxEntry->dwIpAddr == pxKeyEntry->dwIpAddr) &&
      ((pxEntry->oIfIdx == pxKeyEntry->oIfIdx) ||
       (pxKeyEntry->oIfIdx == NETIFIDX_ANY) ||
       (pxEntry->oIfIdx == NETIFIDX_ANY)) &&
      (((pxEntry->wVlan & NETVLAN_VIDMASK) ==
         (pxKeyEntry->wVlan & NETVLAN_VIDMASK)) ||
       (pxKeyEntry->wVlan == NETVLAN_ANY) ||
       (pxEntry->wVlan == NETVLAN_ANY))) {
    return (LONG)0;
  }

  return (LONG)-1;
}

/****************************************************************************
 * _ArpTableCreate - Allocate and initialize the ARP table
 *
 *  param: ARPSTATE *
 * return: void
 ****************************************************************************/
void _ArpTableCreate(ARPSTATE *pxArp)
{
  OCTET oIdx;

  ARP_CHECK_STATE(pxArp);

  /* Create the ARP table */
#ifdef ARP_CACHE_32
  ARP_DBG_ASSERT(pxArp->oArpTableSize != (OCTET)0);
  pxArp->pxArpTable = MALLOC(pxArp->oArpTableSize* sizeof(ARPENTRYSTATE));
  ARP_DBG_ASSERT(pxArp->pxArpTable);
  MOC_MEMSET ((ubyte *)(pxArp->pxArpTable),0,
            pxArp->oArpTableSize* sizeof(ARPENTRYSTATE));
  for (oIdx = 0; oIdx < pxArp->oArpTableSize - 1; oIdx++) {
    pxArp->pxArpTable[oIdx].pxNext = &(pxArp->pxArpTable[oIdx + 1]);
  }
  pxArp->pxArpTable[pxArp->oArpTableSize - 1].pxNext = NULL;
  pxArp->pxFirstFreeArpEntry = &(pxArp->pxArpTable[0]);
  ARP_DBG_ASSERT(pxArp->oArpHashSize != (OCTET)0);
  /* Create the hash table for 32 entries*/
  pxArp->apxArpHashTable = MALLOC(pxArp->oArpHashSize*sizeof(void *));
#else
  ARP_DBG_ASSERT(pxArp->wArpHashSize != (OCTET)0);
  /* Create the hash table */
  pxArp->apxArpHashTable = MALLOC(pxArp->wArpHashSize*sizeof(void *));
#endif
  ARP_DBG_ASSERT(pxArp->apxArpHashTable);
#ifdef ARP_CACHE_32
  MOC_MEMSET((ubyte *)(pxArp->apxArpHashTable), 0,
              pxArp->oArpHashSize*sizeof(void *));
#else
  MOC_MEMSET((ubyte *)(pxArp->apxArpHashTable), 0,
              pxArp->wArpHashSize*sizeof(void *));
#endif
}

/****************************************************************************
 * _ArpTableDestroy - Destroy the ARP table
 *
 *  param: ARPSTATE *
 * return: void
 ****************************************************************************/
void _ArpTableDestroy(ARPSTATE *pxArp)
{
  ARP_CHECK_STATE(pxArp);

#ifdef ARP_CACHE_32
  FREE(pxArp->pxArpTable);
#endif
  FREE(pxArp->apxArpHashTable);
}



/***************************************************************************
*  Create and send an Gratuitous ARP REQUEST packet.
*
*  par: dst_IP   - destination IP address
*
*  ret: 0 == sucess, < 0 == error
****************************************************************************/
LONG _ArpSendGRequest(ARPSTATE *pxArp, OCTET oIfIdx, DWORD dwIpAddr)
{
  NETPACKET xPacket;
  NETPACKETACCESS xNetPktAccess;
  OCTET *poPayload;
  WORD wPacketLength;
  LONG lReturn;
  WORD wTemp;
  ETHID xEthId;
  DWORD ipaddr;
  ARPENTRY xGratArpEntry;

  ARP_CHECK_STATE(pxArp);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ARP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ARP_DBGP(DBGLVL_REPETITIVE,"_ArpSendGRequest: who has %ld.%ld.%ld.%ld ?  oIfIdx %d\n",
                              IPADDRDISPLAY(dwIpAddr),
                              oIfIdx);*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "_ArpSendGRequest: who has ", dwIpAddr);
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, " ?  oIfIdx ", oIfIdx);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  lReturn = (LONG)0;

  /*AN: Code changes for adding entries within the ARP Table for Gratitous ARP*/
  /*Create a new ARP entry for Gratitous ARP*/
  xGratArpEntry.dwIpAddr = dwIpAddr;
  MOC_MEMCPY(xGratArpEntry.aoEthAddr, (ubyte *)pxArp->aaoIfEthAddr[oIfIdx],
             (ubyte4)ARP_ETHLEN);
  xGratArpEntry.wVlan = 0;
  xGratArpEntry.oIfIdx = oIfIdx;
  xGratArpEntry.eArpFlag = E_ARPLOCAL;
  /*Add this entry into the ARP table*/
  ArpAdd(pxArp, &xGratArpEntry);
  /*AN: Code changes end*/

  /*
   *payload creation and allocation
   */
  wPacketLength = (WORD)(pxArp->wOffset +
                         ETH_MINLEN + /*ARPPACKET_MINSIZE +*/
                         pxArp->wTrailer);

  xNetPktAccess.wOffset = pxArp->wOffset;
  xNetPktAccess.wLength = ARPPACKET_MINSIZE;

  ASSERT(pxArp->pfnMalloc && pxArp->pfnFree);
  poPayload = (OCTET*) pxArp->pfnMalloc(wPacketLength);
  ASSERT(poPayload);

/*MG  MOC_MEMSET((ubyte *)poPayload,0xbb,wPacketLength);*/

  NETPAYLOAD_CREATE((&(xPacket.pxPayload)),pxArp->pfnFree,pxArp->pxMutex,
                    poPayload,wPacketLength);
  if(NULL == xPacket.pxPayload)
  {
      lReturn = -1;
      DEBUG_ERROR(DEBUG_MOC_IPV4, "Error:_ArpSendGRequest - NETPAYLOAD_CREATE failed : %d",lReturn);
      pxArp->pfnFree(poPayload);
      return lReturn;;
  }
  /*
   * Fill in the request.
   */
  poPayload += pxArp->wOffset;
  /* Copy in the header */
  MOC_MEMCPY((ubyte *)poPayload, (ubyte *)pxArp->aoArpHeader, (ubyte4)ARP_HRDLEN);
  poPayload += ARP_HRDLEN;
  /* Copy in the op code */
  wTemp = htons((WORD)ARPOP_ARPREQUEST);
  MOC_MEMCPY((ubyte *)poPayload, (ubyte *)&wTemp, (ubyte4)ARP_OPLEN);
  poPayload += ARP_OPLEN;
  /* Copy in our ethernet address. */
  MOC_MEMCPY((ubyte *)poPayload, (ubyte *)pxArp->aaoIfEthAddr[oIfIdx],
         (ubyte4)ARP_ETHLEN);
  poPayload += ARP_ETHLEN;
#if 0
  /* Copy in our IP address */
  {
    IPTABLEENTRY xIpEntry;

    xIpEntry.oIfIdx = oIfIdx;
    xIpEntry.wDefaultVlan = NETVLAN_DEFAULT;
    xIpEntry.eAddrType = IPADDRT_ANY;
    xIpEntry.dwAddr = (DWORD)0;

    IpTableMsg(IPTABLEMSG_GETDEFAULT,(H_NETDATA)&xIpEntry);
    /* Delete the packet if no IP address found.
     * e.g. This can happen when when changing the
     * configuration of an interface */
    if (xIpEntry.dwAddr == 0) {
      NETPAYLOAD_DELUSER(xPacket.pxPayload);
      return -1;
    }
    ipaddr = htonl(dwIpAddr);
    MOC_MEMCPY((ubyte *)poPayload, (ubyte *)&(ipaddr),(ubyte4)ARP_IPLEN);
  }
#else
    ipaddr = htonl(dwIpAddr);
    MOC_MEMCPY((ubyte *)poPayload, (ubyte *)&(ipaddr),(ubyte4)ARP_IPLEN);
#endif
  poPayload += ARP_IPLEN;
  /* Set the target eth address to 0 */
  MOC_MEMSET((ubyte *)poPayload, (OCTET)0, (ubyte4)ARP_ETHLEN);
  poPayload += ARP_ETHLEN;

  /* Copy in the target IP address */
  ipaddr = htonl(dwIpAddr);
  MOC_MEMCPY((ubyte *)poPayload, (ubyte *)&(ipaddr),(ubyte4)ARP_IPLEN);

  /* Get the broadcast eth address to use for the dest */
  MOC_MEMCPY((ubyte *)xEthId.aoAddr, (ubyte *)pxArp->aoBcastEthAddr, (ubyte4)ARP_ETHLEN);
  /* Copy the interface data */
  xEthId.oIfIdx = oIfIdx;
  xEthId.wVlan = NETVLAN_DEFAULT;

  /*send the packet*/
  ASSERT(pxArp->pfnLLWrite != NULL);
  pxArp->pfnLLWrite(pxArp->hLL,pxArp->hLLIf,&xPacket,&xNetPktAccess,
                    (H_NETDATA)&xEthId);
  return lReturn;
}


