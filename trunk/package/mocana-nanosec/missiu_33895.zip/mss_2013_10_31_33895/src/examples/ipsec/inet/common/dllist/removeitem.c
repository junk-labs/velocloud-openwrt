#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

DLLIST_ITEM *DLLIST_remove_ITEM(DLLIST *dllist, DLLIST_ITEM *dllitem)
{
  DLLIST_ITEM *tmp1;
  DLLIST_ITEM *new_cur;
  void *tmpitem;
  
  dllist->cur = dllitem;

  if (dllist->cur != NULL) {
    tmp1 = dllist->cur;
    new_cur = tmp1->next;
    tmpitem = tmp1->item;
    if ((tmp1->prev == NULL) && (tmp1->next == NULL)) {
      dllist->head = NULL;
      dllist->tail = NULL;
      del_DLLIST_ITEM(dllist,dllist->cur);
    } else if (tmp1->prev == NULL) {
      tmp1 = tmp1->next;
      tmp1->prev = NULL;
      dllist->head = tmp1;
      del_DLLIST_ITEM(dllist,dllist->cur);
    } else if (tmp1->next == NULL) {
      tmp1 = tmp1->prev;
      tmp1->next = NULL;
      dllist->tail = tmp1;
      del_DLLIST_ITEM(dllist,dllist->cur);
    } else {
      tmp1->prev->next = tmp1->next;
      tmp1->next->prev = tmp1->prev;
      del_DLLIST_ITEM(dllist,dllist->cur);
    }
    dllist->cur = new_cur;
    dllist->count--;
    return(dllitem);
  }
  return(NULL);
}
