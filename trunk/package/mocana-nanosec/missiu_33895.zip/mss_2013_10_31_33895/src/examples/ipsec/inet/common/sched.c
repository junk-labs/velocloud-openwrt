/*
 * sched.c
 *
 * vars for scheduler support
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "NNstyle.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "scheduler.h"
#include "cllist.h"
#include "sched_private.h"


#if defined(_AUDACITYT2)
#  include "kodiacdefs.h"
#endif
#if defined(_VCPEX) || defined(_AUDACITY)
#  include "vcpdefs.h"
#endif



#if defined(_VCPEX) || defined(_AUDACITY)
#  define SCHED_CLOCK() (vcp[riface_timer])
#else
#  define SCHED_CLOCK() 0
#endif

#if defined(SCHED_STATS)
#  include "xstat.h"
#  include <stdio.h>

#  define SCHEDUSR_STAT_DEF(dw) DWORD dw
#  define SCHEDUSR_STAT_START_TIME(dw) dw = SCHED_CLOCK()
#  define SCHEDUSR_STAT_DONE_TIME(x, dw) \
        XSTAT_RECORD((x), (SCHED_CLOCK() - (dw)))
#  define SCHEDOVERHEAD_STAT_DEF(dw) DWORD dw
#  define SCHEDOVERHEAD_STAT_START_TIME(dw) dw = SCHED_CLOCK()
#  define SCHEDOVERHEAD_STAT_DONE_TIME(x, dw) \
        XSTAT_RECORD((x), (SCHED_CLOCK() - (dw)))

DWORD dbg_bSchedReport = FALSE;
DWORD dbg_bSchedResetStats = FALSE;
DWORD dbg_bSchedResetAfterReport = FALSE;

#else /* if defined(SCHED_STATS) */
#  define SCHEDUSR_STAT_DEF(dw)
#  define SCHEDUSR_STAT_START_TIME(dw)
#  define SCHEDUSR_STAT_DONE_TIME(x, dw)
#  define SCHEDOVERHEAD_STAT_DEF(dw)
#  define SCHEDOVERHEAD_STAT_START_TIME(dw)
#  define SCHEDOVERHEAD_STAT_DONE_TIME(x, dw)
#endif /* if defined(SCHED_STATS) else */

/********************************************************************
 *
 * Private variables
 *
 ********************************************************************/

DWORD bSchedInitialized = FALSE;
L_SCHEDULER lstScheduler;


/********************************************************************
 *
 * public variables
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Private Functions
 *
 ********************************************************************/


/*
 * set SCHED_USER_DO_RELEASE for all users with lower than the given
 * priority that can release, including SCHED_PRIORITY_OFF and delayed users
 *
 * NOTE: may be called from SchedSetPriority() which may be called
 *     from an ISR
 *
 * parms:
 *    pScheduler        the scheduler
 *    ePriority        the priority
 */
static void SchedSetReleaseUsers(SCHEDULER *pScheduler,
                 E_SCHED_PRIORITY ePriority)
{
  SCHED_USER *pSaveCurr;
  SCHED_USER *pSchedUser;

  /* save the current place in the CLL */
  DBG_CHKPT;
  pSaveCurr = CllGetCurr(pScheduler->lstUsers);
  if (NULL == pSaveCurr)
    return;

  /* start at the anchor and check each user    */
  pSchedUser = CllGetAnchor(pScheduler->lstUsers);
  CllSetCurr(pScheduler->lstUsers, pSchedUser);
  do {
    /* if can release and has lower priority, release it */
    if ((pSchedUser->fFlags & SCHED_USER_CAN_RELEASE) &&
    (pSchedUser->ePriority < ePriority)) {
      pSchedUser->fFlags |= SCHED_USER_DO_RELEASE;
    }
    /* next user */
    CllNext(pScheduler->lstUsers);
    pSchedUser = CllGetCurr(pScheduler->lstUsers);
  } while (pSchedUser != CllGetAnchor(pScheduler->lstUsers));

  /* restore the saved place in the CLL */
  CllSetCurr(pScheduler->lstUsers, pSaveCurr);
  DBG_CHKPT;

}


/*
 * release all users with SCHED_USER_DO_RELEASE set
 *
 * parms:
 *    pScheduler        the scheduler
 */
static void SchedDoReleaseUsers(SCHEDULER *pScheduler)
{
  SCHED_USER *pSaveCurr;
  SCHED_USER *pSchedUser;

  /* save the current place in the CLL */
  DBG_CHKPT;
  pSaveCurr = CllGetCurr(pScheduler->lstUsers);
  if (NULL == pSaveCurr)
    return;

  /* start at the anchor and check each user    */
  pSchedUser = CllGetAnchor(pScheduler->lstUsers);
  CllSetCurr(pScheduler->lstUsers, pSchedUser);
  do {
    /* if lower priority and has a Relase(), release it */
    if (pSchedUser->fFlags & SCHED_USER_DO_RELEASE) {
      (pSchedUser->Process)(pSchedUser->hInstance, 0);
      ASSERT(!(pSchedUser->fFlags & SCHED_USER_DO_RELEASE));
    }
    /* next user */
    CllNext(pScheduler->lstUsers);
    pSchedUser = CllGetCurr(pScheduler->lstUsers);
  } while (pSchedUser != CllGetAnchor(pScheduler->lstUsers));

  /* restore the saved place in the CLL */
  CllSetCurr(pScheduler->lstUsers, pSaveCurr);
  DBG_CHKPT;

}




/********************************************************************
 *
 * Public Functions
 *
 ********************************************************************/


/*
 * initialize the Scheduler
 */
void SchedInitialize(void)
{
  ASSERT(!bSchedInitialized);
  bSchedInitialized = TRUE;
  CllClear(lstScheduler);
#if !defined(_VCPEX) && !defined(_AUDACITY)
    printf("Unrecoverable error: sched can only be used on VCPex!!!\n");
    /* because timer, IRQ supress, disable IRQs, Cll*Sup() not avail */
    ASSERT(0);
    while (1) ;
#endif
}



/*
 * terminate the Scheduler
 */
void SchedTerminate(void)
{
  ASSERT(bSchedInitialized);
  ASSERT(0 == CllGetCount(lstScheduler));
  bSchedInitialized = FALSE;
}




/*
 * Create a Scheduler
 *
 * returns:
 *    scheduler handle, NULL if error
 */
H_SCHED SchedCreate(void)
{
  SCHEDULER *pScheduler;

  /* get a schedule */
  ASSERT(bSchedInitialized);
  pScheduler = (SCHEDULER *) MALLOC(sizeof(SCHEDULER));
  ASSERT(NULL != pScheduler);

  /* initialize it and return it */
  memset(pScheduler, 0x00, sizeof(SCHEDULER));
  CllClear(pScheduler->lstUsers);
  pScheduler->dwMagic = SCHEDULER_MAGIC;
  CllInsertPreAnchor(lstScheduler, pScheduler);
  return (H_SCHED) pScheduler;
}


/*
 * Destroy a Scheduler
 *
 * parms:
 *    hScheduler    scheduler to destroy
 */
void SchedDestroy(H_SCHED hScheduler)
{
#if !defined(NDEBUG)
  E_SCHED_PRIORITY ePriority;
#endif

  SCHEDULER *pScheduler = (SCHEDULER *) hScheduler;

  ASSERT(bSchedInitialized);
  ASSERT(0 == CllGetCount(pScheduler->lstUsers));
  ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);
  DEBUG({
    for (ePriority = SCHED_PRIORITY_OFF;
     ePriority < SCHED_PRIORITY_ENUMMAX;
     ePriority++) {
      ASSERT(0 == pScheduler->aoPriorityCnt[ePriority]);
    }
  });

  /* find the scheduler */
  CllFind(lstScheduler, pScheduler);
  ASSERT(CllWasFound(lstScheduler));

  /* remove from the list and free it */
  if (CllWasFound(lstScheduler)) {
    CllDel(lstScheduler);
    pScheduler->dwMagic = 0;
    FREE(pScheduler);
  }
}



/*
 * attach to given scheduler as a nested scheduler in the
 * specified super scheduler, if any of the users of the
 * nested scheduler panic then the nested scheduler will
 * raise its priority to PANIC in the super scheduler.
 *
 * parms:
 *    hScheduler        the nested scheduler
 *    hSuperScheduler        the super scheduler
 *
 * returns:
 *    nested schedule user handle
 */
H_SCHED_SCHED SchedAttachSched(H_SCHED hScheduler,
                   H_SCHED hSuperScheduler)
{
  SCHEDULER *pScheduler = (SCHEDULER *) hScheduler;

  ASSERT(bSchedInitialized);
  ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);
  ASSERT(NULL == pScheduler->hSuperSchedUser);

  /* register with the super scheduler    */
  pScheduler->hSuperSchedUser = SchedRegisterUser(hSuperScheduler, hScheduler,
                        SchedProcess,
                        SCHED_USER_CAN_RELEASE_EARLY);
  SchedRegisterName(pScheduler->hSuperSchedUser, "Scheduler");

  SchedSetPriority(pScheduler->hSuperSchedUser,pScheduler->eCurrPriority);
  return (H_SCHED_SCHED) pScheduler->hSuperSchedUser;
}


/*
 * Detach a scheduler from a (super) scheduler (a super scheduler
 * is a scheduler that has a scheduler user)
 *
 * parms:
 *    hSchedAttach        the nested scheduler user handle
 */
void SchedDetachSched(H_SCHED_SCHED hSchedAttach)
{
  SCHED_USER *pSchedUser = (SCHED_USER *) hSchedAttach;

  ASSERT(bSchedInitialized);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  /* unregister with the super scheduler    */
  SchedUnregisterUser((H_SCHED_USER) pSchedUser);
}




/*
 * set the threshold which is checked for early return from the scheduler:
 * return if all non-SCHED_PRIORITY_OFF users have a delay > dwDelayThreshold
 *
 * parms:
 *    hScheduler        the scheduler handle
 *    dwDelayThreshold    the threshold
 */
void SchedSetReturnDelayThreshold(H_SCHED hScheduler, DWORD dwDelayThreshold)
{
  SCHEDULER *pScheduler = (SCHEDULER *) hScheduler;

  ASSERT(bSchedInitialized);
  ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);
  pScheduler->dwDelayThreshold = dwDelayThreshold;
}




/*
 * Register a process for scheduling. Scheduling for the process is
 * disabled by default, SchedSetPriority() must be called to
 * enable scheduling for the process.
 *
 * parms:
 *    hScheduler        scheduler to register with
 *    hInstance        instantiation handle for the module
 *      Process                 user's Process() function
 *      eSchedRelease           inidcates if user can release early
 *
 * returns:
 *    process schedule handle, NULL if error
 */
H_SCHED_USER SchedRegisterUser(H_SCHED hScheduler, void *hInstance,
                               SCHED_PROCESS Process,
                   E_SCHED_USER_RELEASE eSchedRelease)
{
  SCHED_USER *pSchedUser;
  SCHEDULER *pScheduler = (SCHEDULER *) hScheduler;

  /* get a schedule */
  ASSERT(bSchedInitialized);
  ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);
  pSchedUser = (SCHED_USER *) MALLOC(sizeof(SCHED_USER));
  ASSERT(NULL != pSchedUser);

  /* initialize it and queue it */
  memset(pSchedUser, 0x00, sizeof(SCHED_USER));
  pSchedUser->pScheduler = pScheduler;
  pSchedUser->hInstance = hInstance;
  pSchedUser->Process = Process;
  pSchedUser->ePriority = SCHED_PRIORITY_OFF;
  if (SCHED_USER_CAN_RELEASE_EARLY == eSchedRelease)
    pSchedUser->fFlags |= SCHED_USER_CAN_RELEASE;
  pSchedUser->dwMagic = SCHED_USER_MAGIC;
#if defined(SCHED_PRIORITY_CHANGE_STATS)
  pSchedUser->xPriorityHistory.dwLast = NO_LAST_PRIORITY;
#endif
#if defined(_VCPEX) || defined(_AUDACITY)
  CllInsertPreAnchorSup(pScheduler->lstUsers, pSchedUser);
#endif
  pScheduler->aoPriorityCnt[pSchedUser->ePriority]++;
  ASSERT(256 > CllGetCount(pScheduler->lstUsers));
                  /* else aoPriorityCnt must be awP... */

  /* if the 1st one then reset the sweep settings    */
  if (1 == CllGetCount(pScheduler->lstUsers)) {
    pScheduler->fFlags &= ~SCHEDULER_SWEEP_ABORT;
    pScheduler->fFlags |= SCHEDULER_SWEEP_PRIORITY_OFF;
  }

  return (H_SCHED_USER) pSchedUser;

}


/*
 * unregister a process from a scheduler
 *
 * parms:
 *    hSchedUser    scheduler user handle to unregister
 */
void SchedUnregisterUser(H_SCHED_USER hSchedUser)
{
  SCHEDULER *pScheduler;
  SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  SCHED_USER *pSchedUserCurrent;

  /* save current place */
  ASSERT(bSchedInitialized);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);
  pScheduler = pSchedUser->pScheduler;
  ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);
  pSchedUserCurrent = CllGetCurr(pScheduler->lstUsers);
  ASSERT(NULL != pSchedUserCurrent);

  /* find and delete the schedule to be unregistered from the queue */
  CllFind(pScheduler->lstUsers, pSchedUser);
  ASSERT(CllWasFound(pScheduler->lstUsers));
#if defined(_VCPEX) || defined(_AUDACITY)
  CllDelSup(pScheduler->lstUsers);
#endif
  pScheduler->aoPriorityCnt[pSchedUser->ePriority]--;

  /* restore the saved place in the queue (unless that was the one    */
  /*  deleted, in which case the cursor has already been advanced)    */
  if (pSchedUserCurrent != pSchedUser)
    CllFind(pScheduler->lstUsers, pSchedUserCurrent);

  /* free it and return */
#if defined(SCHED_STATS)
  SchedReportScheduleUserStats((H_SCHED_USER) pSchedUser);
#endif
  pSchedUser->dwMagic = 0;
  FREE(pSchedUser);
  return;
}




/*
 * Schedule processes until available time is used up.
 *
 * parms:
 *    hScheduler    handle identifying scheduler instance
 *    dwTicksAvail    size of timeslice available (in clock cycles)
 *
 * returns:
 *    # ticks needed on next call
 */
DWORD SchedProcess(H_SCHED hScheduler, DWORD dwTicksAvail)
{
  SCHED_USER *pSchedUser;
  SCHEDULER *pScheduler = (SCHEDULER *) hScheduler;
  DWORD dwStartTime;
  DWORD dwTicksUsed, dwTicksLeft;
  DWORD dwDelayed, dwSweepMinDelay = 0xFFFFFFFF;
  SCHEDOVERHEAD_STAT_DEF(dwOverheadStart);

  SCHEDOVERHEAD_STAT_START_TIME(dwOverheadStart);
  ASSERT(bSchedInitialized);
  ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);

  /* keep calling stuff until the time has run out or list is empty */
  dwStartTime = SCHED_CLOCK();
  while (1) {

    /* if super scheduler requests release, then release all    */
    if ((NULL != pScheduler->hSuperSchedUser) &&
    (TRUE == SchedQueryRelease(pScheduler->hSuperSchedUser))) {
      pScheduler->fFlags |= SCHEDULER_SWEEP_ABORT;
      SchedSetReleaseUsers(pScheduler, SCHED_PRIORITY_ENUMMAX);
      SchedDoReleaseUsers(pScheduler);
      break;
    }

    /* if some user of this scheduler raised its priority,    */
    /*  then release all users that have SCHED_USER_DO_RELEASE    */
    /*   set (which will be those with lower priority)        */
    if (pScheduler->fFlags & SCHEDULER_RAISED_PRIORITY) {
      SchedDoReleaseUsers(pScheduler);
      pScheduler->fFlags &= ~SCHEDULER_RAISED_PRIORITY;
    }

    /* if no registered users, then release    */
    if (0 == CllGetCount(pScheduler->lstUsers)) {
      pScheduler->fFlags |= SCHEDULER_SWEEP_ABORT;
      break;
    }

    /* calculate # ticks yet remaining,        */
    /*  if no ticks remaining then release    */
    dwTicksUsed = (SCHED_CLOCK() - dwStartTime);
    if (dwTicksAvail <= dwTicksUsed) {
      pScheduler->fFlags |= SCHEDULER_SWEEP_ABORT;
      break;
    }
    dwTicksLeft = dwTicksAvail - dwTicksUsed;

    /* get the next schedule and then advance the list    */
    pSchedUser = CllGetCurr(pScheduler->lstUsers);
    CllNext(pScheduler->lstUsers);
    ASSERT(NULL != pSchedUser);
    ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

    /* if not delayed and high enough priority then call the process    */
    /*  (suppress IRQs in case an ISR changes the delay)        */
    /*  (races with ISR => changing a priority should turn out OK)    */
    /*  (races with ISR => setting SCHED_USER_DO_RELEASE will be caught    */
    /*   by the SchedQueryRelease() call in the Process())        */
#if defined(_VCPEX) || defined(_AUDACITY)
    PUT_VCP_REG(riface_irqsupress, 0);
    WAIT2;
    PUT_VCP_REG(riface_irqsupress, 0);
#endif
    dwDelayed = SCHED_CLOCK() - pSchedUser->dwDelayStart;
#if defined(_VCPEX) || defined(_AUDACITY)
    PUT_VCP_REG(riface_irqsupress, 0);
#endif
    if (dwDelayed >= pSchedUser->dwDelay) {
      pSchedUser->fFlags &= ~SCHED_USER_DELAY;
    }
    if (!(pSchedUser->fFlags & SCHED_USER_DELAY) &&
    (pSchedUser->ePriority >= pScheduler->eCurrPriority) &&
    (pSchedUser->ePriority > SCHED_PRIORITY_OFF)) {
      SCHEDUSR_STAT_DEF(dwInTime);

      pScheduler->pActiveUser = pSchedUser;
      SCHEDOVERHEAD_STAT_DONE_TIME(pScheduler->xSchedOverhead,dwOverheadStart);
      SCHEDUSR_STAT_START_TIME(dwInTime);
      (pSchedUser->Process)(pSchedUser->hInstance, dwTicksLeft);
      SCHEDUSR_STAT_DONE_TIME(pSchedUser->xInProcess, dwInTime);
      SCHEDOVERHEAD_STAT_START_TIME(dwOverheadStart);
      pScheduler->pActiveUser = NULL;
    }

    /* gather sweep information    */
    if (SCHED_PRIORITY_OFF != pSchedUser->ePriority) {
      /* at least one non-SCHED_PRIORITY_OFF in the sweep    */
      pScheduler->fFlags &= ~SCHEDULER_SWEEP_PRIORITY_OFF;

      /* if delayed, then see if delay is a new minimum    */
      if (pSchedUser->fFlags & SCHED_USER_DELAY) {
    /* since SCHED_USER_DELAY is set, dwDelay < pSchedUser->dwDelay    */
    if ((pSchedUser->dwDelay - dwDelayed) < dwSweepMinDelay)
      dwSweepMinDelay = pSchedUser->dwDelay - dwDelayed;
      }

      /* else not delayed, then min delay is 0    */
      else {
    dwSweepMinDelay = 0;
      }
    }


    /* check for end of a sweep through all registered users    */
    /*  (convention here is the anchor is the "start of sweep")    */
    if (CllGetCurr(pScheduler->lstUsers) ==
    CllGetAnchor(pScheduler->lstUsers)) {
      DWORD fPrevFlags;
      DWORD dwPrevSweepMinDelay;

      /* save settings for sweep just ended and    */
      /*  reset settings for next sweep        */
      fPrevFlags = pScheduler->fFlags;
      dwPrevSweepMinDelay = dwSweepMinDelay;
      pScheduler->fFlags &= ~SCHEDULER_SWEEP_ABORT;
      pScheduler->fFlags |= SCHEDULER_SWEEP_PRIORITY_OFF;
      dwSweepMinDelay = 0xFFFFFFFF;

      /* if prev was a full sweep (i.e. not aborted)    */
      /*  then check for early return            */
      if (!(fPrevFlags & SCHEDULER_SWEEP_ABORT)) {

    /* if all users were SCHED_PRIORITY_OFF in prev sweep, return    */
    if (fPrevFlags & SCHEDULER_SWEEP_PRIORITY_OFF) {
      break;
    }

    /* if all non-SCHED_PRIORITY_OFF had a delay > threshold    */
    /*  in prev sweep, return                    */
    if (dwPrevSweepMinDelay > pScheduler->dwDelayThreshold) {
      break;
    }
      } /* was a full sweep */
    } /* end of sweep */

  } /* check time and empty list */

  SCHEDOVERHEAD_STAT_DONE_TIME(pScheduler->xSchedOverhead, dwOverheadStart);
#if defined(SCHED_STATS)
  /*
   * if requested, output sched report
   */
  if (dbg_bSchedReport) {
    SchedReportStats();
    dbg_bSchedReport = FALSE;
    if (dbg_bSchedResetAfterReport) {
      SchedResetStats();
    }
  }
  if (dbg_bSchedResetStats) {
    SchedResetStats();
    dbg_bSchedResetStats = FALSE;
  }
#endif

  return 40000;
}







/*
 * SchedSetPriorityX
 *     set the priority for a registered module, if new priority is greater
 *    than the current priority then signal all lower priority users (that
 *     can) to release
 *
 * NOTE: interrupts are disabled in case an ISR calls this while it is running
 *
 * NOTE: a macro in scheduler.h translates this to SchedSetPriority()
 *
 * Arguments:
 *    hSchedUser    registered scheduler user handle
 *      ePriority    new priority, SCHED_PRIORITY_OFF = disabled
 *
 * Returns:
 *      none
 *
 * NOTE: the name of this function is changed if SCHED_STATS is defined
 *     so that a macro can replace the function call
 */
void SchedSetPriorityX(H_SCHED_USER hSchedUser, E_SCHED_PRIORITY ePriority)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  register E_SCHED_PRIORITY ePriorityReg = ePriority;
  register E_SCHED_PRIORITY eCurrPrioritySave;
  register SCHEDULER *pScheduler;
  /* DBG_PRINTF2(("hSchedUser 0x%08lX, ePriority %d\n"),
          (unsigned long) hSchedUser, ePriority); */

  /* set the new priority (only if different)    */
  ASSERT(bSchedInitialized);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);
  pScheduler = pSchedUser->pScheduler;
  ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);
  ASSERT(0 != pScheduler->aoPriorityCnt[pSchedUser->ePriority]);
#if defined(_VCPEX) || defined(_AUDACITY) || defined(_AUDACITYT2)
  DISABLE_INTERRUPTS;
#endif
  if (pSchedUser->ePriority != ePriorityReg) {

    /* change the priority counts and the priority    */
    pScheduler->aoPriorityCnt[pSchedUser->ePriority]--;
    pSchedUser->ePriority = ePriorityReg;
    pScheduler->aoPriorityCnt[ePriorityReg]++;
    eCurrPrioritySave = pScheduler->eCurrPriority;

    /* if the new priority is higher, it must become the current priority */
    if (ePriorityReg > pScheduler->eCurrPriority) {
      pScheduler->eCurrPriority = ePriorityReg;

      /* signal all lower priority users (that can) to release    */
      /*  (even _OFF and delayed), and signal the scheduler    */
      /*   that the priority has gone up (so it will call    */
      /*    release Process()'s so they can release        */
      SchedSetReleaseUsers(pScheduler, ePriorityReg);
      pScheduler->fFlags |= SCHEDULER_RAISED_PRIORITY;
    }

    /* otherwise the new priority is lower, check if current    */
    /*  priority should change                    */
    else {

      /* if no more users at current priority, find new current priority */
      while (0 == pScheduler->aoPriorityCnt[pScheduler->eCurrPriority]) {
    pScheduler->eCurrPriority--;
      }
    }

    /* if the current priority changed and this sheduler is    */
    /*  nested within another, then change the priority of this    */
    /*   nested scheduler in the super scheduler        */
    if ((eCurrPrioritySave != pScheduler->eCurrPriority) &&
    (NULL != pScheduler->hSuperSchedUser)) {
      SchedSetPriority(pScheduler->hSuperSchedUser,
               pScheduler->eCurrPriority);
    }
  }
#if defined(_VCPEX) || defined(_AUDACITY) || defined(_AUDACITYT2)
  RESTORE_INTERRUPTS;
#endif
  ASSERT(0 != pScheduler->aoPriorityCnt[ePriorityReg]);
}


/*
 * SchedGetPriority
 *     get the priority for a registered module
 *
 * Arguments:
 *    hSchedUser    registered scheduler user handle
 *
 * Returns:
 *      the priority (E_SCHED_PRIORITY), SCHED_PRIORITY_OFF = disabled
 */
E_SCHED_PRIORITY SchedGetPriority(H_SCHED_USER hSchedUser)
{
  SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;

  ASSERT(bSchedInitialized);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);
  return pSchedUser->ePriority;
}



/*
 * SchedSetDelay
 *     set the delay before the next call to registered module
 *
 * NOTE: interrupts are disabled in case an ISR calls this while it is running
 *
 * Arguments:
 *    hSchedUser    registered scheduler user handle
 *      dwStart        start of delay interval (in clocks)
 *    dwInterval    # clocks after start to delay before calling the module
 *
 * Returns:
 *      none
 */
void SchedSetDelay(H_SCHED_USER hSchedUser, DWORD dwStart, DWORD dwInterval)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  register DWORD dwIntervalReg = dwInterval;

  ASSERT(bSchedInitialized);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);
#if defined(_VCPEX) || defined(_AUDACITY) || defined(_AUDACITYT2)
  DISABLE_INTERRUPTS;
#endif
  pSchedUser->dwDelayStart = dwStart;
  pSchedUser->dwDelay = dwIntervalReg;
  if (0 == dwIntervalReg)
    pSchedUser->fFlags &= ~SCHED_USER_DELAY;
  else
    pSchedUser->fFlags |= SCHED_USER_DELAY;
#if defined(_VCPEX) || defined(_AUDACITY) || defined(_AUDACITYT2)
  RESTORE_INTERRUPTS;
#endif
}


/*
 * SchedGetDelay
 *     get the delay before calling registered module
 *
 * Arguments:
 *    hSchedUser    registered scheduler user handle
 *    pdwStart    addr to put start of delay
 *    pdwInterval    addr to put delay interval
 *
 * Returns:
 *      TRUE  if delay has not yet expired
 *    FALSE if delay has expired or was originally set to 0
 */
DWORD SchedGetDelay(H_SCHED_USER hSchedUser,
            DWORD *pdwStart, DWORD *pdwInterval)
{
  SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;

  ASSERT(bSchedInitialized);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);
  *pdwStart = pSchedUser->dwDelayStart;
  *pdwInterval = pSchedUser->dwDelay;
  if (pSchedUser->fFlags & SCHED_USER_DELAY) {
    /* delay not expired last time it was checked, check again */
    if (pSchedUser->dwDelay > (SCHED_CLOCK() - pSchedUser->dwDelayStart))
      return TRUE;
    else {
      pSchedUser->fFlags &= ~SCHED_USER_DELAY;
      return FALSE;
    }
  }
  else {
    /* delay has already expired (or was 0) */
    return FALSE;
  }
}






/*
 * SchedQueryRelease
 *     check if an early release is required, called from user's
 *      Process() function
 *
 * Arguments:
 *    hSchedUser    registered scheduler user handle
 *
 * Returns:
 *      TRUE    then user Process() must immediately cleanup any work
 *         in progress, release all resources, and return
 *    FALSE    then the user Process() may proceed as normal
 */
DWORD SchedQueryRelease(H_SCHED_USER hSchedUser)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  register SCHEDULER *pScheduler;
  register DWORD bRelease;

  /* check if release needed and reset it (atomically) */
  ASSERT(bSchedInitialized);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);
  pScheduler = pSchedUser->pScheduler;
  ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);
#if defined(_VCPEX) || defined(_AUDACITY) || defined(_AUDACITYT2)
  DISABLE_INTERRUPTS;
#endif
  if (pSchedUser->fFlags & SCHED_USER_DO_RELEASE) {
    bRelease = TRUE;
    pSchedUser->fFlags &= ~SCHED_USER_DO_RELEASE;
  }
  else
    bRelease = FALSE;
#if defined(_VCPEX) || defined(_AUDACITY) || defined(_AUDACITYT2)
  RESTORE_INTERRUPTS;
#endif

  DEBUG({
    if (bRelease)
      ASSERT(pSchedUser->fFlags & SCHED_USER_CAN_RELEASE);
  });
  return bRelease;
}




#if defined(SCHED_STATS)

/*
 * give a name to associtate with a sched user, used in the
 * statistics reports
 *
 * parms:
 *    pSchedUser    the sched user
 *    szName        the name
 */
void SchedRegisterName(H_SCHED_USER hSchedUser, CHAR *szName)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;

  ASSERT(bSchedInitialized);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  pSchedUser->szName = szName;

}



/*
 * report the stats for all schedulers and schedule users
 *
 */
void SchedReportStats(void)
{
  SCHEDULER *pScheduler;
  SCHEDULER *pCurrSchedSave;

  pCurrSchedSave = CllGetCurr(lstScheduler);
  pScheduler = pCurrSchedSave;
  do {
    SchedReportSchedulerStats((H_SCHED) pScheduler);
    CllNext(lstScheduler);
    pScheduler = CllGetCurr(lstScheduler);
  } while (pScheduler != pCurrSchedSave);
}



/*
 * report the stats for a scheduler and its schedule users
 *
 */
void SchedReportSchedulerStats(H_SCHED hScheduler)
{
  SCHEDULER *pScheduler = (SCHEDULER *) hScheduler;
  SCHED_USER *pSchedUser;
  SCHED_USER *pCurrSchedUserSave;
  int ePri;

  ASSERT(NULL != pScheduler);
  ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);

  /* report the scheduler state */
  printf("===========================================================");
  printf("\n\nScheduler @ 0x%08lX", (unsigned long) pScheduler);
  if (NULL != pScheduler->hSuperSchedUser)
    printf(" (nested as SchedUser 0x%08lX)",
       (long unsigned) pScheduler->hSuperSchedUser);
  printf(", # Users %ld\n", (long unsigned) CllGetCount(pScheduler->lstUsers));
  printf("  Curr Priority %d, Histogram (pri:cnt) ", pScheduler->eCurrPriority);
  for (ePri = 0; ePri < SCHED_PRIORITY_ENUMMAX; ePri++)
    printf(" %d:%d, ", ePri, (int) pScheduler->aoPriorityCnt[ePri]);
  printf("\n  ");
  if (!(pScheduler->fFlags & SCHEDULER_RAISED_PRIORITY))
    printf("!");
  printf("RAISED_PRIORITY,  ");
  if (!(pScheduler->fFlags & SCHEDULER_SWEEP_ABORT))
    printf("!");
  printf("SWEEP_ABORT,  ");
  if (!(pScheduler->fFlags & SCHEDULER_SWEEP_PRIORITY_OFF))
    printf("!");
  printf("SWEEP_PRIORITY_OFF\n");
  printf("  Overhead cycles: ");
  XSTAT_REPORT_TOTAL(pScheduler->xSchedOverhead);

  /* check each user of this scheduler */
  if (0 != CllGetCount(pScheduler->lstUsers)) {
    pCurrSchedUserSave = CllGetCurr(pScheduler->lstUsers);
    pSchedUser = pCurrSchedUserSave;
    do {
      SchedReportScheduleUserStats((H_SCHED_USER) pSchedUser);
      CllNext(pScheduler->lstUsers);
      pSchedUser = CllGetCurr(pScheduler->lstUsers);
    } while (pSchedUser != pCurrSchedUserSave);

  }

}



/*
 * report the stats for a schedule user
 *
 */
void SchedReportScheduleUserStats(H_SCHED_USER hSchedUser)
{
  SCHED_USER *pSchedUser = (H_SCHED_USER) hSchedUser;

  ASSERT(NULL != pSchedUser);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  printf("-----------------------------------------------------------");
  printf("\nSchedUser 0x%08lX  (%s, hInstance 0x%08lX),"
     " Scheduler 0x%08lX\n",
     (long unsigned) pSchedUser,
     pSchedUser->szName,
     (long unsigned) pSchedUser->hInstance,
     (long unsigned) pSchedUser->pScheduler);
  printf("  Priority %d,", pSchedUser->ePriority);
  printf("  ");
  if (!(pSchedUser->fFlags & SCHED_USER_DELAY))
    printf("!");
  printf("DELAY,  ");
  if (!(pSchedUser->fFlags & SCHED_USER_CAN_RELEASE))
    printf("!");
  printf("CAN_RELEASE,  ");
  if (!(pSchedUser->fFlags & SCHED_USER_DO_RELEASE))
    printf("!");
  printf("DO_RELEASE\n");

  printf("\n*** Process() Cycles Stats ***");
  XSTAT_REPORT(pSchedUser->xInProcess);

#if defined(SCHED_PRIORITY_CHANGE_STATS)
  SchedReportPriorityHistory((H_SCHED_USER) pSchedUser);
#endif

#if defined(SCHED_PROCESS_RESOURCE_STATS)
  SchedReportProcessResourceStats((H_SCHED_USER) pSchedUser);
#endif

  printf("\n");

}



/*
 * reset all statistics
 *
 */
void SchedResetStats(void)
{
  SCHEDULER *pScheduler;
  SCHEDULER *pCurrSchedSave;
  SCHED_USER *pSchedUser;
  SCHED_USER *pCurrSchedUserSave;

  /* check each scheduler */
  pCurrSchedSave = CllGetCurr(lstScheduler);
  pScheduler = pCurrSchedSave;
  do {
    ASSERT(NULL != pScheduler);
    ASSERT(SCHEDULER_MAGIC == pScheduler->dwMagic);

    /* check each user of this scheduler */
    if (0 != CllGetCount(pScheduler->lstUsers)) {
      pCurrSchedUserSave = CllGetCurr(pScheduler->lstUsers);
      pSchedUser = pCurrSchedUserSave;
      do {
    ASSERT(NULL != pSchedUser);
    ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

    /* clear schedule user stats */
    XSTAT_CLEAR(pSchedUser->xInProcess);

#if defined(SCHED_PRIORITY_CHANGE_STATS)
    /* reset the priority history stats */
    SchedResetPriorityHistory((H_SCHED_USER) pSchedUser);
#endif

#if defined(SCHED_PROCESS_RESOURCE_STATS)
    /* reset the process resource stats */
    SchedResetProcessResourceStats((H_SCHED_USER) pSchedUser);
#endif

    /* next scheduler */
    CllNext(pScheduler->lstUsers);
    pSchedUser = CllGetCurr(pScheduler->lstUsers);
      } while (pSchedUser != pCurrSchedUserSave);

    }

    /* clear scheduler stats */
    XSTAT_CLEAR(pScheduler->xSchedOverhead);

    /* next scheduler */
    CllNext(lstScheduler);
    pScheduler = CllGetCurr(lstScheduler);
  } while (pScheduler != pCurrSchedSave);

}

#endif



#if defined(SCHED_PRIORITY_CHANGE_STATS)
/*
 * record the pritority change history
 *
 * NOTE: this history is currently an array, it could be changed to a linked
 *      list... but watch out because it may be called by an ISR (since it
 *      is called whenever SchedSetPriority() is called) so malloc
 *      is NOT safe
 *
 * parms:
 *    hSchedUser    the user handle
 *    ePriority    the new priority
 *    dwLine        the line # of the SchedSetPriority() call
 *    pFile        ptr to the file name of the SchedSetPriority() call
 */
void SchedPriorityChangeHistory(H_SCHED_USER hSchedUser,
                E_SCHED_PRIORITY ePriority,
                DWORD dwLine, OCTET *pFile)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  PRIORITY_CHANGE *pEntry;
  DWORD dwEntry, dwLast;

  ASSERT(bSchedInitialized);
  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  /* check if this change has already been entered */
  pEntry = pSchedUser->xPriorityHistory.axChange;
  dwEntry = 0;
  do {
    ASSERT(pEntry <        /* see NOTE in prologue */
       pSchedUser->xPriorityHistory.axChange + MAX_PRIORITY_CHANGE_ENTRIES);

    /* if entry found, then done searching */
    if ((dwLine == pEntry->dwLine) &&
    (pFile == pEntry->pFile) &&
    (ePriority == pEntry->ePriority)) {
      break;
    }

    /* if at end of entries, add this one */
    if (0 == pEntry->dwLine) {
      ASSERT(NULL == pEntry->pFile);
      ASSERT(0 == pEntry->dwTotal);
      pEntry->dwLine = dwLine;
      pEntry->pFile = pFile;
      pEntry->ePriority = ePriority;
      break;
    }

    /* next entry */
    pEntry++;
    dwEntry++;

  } while (1);

  /* if this change is not the same as the last one, set it as a new last */
  dwLast = pSchedUser->xPriorityHistory.dwLast;
  if (dwEntry != dwLast) {
    pSchedUser->xPriorityHistory.dwLast = dwEntry;
  }

  /* increment counts */
  pEntry->dwTotal++;
  if (NO_LAST_PRIORITY != dwLast)
    pEntry->adwLastHistogram[dwLast]++;

}



/*
 * report the priority change history for a schedule user
 *
 * parms:
 *    pSchedUser    the sched user
 */
void SchedReportPriorityHistory(H_SCHED_USER hSchedUser)
{
  PRIORITY_CHANGE *pEntry;
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  DWORD dwEntry;
  int i;

  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  /* report each entry */
  printf("\n*** Priority Change History for hSchedUser 0x%08lX "
     "(last change marked with '*')\n",
     (long int) pSchedUser);
  printf("index   total   pri   line file              "
     "  prev change histogram (index:count)\n");
  pEntry = pSchedUser->xPriorityHistory.axChange;
  dwEntry = 0;
  do {

    /* if done then break */
    if (dwEntry >= MAX_PRIORITY_CHANGE_ENTRIES)
      break;
    if (0 == pEntry->dwLine)
      break;

    /* print the priority change info */
    printf("  %2ld  %08lX  %2d",
       (unsigned long) dwEntry,
       (unsigned long) pEntry->dwTotal,
       pEntry->ePriority);
    if (dwEntry == pSchedUser->xPriorityHistory.dwLast)
      printf("*");
    else
      printf(" ");
    printf("  %5ld %-18s ",
       (unsigned long) pEntry->dwLine,
       pEntry->pFile);
    for (i = 0; i < MAX_PRIORITY_CHANGE_ENTRIES; i++)
      if (0 != pEntry->adwLastHistogram[i])
    printf(" %d:%08lX", i, (unsigned long) pEntry->adwLastHistogram[i]);
    printf("\n");

    /* next entry */
    pEntry++;
    dwEntry++;

  } while (1);

}



/*
 * reset the priority change history for a schedule user
 *
 * parms:
 *    pSchedUser    the sched user
 */
void SchedResetPriorityHistory(H_SCHED_USER hSchedUser)
{
  PRIORITY_CHANGE *pEntry;
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  int i;

  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  pEntry = pSchedUser->xPriorityHistory.axChange;
  do {

    /* if done then break */
    if (pEntry >=
    pSchedUser->xPriorityHistory.axChange + MAX_PRIORITY_CHANGE_ENTRIES)
      break;
    if (0 == pEntry->dwLine)
      break;

    /* clear stats */
    for (i = 0; i < MAX_PRIORITY_CHANGE_ENTRIES; i++)
      pEntry->adwLastHistogram[i] = 0;
    pEntry->dwTotal = 0;

    /* next entry */
    pEntry++;

  } while (1);

}
#endif




#if defined(SCHED_PROCESS_RESOURCE_STATS)

/*
 * register the names and max levels for process resource stats
 *
 * parms:
 *    hSchedUser        the schedule user handle
 *    dwNumReasons        # of different reason for return
 *    pszReasonNames        persistent array of reason names
 *    dwNumResources        # of different resources
 *    pszResourceNames    persistent array of resource names
 *    adwMaxResourceLevels    persistent array of max resource levels
 */
void SchedRegisterProcessResources(H_SCHED_USER hSchedUser,
                   DWORD dwNumReasons,
                   CHAR **pszReasonNames,
                   DWORD dwNumResources,
                   CHAR **pszResourceNames,
                   DWORD *adwMaxResourceLevels)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;

  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  /* malloc an array for process entry resource level stats and clear it */
  ASSERT(NULL == pSchedUser->xProcResourceStats.axEntryResourceStats);
  if (0 != dwNumResources) {
    pSchedUser->xProcResourceStats.axEntryResourceStats =
      calloc(dwNumResources,
         sizeof(*(pSchedUser->xProcResourceStats.axEntryResourceStats)));
    ASSERT(NULL != pSchedUser->xProcResourceStats.axEntryResourceStats);
  }

  /* malloc an array for process return reason histogram and clear it */
  ASSERT(0 != dwNumReasons);
  ASSERT(NULL == pSchedUser->xProcResourceStats.adwReasonHistogram);
  pSchedUser->xProcResourceStats.adwReasonHistogram =
    calloc(dwNumReasons,
       sizeof(*(pSchedUser->xProcResourceStats.adwReasonHistogram)));
  ASSERT(NULL != pSchedUser->xProcResourceStats.adwReasonHistogram);

  /* malloc an array for process return resource level stats and clear it */
  ASSERT(NULL == pSchedUser->xProcResourceStats.axReturnResourceStats);
  if (0 != dwNumResources) {
    pSchedUser->xProcResourceStats.axReturnResourceStats =
      calloc(dwNumResources,
         sizeof(*(pSchedUser->xProcResourceStats.axReturnResourceStats)));
    ASSERT(NULL != pSchedUser->xProcResourceStats.axReturnResourceStats);
  }

  /* fill in the rest of the resource stats array */
  pSchedUser->xProcResourceStats.dwNumReasons = dwNumReasons;
  pSchedUser->xProcResourceStats.pszReasonNames = pszReasonNames;
  pSchedUser->xProcResourceStats.dwNumResources = dwNumResources;
  pSchedUser->xProcResourceStats.pszResourceNames = pszResourceNames;
  pSchedUser->xProcResourceStats.adwMaxResourceLevels = adwMaxResourceLevels;
}




/*
 * record resource levels at entry to a Process()
 *
 * parms:
 *    hSchedUser    the schedule user handle
 *    pdwLevels    pointer to the resource level array
 *             (length set by SchedRegisterProcessResources())
 */
void SchedProcessEnterResources(H_SCHED_USER hSchedUser,
                DWORD *pdwLevels)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  DWORD dwResource;
  XSTAT *pxStat;

  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  /* check if any resource registered */
  if (0 != pSchedUser->xProcResourceStats.dwNumResources) {
    ASSERT(NULL != pSchedUser->xProcResourceStats.axEntryResourceStats);

    /* add to the stats of each resource */
    for (dwResource = 0;
     dwResource < pSchedUser->xProcResourceStats.dwNumResources;
     dwResource++) {
      pxStat =
    &(pSchedUser->xProcResourceStats.axEntryResourceStats[dwResource]);
      XSTAT_RECORD(*pxStat, pdwLevels[dwResource]);
    }
  }
}




/*
 * record resource levels at return from a Process()
 *
 * parms:
 *    hSchedUser    the schedule user handle
 *    dwReason    reason for return
 *    pdwLevels    pointer to the resource level array
 *             (length set by SchedRegisterProcessResources())
 */
void SchedProcessReturnResources(H_SCHED_USER hSchedUser,
                 DWORD dwReason,
                 DWORD *pdwLevels)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  DWORD dwResource;
  XSTAT *pxStat;

  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  /* if not registered, then just return */
  if (0 == pSchedUser->xProcResourceStats.dwNumReasons)
    return;
  ASSERT(NULL != pSchedUser->xProcResourceStats.adwReasonHistogram);

  /* save the return reason in reason histogram */
  ASSERT(dwReason < pSchedUser->xProcResourceStats.dwNumReasons);
  pSchedUser->xProcResourceStats.dwTotalReturns++;
  pSchedUser->xProcResourceStats.adwReasonHistogram[dwReason]++;

  /* check if any resources registered */
  if (0 != pSchedUser->xProcResourceStats.dwNumResources) {
    ASSERT(NULL != pSchedUser->xProcResourceStats.axReturnResourceStats);

    /* add to the stats of each resource */
    for (dwResource = 0;
     dwResource < pSchedUser->xProcResourceStats.dwNumResources;
     dwResource++) {
      pxStat =
    &(pSchedUser->xProcResourceStats.axReturnResourceStats[dwResource]);
      XSTAT_RECORD(*pxStat, pdwLevels[dwResource]);
    }
  }
}




/*
 * report resource levels at entry and return for a process
 *
 * parms:
 *    hSchedUser        the schedule user handle for the process
 */
void SchedReportProcessResourceStats(H_SCHED_USER hSchedUser)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  DWORD dwResource, dwReason;
  XSTAT *pxStat;

  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  /* if not registered, then just return */
  if (0 == pSchedUser->xProcResourceStats.dwNumReasons) {
    return;
  }
  ASSERT(NULL != pSchedUser->xProcResourceStats.adwReasonHistogram);

  /* print out the process entry resource stats */
  for (dwResource = 0;
       dwResource < pSchedUser->xProcResourceStats.dwNumResources;
       dwResource++) {
    printf("\n*** Process() ENTRY Resource #%ld Level (%s, Max 0x%08lX) ***\n",
       (long unsigned) dwResource,
       pSchedUser->xProcResourceStats.pszResourceNames[dwResource],
       (long unsigned)
         pSchedUser->xProcResourceStats.adwMaxResourceLevels[dwResource]);
    pxStat =&(pSchedUser->xProcResourceStats.axEntryResourceStats[dwResource]);
    XSTAT_REPORT(*pxStat);
  }
  printf("\n");

  /* print out the return reason histogram */
  printf("\n*** Process() Return Reason Histogram, total # returns 0x%08lX:\n",
     pSchedUser->xProcResourceStats.dwTotalReturns);
  printf("reason   count  name\n");
  for (dwReason = 0;
       dwReason < pSchedUser->xProcResourceStats.dwNumReasons;
       dwReason++) {
    printf("%4ld   %08lX %s\n",
       (long unsigned) dwReason,
       (long unsigned)
         pSchedUser->xProcResourceStats.adwReasonHistogram[dwReason],
       pSchedUser->xProcResourceStats.pszReasonNames[dwReason]);
  }
  printf("\n");

  /* print out the process return resource stats */
  for (dwResource = 0;
       dwResource < pSchedUser->xProcResourceStats.dwNumResources;
       dwResource++) {
    printf("\n*** Process() RETURN Resource #%ld Level (%s, Max 0x%08lX) ***\n",
       (long unsigned) dwResource,
       pSchedUser->xProcResourceStats.pszResourceNames[dwResource],
       (long unsigned)
         pSchedUser->xProcResourceStats.adwMaxResourceLevels[dwResource]);
    pxStat =&(pSchedUser->xProcResourceStats.axReturnResourceStats[dwResource]);
    XSTAT_REPORT(*pxStat);
  }
  printf("\n");

}





/*
 * reset resource levels at entry and return for a process
 *
 * parms:
 *    hSchedUser        the schedule user handle for the process
 */
void SchedResetProcessResourceStats(H_SCHED_USER hSchedUser)
{
  register SCHED_USER *pSchedUser = (SCHED_USER *) hSchedUser;
  DWORD dwReason, dwResource;
  XSTAT *pxStat;

  ASSERT(SCHED_USER_MAGIC == pSchedUser->dwMagic);

  /* free any malloced arrays */
  if (NULL != pSchedUser->xProcResourceStats.axEntryResourceStats) {
    pxStat = pSchedUser->xProcResourceStats.axEntryResourceStats;
    for (dwResource = 0;
     dwResource < pSchedUser->xProcResourceStats.dwNumResources;
     dwResource++) {
      XSTAT_CLEAR(*pxStat);
      pxStat++;
    }
  }
  if (NULL != pSchedUser->xProcResourceStats.adwReasonHistogram) {
    for (dwReason = 0;
     dwReason < pSchedUser->xProcResourceStats.dwNumReasons;
     dwReason++) {
      pSchedUser->xProcResourceStats.adwReasonHistogram[dwReason] = 0;
    }
  }
  if (NULL != pSchedUser->xProcResourceStats.axReturnResourceStats) {
    pxStat = pSchedUser->xProcResourceStats.axReturnResourceStats;
    for (dwResource = 0;
     dwResource < pSchedUser->xProcResourceStats.dwNumResources;
     dwResource++) {
      XSTAT_CLEAR(*pxStat);
      pxStat++;
    }
  }

  /* clear other fields */
  pSchedUser->xProcResourceStats.dwTotalReturns = 0;

}


#endif







