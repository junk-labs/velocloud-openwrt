#ifndef __MULT_H__
#define __MULT_H__


#define _mult_CA(z,a,b) { register LONG ra, rb;  \
		        ra = a;                \
			rb = b;                \
                        vcp[mult_a] = ra;      \
                        vcp[mult_b32] = rb;    \
		        asm("nop");            \
		        asm("nop");            \
			z = vcp[mult_z1]; }

#define mult16(z,a,b) { register LONG ra, rb;  \
		        ra = a;                \
			rb = b;                \
                        vcp[mult_a] = ra;      \
                        vcp[mult_b16] = rb;    \
		        asm("nop");            \
		        asm("nop");            \
		        asm("nop");            \
			z = vcp[mult_z2]; }

#define vecscale16_allign(dst, src, scale, size) { \
          SHORT *ps=src, *pd=dst, *pe=ps+size-1;   \
          LONG rb,rz1,rz2;                         \
	  ASSERT(!(((DWORD)src&0x3)));             \
          ASSERT(!(size&0x1));                     \
          vcp[mult_a] = (scale & 0xffff) | ((LONG)scale << 16); \
          rb=*(LONG *)ps;                          \
          do { vcp[mult_b16] = rb;                 \
            ps += 2;                               \
            rb = *(LONG *)ps;                      \
            rz1 = vcp[mult_z1];                    \
            rz2 = vcp[mult_z2];	                   \
            *pd++ = rz1;                           \
            *pd++ = rz2;                           \
	  } while (pe > ps); }   

#define macc16_allign(dst, src1, src2, size) {     \
          LONG ra, rb;                             \
          SHORT *ps1=src1, *ps2=src2, *pe;         \
	  ASSERT(!((DWORD)src1&0x3));              \
          ASSERT(!((DWORD)src2&0x3));              \
          ASSERT(!(size&0x1));                     \
          vcp[macc_z] = 0x0;                       \
          pe = ps1+size-1;                         \
          for ( ; ps1 < pe; ) {                    \
            ra=*(LONG *)ps1;                       \
            rb=*(LONG *)ps2;                       \
	    vcp[macc_a]=ra;                        \
            vcp[macc_b16]=rb;                      \
            ps1+=2; ps2+=2;}                       \
            *dst = vcp[macc_z]; }

#define vecmult16_allign(dst, src1, src2, size) {  \
          LONG ra,rb,rz1,rz2,*pd=dst;              \
          SHORT *ps1=src1, *ps2=src2, *pe=ps1+size-1; \
          ASSERT(!((DWORD)src1&0x3));              \
          ASSERT(!((DWORD)src2&0x3));              \
          ASSERT(!(size&0x1));                     \
          for ( ; ps1 < pe; ) {                    \
            ra=*(LONG *)ps1;                       \
            rb=*(LONG *)ps2;                       \
            vcp[mult_a]=ra;                        \
            vcp[mult_b16]=rb;                      \
            ps1+=2; ps2+=2;                        \
            rz1=vcp[mult_z1];                      \
            rz2=vcp[mult_z2];                      \
            *pd++=rz1;                             \
            *pd++=rz2; } }


#define _mult(z,a,b)    z = a * b;

#define _macc16(dst, src1, src2, size) {           \
          SHORT *ps1=src1, *ps2=src2, *pe=ps1+size; \
          LONG macc=0;                             \
          do macc+=(*ps1++)*(*ps2++); while(ps1<pe); \
	  *dst = macc; }

#define _macc32(dst, src1, src2, size) {           \
          LONG *ps1=src1, *ps2=src2, *pe=ps1+size; \
          LONG macc=0;                             \
          do macc+=(*ps1++)*(*ps2++); while(ps1<pe); \
	  *dst = macc; }

#define _vecscale16(dst, src, scale, size) {       \
          SHORT *ps=src, *pd=dst, *pe=ps+size;     \
          do *pd++ = scale*(*ps++); while(ps<pe);} 

#define _vecscale32(dst, src, scale, size) {        \
          LONG *ps=src, *pd=dst, *pe=ps+size;       \
          do *pd++ = scale*(*ps++); while(ps<pe);} 

#define _vecmult16(dst, src1, src2, size)  {          \
          SHORT *ps1=src1, *ps2=src2, *pe=ps1+size; LONG *pd=dst; \
	  do *pd++=(*ps1++)*(*ps2++); while(ps1<pe);} 
                  
#define _vecmult32(dst, src1, src2, size)  {          \
          LONG *ps1=src1, *ps2=src2, *pe=ps1+size; LONG *pd=dst; \
	  do *pd++=(*ps1++)*(*ps2++); while(ps1<pe);} 
                  
void _macc32_CA(LONG *dst, LONG *src1, LONG *src2, DWORD size);
void _macc16_CA(LONG *plDst, SHORT *pnSrc1, SHORT *pnSrc2, DWORD dwSize);
void _macc8_CA(SHORT *pnDst, OCTET *pnSrc1, OCTET *pnSrc2, DWORD dwSize);
void _vecscale32_CA(LONG *plDst, LONG *plSrc, DWORD dwScale, DWORD dwSize); 
void _vecscale16_CA(SHORT *pnDst, SHORT *pnSrc, SHORT nScale, DWORD dwSize);
void _vecmult32_CA(LONG *dst, LONG *src1, LONG *src2, DWORD size);
void _vecmult16_CA(LONG *pnDst, SHORT *pnSrc1, SHORT *pnSrc2, DWORD dwSize);

#ifdef MULTIPLIER
#define mult       _mult_CA
#define macc32     _macc32_CA
#define macc16     _macc16_CA
#define macc8      _macc8_CA
#define vecscale32 _vecscale32_CA
#define vecscale16 _vecscale16_CA
#define vecmult32  _vecmult32_CA
#define vecmult16  _vecmult16_CA
#else

#define mult       _mult
#define macc32     _macc32
#define macc16     _macc16
#define vecscale32 _vecscale32
#define vecscale16 _vecscale16
#define vecmult32  _vecmult32
#define vecmult16  _vecmult16
#endif

#endif
