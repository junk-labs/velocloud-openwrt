/*
 * netif_write.c
 *
 * NetIfDriverWrite
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"

#ifdef __MULTICORE_ON__
#include "multicore_defs.h"
#endif

#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "snmp_tcpip_data.h"
#include "../include/if_types.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "netdbg.h"
#include "ethernet.h"
#include "arp.h"
#include "ip1ton.h"
#include "netdefs.h"
#include "netconfig.h"
#include "netmain.h"
#include "linkconf.h"
#ifdef ETHERNET
#include "ethconf.h"
#include "ethlink.h"
#endif /*#ifdef ETHERNET*/
#ifdef PPP
#include "ppp.h"
#include "pppoeconf.h"
#include "pppconf.h"
#include "pppoecommon.h"
#endif /*#ifdef PPP*/
#ifdef NET_DSL
#include "mpoaconf.h"
#include "mpoa.h"
#include "adslmgr.h"
#endif /*#ifdef NET_DSL*/
#include "netif.h"
#include "netsnmp.h"
#include "routing_table.h"
#include "dhcpclient.h"
#include "dnsapi.h"
#include "sockapi.h"

#ifdef ROUTER
  #include "router.h"
#endif

#ifdef IPSEC
  #include "ipsec.h"
#endif /*#ifdef IPSEC*/

#ifdef IPFRAG
  #include "ipfrag.h"
#endif /*#ifdef IPFRAG*/

#ifdef NAT
  #include "nat.h"
#endif /*#ifdef NAT*/

#ifdef _ENABLE_L4_FLOW_
  #include "ip.h"
#endif

#include "mn_ndi.h"

#ifndef NDEBUG
DWORD dbg_dwNetMainwriteFailureCount = 0;
DWORD dbg_dwSmallPacketCount = 0;
#endif

#define ETH_DRIVERHDRSIZE 2

#ifdef _ENABLE_L4_FLOW_

#define IPROTO_TCP 6
#define IPROTO_UDP 17

DWORD
NetIfGetL4FlowLabel(NETIFCONF *pxNetIfConf,
                     NETPACKET *pxPacket,
                     NETPACKETACCESS *pxAccess);
#endif

 /*
 * NetIfDriverWrite
 *  Write function provided to the lowest link module LL
 *
 *  Args:
 *   hLLInst               casted driver file descriptor
 *   hIf                   Unused.
 *   pxPacket              packet structure pointer
 *   pxAccess              access structure pointer
 *   hData                 Unused.
 *
 *  Return:
 *   Length written or NETERR_XXX
 */
LONG NetIfDriverWrite(H_NETINSTANCE hLLInst,
                      H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,
                      NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  NETIFCONF *pxNetIfConf;
  int iBytesWritten = 0;
  NETWRAPPERSTATE *pxWrapperState;
  NETPAYLOAD *pxPayload;
  WORD wMtu,wLtu;
  OCTET *poPayload;
  OCTET oL3AddrLength;
  E_PHYLINKTYPE ePhyLinkType;
  NETIFCONF *pxIfConf;
  ubyte2  iPhyIdx;
  NETIFSTATE *pxNetIfState;
  MSTATUS status;

  NETPACKET_CHECK(pxPacket);
  NETMAIN_ASSERT(pxAccess != NULL);
  NETMAIN_ASSERT((int)hIf < IFNUMMAX);

  pxPayload = pxPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  NETMAIN_ASSERT( (pxAccess->wOffset + pxAccess->wLength) <= pxPayload->wSize );

  /* NETMAIN_DBGP(REPETITIVE,"NetIfDriverWrite called on interface %d,wOffset=%d,wLength=%d\n",
               (OCTET)hIf,pxAccess->wOffset,pxAccess->wLength); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_REPETITIVE))
  {
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,
                            "NetIfDriverWrite called on interface ",(OCTET)hIf,
                            ",wOffset=",pxAccess->wOffset);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,",wLength=",pxAccess->wLength);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  /*NETMAIN_DBG(XREPETITIVE,(NetPrintPayload(poPayload + pxAccess->wOffset,pxAccess->wLength))); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_DETAIL))
  {
      NetPrintPayload(poPayload + pxAccess->wOffset,pxAccess->wLength);
  }

  pxNetWrapper = NETGETWRAPPER;
#ifndef __MULTICORE_COMMON_ON__
  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL); /*we will have problems when we open up ATM code*/
#endif

#ifdef LINK_AGGREGATION /* Atul */
  pxNetIfConf = NETGETIFCONF(pxNetWrapper,(OCTET)hData);
#else
  pxNetIfConf = NETGETIFCONF(pxNetWrapper,(OCTET)hIf);
#endif

  NETMAIN_ASSERT(pxNetIfConf != NULL);

  ePhyLinkType  = pxNetIfConf->ePhyLinkType;
  wMtu          = pxNetIfConf->wMtu;
  wLtu          = pxNetIfConf->wLtu;
  oL3AddrLength = pxNetIfConf->oL3AddrLength;

#ifdef LINK_AGGREGATION /* switch to driver FD */
  {
      NETMAIN_ASSERT ( pxNetIfConf->oFlags & IFF_LOGICAL );
      NETMAIN_ASSERT ( pxNetIfConf->iActivePhyLinkIfIdx >= 0 );

      iPhyIdx = pxNetIfConf->iActivePhyLinkIfIdx;
#ifdef _ENABLE_L4_FLOW_ /* Distribution based on L4 ports */

      /* Check if there are multiple interfaces */
      if(((MnDeviceInstanceConf_t *)pxNetIfConf->pMnDeviceInstance)->MnNumPhysicalInstances > 1)
      {
          /* In case of multiple physical interfaces bound to 1 Logical interface
           * find the next physical interface to send the packet.
          */
          iPhyIdx = NetIfGetL4FlowLabel(pxNetIfConf, pxPacket, pxAccess);
      }
      /* NETMAIN_DBGP(REPETITIVE,"NetIfDriverWrite: Sending to physical interface %d\n",iPhyIdx);*/
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_REPETITIVE))
      {
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,
                     "NetIfDriverWrite: Sending to physical interface ",iPhyIdx);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
      }

#endif /* _ENABLE_L4_FLOW_ */

     /*  pxIfConf = NETGETIFCONF(pxNetWrapper,
                     (OCTET)pxNetIfConf->iActivePhyLinkIfIdx); */

      /* check if any of the interfaces are active */
      if(iPhyIdx == (ubyte2)-1 )
      {
          iPhyIdx = pxAccess->wLength;
          /* free the packet and return */
          NETPAYLOAD_DELUSER(pxPayload);
          /* Always act as if all was sent: packet loss is a fact of life */

          return(pxAccess->wLength);
      }
      pxIfConf = NETGETIFCONF(pxNetWrapper,iPhyIdx);
      NETMAIN_ASSERT(pxIfConf != NULL);
      hLLInst = (H_NETINSTANCE)pxIfConf->iFd;
  }
#endif

  switch(ePhyLinkType)
  {
  case ETH:
    {
    NET_DRV_BUFFER *pndbTxPacket;
#ifndef __LOCK_OPT_ON__
    /* JJ Removed it as no need for this as we are under Global Mutex Lock Here */
    /*RTOS_mutexWait((pxIfConf->xMutex));*/
#endif

#if 0
    pndbTxPacket = &(pxWrapperState->xndbTxPacket);
#else
    pndbTxPacket = &(pxIfConf->xndbTxPacket);
#endif

    if (pxAccess->wLength < wLtu)
    {
      pndbTxPacket->dwLength = wLtu + ETH_DRIVERHDRSIZE;
      DEBUG(dbg_dwSmallPacketCount ++;);
    } else {
      pndbTxPacket->dwLength = pxAccess->wLength + ETH_DRIVERHDRSIZE;
    }

#if 0
    NETMAIN_ASSERT((DLLIST_count_inline(&pxWrapperState->dllTxBuf)) > 0);
    NETMAIN_ASSERT(pndbTxPacket == DLLIST_read(&pxWrapperState->dllTxBuf));
#else
    NETMAIN_ASSERT((DLLIST_count_inline(&pxIfConf->dllTxBuf)) > 0);
    NETMAIN_ASSERT(pndbTxPacket == DLLIST_read(&pxIfConf->dllTxBuf));
#endif

    NETMAIN_ASSERT(pndbTxPacket->dwLength <= wMtu + oL3AddrLength);

    NETPAYLOAD_LOCK(pxPayload);
    if (pxPayload->oUserCount > 1)
    {
      /* This packet is being re-used somewhere: we have
         to copy it */
#if defined (__TCP_SEND_SEGMENT__) && !defined (__RTOS_VXWORKS__)
         /* Need to do Zero Copy  Only in the case of Linux
             In VxWorks as the Driver Keeps the buffer
            in its TBD, this will crash if TCP frees this
             Need to narrow down these to try to do zerocopy
            Basically when we are sending the Segment the first time
            we can set a bit stating that the driver Should not free
            the buffer. hence only in case of retransmiussion we
            need to copy     */
        if (pxPayload->pTxSegment)
        {
          NETMAIN_ASSERT(pxAccess->wOffset >= ETH_DRIVERHDRSIZE);
          pndbTxPacket->poData = poPayload;
          pndbTxPacket->wSize = pxPayload->wSize;
          pndbTxPacket->wOffset = pxAccess->wOffset - ETH_DRIVERHDRSIZE;
          pndbTxPacket->pfnFree = pxPayload->pfnFree;
          pndbTxPacket->pTxSegment = pxPayload->pTxSegment;
          pndbTxPacket->oUserCount = pxPayload->oUserCount;
          NETPAYLOAD_UNLOCK(pxPayload);
          NETPAYLOAD_DELUSER(pxPayload);

          goto process;
        }

#endif
      /* JJ TODO We should not be copying here. We shoudl use UserCount */
#ifdef __INET_USE_PAYLOAD_MEMPOOL__
      status = NetAllocPayload(&pndbTxPacket->poData ,pndbTxPacket->dwLength + ETH_DRIVERHDRSIZE);
      if(OK != status)
      {
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "NetIfDriverWrite : unable to allocate memory for poData, returning.");
        NETPAYLOAD_UNLOCK(pxPayload);
        NETPAYLOAD_DELUSER(pxPayload);
    break;
      }
#else
      pndbTxPacket->poData = MALLOC(pndbTxPacket->dwLength + ETH_DRIVERHDRSIZE);
#endif
      ASSERT(pndbTxPacket->poData != NULL);
      /* printf("******** Allocating poData %p *********\n",pndbTxPacket->poData); */
      pndbTxPacket->wSize = pndbTxPacket->dwLength + ETH_DRIVERHDRSIZE;
      pndbTxPacket->wOffset = 0;
      pndbTxPacket->pfnFree = NetFree;
      MOC_MEMCPY((ubyte *)(pndbTxPacket->poData + ETH_DRIVERHDRSIZE),
             (ubyte *)(poPayload + pxAccess->wOffset),
             pxAccess->wLength);
#ifdef __TCP_SEND_SEGMENT__
      pndbTxPacket->pTxSegment = pxPayload->pTxSegment;
      pndbTxPacket->oUserCount = pxPayload->oUserCount;
#endif
      NETPAYLOAD_UNLOCK(pxPayload);
      NETPAYLOAD_DELUSER(pxPayload);
    } else {
      /* Cool, we are the only user: pass down the original
         pointer to the driver */
      NETMAIN_ASSERT(pxAccess->wOffset >= ETH_DRIVERHDRSIZE);
      pndbTxPacket->poData = poPayload;
      pndbTxPacket->wSize = pxPayload->wSize;
      pndbTxPacket->wOffset = pxAccess->wOffset - ETH_DRIVERHDRSIZE;
      pndbTxPacket->pfnFree = pxPayload->pfnFree;
#ifdef __TCP_SEND_SEGMENT__
      pndbTxPacket->pTxSegment = pxPayload->pTxSegment;
      pndbTxPacket->oUserCount = 0;
#endif
      NETPAYLOAD_UNLOCK(pxPayload);
      pxPayload->poPayload = NULL; /* The poPayload will be freed later on */
      NETPAYLOAD_DELUSER(pxPayload);
    }

#ifdef __TCP_SEND_SEGMENT__
process:
#endif

    /* 0xFFFF needed by the current driver */
    /*
    pndbTxPacket->poData[pndbTxPacket->wOffset] = 0xFF;
    pndbTxPacket->poData[pndbTxPacket->wOffset+1] = 0xFF;
    */

#if 0
    /* RS: zero out extra trailer on small packets. Else, receiving host
           may treat the incoming FCS as invalid */
    if ( pndbTxPacket->dwLength > (pndbTxPacket->wSize - ETH_DRIVERHDRSIZE))
       MOC_MEMSET((ubyte *)(pndbTxPacket->poData + pndbTxPacket->wOffset +
           ETH_DRIVERHDRSIZE + pndbTxPacket->wSize), 0,
           pndbTxPacket->dwLength - pndbTxPacket->wSize -
           ETH_DRIVERHDRSIZE);
#endif


#if 0
    iBytesWritten = write((int)hLLInst,
                          (char *)(&(pxWrapperState->dllTxBuf)),
                          (int)pndbTxPacket->dwLength);
#else
  {
  iBytesWritten = (((MnDeviceInstanceConf_t *)
                    pxNetIfConf->pMnDeviceInstance)->MnDeviceInfo->MnDeviceCallbackFns.funcPtr_MnDeviceWrite)
                      ((int)iPhyIdx,/* (int)hData, */
                      /*(char *)(&(pxIfConf->dllTxBuf)), JJ Passing Txpacket Now as we are not queueing during XMits */
                      (char *)((pndbTxPacket)),
                      pndbTxPacket->dwLength);
  }
#endif
    /* Got to fix the case wherein we send the data in Vxworks but it returns
       an error  We need to free it then here currently there is a leak*/
    if (!iBytesWritten)/* In the case of Linux  (Sync XMit .it returns 0 ) */
    {
      /* The driver has not accepted the data */
#ifdef __TCP_SEND_SEGMENT__
      if (0 == pndbTxPacket->oUserCount)
      {
          /* Return it to the application if txSegment is Present */
        if (pndbTxPacket->pTxSegment)
              DEBUG_PRINTNL(DEBUG_MOC_IPV4, " Need to Return to User  TxSegment Present .. Code Missing ");
        else
           pndbTxPacket->pfnFree(pndbTxPacket->poData);
      }
      else
      {
        if (NULL == pndbTxPacket->pTxSegment)
          pndbTxPacket->pfnFree(pndbTxPacket->poData);
      }
#else
       pndbTxPacket->pfnFree(pndbTxPacket->poData);
#endif
      DEBUG(dbg_dwNetMainwriteFailureCount ++;);
    }

    /* Reset the header fields */
    pndbTxPacket->poData = NULL;
    pndbTxPacket->dwLength = 0;
#ifndef __LOCK_OPT_ON__
    /* JJ Removed it as no need for this as we are under Global Mutex Lock Here */
    /*RTOS_mutexRelease((pxIfConf->xMutex));*/
#endif
    break;
    }
#ifdef NET_DSL
  case ATM:
    {
    DRIVERBUFFER *pxDriverBufferTx;
/*    WORD wSize; */
    pxDriverBufferTx = &(pxWrapperState->xDriverBufferTx);

    pxDriverBufferTx->dwLength = pxAccess->wLength;

    NETMAIN_ASSERT(pxDriverBufferTx->dwLength <= wMtu + oL3AddrLength);

    pxDriverBufferTx->oPriority = pxAccess->oPriority;
#ifdef CUSTOM_QUEUE
    pxDriverBufferTx->oClass = pxAccess->oClass;
#endif

    if (pxDriverBufferTx->dwLength < wLtu) {
      pxDriverBufferTx->dwLength = wLtu;
      DEBUG(dbg_dwSmallPacketCount ++;);
    }

    NETPAYLOAD_LOCK(pxPayload);
    if (/*pxPayload->oUserCount > 1*/TRUE) {
      /* This packet is being re-used somewhere: we have
         to copy it */

      pxDriverBufferTx->wOffset = 0;
      /*pxDriverBufferTx->wPad = 47+8; */ /*CPCS Trailer+Pad*/

      pxDriverBufferTx->wSize = pxDriverBufferTx->dwLength +
                                47+8; /*pxDriverBufferTx->wPad; */

      pxDriverBufferTx->poData = MALLOC(pxDriverBufferTx->wSize);
      pxDriverBufferTx->pfnFree = NetFree;

      NETMAIN_ASSERT(pxDriverBufferTx->poData != NULL);

      MOC_MEMCPY((ubyte *)pxDriverBufferTx->poData,
             (ubyte *)(poPayload + pxAccess->wOffset),
             pxDriverBufferTx->dwLength);

      NETPAYLOAD_UNLOCK(pxPayload);
      NETPAYLOAD_DELUSER(pxPayload);
    } else {
      WORD wPad;
      ASSERT(pxPayload->wSize >= (pxAccess->wOffset + pxAccess->wLength));
      wPad = pxPayload->wSize - (pxAccess->wOffset + pxAccess->wLength);
      /* Cool, we are the only user: pass down the original
         pointer to the driver */
      #ifndef NDEBUG
      if(pxAccess->wLength > 74){
        ASSERT(wPad >= 47+8); /* ensure space for AAL5 trailer */
      }
      #endif
      pxDriverBufferTx->wOffset = pxAccess->wOffset;
/*      pxDriverBufferTx->wPad = wPad; */
      pxDriverBufferTx->wSize = pxPayload->wSize;

      pxDriverBufferTx->poData = poPayload;
      pxDriverBufferTx->pfnFree = pxPayload->pfnFree;

      NETPAYLOAD_UNLOCK(pxPayload);
#ifdef __INET_USE_MEMPOOL__
      NETPAYLOAD_DELUSER(pxPayload);
#else
      FREE(pxPayload); /* Usually, this happens through the DELUSER macro */
#endif
    }
    iBytesWritten = write((int)hLLInst,
                          (char *)pxDriverBufferTx,
                          (int)pxDriverBufferTx->dwLength);

    }
    break;
#endif
    default:
     NETMAIN_ASSERT(0);
  }
  SNMP(xTcpipData.ifNum[((OCTET)hIf == 0) ? 0 : 1].ifOutFrames++);
  SNMP(xTcpipData.ifNum[((OCTET)hIf == 0) ? 0 : 1].ifOutOctets += pxAccess->wLength;);

  /* Always act as if all was sent: packet loss is a fact of life */
  return(pxAccess->wLength);
}

#ifdef _ENABLE_L4_FLOW_ /* Distribution based on L4 ports */

#define DEST_PORT_OFFSET 2
DWORD
NetIfGetL4FlowLabel(NETIFCONF *pxNetIfConf,
                     NETPACKET *pxPacket,
                     NETPACKETACCESS *pxAccess )
{

    int i;
    MnDeviceInstanceConf_t *pDeviceInstanceConf;
    ubyte2 iPhyIdx, iNumPhyLinks, iSrcPort, iDestPort, iL4Label;
    ubyte *poEthHdr;
    IPHDR *pxIpHdr;
    void *pvProtocolHdr;
    ubyte2 iProtocol;
    NETIFCONF *pxIfConf;
    NETWRAPPER *pxNetWrapper;

    NETPACKET_CHECK(pxPacket);
    NETMAIN_ASSERT(pxNetIfConf != NULL);

    pxNetWrapper = NETGETWRAPPER;
    pDeviceInstanceConf = (MnDeviceInstanceConf_t *)pxNetIfConf->pMnDeviceInstance;
    iNumPhyLinks = pDeviceInstanceConf->MnNumPhysicalInstances;
    poEthHdr = pxPacket->pxPayload->poPayload + (pxAccess->wOffset);

    /* check for only IP Protocol Packets */
    /* iProtocol = (ubyte2) (*((ubyte4*)(poEthHdr + ETHTYPE_OFFSET))); Eth type */
/*
    MOC_MEMCPY((ubyte *)(&iProtocol),
               (ubyte *)(poEthHdr+ETHTYPE_OFFSET), (ubyte4)ETHTYPE_LEN);

    iProtocol = ntohs(iProtocol);
*/
    if((NetIfGetShortValue(poEthHdr+ETHTYPE_OFFSET)) != ETHID_IP)
    {
      /* All packets other than  IP are sent on current PHY which is LOGICAL */
       return (pxNetIfConf->iActivePhyLinkIfIdx);
    }
    pxIpHdr = (IPHDR *)(poEthHdr + ETHHEADER_LEN);


    /* look at the protocol and process if only TCP or UDP */
    if(pxIpHdr->oProtocol == IPROTO_TCP || pxIpHdr->oProtocol == IPROTO_UDP)
    {
        pvProtocolHdr = ((ubyte *)pxIpHdr + (pxIpHdr->oIpHdrLen * 4));
#if 0
        MOC_MEMCPY((ubyte *)(&iSrcPort), (ubyte *)(pvProtocolHdr), 2);
        MOC_MEMCPY((ubyte *)(&iDestPort), (ubyte *)(pvProtocolHdr+2), 2);

        iSrcPort = (ubyte2) (*((ubyte2 *)pvProtocolHdr)); Src Port
        iDestPort = (ubyte2) (*(((ubyte2 *)pvProtocolHdr) + sizeof(ubyte2))); Dest port
        iL4Label  = (ntohs(iDestPort) + ntohs(iSrcPort)) % iNumPhyLinks;
#endif

        /* Simple Hash Function: (SrcPort + DestPort) % Num_links */
        iL4Label = ((NetIfGetShortValue(pvProtocolHdr))+
                    (NetIfGetShortValue(pvProtocolHdr+DEST_PORT_OFFSET))) % iNumPhyLinks;
    }
    else
    {
      /* All packets other than TCP and UDP  are sent on current PHY which is LOGICAL */
       return (pxNetIfConf->iActivePhyLinkIfIdx);
    }
    /* select the physical interface using the L4 Label */
    iPhyIdx = pDeviceInstanceConf->MnPhysicalAggInstanances[iL4Label];

    pxIfConf = NETGETIFCONF(pxNetWrapper, iPhyIdx);

    /* NETMAIN_DBGP(REPETITIVE,"--------> NetIfGetL4FlowLabel: Distribute to physical interface %d, Flags %x\n",
                          pDeviceInstanceConf->MnPhysicalAggInstanances[iL4Label],
                          pxIfConf->oFlags); */

    /* check to see if the interface is UP */
    if(0 == (pxIfConf->oFlags & IFF_PHYUP))
    {
        /* The selected interface is down. Find the next active interface */
        for(i=0; i < iNumPhyLinks; i++)
        {
            iL4Label = ++iL4Label % iNumPhyLinks;

            pxIfConf = NETGETIFCONF(pxNetWrapper,
                       pDeviceInstanceConf->MnPhysicalAggInstanances[iL4Label]);
            if(pxIfConf->oFlags & IFF_PHYUP)
            {
                /* found an active physical interface */
                /* NETMAIN_DBGP(REPETITIVE,"--------> NetIfGetL4FlowLabel: Interface down: Selected new physical interface %d\n",
                          pDeviceInstanceConf->MnPhysicalAggInstanances[iL4Label]); */

                return (pDeviceInstanceConf->MnPhysicalAggInstanances[iL4Label]);
            }
        }
        if(i == iNumPhyLinks)
        {
            /* No Active Links on the interface */
            /* return (pxNetIfConf->iActivePhyLinkIfIdx); */
            return -1;
        }
    }
    return (iPhyIdx);
}

#endif /* _ENABLE_L4_FLOW_ */

