#ifndef __COMMON_H__
#define __COMMON_H__

/* Map the build flavor into more meaningful constants internal
 * to the library.  The constant _FLAVOR_xx where xx is
 * the build flavor will be defined by the build environment.
 *
 * Be sure to check that a valid build flavor is defined.
 *
 * This file should be included by all source files.
*/

#if defined(_FLAVOR_gn)

#elif defined(_FLAVOR_ca)

#elif defined(_FLAVOR_irom)

#else
#  error Unknown Build Flavor
#endif

#endif
