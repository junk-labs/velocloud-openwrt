/*
 * ntp.c
 *
 * Network Time functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include <NNstyle.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <pthread.h>
#include <strings.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/time.h>
#include <net/if.h>
#include <netdb.h>
#include <stdio.h>
#include <ctype.h>

/*#include "protocol.h" */

#if defined(_AUDACITY) || defined(_AUDACITYT2)
#include <setupnet.h>
#endif

#include "ntpapi.h"
#include "ntpint.h"

/*#include "protutil.h" */
/*#undef PROFILE */

/* NTP Network Time Protocol since Jan 1, 1900 in units of ~200 pico seconds */
/* ATP Ancient Time Protocol sinc Oct 15, 1582 in units of ~100 nano seconds */

int _iNtpInitCount=0;
DWORD _NTPTime[2] = {0,0};   /*   2.328306436539e-10 sec/bit */
DWORD _ATPTime[2] = {0,0};   /*  1.0e-7             sec/bit */
BOOL bTimeSynced=FALSE;
DWORD g_dwLastUpdateTime=0;
pthread_mutex_t _lckNtp;

#define NTPTICKper10MSEC 0x28f5c29 /* Should be 10-3 / 2.328306436539e-10)
                      with an error of .19 ticks)  */
static DWORD gs_dwNtpTick10ms[2]={0,NTPTICKper10MSEC};
#define ATPTICKper10MSEC   100000       /* 0x186a0 10e-3 / 1.0e-7 */
static DWORD gs_dwAtpTick10ms[2]={0,ATPTICKper10MSEC};


/* ATP ticks per NTP tick    (ATPTICKper10MSEC/NTPTICKper10MSEC)  Should be  429.4967295999 */

#define ATPperNTP   0x0989            /*  0.00232830643437 * 2**20 */
#define ATPDELTADAYS      115862       /* 0x1c496 */
#define SECPERDAY        24*60*60      /* 0x15180 */
/*multiplied = 0x254abc100 */
/*1e7 =         0x989680 */
/* result to ATPDelta[2] */

#define NTPPOLLTIME (100/*ms*/)

/* Approximate difference in 100 nanosec units from Oct 15,1582 to Jan 1 1900 *
   Delta days = 115862.0     */
DWORD ATPDelta[2] = {0x015e9acd, 0xDF931000};

/* Source of NTP time */
/* The LLNL clock has been discontinued */
/*DWORD dwNtpIPAddress = 0x80730e61;  */ /* 128.115.14.97 = clock.llnl.gov */
DWORD dwNtpIPAddress = 0xcc98b848;  /* 204.152.184.72 = clock.isc.org */

int iNtpSocket=-1;

/*/////////////////////////////////////////////////////////////////////////////
/* _BigAdd */
/* 64bit add */
/////////////////////////////////////////////////////////////////////////////*/
void _BigAdd(DWORD x[],DWORD y[],DWORD a[])
{
  DWORD temp;
  temp = y[1];
  x[1] = y[1] + a[1];
  x[0] = y[0] + a[0];
  if(temp > x[1])
    x[0]++;
}

/*/////////////////////////////////////////////////////////////////////////////
/* _BigMultiply */
/* 64bit * 16bit multiply */
/////////////////////////////////////////////////////////////////////////////*/
void _BigMultiply(DWORD x[],DWORD y[],WORD m)
{
  DWORD temp1;
  DWORD temp2;

  temp1 = y[1] & 0xffff;
  temp1 *= m;
  temp2 = (y[1] >> 16) & 0xffff;
  temp2 *= m;
  x[1] = temp1 + (temp2 << 16);
  x[0] = y[0]*m + (temp2 >> 16);
  if (x[1] < temp1)
    x[0]++;
}

/*/////////////////////////////////////////////////////////////////////////////
/* _NtpIncrement */
/////////////////////////////////////////////////////////////////////////////*/
void _NtpIncrement()
{
  struct timeval tvCurrentTime;
  DWORD dwTimeSinceLast;
  DWORD dwCurrentTime;
  WORD wUpper;
  WORD wLower;

  pthread_mutex_lock(&_lckNtp);
  gettimeofday(&tvCurrentTime,NULL);

  /* in units of 10ms */
  dwCurrentTime=(tvCurrentTime.tv_sec*100)+(tvCurrentTime.tv_usec/10000);
  dwTimeSinceLast=dwCurrentTime-g_dwLastUpdateTime;
  g_dwLastUpdateTime=dwCurrentTime;

  wLower=(WORD)(dwTimeSinceLast&0xffff);
  wUpper=(WORD)((dwTimeSinceLast>>16)&0xffff);

  ASSERT(wUpper==0);

  /* update ATP */
  {
    DWORD x[2];
    _BigMultiply(x,gs_dwAtpTick10ms,wLower);
    _BigAdd(_ATPTime,_ATPTime,x);
  }

  /* update NTP */
  {
    DWORD x[2];
    _BigMultiply(x,gs_dwNtpTick10ms,wLower);
    _BigAdd(_NTPTime,_NTPTime,x);
  }
  pthread_mutex_unlock(&_lckNtp);
}

/*/////////////////////////////////////////////////////////////////////////////
/* _NtpUpdate */
/*  Updates the stored time. Called whenever a new time is retrieved from */
/* the network time server */
/////////////////////////////////////////////////////////////////////////////*/
BOOL _NtpUpdate(DWORD upper, DWORD lower)
{
  BOOL bReturn=FALSE;
  SYSLOG(LOG_DEBUG,"_NtpUpdate: %lx %lx (old %lx %lx)\n",
     upper,lower,_NTPTime[0],_NTPTime[1]);

  if (upper==0 && lower==0) {
    SYSLOG(LOG_ERR,"_NtpUpdate called with ZERO time - not valid!\n");
  } else {
    struct timeval tvCurrentTime;

    pthread_mutex_lock(&_lckNtp);
    gettimeofday(&tvCurrentTime,NULL);
    g_dwLastUpdateTime=(tvCurrentTime.tv_sec*100)+(tvCurrentTime.tv_usec/10000);
    _NTPTime[0] = upper;
    _NTPTime[1] = lower;
    _BigMultiply(_ATPTime,_NTPTime,ATPperNTP);
    _ATPTime[1] = (_ATPTime[1] >> 20) + ((_ATPTime[0] & 0x0fffff) << 12);
    _ATPTime[0] = _ATPTime[0] >> 20;
    _BigAdd(_ATPTime,_ATPTime,ATPDelta);

    bTimeSynced=TRUE;
    bReturn=TRUE;
    pthread_mutex_unlock(&_lckNtp);
  }

  return bReturn;
}

/*/////////////////////////////////////////////////////////////////////////////
/* NtpGet */
/* Returns the current (or best guess) NTP time */
/* return code is true if at least one network sync has occurred */
/////////////////////////////////////////////////////////////////////////////*/
int NtpGet(DWORD *upper, DWORD *lower)
{
  _NtpIncrement();

  pthread_mutex_lock(&_lckNtp);
  *upper = _NTPTime[0];
  *lower = _NTPTime[1];
  pthread_mutex_unlock(&_lckNtp);

  return bTimeSynced;
}

/*/////////////////////////////////////////////////////////////////////////////
/* NetGetAtp */
/* Returns the current (or best guess) ATP time */
/////////////////////////////////////////////////////////////////////////////*/
int NtpGetAtp(DWORD *upper, DWORD *lower)
{
  _NtpIncrement();

  pthread_mutex_lock(&_lckNtp);
  *upper = _ATPTime[0];
  *lower = _ATPTime[1];
  pthread_mutex_unlock(&_lckNtp);

  return bTimeSynced;
}

NtpState _NtpState = NTP_START;
DWORD _dwNtpRetryCounter=0;

void _NtpRecvCb(int lsockfd, void *oData,
        size_t sBytesRead, struct sockaddr *from, socklen_t addrlen, void *arg)
{
    if (sBytesRead==NTP_PKT_LEN) {
    DEBUG(SYSLOG(LOG_INFO,"Got rsp from NTP server\n"));
      NtpPacket* pinpkt=(NtpPacket*)oData;

      if (_NtpUpdate(ntohl(pinpkt->xmt.Xl_i),
             ntohl(pinpkt->xmt.Xl_f))) {
        _NtpState=NTP_DONE;
      } else {
        _NtpState=NTP_SEND; /* retry request */
      }
    }
}
/*/////////////////////////////////////////////////////////////////////////////
/* _NtpStateMachine */
/* network time retrieval state machine */
/////////////////////////////////////////////////////////////////////////////*/
void _NtpStateMachine()
{
  switch (_NtpState)
    {
    case NTP_START:   /* open socket */
      {
    DEBUG(SYSLOG(LOG_INFO,"Connecting to NTP server 0x%lx\n", dwNtpIPAddress));

    iNtpSocket=socket(AF_INET, SOCK_DGRAM, 0);
    fcntl(iNtpSocket,F_SETFL,fcntl(iNtpSocket,F_GETFL,0)|O_NONBLOCK);
    ASSERT(iNtpSocket>=0);
    if (iNtpSocket>=0) {
#ifdef ASYNC_MODEL
      OCTET oData[NTP_PKT_LEN+1];
#endif
      DEBUG(SYSLOG(LOG_DEBUG,"NTP port opened %lx\n",(DWORD)iNtpSocket));
#ifdef ASYNC_MODEL
      /* register async recv callback */
      if ( recvfrom(iNtpSocket, oData, sizeof(oData)-1, 0, NULL, NULL,
                _NtpRecvCb,NULL, NULL, NULL) == 0 ){
          _NtpState = NTP_SEND;
      }else
          iNtpSocket=-1;
#else
      _NtpState = NTP_SEND;
#endif
    } else {
      iNtpSocket=-1;
      DEBUG(SYSLOG(LOG_ERR,"!!_NtpStateMachine::udpopen failed\n"));
          _dwNtpRetryCounter= 15000/NTPPOLLTIME;  /* try again in 15 secs */
      _NtpState = NTP_RESYNC;
    }
      }
      break;

    case NTP_SEND:    /* send ntp request */
      {
        NtpPacket* poutpkt;

    /* allocate zeroed packet */
    poutpkt=calloc(1,sizeof(NtpPacket));
    ASSERT(poutpkt!=NULL);

    if (poutpkt!=NULL) {
      poutpkt->li_vn_mode = PKT_LI_VN_MODE(0, NTP_VERSION, MODE_CLIENT);
      ASSERT(iNtpSocket>=0);
      {
        struct sockaddr_in sinAddress;
        memset(&sinAddress,0,sizeof(struct sockaddr_in));
        sinAddress.sin_family=AF_INET;
        sinAddress.sin_addr.s_addr=htonl(dwNtpIPAddress);
        sinAddress.sin_port=htons(NTP_PORT);
        sendto(iNtpSocket,poutpkt,NTP_PKT_LEN,0,
           (struct sockaddr*)&sinAddress,sizeof(struct sockaddr_in));
      }
      FREE(poutpkt);
    }
    _dwNtpRetryCounter=15000/NTPPOLLTIME;   /* 15 seconds */
    _NtpState = NTP_WAIT_FOR_REPLY;
      }
      break;

    case NTP_WAIT_FOR_REPLY:   /* wait for data from ntp - retry send after 15sec */
      {
#ifndef ASYNC_MODEL /* not Async model */
    OCTET oData[NTP_PKT_LEN+1];
    LONG sBytesRead;
    sBytesRead=recvfrom(iNtpSocket,oData,NTP_PKT_LEN,0,NULL,NULL,NULL,NULL);

    if (sBytesRead==NTP_PKT_LEN) {
      NtpPacket* pinpkt=(NtpPacket*)oData;

      if (_NtpUpdate(ntohl(pinpkt->xmt.Xl_i),
             ntohl(pinpkt->xmt.Xl_f))) {
        _NtpState=NTP_DONE;
      } else {
        _NtpState=NTP_SEND; /* retry request */
      }
    }
    else {
#endif
      _dwNtpRetryCounter--;
      if (_dwNtpRetryCounter==0) {
        _NtpState=NTP_SEND;  /* retry request */
      }
#ifndef ASYNC_MODEL
    }
#endif
      }
      break;

    case NTP_DONE:   /* close socket and set resync time (30mins) */
      {
    if (iNtpSocket>=0) {
      close(iNtpSocket);
      iNtpSocket=-1;
    }
        _dwNtpRetryCounter= 1800000/NTPPOLLTIME;  /* 30 minutes */
    _NtpState = NTP_RESYNC;
      }
      break;

    case NTP_RESYNC:   /* countdown resync time */
      {
    _dwNtpRetryCounter--;
    if (_dwNtpRetryCounter==0) {
      _NtpState=NTP_START;
    }
      }
      break;

    default:
      break;

    }
}


#ifdef NETSRV_THREAD
BOOL _bNtpKillThread=FALSE;
#else
OCTET g_hInstNTP = 0;
#endif

/*/////////////////////////////////////////////////////////////////////////////
/* _NtpThread */
/* Independant processing thread */
/////////////////////////////////////////////////////////////////////////////*/
void* _NtpThread(void * pArg)
{
  int iIncrementCounter=1;

#ifdef NETSRV_THREAD
#ifdef PROFILE
  H_PROFILE_THREAD hProfNtp;

  hProfNtp = ProfileRegisterThread("NTP", pthread_self());
  ASSERT(hProfNtp);
#endif

  while (!_bNtpKillThread) {
    {
      struct timespec stTime;
      stTime.tv_sec=0;
      stTime.tv_nsec=NTPPOLLTIME*1000000;
#ifdef PROFILE
      ProfilePostEvent(hProfEvtEndRun, NULL);
#endif
      nanosleep(&stTime,NULL);
    }
#endif
    _NtpStateMachine();
    iIncrementCounter--;
    if (iIncrementCounter<=0) {
      _NtpIncrement();
      iIncrementCounter=60000/NTPPOLLTIME; /* 1min */
    }
#ifdef NETSRV_THREAD
  }

  /* reset kill flag */
  _bNtpKillThread=FALSE;
#ifdef PROFILE
  ProfileUnregisterThread(hProfNtp);
#endif
#endif
  return NULL;
}

/*/////////////////////////////////////////////////////////////////////////////
/* NtpSetDefaultServer */
/* dwIPAddress - IP address of NTP server. 0 means use current selection */
/* set by  a previous call, or the compiled default if this is first call */
/////////////////////////////////////////////////////////////////////////////*/
void NtpSetDefaultServer(DWORD dwIPAddress)
{

#if defined(_AUDACITY) || defined(_AUDACITYT2)

  if (0 == dwIPAddress) {
    /* If no address was provided check if stack has one */
    SetupNetGetNTPIPAddr(&dwIPAddress);
  }
#endif

  pthread_mutex_lock(&_lckNtp);

  if (dwIPAddress) {
    dwNtpIPAddress=dwIPAddress;
  }

  pthread_mutex_unlock(&_lckNtp);
}

/*/////////////////////////////////////////////////////////////////////////////
/* NtpInit */
/* Initialize NTP service. Starts processing thread */
/* dwIPAddress - IP address of NTP server. 0 means use current selection (if */
/* a previous init, or default if this is first init) */
/////////////////////////////////////////////////////////////////////////////*/
void NtpInit(DWORD dwIPAddress)
{
  static OCTET bFirstTime = TRUE;
  if (bFirstTime == TRUE) {
    pthread_mutex_init(&_lckNtp, NULL);
    bFirstTime = FALSE;
  }

  NtpSetDefaultServer(dwIPAddress);

  pthread_mutex_lock(&_lckNtp);
  _iNtpInitCount++;
  pthread_mutex_unlock(&_lckNtp);

  if (_iNtpInitCount==1) {
    if (!bTimeSynced) {
      /* initialize update base */
      _NtpUpdate(0,1);
    }
#ifdef NETSRV_THREAD
    {
      pthread_t tid;
      _bNtpKillThread=FALSE;
      pthread_create(&tid,NULL,_NtpThread,0);
    }
#else
    g_hInstNTP = ProtocolServiceRegister(_NtpThread, NTPPOLLTIME);
#endif
  }

}

/*/////////////////////////////////////////////////////////////////////////////
/* NtpTerm */
/* Terminate NTP service. Ends processing thread */
/////////////////////////////////////////////////////////////////////////////*/
void NtpTerm()
{
  pthread_mutex_lock(&_lckNtp);
  _iNtpInitCount--;
  if (_iNtpInitCount==0) {
    struct timespec stTime;
#ifdef NETSRV_THREAD
    _bNtpKillThread=TRUE;
#else
    ProtocolServiceUnregister(g_hInstNTP);
#endif
    stTime.tv_sec=0;
    stTime.tv_nsec=NTPPOLLTIME*2*1000;  /* 2x poll time */
    nanosleep(&stTime,NULL);
  } else if (_iNtpInitCount<0) {
    /* error case - just fix it. */
    _iNtpInitCount=0;
  }
  pthread_mutex_unlock(&_lckNtp);
}

/*//////////////////////////// END OF FILE /////////////////////////////////*/







