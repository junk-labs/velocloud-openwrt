/*
 * meterdefs.h
 *
 * Meter internal API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _METERDEFS_H_
#define _METERDEFS_H_

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

typedef struct {
  /* provisioned settings */
  DWORD dwBitRate; /* in bytes/sec */

  /* calculated from provisioned bitrate, based on the following:
   *  - window size
   *  - prior high priority packets in previous windows
   */
  DWORD dwBytesPerWindowReservedHigh;
  DWORD dwBytesPerWindowMaxTotal;

  DWORD dwBytesPerWindowReservedMinimum; /* when there is high traffic */
  DWORD dwBytesPerWindowReservedHighDefault;

  /* window data to be reset once in new window */
  struct {
    DWORD dwBytesPassedHigh;
    DWORD dwBytesPassedTotal;
    DWORD dwBytesReqForHigh; /* to be fed into next dwMaxBytesPerWindowHigh */
  } xWindow;

  /* Long term assessment window */
  struct {
    DWORD dwWindowNo;
    DWORD dwBytesPassedHighMax;
  } xAssessWindow;
} GRPSTATE;

#define METER_ASSESSWINDOWS 10

typedef struct {
  /* provisioned settings */
  OCTET oGroupIdx; /* which group this maps to */
} IFSTATE;

typedef struct {
  DWORD dwTimeSlot; /* in millisces */
  GRPSTATE axGroup[METER_MAXNUM_GROUP];
  IFSTATE axIf[METER_MAXNUM_IF];
  OCTET oNumberGrps;
} METERSTATE;


/*****************************************************************************
 *
 * MOC_EXTERN variables
 *
 *****************************************************************************/

/*
 * Meter structure
 */
MOC_EXTERN METERSTATE xMeter;


#endif /* #ifndef _METERDEFS_H_ */

