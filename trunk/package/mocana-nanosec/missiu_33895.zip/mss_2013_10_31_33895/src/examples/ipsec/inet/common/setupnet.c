/*
 * setupnet.c
 *
 * Functions to configure the network stack based on config file variables
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcfg.h"
#include "setupnet.h"
#include "configapi.h"
#include "../include/if_dl.h"
#include "netstack.h"
#include "routercfgapi.h"
#include "nettime.h"
#ifdef NET_MULTIF
#include "meter.h"
#endif

#ifdef DHCP_CUSTOM_OPTIONS
#include "netcommon.h"
#include "dhcpclient.h"
#endif /* DHCP_CUSTOM_OPTIONS */

/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/

DWORD g_dwSetupNetDebugLevel = 3;

const VAR_IOCTL pxIfVarIoctlTableSet[] = {
  {"L3PROT",             MO_SIOCSIFITYPE},       /* MUST be first item! */
  {"IPADDRESS",          MO_SIOCSIFIADDR},
  {"IPNETMASK",          MO_SIOCSIFINETMASK},
  {"IPGATEWAY",          MO_SIOCSIFIGWADDR},
  {"IPDNS",              MO_SIOCSIFIDNS},
  {"DNSDOMAINNAME",      MO_SIOCSIFIDN},
  {"DNSHOSTNAME",        MO_SIOCSIFIHN},
  {"IPTOS",              MO_SIOCSIFITOS},

#ifdef PPP
  {"PPP_USERNAME",       MO_SIOCSIFIPPPNAME},
  {"PPP_PASSWORD",       MO_SIOCSIFIPPPPW},
  {"PPP_IDLETO",         MO_SIOCSIFIPPPIDLETO},
  {"PPP_ECHOTO",         MO_SIOCSIFIPPPECHOTO},
  {"PPP_ECHOCOUNT",      MO_SIOCSIFIPPPECHOCOUNT},
  {"PPPOE_SRV",          MO_SIOCSIFIPPPSRV},
  {"PPPOE_AC",           MO_SIOCSIFIPPPAC},
#endif

#ifdef NET_BR
  {"BCAST",              MO_SIOCSIFIBRBCASTLIMIT},
  {"MCAST",              MO_SIOCSIFIBRMCASTLIMIT},
  {"NETCONF",            MO_SIOCIFIBRENABLE},
#endif

  {NULL,                 0}  /* End marker */
};


#ifdef NET_DSL
const VAR_IOCTL pxAtmIfVarIoctlTableSet[] = {
  {"VPI",                MO_SIOCSIFIATMVPI},
  {"VCI",                MO_SIOCSIFIATMVCI},
  {"MODE",               MO_SIOCSIFIATMMODE},
  {"CHANNELMODE",        MO_SIOCSIFIATMLATENCY},
  {NULL,                 0}  /* End marker */
};
#endif
/* JJ */
BOOL g_bForceMacTo0090a0ffffff=TRUE;

/****************************************************************************
 *
 * Local private functions
 *
 ****************************************************************************/

/*
 * _SetNetIfParameter
 *  Configure a specific parameter
 *
 *  Args:
 *   iSock               Socket interface for ioctl use
 *   oIfIdx              Interface index
 *   dwSocketIoctl       Configuration ioctl to use
 *   pchParamValue       Argument to ioctl
 *
 *  Return
 *   0
 */
LONG _SetNetIfParameter(int   iSock,
                        OCTET oIfIdx,
                        DWORD dwSocketIoctl,
                        char *pchParamValue)
{
  if (iSock<0) {
    ASSERT(0);
    return -1;
  }

  else {
    struct ifreq xIfReq;
    struct ifconf xIfConf;
    mnIoctlArgList_t mnIoctlArgList;

    mnIoctlArgList.ifreq = (void *)&xIfReq;
    mnIoctlArgList.ifconf = (void *)&xIfConf;
    xIfReq.ifr_name[0] = oIfIdx;

    /* Configure parameter */
    switch(dwSocketIoctl) {

    case MO_SIOCIFIOPEN:                  /* Open Interface */
    case MO_SIOCIFICLOSE:                 /* Close Interface */
      ioctl(iSock, dwSocketIoctl, &mnIoctlArgList);
      break;


    case MO_SIOCSIFIADDR:                 /* IP address */
    case MO_SIOCSIFINETMASK:              /* Subnet Mask */
    case MO_SIOCSIFIGWADDR:               /* Default gateway */
    case MO_SIOCSIFIDNS:                  /* DNS server */
    case MO_SIOCSIFIBRDADDR:              /* Broadcast address */
      {
        DWORD dwAddress = 0;
        if (MOC_STRCMP((sbyte *)pchParamValue,(sbyte *)"")) {
          dwAddress = htonl(inet_addr(pchParamValue));
        }
        ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr = dwAddress;
        ioctl(iSock, dwSocketIoctl, &mnIoctlArgList);
      }
      break;


    case MO_SIOCSIFITYPE:                 /* Interface type */
      xIfReq.ifr_type = IFT_ETHER;     /* Default is Ethernet */

#ifdef PPP
      if (!MOC_STRCMP((sbyte *)pchParamValue,(sbyte *)"PPPOE")) {
        xIfReq.ifr_type = IFT_PPPOE;
      }
#endif
#ifdef NET_DSL
      if (!MOC_STRCMP((sbyte *)pchParamValue,(sbyte *)"NULL")) {
        xIfReq.ifr_type = IFT_NULL;
      }
      else if (!MOC_STRCMP((sbyte *)pchParamValue,(sbyte *)"PPP")) {
        xIfReq.ifr_type = IFT_PPP;
      }
#endif

      ioctl(iSock, dwSocketIoctl, &mnIoctlArgList);
      break;


    case MO_SIOCSIFIDN:                   /* Domain Name */
    case MO_SIOCSIFIHN:                   /* Host Name */
#ifdef PPP
    case MO_SIOCSIFIPPPNAME:              /* PPP Username */
    case MO_SIOCSIFIPPPPW:                /* PPP Password */
    case MO_SIOCSIFIPPPSRV:               /* PPPoE Service Name */
    case MO_SIOCSIFIPPPAC:                /* PPPoE AC Name */
#endif
      xIfConf.ifc_len = strlen(pchParamValue);
      xIfConf.ifc_buf = pchParamValue;
      mnIoctlArgList.oIfIdx = oIfIdx;
      ioctl(iSock, dwSocketIoctl,&mnIoctlArgList);
      break;


    case MO_SIOCSIFIVLAN:                 /* VLAN settings */
#ifdef PPP
    case MO_SIOCSIFIPPPIDLETO:            /* PPP idle timeout (minutes) */
    case MO_SIOCSIFIPPPECHOTO:            /* PPP echo timeout (seconds) */
    case MO_SIOCSIFIPPPECHOCOUNT:         /* PPP echo count */
#endif
#ifdef NET_BR
    case MO_SIOCSIFIBRBCASTLIMIT:         /* Broadcast limit (%) */
    case MO_SIOCSIFIBRMCASTLIMIT:         /* Multicast limit (%) */
#endif
      if (MOC_STRCMP((sbyte *)pchParamValue,(sbyte *) "")) {
        xIfReq.ifr_value = MOC_ATOL(pchParamValue, NULL);
      } else {
#ifdef PPP
        if (dwSocketIoctl == MO_SIOCSIFIPPPIDLETO) {
          xIfReq.ifr_value = 0;    /* Infinite timeout */
        }
        if (dwSocketIoctl == MO_SIOCSIFIPPPECHOTO) {
          xIfReq.ifr_value = 0;    /* Infinite timeout */
        }
        if (dwSocketIoctl == MO_SIOCSIFIPPPECHOCOUNT) {
          xIfReq.ifr_value = -1;   /* Infinite timeout */
        }
#endif
#ifdef NET_BR
        if (dwSocketIoctl == MO_SIOCSIFIBRBCASTLIMIT ||
            dwSocketIoctl == MO_SIOCSIFIBRMCASTLIMIT) {
          xIfReq.ifr_value = 100;  /* 100% */
        }
#endif
      }
      ioctl(iSock, dwSocketIoctl, &mnIoctlArgList);
      break;

#ifdef NET_BR
    case MO_SIOCIFIBRENABLE:
      xIfReq.ifr_value = TRUE;
#ifdef ROUTER
      if (!MOC_STRCMP((sbyte *)pchParamValue,(sbyte *) "ROUTED")) {
        /* Disable bridging if it's a routed interface */
        xIfReq.ifr_value = FALSE;
      }
#endif
      ioctl(iSock, dwSocketIoctl, &mnIoctlArgList);
      break;
#endif


#ifdef NET_DSL
    case MO_SIOCSIFIATMVPI:
    case MO_SIOCSIFIATMVCI:
      if (MOC_STRCMP((sbyte *)pchParamValue, (sbyte *)"")) {
        xIfReq.ifr_value = MOC_ATOL(pchParamValue, NULL);
      ioctl(iSock, dwSocketIoctl, &mnIoctlArgList);
      }
      break;

    case MO_SIOCSIFIATMMODE:
      if (!MOC_STRCMP((sbyte *)pchParamValue,(sbyte *) "VCMUX")) {
        xIfReq.ifr_value = IF_ATM_MODE_VCMUX;
      } else {
        xIfReq.ifr_value = IF_ATM_MODE_LLCSNAP;
      }
      ioctl(iSock, dwSocketIoctl, &mnIoctlArgList);
      break;

    case MO_SIOCSIFIATMLATENCY:
      if (!MOC_STRCMP((sbyte *)pchParamValue,(sbyte *) "INTERLEAVED")) {
        xIfReq.ifr_value = IF_ATM_LATENCY_INTERLEAVED;
      } else {
        xIfReq.ifr_value = IF_ATM_LATENCY_FAST;
      }
      ioctl(iSock, dwSocketIoctl, &mnIoctlArgList);
      break;
#endif
#ifdef LINK_AGGREGATION
    case MO_SIOCIFIAGGRADD:
    case MO_SIOCIFIAGGRDEL:
      xIfReq.ifr_value = MOC_ATOL(pchParamValue, NULL);
      ioctl(iSock, dwSocketIoctl, &mnIoctlArgList);
      break;
#endif

    }
  }

  return 0;
}


/*
 * _ComputeVlanValue
 *  Compute the VLAN WORD (VLAN ID tag and Priority tag) for an interface
 *
 *  Args:
 *   oIfIdx              Interface index
 *
 *  Return
 */
WORD _ComputeVlanValue(OCTET oIfIdx)
{
  char cTmpString[30];
  char chParamValue[CONFIG_MAXPARAMLENGTH+1];
  BOOL bVID = FALSE;
  BOOL bPriority = FALSE;
  WORD wValue = 0xFFFF;      /* Default if neither value is set */
  WORD wVID = 0;             /* Default if blank */
  WORD wPriority = 0;        /* Default if blank */

  sprintf(cTmpString,"IF%dVLANTAG",oIfIdx);
  if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
    wVID = MOC_ATOL(chParamValue, NULL);
    bVID = TRUE;
  }

  sprintf(cTmpString,"IF%dPRIORITYTAG",oIfIdx);
  if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
    wPriority = MOC_ATOL(chParamValue, NULL);
    bPriority = TRUE;
  }

  if (bVID || bPriority) {
    wValue = (wPriority << NETVLAN_PRISHIFT) | (wVID & NETVLAN_VIDMASK);
  }

  return wValue;
}

#ifdef NET_MULTIF
#define METER_TIMESLOT 100 /* msecs */

const OCTET aoGroup0[] = {0};
#ifdef NET_DSL
OCTET aoGroup1[IFNUMMAX-1] = {0};
#else
const OCTET aoGroup1[] = {1};
#endif
typedef struct {
  OCTET const * poMeterIfs;
  OCTET  oNumIfs;
} MeterGroup;

MeterGroup axMeterGroups[] = {
  { aoGroup0, sizeof(aoGroup0) },
  { aoGroup1, sizeof(aoGroup1) }
};

#define N_METERGRPS (sizeof(axMeterGroups)/sizeof(MeterGroup))

/*
 * _SetupMeter
 *   Set up the metering module for the stack.
 *
 *   Args:
 *    eType                    Type of LAN interface
 *                             setup (see setupnet.h for def)
 *   Return:
 *    SetupNetReturn           error code (see setupnet.h for def)
 */
void
_SetupMeter(void)
{
  LONG lRv;
  METERGROUPMEMBER xMeterGroup;
  OCTET oGrpIdx, oIfArrIdx;

  lRv = MeterInitialize();
  ASSERT(0L==lRv);

  MeterMsg(METERMSG_SETTIMESLOT, (H_METERDATA)METER_TIMESLOT);

  MeterMsg(METERMSG_SETNUMBERGROUPS, (H_METERDATA)N_METERGRPS);

#ifdef NET_DSL
  {
    int i;
    for (i=0; i<(IFNUMMAX-1); i++) {
      aoGroup1[i] = i+1;
    }
  }
#endif

  for (oGrpIdx=0; oGrpIdx<N_METERGRPS; oGrpIdx++) {
    xMeterGroup.oGroupIdx = oGrpIdx;

    for (oIfArrIdx=0; oIfArrIdx<axMeterGroups[oGrpIdx].oNumIfs; oIfArrIdx++) {
      xMeterGroup.oIfIdx = axMeterGroups[oGrpIdx].poMeterIfs[oIfArrIdx];
      MeterMsg(METERMSG_SETGROUPMEMBER, (H_METERDATA)&xMeterGroup);
    }
  }
}
#endif /* End metering code */


/*
 * _ConvertToMac
 *  Convert a string to a MAC address (array of 6 octets)
 *
 *  Args:
 *   poMac               Pointer to 6 OCTET array to fill
 *   pchMacString        String containing MAC address
 *
 *  Return
 */
void _ConvertToMac(OCTET *poMac, char *pchMacString)
{
#if 0
  if (poMac && pchMacString && strlen(pchMacString)==12) {
    int j;
    int iMac[6];

    for (j=0;j<strlen(pchMacString);j++) {
      pchMacString[j] = MTOUPPER(pchMacString[j]);
    }

    sscanf(pchMacString,"%02X%02X%02X%02X%02X%02X",
           &iMac[0],&iMac[1],&iMac[2],&iMac[3],&iMac[4],&iMac[5]);
    poMac[0]=iMac[0];
    poMac[1]=iMac[1];
    poMac[2]=iMac[2];
    poMac[3]=iMac[3];
    poMac[4]=iMac[4];
    poMac[5]=iMac[5];
  }
#endif
}


#ifdef DHCP_CUSTOM_OPTIONS

void _DHCPCustomCB(OCTET oOption, OCTET * poResponseBuf, OCTET oLen)
{
  SETUPNET_DBGP(NORMAL,"<<DHCP Client Custom Option Callback>> response %d, length %d,", oOption, oLen);
  while (oLen--) {
        SETUPNET_DBGP(NORMAL," %d", *poResponseBuf++);
  }
  SETUPNET_DBGP(NORMAL,"\n");
}

void _DHCPErrorCB(OCTET oIf, OCTET oMsg)
{
  SETUPNET_DBGP(NORMAL,"<<DHCP Client Callback>> Interface:%d Message:%d\n",
                oIf,
                oMsg);
}

#endif /*DHCP_CUSTOM_OPTIONS */

/*
 * SetupNetStack
 *   Set up the network stack.
 *
 *   Args:
 *    eType                    Type of LAN interface
 *                             setup (see setupnet.h for def)
 *
 *   Return:
 *    SetupNetReturn           error code (see setupnet.h for def)
 */
SetupNetReturn SetupNetStack(SetupNetType eSetupType)
{
  int iSock;
  OCTET oIfIdx, oLIfIdx;
  OCTET oIfNum = 1;    /* Default */
  char cTmpString[30];
  char chParamValue[CONFIG_MAXPARAMLENGTH+1];
  OCTET aoMac[6], macLast;
  static BOOL bSetup = FALSE;
  int iRv;
  mnIoctlArgList_t mnIoctlArgList;

#ifdef NET_MULTIF
  BOOL bMacSpoofing = FALSE;
  OCTET aoSpoofMac[6];
#endif

  /* check if forced mac needed (mac burn mode) */
  if (eSetupType==SETUPNET_MACBURN) {
    g_bForceMacTo0090a0ffffff=TRUE;
  }

#if 0
  if (bSetup != TRUE) {
    /* Start up the network stack (first call only) */
    NetInitialize();
#ifdef NET_MULTIF
    /* Setup metering module appropriately for non-endpoint apps */
    _SetupMeter();
#endif
  }
#endif

  bSetup = TRUE;

  /* Open a socket */
  if ((iSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return -1;
  }

#ifdef NET_MULTIF
#if 0

/* Note the return value is oIfNum  */
  /* Get the number of interfaces */
  ioctl(iSock, MO_SIOCGIFNUM, &oIfNum);
#endif

#if 0
  ASSERT(oIfNum > 0);

  /* Get the 'spoofed' MAC address value for the WAN interfaces */
  if (ConfigGetParam("WANMACSPOOF", chParamValue,
                     CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
    if (strlen(chParamValue) == 12) {
      bMacSpoofing = TRUE;
      _ConvertToMac(aoSpoofMac, chParamValue);
    }
  }
#endif
#endif

  SETUPNET_DBGP(NORMAL,"SetNetStack: There are %d interfaces\n",oIfNum);

  /* Get the MAC address from the flash file */
  if (SetupNetGetMacAddress(&aoMac[0]) != SETUPNET_OK) {
    ASSERT(0);
    SETUPNET_DBGP(ERROR,"Failed to get mac address from flash\n");
    return SETUPNET_MACMISSING;
  }
  macLast = aoMac[5];

#if 0
  /*
   * Interface Configuration
   */
  for (oIfIdx=0; oIfIdx<oIfNum; oIfIdx++) {
    BOOL bEnabled = FALSE;
    BOOL bDhcp = TRUE;
    BOOL bForcedConfig = FALSE;
    BOOL bLogical = TRUE;
    int j = 0;
    struct ifreq xIfReq;

    xIfReq.ifr_name[0] = oIfIdx;

    SETUPNET_DBGP(NORMAL,"SetNetStack: configuring interface %d\n",oIfIdx);

#ifdef LINK_AGGREGATION
#if 1
    if ( oIfIdx > (oIfNum - 3) ) /* last two interfaces */
#else /* We do not retrieve from config */
    sprintf(cTmpString,"IF%dLOGICAL",oIfIdx);
    if ( ConfigGetParam(cTmpString, chParamValue,
                         CONFIG_MAXPARAMLENGTH) == CONFIG_OK &&
         MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"YES") == 0 )
#endif
       bLogical = TRUE;
    else
       bLogical = FALSE;
#endif

    if (oIfIdx == 0) {
      /* LAN is always ethernet and enabled */
      bEnabled = TRUE;
      if (ConfigGetParam("IF0ENABLED", chParamValue,
                         CONFIG_MAXPARAMLENGTH) != CONFIG_OK) {
        ConfigSetParam("IF0ENABLED","YES");
      }

      _SetNetIfParameter(iSock, 0, MO_SIOCSIFITYPE, "ETH");

#ifdef NET_MULTIF
#if 0 /* RS removed special treatment for intf 0 */
      {
        LONG lReturn = ConfigGetParam("IF0DHCP", chParamValue, CONFIG_MAXPARAMLENGTH);
        if (lReturn != CONFIG_OK || MOC_STRCMP((sbyte *)chParamValue, (sbyte *)"FIXED")) {
          bDhcp = FALSE;
          _SetNetIfParameter(iSock, 0, MO_SIOCSIFIADDR, "192.168.1.1");
          ConfigSetParam("IF0IPADDRESS","192.168.1.1");
          ConfigSetParam("IF0DHCP","FIXED");
        }
      }
#endif
      _SetNetIfParameter(iSock, 0, MO_SIOCIFIBRENABLE, "BRIDGED");
#endif
    }

#ifdef NET_MULTIF
    else {
#ifndef NET_DSL
#if 0 /* RS removed special treatment for intf 2 */
      if (oIfNum == 2) {
#endif
        bEnabled = TRUE;
        if (ConfigGetParam("IF1ENABLED", chParamValue,
                           CONFIG_MAXPARAMLENGTH) != CONFIG_OK) {
          ConfigSetParam("IF1ENABLED","YES");
        }

        _SetNetIfParameter(iSock, oIfIdx, MO_SIOCSIFITYPE, "ETH");
#if 0 /* RS removed special treatment for intf 2 */
      }
#endif
#endif

#ifndef ROUTER
      /* Interfaces are always bridged if there is no router */
      _SetNetIfParameter(iSock, oIfIdx, MO_SIOCIFIBRENABLE, "BRIDGED");
#endif

    }
#endif

    if ( bLogical ){

    /* Interface Defaults */
    _SetNetIfParameter(iSock, oIfIdx, MO_SIOCSIFINETMASK, "255.255.255.0");
    _SetNetIfParameter(iSock, oIfIdx, MO_SIOCSIFIBRDADDR, "255.255.255.255");

#ifdef NET_BR
    /* Set the initial spanning tree port state */
    xIfReq.ifr_value = BRIF_FORWARDING;
    ioctl(iSock,MO_SIOCIFBRINITIALIFSTATE,&xIfReq);
#endif

    /*
     * Check for DHCP configuration
     */
    sprintf(cTmpString,"IF%dDHCP",oIfIdx);
    if ((ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) &&
        (!MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"FIXED"))) {
      bDhcp = FALSE;
    }

    SETUPNET_DBGP(NORMAL,"SetNetStack: DHCP = %s\n",bDhcp?"DHCP":"FIXED");

#ifdef NET_MULTIF
    /*Is there any other routed leg ?
      if yes, this bridge leg should forward only pppoe traffic*/
    sprintf(cTmpString,"IF%dNETCONF",oIfIdx);
    if ((ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) &&
        (!MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"BRIDGED"))) {
      BOOL bBridgeOnly = FALSE;
      SetupNetCheckBridgeOnly(&bBridgeOnly,-1);
      if(bBridgeOnly == FALSE){
        xIfReq.ifr_value = TRUE;
        iRv = ioctl(iSock,MO_SIOCIFIBRPPPOE,&xIfReq);
        ASSERT(iRv == 0);
      }
    }
#endif

    /*
     * Set the interface MAC address
     */
#ifdef NET_MULTIF
    aoMac[5] = macLast + oIfIdx;
    if (oIfIdx>0 && bMacSpoofing) {
      /* WAN interfaces inherit 'spoofed' MAC address */
      MOC_MEMCPY((ubyte *)((struct sockaddr_dl *)&(xIfReq.ifr_addr))->sdl_data,
             (ubyte *)&aoSpoofMac[0], 6);
    }
    else
#endif
    {
      MOC_MEMCPY((ubyte *)((struct sockaddr_dl *)&(xIfReq.ifr_addr))->sdl_data,
             (ubyte *)&aoMac[0], 6);
      ((struct sockaddr_dl *)&(xIfReq.ifr_addr))->sdl_alen = 6;
      xIfReq.ifr_addr.sa_len = sizeof(struct sockaddr_dl);
      iRv = ioctl(iSock,MO_SIOCSIFIDLADDR,&xIfReq);
      ASSERT(iRv == 0);
    }

    /*
     * Handle special 'safe' bootup modes for LAN interface 0
     * (These are usually called by the downloader application)
     */
    if (oIfIdx == 0) {
      if (eSetupType == SETUPNET_10DOT1) {
        SETUPNET_DBGP(NORMAL,"SetNetStack: Forced 10.1.0.54 IP address mode - no VLAN\n");
        _SetNetIfParameter(iSock, 0, MO_SIOCSIFIADDR, "10.1.0.54");
        bForcedConfig = TRUE;
        bDhcp = FALSE;
      }
      else if (eSetupType == SETUPNET_MACBURN) {
        SETUPNET_DBGP(NORMAL,"SetNetStack: Forced 192.168.1.199 MAC burn IP address mode - no VLAN\n");
        _SetNetIfParameter(iSock, 0, MO_SIOCSIFIADDR, "192.168.1.199");
        bForcedConfig = TRUE;
        bDhcp = FALSE;
      }
      else if (eSetupType == SETUPNET_DHCP) {
        /* Override cfg variable and force DHCP mode */
        SETUPNET_DBGP(NORMAL,"SetNetStack: Forced DHCP mode - no VLAN\n");
        bDhcp = TRUE;
        bForcedConfig = TRUE;
      }
      else if (eSetupType == SETUPNET_FIXEDIP) {
        /* Override cfg variable and force Fixed IP mode */
        SETUPNET_DBGP(NORMAL,"SetNetStack: Forced Fixed IP mode - no VLAN\n");
        if (ConfigGetParam("IF0IPADDRESS", chParamValue,
                           CONFIG_MAXPARAMLENGTH) != CONFIG_OK) {
          bDhcp = TRUE;
        } else {
         /* JJ Setting it to 192.168.10.50 */
          /*_SetNetIfParameter(iSock, 0, MO_SIOCSIFIADDR, chParamValue); */
          _SetNetIfParameter(iSock, 0, MO_SIOCSIFIADDR, "192.168.3.50");
          _SetNetIfParameter(iSock, 0, MO_SIOCSIFINETMASK, "255.255.255.0");
          _SetNetIfParameter(iSock, 0, MO_SIOCSIFIGWADDR, "192.168.3.5");
          bDhcp = FALSE;
        }
        bForcedConfig = TRUE;
      }
    }
#ifdef NET_MULTIF
    /* RS added this section */
    else if (eSetupType == SETUPNET_FIXEDIP) {
        /* RS Setting it to 192.168.10+oIfIdx.50 */
        snprintf(cTmpString, sizeof(cTmpString), "192.168.%d.10", 241+oIfIdx);
        _SetNetIfParameter(iSock, oIfIdx, MO_SIOCSIFIADDR, cTmpString);
        _SetNetIfParameter(iSock, oIfIdx, MO_SIOCSIFINETMASK, "255.255.255.0");
        snprintf(cTmpString, sizeof(cTmpString), "192.168.%d.1", 241+oIfIdx);
        _SetNetIfParameter(iSock, oIfIdx, MO_SIOCSIFIGWADDR, cTmpString);
        bDhcp = FALSE;
        bForcedConfig = TRUE;
    }
#endif

    if (bDhcp == TRUE) {
      /* Is it standard client ID or custom? */
      sprintf(cTmpString,"IF%dSTANDARDCLIENTID",oIfIdx);
      if ((ConfigGetParam(cTmpString,chParamValue,
                          CONFIG_MAXPARAMLENGTH) == CONFIG_OK)
          && (!MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"CUSTOM"))) {
        /* DHCP custom client id */
        struct ifconf xIfConf;

        sprintf(cTmpString,"IF%dCICUSTOM",oIfIdx);
        ConfigGetParam(cTmpString,chParamValue,CONFIG_MAXPARAMLENGTH);
        xIfConf.ifc_len = strlen(chParamValue);
        xIfConf.ifc_buf = chParamValue;
        ioctl(iSock, MO_SIOCSIFICLIENTID, oIfIdx, &xIfConf);
      }

#ifdef DHCP_CUSTOM_OPTIONS
      /* test registation of custom dhcp options */
      {
        OCTET aotmp[4] = { 0,0,0,60 };  /* lease */
        OCTET aotmp1[4] = { 1,3,6,15 }; /* parameter request list */
        DHCP_CUSTOM_OPTION xOption;

        xOption.oPktType = DHCP_CPT_DISCOVERY|DHCP_CPT_REQUEST;
        xOption.oCustomOption = 51; /* lease */
        xOption.poCustomOptionBuf = aotmp;
        xOption.oBufSize = sizeof(aotmp);
        xOption.pfnCB = _DHCPCustomCB;
        SETUPNET_DBGP(NORMAL,"<<Register DHCP custom option; lease>>\n");
        ioctl(iSock, MO_SIOCSIFIDHCPCUSTOMOPT, 1, &xOption);

        xOption.oPktType = DHCP_CPT_DISCOVERY|DHCP_CPT_REQUEST;
        xOption.oCustomOption = 55; /* parameter request list */
        xOption.poCustomOptionBuf = aotmp1;
        xOption.oBufSize = sizeof(aotmp1);
        xOption.pfnCB = _DHCPCustomCB;
        SETUPNET_DBGP(NORMAL,"<<Register DHCP custom option; paramter request list>>\n");
        ioctl(iSock, MO_SIOCSIFIDHCPCUSTOMOPT, 1, &xOption);

        xOption.oPktType = DHCP_CPT_REPORT_ONLY;
        xOption.oCustomOption = 1; /* subnet mask */
        xOption.poCustomOptionBuf = NULL;
        xOption.oBufSize = 0;
        xOption.pfnCB = _DHCPCustomCB;
        SETUPNET_DBGP(NORMAL,"<<Register DHCP custom option; subnet mask>>\n");
        ioctl(iSock, MO_SIOCSIFIDHCPCUSTOMOPT, 1, &xOption);

        xOption.oPktType = DHCP_CPT_REPORT_ONLY;
        xOption.oCustomOption = 3; /* default router */
        xOption.poCustomOptionBuf = NULL;
        xOption.oBufSize = 0;
        xOption.pfnCB = _DHCPCustomCB;
        SETUPNET_DBGP(NORMAL,"<<Register DHCP custom option; default router>>\n");
        ioctl(iSock, MO_SIOCSIFIDHCPCUSTOMOPT, 1, &xOption);

        /* register callback */
        SETUPNET_DBGP(NORMAL,"<<Register DHCP Error callback>>\n");
        ioctl(iSock, MO_SIOCSDHCPERRORCBK, _DHCPErrorCB);
      }
#endif /*DHCP_CUSTOM_OPTIONS */

      /* Set IFF_DYNAMIC bit to force DHCP client to start */
      ioctl(iSock,MO_SIOCGIFIFLAG,&xIfReq);
      xIfReq.ifr_flags |= IFF_DYNAMIC;
      ioctl(iSock,MO_SIOCSIFIFLAG,&xIfReq);
    }
    else {
      ioctl(iSock,MO_SIOCGIFIFLAG,&xIfReq);
      xIfReq.ifr_flags &= ~IFF_DYNAMIC; /* Don't use DHCP */
      ioctl(iSock,MO_SIOCSIFIFLAG,&xIfReq);
    }

    /*
     * Scan through config table for interface related config variables
     */
    while (!bForcedConfig && pxIfVarIoctlTableSet[j].pcVarName != NULL) {

      DWORD dwIoctlCode = pxIfVarIoctlTableSet[j].dwIoctlCode;

      sprintf(cTmpString,"IF%d%s", oIfIdx, pxIfVarIoctlTableSet[j].pcVarName);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        SETUPNET_DBGP(REPETITIVE,"SetNetStack: %s = %s\n",cTmpString,chParamValue);

        if ((bDhcp == TRUE) &&
            (dwIoctlCode == MO_SIOCSIFIADDR ||
             dwIoctlCode == MO_SIOCSIFINETMASK ||
             dwIoctlCode == MO_SIOCSIFIGWADDR)) {
          /* Don't set these if we want DHCP assignment */
        } else {
          _SetNetIfParameter(iSock, oIfIdx,
                             dwIoctlCode,
                             chParamValue);
        }
      } else {
        SETUPNET_DBGP(REPETITIVE,"SetNetStack: %s doesn't exist\n",cTmpString);
      }

      j++;
    }

#ifdef NET_DSL
    j = 0;
    while (pxAtmIfVarIoctlTableSet[j].pcVarName != NULL) {

      sprintf(cTmpString,"VC%d%s", oIfIdx, pxAtmIfVarIoctlTableSet[j].pcVarName);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        SETUPNET_DBGP(REPETITIVE,"SetNetStack: %s = %s\n",
                      cTmpString,chParamValue);
        _SetNetIfParameter(iSock, oIfIdx,
                           pxAtmIfVarIoctlTableSet[j].dwIoctlCode,
                           chParamValue);
      } else {
        SETUPNET_DBGP(REPETITIVE,"SetNetStack: %s doesn't exist\n",cTmpString);
      }

      j++;
    }
#endif

    /* Interface VLAN settings (not set if 'safe' bootup mode) */
    if (!bForcedConfig) {
      sprintf(chParamValue, "%d", _ComputeVlanValue(oIfIdx));
      _SetNetIfParameter(iSock, oIfIdx, MO_SIOCSIFIVLAN, chParamValue);
    }

    } /* if ( bLogical ) */

#ifdef LINK_AGGREGATION
    if ( bLogical ){
    int i;

    oLIfIdx = oIfIdx; /* save for later use */

        /* Set IFF_LOGICAL bit */
        ioctl(iSock,MO_SIOCGIFIFLAG,&xIfReq);
        xIfReq.ifr_flags |= IFF_LOGICAL;
        ioctl(iSock,MO_SIOCSIFIFLAG,&xIfReq);

        for(i=0; i < oIfNum; i++){
#if 1
           if ( i > (oIfNum - 3) ) /* skip the logical interfaces itself */
        continue;
           sprintf(chParamValue, "%d", i);
       if ( (i%2 == 0 && oIfIdx == (oIfNum - 2) ) || /* even # to last but one */
            (i%2 && oIfIdx == (oIfNum - 1) ) ) /* odd # to last one */
#else /* We do not retrieve from config */
           sprintf(cTmpString,"IF%dPHYSICAL%d", oIfIdx, i);
           if ( ConfigGetParam(cTmpString, chParamValue,
                               CONFIG_MAXPARAMLENGTH) == CONFIG_OK )
#endif
           {
              _SetNetIfParameter(iSock, oIfIdx, MO_SIOCIFIAGGRADD, chParamValue);
           }
       }
    }
#endif



    /*
     * Open the interface now, if it is enabled
     *   Note, oIfIdx = 0 = IF0 = LAN is always enabled
     */
    sprintf(cTmpString,"IF%dENABLED",oIfIdx);
    if ((bEnabled == TRUE) ||
        ((ConfigGetParam(cTmpString, chParamValue,
                         CONFIG_MAXPARAMLENGTH) == CONFIG_OK) &&
         (!MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"YES")))) {
      if (_SetNetIfParameter(iSock, oIfIdx, MO_SIOCIFIOPEN, NULL) < 0) {
        ASSERT(0);
        return -1;
      }
      SETUPNET_DBGP(NORMAL,"SetNetStack: Interface %d opened\n",oIfIdx);
    }

  } /* for each interface */

  /* Commit any default settings */
  ConfigCommit();
#endif /* 0 */

#ifdef NAT
  /*
   * NAT Port Forwarding Configuration
   */
  {
    int j;

    for (j=0; j<8; j++) {
      struct nat_portfwd_lan xNat;
      BOOL bNullifyEntry = FALSE;

      bzero(&xNat, sizeof(struct nat_portfwd_lan));

      sprintf(cTmpString, "PORTFWDMIN%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"")) xNat.wPortBeg
                                          = MOC_ATOL(chParamValue, NULL);
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "PORTFWDMAX%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"")) xNat.wPortEnd = MOC_ATOL(chParamValue, NULL);
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "PORTFWDIP%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"")) xNat.dwIp = MOC_ATOL(chParamValue, NULL);
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "PORTFWDPROT%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (!MOC_STRCMP((sbyte *)chParamValue,(sbyte *) "UDP")) {
          xNat.wFlags |= NAT_PORT_FORWARD_PROT_UDP;
        } else if (!MOC_STRCMP((sbyte *)chParamValue, (sbyte *)"TCP")) {
          xNat.wFlags |= NAT_PORT_FORWARD_PROT_TCP;
        } else if (!MOC_STRCMP((sbyte *)chParamValue, (sbyte *)"BOTH")) {
          xNat.wFlags |= NAT_PORT_FORWARD_PROT_BOTH;
        } else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      xNat.bNullifyEntry = bNullifyEntry;
      xNat.dwIndex = j;

      ioctl(iSock, MO_SIOCNATREGFWDWAN2LAN, &xNat);
    }
  }


  /*
   * CPE Port Forwarding configuration
   */
  {
    /* register DHCP client on both LAN and WAN (always forwarded) */
    SetupNetRegisterWan2CpePortFwd(68,68,1);
  }
#endif


#ifdef ROUTER
  /*
   * Static Routing Configuration
   */
  {
    int j;

    for (j=0; j<8; j++) {
      struct rtentry xRt;
      int bNullifyEntry = FALSE;

      sprintf(cTmpString, "ROUTEDESTIP%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"")) {
          ((struct sockaddr_in *)&(xRt.rt_dst))->sin_addr.s_addr = inet_addr(chParamValue);
        }
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "ROUTESUBNETMASK%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"")) {
          ((struct sockaddr_in *)&(xRt.rt_genmask))->sin_addr.s_addr = inet_addr(chParamValue);
        }
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "ROUTEGATEWAYIP%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"")) {
          ((struct sockaddr_in *)&(xRt.rt_gateway))->sin_addr.s_addr = inet_addr(chParamValue);
        }
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "ROUTEMETRIC%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"")) {
          xRt.rt_metric = MOC_ATOL(chParamValue, NULL);
        }
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "ROUTEINT%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        int k;
        for (k=0; k<oIfNum; k++) {
          sprintf(cTmpString, "IF%d", k);
          if (!MOC_STRCMP((sbyte *)chParamValue, (sbyte *)cTmpString)) {
            xRt.rt_ifindex = k;
            break;
          }
        }

        if (k==oIfNum) bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      mnIoctlArgList.dwIndex = j;
      mnIoctlArgList.bNullifyEntry = bNullifyEntry;
      mnIoctlArgList.pxRtEntry = (void *)&xRt;
      ioctl(iSock, MO_SIOCRTABLESETSTATICRT, &mnIoctlArgList);
    }
  }

  /*
   * IP Address Filtering Configuration
   */
  {
    int j;

    for (j=0; j<30; j++) {
      ROUTERCFG_IPFILTERING xFilter;
      BOOL bNullifyEntry = FALSE;

      bzero(&xFilter, sizeof(ROUTERCFG_IPFILTERING));

      sprintf(cTmpString, "FILTADDR%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"")) xFilter.dwIp = MOC_ATOL(chParamValue, NULL);
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "FILTPROT%d", j+1);
      if (ConfigGetParam(cTmpString, chParamValue, CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
        if (!MOC_STRCMP((sbyte *)chParamValue,(sbyte *) "UDP")) {
          xFilter.wFlags |= IP_FILTERING_PROT_UDP;
        } else if (!MOC_STRCMP((sbyte *)chParamValue,(sbyte *) "TCP")) {
          xFilter.wFlags |= IP_FILTERING_PROT_TCP;
        } else if (!MOC_STRCMP((sbyte *)chParamValue,(sbyte *) "BOTH")) {
          xFilter.wFlags |= IP_FILTERING_PROT_BOTH;
        } else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      xFilter.bNullifyEntry = bNullifyEntry;
      xFilter.dwIndex = j;

      ioctl(iSock, MO_SIOCIPFILTERINGCFG, &xFilter);
    }
  }
#endif

  /*
   * We need to wait until the LAN interface is up
   * and has an IP address
   */
  {
    struct timespec stTime;
    struct ifreq xIfReq;
    mnIoctlArgList_t mnIoctlArgList;

    mnIoctlArgList.ifreq = (void *)&xIfReq;

#ifdef LINK_AGGREGATION
    xIfReq.ifr_name[0] = oLIfIdx;
#else
    xIfReq.ifr_name[0] = 0;
#endif

#if 1
    xIfReq.ifr_name[0] = 0;
#endif

    /* set loop time = 200ms */
    stTime.tv_sec=0;
    stTime.tv_nsec=200*1000000;

    while(1) {
      if (ioctl(iSock, MO_SIOCGIFIFLAG, &mnIoctlArgList) < 0) {
        ASSERT(0);
        close(iSock);
        return SETUPNET_ERROR;
      }

printf("Flags %x \n", xIfReq.ifr_flags);

      if ((xIfReq.ifr_flags & IFF_IPUP) ||
          ((xIfReq.ifr_flags & IFF_UP) == 0)) {
        break;
      }

      /* give net stack time to execute */
      nanosleep(&stTime,NULL);
    }
  }

  close(iSock);

#ifdef IPSEC
  /* setup IPSec configuration */
  SetupNetIPSec();
#endif /* IPSEC */

  return SETUPNET_OK;
}


/*
 * SetupNetIPSec
 *   Function to configure IPSEC
 *
 *   Args:
 *    None
 *
 *   Return:
 *    SetupNetReturn           error code (see setupnet.h for def)
 */
SetupNetReturn SetupNetIPSec(void)
{
/* #ifdef IPSEC */
#if 0
/* IPSEC is configed by us. */
  int iSock;
  char chParamValue[CONFIG_MAXPARAMLENGTH+1];
  char szIPSec[16];
  void* pxSP=NULL;
  RTDATA xRoute;
  SPDATA xSP;
  SADATA xSA;
  int i,j,k;

  /* Open a socket */
  if ((iSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return -1;
  }

  /* clean up all SP and SA */
  ioctl(iSock, MO_SIOCIPSECCLEARSASP, 0);

  /* configure new SP and SA's */
  for (i=1; i<=MAX_POLICY; i++) {
    /* initialize route data */
    xRoute.oIfIdx=-1;
    xRoute.dwGateway=INADDR_ANY;

    sprintf(szIPSec,"POLICY%d",i);
    if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK &&
        MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"ON") == 0) {
      DWORD dwRemoteIPStart=0;
      DWORD dwRemoteIPEnd=0;

      SETUPNET_DBGP(NORMAL,"\n%s, ", szIPSec);

      sprintf(szIPSec,"SAREMOTES%d",i);
      if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
        dwRemoteIPStart = inet_addr(chParamValue);
        SETUPNET_DBGP(NORMAL, "remote_begin=%lx,", dwRemoteIPStart);
      }

      sprintf(szIPSec,"SAREMOTEE%d",i);
      if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
        dwRemoteIPEnd = inet_addr(chParamValue);
        SETUPNET_DBGP(NORMAL, "remote_end=%lx", dwRemoteIPEnd);
      }

      sprintf(szIPSec,"SATRPROTO%d",i);
      if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
        if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"UDP") == 0) {
          xSP.oTransProto = IPPROTO_UDP;
          SETUPNET_DBGP(NORMAL, ": UDP,");
        } else if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"TCP") == 0) {
          xSP.oTransProto = IPPROTO_TCP;
          SETUPNET_DBGP(NORMAL, ": TCP,");
        } else if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"ICMP") == 0) {
          xSP.oTransProto = IPPROTO_ICMP;
          SETUPNET_DBGP(NORMAL, ": ICMP,");
        } else {
          xSP.oTransProto = 0;
          SETUPNET_DBGP(NORMAL, "ALL,");
        }
      }

      if (dwRemoteIPStart) {
        DWORD dwGWIP=0;

        xSP.oIPSecMode = IPSEC_MODE_TUNNEL;   /* default is Tunnel mode */
        /* get IPSec mode */
        sprintf(szIPSec,"SAMODE%d",i);
        if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
          if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"TRANS") == 0) {
            xSP.oIPSecMode = IPSEC_MODE_TRANSPORT;
            SETUPNET_DBGP(NORMAL, "TRANS MODE,");
          } else if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"TUNL") == 0) {
            xSP.oIPSecMode = IPSEC_MODE_TUNNEL;
            SETUPNET_DBGP(NORMAL, "TUNNEL MODE,");
          } else if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"BLIND_TUNL")==0) {
            xSP.oIPSecMode = IPSEC_MODE_BLIND_TUNNEL;
            SETUPNET_DBGP(NORMAL, "TUNNEL MODE(GW),");
          } else {
            SETUPNET_DBGP(NORMAL, "TUNNEL MODE(default),");
          }
        }

        /* get remote GW info */
        sprintf(szIPSec,"SAGW%d",i);
        if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
          dwGWIP = inet_addr(chParamValue);
          SETUPNET_DBGP(NORMAL, "Remote secure GW=%lx", dwGWIP);
        }

        /*
         * Look up gateway address and interface index to which
         * the packet has to be forwarded.
         */
        if (dwGWIP == 0) {
          /* no security gateway provided */
          dwGWIP = dwRemoteIPStart;
        }
        ioctl(iSock, MO_SIOCIPSECGETROUTE, dwGWIP, &xRoute);

        /* get SA info, first for outbound and then for inbound */
        for (j=1; j<=2; j++) {
          DWORD dwSpiESP=0;
          DWORD dwSpiAH=0;

          /* initialize SPDATA parameters */
          MOC_MEMSET((ubyte *)&xSP, 0, sizeof(struct spdata));

          /* initialize SA paramters */
          MOC_MEMSET((ubyte *)&xSA, 0, sizeof(struct sadata));
          xSA.wAuthKeyOctets=16;
          xSA.wOrgDigestLen=16;
          xSA.wIcvLen=12;
          xSA.wEncKeyDwords=6;
          xSA.wIvDwords=2;
          xSA.wBlockLen=8;
          xSA.wMaxPadLen=8;
          xSA.oIPSecProto = IPSEC_PROTO_ESP_AUTH;

          /* set direction (destination and src) */
          if (j==1) {
            /* out bound */
            SetupNetGetIfIPAddress(0, &xSP.dwSrcIPSt);
#ifdef ROUTER
            xSP.dwSrcIPSt &= 0xffffff00;
            xSP.dwSrcIPEd = xSP.dwSrcIPSt | 0x000000ff;
            SetupNetGetIfIPAddress(xRoute.oIfIdx, &xSP.dwTunSrcIP);
#else /* if ROUTER */
            xSP.dwSrcIPEd = 0;
            xSP.dwTunSrcIP = xSP.dwSrcIPSt;
#endif /* if ROUTER else */
            xSP.dwDestIPSt = dwRemoteIPStart;
            xSP.dwDestIPEd = dwRemoteIPEnd;
            xSP.dwTunDestIP = dwGWIP ;
          } else {
            /* in bound */
            xSP.dwSrcIPSt = dwRemoteIPStart;
            xSP.dwSrcIPEd = dwRemoteIPEnd;
            SetupNetGetIfIPAddress(0, &xSP.dwDestIPSt);
#ifdef ROUTER
            xSP.dwDestIPSt &= 0xffffff00;
            xSP.dwDestIPEd = xSP.dwDestIPSt | 0x000000ff;
            SetupNetGetIfIPAddress(xRoute.oIfIdx, &xSP.dwTunDestIP);
#else /* if ROUTER */
            xSP.dwDestIPEd = 0;
            xSP.dwTunDestIP = xSP.dwDestIPSt;
#endif /* if ROUTER else */
            xSP.dwTunSrcIP = dwGWIP;
          }

          SETUPNET_DBGP(NORMAL, "\n +-> (%08lx[%08lx:%08lx=>%08lx:%08lx]%08lx):",
                                xSP.dwTunSrcIP, xSP.dwSrcIPSt, xSP.dwSrcIPEd,
                                xSP.dwDestIPSt, xSP.dwDestIPEd, xSP.dwTunDestIP);

          /* get SPIs */
          sprintf(szIPSec,"SASPI%d_%d_1",i,j);
          MOC_MEMSET((ubyte *)chParamValue,0x30,CONFIG_MAXPARAMLENGTH+1);    /* init with '0' */
          if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
            dwSpiAH = MOC_ATOL(chParamValue, NULL);
            SETUPNET_DBGP(NORMAL, "AH SPI=%ld,", dwSpiAH);
          }

          sprintf(szIPSec,"SASPI%d_%d_2",i,j);
          MOC_MEMSET((ubyte *)chParamValue,0x30,CONFIG_MAXPARAMLENGTH+1);    /* init with '0' */
          if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
            dwSpiESP = MOC_ATOL(chParamValue, NULL);
            SETUPNET_DBGP(NORMAL, "ESP SPI=%ld,", dwSpiESP);
          }

          /* check if source address range and */
          /* destination address range overlaps */
          if (IPSecSadbCheckRange(xSP.dwSrcIPSt, xSP.dwSrcIPEd,
                                  xSP.dwDestIPSt, xSP.dwDestIPEd)) {
            /* disable security policy if overlaps */
            dwSpiAH=0;
            dwSpiESP=0;
            SETUPNET_DBGP(ERROR, "\nIPSec: Src and Dest addr range overlaps!!\n");
          }

          /* create security policy for this direction */
          if (dwSpiESP || dwSpiAH) {
            ioctl(iSock, MO_SIOCIPSECCREATESP, &pxSP, &xSP, &xRoute);
          }

          /* put ESP first, - inner processing, if nested */
          if (dwSpiESP) {
            xSA.dwSpi = dwSpiESP;

            sprintf(szIPSec,"SAAUTHALG%d_%d_2",i,j);
            if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
              if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"HMAC-MD5") == 0) {
                xSA.oAuthAlgo = IPSEC_AUTHALG_MD5;
                xSA.pfnAuth=hmac_md5;
                xSA.wAuthKeyOctets=16;
                xSA.wOrgDigestLen=16;
                xSA.wIcvLen=12;
                SETUPNET_DBGP(NORMAL, "HMAC-MD5,");
              } else if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"HMAC-SHA1") == 0) {
                xSA.oAuthAlgo = IPSEC_AUTHALG_SHA1;
                xSA.pfnAuth=hmac_sha1;      /* not implemented yet */
                xSA.wAuthKeyOctets=20;
                xSA.wOrgDigestLen=20;
                xSA.wIcvLen=12;
                SETUPNET_DBGP(NORMAL, "HMAC-SHA1,");
              }
            }

            sprintf(szIPSec,"SAENCALG%d_%d_2",i,j);
            if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
              if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"3DES-CBC") == 0) {
                xSA.oEncAlgo=IPSEC_ENCALG_3DES;
                xSA.pfnEnc=Des3CbcEncAligned;
                xSA.pfnDec=Des3CbcDecAligned;
                xSA.wEncKeyDwords=6;
                xSA.wIvDwords=2;
                xSA.wBlockLen=8;
                xSA.wMaxPadLen=8;
                SETUPNET_DBGP(NORMAL, "3DES-CBC,");
              } else if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"DES-CBC") == 0) {
                xSA.oEncAlgo=IPSEC_ENCALG_DES;
                xSA.pfnEnc=DesCbcEncAligned;
                xSA.pfnDec=DesCbcDecAligned;
                xSA.wEncKeyDwords=2;
                xSA.wIvDwords=2;
                xSA.wBlockLen=8;
                xSA.wMaxPadLen=8;
                SETUPNET_DBGP(NORMAL, "DES-CBC,");
              }
            }

            sprintf(szIPSec,"SAAUTHKEY%d_%d_2",i,j);
            MOC_MEMSET((ubyte *)chParamValue,0,CONFIG_MAXPARAMLENGTH+1);
            if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
              SETUPNET_DBGP(NORMAL," AUTH_KEY:");
              chParamValue[strlen(chParamValue)]=0x30;  /* replace end of string with '0' */
              for (k=0;k<xSA.wAuthKeyOctets;k++) {
                int iValue;

                sscanf(chParamValue+(2*k),"%2x",&iValue);
                xSA.aoKey[k]=(OCTET)iValue;
                SETUPNET_DBGP(NORMAL,"%02x",xSA.aoKey[k]);
              }
            }

            sprintf(szIPSec,"SAENCKEY%d_%d_2",i,j);
            MOC_MEMSET((ubyte *)chParamValue,0x30,CONFIG_MAXPARAMLENGTH+1);  /* init with '0' */
            if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
              SETUPNET_DBGP(NORMAL," ENCR_KEY:");
              chParamValue[strlen(chParamValue)]=0x30;  /* replace end of string with '0' */
              for (k=0;k<xSA.wEncKeyDwords;k++) {
                DWORD dwValue;

                sscanf(chParamValue+(8*k),"%8lx",&dwValue);
                xSA.adwKey[k]=dwValue;
                SETUPNET_DBGP(NORMAL,"%08lx",xSA.adwKey[k]);
              }
            }

            if (xSA.pfnAuth) {
              if (xSA.pfnEnc && xSA.pfnDec) {
                xSA.oIPSecProto = IPSEC_PROTO_ESP_AUTH;
                SETUPNET_DBGP(NORMAL, " ESP/AUTH,");
              } else {
                xSA.oIPSecProto = IPSEC_PROTO_NULL_AUTH;
                SETUPNET_DBGP(NORMAL, " NULL/AUTH,");
                /* don't use IV if using null ESP */
                xSA.wIvDwords=0;
              }
            } else {
              xSA.oIPSecProto = IPSEC_PROTO_ESP_NULL;
              SETUPNET_DBGP(NORMAL, " ESP,");
              if (NULL==xSA.pfnEnc) xSA.pfnEnc = Des3CbcEncAligned;
              if (NULL==xSA.pfnDec) xSA.pfnDec = Des3CbcDecAligned;
            }

            if (IPSEC_PROTO_NULL_AUTH != xSA.oIPSecProto) {
              DWORD dwCurrentTime;
              struct timeval tv;

              /* get current time (in msec) */
              gettimeofday(&tv, NULL);
              dwCurrentTime = (tv.tv_sec * 1000) + (tv.tv_usec / 1000);

              srand(dwCurrentTime+1);

              /* get IV value */
              for (k=0;k<xSA.wIvDwords;k++) {
                xSA.adwIv[k] = (rand()<<16) | rand();
              }
            }

            /* create security association */
            ioctl(iSock, MO_SIOCIPSECCREATESA, (DWORD)pxSP, &xSP, &xSA);

            /* set security association parameters */
            ioctl(iSock, MO_SIOCIPSECSETSA, &xSP, &xSA);

          }

          /* initialize SA paramters again for AH */
          MOC_MEMSET((ubyte *)&xSA, 0, sizeof(struct sadata));
          xSA.wAuthKeyOctets=16;
          xSA.wOrgDigestLen=16;
          xSA.wIcvLen=12;
          xSA.wBlockLen=8;

          if (dwSpiAH) {
            xSA.dwSpi = dwSpiAH;

            /* authentication header */
            xSA.oIPSecProto = IPSEC_PROTO_AH;

            sprintf(szIPSec,"SAAUTHALG%d_%d_1",i,j);
            if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
              if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"HMAC-MD5") == 0) {
                xSA.oAuthAlgo = IPSEC_AUTHALG_MD5;
                xSA.pfnAuth=hmac_md5;
                xSA.wAuthKeyOctets=16;
                xSA.wOrgDigestLen=16;
                xSA.wIcvLen=12;
                SETUPNET_DBGP(NORMAL, " HMAC-MD5,");
              } else if (MOC_STRCMP((sbyte *)chParamValue,(sbyte *)"HMAC-SHA1") == 0) {
                xSA.oAuthAlgo = IPSEC_AUTHALG_SHA1;
                xSA.pfnAuth=hmac_sha1;      /* not implemented yet */
                xSA.wAuthKeyOctets=20;
                xSA.wOrgDigestLen=20;
                xSA.wIcvLen=12;
                SETUPNET_DBGP(NORMAL, " HMAC-SHA1,");
              }
            }

            sprintf(szIPSec,"SAAUTHKEY%d_%d_1",i,j);
            MOC_MEMSET((ubyte *)chParamValue,0,CONFIG_MAXPARAMLENGTH+1);
            if (ConfigGetParam(szIPSec,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
              SETUPNET_DBGP(NORMAL," AUTH_KEY:");
              chParamValue[strlen(chParamValue)]=0x30;  /* replace end of string with '0' */
              for (k=0;k<xSA.wAuthKeyOctets;k++) {
                int iValue;

                sscanf(chParamValue+(2*k),"%2x",&iValue);
                xSA.aoKey[k]=(OCTET)iValue;
                SETUPNET_DBGP(NORMAL,"%02x",xSA.aoKey[k]);
              }
            }
            SETUPNET_DBGP(NORMAL,"\n");

            /* create security association */
            ioctl(iSock, MO_SIOCIPSECCREATESA, (DWORD)pxSP, &xSP, &xSA);

            /* set security association parameters */
            ioctl(iSock, MO_SIOCIPSECSETSA, &xSP, &xSA);

          }
        }
      }
    }
  }
  SETUPNET_DBGP(NORMAL, "\n");

  close(iSock);

#endif /* if IPSEC */

  return SETUPNET_OK;
}


int ConfigGetParam(char * str,char *value,int len) {

    return CONFIG_OK;
}

int ConfigSetParam(char * str,char *value) {

    return CONFIG_OK;
}

int ConfigCommit() {

    return ;
}
