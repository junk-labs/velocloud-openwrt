#include <stdio.h>

#include <NNstyle.h>
#include <vcpdefs.h>
#include <vcpex.h>

void _vecscale32_CA(LONG *plDst, LONG *plSrc, DWORD dwScale, DWORD dwSize) 
{                   
  LONG *plSrcEnd = plSrc + dwSize;
  LONG rb = *plSrc;        

  vcp[mult_a] = dwScale;                       
  do {                                       
    vcp[mult_b32] = rb;                      
    rb = *++plSrc;                           
    *plDst++ = vcp[mult_z1];                   
  } while (plSrcEnd > plSrc); 
}

void _vecscale16_CA(SHORT *pnDst, SHORT *pnSrc, SHORT nScale, DWORD dwSize) 
{
  LONG rb, rz1, rz2;
  SHORT *pnSrcEnd;

  vcp[mult_a] = (nScale & 0xffff) | ((LONG)nScale << 16);    

  if ((DWORD)pnSrc & 0x3) {
    vcp[mult_b16] = *pnSrc;
    pnSrc++;
    dwSize --;
    asm("nop");
    *pnDst++ = vcp[mult_z2];
  }

  rb = *(LONG *)pnSrc;
  pnSrcEnd = pnSrc + dwSize - 1 ;

  do {                    
    vcp[mult_b16] = rb;
    pnSrc += 2;
    rb = *(LONG *)pnSrc;
    rz1 = vcp[mult_z1];
    rz2 = vcp[mult_z2];
    *pnDst++ = rz1;
    *pnDst++ = rz2;
  } while (pnSrcEnd > pnSrc);

  if (dwSize & 0x1) {
    vcp[mult_b16] = rb; /* in high 16b */
    asm("nop");
    asm("nop");
    *pnDst = vcp[mult_z1];
  }
}

void _macc8_CA(SHORT *psDst, OCTET *poSrc1, OCTET *poSrc2, DWORD dwSize)
{
  LONG raH, raL, rbH, rbL;
  OCTET *poSrcEnd;

  vcp[macc_z] = 0x0;

  poSrcEnd = poSrc1 + dwSize -1;

  for (;poSrc1 < poSrcEnd;) {
    raH = *poSrc1++;
    rbH = *poSrc2++;
    raL = *poSrc1++;
    rbL = *poSrc2++;
    vcp[macc_a]   = (raH << 16) | (raL & 0xffff);
    vcp[macc_b16] = (rbH << 16) | (rbL & 0xffff);
  }

  if (dwSize & 0x01) {
    raL = *poSrc1;
    rbL = *poSrc2;
    vcp[macc_a]   = raL & 0xffff;
    vcp[macc_b16] = rbL;
    asm("nop");
    asm("nop");
    asm("nop");
  }
  *psDst = vcp[macc_z];
}

void _macc16_CA(LONG *plDst, SHORT *pnSrc1, SHORT *pnSrc2, DWORD dwSize)
{
  LONG ra, rb;
  SHORT *pnSrcEnd;
  DWORD dwCond1, dwCond2;

  vcp[macc_z] = 0x0;

  dwCond1 = (DWORD)pnSrc1 & 0x3;
  dwCond2 = (DWORD)pnSrc2 & 0x3;

  if ((dwCond1 && !dwCond2) || (!dwCond1 && dwCond2)) {
    /* one src pointer is in 16b and the other is in 32b */
    if (dwCond2) {
      SHORT *psTemp;
      psTemp = pnSrc1;
      pnSrc1 = pnSrc2;
      pnSrc2 = psTemp;
    } /* pnSrc1: WORD boundary, pnSrc2: DWORD boundary */

    pnSrcEnd = pnSrc2 + dwSize - 1;

    ra = *pnSrc1++;
    for (; pnSrc2 < pnSrcEnd; ) {
      vcp[macc_a] = (ra << 16);
      ra = *(LONG *)pnSrc1;
      rb = *(LONG *)pnSrc2;
      vcp[macc_a] |= ((ra >> 16)&0xffff);
      vcp[macc_b16] = rb;
      pnSrc1 += 2;
      pnSrc2 += 2;
    }

    if (dwSize & 0x01) {
      rb = *pnSrc2;
      vcp[macc_a] = ra & 0xffff; /* in the least significant 16b */
      vcp[macc_b16] = rb;
      asm("nop");
      asm("nop");
      asm("nop");
    }
    *plDst = vcp[macc_z];

  } else {

    if (dwCond1) {
      /* the first element is in 16b.*/
      ra = *pnSrc1;
      rb = *pnSrc2;
      vcp[macc_a]   = ra & 0xffff;
      vcp[macc_b16] = rb & 0xffff;
      pnSrc1++;
      pnSrc2++;
      dwSize --;
    }

    pnSrcEnd = pnSrc1 + dwSize -1;

    for (;pnSrc1 < pnSrcEnd;) {
      ra = *(LONG *)pnSrc1;
      rb = *(LONG *)pnSrc2;
      vcp[macc_a]   = ra;
      vcp[macc_b16] = rb;
      pnSrc1 += 2;
      pnSrc2 += 2;
    }

    if (dwSize & 0x01) {
      ra = *pnSrc1 & 0xffff;
      rb = *pnSrc2;
      vcp[macc_a]   = ra;
      vcp[macc_b16] = rb;
      asm("nop");
      asm("nop");
      asm("nop");
    }
    *plDst = vcp[macc_z];
  }
}

void _macc32_CA(LONG *dst, LONG *src1, LONG *src2, DWORD size)
{
  LONG ra, rb;
  LONG *plSrc1, *plSrc2, *plSrcEnd;
  
  vcp[macc_z] = 0x0;

  for (plSrc1=src1, plSrcEnd = plSrc1 + size, plSrc2=src2; plSrc1 < plSrcEnd;
       plSrc1++, plSrc2++) {
    ra = *plSrc1;
    rb = *plSrc2;
    vcp[macc_a]   = ra;
    vcp[macc_b32] = rb;
  }

  *dst = vcp[macc_z];
}

void _vecmult32_CA(LONG *dst, LONG *src1, LONG *src2, DWORD size)
{
  LONG ra, rb;
  LONG *plSrc1, *plSrc2, *plSrcEnd;

  for (plSrc1=src1, plSrcEnd = plSrc1 + size, plSrc2=src2; plSrc1 < plSrcEnd;) {
    ra = *plSrc1;
    rb = *plSrc2;
    vcp[mult_a]   = ra;
    vcp[mult_b32] = rb;
    plSrc1++;
    plSrc2++;
    *dst++ = vcp[mult_z1];
  }
}

void _vecmult16_CA(LONG *pnDst, SHORT *pnSrc1, SHORT *pnSrc2, DWORD dwSize)
{
  LONG ra, rb, rz1, rz2;
  SHORT *pnSrcEnd;
  DWORD dwCond1, dwCond2;

  dwCond1 = (DWORD)pnSrc1 & 0x3;
  dwCond2 = (DWORD)pnSrc2 & 0x3;

  if ((dwCond1 && !dwCond2) || (!dwCond1 && dwCond2)) {
    /* one src pointer is in 16b and the other is in 32b */

    if (dwCond2) {
      SHORT *psTemp;
      psTemp = pnSrc1;
      pnSrc1 = pnSrc2;
      pnSrc2 = psTemp;
    } /* pnSrc1: WORD boundary, pnSrc2: DWORD boundary */

    pnSrcEnd = pnSrc2 + dwSize - 1;

    ra = *pnSrc1++;
    for (; pnSrc2 < pnSrcEnd; ) {
      vcp[mult_a] = (ra << 16);
      ra = *(LONG *)pnSrc1;
      rb = *(LONG *)pnSrc2;
      vcp[mult_a] |= ((ra >> 16)&0xffff);
      vcp[mult_b16] = rb;
      pnSrc1 += 2;
      pnSrc2 += 2;
      rz1 = vcp[mult_z1];
      rz2 = vcp[mult_z2];
      *pnDst++ = rz1;
      *pnDst++ = rz2;
    }

    if (dwSize & 0x01) {
      rb = *pnSrc2;
      vcp[mult_a] = ra; /* in the least significant 16b */
      vcp[mult_b16] = rb;
      asm("nop");
      asm("nop");
      asm("nop");
      *pnDst = vcp[mult_z2];
    }
  } else {

    if (dwCond1) {
      ra = *pnSrc1;
      rb = *pnSrc2;
      vcp[mult_a]   = ra;
      vcp[mult_b16] = rb;
      pnSrc1++;
      pnSrc2++;
      dwSize --;
      *pnDst++ = vcp[mult_z2];
    }

    pnSrcEnd = pnSrc1 + dwSize - 1;

    for (;pnSrc1 < pnSrcEnd;) {
      ra = *(LONG *)pnSrc1;
      rb = *(LONG *)pnSrc2;
      vcp[mult_a]   = ra;
      vcp[mult_b16] = rb;
      pnSrc1 += 2;
      pnSrc2 += 2;
      rz1 = vcp[mult_z1];
      rz2 = vcp[mult_z2];
      *pnDst++ = rz1;
      *pnDst++ = rz2;
    }

    if (dwSize & 0x01) {
      ra = *pnSrc1;
      rb = *pnSrc2;
      vcp[mult_a]   = ra;
      vcp[mult_b16] = rb;
      asm("nop");
      asm("nop");
      asm("nop");
      *pnDst = vcp[mult_z2];
    }
  }
}
