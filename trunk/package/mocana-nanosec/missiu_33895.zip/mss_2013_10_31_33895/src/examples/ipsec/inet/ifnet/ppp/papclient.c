/*
 * pap.c
 *
 * Implementation of the PAP protocol as specified in RFC 1334
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"

#include "papclient_flavor.h"
#include "string.h"
#include "stdlib.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h> /* ntoh macros */
#include <netinet/in.h> /* ntoh macros on Linux/Solaris */
#include <pthread.h>
/*#include <mqueue.h>*/
#include <stdio.h>
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"
#include "netdbg.h"
#include "papparser.h"
#include "papclient.h"

/*****************************************************************************
 *
 * defines & macros
 *
 *****************************************************************************/

/* Timer defaults*/
#define PAPCLIENTDEFAULT_TIMER     3000

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef PAPCLIENTDBG_HI
   #define PAPCLIENTDBG_HI
  #endif

 #endif

#else

 #ifdef PAPCLIENTDBG_HI
  #undef PAPCLIENTDBG_HI
 #endif

#endif

/*#ifdef PAPCLIENTDBG_HI*/
#if defined(PAPCLIENTDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

#define PAPMAGICCOOKIE 0x50415000  /*"PAP"*/

  #define PAPDBG_SETMAGICOOKIE(pxState) \
    (pxState->dwMagicCookie = PAPMAGICCOOKIE)
  #define PAPDBG_UNSETMAGICCCOOKIE(pxState) \
    (pxState->dwMagicCookie = PAPMAGICCOOKIE)
  #define PAPDBG_CHECKSTATE(pxState) \
    ASSERT((pxState!=NULL) && (pxState->dwMagicCookie == PAPMAGICCOOKIE))

  #define PAP_DBGP(level, fmt, args...) do { \
    if (level <= g_dwPapDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define PAP_DBG(level, x) do {  \
    if (level <= g_dwPapDebugLevel) {  \
      x;      \
    }       \
  } while (0)

#else
  #define PAPDBG_SETMAGICOOKIE(pxState)
  #define PAPDBG_UNSETMAGICCCOOKIE(pxState)
  #define PAPDBG_CHECKSTATE(pxState)
  #define PPP_DBGP(level, fmt, args...)
  #define PPP_DBG(level, x)
#endif

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * PAPCLIENT states
 */
typedef enum {
  PAPCLIENTSTATE_DOWN = 0,
  PAPCLIENTSTATE_UP
} E_PAPCLIENTSTATE;

/*
 * PAPCLIENT main structure
 */
typedef struct {
#ifndef NDEBUG
  DWORD dwMagicCookie;   /* 0xdeadface */
#endif
  E_PAPCLIENTSTATE eState;

  DWORD dwTimer;

  OCTET obAuthentificationComplete; /* The Authentification has ended,
                                       whether positively or not */

  OCTET oCurrentId;

  OCTET *poId;
  OCTET oIdLength;
  OCTET *poPasswd;
  OCTET oPasswdLength;

  PFN_NETCBK pfnNetCbk;
  H_NETINSTANCE hNetCbk;

  H_NETINSTANCE hLl;
  H_NETINTERFACE hLlIf;
  PFN_NETWRITE pfnLlWrite;
  NETIFID xNetIfId;

  PFN_NETFREE pfnNetFree;
  PFN_NETMALLOC pfnNetMalloc;
  pthread_mutex_t *pxNetMutex;

  WORD wOffset;
  WORD wTrailer;

} PAPCLIENTSTATE;

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * PapClientInitialize
 *  Initialize the PAP library
 *
 *  Args:
 *
 *  Return:
 *    >=0
 */
LONG PapClientInitialize(void)
{
  /* Nothing to do */
  return NETERR_NOERR;
}

/*
 * PapClientTerminate
 *  Terminate the PapClient library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG PapClientTerminate(void)
{
  /* Nothing to do */
  return 0;
}

/*
 * PapClientInstanceCreate
 *  Create a PAP instance
 *
 *  Args:
 *
 *  Return:
 *   instance handle
 */
H_NETINSTANCE PapClientInstanceCreate(void)
{
  PAPCLIENTSTATE *pxPapClient;

  pxPapClient = (PAPCLIENTSTATE *)calloc(1,sizeof(PAPCLIENTSTATE));
  ASSERT(pxPapClient != NULL);

  PAPDBG_SETMAGICOOKIE(pxPapClient);

  /* Prevents processing till LL is Up */
  pxPapClient->obAuthentificationComplete = TRUE;

  return (H_NETINSTANCE)pxPapClient;
}

/*
 * PapClientInstanceDestroy
 *  Destroy a chap instance
 *
 *  Args:
 *   hPapClient              PapClient instance handle
 *
 *  Return:
 *   >=0
 */
LONG PapClientInstanceDestroy(H_NETINSTANCE hPapClient)
{
  PAPCLIENTSTATE *pxPapClient = (PAPCLIENTSTATE *)hPapClient;

  PAPDBG_CHECKSTATE(pxPapClient);

  if (pxPapClient->poId != NULL) {
    FREE(pxPapClient->poId);
  }

  if (pxPapClient->poPasswd != NULL) {
    FREE(pxPapClient->poPasswd);
  }
  PAPDBG_UNSETMAGICCCOOKIE(pxPapClient);
  FREE(pxPapClient);

  return NETERR_NOERR;
}

/*
 * PapClientInstanceSet
 *   Set PAP options
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceSet(H_NETINSTANCE hPapClient,OCTET oOption,
                      H_NETDATA hData)
{
  PAPCLIENTSTATE *pxPapClient = (PAPCLIENTSTATE *)hPapClient;

  ASSERT(pxPapClient != NULL);

  switch(oOption) {
  case NETOPTION_FREE:
    pxPapClient->pfnNetFree = (PFN_NETFREE)hData;

  case NETOPTION_MALLOC:
    pxPapClient->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    pxPapClient->pxNetMutex = (pthread_mutex_t *)hData;
    break;

 case NETOPTION_NETCBK:
    pxPapClient->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case NETOPTION_NETCBKHINST:
    pxPapClient->hNetCbk = (H_NETINSTANCE)hData;
    break;

  case NETOPTION_OFFSET:
    pxPapClient->wOffset = (WORD)( (DWORD)hData & 0xFFFF);
    break;

  case NETOPTION_TRAILER:
    pxPapClient->wTrailer = (WORD)( (DWORD)hData & 0xFFFF);
    break;

  case PAPCLIENTOPTION_ID:
    {
      PAPCLIENTCONF *pxConf = (PAPCLIENTCONF *)hData;

      if (pxPapClient->poId != NULL) {
        FREE(pxPapClient->poId);
      }
      pxPapClient->poId = (OCTET *)MALLOC((pxConf->wConfLength + 1)*sizeof(OCTET));
      ASSERT(pxPapClient->poId != NULL);
      memcpy(pxPapClient->poId,pxConf->poConf,(pxConf->wConfLength + 1));
      pxPapClient->oIdLength = (OCTET)(pxConf->wConfLength);
    }
  break;

  case PAPCLIENTOPTION_PASSWD:
    {
      PAPCLIENTCONF *pxConf = (PAPCLIENTCONF *)hData;
      if (pxPapClient->poPasswd != NULL) {
        FREE(pxPapClient->poPasswd);
      }
      pxPapClient->poPasswd = (OCTET *)
        MALLOC((pxConf->wConfLength + 1)*sizeof(OCTET));
      ASSERT(pxPapClient->poPasswd != NULL);
      memcpy(pxPapClient->poPasswd,pxConf->poConf,(pxConf->wConfLength + 1));
      pxPapClient->oPasswdLength = (OCTET)pxConf->wConfLength;
    }
  break;

  case PAPCLIENTOPTION_IFIDX:
    pxPapClient->xNetIfId.oIfIdx = (OCTET)hData;
    break;

  case PAPCLIENTOPTION_VLAN:
    pxPapClient->xNetIfId.wVlan = (WORD)hData;
    break;

  }

  return NETERR_NOERR;
}

/*
 * PapClientInstanceMsg
 *   PAPCLIENT msg function
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceMsg(H_NETINSTANCE hPapClient,OCTET oMsg,H_NETDATA hData)
{
  PAPCLIENTSTATE *pxPapClient = (PAPCLIENTSTATE *)hPapClient;
  LONG lReturn = NETERR_NOERR;

  PAPDBG_CHECKSTATE(pxPapClient);

  switch(oMsg) {

  case NETMSG_CLOSE:
    pxPapClient->obAuthentificationComplete = TRUE;
    /* Set it to true, so that no processing occurs */
    pxPapClient->eState = PAPCLIENTSTATE_DOWN;
    break;

  case NETMSG_LOWERLAYERUP:
    /* This is going to force processing */
    pxPapClient->obAuthentificationComplete = FALSE;
    break;

  case NETMSG_OPEN:
  case NETMSG_LOWERLAYERDOWN:
    /* Nothing to do here */
    break;
  }
  pxPapClient->pfnNetCbk(pxPapClient->hNetCbk,NETCBK_NEEDPROCESSING,
                         (H_NETDATA)0);

  return lReturn;
}

/*
 * PapClientInstanceLLInterfaceCreate
 *   Create PAP LL interface
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE PapClientInstanceLLInterfaceCreate(H_NETINSTANCE hPapClient)
{
  return (H_NETINTERFACE)1;
}

/*
 * PapClientInstanceLLInterfaceDestroy
 *   Destroy PAP LL interface
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceLLInterfaceDestroy(H_NETINSTANCE hPapClient, H_NETINTERFACE hIf)
{
  ASSERT((H_NETINTERFACE)1 == hIf);

  return NETERR_NOERR;
}

/*
 * PapClientInstanceLLInterfaceIoctl
 *   PAP LL interface ioctl function
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceLLInterfaceIoctl(H_NETINSTANCE hPapClient, H_NETINTERFACE hIf,
                                    OCTET oIoctl,H_NETDATA hData)
{
  PAPCLIENTSTATE *pxPapClient = (PAPCLIENTSTATE *)hPapClient;

  ASSERT(pxPapClient != NULL);

  switch(oIoctl) {

  case NETINTERFACEIOCTL_SETHINST:
    pxPapClient->hLl = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxPapClient->pfnLlWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxPapClient->hLlIf = (H_NETINTERFACE)hData;
    break;


  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    break;

  default:
    ASSERT(0);

  }

  return NETERR_NOERR;
}


/*
 * PapClientInstanceRcv
 *   PAP instance rcv
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            NETIFID *
 *
 *   Return:
 *     >=0
 */
LONG PapClientInstanceRcv(H_NETINSTANCE hPapClient, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  OCTET *poPointer;
  E_PAPPACKETTYPE eType;
  OCTET oId;
  PAPCLIENTSTATE *pxPap = (PAPCLIENTSTATE *)hPapClient;

  PAPDBG_CHECKSTATE(pxPap);

  NETPACKET_CHECK(pxPacket);

  poPointer = pxPacket->pxPayload->poPayload + pxAccess->wOffset;
  eType = PAPGET_TYPE(poPointer);
  oId = PAPGET_ID(poPointer);

  switch(eType) {
  case PAPPACKETTYPE_AUTHENTICATEACK:
    if ((oId == pxPap->oCurrentId) &&
        (pxPap->obAuthentificationComplete == FALSE)) {
      pxPap->obAuthentificationComplete = TRUE;
      pxPap->eState = PAPCLIENTSTATE_UP;
      pxPap->pfnNetCbk(pxPap->hNetCbk,NETCBK_TLU,(H_NETDATA)0);
    }
    break;

  case PAPPACKETTYPE_AUTHENTICATENAK:
    if (oId == pxPap->oCurrentId) {
      pxPap->obAuthentificationComplete = TRUE;
      pxPap->eState = PAPCLIENTSTATE_DOWN;
      pxPap->pfnNetCbk(pxPap->hNetCbk,NETCBK_TLD,(H_NETDATA)0);
    }
    break;

  default:
    /* Note: we don't handle reception of AUTHENTICATEREQUEST, as
       we are the client side */
    ASSERT(0);

  }

  NETPAYLOAD_DELUSER(pxPacket->pxPayload);

  pxPap->pfnNetCbk(pxPap->hNetCbk,NETCBK_NEEDPROCESSING,
                   (H_NETDATA)0);

  return (LONG)pxAccess->wLength;
}

/*
 * PapClientInstanceProcess
 *   PAP processing function
 *
 *   Args:
 *     hPapClient           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG PapClientInstanceProcess(H_NETINSTANCE hPapClient)
{
  PAPCLIENTSTATE *pxPap = (PAPCLIENTSTATE *)hPapClient;
  LONG lReturn = 0x7FFFFFFF;
  PAPDBG_CHECKSTATE(pxPap);

  if ((pxPap->obAuthentificationComplete == FALSE) &&
       (pxPap->poId != NULL) &&
       (pxPap->poPasswd != NULL)) {
    /* The Authentification Process has not completed yet */
    DWORD dwTime;

    dwTime = NetGlobalTimerGet();

    if (dwTime > pxPap->dwTimer) {
      /* Timer as expired: resend a request */
      NETPACKET xPacket;
      NETPACKETACCESS xAccess;
      WORD wSize;
      OCTET *poMsg;
      OCTET *poPointer;

      xAccess.wOffset = pxPap->wOffset;
      xAccess.wLength = (PAP_HLEN + 1 +pxPap->oIdLength + 1 +
                           pxPap->oPasswdLength);
      wSize = xAccess.wLength  + xAccess.wOffset + pxPap->wTrailer;

      poMsg = (OCTET *) MALLOC(wSize * sizeof(OCTET));

      ASSERT(poMsg != NULL);

      poPointer = poMsg + xAccess.wOffset;

      PAPSET_TYPE(poPointer,PAPPACKETTYPE_AUTHENTICATEREQUEST);
      PAPSET_LENGTH(poPointer,xAccess.wLength);
      pxPap->oCurrentId ++;
      PAPSET_ID(poPointer,pxPap->oCurrentId);

      *(PAPGET_DATAPOINTER(poPointer)) = pxPap->oIdLength;
      memcpy(PAPGET_DATAPOINTER(poPointer) + 1,pxPap->poId,pxPap->oIdLength);
      *(PAPGET_DATAPOINTER(poPointer) + 1 + pxPap->oIdLength) =
        pxPap->oPasswdLength;
      memcpy(PAPGET_DATAPOINTER(poPointer) + 1 + pxPap->oIdLength + 1,
             pxPap->poPasswd,pxPap->oPasswdLength);

      NETPAYLOAD_CREATE(&(xPacket.pxPayload),
                        pxPap->pfnNetFree,pxPap->pxNetMutex,
                        poMsg,
                        wSize);
      pxPap->pfnLlWrite(pxPap->hLl,pxPap->hLlIf,&xPacket,&xAccess,
                        (H_NETDATA)&(pxPap->xNetIfId));

      /* Reset the Timer */
      pxPap->dwTimer = dwTime + PAPCLIENTDEFAULT_TIMER;
      lReturn = PAPCLIENTDEFAULT_TIMER;
    }

  }
  return lReturn;
}


