/*
 * udp_cli.c
 *
 * Implements the "command line interface" for UDP
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/
#ifdef __MOC_CLI__

#include "../../common/mtypes.h"
#include "udp_cli.h"

ubyte4 UdpCliShow(ubyte *cmdRx, ubyte *uSbuf, ubyte4 *uSbufLen)
{
  printf("----\nUSAGE : not supported \n----\n");
  return(0);
}

ubyte4 UdpCliConfig(ubyte *cmdRx)
{
  return 0;
}
#endif

