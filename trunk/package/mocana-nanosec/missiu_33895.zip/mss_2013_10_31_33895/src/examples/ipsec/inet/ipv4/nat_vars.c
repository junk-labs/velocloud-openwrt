/*
 * nat_vars.c
 *
 * Global variables used by NAT.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "nat.h"
#include "nat_defs.h"

/*
 * Global variables used by NAT.
 * The scope of these variables is limited to NAT.
 */

/*
 * Total number of NAT bindings
 */
DEBUG_VAR(DWORD g_dwNatTotalNumBindings = 0;)


/*
 * NAT debug level.
 */
NAT_DBG_VAR(DWORD g_dwNatDebugLevel = DBGLVL_REPETITIVE;)


/*
 * NAT debug display bindings.
 */
NAT_DBG_VAR(BOOL g_bNatDisplayBindings;)


/*
 * Number of bindings
 */
NAT_DBG_VAR(DWORD g_adwNatNumActiveBindings[NAT_BINDING_MAX];)


/*
 * NAT debug display forwarded ports.
 */
NAT_DBG_VAR(BOOL g_bNatDisplayPortForward;)
