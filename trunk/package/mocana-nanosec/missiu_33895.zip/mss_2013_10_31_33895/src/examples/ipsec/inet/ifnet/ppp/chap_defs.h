/*
 * chap_defs.h
 *
 * Chap definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

 /*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#ifndef CHAP_DEFS_H
#define CHAP_DEFS_H

#include "NNstyle.h"

#include "chapclient_flavor.h"
#include "string.h"
#include "stdlib.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h> /* ntoh macros */
#include <netinet/in.h> /* ntoh macros on Linux/Solaris */
#include <pthread.h>
/* #include <mqueue.h> */
#include <stdio.h>
#include "netcommon.h"
#include "netutils.h"
#include "netdbg.h"
#include "nettime.h"
#include "cryptcommon.h"
#include "md5.h"
#include "chapparser.h"
#include "chapclient.h"
#include "chap_dbg.h"

/*****************************************************************************
 *
 * Defines & macros
 *
 *****************************************************************************/

#define CHAPCLIENTDEFAULT_TIMER          3000

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/
/*
 * CHAP states
 */
typedef enum {
  CHAPCLIENTSTATE_DOWN = 0,
  CHAPCLIENTSTATE_UP
} E_CHAPCLIENTSTATE;


/*
 * CHAPCLIENT main struture
 */
typedef struct {
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif
  E_CHAPCLIENTSTATE eState;   /* State */

  DWORD dwTimer; /* Timer */

  /* Secret */
  OCTET *poSecret;
  DWORD dwSecretLength;

  /* Name */
  OCTET *poName;     /* NULL terminated string */
  OCTET oNameLength; /* Must include the `0` */

  /* Challenge */
  OCTET *poCurrentChallenge;
  OCTET oCurrentChallengeLength;
  OCTET oCurrentChallengeId;
  OCTET obChallengeValid; /* Indicates that the challenge is valid */


  CHAPCLIENTENCRYPTIONSTATE xEncryption;

  PFN_NETCBK pfnNetCbk;
  H_NETINSTANCE hNetCbk;

  H_NETINSTANCE hLl;
  H_NETINTERFACE hLlIf;
  PFN_NETWRITE pfnLlWrite;
  NETIFID xNetIfId;

  PFN_NETFREE pfnNetFree;
  PFN_NETMALLOC pfnNetMalloc;
  pthread_mutex_t *pxNetMutex;

  WORD wOffset;
  WORD wTrailer;

} CHAPCLIENTSTATE;



/*****************************************************************************
 *
 * extern
 *
 *****************************************************************************/

#ifndef NDEBUG
MOC_EXTERN const OCTET *apoChapOptionString[CHAPCLIENTOPTIONMAX];
MOC_EXTERN const OCTET *apoChapMsgString[CHAPCLIENTMSGMAX];
#endif

/*****************************************************************************
 *
 * Local function definitions
 *
 *****************************************************************************/



#endif /*CHAP_DEFS_H*/
