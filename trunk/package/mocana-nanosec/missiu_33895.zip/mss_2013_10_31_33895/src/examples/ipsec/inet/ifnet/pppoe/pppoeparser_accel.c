/*
 * pppoeparser_accel.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "pppoeparser_defs.h"
/*****************************************************************************
 *
 * statics
 *
 *****************************************************************************/
static WORD awPppoETagIdxToType[PPPOETAGIDX_ENDOFLIST + 1] = {
  PPPOETAGTYPE_SERVICENAME,
  PPPOETAGTYPE_ACNAME,
  PPPOETAGTYPE_HOSTUNIQ,
  PPPOETAGTYPE_ACCOOKIE,
  PPPOETAGTYPE_VENDORSPECIFIC,
  PPPOETAGTYPE_RELAYSESSIONID,
  PPPOETAGTYPE_SERVICENAMEERROR,
  PPPOETAGTYPE_ACSYSTEMERROR,
  PPPOETAGTYPE_GENERICERROR,
  PPPOETAGTYPE_ENDOFLIST
};




 /*****************************************************************************
 *
 * Local Function
 *
 *****************************************************************************/
OCTET PppoETagTypeToIdx(WORD wTagType) {

  switch (wTagType) {
  case PPPOETAGTYPE_ENDOFLIST:
    return PPPOETAGIDX_ENDOFLIST;

  case PPPOETAGTYPE_SERVICENAME:
    return PPPOETAGIDX_SERVICENAME;

  case PPPOETAGTYPE_ACNAME:
    return PPPOETAGIDX_ACNAME;

  case PPPOETAGTYPE_HOSTUNIQ:
    return PPPOETAGIDX_HOSTUNIQ;

  case PPPOETAGTYPE_ACCOOKIE:
    return PPPOETAGIDX_ACCOOKIE;

  case PPPOETAGTYPE_VENDORSPECIFIC:
    return PPPOETAGIDX_VENDORSPECIFIC;

  case PPPOETAGTYPE_RELAYSESSIONID:
    return PPPOETAGIDX_RELAYSESSIONID;

  case PPPOETAGTYPE_SERVICENAMEERROR:
    return PPPOETAGIDX_SERVICENAMEERROR;

  case PPPOETAGTYPE_ACSYSTEMERROR:
    return PPPOETAGIDX_ACSYSTEMERROR;

  case PPPOETAGTYPE_GENERICERROR:
    return PPPOETAGIDX_GENERICERROR;
  }

  return PPPOETAGIDX_UNKNOWN;
}



/*****************************************************************************
 *
 * API
 *
 *****************************************************************************/

/*
 * PppoEDecode
 *  Decode a PPPoE packet
 *
 *  Args:
 *   poPDU               PPPoE PDU
 *   pxHdr               Header-to be filled in
 *   aTagTable           Tag Table-to be filled in
 *
 *  Return:
 *   >=0 successfull parsing
 *   -1 Parsing error
 *   -PPPOETAGTIDX_XXXERROR if an error tag has been found
 */
LONG PppoEDecode(OCTET *poPdu,PPPOEHDR *pxHdr,A_PPPOETAGTABLE aTagTable)
{
  LONG lReturn = NETERR_NOERR;
  OCTET *poPayload;
  /*
   * Fill up the header
   */
  pxHdr->oVersionType = PPPOEHDRGET_VERTYPE(poPdu);
  pxHdr->oCode        = PPPOEHDRGET_CODE(poPdu);
  pxHdr->wSessionId   = PPPOEHDRGET_SESSIONID(poPdu);
  pxHdr->wLength      = PPPOEHDRGET_LENGTH(poPdu);

  if ((pxHdr->oCode != PPPOECODE_SESSION) && (pxHdr->wLength > 0)) {
    WORD wOffset = 0;
   /* Not a session packet, and there is a payload: tags */
    /* Move the PDU to the beginning of the payload */
    poPayload = PPPOEHDRGET_PAYLOADPOINTER(poPdu);

    while (wOffset < pxHdr->wLength) {
      OCTET *poTag;
      WORD wTagType;
      PPPOETAG *pxTag;
      PPPOETAGITEM *pxTagItem;
      OCTET oTagIdx;

      /* Set tag pointer */
      poTag = poPayload + wOffset;

      wTagType = PPPOETAGGET_TYPE(poTag);

      oTagIdx = PppoETagTypeToIdx(wTagType);
      pxTag = &(aTagTable[oTagIdx]);

      /* Add an item in the list */
      pxTag->pxItemList = (PPPOETAGITEM *)
        realloc(pxTag->pxItemList,(++pxTag->wItemNum)*sizeof(PPPOETAGITEM));
      ASSERT(pxTag->pxItemList != NULL);

      pxTagItem = pxTag->pxItemList + (pxTag->wItemNum -1);

      pxTagItem->wLength = PPPOETAGGET_LENGTH(poTag);
      if (pxTagItem->wLength != 0) {
        pxTagItem->poData = (OCTET *)malloc(pxTagItem->wLength *sizeof(OCTET));
        memcpy(pxTagItem->poData,PPPOETAGGET_VALUEPOINTER(poTag),
               pxTagItem->wLength);
      }
      else {
        pxTagItem->poData = NULL;
      }
      wOffset += (PPPOETAG_HDRLEN + pxTagItem->wLength);

      if (wTagType == PPPOETAGTYPE_ENDOFLIST) {
        break;
      }
      if (wTagType >= PPPOETAGTYPE_ERROR_MIN) {
        lReturn = -oTagIdx;
      }
    }

  }

  return lReturn;
}

/*
 * PppoEEncode
 *  Encode a PPPoE PDU
 *
 *  Args:
 *   poPDU              Must point to the begginning of the PDU
 *                      Must be of the right length
 *   pxHdr              PPPoE Hdr. The length field must be correct
 *   aTagTable          Tag Table
 *
 * Return:
 *  >=0
 */
LONG PppoEEncode(OCTET *poPDU,PPPOEHDR *pxHdr,A_PPPOETAGTABLE aTagTable)
{
  ASSERT(pxHdr != NULL);

  /* deal with the case of an empty services field in a PADI */
  /* (a PADI must contain a services field) */
  if (pxHdr->oCode == PPPOECODE_PADI) {
    PPPOETAG *pxTag = &(aTagTable[PPPOETAGIDX_SERVICENAME]);
    if (pxTag->wItemNum == 0) {
      pxTag->wItemNum = 1;
      pxTag->pxItemList = (PPPOETAGITEM *)calloc(1,sizeof(PPPOETAGITEM));
      pxHdr->wLength += 4;
      ASSERT(pxTag->pxItemList != NULL);
    }
  }

  /* Fill up the header */
  PPPOEHDRSET_VERTYPE(poPDU,pxHdr->oVersionType);
  PPPOEHDRSET_CODE(poPDU,pxHdr->oCode);
  PPPOEHDRSET_SESSIONID(poPDU,pxHdr->wSessionId);
  PPPOEHDRSET_LENGTH(poPDU,pxHdr->wLength);

  if ((pxHdr->oCode != PPPOECODE_SESSION) && (pxHdr->wLength > 0)) {
    WORD wOffset = 0;
    OCTET o;
    /* Not a session packet, and the length is big enough for tags */
    /* Move the PDU to the beginning of the payload */
    poPDU = PPPOEHDRGET_PAYLOADPOINTER(poPDU);

    for (o=0; o <= PPPOETAGIDX_ENDOFLIST; o ++) {
      OCTET *poTag;
      OCTET o1;
      PPPOETAG *pxTag = aTagTable + o;
      WORD wTagType;

      wTagType = awPppoETagIdxToType[o];

      for (o1=0;o1<pxTag->wItemNum;o1++) {
        PPPOETAGITEM *pxTagItem = pxTag->pxItemList + o1;

        if ((wOffset + pxTagItem->wLength + PPPOETAG_HDRLEN) > pxHdr->wLength) {
          /* Not enough space for the rest */
          ASSERT(0);
          return 0;
        }

        poTag = poPDU + wOffset;
        PPPOETAGSET_TYPE(poTag,wTagType);
        PPPOETAGSET_LENGTH(poTag,pxTagItem->wLength);

        wOffset += PPPOETAG_HDRLEN;

        if (pxTagItem->wLength != 0) {
          memcpy(PPPOETAGGET_VALUEPOINTER(poTag),pxTagItem->poData,pxTagItem->wLength);
          wOffset += pxTagItem->wLength;
        }
      }
    }
  }

  return 0;
}




