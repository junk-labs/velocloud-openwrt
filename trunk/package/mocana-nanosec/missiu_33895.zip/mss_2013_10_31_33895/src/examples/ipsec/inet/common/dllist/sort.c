#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void DLLIST_sort(DLLIST *dllist, LONG (*sortfcn)(void *,void *))
{
  DLLIST_ITEM *tmpitem;
  DWORD was_a_change;

  if (sortfcn == NULL) sortfcn = this_item;

  do {
    was_a_change = 0x0;
    tmpitem = dllist->head;

    while(tmpitem != NULL) {
      if (tmpitem->next != NULL) {
	if (sortfcn(tmpitem->item,tmpitem->next->item) > 0) {
	  void *tmpdata;
	  tmpdata = tmpitem->item;
	  tmpitem->item = tmpitem->next->item;
	  tmpitem->next->item = tmpdata;
	  was_a_change++;
	}
      }
  
      tmpitem = tmpitem->next;
    }
 
  } while(was_a_change);
}

