/*
 * udpquery.c
 *
 * UDP module query
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "udp_flavor.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "netnetwork.h"
#include "../include/in.h"
#include "../include/socket.h"
#include "netutils.h"
#include "nettransport.h"
#include "ecc.h"
#include "udp.h"
#include "udpdefs.h"
#include "udp_dbg.h"


/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Local functions definition
 *
 *****************************************************************************/

/*
 * UdpInstanceQuery
 *  Query a UDP Instance Option
 *
 *  Args:
 *   hUdp                       UDP instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG UdpInstanceQuery(H_NETINSTANCE hUdp,OCTET oOption,
                      H_NETDATA *phData)
{
  UDPSTATE *pxUdp = (UDPSTATE *)hUdp;
  LONG lRv = NETERR_NOERR;
  UDP_CHECK_STATE(pxUdp);
  ASSERT(phData != NULL);

  switch(oOption) {

  case NETOPTION_PAYLOADMUTEX:
    *phData = (H_NETDATA)pxUdp->pxMutex;
    break;

  case NETOPTION_OFFSET:
    *phData = (H_NETDATA)pxUdp->wOffset;
    break;

  case NETOPTION_TRAILER:
    *phData = (H_NETDATA)pxUdp->wTrailer;
    break;

  case NETOPTION_NETCBK:
    *phData = (H_NETDATA)pxUdp->pfnNetCbk;
    break;


  default:
    lRv = NETERR_BADVALUE;
    ASSERT(0);
  }

  return lRv;

}

