/*
 * scheduler.h
 *
 * API for the Scheduler
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __SCHEDULER_H
#define __SCHEDULER_H

/************/
/* includes */
/************/

#include "NNstyle.h"


/***********/
/* defines */
/***********/

#if defined(SCHED_PRIORITY_CHANGE_STATS) && !defined(SCHED_STATS)
#  define SCHED_STATS
#endif

#if defined(SCHED_PROCESS_RESOURCE_STATS) && !defined(SCHED_STATS)
#  define SCHED_STATS
#endif

/************/
/* typedefs */
/************/

/*
 * handles
 */
typedef void *H_SCHED;            /* scheduler instance        */
typedef void *H_SCHED_USER;        /* scheduler user handle    */
typedef void *H_SCHED_SCHED;        /* nested scheduler attach handle */



/*
 * user Process() function, called by scheduler when its priority
 * is not SCHED_PRIORITY_OFF and its delay has expired
 *
 * parms:
 *    hInstance    instantiation handle for the module
 *    dwTicksAvail    # cycles available for the module to process
 */
typedef DWORD (*SCHED_PROCESS)(void *hInstance, DWORD dwTicksAvail);

/*
 * Early Release of Resources capability
 */
typedef enum {
  SCHED_USER_CAN_RELEASE_EARLY,
  SCHED_USER_CANNOT_RELEASE_EARLY
} E_SCHED_USER_RELEASE;


/*
 * Scheduler Events
 *
 * event data is READ-ONLY and only valid until the event callback function
 * returns
 */
typedef enum {

  /* currently no scheduler events */

  SCHED_EVENT_ENUMMAX        /* *** must be LAST in enum ***             */
} E_SCHED_EVENT;



/*
 * Scheduler error codes
 */
typedef enum {

  /* currently no scheduler errors */

  SCHED_ERR_ENUMMAX        /* *** must be LAST in enum ***             */
} E_SCHED_ERR;


/*
 * priorities
 */
typedef enum {
  SCHED_PRIORITY_OFF,
  SCHED_PRIORITY_NORMAL,
  SCHED_PRIORITY_PANIC,

  SCHED_PRIORITY_ENUMMAX        /* *** must be LAST in enum ***    */
} E_SCHED_PRIORITY;




/*******/
/* API */
/*******/

MOC_EXTERN void SchedInitialize(void);
MOC_EXTERN void SchedTerminate(void);
MOC_EXTERN H_SCHED SchedCreate(void);
MOC_EXTERN void SchedDestroy(H_SCHED hScheduler);
MOC_EXTERN H_SCHED_SCHED SchedAttachSched(H_SCHED hScheduler,
                      H_SCHED hSuperScheduler);
MOC_EXTERN void SchedDetachSched(H_SCHED_SCHED hSchedNested);
MOC_EXTERN H_SCHED_USER SchedRegisterUser(H_SCHED hScheduler, void *hInstance,
                      SCHED_PROCESS Process,
                      E_SCHED_USER_RELEASE eSchedRelease);
MOC_EXTERN void SchedUnregisterUser(H_SCHED_USER hSchedUser);
MOC_EXTERN DWORD SchedProcess(H_SCHED hScheduler, DWORD dwTicksAvail);
MOC_EXTERN E_SCHED_PRIORITY SchedGetPriority(H_SCHED_USER hSchedUser);
MOC_EXTERN void SchedSetDelay(H_SCHED_USER hSchedUser,
              DWORD dwStart, DWORD dwInterval);
MOC_EXTERN DWORD SchedGetDelay(H_SCHED_USER hSchedUser,
              DWORD *pdwStart, DWORD *pdwInterval);
MOC_EXTERN DWORD SchedQueryRelease(H_SCHED_USER hSchedUser);
MOC_EXTERN void SchedSetPriorityX(H_SCHED_USER hSchedUser,
                  E_SCHED_PRIORITY ePriority);


#if defined(SCHED_STATS)
   MOC_EXTERN void SchedReportScheduleUserStats(H_SCHED_USER hSchedUser);
   MOC_EXTERN void SchedReportSchedulerStats(H_SCHED hScheduler);
   MOC_EXTERN void SchedReportStats(void);
   MOC_EXTERN void SchedResetStats(void);
   MOC_EXTERN void SchedRegisterName(H_SCHED_USER hSchedUser, CHAR *szName);
#else
#  define SchedReportScheduleUserStats(h)
#  define SchedReportSchedulerStats(h)
#  define SchedReportStats()
#  define SchedResetStats()
#  define SchedRegisterName(h, s)
#endif

#if defined(SCHED_PROCESS_RESOURCE_STATS)
   MOC_EXTERN void SchedProcessEnterResources(H_SCHED_USER hSchedUser,
                      DWORD *pdwLevels);
   MOC_EXTERN void SchedProcessReturnResources(H_SCHED_USER hSchedUser,
                       DWORD dwReason,
                       DWORD *pdwLevels);
   MOC_EXTERN void SchedRegisterProcessResources(H_SCHED_USER hSchedUser,
                         DWORD dwNumReasons,
                         CHAR **pszReasonNames,
                         DWORD dwNumResources,
                         CHAR **pszResourceNames,
                         DWORD *adwMaxLevels);
   MOC_EXTERN void SchedReportProcessResourceStats(H_SCHED_USER hSchedUser);
   MOC_EXTERN void SchedResetProcessResourceStats(H_SCHED_USER hSchedUser);
#else
#  define SchedProcessEnterResources(h, p)
#  define SchedProcessReturnResources(h, r, p)
#  define SchedRegisterProcessResources(h, nrsn, prsn, nrsc, prsc, plvls)
#  define SchedReportProcessResourceStats(h)
#  define SchedResetProcessResourceStats(h)
#endif


#if defined(SCHED_PRIORITY_CHANGE_STATS)
   MOC_EXTERN void SchedPriorityChangeHistory(H_SCHED_USER hSchedUser,
                      E_SCHED_PRIORITY ePriority,
                      DWORD dwLine, OCTET *pFile);
   MOC_EXTERN void SchedReportPriorityHistory(H_SCHED_USER hSchedUser);
   MOC_EXTERN void SchedResetPriorityHistory(H_SCHED_USER hSchedUser);
#  define SchedSetPriority(h, p) do {                    \
        SchedPriorityChangeHistory((h), (p), __LINE__, __FILE__);    \
        SchedSetPriorityX((h), (p));                \
      } while (0)
#else
#  define SchedSetPriority(h, p) SchedSetPriorityX((h), (p))
#  define SchedReportPriorityHistory(h)
#  define SchedResetPriorityHistory(h)
#endif





#endif /* __SCHEDULER_H */










