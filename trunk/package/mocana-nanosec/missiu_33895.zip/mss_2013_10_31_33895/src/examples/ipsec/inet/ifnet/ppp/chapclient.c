/*
 * chapclient.c
 *
 * CHAP (Challenge Handshake Authentification Protocol) client
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "chap_defs.h"

/*****************************************************************************
 *
 * global
 *
 *****************************************************************************/

CHAP_DBG_VAR(DWORD g_dwChapDebugLevel = 3);

#ifdef CHAPDBG_HI
char* acChapTypeToString[] = {
             "CHAPPACKETTYPE_CHALLENGE",
             "CHAPPACKETTYPE_RESPONSE",
             "CHAPPACKETTYPE_SUCCESS",
             "CHAPPACKETTYPE_FAILURE"
};
#endif /*#ifdef CHAPDBG_HI*/

/*****************************************************************************
 *
 * Local Function
 *
 *****************************************************************************/

/*
 * ChapClientInstanceCreateRspMsg
 *   Create a ChapClient Rsp
 *
 *   Args:
 *   hChapClient               instance handle
 *   pxPacket            packet
 *   pxAccess            access
 */
LONG ChapClientInstanceCreateRspMsg(H_NETINSTANCE hChapClient,
                                    NETPACKET *pxPacket,
                                    NETPACKETACCESS *pxAccess)
{
  CHAPCLIENTSTATE *pxChapClient = (CHAPCLIENTSTATE *)hChapClient;
  WORD wSize;
  OCTET *poPayload,*poChapClientPDU;

  ASSERT(pxChapClient != NULL);
  ASSERT(pxPacket != NULL);
  ASSERT(pxAccess != NULL);

  pxAccess->wOffset = pxChapClient->wOffset;
  pxAccess->wLength = CHAP_HLEN + 1 + MD5_HASH_SIZE + pxChapClient->oNameLength;

  wSize = pxAccess->wOffset + pxAccess->wLength + pxChapClient->wTrailer;

  poPayload = (OCTET *)pxChapClient->pfnNetMalloc(wSize*sizeof(OCTET));
  ASSERT(poPayload != NULL);

  poChapClientPDU = poPayload + pxAccess->wOffset;

  CHAPSET_TYPE(poChapClientPDU,CHAPPACKETTYPE_RESPONSE);
  CHAPSET_ID(poChapClientPDU,pxChapClient->oCurrentChallengeId);
  CHAPSET_LENGTH(poChapClientPDU,pxAccess->wLength);

  CHAPDATASET_VALUESIZE(CHAPGET_DATAPOINTER(poChapClientPDU),MD5_HASH_SIZE);

  /* Encrypt the Rsp Value field */
  {
    H_CRYPT hCrypt;

    hCrypt = pxChapClient->xEncryption.pfnCryptInit();
    pxChapClient->xEncryption.pfnCryptUpdate(hCrypt,&(pxChapClient->oCurrentChallengeId),
                                       1);
    pxChapClient->xEncryption.pfnCryptUpdate(hCrypt,pxChapClient->poSecret,
                                             pxChapClient->dwSecretLength);

    ASSERT(pxChapClient->poCurrentChallenge != NULL);
    ASSERT(pxChapClient->oCurrentChallengeLength);

    pxChapClient->xEncryption.pfnCryptUpdate(hCrypt,
                                             pxChapClient->poCurrentChallenge,
                                             pxChapClient->oCurrentChallengeLength);

    pxChapClient->xEncryption.pfnCryptFinish(hCrypt,
                                             CHAPGET_DATAPOINTER(poChapClientPDU) + 1);

  }

  /* Set the name, if any */
  if (pxChapClient->oNameLength != 0) {
    ASSERT(pxChapClient->poName != NULL);
    memcpy(CHAPGET_DATAPOINTER(poChapClientPDU) + 1 + MD5_HASH_SIZE,
           pxChapClient->poName,pxChapClient->oNameLength);
  }

  NETPAYLOAD_CREATE(&(pxPacket->pxPayload),
                    pxChapClient->pfnNetFree,pxChapClient->pxNetMutex,
                    poPayload,
                    wSize);

  pxPacket->hMarker = (H_NETDATA)NULL;

  return NETERR_NOERR;
}

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * ChapClientInitialize
 *  Initialize the CHAP library
 *
 *  Args:
 *
 *  Return:
 *    >=0
 */
LONG ChapClientInitialize(void)
{
  /* Nothing to do */
  return NETERR_NOERR;
}

/*
 * ChapClientTerminate
 *  Terminate the ChapClient library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG ChapClientTerminate(void)
{
  /* Nothing to do */
  return 0;
}

/*
 * ChapClientInstanceCreate
 *  Create a CHAP instance
 *
 *  Args:
 *
 *  Return:
 *   instance handle
 */
H_NETINSTANCE ChapClientInstanceCreate(void)
{
  CHAPCLIENTSTATE *pxChapClient;

  pxChapClient = (CHAPCLIENTSTATE *)calloc(1,sizeof(CHAPCLIENTSTATE));
  ASSERT(pxChapClient != NULL);
  CHAP_SET_COOKIE(pxChapClient);

  return (H_NETINSTANCE)pxChapClient;
}

/*
 * ChapClientInstanceDestroy
 *  Destroy a chap instance
 *
 *  Args:
 *   hChapClient              ChapClient instance handle
 *
 *  Return:
 *   >=0
 */
LONG ChapClientInstanceDestroy(H_NETINSTANCE hChapClient)
{
  CHAPCLIENTSTATE *pxChapClient = (CHAPCLIENTSTATE *)hChapClient;

  CHAP_CHECK_STATE(pxChapClient);

  if (pxChapClient->poSecret != NULL) {
    free(pxChapClient->poSecret);
  }

  if (pxChapClient->poName != NULL) {
    free(pxChapClient->poName);
  }

  if (pxChapClient->poCurrentChallenge != NULL) {
    free(pxChapClient->poCurrentChallenge);
  }

  CHAP_UNSET_COOKIE(pxChapClient);
  free(pxChapClient);

  return NETERR_NOERR;
}

/*
 * ChapClientInstanceSet
 *   Set CHAP options
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceSet(H_NETINSTANCE hChapClient,OCTET oOption,
                      H_NETDATA hData)
{
  CHAPCLIENTSTATE *pxChapClient = (CHAPCLIENTSTATE *)hChapClient;
  CHAP_CHECK_STATE(pxChapClient);

  switch(oOption) {
  case NETOPTION_FREE:
    pxChapClient->pfnNetFree = (PFN_NETFREE)hData;

  case NETOPTION_MALLOC:
    pxChapClient->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    pxChapClient->pxNetMutex = (pthread_mutex_t *)hData;
    break;

 case NETOPTION_NETCBK:
    pxChapClient->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case NETOPTION_NETCBKHINST:
    pxChapClient->hNetCbk = (H_NETINSTANCE)hData;
    break;

  case NETOPTION_OFFSET:
    pxChapClient->wOffset = (WORD)( (DWORD)hData & 0xFFFF);
    break;

  case NETOPTION_TRAILER:
    pxChapClient->wTrailer = (WORD)( (DWORD)hData & 0xFFFF);
    break;

  case CHAPCLIENTOPTION_ENCRYPTION:
    memcpy(&(pxChapClient->xEncryption),(void *)hData,sizeof(CHAPCLIENTENCRYPTIONSTATE));
    break;

  case CHAPCLIENTOPTION_NAME:
    {
      CHAPCLIENTCONF *pxConf = (CHAPCLIENTCONF *)hData;

      if (pxChapClient->poName != NULL) {
        free(pxChapClient->poName);
      }
      pxChapClient->poName = (OCTET *)malloc((pxConf->wConfLength + 1)*sizeof(OCTET));
      ASSERT(pxChapClient->poName != NULL);
      memcpy(pxChapClient->poName,pxConf->poConf,(pxConf->wConfLength + 1));
      pxChapClient->oNameLength = (OCTET)(pxConf->wConfLength);
    }
  break;

  case CHAPCLIENTOPTION_SECRET:
    {
      CHAPCLIENTCONF *pxConf = (CHAPCLIENTCONF *)hData;
      if (pxChapClient->poSecret != NULL) {
        free(pxChapClient->poSecret);
      }
      pxChapClient->poSecret = (OCTET *)malloc((pxConf->wConfLength + 1)*sizeof(OCTET));
      ASSERT(pxChapClient->poSecret != NULL);
      memcpy(pxChapClient->poSecret,pxConf->poConf,(pxConf->wConfLength + 1));
      pxChapClient->dwSecretLength = pxConf->wConfLength;
    }
  break;

  }

  return NETERR_NOERR;
}

/*
 * ChapClientInstanceMsg
 *   CHAPCLIENT msg function
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceMsg(H_NETINSTANCE hChapClient,OCTET oMsg,H_NETDATA hData)
{
  CHAPCLIENTSTATE *pxChapClient = (CHAPCLIENTSTATE *)hChapClient;
  LONG lReturn = NETERR_NOERR;
  CHAP_CHECK_STATE(pxChapClient);

  switch(oMsg) {

  case NETMSG_CLOSE:
    pxChapClient->oCurrentChallengeId = 0;
   pxChapClient->obChallengeValid = FALSE;

   if (pxChapClient->poCurrentChallenge != NULL) {
     free(pxChapClient->poCurrentChallenge);
     pxChapClient->poCurrentChallenge = NULL;
     pxChapClient->oCurrentChallengeLength = 0;
   }

   pxChapClient->eState = CHAPCLIENTSTATE_DOWN;
   break;

  case NETMSG_OPEN:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    /* Nothing to do here */
    break;

  case CHAPCLIENTMSG_CONFREQ:
    /* Encryption configuration */
    {
      CHAPCLIENTCONF *pxConf = (CHAPCLIENTCONF *)hData;
      ASSERT(pxConf->poConf != NULL);
      if (*(pxConf->poConf) != pxChapClient->xEncryption.oId) {
        CHAP_DBGP(ERROR,"ChapClientInstanceMsg:configuration fails\n");
        *pxConf->poConf = pxChapClient->xEncryption.oId;
        lReturn = NETERR_UNKNOWN;
      }
    }
    break;
  }

  return lReturn;
}

/*
 * ChapClientInstanceLLInterfaceCreate
 *   Create CHAP LL interface
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE ChapClientInstanceLLInterfaceCreate(H_NETINSTANCE hChapClient)
{
  return (H_NETINTERFACE)1;
}

/*
 * ChapClientInstanceLLInterfaceDestroy
 *   Destroy CHAP LL interface
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceLLInterfaceDestroy(H_NETINSTANCE hChapClient, H_NETINTERFACE hIf)
{
  ASSERT((H_NETINTERFACE)1 == hIf);

  return NETERR_NOERR;
}

/*
 * ChapClientInstanceLLInterfaceIoctl
 *   CHAP LL interface ioctl function
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceLLInterfaceIoctl(H_NETINSTANCE hChapClient, H_NETINTERFACE hIf,
                                    OCTET oIoctl,H_NETDATA hData)
{
  CHAPCLIENTSTATE *pxChapClient = (CHAPCLIENTSTATE *)hChapClient;
  CHAP_CHECK_STATE(pxChapClient);

  switch(oIoctl) {

  case NETINTERFACEIOCTL_SETHINST:
    pxChapClient->hLl = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxChapClient->pfnLlWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxChapClient->hLlIf = (H_NETINTERFACE)hData;
    break;


  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    break;

  default:
    ASSERT(0);

  }

  return NETERR_NOERR;
}

/*
 * ChapClientInstanceRcv
 *   CHAP instance rcv
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            NETIFID *
 *
 *   Return:
 *     >=0
 */
LONG ChapClientInstanceRcv(H_NETINSTANCE hChapClient, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  OCTET *poData;
  E_CHAPPACKETTYPE eType;
  CHAPCLIENTSTATE *pxChapClient = (CHAPCLIENTSTATE *)hChapClient;
  LONG lReturn = pxAccess->wLength;
  OCTET oId;
  WORD wLength;

  CHAP_CHECK_STATE(pxChapClient);
  ASSERT(pxAccess != NULL);
  NETPACKET_CHECK(pxPacket);
  poData = pxPacket->pxPayload->poPayload + pxAccess->wOffset;

  eType = CHAPGET_TYPE(poData);
  oId = CHAPGET_ID(poData);
  wLength = CHAPGET_LENGTH(poData);

  CHAP_DBGP(REPETITIVE,"ChapClientInstanceRcv:hChapClient=%d,%s\n",
                        (int)hChapClient,acChapTypeToString[eType - 1]);


  if((pxChapClient->poSecret == NULL) || (pxChapClient->poName == NULL)){
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    return -1;
  }

  switch (eType) {
  case CHAPPACKETTYPE_CHALLENGE:
    {
      OCTET *poPointer = CHAPGET_DATAPOINTER(poData);
      OCTET oValueSize = CHAPDATAGET_VALUESIZE(poPointer);
      NETPACKET xNetPacket;
      NETPACKETACCESS xNetAccess;

      ASSERT(oValueSize != 0);

      if (((oId != pxChapClient->oCurrentChallengeId) ||
           (pxChapClient->obChallengeValid == FALSE)) && (oValueSize != 0)) {
        pxChapClient->poCurrentChallenge = realloc(pxChapClient->poCurrentChallenge,
                                             oValueSize * sizeof(OCTET));
        ASSERT(pxChapClient->poCurrentChallenge != NULL);

        pxChapClient->oCurrentChallengeLength = oValueSize;
        pxChapClient->oCurrentChallengeId = oId;
        pxChapClient->obChallengeValid = TRUE;

        memcpy(pxChapClient->poCurrentChallenge,CHAPDATAGET_VALUEPOINTER(poPointer),
               oValueSize);

        memcpy(&(pxChapClient->xNetIfId),(void *)hData,sizeof(NETIFID));
      }
      ASSERT(pxChapClient->poCurrentChallenge != NULL);

      ChapClientInstanceCreateRspMsg(hChapClient,&xNetPacket,&xNetAccess);

      /* Allocate the Rsp Msg */
      pxChapClient->pfnLlWrite(pxChapClient->hLl,pxChapClient->hLlIf,
                         &xNetPacket,&xNetAccess,hData);

      /* Start Up the Timer */
      pxChapClient->dwTimer = NetGlobalTimerGet() + CHAPCLIENTDEFAULT_TIMER;
      break;
    }

  case CHAPPACKETTYPE_SUCCESS:
    /* Authentification successfull */
    if (oId == pxChapClient->oCurrentChallengeId) {
      /* It is the right ID */
      pxChapClient->eState = CHAPCLIENTSTATE_UP;
      pxChapClient->pfnNetCbk(pxChapClient->hNetCbk,NETCBK_TLU,(H_NETDATA)0);
    }
    break;

  case CHAPPACKETTYPE_FAILURE:
    if (oId == pxChapClient->oCurrentChallengeId) {
      pxChapClient->eState = CHAPCLIENTSTATE_DOWN;
      pxChapClient->oCurrentChallengeId = 0;
      if (pxChapClient->poCurrentChallenge != NULL) {
        free(pxChapClient->poCurrentChallenge);
        pxChapClient->poCurrentChallenge = NULL;
        pxChapClient->oCurrentChallengeLength = 0;
        pxChapClient->pfnNetCbk(pxChapClient->hNetCbk,NETCBK_TLD,(H_NETDATA)0);
      }
    }
    break;

  default:
    /* We don't support RESPONSE at reception, as we don't send
       any challenge (client side) */

    }

  pxChapClient->pfnNetCbk(pxChapClient->hNetCbk,NETCBK_NEEDPROCESSING,(H_NETDATA)0);

  /* Free the data */
  NETPAYLOAD_DELUSER(pxPacket->pxPayload);

  return lReturn;
}

/*
 * ChapClientInstanceProcess
 *   CHAP processing function
 *
 *   Args:
 *     hChapClient           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG ChapClientInstanceProcess(H_NETINSTANCE hChapClient)
{
  CHAPCLIENTSTATE *pxChapClient = (CHAPCLIENTSTATE *)hChapClient;
  LONG lReturn = 0x7FFFFFFF;
  CHAP_CHECK_STATE(pxChapClient);

  if (pxChapClient->eState == CHAPCLIENTSTATE_DOWN) {
    if (pxChapClient->poCurrentChallenge != NULL) {
      /* Means the Authentification is still running */
      DWORD dwTime;

      dwTime = NetGlobalTimerGet();
      if (dwTime > pxChapClient->dwTimer) {
        NETPACKET xNetPacket;
        NETPACKETACCESS xNetAccess;
        /* Timer has expired, retransmit the RSP */
        ChapClientInstanceCreateRspMsg(hChapClient,&xNetPacket,&xNetAccess);

        pxChapClient->pfnLlWrite(pxChapClient->hLl,pxChapClient->hLlIf,
                           &xNetPacket,&xNetAccess,
                           (H_NETDATA)&(pxChapClient->xNetIfId));
        /* Start Up the Timer */
        pxChapClient->dwTimer = NetGlobalTimerGet() + CHAPCLIENTDEFAULT_TIMER;
        lReturn = CHAPCLIENTDEFAULT_TIMER;
      }

    }
  }

  return lReturn;
}













