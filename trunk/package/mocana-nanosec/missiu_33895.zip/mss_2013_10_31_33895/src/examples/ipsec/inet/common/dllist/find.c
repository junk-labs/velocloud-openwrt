#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void *DLLIST_find(DLLIST *dllist, void *pKey, LONG (*sortfcn)(void *,void *))
{
  DLLIST_ITEM *tmp1;
  
  if (sortfcn == NULL) sortfcn = this_item;
	
  tmp1 = dllist->cur;

  while(tmp1 != NULL) {
    if (sortfcn(tmp1->item,pKey) == 0) {
      break;
    }
  
    tmp1 = tmp1->next;
  }

  dllist->cur = tmp1;
  return(tmp1 ? tmp1->item : NULL);
}
