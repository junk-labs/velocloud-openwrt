/*
 * pppoecommon.h
 *
 * PPPoE common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPPOECOMMON_H_
#define _PPPOECOMMON_H_

/****************************************************************************
 *
 * defines
 *
 ****************************************************************************/

/*
 * default header length
 */
#define PPPOE_HDRLEN                        6

#define PPPOEDEFAULT_RETRANSMISSIONTO       5000   /* 5s in msec */
#define PPPOEDEFAULT_RECONNECTION_TO        60000  /* 60s in msec */

#define PPPOEDEFAULT_RETRANSMISSIONCOUNTER  3

/*
 * PPPoE ethernet protocol type
 */
#define PPPOEETHPROT_DISCOVERY              0x886
#define PPPOEETHPROT_SESSION                0x8864

/*
 * PPPoE wide options
 */
#define PPPOEOPTION_RETRANSMISSIONTO         \
  (NETOPTION_MODULESPECIFICBEGIN)           /* Retransmission time-out, in ms
                                              data is a DWORD. it is used
                                              as a base */

#define PPPOEOPTION_RETRANSMISSIONCOUNTER     \
  (NETOPTION_MODULESPECIFICBEGIN + 1)      /* Retransmission counter,
                                              data is a DWORD. When
                                              the counter reaches 0, a
                                              COUNTEREXPIRED event is
                                              generated */
#define PPPOEOPTION_PHYIF                     \
  (NETOPTION_MODULESPECIFICBEGIN + 2)      /* Physical interface used.
                                              data is OCTET (index) */

#define PPPOEOPTION_VLAN                     \
  (NETOPTION_MODULESPECIFICBEGIN + 3)      /* Vlan. data is Vlan */

#define PPPOEOPTION_RECONNECTIONTO         \
  (NETOPTION_MODULESPECIFICBEGIN + 4)        /* Reconnection timeout, in ms
                                              data is a DWORD. */

#define PPPOEOPTION_MODULESPECIFICBEGIN      \
  (NETOPTION_MODULESPECIFICBEGIN + 5)


/*
 * PPPoE common LL interface ioctl
 */
#define PPPOELLINTERFACEIOCTL_SETSESSIONIF   \
 (NETINTERFACEIOCTL_MODULESPECIFICBEGIN)        /* Set the session LL if handle
                                                 */

#define PPPOELLINTERFACEIOCTL_MODULESPECIFICBEGIN    \
 (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 1)

#endif /* #ifndef _PPPOECOMMON_H_ */
