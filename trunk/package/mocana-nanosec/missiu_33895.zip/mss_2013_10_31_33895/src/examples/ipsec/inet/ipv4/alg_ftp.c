/*
 * alg_ftp.c
 *
 * Routines to handle FTP ALG
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "alg_ftp.h"


/*****************************************************************************
Function:
        ProcessFTPPacket()
Description:
        Searches through the payload of an FTP packet for 'PORT' commands
        and responses to the 'PASV' command. Replaces the IP address and port
        strings with relevent translations.
Arguments:
        NATSTATE*               pxNat                   NAT instance handle.
        NETPACKET*              pxNetPacket             Packet pointer
        NETPACKETACCESS*        pxNetPacketAccess       Packet info
    H_NETDATA               hData                   NETWORKID*
        DWORD                   dwPayloadOffset         Offset to start of payload
        DWORD                   dwPayloadSize           Size of input payload.
        DWORD                   dwIpAddr                Translation IP address (to
                                                        replace what is found)
        WORD                    wPort                   Translation PORT (to
                                                        replace what is found)
        SHORT*                  psDelta                 Change in the packet size,
                                                        this is an output
Outputs:
        NETPACKET*              pxNetPacket             Modified packet (if necessary)
        NETPACKETACCESS*        pxNetPacketAccess       Modified packet info (if necessary)
        H_NETDATA               hData                   Modified NETWORKID (if necessary)
        SHORT*                  psDelta                 Change in the packet size
Returns:
        BOOL                    1                       Packet payload was altered
                                0                       Packet payload was not altered
Revisions:
        30-Oct-2001                                     Initial
        26-Mar-2002                                     API change
*****************************************************************************/
LONG ProcessFTPPacket(NATSTATE* pxNat,
                      NETPACKET *pxNetPacket,
                      NETPACKETACCESS *pxNetPacketAccess,
                      H_NETDATA hData,
                      DWORD dwPayloadOffset,
                      DWORD dwPayloadSize,
                      DWORD dwIpAddr,
                      WORD  wPort,
                      SHORT *psDelta)
{
  OCTET *poPayload = pxNetPacket->pxPayload->poPayload + dwPayloadOffset;
  NETWORKID* pxNetworkId = (NETWORKID*) hData;
  NETPAYLOAD* pxNetPayload = pxNetPacket->pxPayload;
  DWORD dwNewPayloadSize = 0;

  /* Look for and replace 'PORT' command parameters */
  if (!strncasecmp(poPayload,"PORT",4)) {
    int aiD[6];
    WORD wPORTPort;
    DWORD dwLanAddr;

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
    {
      /*NAT_DBGP(DBGLVL_REPETITIVE, "Detected PORT command\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Detected PORT command\n");
    }

    if (6 == sscanf(poPayload+5,"%d,%d,%d,%d,%d,%d\r\n",
                    &aiD[0],&aiD[1],&aiD[2],
                    &aiD[3],&aiD[4],&aiD[5])) {
      DWORD dwNewLen;
      char pcReplaceStr[30];

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "PORT command advertised %d.%d.%d.%d:%d\n",
                      aiD[0], aiD[1], aiD[2], aiD[3],
                      (WORD) ((aiD[4] << 8) | (aiD[5])));*/
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "PORT command advertised", aiD[0], ".", aiD[1]);
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ".", aiD[2], ".", aiD[3]);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ":", (WORD) ((aiD[4] << 8) | (aiD[5])));
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }

      dwLanAddr = (DWORD)((aiD[0]&0xff) << 24) | ((aiD[1]&0xff) << 16) | ((aiD[2]&0xff) << 8) | (aiD[3]&0xff);
      wPORTPort = (WORD)((aiD[4]&0xff) << 8) | aiD[5];
      if ((wPORTPort = NatPortForwardAlg(pxNat,
                                         dwLanAddr, wPORTPort,
                                         dwIpAddr, pxNetworkId->oIfIdx,
                                         IPPROTO_TCP)) == 0) {
        /* cannot create a binding */
        return (-1);
      }

      sprintf(pcReplaceStr,"%ld,%ld,%ld,%ld,%d,%d\r\n",
              (dwIpAddr>>24),
              (dwIpAddr>>16)&0xff,
              (dwIpAddr>>8)&0xff,
              (dwIpAddr)&0xff,
              (wPORTPort>>8),
              (wPORTPort)&0xff);
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "PORT command advertisement translated to %ld.%ld.%ld.%ld:%d\n",
                      (dwIpAddr>>24),
                      (dwIpAddr>>16)&0xff,
                      (dwIpAddr>>8)&0xff,
                      (dwIpAddr&0xff),
                      wPORTPort);*/
        DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "PORT command advertisement translated to ", dwIpAddr);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ":", wPORTPort);
      }

      dwNewPayloadSize = strlen(pcReplaceStr) + 5 /* for the string PORT */;
      *psDelta = (SHORT)(dwNewPayloadSize - dwPayloadSize);

      /* Need to realloc? */
      if (*psDelta > 0) {
        dwNewLen = pxNetPayload->wSize + *psDelta;
        poPayload = MALLOC(dwNewLen * sizeof(CHAR));
        if (poPayload == NULL) {
          return (-1);
        }
        MOC_MEMCPY((ubyte *)poPayload, (ubyte *)pxNetPayload->poPayload, pxNetPayload->wSize);

        NETPAYLOAD_DELUSER(pxNetPayload);

        NETPAYLOAD_CREATE(&pxNetPacket->pxPayload,
                          NetFree,
                          NULL,        /* TODO use the proper Mutex */
                          poPayload,
                          dwNewLen);

        poPayload += dwPayloadOffset;    /* points to the start of the payload, past all headers */
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "Payload size increased - REALLOC!\n");*/
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Payload size increased - REALLOC!");
        }
      }

      MOC_MEMCPY((ubyte *)(poPayload+5), (ubyte *)pcReplaceStr, dwNewPayloadSize-5);

      pxNetPacketAccess->wLength += *psDelta;
      pxNetworkId->wTotalLen += *psDelta;

      return TRUE;
    }
  }

  /* Look for and replace response to 'PASV' command */
  else if (!strncasecmp(poPayload,"227",3)) {
    int aiD[6];
    WORD wPASVPort;
    DWORD dwLanAddr;

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
    {
      /*NAT_DBGP(DBGLVL_REPETITIVE, "Detected PASV response\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Detected PASV response");
    }

    if (6 == sscanf(poPayload+26,"(%d,%d,%d,%d,%d,%d)\r\n",
                    &aiD[0],&aiD[1],&aiD[2],
                    &aiD[3],&aiD[4],&aiD[5])) {
      DWORD dwNewLen;
      char pcReplaceStr[30];

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "PASV response advertised %d.%d.%d.%d:%d\n",
                      aiD[0], aiD[1], aiD[2], aiD[3],
                      (WORD) ((aiD[4] << 8) | (aiD[5])));*/
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "PASV response advertised", aiD[0], ".", aiD[1]);
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ".", aiD[2], ".", aiD[3]);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ":", (WORD) ((aiD[4] << 8) | (aiD[5])));
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }

      dwLanAddr = (DWORD)((aiD[0]&0xff) << 24) | ((aiD[1]&0xff) << 16) | ((aiD[2]&0xff) << 8) | (aiD[3]&0xff);
      wPASVPort = (WORD)((aiD[4]&0xff) << 8) | aiD[5];

      if ((wPASVPort = NatPortForwardAlg(pxNat,
                                         dwLanAddr, wPASVPort,
                                         dwIpAddr, pxNetworkId->oIfIdx,
                                         IPPROTO_TCP)) == 0) {
        /* cannot create a binding */
        return (-1);
      }

      sprintf(pcReplaceStr,"(%ld,%ld,%ld,%ld,%d,%d)\r\n",
              (dwIpAddr>>24),
              (dwIpAddr>>16)&0xff,
              (dwIpAddr>>8)&0xff,
              (dwIpAddr)&0xff,
              (wPASVPort>>8),
              (wPASVPort)&0xff);

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "PASV response advertisement translated to %ld.%ld.%ld.%ld:%d\n",
                      (dwIpAddr>>24),
                      (dwIpAddr>>16)&0xff,
                      (dwIpAddr>>8)&0xff,
                      (dwIpAddr&0xff),
                      wPASVPort);*/
        DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "PASV response advertisement translated to ", dwIpAddr);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ":", wPASVPort);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }

      dwNewPayloadSize = strlen(pcReplaceStr) + 26;
      *psDelta = (SHORT)(dwNewPayloadSize - dwPayloadSize);

      /* Need to realloc? */
      if (*psDelta > 0) {
        dwNewLen = pxNetPayload->wSize + *psDelta;
        poPayload = MALLOC(dwNewLen * sizeof(CHAR));
        if (poPayload == NULL) {
          return (-1);
        }
        MOC_MEMCPY((ubyte *)poPayload,(ubyte *) pxNetPayload->poPayload, pxNetPayload->wSize);

        NETPAYLOAD_DELUSER(pxNetPayload);

        NETPAYLOAD_CREATE(&pxNetPacket->pxPayload,
                          NetFree,
                          NULL,        /* TODO use the proper Mutex */
                          poPayload,
                          dwNewLen);

        poPayload += dwPayloadOffset;    /* points to the start of the payload, past all headers */

        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "Payload size increased - REALLOC!\n"); */
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Payload size increased - REALLOC!");
        }
      }

      MOC_MEMCPY((ubyte *)(poPayload+26),(ubyte *) pcReplaceStr, dwNewPayloadSize-26);

      pxNetPacketAccess->wLength += *psDelta;
      pxNetworkId->wTotalLen += *psDelta;

      return TRUE;
    }
  }
#ifdef NATDBG_HI
  else {
    if ((!strncasecmp(poPayload,"ORT", 3)) || (!strncasecmp(poPayload, "RT", 2)) ||
        (!strncasecmp(poPayload,"27", 2)) || (!strncasecmp(poPayload, "7", 1))) {
      printf("Possible truncated PORT or PASV command\n");
      NetPrintPayload(poPayload, dwPayloadSize);
    }
  }
#endif

  /* Payload was not changed */
  *psDelta = 0;
  return FALSE;
}


/*********************************************************************************************
Function:
        AlgFtp()
Description:
        Searches through the payload of an FTP packet for 'PORT' commands
        and responses to the 'PASV' command. Replaces the IP address and port
        strings with relevent translations. Also updates the TCP sequence and
        acknowledement numbers based on the cumulative deltas in the packet
        size.
Arguments:
        NATSTATE*               pxNat                   NAT instance handle.
        NETPACKET*              pxNetPacket             Packet pointer
        NETPACKETACCESS*        pxNetPacketAccess       Packet info
        H_NETDATA               hData                   NETWORKID*
        void*                   pvProtocolHdr           Protocol Header.
        NAT_ENTRY*              pxNatEntry              Pointer to the NAT binding entry
        WORD                    wLanPort                The LAN port
        E_NAT_DIRECTION         eDirection              Packet flow direction
Outputs:
        NETPACKET*              pxNetPacket             Modified packet (if necessary)
        NETPACKETACCESS*        pxNetPacketAccess       Modified packet info (if necessary)
        H_NEDATA                hData                   Modified NETWORKID (if necessary)
Returns:
        LONG                    0                       Packet payload was altered
                                1                       Packet payload was not altered
                                -1                      Error
Revisions:
       30-Oct-2001                                      Initial
       26-Mar-2002                                      API change
*********************************************************************************************/
LONG AlgFtp(NATSTATE* pxNat,
            NETPACKET *pxNetPacket,
            NETPACKETACCESS *pxNetPacketAccess,
            H_NETDATA hData,
            void* pvProtocolHdr,
            NAT_ENTRY *pxNatEntry,
            WORD wLanPort,
            E_NAT_DIRECTION eDirection)
{
  SHORT sDeltaLength = 0;
  LONG lReturn = 0;
  TCPHDR* pxTcpHdr = (TCPHDR*) pvProtocolHdr;
  NETWORKID* pxNetworkId = (NETWORKID*) hData;

  /*
   * WAN -> LAN (Downstream)
   */
  if (eDirection == NAT_DIR_W2L) {

    /*
     * Only need to modify the acknowledgement number
     */
    if (pxNatEntry->u.xTUMapping.lUpstreamSeqDelta) {

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "W2L - TCP Acknowledgement number changed from %lu to ", TCP_GET_ACK_NUM(pxTcpHdr));*/
        DEBUG_PRINT(DEBUG_MOC_IPV4, "W2L - TCP Acknowledgement number changed from ");
        DEBUG_UINT(DEBUG_MOC_IPV4, TCP_GET_ACK_NUM(pxTcpHdr));
        DEBUG_PRINT(DEBUG_MOC_IPV4, " to ");
      }

      TCP_SET_ACK_NUM(pxTcpHdr, (TCP_GET_ACK_NUM(pxTcpHdr) - pxNatEntry->u.xTUMapping.lUpstreamSeqDelta));

      if ((TCP_GET_ACK_NUM(pxTcpHdr) <= pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum) ||
          ((TCP_GET_ACK_NUM(pxTcpHdr) - pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum) > (1 << 16)) /* Assume wraparound */) {
        /*
         * This is an acknowledgement of a packet that occurred before the
         * last FTP packet which required a payload modification
         */
        TCP_SET_ACK_NUM(pxTcpHdr, (TCP_GET_ACK_NUM(pxTcpHdr) + pxNatEntry->u.xTUMapping.sLastPayloadModifiedDelta));
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "(retransmission) ");*/
          DEBUG_PRINT(DEBUG_MOC_IPV4, "(retransmission) ");
        }
      }

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "Acknowledgement Number = %lu, Sequence Number = %lu\n",
            TCP_GET_ACK_NUM(pxTcpHdr),
                        TCP_GET_SEQ_NUM(pxTcpHdr));*/
        DEBUG_PRINT(DEBUG_MOC_IPV4, "Acknowledgement Number = ");
        DEBUG_UINT(DEBUG_MOC_IPV4, TCP_GET_ACK_NUM(pxTcpHdr));
        DEBUG_PRINT(DEBUG_MOC_IPV4, ", Sequence Number = ");
        DEBUG_UINT(DEBUG_MOC_IPV4, TCP_GET_SEQ_NUM(pxTcpHdr));
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }

      lReturn = 1;
    }

  } else {

    /*
     * LAN -> WAN (Upstream)
     */

    DWORD dwOriginalSeqNum = TCP_GET_SEQ_NUM(pxTcpHdr);
    DWORD dwPayloadOffset = pxNetPacketAccess->wOffset + TCP_GET_HEADER_LEN(pxTcpHdr);
    DWORD dwPayloadSize = pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen - TCP_GET_HEADER_LEN(pxTcpHdr);

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
    {
      /*NAT_DBGP(DBGLVL_REPETITIVE, "Old payload size = %d\n",
        (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen - TCP_GET_HEADER_LEN(pxTcpHdr)));*/
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "Old payload size = ");
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }


    /*
     * Perform substitution and get change in payload size (if any)
     */
    lReturn = ProcessFTPPacket(pxNat,
                               pxNetPacket,
                               pxNetPacketAccess,
                               hData,
                               dwPayloadOffset,
                               dwPayloadSize,
                               pxNatEntry->dwTransAddr,
                               pxNatEntry->u.xTUMapping.wTransPort,
                               &sDeltaLength);
    if (lReturn < 0) {
      return (lReturn);
    }

    /*
     * Update upstream TCP sequence numbers
     */
    if (pxNatEntry->u.xTUMapping.lUpstreamSeqDelta || sDeltaLength) {
      pxTcpHdr = (TCPHDR*) (pxNetPacket->pxPayload->poPayload + pxNetPacketAccess->wOffset);
      ASSERT(((DWORD) pxTcpHdr & 0x3) == 0);

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "L2W - TCP Sequence number changed from %lu to ", TCP_GET_SEQ_NUM(pxTcpHdr));*/
        DEBUG_PRINT(DEBUG_MOC_IPV4, "L2W - TCP Sequence number changed from ");
        DEBUG_UINT(DEBUG_MOC_IPV4, TCP_GET_SEQ_NUM(pxTcpHdr));
        DEBUG_PRINT(DEBUG_MOC_IPV4, " to ");
      }

      TCP_SET_SEQ_NUM(pxTcpHdr, (TCP_GET_SEQ_NUM(pxTcpHdr) + pxNatEntry->u.xTUMapping.lUpstreamSeqDelta));

      if ((dwOriginalSeqNum <= pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum) ||
          (pxNatEntry->u.xTUMapping.lUpstreamSeqDelta &&
           ((dwOriginalSeqNum -
             pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum) > (1 << 16)) /* Assume wraparound */)) {

        /*
         * This looks like a retransmission of a packet that occurred before
         * the last FTP packet that required a payload modification. Therefore
         * use the previous delta value. This should also catch retransmissions
         * of the packet which required payload mods
         */
        TCP_SET_SEQ_NUM(pxTcpHdr, (TCP_GET_SEQ_NUM(pxTcpHdr) - pxNatEntry->u.xTUMapping.sLastPayloadModifiedDelta));

        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
        {
          /*NAT_DBGP(DBGLVL_REPETITIVE, "(retransmission) ");*/
          DEBUG_PRINT(DEBUG_MOC_IPV4, "(retransmission) ");
        }

      } else {

        if (lReturn && sDeltaLength) {
          /*
           * The payload was modified and the length changed
           */
          pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum = dwOriginalSeqNum;
          pxNatEntry->u.xTUMapping.sLastPayloadModifiedDelta = sDeltaLength;
          pxNatEntry->u.xTUMapping.lUpstreamSeqDelta += sDeltaLength;
        }
      }

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
      {
        /*NAT_DBGP(DBGLVL_REPETITIVE, "%lu, New payload size = %d\n", TCP_GET_SEQ_NUM(pxTcpHdr),
          (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen - TCP_GET_HEADER_LEN(pxTcpHdr)));*/
        DEBUG_UINT(DEBUG_MOC_IPV4, TCP_GET_SEQ_NUM(pxTcpHdr));
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", New payload size = ", (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen - TCP_GET_HEADER_LEN(pxTcpHdr)));
      }

      lReturn = 1;
    }
  }

  return (lReturn);
}
