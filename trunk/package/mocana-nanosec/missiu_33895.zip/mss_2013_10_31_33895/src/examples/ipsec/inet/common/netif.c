/*
 * netif.c
 *
 * interface management
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "snmp_tcpip_data.h"
#include "../include/if_types.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "netdbg.h"
#include "ethernet.h"
#include "arp.h"
#include "ip1ton.h"
#include "netdefs.h"
#include "netconfig.h"
#include "netmain.h"
#include "linkconf.h"
#include "iptable.h"

#define ARPMAX_IFNUM            NUM_IFS
#include "arpdefs.h"

#ifdef ETHERNET
  #include "ethconf.h"
  #include "ethlink.h"
#endif /*#ifdef ETHERNET*/

#ifdef PPP
  #include "ppp.h"
  #include "pppoeconf.h"
  #include "pppconf.h"
  #include "pppoecommon.h"
#endif /*#ifdef PPP*/

#ifdef NET_DSL
  #include "mpoaconf.h"
  #include "mpoa.h"
  #include "adslmgr.h"
#endif /*#ifdef NET_DSL*/

#include "netif.h"
#include "netsnmp.h"
#include "routing_table.h"
#include "dhcpclient.h"
#include "dnsapi.h"
#include "sockapi.h"

#ifdef ROUTER
  #include "router.h"
#endif

#ifdef IPSEC
  #include "ipsec.h"
#if 0
/* IPSEC is not configed by us */
  #include "ipsec_api.h"
#endif
#endif /*#ifdef IPSEC*/

#ifdef IPFRAG
  #include "ipfrag.h"
#endif /*#ifdef IPFRAG*/

#ifdef NAT
  #include "nat.h"
#endif /*#ifdef NAT*/



/****************************************************************************
 *
 * Debug
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Implementation
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Local function
 *
 ****************************************************************************/
#ifdef LINK_AGGREGATION
LONG NetLIfNewActivePhy(OCTET oLIfIdx)
{
    LONG lReturn = 0;
    NETIFCONF *pxLIfConf;
    NETIFSTATE *pxLIfState;
    NETIFCONF *pxIfConf;
    NETIFSTATE *pxIfState;
    int i;
    LONG lTemp;

    pxLIfConf = NETGETIFCONF(&xNetWrapper, oLIfIdx);
    pxLIfState = NETGETIFSTATE(pxLIfConf);
    if ( pxLIfState == NULL || pxLIfState->eStatus != NETIFSTATUS_OPENED )
    return 0;

    if ( pxLIfConf->iActivePhyLinkIfIdx >= 0 ){
       pxIfConf = NETGETIFCONF(&xNetWrapper, pxLIfConf->iActivePhyLinkIfIdx);
       pxIfState = NETGETIFSTATE(pxIfConf);
       if ( pxIfState && pxIfState->eStatus == NETIFSTATUS_OPENED &&
            pxIfConf->oFlags & IFF_UP && pxIfConf->oFlags & IFF_PHYUP ){
            /* If Logical and Physical is not the same ifIdx  */
            if (pxLIfConf->iActivePhyLinkIfIdx != oLIfIdx) {
                lReturn = NetIfPhyStatusUs(&xNetWrapper,
                            pxLIfConf->iActivePhyLinkIfIdx);
                if ( lReturn ) return lReturn;
            }
            else {
                /* Logical and Physical is same ifIdx and it is UP. */
                return 1;
            }
       }
    }

    /* Check if any other Physical can be promoted to Active PhyStatus */
    for(i=0; i < IFNUMMAX; i++){
    if ( pxLIfConf->oPhyLinks[i] ){
           pxIfConf = NETGETIFCONF(&xNetWrapper, i);
           NETMAIN_ASSERT(pxIfConf != NULL);
           pxIfState = NETGETIFSTATE(pxIfConf);
           NETMAIN_ASSERT(pxIfState != NULL);
#if 0
           /* If logical and physical use the same ifIndex */
           if (i == oLIfIdx) {
              pxLIfConf->iActivePhyLinkIfIdx = i;
              return 1;
           } else
#endif
           if ( pxIfState && pxIfState->eStatus == NETIFSTATUS_OPENED &&
                pxIfConf->oFlags & IFF_UP && pxIfConf->oFlags & IFF_PHYUP )
              {
              /* lReturn = NetIfPhyStatusUs(&xNetWrapper, i);
              if ( lReturn ){
              */
                   /* NETMAIN_DBGP(NORMAL,
                                        "NetLIfNewActivePhy:oLIfIdx = %d, oPIfIdx: %d\n", oLIfIdx,i); */
                 if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN,
                                           INET_DBG_LEVEL_NORMAL))
                 {
                      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,
                                            "NetLIfNewActivePhy:oLIfIdx = ",oLIfIdx,
                                            ", oPIfIdx: ", i);
                      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
                 }
                 pxLIfConf->iActivePhyLinkIfIdx = i;
              /*
                 return lReturn;
              }
              */
              return 1;
           }
        }
    }

    /* if we are here, no active phy links */
    pxLIfConf->iActivePhyLinkIfIdx = -1;
    /* NETMAIN_DBGP(NORMAL, "NetLIfNewActivePhy: oLIfIdx = %d, oPIfIdx: -1\n",
                 oLIfIdx); */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,
                              "NetLIfNewActivePhy:oLIfIdx = ",oLIfIdx);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, ", oPIfIdx: -1");
    }

    return 0;
}

LONG NetIfAggr(NETWRAPPER *pxWrapper, int add, NETIFAGGR *aggr)
{
    NETIFCONF *pxLIfConf;
    NETIFSTATE *pxLIfState;
    NETIFCONF *pxIfConf;
    NETIFSTATE *pxIfState;

    pxLIfConf = NETGETIFCONF(&xNetWrapper, aggr->oLIfIdx);
    NETMAIN_ASSERT(pxLIfConf != NULL);

    pxIfConf = NETGETIFCONF(&xNetWrapper, aggr->oPIfIdx);
    NETMAIN_ASSERT(pxIfConf != NULL);

    if (add) {
/** Atul
       if ( pxIfConf->iLogicalLinkIfIdx >= 0 &&
            pxIfConf->iLogicalLinkIfIdx != aggr->oLIfIdx)
**/
       if ( pxIfConf->iLogicalLinkIfIdx >= 0)
            /* physical still associated with some other logical*/
            return -1;
       if ( pxLIfConf->oPhyLinks[aggr->oPIfIdx] )
            /* logical already associated with this physical */
            return -1;
       pxIfConf->iLogicalLinkIfIdx    = aggr->oLIfIdx;
       pxLIfConf->oPhyLinks[aggr->oPIfIdx]    = 1;
       /* Initialize ActivePhyLinkIfIdx to be the same as Logical Link index */
       if(pxLIfConf->iActivePhyLinkIfIdx < 0)  /*Atul*/
           pxLIfConf->iActivePhyLinkIfIdx = aggr->oLIfIdx;
   }else{
       if (pxIfConf->iLogicalLinkIfIdx != aggr->oLIfIdx)
            /* physical not associated with this logical*/
            return -1;
       if ( ! pxLIfConf->oPhyLinks[aggr->oPIfIdx] )
            /* logical not associated with this physical */
            return -1;
       pxIfConf->iLogicalLinkIfIdx        = -1;
       pxLIfConf->oPhyLinks[aggr->oPIfIdx]    = 0;
   }

   NetLIfNewActivePhy(aggr->oLIfIdx);
}
#endif

/*
 * NetIfPhyStatusUs
 *  Query the interface Phy upstream status and bitrate
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *    0 == link down, >0 == bitrate (Kbits/sec)
 */
LONG NetIfPhyStatusUs(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
  NETWRAPPERSTATE *pxWrapperState;
  NETIFCONF *pxIfConf;
  LONG lReturn = 0;
  LONG lTemp;

  pxWrapperState = NETGETWRAPPERSTATE(&xNetWrapper);
  pxIfConf = NETGETIFCONF(&xNetWrapper,oIfIdx);

#ifdef NET_DSL
  if (pxIfConf->ePhyLinkType == ATM) {
    #if 0
      lReturn = 832;
    #else
    if (pxWrapperState->oAtmUp) {
      lReturn = (DWORD)ADSLGetStat(ADSLSTAT_US_BITRATE);
    }
    #endif
  }
  else
#endif
#ifdef LINK_AGGREGATION
    if ( pxIfConf->oFlags & IFF_LOGICAL ){
      lReturn = NetLIfNewActivePhy(oIfIdx);
      return lReturn;
      /*if ( lReturn ){
        pxIfConf = NETGETIFCONF(&xNetWrapper, pxIfConf->iActivePhyLinkIfIdx);
      } */
    } else {
         return 1;
        /* Return status of Physical interface. */
    }
#else
      /* Query the driver */
      lTemp = ioctl(pxIfConf->iFd,ETHERDRV_LINK_CHECK);
      if (lTemp & LINK_UP) {
        lReturn = (lTemp & LINK_100_MBPS) ? 100000 : 10000;
      }
#endif
  return lReturn;
}


/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * NetIfSetup
 *  Sets up an interface. The type must be a valid one
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Wrapper
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   0
 */
LONG NetIfSetup(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
  NETWRAPPERSTATE *pxWrapperState;
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;

  NETMAIN_ASSERT(pxWrapper != NULL);

  /* NETMAIN_DBGP(NORMAL,"NetIfSetup:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfSetup:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  pxIfConf = NETGETIFCONF(pxWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState = NETGETIFSTATE(pxIfConf);

  /* Early checks */
  if (pxIfState != NULL) {
    /* Already set up, obviously */
    NETMAIN_ASSERT(0);
    return -1;
  }

  pxWrapperState = NETGETWRAPPERSTATE(pxWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL);

  /* Allocate the If state */
  pxIfState = (NETIFSTATE *) MALLOC(sizeof(NETIFSTATE));
  NETMAIN_ASSERT(pxIfState != NULL);
  MOC_MEMSET((ubyte *)pxIfState, 0, sizeof(NETIFSTATE));

  NETSETIFSTATE(pxIfConf,pxIfState);

#ifdef LINK_AGGREGATION
/*pxIfConf can contain static configuration of aggregate links.
  pxIfConf->iActivePhyLinkIfIdx = -1;
  pxIfConf->iLogicalLinkIfIdx = -1;
*/
  if ( pxIfConf->oFlags & IFF_LOGICAL ){
  /*pxIfConf->oPhyLinks = calloc(IFNUMMAX, sizeof(pxIfConf->oPhyLinks[0]));  */
#endif
  /* Allocate IpAlias */
  if(pxIfConf->pxIPAlias == NULL){
    pxIfConf->pxIPAlias = (IPCONF*)MALLOC(sizeof(IPCONF));
    MOC_MEMSET((ubyte *)(pxIfConf->pxIPAlias), 0, sizeof(IPCONF));
    pxIfConf->oIPAliasNumber = 1;
  }

#ifdef LINK_AGGREGATION
  } /* if logical */
#endif

#if 0
  /* Don't see static configuration for oIfIdx = 0 */
  /* Set physical link type */
  if(oIfIdx == 0){
    pxIfConf->ePhyLinkType = ETH;
  }
#endif
#ifdef MHX
  if(oIfIdx == 1){
    pxIfConf->ePhyLinkType = ETH;
  }
#endif /*#ifdef MHX*/
#ifdef NET_DSL
  if(oIfIdx >= 1){
    pxIfConf->ePhyLinkType = ATM;
  }
#endif /*#ifdef NET_DSL*/

  NETMAIN_ASSERT((pxIfConf->oType == IFT_ETHER) ||
         (pxIfConf->oType == IFT_PPPOE) ||
         (pxIfConf->oType == IFT_PPP) ||
         (pxIfConf->oType == IFT_NULL));

  NETMAIN_ASSERT((pxIfConf->ePhyLinkType == ETH) ||
         (pxIfConf->ePhyLinkType == ATM));

  /*
   * Set L3TrailerLength, L3AddrLength, Mtu, Ltu and Vlan;
   */
  if(pxIfConf->ePhyLinkType == ETH){

    pxIfConf->oL3TrailerLength = 0;

    if(pxIfConf->oType == IFT_ETHER){
      pxIfConf->oL3AddrLength = ETHHEADER_LEN + ETHVLAN_LEN;
      /* pxIfConf->wMtu = ETHDATA_LEN; */ /* The MTU is set in MN_NDI_attachToIP() */
    }
#ifdef PPP
    else if(pxIfConf->oType == IFT_PPPOE){
      pxIfConf->oL3AddrLength = ETHHEADER_LEN + PPPDEFAULT_HDRLEN + PPPOE_HDRLEN + ETHVLAN_LEN;
      pxIfConf->wMtu = ETHDATA_LEN - PPPDEFAULT_HDRLEN - PPPOE_HDRLEN;
    }
#endif
  }
#ifdef NET_DSL
  else if(pxIfConf->ePhyLinkType == ATM){

    pxIfConf->oL3TrailerLength = 48 + 8 /* CPCS trailer */;

    if(pxIfConf->oType == IFT_ETHER){
      pxIfConf->oL3AddrLength = ETHOA_LEN + ETHHEADER_LEN + ETHVLAN_LEN;
      pxIfConf->wMtu = ETHDATA_LEN;
    }
#ifdef IPOA
    else if(pxIfConf->oType == IFT_NULL){
      pxIfConf->oL3AddrLength = ETHOA_LEN;
      pxIfConf->wMtu = ETHDATA_LEN;
    }
#endif /*#ifdef IPOA*/
#ifdef PPP
    else if(pxIfConf->oType == IFT_PPPOE){
      pxIfConf->oL3AddrLength = ETHOA_LEN + ETHHEADER_LEN + PPPDEFAULT_HDRLEN + PPPOE_HDRLEN + ETHVLAN_LEN;
      pxIfConf->wMtu = ETHDATA_LEN - PPPDEFAULT_HDRLEN - PPPOE_HDRLEN;
    } else if(pxIfConf->oType == IFT_PPP){
      pxIfConf->oL3AddrLength = ETHOA_LEN + ETHHEADER_LEN + PPPDEFAULT_HDRLEN;
      pxIfConf->wMtu = ETHDATA_LEN;
    }
#endif /*#ifdef PPP*/
  }
#endif /*#ifdef NET_DSL*/

  /* oL3AddrLength must be at least equal to the ethernet oL3AddrLength,
     it is used to forward packet without reallocing memory */
  if(pxIfConf->oL3AddrLength < (ETHHEADER_LEN + ETHVLAN_LEN)){
    pxIfConf->oL3AddrLength = ETHHEADER_LEN + ETHVLAN_LEN;
  }

  /* Adjust the offset to be int aligned */
  pxIfConf->oL3AddrLength = (pxIfConf->oL3AddrLength + sizeof(int) - 1) & ~(sizeof(int) - 1);
  NETMAIN_ASSERT( (pxIfConf->oL3AddrLength % sizeof(int)) == 0);

  pxIfConf->wLtu = ETH_MINLEN;

#ifdef LINK_AGGREGATION
  /* setup upper layer conf only for logicals */
  if ( pxIfConf->oFlags & IFF_LOGICAL ) {
#endif
  /*
   * Type specific setup
   */
  switch(pxIfConf->oType) {

#ifdef ETHERNET
  case IFT_ETHER:
    /* ethernet link */
    EthConfSetup(pxIfConf,oIfIdx);
    /* SB Feb-2002 No need for trailer yet */
    break;
#endif /*#ifdef ETHERNET*/

#ifdef PPP
  case IFT_PPPOE:
    /* PppoE link */
    PppoEConfSetup(pxIfConf,oIfIdx);
  case IFT_PPP:
    PppConfSetup(pxIfConf,oIfIdx);
    break;
#ifdef IPOA
  case IFT_NULL:
    IpoAConfSetup(pxIfConf,oIfIdx);
    break;
#endif /*#ifdef IPOA*/
#endif /*#ifdef PPP*/
  default:
    /* Check is done at the socket layer: should not happen */
    NETMAIN_ASSERT(0);
  }
#ifdef LINK_AGGREGATION
  } /* if logical */
#endif

#if 0
/*    Every Logical has at least one Phy and
      one oIfIdx can be both logical and Physical.
*/
#ifdef LINK_AGGREGATION
  /* setup driver layer conf only for physicals */
  if ( ! (pxIfConf->oFlags & IFF_LOGICAL) ) {
#endif
#endif

  /* Physical link specific setup */
  switch(pxIfConf->ePhyLinkType) {

#ifdef ETHERNET
  case ETH:
    /* ethernet link */
    EthLinkSetup(pxIfConf,oIfIdx);
    /* SB Feb-2002 No need for trailer yet */
    break;
#endif /*#ifdef ETHERNET*/
#ifdef NET_DSL
  case ATM:
    MpoaLinkSetup(pxIfConf,oIfIdx);
    break;
#endif
  default:
    /* Check is done at the socket layer: should not happen */
    NETMAIN_ASSERT(0);
  }
#if 0
#ifdef LINK_AGGREGATION
  } /* if physical */
#endif
#endif

#ifdef LINK_AGGREGATION
  /* setup upper layer conf only for logicals */
  if ( pxIfConf->oFlags & IFF_LOGICAL ) {
#endif

#ifdef ROUTER
  /*
   * Inform the router about the MTU of the interface
   */
  {
    ROUTERSETIFMTU xRouterSetIfMtu;
    H_NETINSTANCE hRouterInst = NETGETINST_ROUTER;

    xRouterSetIfMtu.oIfIdx = oIfIdx;
    xRouterSetIfMtu.wMtu   = pxWrapper->pxIfConf[oIfIdx].wMtu;
    (LONG)RouterInstanceMsg(hRouterInst, ROUTERMSG_SETIFMTU, (H_NETDATA)&xRouterSetIfMtu);
  }
#endif

#ifdef NAT
    /*
     *    * Inform NAT about the MTU of the interface
     */
  {
    NATSETIFMTU xNatSetIfMtu = {oIfIdx,pxWrapper->pxIfConf[oIfIdx].wMtu};
    H_NETINSTANCE hRouterInst = NETGETINST_NAT;
   (LONG)NatInstanceMsg(hRouterInst, NATMSG_SETIFMTU, (H_NETDATA)&xNatSetIfMtu);
  }
#endif

#ifdef IPFRAG
  {
    MTUREQUEST xMtuRequest;
    H_NETINSTANCE hIpFragInst = NETGETINST_IPFRAG;

    xMtuRequest.oIfIndex = oIfIdx;
    xMtuRequest.wMtu     = pxWrapper->pxIfConf[oIfIdx].wMtu;
    (LONG)IpFragInstanceSet(hIpFragInst,IPFRAGOPTION_MTU,(H_NETDATA)&xMtuRequest);
  }
#endif /*#ifdef IPFRAG*/

  /*
   *  Plumbing
   */
  if(pxIfConf->ePhyLinkType == ETH){
    if(pxIfConf->oType == IFT_ETHER){
      /* Do nothing */
    }
#ifdef PPP
    else if(pxIfConf->oType == IFT_PPPOE){
      PppoEPlumbing(pxIfConf);
    }
#endif
  }
#ifdef NET_DSL
  else if(pxIfConf->ePhyLinkType == ATM){
    if(pxIfConf->oType == IFT_ETHER){
      EthoAPlumbing(pxIfConf);
    }
#ifdef IPOA
    else if(pxIfConf->oType == IFT_NULL){
      IpoAPlumbing(pxIfConf);
    }
#endif /*#ifdef IPOA*/
#ifdef PPP
    else if(pxIfConf->oType == IFT_PPPOE){
      PppoEoAPlumbing(pxIfConf);
    }
    else if(pxIfConf->oType == IFT_PPP){
      PppoAPlumbing(pxIfConf);
    }
#endif /*#ifdef PPP*/
  }
#endif /*#ifdef NET_DSL*/

  /* Create & configure bottom network interface: ip1ton */
  pxIfState->hNetIf =
    Ip1toNInstanceLLInterfaceCreate(pxWrapperState->hNetBottomInst);

  Ip1toNInstanceLLInterfaceIoctl(pxWrapperState->hNetBottomInst,
                                 pxIfState->hNetIf,
                                 IP1TONLLINTERFACEIOCTL_SETIFIDX,
                                 oIfIdx);

  Ip1toNInstanceLLInterfaceIoctl(pxWrapperState->hNetBottomInst,
                                 pxIfState->hNetIf,
                                 NETINTERFACEIOCTL_SETHINST,
                                 (H_NETDATA)pxIfState->hTopLinkInst);

  Ip1toNInstanceLLInterfaceIoctl(pxWrapperState->hNetBottomInst,
                                 pxIfState->hNetIf,
                                 NETINTERFACEIOCTL_SETIF,
                                 pxIfState->hTopLinkIf);

  Ip1toNInstanceLLInterfaceIoctl(pxWrapperState->hNetBottomInst,
                                 pxIfState->hNetIf,
                                 NETINTERFACEIOCTL_SETOUTPUTPFN,
                                 (H_NETDATA)
                                 pxIfState->pfnTopLinkWrite);

  /* Top link configuration */
  NETMAIN_ASSERT(pxIfState->pfnTopLinkUlIfIoctl != NULL);

  pxIfState->pfnTopLinkUlIfIoctl(pxIfState->hTopLinkInst,pxIfState->hTopLinkIf,
                               NETINTERFACEIOCTL_SETHINST,
                               (H_NETDATA)pxWrapperState->hNetBottomInst);

  pxIfState->pfnTopLinkUlIfIoctl(pxIfState->hTopLinkInst,pxIfState->hTopLinkIf,
                               NETINTERFACEIOCTL_SETIF,
                               (H_NETDATA)pxIfState->hNetIf);

  pxIfState->pfnTopLinkUlIfIoctl(pxIfState->hTopLinkInst,pxIfState->hTopLinkIf,
                               NETINTERFACEIOCTL_SETOUTPUTPFN,
                               (H_NETDATA)
                               Ip1toNInstanceRcv);
  /* Bottom link configuration */
  NETMAIN_ASSERT(pxIfState->pfnBottomLinkLlIfIoctl != NULL);

#if 0
  pxIfState->pfnBottomLinkLlIfIoctl(pxIfState->hBottomLinkInst,
                                  pxIfState->hBottomLinkIf,
                                  NETINTERFACEIOCTL_SETHINST,
                                  (H_NETDATA)pxIfConf->iFd);
#endif
  pxIfState->pfnBottomLinkLlIfIoctl(pxIfState->hBottomLinkInst,
                                  pxIfState->hBottomLinkIf,
                                  NETINTERFACEIOCTL_SETIF,
                                  (H_NETDATA)oIfIdx);

  pxIfState->pfnBottomLinkLlIfIoctl(pxIfState->hBottomLinkInst,
                                  pxIfState->hBottomLinkIf,
                                  NETINTERFACEIOCTL_SETOUTPUTPFN,
                                  (H_NETDATA)NetIfDriverWrite);
#ifdef LINK_AGGREGATION
  } /* if logical */
#endif

  pxIfState->eStatus = NETIFSTATUS_SETUP;

  return 0;
}

/*
 * NetIfOpen
 *  Open an interface. Set it up if it has not been set
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper                Network wrapper pointer
 *   oIfIdx                   Interface index
 *
 *  Return:
 *   >=0 on success
 */
LONG NetIfOpen(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
  NETWRAPPERSTATE *pxWrapperState;
  NETIFSTATE *pxIfState;
  NETIFCONF *pxIfConf;

  NETMAIN_ASSERT(pxWrapper != NULL);

  /* NETMAIN_DBGP(NORMAL,"NetIfOpen:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfOpen:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  pxIfConf = NETGETIFCONF(pxWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxWrapperState = NETGETWRAPPERSTATE(pxWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL);

  pxIfState = NETGETIFSTATE(pxIfConf);

  /* If the interface is not set up, do it. */
  if ((pxIfState == NULL) || (pxIfState->eStatus == NETIFSTATUS_INIT)) {
    if (NetIfSetup(pxWrapper,oIfIdx) < 0) {
      NETMAIN_ASSERT(0);
      return NETERR_UNKNOWN;
    }
  }

  pxIfState = NETGETIFSTATE(pxIfConf);

  if (pxIfState->eStatus == NETIFSTATUS_OPENED) {
    /* Already open: return */
    return NETERR_NOERR;
  }

  NETMAIN_ASSERT(pxIfState->eStatus == NETIFSTATUS_SETUP);

  NETIF_SETFLAG(pxIfConf->oFlags,IFF_UP);

  init_DLLIST(&pxIfConf->dllRxBuf);
  init_DLLIST(&pxIfConf->dllNetPacketRx);

  CIRCQ_init(&pxIfConf->pRxCq, 20000);

  init_DLLIST(&pxIfConf->dllTxBuf);
  DLLIST_append(&(pxIfConf->dllTxBuf),(void *) &(pxIfConf->xndbTxPacket));

#ifndef __LOCK_OPT_ON__
  RTOS_mutexCreate(&pxIfConf->xMutex,0,1);
#endif

#ifdef PPP
  if (pxIfConf->oType == IFT_PPP || pxIfConf->oType == IFT_PPPOE) {
    pxIfConf->oFlags |= (IFF_PP | IFF_DYNAMIC);
  } else {
    pxIfConf->oFlags &= ~IFF_PP;
  }
#endif

#ifdef LINK_AGGREGATION
  /* setup upper layer conf only for logicals */
  if ( pxIfConf->oFlags & IFF_LOGICAL ) {
#endif

  /* If type specific opening calls */
#ifdef NET_DSL
  if (pxIfConf->ePhyLinkType == ATM) {
    MpoaAtmConfOpen(pxIfConf,oIfIdx); /* Not up immediately */
  }
#endif
#ifdef ETHERNET
  if (pxIfConf->oType == IFT_ETHER) {
    if (pxIfConf->oFlags & IFF_DYNAMIC) {
      NETMAIN_ASSERT(pxIfConf->hDhcpClient == 0);
      pxIfConf->hDhcpClient = DHCPClientInstanceCreate();
      pxIfConf->dwDhcpClientProcessTimer = 1;
      DHCPClientInstanceMsg(pxIfConf->hDhcpClient,
                            DHCPCLIENTMSG_ENABLE,
                            oIfIdx);
    }
  }
#endif /*#ifdef ETHERNET*/
#ifndef LINK_AGGREGATION /* for Logicals, driver Fd is not inited */
  NETMAIN_ASSERT(pxIfConf->iFd > 0);
#endif
  /* Moved from the LinkSetup as only known after open  */
  pxIfState->pfnBottomLinkLlIfIoctl(pxIfState->hBottomLinkInst,
                                    pxIfState->hBottomLinkIf,
                                    NETINTERFACEIOCTL_SETHINST,
                                    (H_NETDATA)pxIfConf->iFd);

  /*
   *  Open the corresponding network index
   */
  Ip1toNInstanceLLInterfaceIoctl(pxWrapperState->hNetBottomInst,
                                 pxIfState->hNetIf,
                                 NETINTERFACEIOCTL_OPEN,(H_NETDATA)0);
#ifdef LINK_AGGREGATION
  } /* if logical */
#endif

  pxIfState->eStatus = NETIFSTATUS_OPENED;

#if 0
  /* Is the Phy up ? */
  if (NetIfPhyStatusUs(pxWrapper,oIfIdx) > 0) {
    NetIfPhyUp(pxWrapper,oIfIdx);
  }
#else
    NetIfPhyUp(pxWrapper,oIfIdx);
#endif

  if(pxIfConf->pxIPAlias[0].dwAddr != 0){
    NetIfIpUp(pxWrapper,oIfIdx);
  }

  return 0;
}


/*
 * NetIfEnableNetworkServices
 *  Enable Network layer services (DNS) on an interface
 *  Must only be called if Phy, Link and Net layers are up
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfEnableNetworkServices(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
#ifdef _ENABLE_DNS_
  DnsMsg(DNSMSG_IFENABLE,oIfIdx);
#endif /* _ENABLE_DNS_ */

/*#ifdef IPSEC */
#if 0
/* IPSEC is not configed by us */
  {
    /* Whenever IP address is set to one of the interface,
       IPSec security policies associated with that interface,
       or security policies not associated with valid interface yet,
       need to be reconfigured */
    NETIFCONF *pxIfConf;
    DWORD dwIF0IP=0;    /* IP address for interface 0 */
    DWORD dwIfWanIP=0;    /* WAN IP address for oIfIdx */

    pxIfConf = NETGETIFCONF(pxWrapper,0);
    dwIF0IP = pxIfConf->pxIPAlias->dwAddr;

    pxIfConf = NETGETIFCONF(pxWrapper,oIfIdx);
    dwIfWanIP = pxIfConf->pxIPAlias->dwAddr;

    /* Find Security policy associated with this I/F index or
       interface 0, set local WAN IP address when routing table
       use this I/F to reach the secury destination */
    if (dwIfWanIP) {
      IPSecSadbFindNSetWanIP(oIfIdx, dwIF0IP, dwIfWanIP);
    }
  }
#endif /* if IPSEC */
  return 0;
}

/*
 * NetIfDisableNetworkServices
 *  Disable Network layer services (DNS) on an interface
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfDisableNetworkServices(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
#ifdef _ENABLE_DNS_
  DnsMsg(DNSMSG_IFDISABLE,oIfIdx);
#endif /* _ENABLE_DNS_ */

/*#ifdef IPSEC */
#if 0
/* IPSEC is not configed by us */
  /* Find Security policy associated with this I/F index, and
     reset interface index setting on the security policy. */
  IPSecSadbFindNResetRoute(oIfIdx);
#endif /* if IPSEC */

  return 0;
}

/*
 * NetIfPhyUp
 *  Signal the interface that the phy is up
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfPhyUp(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
  NETIFCONF *pxIfConf;
  NETIFSTATE *pxIfState;

  pxIfConf = NETGETIFCONF(pxWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  /* NETMAIN_DBGP(NORMAL,"NetIfPhyUp:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfPhyUp:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  if (pxIfState->eStatus != NETIFSTATUS_OPENED) {
    return NETERR_UNKNOWN;
  }

  NETIF_SETFLAG(pxIfConf->oFlags,IFF_PHYUP);

#ifdef LINK_AGGREGATION
  /* setup upper layer conf only for logicals */
  /* This will happen only for oIfIdx which is physical and logical */
  if ( pxIfConf->oFlags & IFF_LOGICAL ) {
#endif

#ifdef NET_DSL
  if (ATM == pxIfConf->ePhyLinkType) {
    MpoaInstanceLLInterfaceIoctl(NETGETINST_MPOA(pxIfState),
                                 NETGETIF_MPOALL(pxIfState),
                                 NETINTERFACEIOCTL_OPEN,
                                 (H_NETDATA)NULL);
  }
#endif

  switch(pxIfConf->oType) {
#ifdef ETHERNET
  case IFT_ETHER:
    /* Open all link modules & interfaces */
    EthConfOpen(pxIfConf,oIfIdx);
    break;
#endif
#ifdef PPP
  case IFT_PPPOE:
    PppoEConfOpen(pxIfConf,oIfIdx);
  case IFT_PPP:
    PppConfOpen(pxIfConf,oIfIdx);
    break;
#endif /*#ifdef PPP*/
#ifdef IPOA
  case IFT_NULL:
    IpoAConfOpen(pxIfConf,oIfIdx);
    break;
#endif
  default:
    /* can't happen */
    ASSERT(0);
  }

  { /* RS added link status in routing table */
    ROUTERSETLINKSTATUS xLinkStatus;

    xLinkStatus.oIfIdx    = oIfIdx;
    xLinkStatus.bIsLinkUp = TRUE;
    RoutingTableMsg(ROUTINGTABLEMSG_SETLINKSTATUS,(H_NETDATA)&(xLinkStatus));
  }
#ifdef ROUTER
  {
    H_NETINSTANCE hRouter = NETGETINST_ROUTER;
    ROUTERSETLINKSTATUS xLinkStatus;

    xLinkStatus.oIfIdx    = oIfIdx;
    xLinkStatus.bIsLinkUp = TRUE;
    RouterInstanceMsg(hRouter,ROUTERMSG_SETLINKSTATUS,(H_NETDATA)&(xLinkStatus));
  }
#endif /*#ifdef ROUTER*/

#ifdef LINK_AGGREGATION
  } /* if logical */
  else{
    /* turn corresponding logical up */
    /* only if it is down */
    if ( pxIfConf->iLogicalLinkIfIdx >= 0 ) {
        NETIFCONF *pxLIfConf;
        NETIFSTATE *pxLIfState;

        pxLIfConf = NETGETIFCONF(pxWrapper,pxIfConf->iLogicalLinkIfIdx);
        NETMAIN_ASSERT(pxLIfConf != NULL);

        pxLIfState = NETGETIFSTATE(pxLIfConf);
        NETMAIN_ASSERT(pxLIfState != NULL);

        if ((pxLIfConf->oFlags & IFF_IPUP) == 0)
            NetIfLogicalUp(pxWrapper, pxIfConf->iLogicalLinkIfIdx);
    }
  }
#endif

  SNMP(xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifOperStatus = 2;);

  NetIfSignalOpen(pxWrapper,oIfIdx);

  if (pxWrapper->pfnIfLinkStatusCbk) {
    (pxWrapper->pfnIfLinkStatusCbk)(oIfIdx, 1);
  }

  return NETERR_NOERR;
}

/*
 * NetIfPhyDown
 *  Signal the interface that the phy is down
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfPhyDown(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
  NETIFCONF *pxIfConf = NETGETIFCONF(pxWrapper,oIfIdx);
  NETIFSTATE *pxIfState;

  /* NETMAIN_DBGP(NORMAL,"NetIfPhyDown:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfPhyDown:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  pxIfState = NETGETIFSTATE(pxIfConf);

  if (pxIfState->eStatus != NETIFSTATUS_OPENED) {
    return NETERR_UNKNOWN;
  }

#ifdef LINK_AGGREGATION
  /* setup upper layer conf only for logicals */
  /* In this case Logical and active phy is same */
  if ( pxIfConf->oFlags & IFF_LOGICAL ) {
#endif

#ifdef NET_DSL
  if (ATM == pxIfConf->ePhyLinkType) {
    MpoaInstanceLLInterfaceIoctl(NETGETINST_MPOA(pxIfState),
                                 NETGETIF_MPOALL(pxIfState),
                                 NETINTERFACEIOCTL_CLOSE,
                                 (H_NETDATA)NULL);
  }
#endif

  switch(pxIfConf->oType) {
#ifdef ETHERNET
  case IFT_ETHER:
    EthConfClose(pxIfConf,oIfIdx);
    break;
#endif
#ifdef PPP
  case IFT_PPPOE:
    PppoEConfClose(pxIfConf,oIfIdx);
  case IFT_PPP:
    PppConfClose(pxIfConf,oIfIdx);
    break;
#endif /*#ifdef PPP*/
#ifdef IPOA
  case IFT_NULL:
    IpoAConfClose(pxIfConf,oIfIdx);
    break;
#endif /*#ifdef IPOA*/
  default:
    /* can't happen */
    ASSERT(0);
  }

  { /* RS added link status in routing table */
    ROUTINGTABLESETLINKSTATUS xLinkStatus;

    xLinkStatus.oIfIdx    = oIfIdx;
    xLinkStatus.bIsLinkUp = FALSE;
    RoutingTableMsg(ROUTINGTABLEMSG_SETLINKSTATUS,(H_NETDATA)&xLinkStatus);
  }
#ifdef ROUTER
  {
    H_NETINSTANCE hRouter = NETGETINST_ROUTER;
    ROUTINGTABLESETLINKSTATUS xLinkStatus;

    xLinkStatus.oIfIdx    = oIfIdx;
    xLinkStatus.bIsLinkUp = FALSE;
    RouterInstanceMsg(hRouter,ROUTERMSG_SETLINKSTATUS,(H_NETDATA)&xLinkStatus);
  }
#endif /*#ifdef ROUTER*/

#ifdef LINK_AGGREGATION
  } /* if logical */
#if 0
  else{ /* physical */
    NETIF_UNSETFLAG(pxIfConf->oFlags,IFF_PHYUP);
    /* turn corresponding logical down, if reqd */
    if(pxIfConf->iLogicalLinkIfIdx >= 0)
        NetLIfNewActivePhy(pxIfConf->iLogicalLinkIfIdx);
  }
#endif
#endif
  SNMP(xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifOperStatus = 1;);

  NETIF_UNSETFLAG(pxIfConf->oFlags,IFF_PHYUP);

  if (pxWrapper->pfnIfLinkStatusCbk) {
    (pxWrapper->pfnIfLinkStatusCbk)(oIfIdx, 0);
  }

  return NETERR_NOERR;
}

/*
 * NetIfIfIpUp
 *  Things to do when an interface got a valid IP address
 *
 *  Args:
 *   pxWrapper            Wrapper pointer
 *   oIfIdx                  interface index
 *
 *  Return:
 *   0
 */
LONG NetIfIpUp(NETWRAPPER *pxNetWrapper,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETWRAPPERSTATE *pxWrapperState;
  NETIFCONF *pxIfConf;
  /*NETIF_CBK pfnNetIfOpenCbk; */

  NETMAIN_ASSERT(pxNetWrapper != NULL);

  /* NETMAIN_DBGP(NORMAL,"NetIfIpUp:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfIpUp:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);
#ifdef LINK_AGGREGATION
  /* setup upper layer conf only for logicals */
  if ( ! (pxIfConf->oFlags & IFF_LOGICAL))
    return 0;
#endif


  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL);

  pxIfState = NETGETIFSTATE(pxIfConf);

  /* Early checks */
  if ((pxIfState == NULL) ||
      (pxIfState->eStatus != NETIFSTATUS_OPENED)) {
    return -1;
  }

  NETIF_SETFLAG(pxIfConf->oFlags,IFF_IPUP);

  NetIfEnableNetworkServices(pxNetWrapper,oIfIdx);
{
extern ARPSTATE  *pxArpInstance;
 _ArpSendGRequest(pxArpInstance, oIfIdx, pxIfConf->pxIPAlias->dwAddr);
}

  NetIfSignalOpen(pxNetWrapper,oIfIdx);

  return 0;
}

/*
 * NetIfClose
 *  Closes an interface. Does not free up the resources
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper            Wrapper pointer
 *   oIfIdx                  interface index
 *
 *  Return:
 *   0
 */
LONG NetIfClose(NETWRAPPER *pxNetWrapper,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETWRAPPERSTATE *pxWrapperState;
  NETIFCONF *pxIfConf;
  IPTABLEENTRY xEntry;

  NETMAIN_ASSERT(pxNetWrapper != NULL);

  /* NETMAIN_DBGP(NORMAL,"NetIfClose:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfClose:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL);

  pxIfState = NETGETIFSTATE(pxIfConf);

  /* Early checks */
  if ((pxIfState == NULL) ||
      (pxIfState->eStatus != NETIFSTATUS_OPENED)) {
    return -1;
  }

  /* Must be in OPENED status here */
  NETMAIN_ASSERT(pxIfState->eStatus == NETIFSTATUS_OPENED);

  if(pxIfConf->bCloseInterface == FALSE){
    NetIfSignalClose(pxNetWrapper,oIfIdx);
    return 0;
  }

  pxIfConf->bCloseInterface = FALSE;

#ifdef LINK_AGGREGATION
  /* un-setup upper layer conf only for logicals */
  if ( pxIfConf->oFlags & IFF_LOGICAL ) {
#endif

  NetIfDisableNetworkServices(pxNetWrapper,oIfIdx);

#ifdef LINK_AGGREGATION
  } /* if logical */
#endif

  pxIfState->eStatus = NETIFSTATUS_SETUP;

#ifdef LINK_AGGREGATION
  /* un-setup upper layer conf only for logicals */
  if ( pxIfConf->oFlags & IFF_LOGICAL ) {
#endif

#ifdef NAT
  /*
   * Inform NAT that the interface is down
   */
  {
    H_NETINSTANCE hNatInst = NETGETINST_NAT;
    NatInstanceMsg(hNatInst,NATMSG_DOWNIFIDX, oIfIdx);
  }
#endif

  /* Closes the network interface */
  Ip1toNInstanceLLInterfaceIoctl(pxWrapperState->hNetBottomInst,
                                 pxIfState->hNetIf,NETINTERFACEIOCTL_CLOSE,
                                 (H_NETDATA)0);

#ifdef ETHERNET
  if (pxIfConf->oType == IFT_ETHER) {
    if (pxIfConf->hDhcpClient != 0) {
      DHCPClientInstanceDestroy(pxIfConf->hDhcpClient);
      pxIfConf->hDhcpClient = 0;
    }
  }
#endif

  if (pxIfConf->oFlags & IFF_PHYUP) {
    /* Type specific closing */
    switch(pxIfConf->oType) {

#ifdef ETHERNET
    case IFT_ETHER:
      /* ethernet link */
      EthConfClose(pxIfConf,oIfIdx);
      break;
#endif /*#ifdef ETHERNET*/

#ifdef PPP
    case IFT_PPPOE:
      PppoEConfClose(pxIfConf,oIfIdx);
    case IFT_PPP:
      PppConfClose(pxIfConf,oIfIdx);
      break;
#endif /*#ifdef PPP*/
#ifdef IPOA
  case IFT_NULL:
    IpoAConfClose(pxIfConf,oIfIdx);
    break;
#endif /*#ifdef IPOA*/
    default:
      /* Check is done at the socket layer: should not happen */
      NETMAIN_ASSERT(0);
    }
  }

  /* Delete the iptable entry for this interface */
  xEntry.eAddrType = IPADDRT_MYADDR;
  xEntry.oIfIdx = oIfIdx;
  xEntry.dwAddr = pxIfConf->pxIPAlias->dwAddr;
  xEntry.wDefaultVlan = NETVLAN_ANY;
  IpTableMsg(IPTABLEMSG_DELENTRY,(H_NETDATA)&xEntry);

#ifdef LINK_AGGREGATION
  } /* if logical */
#endif

#ifdef LINK_AGGREGATION
  /* un-set upper layer conf only for physicals */
  if ( ! ( pxIfConf->oFlags & IFF_LOGICAL ) ) {
#endif
  /* link specific close */
  switch(pxIfConf->ePhyLinkType) {

#ifdef ETHERNET
  case ETH:
    /* ethernet link */
    break;
#endif /*#ifdef ETHERNET*/
#ifdef NET_DSL
  case ATM:
    MpoaConfClose(pxIfConf,oIfIdx);
    break;
#endif
  default:
    NETMAIN_ASSERT(0);
  }
#ifdef LINK_AGGREGATION
  } /* if physical */
#endif

#ifdef LINK_AGGREGATION
  /* un-setup upper layer conf only for logicals */
  if ( pxIfConf->oFlags & IFF_LOGICAL ) {
#endif

  /* Delete the interface gateway address (if set) */
  if (pxIfConf->pxIPAlias[0].uLink.xMpData.dwGateway != 0) {
    ROUTEENTRY xRouteEntry;
#ifdef _RADIX_ROUTING_ON_
    xRouteEntry.xRouteNodes->RadixNodeKey = 0;
    xRouteEntry.xRouteNodes->RadixNodeMask = 0;
#else
    xRouteEntry.dwSubnetMask = 0;
    xRouteEntry.dwDstAddr = 0;
#endif
    xRouteEntry.dwGateway = pxIfConf->pxIPAlias[0].uLink.xMpData.dwGateway;
    xRouteEntry.wMetric = 1;
    xRouteEntry.wTOS = 0;
    xRouteEntry.oIfIdx = oIfIdx;
    xRouteEntry.wVlan = NETVLAN_ANY;

    RoutingTableMsg(ROUTINGTABLEMSG_DELROUTE,
                    (H_NETDATA)&xRouteEntry);
  }

  MOC_MEMSET((ubyte *)pxIfConf->pxIPAlias,0x00,sizeof(IPCONF) * pxIfConf->oIPAliasNumber);

#ifdef LINK_AGGREGATION
  } /* if logical */
  else{
    NETIF_UNSETFLAG(pxIfConf->oFlags,(IFF_UP | IFF_IPUP));
    /* turn corresponding logical down, if reqd */
    if(pxIfConf->iLogicalLinkIfIdx >= 0)
        NetLIfNewActivePhy(pxIfConf->iLogicalLinkIfIdx);
  }
#endif

  NETIF_UNSETFLAG(pxIfConf->oFlags,(IFF_UP | IFF_IPUP));

  return 0;
}

/*
 * NetIfTearDown
 *  Tears down an interface. Actually frees up the resources.
 *  Will close the interface if it has not been done.
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper            Wrapper pointer
 *   oIfIdx                  interface index
 *
 *  Return:
 *   0
 *
 */
LONG NetIfTearDown(NETWRAPPER *pxNetWrapper,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETWRAPPERSTATE *pxWrapperState;
  NETIFCONF *pxIfConf;
  int iRv;

  NETMAIN_ASSERT(pxNetWrapper != NULL);

  /* NETMAIN_DBGP(NORMAL,"NetIfTearDown:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfTearDown:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL);

  /* Free PPP cfg */
  if (pxIfConf->xPppConf.pcPppUsername) {
    FREE(pxIfConf->xPppConf.pcPppUsername);
    pxIfConf->xPppConf.pcPppUsername = NULL;
  }
  if (pxIfConf->xPppConf.pcPppPassword) {
    FREE(pxIfConf->xPppConf.pcPppPassword);
    pxIfConf->xPppConf.pcPppPassword = NULL;
  }
  if (pxIfConf->xPppConf.pcPppoESrv) {
    FREE(pxIfConf->xPppConf.pcPppoESrv);
    pxIfConf->xPppConf.pcPppoESrv = NULL;
  }
  if (pxIfConf->xPppConf.pcPppoEAC) {
    FREE(pxIfConf->xPppConf.pcPppoEAC);
    pxIfConf->xPppConf.pcPppoEAC = NULL;
  }

  if(pxIfConf->pxIPAlias != NULL){
    /* Free host and domain name */
    if (pxIfConf->pxIPAlias[0].pcHostName != NULL) {
      FREE(pxIfConf->pxIPAlias[0].pcHostName);
      pxIfConf->pxIPAlias[0].pcHostName = NULL;
    }
    if (pxIfConf->pxIPAlias[0].pcDomainName != NULL) {
      FREE(pxIfConf->pxIPAlias[0].pcDomainName);
      pxIfConf->pxIPAlias[0].pcDomainName = NULL;
    }

    FREE(pxIfConf->pxIPAlias);
    pxIfConf->pxIPAlias = NULL;
    pxIfConf->oIPAliasNumber = 0;
  }

  pxIfState = NETGETIFSTATE(pxIfConf);

  if ((pxIfState == NULL) || (pxIfState->eStatus == NETIFSTATUS_INIT)) {
    return -1;
  }

  if (pxIfState->eStatus == NETIFSTATUS_OPENED) {
    if(NetIfClose(pxNetWrapper,oIfIdx) < 0){
      NETMAIN_ASSERT(0);
      return -1;
    }
  }

  NETIF_SETFLAG(pxIfConf->oFlags,0);

  /* Must be in status SETUP here */
  NETMAIN_ASSERT(pxIfState->eStatus == NETIFSTATUS_SETUP);

#ifdef LINK_AGGREGATION
  /* setup upper layer conf only for logicals */
  if ( pxIfConf->oFlags & IFF_LOGICAL ) {
  /*FREE(pxIfConf->oPhyLinks);*/
#endif

  /* Destroy network if */
  Ip1toNInstanceLLInterfaceDestroy(pxWrapperState->hNetBottomInst,
                                   pxIfState->hNetIf);

  /* Type specific closing */
  switch(pxIfConf->oType) {

#ifdef ETHERNET
  case IFT_ETHER:
    /* ethernet link */
    EthConfDestroy(pxIfConf,oIfIdx);
    break;
#endif /*#ifdef ETHERNET*/
#ifdef PPP
  case IFT_PPPOE:
    PppoEConfDestroy(pxIfConf,oIfIdx);
  case IFT_PPP:
    PppConfDestroy(pxIfConf,oIfIdx);
    break;
#endif /*#ifdef PPP*/
#ifdef IPOA
  case IFT_NULL:
    IpoAConfDestroy(pxIfConf,oIfIdx);
    break;
#endif
  default:
    /* Check is done at the socket layer: should not happen */
    NETMAIN_ASSERT(0);
  }

#ifdef LINK_AGGREGATION
  } /* if logical */
#endif

#ifdef LINK_AGGREGATION
  /* destroy upper layer conf only for physicals */
  if ( ! ( pxIfConf->oFlags & IFF_LOGICAL ) ) {
#endif
  /* link specific destroy */
  switch(pxIfConf->ePhyLinkType) {

#ifdef ETHERNET
  case ETH:
    /* ethernet link */
    /* Close up the driver */
    NETMAIN_ASSERT(pxIfConf->iFd > 0);
    iRv = close(pxIfConf->iFd);
    ASSERT(iRv == 0);
    pxIfConf->iFd = -1;
    break;
#endif /*#ifdef ETHERNET*/
#ifdef NET_DSL
  case ATM:
    MpoaConfDestroy(pxIfConf,oIfIdx);
    break;
#endif
  default:
    NETMAIN_ASSERT(0);
  }

#ifdef LINK_AGGREGATION
  } /* if physical */
#endif

#ifndef __LOCK_OPT_ON__
  /* Free the Mutex */
  RTOS_mutexFree(&pxIfConf->xMutex);
#endif

  /* Free the IfState */
  FREE(pxIfState);
  NETSETIFSTATE(pxIfConf,NULL);

  return 0;
}

/*
 * InterfaceCloseThreadRoutine
 *  Dedicated thread routine for execution of a registered
 *  interface closing callback function
 *
 *  Args:
 *   pArgs                  Pointer to NETIFCONF
 *
 *  Return:
 *   NULL
 */
void *InterfaceCloseThreadRoutine(void *pArg)
{
  OCTET oIfIdx = (OCTET)(DWORD)pArg;
  NETIFCONF *pxIfConf;
  NETIF_CBK pfnNetIfCloseCbk;
  NETWRAPPER *pxNetWrapper = NETGETWRAPPER;;

  NETMAIN_ASSERT((pxNetWrapper != NULL) &&
                 (oIfIdx <= pxNetWrapper->oIfNumber));

  pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  DLLIST_head(&pxNetWrapper->dllPfnIfCloseCbk);
  while((pfnNetIfCloseCbk = DLLIST_read(&pxNetWrapper->dllPfnIfCloseCbk)) != NULL){
    pfnNetIfCloseCbk(oIfIdx);
    DLLIST_next(&pxNetWrapper->dllPfnIfCloseCbk);
  }

  pxIfConf->bCloseInterface = TRUE;

  return NULL;
}

/*
 * InterfaceOpenThreadRoutine
 *  Dedicated thread routine for execution of a registered
 *  interface open callback function
 *
 *  Args:
 *   pArgs                  Pointer to NETIFCONF
 *
 *  Return:
 *   NULL
 */
void *InterfaceOpenThreadRoutine(void *pArg)
{
  OCTET oIfIdx = (OCTET)(DWORD)pArg;
  NETWRAPPER *pxNetWrapper;
  NETIF_CBK pfnNetIfOpenCbk;
  pxNetWrapper = NETGETWRAPPER;

  NETMAIN_ASSERT((pxNetWrapper != NULL) &&
                 (oIfIdx <= pxNetWrapper->oIfNumber));

  DLLIST_head(&pxNetWrapper->dllPfnIfOpenCbk);
  while((pfnNetIfOpenCbk = DLLIST_read(&pxNetWrapper->dllPfnIfOpenCbk)) != NULL){
    pfnNetIfOpenCbk(oIfIdx);
    DLLIST_next(&pxNetWrapper->dllPfnIfOpenCbk);
  }

  return NULL;
}

/*
 * InterfaceDhcpErrorThreadRoutine
 *  Dedicated thread routine for execution of a registered
 *  interface dhcp timeout callback function
 *
 *  Args:
 *   pArgs                  Pointer to NETIFCONF
 *
 *  Return:
 *   NULL
 */
void *InterfaceDhcpErrorThreadRoutine(void *pArg)
{
  OCTET oIfIdx = (OCTET)(DWORD)pArg;
  NETIFCONF *pxIfConf;
  NETWRAPPER *pxNetWrapper;

  pxNetWrapper = NETGETWRAPPER;
  pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);

  NETMAIN_ASSERT(pxNetWrapper->pfnIfDhcpErrorCbk != NULL);
  if (pxNetWrapper->pfnIfDhcpErrorCbk != NULL) {
    (pxNetWrapper->pfnIfDhcpErrorCbk)(oIfIdx, pxIfConf->oDhcpErrorFlag);
  }

  return NULL;
}

/*
 * NetIfSignalClose
 *  Signal that an interface is about to close. If a callback
 *  function has been registered, create a dedicated thread
 *  for execution of the callback function
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Wrapper
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   0
 */
LONG NetIfSignalClose(NETWRAPPER *pxNetWrapper,OCTET oIfIdx)
{
  NETIFCONF *pxIfConf;

  /* NETMAIN_DBGP(NORMAL,"NetIfSignalClose:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfSignalClose:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  NETMAIN_ASSERT(pxNetWrapper != NULL);

  pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);

  if (DLLIST_count_inline(&pxNetWrapper->dllPfnIfCloseCbk) > 0) {
    /* Startup dedicated thread to execute callback function */
    if (RTOS_createThread(InterfaceCloseThreadRoutine,
                          (sbyte4)oIfIdx,
                          0,
                          (sbyte4 *)&(pxIfConf->pth_tThread)) != 0) {
      NETMAIN_ASSERT(0);
      pxIfConf->bCloseInterface = TRUE;
      return -1;
    } else {
    RTOS_destroyThread(pxIfConf->pth_tThread);
    }
  } else {
    pxIfConf->bCloseInterface = TRUE;
  }

  return 0;
}

/*
 * NetIfSignalOpen
 *  Signal that an interface has opened and is up.
 *  If a callback function has been registered,
 *  create a dedicated thread for execution of the callback function
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Wrapper
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   0
 */
LONG NetIfSignalOpen(NETWRAPPER *pxNetWrapper,OCTET oIfIdx)
{
  NETIFCONF *pxIfConf;

  /* NETMAIN_DBGP(NORMAL,"NetIfSignalOpen:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfSignalOpen:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  NETMAIN_ASSERT(pxNetWrapper != NULL);

  pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);

  if((pxIfConf->oFlags & (IFF_IPUP | IFF_PHYUP))) {
    if (DLLIST_count_inline(&pxNetWrapper->dllPfnIfOpenCbk) > 0) {
    /* Startup dedicated thread to execute callback function */
    if (RTOS_createThread(InterfaceOpenThreadRoutine,
                          (sbyte4)oIfIdx,
                          0,
                          (sbyte4 *)&(pxIfConf->pth_tThread)) != 0) {
        NETMAIN_ASSERT(0);
        return -1;
      } else {
        RTOS_destroyThread(pxIfConf->pth_tThread);
      }
    }
  }
  return 0;
}

/*
 * NetIfSignalDhcpError
 *  Signal that an interface has experienced a DHCP client error.
 *  Error may be:
 *    - timeout while attempting to acquire an address
 *    - received a NACK while renewing/acquiring
 *    - lease has expired
 *  If a callback function has been registered,
 *  create a dedicated thread for execution of the callback function
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxWrapper              Wrapper
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   0
 */
LONG NetIfSignalDhcpError(NETWRAPPER *pxNetWrapper,OCTET oIfIdx)
{
  NETIFCONF *pxIfConf;

  NETMAIN_ASSERT(pxNetWrapper != NULL);

  pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);

  /* NETMAIN_DBGP(NORMAL,"NetIfSignalDhcpError:oIfIdx = %d, Error = %d\n",
               oIfIdx, pxIfConf->oDhcpErrorFlag); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,
                            "NetIfSignalDhcpError:oIfIdx = ",oIfIdx,
                            ", Error = ",pxIfConf->oDhcpErrorFlag);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  if (pxNetWrapper->pfnIfDhcpErrorCbk != NULL) {
      /* Startup dedicated thread to execute callback function */
      if (RTOS_createThread(InterfaceDhcpErrorThreadRoutine,
                          (sbyte4)oIfIdx,
                          0,
                          (sbyte4 *)&(pxIfConf->pth_tThread)) != 0) {
      NETMAIN_ASSERT(0);
      return -1;
    } else {
        RTOS_destroyThread(pxIfConf->pth_tThread);
    }
  }

  return 0;
}

/*
 * NetIfLogicalUp
 *  Logical(layer-3) Interface is UP
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfLogicalUp(NETWRAPPER *pxWrapper,OCTET oLIfIdx)
{
  NETIFCONF *pxLIfConf;
  NETIFSTATE *pxLIfState;

  pxLIfConf = NETGETIFCONF(pxWrapper,oLIfIdx);
  NETMAIN_ASSERT(pxLIfConf != NULL);

  pxLIfState = NETGETIFSTATE(pxLIfConf);
  NETMAIN_ASSERT(pxLIfState != NULL);

  /* NETMAIN_DBGP(NORMAL,"NetIfLogicalUp:oIfLIdx = %d\n",oLIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfLogicalUp:oIfIdx = ",oLIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  if (pxLIfState->eStatus != NETIFSTATUS_OPENED) {
    return NETERR_UNKNOWN;
  }

  NETIF_SETFLAG(pxLIfConf->oFlags,IFF_PHYUP);

#ifdef NET_DSL
  if (ATM == pxIfConf->ePhyLinkType) {
    MpoaInstanceLLInterfaceIoctl(NETGETINST_MPOA(pxIfState),
                                 NETGETIF_MPOALL(pxIfState),
                                 NETINTERFACEIOCTL_OPEN,
                                 (H_NETDATA)NULL);
  }
#endif

  switch(pxLIfConf->oType) {
#ifdef ETHERNET
  case IFT_ETHER:
    /* Open all link modules & interfaces */
    EthConfOpen(pxLIfConf,oLIfIdx);
    break;
#endif
#ifdef PPP
  case IFT_PPPOE:
    PppoEConfOpen(pxLIfConf,oLIfIdx);
  case IFT_PPP:
    PppConfOpen(pxLIfConf,oLIfIdx);
    break;
#endif /*#ifdef PPP*/
#ifdef IPOA
  case IFT_NULL:
    IpoAConfOpen(pxLIfConf,oLIfIdx);
    break;
#endif
  default:
    /* can't happen */
    ASSERT(0);
  }

  { /* RS added link status in routing table */
    ROUTINGTABLESETLINKSTATUS xLinkStatus;

    xLinkStatus.oIfIdx    = oLIfIdx;
    xLinkStatus.bIsLinkUp = TRUE;
    RoutingTableMsg(ROUTINGTABLEMSG_SETLINKSTATUS,(H_NETDATA)&(xLinkStatus));
  }
#ifdef ROUTER
  {
    H_NETINSTANCE hRouter = NETGETINST_ROUTER;
    ROUTERSETLINKSTATUS xLinkStatus;

    xLinkStatus.oIfIdx    = oLIfIdx;
    xLinkStatus.bIsLinkUp = TRUE;

    RouterInstanceMsg(hRouter,ROUTERMSG_SETLINKSTATUS,(H_NETDATA)&(xLinkStatus));
  }
#endif /*#ifdef ROUTER*/

  SNMP(xTcpipData.ifNum[(oLIfIdx == 0) ? 0 : 1].ifOperStatus = 2;);

  NetIfSignalOpen(pxWrapper,oLIfIdx);

  if (pxWrapper->pfnIfLinkStatusCbk) {
    (pxWrapper->pfnIfLinkStatusCbk)(oLIfIdx, 1);
  }
}


/*
 * NetIfLogicalDown
 *  Logical(layer-3) Interface is DOWN
 *
 *  Args:
 *   pxWrapper                Wrapper
 *   oIfIdx                   If index
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG NetIfPhyDown_2(NETWRAPPER *pxWrapper,OCTET oIfIdx)
{
  NETIFCONF *pxIfConf = NULL;
  NETIFSTATE *pxIfState= NULL;
  LONG lReturn;

  pxIfConf = NETGETIFCONF(pxWrapper,oIfIdx);
  NETMAIN_ASSERT(pxIfConf != NULL);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  /* NETMAIN_DBGP(NORMAL,"NetIfPhyDown_2:oIfIdx = %d\n",oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NetIfPhyDown_2:oIfIdx = ",oIfIdx);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  if (pxIfState->eStatus != NETIFSTATUS_OPENED) {
    return NETERR_UNKNOWN;
  }
#ifdef LINK_AGGREGATION /*Atul*/
  /* Check if this is only one Phy for its Logical interface.
   * In that case logical should marked as down.
   */
  if(pxIfConf->iLogicalLinkIfIdx >= 0)
  {
      NETIF_UNSETFLAG(pxIfConf->oFlags, IFF_PHYUP);

      lReturn = NetLIfNewActivePhy(pxIfConf->iLogicalLinkIfIdx);
      if (lReturn == 0) {
        NetIfPhyDown(pxWrapper, pxIfConf->iLogicalLinkIfIdx);
      }
  }
  /* else */
#endif
  {
    /* Phy not associated with any Logical */
    /* Mark it down */
    SNMP(xTcpipData.ifNum[(oIfIdx == 0) ? 0 : 1].ifOperStatus = 1;);

    NETIF_UNSETFLAG(pxIfConf->oFlags,IFF_PHYUP);

    if (pxWrapper->pfnIfLinkStatusCbk) {
        (pxWrapper->pfnIfLinkStatusCbk)(oIfIdx, 0);
    }
  }
}

/*
 * NetIfGetShortValue
 * Returns a short value in HOST order from a character buffer
 *
 *  Args:
 *   buf              Buffer
 *
 *  Return:
 *   short value
 */
ubyte2
NetIfGetShortValue(const ubyte* buf)
{
    return (ubyte2)((buf[0] << 8) | (buf[1]));
}

