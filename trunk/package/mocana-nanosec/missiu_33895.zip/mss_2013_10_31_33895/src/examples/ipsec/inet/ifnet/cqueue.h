/*
 * cqueue.h
 *
 * Custom Queue common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _CQUEUE_H_
#define _CQUEUE_H_

#define MAX_CUSTOM_QUEUE_CRITERIA  16
#define MAX_CUSTOM_QUEUE           5

#define CUSTOM_QUEUE_NO_MATCH      255

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * Custom Queue Filter structure
 * One or more of the elements can be populated, which leads to logical
 * AND operation when filter is applied.
 */
typedef struct {
  /* Data layer filter criteria */
  BOOL  bEthVlanTagged;   /* Select if frame is VLAN tagged */
  WORD  wEthVlanTag;      /* VLAN tag matches */
  BOOL  bEthBroadcast;    /* Broadcast frame */
  BOOL  bEthMulticast;    /* Multicast frame */
  WORD  wEthProtocol;     /* Protocol matches, e.g. ARP, IP */

  /* Network layer filter criteria - used w/ IP packets */
  OCTET oIpPrecedence;    /* TOS precedence matches, 0-7 valid */
  OCTET oIpTos;           /* TOS matches, 0-31 valid */
  OCTET oIpProtocol;      /* Protocol matches, e.g. ICMP, UDP, TCP */
  DWORD dwIpSrcAddress;   /* Source IP address matches */
/*  DWORD dwIpSrcNetMask; */ /* Source IP netmask - used w/ address */
  DWORD dwIpDstAddress;   /* Destination IP address matches */
/*  DWORD dwIpDstNetMask; */ /* Destination IP netmask - used w/ address */

  /* Transport layer filter criteria - used w/ UDP and TCP packets */
  WORD  wTransSrcPort;    /* Source port matches */
  WORD  wTransDstPort;    /* Destination port matches */

  /* Class associated w/ this criteria set */
/*  OCTET oClass; */
} CUSTOM_QUEUE_CRITERIA;


typedef CUSTOM_QUEUE_CRITERIA CUSTOM_QUEUE_CRITERIA_TABLE [MAX_CUSTOM_QUEUE_CRITERIA];

MOC_EXTERN CUSTOM_QUEUE_CRITERIA CustomQueueTable[MAX_CUSTOM_QUEUE_CRITERIA];
MOC_EXTERN OCTET aoCustomQueueClass[MAX_CUSTOM_QUEUE_CRITERIA];

/*****************************************************************************
 *
 * Functions
 *
 *****************************************************************************/

DWORD CustomQueueSetCriteriaStruct(CUSTOM_QUEUE_CRITERIA* pxCustomQueueCriteriaStruct, CUSTOM_QUEUE_CRITERIA* pxLocalStruct);
DWORD CustomQueueSetClass(OCTET* poClass, OCTET val);
DWORD CustomQueueCriteriaInit(CUSTOM_QUEUE_CRITERIA* pxCustomQueueCriteriaStruct);

#endif

