/*
 * sockdefs.h
 *
 * socket library internal definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _SOCKDEFS_H_
#define _SOCKDEFS_H_

#include "sockapi.h"
#include "queue.h"
#include "sockdbg.h"
#ifndef __MOCANA_LIBSOCK__
#include "../../utils/mocinclude.h"
#endif

/****************************************************************************
 *
 * Defines
 *
 ****************************************************************************/


#define REGISTER_SOCKET(a, b) SocketRegister((a),(b))
#define UNREGISTER_SOCKET(a) SocketUnregister(a)
#ifdef SOCKETDBG_HI
/* Retrieve being used for all packets, and in NDEBUG
   being reduced to a sole line, it's better as a macro then. */
#define RETRIEVE_SOCKET(a)  SocketRetrieve(a)
#else
#define RETRIEVE_SOCKET(a) xSocketRep.apxSockets[(a & 0xFFFFFF) & DEVICE_NMBR_MASK]
#endif

/*
 * Socket type (SOCK_DGRAM, SOCK_STREAM) to protocol index
 * (0==UDP,1==TCP). Used to index the protocol array in SOCKET_REPOSITORY
 * structures
 */
#define SOCKTYPE2PROTINDEX(lType) (lType & 0x1)

/* Protocol index definition in the SOCKET_REPOSITORY structure */
#define UDP_INDEX 0
#define TCP_INDEX 1

/* UDP buffering defines */
#define UDP_MAX_BUFFER 1400 /* in bytes */

/* TOS setting */
#define SOCKTOS_NOTSET   0xFF
#define SOCKTOS_DEFAULT  SOCKTOS_NOTSET

/*Hash defines for memory pools within the socket module*/
#ifdef __SOCKET_USE_MEMPOOL__
#define SOCKET_CNTL_BLK_MAX     MAX_FD
#define TCPSOCKET_CNTL_BLK_MAX  25000
#define UDPSOCKET_CNTL_BLK_MAX  1000
#define TCPCONNECT_CNTL_BLK_MAX 25000
#endif

/****************************************************************************
 *
 * Typedef
 *
 ****************************************************************************/
/*
 * TCP listen socket members structure
 */
typedef struct {
  WORD oBackLogMax;
  WORD oBackLogLevel;
  QUEUE(struct socket) qWaitForAccept;
  QUEUE(struct socket) qAccepted;
  mn_sock_accept_cb_t pfAcceptCb;
  void* pvAcceptCbArg;
#ifndef __MOCANA_LIBSOCK__
  void*               ipc_req;
#endif
} TCPLISTEN;
#if 0
/* unsent packet waiting in the queue for async sends */
typedef struct {
  WORD wLength; /* Length of the payload */
  OCTET *poPayload;
  mn_send_cb_t pfSendCb;
  void     pvSendCbArg;
} ASYNCSENDBLK;
#endif

/*
 * TCP connect socket members structure
 */
typedef struct {
  struct socket *pxFather; /* Listening sockets from where it is issued */
#if 0
  /* list to queue up unsent packets for async send*/
  DLLIST *pDllAsyncSendBlks;
#endif
  mn_sock_connect_cb_t pfCb;
  void *pvCbArg;
#ifndef __MOCANA_LIBSOCK__
  void*                ipc_req;
#endif
} TCPCONNECT;

/*
 * TCP socket members structure
 */
typedef struct {
  OCTET oType;
  union {
    TCPLISTEN *pxListen;
    TCPCONNECT *pxConnect;
  } u;
} TCPSOCKET;


/*
 * UDPPACKET
 * Used to store unread Rx packets
 * contains wLength, the transport Id and the payload pointer
 * !!! The payload is in-line in the DLLIST buffering case: simplifies
 * buffering !!!
 */
typedef struct {
  TRANSPORTID xId;
  WORD wLength; /* Length of the payload */
#if 0 /* zero-copy */
  OCTET *poPayload;
#else
  NETPAYLOAD *pxPayload;
  WORD wOffset;
#endif
} UDPPACKET;

/*
 * UDP socket members structure
 */
typedef struct {
  TRANSPORTID xRxTransportId;

  /* extra buffering (used when packets are received but no
     app buffer is available == no recvfrom or NON blocking socket */
  DLLIST *pDllPackets;
  WORD wBufferedLength; /* Number of bytes buffered */

  OCTET oMcastTtl;
  OCTET oMcastLoop;

  LONG lErrno; /* stores pending error on socket. Currently
                  only used for EHOSTUNREACH in sendto */
} UDPSOCKET;

#ifndef __MOCANA_LIBSOCK__
struct client_req;

typedef TAILQ_HEAD(client_list_t, client_req) client_list_t;

typedef struct client_req
{
    TAILQ_ENTRY(client_req)    im_link;
    _ipc_msg_t                 ipc_req;
} client_req;
#endif
/*
 * Main socket structure
 */
typedef struct socket {
#ifndef NDEBUG
  DWORD dwMagicCookie;     /* Set up to SOCKET_MAGICCOOKIE at initialisation */
#endif
  LONG lFd;
  H_NETINTERFACE hLL;  /* Network interface to lower protocol : UDP/TCP*/

  LONG lFamily;
  LONG lType;

  LONG lProtocol;

  DWORD dwSockState; /* Socket state (SS_XXX) as defined in socket.h */
  DWORD dwSockOptions;

  DWORD dwLingerTimeOut; /* !!! SB Aug 2001 should that be a DWORD !!! */

  OCTET oSelect;         /* Number of select on the thread
                            Should we separate read/write/exceptions */

  OCTET oBoundFlag;
#define SOCKETBOUNDFLAG_IF             0x1
#define SOCKETBOUNDFLAG_VLAN           0x2
#define SOCKETBOUNDFLAG_IP             0x4
#define SOCKETBOUNDFLAG_TOS            0x8

  TRANSPORTID xTransportId;

  OCTET *poAppBuffer;
  WORD wAppBufferSize;
  WORD wAppBufferUsedLength;
  OCTET **ppoAppBuffer;
  void **ppFreeArg;
  mn_sock_recv_cb_t pfRecvCb;
  void *pvRecvCbArg;
  mn_sock_event_cb_t pfEventCb;
  void *pvEventCbArg;
  ubyte *ipc_req;


  /* Condition variable */
  pthread_cond_t xCond;

  DWORD dwSocketId; /* Uniquely identifies a socket. This prevents
                       socket re-use problem (typically, a socket
                       gets closed. Another ones gets created on the
                       same spot before a connect or a recvfrom has
                       awoken => could cause damage. It is set automatically
                       in the REGISTER_SOCKET macro. However, it is up
                       to the implementer to check its value.
                       !!! SB Do we need a DWORD ? !!!*/

  union {
    TCPSOCKET *pxTcp;
    UDPSOCKET *pxUdp;
  } u;

#ifndef __MOCANA_LIBSOCK__
  client_list_t  client_list;
#endif

#ifndef __SELECT_OPT_ON__
  LONG lPid; /* To Which PID does this Socket Belong */
#endif
  struct socket *pNext; /* Next socket in the dynasty */

} SOCKET;

#ifndef __SELECT_OPT_ON__
typedef struct
{
  struct rbnode node;
  LONG           lPid;
  void         *fdTree;
} PIDINFO;

typedef struct
{
  struct rbnode node;
  LONG           lFd;
} PIDFDINFO;
#endif
/*
 * Socket Repository structure.
 */
typedef struct {
  SOCKET *apxSockets[MAX_FD]; /* Array of all possible sockets. NULL means
                                 it does not exist. Need this for
                                 efficiency */
  DWORD dwSocketCounter; /* incremented by one for each created socket,
                            which uses it as its dwSocketId. This prevents
                            socket re-use problem (typically, a socket
                            gets closed. Another ones gets created on the
                            same spot before a connect or a recvfrom has
                            awoken => could cause damage
                            !!! SB Do we need a DWORD ? !!!*/
  /* Protocols (UDP/TCP) facilitie : */
  struct {
    H_NETINSTANCE hInst;
    LONG (*pfnCreateConn)(SOCKET *pxSock);
    LONG (*pfnConnectConn)(SOCKET *pxSock,mn_sock_connect_cb_t cb, void *cbarg, void * ipc_msg);
    PFN_NETWRITE pfnWrite;
    PFN_NETRXCBK pfnRxCbk;
    PFN_NETIOCTL pfnIoctl;
  } axProtocols[2]; /* 0==UDP. 1== TCP */

  /* Network layer entry point: for transiting data */
  H_NETINSTANCE hNetwork;

 /* Igmp hooks */
  H_NETINSTANCE hIgmp;

  /* Icmp hooks */
  H_NETINSTANCE hIcmp;

  /* Arp hooks */
  H_NETINSTANCE hArp;

  /* Router hooks */
  H_NETINSTANCE hRouter;

  /* NAT hooks */
  H_NETINSTANCE hNat;

  /* Ethernet hooks */
  H_NETINSTANCE hEth;

  /* IPSec hooks */
  H_NETINSTANCE hIpsec;

#ifndef __SELECT_OPT_ON__
  /* Contains all the PID specific Info (PIDINFO) ,
     the fd list of sockets PID Owns */
  void *pidTree;
#endif

#ifdef __SOCKET_USE_MEMPOOL__
  poolHeaderDescr tcpSockConnPool; /* Pool holding all TCPSOCKET structures */
  poolHeaderDescr udpSockConnPool; /* Pool holding all UDPSOCKET structures */
  poolHeaderDescr sockConnPool;    /* Pool holding all SOCKET structures */
  poolHeaderDescr tcpconnectConnPool; /* Pool holding all TCPCONNECT structures */
#endif
} SOCKET_REPOSITORY;


typedef struct ip_mreq IP_MREQ;

/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/
MOC_EXTERN SOCKET_REPOSITORY xSocketRep;

/****************************************************************************
 *
 * Helper function
 *
 ****************************************************************************/

#ifndef NDEBUG
/* Retrieve being used for all packets, and in NDEBUG
   being reduced to a sole line, it's better as a macro then
   (see RETRIEVE_SOCKET def) */
/*
 * SocketRetrieve
 *  Retrieve the SOCKET * coresponding to a socket
 *  file descriptor
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   iSockFd            socket file descriptor
 *
 *  Return:
 *   SOCKET *           if found, NULL otherwise
 */
SOCKET* SocketRetrieve(int iSockfd);
#endif

/*
 * SocketRegister
 *  Register a SOCKET * with its socket file descriptor
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   iSockFd             socket file descriptor
 *   pxSocket            coresponding SOCKET *
 *
 *  Return:
 *   >=0 if success
 */
LONG    SocketRegister(int iSockFd,SOCKET* pxSocket);

/*
 * SocketUnregister
 *  Unregister a socket fd (=>makes it unused)
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   iSockFd             socket file descriptor
 *
 *  Return:
 *   >=0 if success
 */
LONG    SocketUnregister(int iSockFd);

/*
 * TcpRxCbk
 *  Rx Cbk function provided to a TCP UL interface
 *
 *  Args:
 *   hULInst                   UL instance handle. In fact a socket
 *                             structure pointer
 *   hIf                       unused
 *   pxPacket                  packet pointer
 *   pxAccess                  access info
 *   hData                     cast TRANSPORTID of the remote end
 *
 *  Return:
 *   length accepted or -1 (error)
 */
LONG TcpRxCbk(H_NETINSTANCE hULInst,H_NETINTERFACE hIf,
              NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
              H_NETDATA hData);

/*
 * UdpRxCbk
 *  Rx Cbk function provided to a UDP UL interface
 *
 *  Args:
 *   hULInst                   UL instance handle. In fact a socket
 *                             structure pointer
 *   hIf                       Unused
 *   pxPacket                  packet pointer
 *   pxAccess                  access info
 *   hData                     Cast TRANSPORTID of the remote end
 *
 *  Return:
 *   length accepted or -1 (error)
 */
LONG UdpRxCbk(H_NETINSTANCE hULInst,H_NETINTERFACE hIf,
              NETPACKET *pxPacket,
              NETPACKETACCESS *pxAccess,
              H_NETDATA hData);

/*
 * SocketWakeSelect
 *  Wakeup select on behalf of a socket (connection) which can now send
 *  or receive data.
 *  !!! Does not lock the mutex !!!
 *
 * Args:
 *  lFd                          socket file descriptot
 *  oType                        available for read or write
 *
 * Return:
 *  >=0
 */
LONG SocketWakeSelect(SOCKET *,OCTET oType);

/*
 * SocketTcpForceTypeToABortNBIO
 *  Forces the type of the socket to abort and non-blocking
 *  for fast close/shutdown
 *
 *  Args:
 *   pxSock
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG SocketTcpForceTypeToAbortNBIO(SOCKET *pxSock);

/****************************************************************************
 *
 * Local function prototypes
 *  Function descriptions head their implementation
 *
 ****************************************************************************/
void FreeUdpPacket(void *);
LONG SocketTcpSetLastChild(SOCKET *pxSock,SOCKET *pxChild);
LONG SocketTcpCreateConn(SOCKET *pxSock);
LONG SocketTcpUlCbk(H_NETINSTANCE hUL, H_NETINTERFACE hInt,
#ifndef __TCP_OPT_ON__
                  LONG lFd,
#endif
                  E_TCPULINTERFACECBK eCbk,
                  H_NETDATA hData);
LONG SocketTcpConnectConn(SOCKET *pxSock, mn_sock_connect_cb_t cb, void *cbarg, void * ipc_msg);
LONG SocketTcpDestroy(SOCKET *pxSock);
LONG SocketUdpCreateConn(SOCKET *pxSock);
LONG SocketUdpConnectConn(SOCKET *pxSock, mn_sock_connect_cb_t cb, void *cbarg, void * ipc_msg);
LONG SocketUdpDestroy(SOCKET *pxSock);
LONG SocketCreate(LONG lFd,LONG lFamily,LONG lType,LONG lProtocol,
                  H_NETINTERFACE hConn);
LONG SocketDestroy(LONG lFd);
LONG SocketOpen(INODE *pxInode, struct file *pxFile);
LONG SocketIoctl(INODE* inode, struct file *pxFile, DWORD dwRequest,
                 mnIoctlArgList_t *pArgList);
LONG SocketClose(INODE *pxInode, struct file *pxFile);
LONG SocketRecv(INODE *pxInode, struct file *pxFile, void *pBuf, ubyte4 dwCnt);
LONG SocketSend(INODE *pxInode, struct file *pxFile, void *pBuf, ubyte4 dwCnt);
LONG SocketShut(SOCKET *pxSock);


#endif /* #ifndef _SOCKDEFS_H_ */
