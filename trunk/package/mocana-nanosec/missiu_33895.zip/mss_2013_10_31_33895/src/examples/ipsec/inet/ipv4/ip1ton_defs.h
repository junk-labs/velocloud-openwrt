/*
 * ipfrag_defs.h
 *
 * Ip1toN module common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __IP1TONDEFS_H__
#define __IP1TONDEFS_H__

/*****************************************************************************
 *
 * include
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "ip1ton_flavor.h"
#include "../include/socket.h"
#include "netutils.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "netnetwork.h"
#include "ip1ton.h"
#include "ip1ton_dbg.h"
#include "netsnmp.h"
#include "ip.h"
#include "../include/in.h"
#include "../include/socket.h"
#include "ecc.h"
#include "netutils.h"
#include "netdefs.h"

/*****************************************************************************
 *
 * define
 *
 *****************************************************************************/

#define IP1TONLLIDX_INVALID 0xFF

/*****************************************************************************
 *
 * Structures & Typedefs
 *
 *****************************************************************************/



typedef struct {
  H_NETINSTANCE hLLInst;
  H_NETINTERFACE hLLIf;
  PFN_NETWRITE  pfnLLWrite;
  OCTET oIfIdx;
  OCTET obUsed;
} IP1TON_LL;


/*
 * Ip1toN instance structure
 */
typedef struct {
  /* Basic structure override protection */
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

  /* LL modules */
  IP1TON_LL *pxLl;
  OCTET oLLNumberIf;

  OCTET aIfIdxToLlMap[IP1TON_MAXIF];

  /* UL interface stuff */
  H_NETINSTANCE hULInst;
  H_NETINTERFACE hULIf;
  PFN_NETRXCBK pfnRxCbk;

} IP1TONSTATE;

/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/



#endif /* #ifndef __IP1TONDEFS_H__ */
