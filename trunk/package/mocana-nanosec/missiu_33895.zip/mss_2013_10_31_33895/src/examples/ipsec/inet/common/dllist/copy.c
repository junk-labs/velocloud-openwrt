#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void DLLIST_copy(DLLIST *dllDst, DLLIST *dllSrc)
{
  MOC_MEMCPY((ubyte *)dllDst, (ubyte *)dllSrc, sizeof(DLLIST));
}
