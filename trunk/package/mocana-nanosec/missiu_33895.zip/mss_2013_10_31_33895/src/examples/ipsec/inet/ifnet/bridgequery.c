/*
 * ethquery.c
 *
 * Ethernet instance query function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include <NNstyle.h>
#include "ethbridge_flavor.h"
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "netcommon.h"
#include "dllist.h"
#include "sys/socket.h"
#include "netdefs.h"
#include "ethernet.h"
#include "bridgedbg.h"
#include "bridgedefs.h"
#include "netsnmp.h"

/*****************************************************************************
 *
 * Implemetation
 *
 *****************************************************************************/

/*
 * EthInstanceQuery
 *  Query a ETH Instance Option
 *
 *  Args:
 *   hEth                       ETH instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceQuery(H_NETINSTANCE hEth,OCTET oOption,
                      H_NETDATA *phData)
{
  ETHSTATE *pxEth = (ETHSTATE *)hEth;
  LONG lReturn = NETERR_NOERR;

  ETH_CHECK_STATE(pxEth);
  ETH_DBGP(REPETITIVE, "EthInstanceQuery: Option: %x\n", oOption);

  switch(oOption) {
  case ETHOPTION_MACADDR:
    {
      ETHID *pxEthId = (ETHID*)phData;
      ASSERT(pxEthId->oIfIdx <= ETHBR_MAXNUM_IF);
      MOC_MEMCPY((ubyte *)pxEthId->aoAddr,
            (ubyte *)pxEth->aaoIfEthAddr[pxEthId->oIfIdx],
            ETHADDRESS_LEN);
    }
    break;

  case ETHOPTION_IFTOLLMAP:
    {
      ETHIFTOLL *pIfToLl = (ETHIFTOLL *)phData;
      ASSERT(pIfToLl->oIfIdx <= ETHBR_MAXNUM_IF);
      pIfToLl->hLlIf = (H_NETINTERFACE)pxEth->apxIfToLlMap[pIfToLl->oIfIdx];
    }
    break;

#ifndef NDEBUG
  case NETOPTION_MALLOC:
  case NETOPTION_FREE:
  case NETOPTION_PAYLOADMUTEX:
  case NETOPTION_OFFSET:
  case NETOPTION_TRAILER:
  case NETOPTION_NETCBK:
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
#endif
  }

  return lReturn;
}
