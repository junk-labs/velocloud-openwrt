/*
 * pppoeclient_accel.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "pppoeclientdefs.h"


/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/

/*
 * PppoEClientInstanceResetTransmission
 *  Reset the transmission members of the PPPoE client
 *
 *  Args:
 *   pxPppoeClient                instance state structure
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG PppoEClientInstanceResetTransmission(PPPOECLIENTSTATE *pxPppoeClient)
{
  PPPOECLIENT_CHECKSTATE(pxPppoeClient);

  pxPppoeClient->dwRetranmissionCounter = pxPppoeClient->dwRetranmissionCounterBase;
  pxPppoeClient->dwRetransmissionTO = pxPppoeClient->dwRetransmissionTOBase;
  pxPppoeClient->dwNextRetransmissionT = NetGlobalTimerGet();

  /* Need processing now ! */
  ASSERT(pxPppoeClient->pfnNetCbk != NULL);
  pxPppoeClient->pfnNetCbk(pxPppoeClient->hNetCbk,NETCBK_NEEDPROCESSING,0);

  return NETERR_NOERR;
}



/*
 * PppoEClientProcessPacket
 *  Process a PPPoE packet. Will clear the axTagTable
 *
 *  Args:
 *   pxPppoeClient              PPPoE client state
 *   pxHdr                packet hdr
 *   axTagTable           packet tag table
 *   pxEthId              ethernet id of the packet
 *
 *  Return 0;
 */
LONG PppoEClientProcessPacket(H_NETINSTANCE hInst,
                              PPPOECLIENTSTATE *pxPppoeClient,
                              PPPOEHDR *pxHdr,A_PPPOETAGTABLE axTagTable,
                              ETHID *pxEthId)
{
  ASSERT((pxPppoeClient->pfnNetCbk != NULL) && (pxPppoeClient->pfnLlWrite != NULL));

  PPPOECLIENT_DBG(REPETITIVE,PppoEPrintTagTable(axTagTable));

  if ((pxHdr->oCode == PPPOECODE_PADT) ||
      ((axTagTable[PPPOETAGIDX_SERVICENAMEERROR].wItemNum == 0) &&
       (axTagTable[PPPOETAGIDX_ACSYSTEMERROR].wItemNum == 0) &&
       (axTagTable[PPPOETAGIDX_GENERICERROR].wItemNum == 0) &&
       (axTagTable[PPPOETAGIDX_UNKNOWN].wItemNum == 0))) {
    /* If no error or PADT */
    switch(pxHdr->oCode) {
    case PPPOECODE_PADO:
      /* If the client in the discover stage, continue */
      if ((pxPppoeClient->eState == PPPOECLIENTSTATE_DISCOVER) &&
          (PppoETagTableMatch(axTagTable,PPPOETAGIDX_SERVICENAME,
                              pxPppoeClient->axTagTable[PPPOETAGIDX_SERVICENAME].pxItemList) >= 0) &&
          (PppoETagTableMatch(axTagTable,PPPOETAGIDX_ACNAME,
                              pxPppoeClient->axTagTable[PPPOETAGIDX_ACNAME].pxItemList) == 0) ) {
        PPPOETAG *pxServiceNameTag = NULL;
        CHAR *pcServiceName = NULL;
    LONG dwNumServices;

    /* Find out how which service matches */
        dwNumServices = PppoETagTableMatch(axTagTable,PPPOETAGIDX_SERVICENAME,
                          pxPppoeClient->axTagTable[PPPOETAGIDX_SERVICENAME].pxItemList);

    /* Verify which ACName matches - there should be only one but Cisco
     * have been known to erroneously put more than one in a PADO - CF
     * This checks that the first one matches if there is a match  */
        ASSERT(0 == PppoETagTableMatch(axTagTable,PPPOETAGIDX_ACNAME,
                          pxPppoeClient->axTagTable[PPPOETAGIDX_ACNAME].pxItemList));

        ASSERT(pxPppoeClient->xHdr.wSessionId == 0);

    if (0 != dwNumServices)  /* At least one service is offered which matches configured */
                             /* so use the one which is configured */
          pxServiceNameTag = &pxPppoeClient->axTagTable[PPPOETAGIDX_SERVICENAME];
    else {  /* No service configured, so select first one offered */
          pxServiceNameTag->wItemNum = 1;
          pxServiceNameTag->pxItemList = axTagTable[PPPOETAGIDX_SERVICENAME].pxItemList;
        }

        /*The client should have got a service name if one is configured, or null tag */
        ASSERT((pxServiceNameTag->wItemNum == 1) &&
               (pxServiceNameTag->pxItemList != NULL));

        if(pxServiceNameTag->pxItemList->poData != NULL){
          /* One needs a copy of the service name before the tag table is deleted*/
          pcServiceName = (CHAR *)malloc(pxServiceNameTag->pxItemList->wLength + 1);
          ASSERT(pcServiceName != NULL);

          (void*)memcpy((void*)pcServiceName,
                        (void*)pxServiceNameTag->pxItemList->poData,
                        (size_t)pxServiceNameTag->pxItemList->wLength);
          pcServiceName[pxServiceNameTag->pxItemList->wLength] = '\0';
        }

        PppoETagTableClear(pxPppoeClient->axTagTable);
        PppoETagTableMove(pxPppoeClient->axTagTable,axTagTable);

    /* If service is offered */
        if(pcServiceName != NULL){
          PppoETagTableDeleteTag(pxPppoeClient->axTagTable,PPPOETAGIDX_SERVICENAME);
          PppoEClientInstanceSet(hInst,PPPOECLIENTOPTION_SERVICENAME,(H_NETDATA)pcServiceName);
          free(pcServiceName);
        }

        /* Get ready for the next stage */
        pxPppoeClient->eState = PPPOECLIENTSTATE_REQUEST;
        pxPppoeClient->xHdr.oCode = PPPOECODE_PADR;
        memcpy(pxPppoeClient->xServerEthId.aoAddr,pxEthId->aoAddr,ETHADDRESS_LEN);
        PppoEClientInstanceResetTransmission(pxPppoeClient);
      }
      break;

    case PPPOECODE_PADS:
      if ((pxPppoeClient->eState == PPPOECLIENTSTATE_REQUEST) &&
          (PppoETagTableMatch(axTagTable,PPPOETAGIDX_SERVICENAME,
                              pxPppoeClient->axTagTable[PPPOETAGIDX_SERVICENAME].pxItemList) >= 0) &&
          (PppoETagTableMatch(axTagTable,PPPOETAGIDX_ACNAME,
                              pxPppoeClient->axTagTable[PPPOETAGIDX_ACNAME].pxItemList)
           <=0 /* Not set (==no match, or the match is the 1st one) */) &&
          (pxHdr->wSessionId != 0)) {

        /* Register the session id */
        ASSERT(pxPppoeClient->xHdr.wSessionId == 0);
        pxPppoeClient->xHdr.wSessionId = pxHdr->wSessionId;
        pxPppoeClient->xHdr.oCode = PPPOECODE_SESSION;

        /* Get ready for the next stage */
        pxPppoeClient->eState = PPPOECLIENTSTATE_SESSION;
        pxPppoeClient->pfnNetCbk(pxPppoeClient->hNetCbk,
                           NETCBK_TLU,(H_NETDATA)0);
        PppoEClientInstanceResetTransmission(pxPppoeClient);
      }
      else {
        PPPOECLIENT_DBGP(ERROR,"PppoEClientProcessPacket: can't accept the PADS\n");
      }
      break;

    case PPPOECODE_PADT:
      if (pxHdr->wSessionId == pxPppoeClient->xHdr.wSessionId) {
        if (pxPppoeClient->eState == PPPOECLIENTSTATE_TERMINATE) {
          /* Signal CLOSED, go to INIT stage */
          pxPppoeClient->xHdr.oCode = PPPOECODE_PADI;
          pxPppoeClient->eState = PPPOECLIENTSTATE_INIT;
          PppoEClientInstanceResetTransmission(pxPppoeClient);
          pxPppoeClient->pfnNetCbk(pxPppoeClient->hNetCbk,
                             NETCBK_TLF,(H_NETDATA)0);
        }
        else if (pxPppoeClient->eState == PPPOECLIENTSTATE_SESSION) {
          /* Server initiated termination: Send 1 PADT */
          NETPACKET xNetPacket;
          NETPACKETACCESS xAccess;

          PppoEClientCreatePacket(pxPppoeClient,&xNetPacket,&xAccess);

          pxPppoeClient->pfnLlWrite(pxPppoeClient->hLl,pxPppoeClient->hLlPppoEIf,
                              &xNetPacket,&xAccess,
                              (H_NETDATA)pxEthId);
          /* signal down. Go to discover */
          pxPppoeClient->pfnNetCbk(pxPppoeClient->hNetCbk,
                             NETCBK_TLD,(H_NETDATA)0);

          PppoEClientInstanceResetTransmission(pxPppoeClient);

          pxPppoeClient->eState = PPPOECLIENTSTATE_INIT;
          pxPppoeClient->xHdr.oCode = PPPOECODE_PADI;
        }

      }
      break;

    case PPPOECODE_PADI:
      /*Nothing to do, this used by pppoe server*/
      break;
    default:
      /* ignore all other messages */
      ASSERT(0);
    }
  }
  PppoETagTableClear(axTagTable);

  return 0;
}

/*
 * PppoEClientInstanceRcv
 *  PPPoE client Rcv function. packet based
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     UL interface handle
 *   pxPacket                packet
 *   pxAccess                Access information
 *   hData                   casted ETHID *
 *
 *  Return:
 *   Length written if success
 */
LONG PppoEClientInstanceRcv(H_NETINSTANCE hInst,H_NETINTERFACE hIf,
                            NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                            H_NETDATA hData)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;
  LONG lReturn;
  PPPOEHDR xHdr;
  A_PPPOETAGTABLE axTagTable;
  ETHID *pxEthId = (ETHID *)hData;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);
  NETPACKET_CHECK(pxPacket);
  ASSERT((pxAccess != NULL) &&
         ((pxAccess->wOffset + pxAccess->wLength) <= pxPacket->pxPayload->wSize) &&
         (pxPppoeClient->pfnRxCbk != NULL) &&
         (pxEthId != NULL) &&
         (pxEthId->oIfIdx < PPPOE_MAXNUM_IF));

  lReturn = pxAccess->wLength;

  memset(axTagTable,0x00,sizeof(A_PPPOETAGTABLE));

  /* Decode the packet */
  PppoEDecode(pxPacket->pxPayload->poPayload + pxAccess->wOffset,
              &xHdr,axTagTable);

  PPPOECLIENT_DBGP(REPETITIVE,"PppoEClientInstanceRcv:%d, oIfIdx=%d, Rx %s from "MACFORM",SessionId=%d\n",
                   (int)pxPppoeClient,pxEthId->oIfIdx,PppoECodeToString(xHdr.oCode),
                   HWADDRDISPLAY(pxEthId->aoAddr),xHdr.wSessionId);

  switch(xHdr.oCode){
  case PPPOECODE_SESSION:
    if ((pxPppoeClient->eState == PPPOECLIENTSTATE_SESSION) &&
        (xHdr.wSessionId == pxPppoeClient->xHdr.wSessionId)) {
      /* session packet: send up */
      NETIFID xIfId;
      ASSERT(pxAccess->wLength > PPPOE_HDRLEN);
      pxAccess->wLength -= PPPOE_HDRLEN;
      pxAccess->wOffset += PPPOE_HDRLEN;

      xIfId.oIfIdx = pxEthId->oIfIdx;
      xIfId.wVlan = pxEthId->wVlan;

      pxPppoeClient->pfnRxCbk(pxPppoeClient->hUl,pxPppoeClient->hUlIf,pxPacket,pxAccess,
                        (H_NETDATA)&(xIfId));
    }
    else {
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    }
    break;


  case PPPOECODE_PADO:
  case PPPOECODE_PADS:
  case PPPOECODE_PADT:
  {
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    PppoEClientProcessPacket(hInst,pxPppoeClient,&xHdr,axTagTable,pxEthId);
  }
    break;

  case PPPOECODE_PADI:
  case PPPOECODE_PADR:
    /*These message are received by the server*/
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
    /* Must free the tags too */
    PppoETagTableClear(axTagTable);
    break;
  default:
    ASSERT(0);
  }
  return lReturn;
}

/*
 * PppoEClientInstanceWrite
 *  PPPoE client write function. packet based
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     UL interface handle
 *   pxPacket                packet
 *   pxAccess                Access information
 *   hData                   casted NETIFID *
 *
 *  Return:
 *   Length written if success
 */
LONG PppoEClientInstanceWrite(H_NETINSTANCE hInst,H_NETINTERFACE hIf,
                              NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                              H_NETDATA hData)
{
  PPPOECLIENTSTATE *pxPppoeClient = (PPPOECLIENTSTATE *)hInst;
  LONG lReturn;

  PPPOECLIENT_CHECKSTATE(pxPppoeClient);
  NETPACKET_CHECK(pxPacket);
  ASSERT((pxAccess != NULL) &&
         ((pxAccess->wOffset + pxAccess->wLength) <= pxPacket->pxPayload->wSize) &&
         (pxPppoeClient->pfnLlWrite != NULL));

  lReturn = pxAccess->wLength;

  if (pxPppoeClient->eState == PPPOECLIENTSTATE_SESSION) {
    /* Session state: Add the PPPoE header and pass down */
    /* PPPoE header */
    pxPppoeClient->xHdr.wLength = pxAccess->wLength;

    ASSERT(pxAccess->wOffset >= PPPOE_HDRLEN);
    pxAccess->wLength += PPPOE_HDRLEN;
    pxAccess->wOffset -= PPPOE_HDRLEN;

    PppoEEncode(pxPacket->pxPayload->poPayload + pxAccess->wOffset,
                &(pxPppoeClient->xHdr),pxPppoeClient->axTagTable);

    pxPppoeClient->pfnLlWrite(pxPppoeClient->hLl,pxPppoeClient->hLlSessionIf,
                        pxPacket,pxAccess,(H_NETDATA)&(pxPppoeClient->xServerEthId));
  }
  else {
    NETPAYLOAD_DELUSER(pxPacket->pxPayload);
  }



  return lReturn;
}


