/*
 * hmac_sha1_ref.c
 *
 * HMAC message authentication using SHA1
 *    code modified from RFC-2104. (Reference)
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "stdlib.h"
#include "strings.h"
#include "cryptcommon.h"
#include "sha1.h"
#include "hmac_sha1.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*****************************************************************************
 * hmac_sha1_ref (HMAC-SHA1 reference implementation)
 *   poText : pointer to data stream
 *   dwTextLen :length of data stream
 *   poKey : pointer to authentication key
 *   dwKeyLen : length of authentication key
 *   poDigest : pointer to caller digest to be filled in (should be allocated)
 *****************************************************************************/
void hmac_sha1_ref(OCTET* poText,
                   DWORD dwTextLen,
                   OCTET* poKey,
                   DWORD dwKeyLen,
                   OCTET* poDigest)
{
  SHA1_CTX* pxContext;
  OCTET aoKIpad[65];    /* inner padding - */
  OCTET aoKOpad[65];    /* outer padding - */
  int i;

  ASSERT(poText!=NULL);
  ASSERT(poKey!=NULL);
  ASSERT(poDigest!=NULL);

  if (poText && poKey && poDigest) {

    /* if key is longer than 64 bytes reset it to key=SHA1(key) */
    if (dwKeyLen > 64) {
      SHA1_CTX*      pxTctx;
      OCTET aoTk[SHA1_HASH_SIZE];

      pxTctx = (SHA1_CTX*) SHA1Init();
      SHA1Update((H_CRYPT)pxTctx, poKey, dwKeyLen);
      SHA1Final((H_CRYPT)pxTctx,aoTk);

      poKey = aoTk;
      dwKeyLen = SHA1_HASH_SIZE;
    }

    /*
     * the HMAC_SHA1 transform looks like:
     *
     * SHA1(K XOR opad, SHA1(K XOR ipad, text))
     *
     * where K is an n byte key
     * ipad is the byte 0x36 repeated 64 times
     * opad is the byte 0x5c repeated 64 times
     * and text is the data being protected
     */

#if 0
    /* start out by storing key in pads */
    bzero( aoKIpad, sizeof aoKIpad);
    bzero( aoKOpad, sizeof aoKOpad);
    bcopy( poKey, aoKIpad, dwKeyLen);
    bcopy( poKey, aoKOpad, dwKeyLen);

    /* XOR key with ipad and opad values */
    for (i=0; i<64; i++) {
      aoKIpad[i] ^= 0x36;
      aoKOpad[i] ^= 0x5c;
    }
#else /* if 0 */
    /* XOR key with ipad and opad values */
    for (i=0; i<dwKeyLen; i++) {
      aoKIpad[i] = 0x36 ^ poKey[i];
      aoKOpad[i] = 0x5c ^ poKey[i];
    }
    for (i=dwKeyLen; i<65; i++) {
      aoKIpad[i] = 0x36;
      aoKOpad[i] = 0x5c;
    }
#endif /* if 0 else */
    /*
     * perform inner SHA1
     */
    pxContext = (SHA1_CTX*) SHA1Init();            /* init context for 1st pass */
    SHA1Update((H_CRYPT)pxContext, aoKIpad, 64);/* start with inner pad */
    SHA1Update((H_CRYPT)pxContext, poText, dwTextLen);/*then text of datagram*/
    SHA1Final((H_CRYPT)pxContext,poDigest);        /* finish up 1st pass*/

    /*
     * perform outer SHA1
     */
    pxContext = (SHA1_CTX*) SHA1Init();        /* init context for 2nd pass */
    SHA1Update((H_CRYPT)pxContext, aoKOpad, 64);/* start with outer pad */
    SHA1Update((H_CRYPT)pxContext, poDigest, SHA1_HASH_SIZE);/* then results of 1st  */
    SHA1Final((H_CRYPT)pxContext,poDigest);    /* finish up 2nd pass */
  }
} /* end of hmac_sha1_ref() */

