/*
 * icmp.c
 *
 * ICMP module implementation
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "icmp_defs.h"


/*****************************************************************************
 *
 * local variables
 *
 *****************************************************************************/
ICMP_DBG_VAR(DWORD g_dwIcmpDebugLevel = ERROR);

struct icmp_packetdef {
  OCTET oType;
  OCTET oCode;
/*} axIcmpMsgToDef[ICMPMSG_MAX -1 - ICMPMSG_SEND_MAX] = { */
} axIcmpMsgToDef[ICMPMSG_MAX ] = {
  /* Frag needed */
  {ICMPTYP_DEST_UNREACH,ICMP_FRAG_NEEDED},
  /* Port unreachable */
  {ICMPTYP_DEST_UNREACH,ICMP_PORT_UNREACH},
  /* Net unreachable */
  {ICMPTYP_DEST_UNREACH,ICMP_NET_UNREACH},
  /* Host unreach */
  {ICMPTYP_DEST_UNREACH,ICMP_HOST_UNREACH},
  /* Echo */
  {ICMPTYP_ECHO,0},
  /* Exceeded TTL */
  {ICMPTYP_TIME_EXCEEDED,ICMP_TIME_EXCEEDED_TTL},
  /* Exceeded Frag Time */
  {ICMPTYP_TIME_EXCEEDED,ICMP_TIME_EXCEEDED_FRAGTIME}
#ifdef NEW_ICMP_MSG_ADDED
  , {ICMPTYP_DEST_UNREACH, ICMP_PROT_UNREACH}
  , {ICMPTYP_REDIRECT, ICMP_REDIR_HOST}
  , {ICMPTYP_TIMESTAMP, 0}
#endif
};

/*****************************************************************************
 *
 * local functions
 *
 *****************************************************************************/

static void _IcmpRcvEchoRequest(ICMP_STATE *pxIcmp,
                                       ICMPCBKDATA *pxIcmpCbkData);

#ifdef NEW_ICMP_MSG_ADDED
static void _IcmpRcvTimeStampRequest(ICMP_STATE *pxIcmp,
                                            ICMPCBKDATA *pxIcmpCbkData);
#endif

SNMP_TCPIP_DATA xTcpipData;

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * IcmpInitialize
 *  Initialize the ICMP Library
 *
 *  Args:
 *
 *  Return:
 *    NETERR_NOERR
 */
LONG IcmpInitialize(void)
{
  /* Nothing to do */

  /* Set the debug level for ICMP module to ERROR */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_ICMP, INET_DBG_LEVEL_ERROR);
  return NETERR_NOERR;
}

/*
 * IcmpTerminate
 *  Terminate the ICMP Library
 *
 *  Args:
 *
 *  Return:
 *    NETERR_NOERR
 */
LONG IcmpTerminate(void)
{
  /* nothing to do */

  return NETERR_NOERR;
}


/*
 * IcmpInstanceCreate
 *  Creates a ICMP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IcmpInstanceCreate(void)
{
  ICMP_STATE *pxIcmp;

  /*Allocate memory for the ICMP_STATE*/
  pxIcmp = (ICMP_STATE *)MALLOC(sizeof(ICMP_STATE));
  ASSERT(pxIcmp != NULL);
  MOC_MEMSET((ubyte *)pxIcmp, 0, sizeof(ICMP_STATE));


  /*Set the Igmp cookie*/
  ICMP_SET_COOKIE(pxIcmp);

  return (H_NETINSTANCE)pxIcmp;
}

/*
 * IcmpInstanceDestroy
 *  Destroy a ICMP Instance
 *
 *  Args:
 *   hIcmp                 ICMP instance
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceDestroy(H_NETINSTANCE hIcmp)
{
  ICMP_STATE *pxIcmp = (ICMP_STATE *)hIcmp;
  ICMP_CHECK_STATE(pxIcmp);

  /*Set the Icmp cookie*/
  ICMP_UNSET_COOKIE(pxIcmp);

  /*free the icmp instance*/;
  FREE(pxIcmp);

  return NETERR_NOERR;
}

/*
 * IcmpInstanceSet
 *  Set a ICMP Instance Option
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceSet(H_NETINSTANCE hIcmp,
                     OCTET oOption,
                     H_NETDATA hData)
{
  LONG lRv = NETERR_NOERR;
  ICMP_STATE *pxIcmp = (ICMP_STATE *)hIcmp;
  ICMP_CHECK_STATE(pxIcmp);

  switch(oOption) {

  case NETOPTION_FREE:
    pxIcmp->pfnNetFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_MALLOC:
    pxIcmp->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    ASSERT((void*)hData != NULL);
    pxIcmp->pxMutex = (RTOS_MUTEX)hData;
    break;

  case NETOPTION_OFFSET:
    if ((hData & 0xFFFF) > pxIcmp->wOffset) {
      pxIcmp->wOffset = (WORD)(hData & 0xFFFF);
    }
    break;

  case NETOPTION_TRAILER:
    if ((hData & 0xFFFF) > pxIcmp->wTrailer) {
      pxIcmp->wTrailer = (WORD)(hData & 0xFFFF);
    }
    break;

  case NETOPTION_NETCBK:
    pxIcmp->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  default:
    lRv = NETERR_BADVALUE;
    ASSERT(0);
  }

  return lRv;
}

/*
 * IcmpInstanceMsg
 *  Send a msg to a ICMP instance
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *   oMsg                       Msg. See netcommon.h and icmp.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceMsg(H_NETINSTANCE hIcmp,
                     OCTET oMsg,
                     H_NETDATA hData)
{
  LONG lReturn = NETERR_NOERR;
  ICMP_STATE *pxIcmp = (ICMP_STATE *)hIcmp;

  ICMP_CHECK_STATE(pxIcmp);

  switch(oMsg) {
  case NETMSG_OPEN:
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
#ifdef _RADIX_ROUTING_ON_
    break;
#endif
  case NETMSG_LOWERLAYERDOWN:
#ifdef _RADIX_ROUTING_ON_
    {
      ICMPMSGDATA *pxIcmpMsgData = (ICMPMSGDATA *) hData;
      sbyte oSkipIcmp = 1;
      handleIcmpInstanceMsgToUL(ICMPERR_UNREACH_NET, pxIcmpMsgData);
    }
#endif
    break;

  case ICMPMSG_DONTREPLYTOPING:
    {
      OCTET oDontReplyToPing = (WORD)((DWORD)hData & 0xFFFF);
      OCTET oIfIdx = (OCTET) ((DWORD)hData >> 16);

      if (oDontReplyToPing == FALSE) {
        pxIcmp->wDontReplyToPing &= ~(1<<oIfIdx);
      }
      else {
        pxIcmp->wDontReplyToPing |= (1<<oIfIdx);
      }
    }
    break;

  case ICMPMSG_SENDFRAGNEEDED:
  case ICMPMSG_SENDPORTUNREACH:
  case ICMPMSG_SENDNETUNREACH:
  case ICMPMSG_SENDHOSTUNREACH:
  case ICMPMSG_SENDTIMEEXCEEDEDTTL:
  case ICMPMSG_SENDTIMEEXCEEDEDFRAGTIME:
  case ICMPMSG_SENDECHO:
#ifdef NEW_ICMP_MSG_ADDED
  case IPMSG_PROTOCOLUNREACHABLE:
  case ICMPMSG_REDIRECTHOST:
  case ICMPMSG_TIMESTAMPREQ:
#endif
    {
      ICMPMSGDATA *pxIcmpMsgData = (ICMPMSGDATA *)hData;
      NETPACKET_CHECK(pxIcmpMsgData->pxNetPacket);

      IcmpSendPacket(pxIcmp,
                     axIcmpMsgToDef[oMsg - ICMPMSG_BEGIN].oType,
                     axIcmpMsgToDef[oMsg - ICMPMSG_BEGIN].oCode,
                     pxIcmpMsgData);

    }
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}

/*
 * IcmpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
*/
H_NETINTERFACE IcmpInstanceLLInterfaceCreate(H_NETINSTANCE hIcmp)
{
  /* There will only be one interface: return anything >=0 */
  return 1;
}

/*
 * IcmpInstanceLLInterfaceDestroy
 *  Destroy a ICMP LL interface
 *
 *  Args:
 *   hIcmp                      ICMP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceLLInterfaceDestroy(H_NETINSTANCE hIcmp,
                                    H_NETINTERFACE hInterface)
{
  ICMP_CHECK_STATE((ICMP_STATE*) hIcmp);

  ASSERT(hInterface == 1);

  return NETERR_NOERR;
}

/*
 * IcmpInstanceLLInterfaceIoctl
 *  ICMP LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and netransport.h
 *  for precisions
 *
 *  Args:
 *   hIcmp                        Icmp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 success
 *   <=-1 error
 */
LONG IcmpInstanceLLInterfaceIoctl(H_NETINSTANCE hIcmp,
                                  H_NETINTERFACE hLLInterface,
                                  OCTET oIoctl,
                                  H_NETDATA hData)
{
  LONG lReturn = NETERR_NOERR;
  ICMP_STATE *pxIcmp = (ICMP_STATE *)hIcmp;

  switch(oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
    ASSERT(pxIcmp->pfnLLWrite != NULL);
  case NETINTERFACEIOCTL_CLOSE:
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxIcmp->hLLInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIcmp->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIcmp->hLLIf = (H_NETDATA)hData;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}

/*
 * IcmpInstanceRcv
 *   ICMP Instance Rcv function. Follows PFN_NETWORRXCBK
 *   typedef.
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG IcmpInstanceRcv(H_NETINSTANCE hIcmp,
                     H_NETINTERFACE hIf,
                     NETPACKET *pxNetPacket,
                     NETPACKETACCESS *pxNetPacketAccess,
                     H_NETDATA hData)
{
  ICMP_HDR *pxIcmpHdr;
  NETWORKID *pxNetworkId = (NETWORKID*)hData;
  ICMP_STATE *pxIcmp = (ICMP_STATE *)hIcmp;
  NETPAYLOAD *pxPayload;
  OCTET *poPayload;
  WORD wOffset;
  WORD wLength;
  ICMPCBKDATA xIcmpCbkData;
  PFN_NETCBK pfnNetCbk;
  H_NETDATA hCbkData;


  ICMP_CHECK_STATE(pxIcmp);
  NETPACKET_CHECK(pxNetPacket);
  ASSERT(pxNetPacketAccess != NULL);
  ASSERT(pxNetworkId != NULL);

  pxPayload = pxNetPacket->pxPayload;
  poPayload = pxPayload->poPayload;
  wOffset   = pxNetPacketAccess->wOffset;
  wLength   = pxNetPacketAccess->wLength;

  /*Set the pointer to the icmp packet*/
  pxIcmpHdr = (ICMP_HDR*)(poPayload + wOffset);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ICMP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ICMP_DBGP(REPETITIVE,"IcmpInstanceRcv, message of type : %d, and code : %d \n", pxIcmpHdr->oType, pxIcmpHdr->oCode);*/
    DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "IcmpInstanceRcv, message of type :", pxIcmpHdr->oType,
                        ", and code : ", pxIcmpHdr->oCode);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  SNMP(xTcpipData.icmpInMsgs++);

  /*Reject packet with a broadcast or multicast destination address */
  if( (pxNetworkId->eDstAddrType == IPADDRT_BROADCAST) ||
      (pxNetworkId->eDstAddrType == IPADDRT_MULTICASTJOINED) ||
      (Checksum16((OCTET*)pxIcmpHdr,wLength) != 0)){
    SNMP(xTcpipData.icmpInErrors++);
    NETPAYLOAD_DELUSER(pxPayload);
    return -1;
  }

  xIcmpCbkData.pxNetPacket       = pxNetPacket;
  xIcmpCbkData.pxNetPacketAccess = pxNetPacketAccess;
  xIcmpCbkData.pxNetworkId       = pxNetworkId;
#ifdef NEW_ICMP_MSG_ADDED
  xIcmpCbkData.pxIcmpHdr         = pxIcmpHdr;
#else
  xIcmpCbkData.oCode             = pxIcmpHdr->oCode;
#endif

  pfnNetCbk = pxIcmp->pfnNetCbk;
  ASSERT(pfnNetCbk != NULL);

  hCbkData = (H_NETDATA)&xIcmpCbkData;

  switch(pxIcmpHdr->oType){
  case ICMPTYP_ECHOREPLY:
    (LONG)pfnNetCbk((H_NETINSTANCE)pxIcmp,ICMPCBK_ECHOREPLY,hCbkData);
    SNMP( xTcpipData.icmpInEchoReps++ );
    return wLength;

  case ICMPTYP_DEST_UNREACH:
    (LONG)pfnNetCbk((H_NETINSTANCE)pxIcmp,ICMPCBK_DESTUNREACHABLE,hCbkData);
    SNMP( xTcpipData.icmpInDestUnreachs++);
    return wLength;

  case ICMPTYP_SOURCE_QUENCH:
    SNMP( xTcpipData.icmpInSrcQuenchs++;)
#ifdef NEW_ICMP_MSG_ADDED
   (LONG)pfnNetCbk((H_NETINSTANCE)pxIcmp,ICMPCBK_DESTUNREACHABLE,hCbkData);
#endif
    break;

  case ICMPTYP_REDIRECT:
    SNMP( xTcpipData.icmpInRedirects++);
    pfnNetCbk((H_NETINSTANCE)pxIcmp,ICMPCBK_REDIRECT,hCbkData);
    return wLength;

  case ICMPTYP_TIME_EXCEEDED:
    SNMP( xTcpipData.icmpInTimeExcds++);
#ifdef NEW_ICMP_MSG_ADDED
    pfnNetCbk((H_NETINSTANCE)pxIcmp, ICMPCBK_TIME_EXCEEDED, hCbkData);
#endif
    break;

  case ICMPTYP_ECHO:
    if(pxIcmpHdr->oCode != (OCTET)ICMPTYP_ECHOREPLY) {
      SNMP(xTcpipData.icmpInErrors++);
      NETPAYLOAD_DELUSER(pxPayload);
      return -1;
    }
    SNMP(xTcpipData.icmpInEchos++;)
    _IcmpRcvEchoRequest(pxIcmp,(ICMPCBKDATA *)hCbkData);
    return wLength;

  case ICMPTYP_PARAMETERPROB:
    SNMP(xTcpipData.icmpInParmProbs++;)
    break;

  case ICMPTYP_TIMESTAMP:
    SNMP(xTcpipData.icmpInTimestamps++;)
#ifdef NEW_ICMP_MSG_ADDED
    _IcmpRcvTimeStampRequest(pxIcmp, (ICMPCBKDATA *)hCbkData);
    return wLength;
#endif
    break;

  case ICMPTYP_TIMESTAMPREPLY:
    SNMP(xTcpipData.icmpInTimestampReps++;)
    break;

  case ICMPTYP_ADDRESS:
    SNMP(xTcpipData.icmpInAddrMasks++;)
    break;

  case ICMPTYP_ADDRESSREPLY:
    SNMP(xTcpipData.icmpInAddrMaskReps++;)
    break;

  default:
    SNMP(xTcpipData.icmpInErrors++);
    NETPAYLOAD_DELUSER(pxPayload);
    return -1;
  }

  NETPAYLOAD_DELUSER(pxPayload);

  return (LONG)wLength;
}

/*
 * _IcmpRcvEchoRequest
 *
 * Handle icmp echo reply
 *
 */

static void _IcmpRcvEchoRequest(ICMP_STATE *pxIcmp,
                                       ICMPCBKDATA *pxIcmpCbkData)
{
  ICMPMSGDATA xIcmpMsgData;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ICMP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ICMP_DBGP(REPETITIVE,"_IcmpRcvEchoRequest\n");*/
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_IcmpRcvEchoRequest");
  }

  if((pxIcmp->wDontReplyToPing &
      (1<<pxIcmpCbkData->pxNetworkId->oIfIdx)) != 0) {
    NETPAYLOAD_DELUSER(pxIcmpCbkData->pxNetPacket->pxPayload);
    return;
  }

  xIcmpMsgData.pxNetPacket       = pxIcmpCbkData->pxNetPacket;
  xIcmpMsgData.pxNetPacketAccess = pxIcmpCbkData->pxNetPacketAccess;
  xIcmpMsgData.oIfIdx            = pxIcmpCbkData->pxNetworkId->oIfIdx;
  xIcmpMsgData.wVlan             = pxIcmpCbkData->pxNetworkId->wVlan;
  xIcmpMsgData.dwDstAddr         = pxIcmpCbkData->pxNetworkId->dwSrcAddr;
  xIcmpMsgData.dwSrcAddr         = pxIcmpCbkData->pxNetworkId->dwDstAddr;

  (LONG)IcmpSendPacket(pxIcmp,
                       ICMPTYP_ECHOREPLY,
                       ICMPTYP_ECHOREPLY,
                       &xIcmpMsgData);

  return;
}

#ifdef NEW_ICMP_MSG_ADDED
/*
 * Handle Time Stamp Requests
 */

static void _IcmpRcvTimeStampRequest(ICMP_STATE *pxIcmp,
                                            ICMPCBKDATA *pxIcmpCbkData)
{
  ICMPMSGDATA xIcmpMsgData;
  NETPAYLOAD *pxPayload;
  ubyte *poPayload;
  WORD wOffset;
  ICMP_DATA *pxIcmpData;

  pxPayload   = pxIcmpCbkData->pxNetPacket->pxPayload;
  poPayload   = pxPayload->poPayload;
  wOffset     = pxIcmpCbkData->pxNetPacketAccess->wOffset;
  pxIcmpData  = (ICMP_DATA *)(poPayload + wOffset + sizeof(ICMP_HDR));

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_ICMP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*ICMP_DBGP(REPETITIVE,"_IcmpRcvTimeStampRequest\n");*/
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_IcmpRcvTimeStampRequest");
  }

  /*Fill up the current time stamps*/
  pxIcmpData->u_icmp_data.icmp_ts.wRxtime = (ubyte4)NetGetMsecTime();
  pxIcmpData->u_icmp_data.icmp_ts.wTtime  = pxIcmpData->u_icmp_data.icmp_ts.wRxtime;

  xIcmpMsgData.pxNetPacket       = pxIcmpCbkData->pxNetPacket;
  xIcmpMsgData.pxNetPacketAccess = pxIcmpCbkData->pxNetPacketAccess;
  xIcmpMsgData.oIfIdx            = pxIcmpCbkData->pxNetworkId->oIfIdx;
  xIcmpMsgData.wVlan             = pxIcmpCbkData->pxNetworkId->wVlan;
  xIcmpMsgData.dwDstAddr         = pxIcmpCbkData->pxNetworkId->dwSrcAddr;
  xIcmpMsgData.dwSrcAddr         = pxIcmpCbkData->pxNetworkId->dwDstAddr;

  (LONG)IcmpSendPacket(pxIcmp,
                       ICMPTYP_TIMESTAMPREPLY,
                       0,
                       &xIcmpMsgData);

  return;
}
#endif
