/*
 * ipsec_defs.h
 *
 * IPSec module common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __IPSEC_DEFS_H__
#define __IPSEC_DEFS_H__

/*****************************************************************************
 *
 * include
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "ipsec_flavor.h"
#include "stdlib.h"
#include "string.h"
#include "sys/socket.h"
#include "pthread.h"
#include "netutils.h"
#include "netcommon.h"
#include "netnetwork.h"
#include "nettransport.h"
#include "transportparser.h"
#include "iptable.h"
#include "ipsec.h"
#include "ipsec_dbg.h"
/*#include "ipsec_sadb.h" */
#include "ip.h"
#include "ethernet.h"
#include <netinet/in.h>
#include <sys/socket.h>
#include "cryptcommon.h"
#include "des.h"
#include "hmac_md5.h"
#include "ecc.h" /* Checksum16 */

/*****************************************************************************
 *
 * define
 *
 *****************************************************************************/


/*****************************************************************************
 *
 * Structures & Typedefs
 *
 *****************************************************************************/


/*
 * Ip1toN instance structure
 */
typedef struct {
  /* Basic structure override protection */
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

  /* LL modules */
  H_NETINSTANCE hLLInst;
  H_NETINTERFACE hLLIf;
  PFN_NETRXCBK pfnLLWrite;

  /* UL interface stuff */
  H_NETINSTANCE hULInst;
  H_NETINTERFACE hULIf;
  PFN_NETRXCBK pfnRxCbk;

  /* LAN I/F index */
  OCTET oIfIdxLan;

} IPSECSTATE;

/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/

int _IPSecSadbGetIPSecLen(struct spdb* pxSP);
int _IPSecSadbFree(struct sadb* pxSa);



#endif /* #ifndef __IPSEC_DEFS_H__ */
