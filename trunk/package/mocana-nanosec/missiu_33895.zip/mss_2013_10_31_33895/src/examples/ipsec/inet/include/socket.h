/*
 * socket.h
 *
 * Definitions for the Socket API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef socket_h
#define socket_h
#endif

