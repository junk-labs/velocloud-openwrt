/*
 * ipcp.c
 *
 * IPCP protocol
 *  Encapsulate the PPPCP instance and adds IPCP specific items
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * include
 *
 *****************************************************************************/

#include "ipcp_defs.h"

/*****************************************************************************
 *
 * global
 *
 *****************************************************************************/

IPCP_DBG_VAR(DWORD g_dwIpCpDebugLevel = 3);

/*****************************************************************************
 *
 * Local Functions
 *
 *****************************************************************************/

LONG IpcpInstanceCpCbk(H_NETINSTANCE hIpcp, OCTET oCbk, H_NETDATA hData)
{
  LONG lReturn = NETERR_NOERR;
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;
  ASSERT(pxIpCp != NULL);

  IPCP_DBGP(REPETITIVE,"IpcpInstanceCpCbk:hIpcp=%d,oCbk=%s,hData=%d\n",
           (int)hIpcp,
           ((oCbk >= NETCBK_MODULESPECIFICBEGIN) ?
           apoPppCpCbkString[oCbk - NETCBK_MODULESPECIFICBEGIN]:
           apoNetCbkString[oCbk]),
           (int)hData);


  switch(oCbk) {
  case PPPCPCBK_RXCONFREQ: /* Received a Conf Req */
    {
      PPPCPOPTIONFIELDS *pxOptions = ( PPPCPOPTIONFIELDS *)hData;
      OCTET *poPointer;
      OCTET *poLast;

      ASSERT(pxOptions != NULL);
      ASSERT(pxOptions->poRej == NULL);
      ASSERT(pxOptions->wRejLength == 0);
      ASSERT(pxOptions->poNak == NULL);
      ASSERT(pxOptions->wNakLength == 0);

      poPointer = pxOptions->poReq;
      poLast = pxOptions->poReq + pxOptions->wReqLength;

      while (poPointer < poLast) {
        E_IPCPPROTOPTION eType = IPCPPROTOPTIONGET_TYPE(poPointer);
        OCTET oLength = IPCPPROTOPTIONGET_LENGTH(poPointer);

        if (eType == IPCPPROTOPTION_IPADDRESS) {
          pxIpCp->dwRemoteIpAddr = IPCPPROTOPTIONGET_IPADDRESS(poPointer);
        }
        else if ((eType == IPCPPROTOPTION_PRIMARYDNS) ||
                 (eType == IPCPPROTOPTION_SCNDARYDNS)) {
          /* Do nothing : we don't care about the remote DNS  ... */
        }
        else {
          pxOptions->poRej =
            realloc(pxOptions->poRej,pxOptions->wRejLength + oLength);
          ASSERT(pxOptions->poRej != NULL);

          memcpy(pxOptions->poRej + pxOptions->wRejLength,
                 poPointer,oLength);
          pxOptions->wRejLength += oLength;
          lReturn = NETERR_UNKNOWN;
        }
        poPointer +=oLength;
      }
    }
  break;

  case PPPCPCBK_RXCONFNAK:
    {
      PPPCPOPTIONFIELDS *pxOptions = ( PPPCPOPTIONFIELDS *)hData;
      OCTET *poPointer;
      OCTET *poLast;

      ASSERT(pxOptions != NULL);
      ASSERT(pxOptions->poNak != NULL);

      poLast = pxOptions->poNak + pxOptions->wNakLength;
      poPointer = pxOptions->poNak;

      while(poPointer < poLast) {
        E_IPCPPROTOPTION eType = IPCPPROTOPTIONGET_TYPE(poPointer);
        OCTET oLength = IPCPPROTOPTIONGET_LENGTH(poPointer);

        if (eType == IPCPPROTOPTION_IPADDRESS) {
          pxIpCp->dwLocalIpAddr = IPCPPROTOPTIONGET_IPADDRESS(poPointer);
        }
        else if (eType == IPCPPROTOPTION_PRIMARYDNS) {
         pxIpCp->dwPrimaryDnsIpAddr =
           IPCPPROTOPTIONGET_PRIMARYDNS(poPointer);
        }
        else if (eType == IPCPPROTOPTION_SCNDARYDNS) {
          pxIpCp->dwScndaryDnsIpAddr =
            IPCPPROTOPTIONGET_PRIMARYDNS(poPointer);
        }
        poPointer += oLength;
      }
    }
  break;

  case PPPCPCBK_RXCONFREJ:
    {
      PPPCPOPTIONFIELDS *pxOptions = ( PPPCPOPTIONFIELDS *)hData;
      OCTET *poPointer;
      OCTET *poLast;

      ASSERT(pxOptions != NULL);
      ASSERT(pxOptions->poRej != NULL);

      poLast = pxOptions->poRej + pxOptions->wRejLength;
      poPointer = pxOptions->poRej;

      while(poPointer < poLast) {
        E_IPCPPROTOPTION eType = IPCPPROTOPTIONGET_TYPE(poPointer);
        OCTET oLength = IPCPPROTOPTIONGET_LENGTH(poPointer);

        if (eType == IPCPPROTOPTION_PRIMARYDNS) {
          pxIpCp->dwPrimaryDnsIpAddr = IPCPOPTIONDNS_NONE;
        }
        else if (eType == IPCPPROTOPTION_SCNDARYDNS) {
          pxIpCp->dwScndaryDnsIpAddr = IPCPOPTIONDNS_NONE;
        }

        poPointer += oLength;
      }
    }
  break;

  case PPPCPCBK_OPTIONCODE:
    {
      PPPCPOPTIONFIELDS *pxOptions = (PPPCPOPTIONFIELDS *)hData;

      pxOptions->wReqLength = IPCPPROTOPTIONLENGTH_IPADDRESS;

      if (pxIpCp->dwPrimaryDnsIpAddr != IPCPOPTIONDNS_NONE) {
        pxOptions->wReqLength += IPCPPROTOPTIONLENGTH_PRIMARYDNS;
      }
      if (pxIpCp->dwScndaryDnsIpAddr != IPCPOPTIONDNS_NONE) {
        pxOptions->wReqLength += IPCPPROTOPTIONLENGTH_SCNDARYDNS;
      }

      pxOptions->poReq = (OCTET *)malloc(pxOptions->wReqLength*sizeof(OCTET));
      ASSERT(pxOptions->poReq != NULL);

      IPCPPROTOPTIONSET_TYPE(pxOptions->poReq,IPCPPROTOPTION_IPADDRESS);
      IPCPPROTOPTIONSET_LENGTH(pxOptions->poReq,
                               IPCPPROTOPTIONLENGTH_IPADDRESS);
      IPCPPROTOPTIONSET_IPADDRESS(pxOptions->poReq,
                                  pxIpCp->dwLocalIpAddr);

      {
        OCTET *poPacketIdx = pxOptions->poReq + IPCPPROTOPTIONLENGTH_IPADDRESS;

        /* Primary DNS */
        if (pxIpCp->dwPrimaryDnsIpAddr != IPCPOPTIONDNS_NONE) {
          IPCPPROTOPTIONSET_TYPE(poPacketIdx,IPCPPROTOPTION_PRIMARYDNS);
          IPCPPROTOPTIONSET_LENGTH(poPacketIdx,
                                   IPCPPROTOPTIONLENGTH_PRIMARYDNS);
          IPCPPROTOPTIONSET_PRIMARYDNS(poPacketIdx,
                                       pxIpCp->dwPrimaryDnsIpAddr);

          poPacketIdx += IPCPPROTOPTIONLENGTH_PRIMARYDNS;
        }
        /* Secondary DNS */
        if (pxIpCp->dwScndaryDnsIpAddr != IPCPOPTIONDNS_NONE) {
          IPCPPROTOPTIONSET_TYPE(poPacketIdx,IPCPPROTOPTION_SCNDARYDNS);

          IPCPPROTOPTIONSET_LENGTH(poPacketIdx,
                                   IPCPPROTOPTIONLENGTH_SCNDARYDNS);
          IPCPPROTOPTIONSET_PRIMARYDNS(poPacketIdx,
                                       pxIpCp->dwScndaryDnsIpAddr);

        }
      }
    }
  break;


  case PPPCPCBK_RXUNKNOWNCODE:
  {
    PPPCPPACKET *pxPacket = (PPPCPPACKET *)hData;
    NETPAYLOAD_DELUSER(pxPacket->pxPacket->pxPayload);
    lReturn = NETERR_UNKNOWN;
  }
  break;

  default:
    /* Transmit the messages up */
    pxIpCp->pfnNetCbk(pxIpCp->hNetCbk,oCbk,hData);

  }

  return lReturn;
}
/*****************************************************************************
 *
 * API Functions
 *
 *****************************************************************************/

/*
 * IpcpInitialize
 *   Initialize the IPCP library. Must be called after PppCpInitialize
 *
 *   Args:
 *
 *   Return:
 *
 */
LONG IpcpInitialize(void)
{
  /* nothing to do */

  return NETERR_NOERR;
}

/*
 * IpcpTerminate
 *   Terminate the IPCP library
 *
 *   Args:
 *
 *   Return:
 *
 */
LONG IpcpTerminate(void)
{
  /* nothing to do */

  return NETERR_NOERR;
}

/*
 * IpcpInstanceCreate
 *   Create an IPCP instance
 *
 *   Args:
 *
 *   Return:
 *    instance handle
 */
H_NETINSTANCE IpcpInstanceCreate(void)
{
  IPCPSTATE *pxIpCp;

  pxIpCp = (IPCPSTATE*)calloc(1,sizeof(IPCPSTATE));
  ASSERT(pxIpCp != NULL);

  IPCP_SET_COOKIE(pxIpCp);

  /* PPP CP configuration */
  pxIpCp->hCp = PppCpInstanceCreate();
  pxIpCp->hCpIf = PppCpInstanceLLInterfaceCreate(pxIpCp->hCp);

  PppCpInstanceSet(pxIpCp->hCp,NETOPTION_NETCBK,
                   (H_NETDATA)IpcpInstanceCpCbk);
  PppCpInstanceSet(pxIpCp->hCp,NETOPTION_NETCBKHINST,(H_NETDATA)pxIpCp);

  pxIpCp->dwPrimaryDnsIpAddr = IPCPOPTIONDEFAULT_DNS;
  pxIpCp->dwScndaryDnsIpAddr = IPCPOPTIONDEFAULT_DNS;

  return (H_NETINSTANCE)pxIpCp;
}

/*
 * IpcpInstanceDestroy
 *   Destroy a IPCP instance
 *
 *   Args:
 *    hIpcp                 instance handle
 *
 *   Return:
 *
 */
LONG IpcpInstanceDestroy(H_NETINSTANCE hIpcp)
{
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;

  IPCP_CHECK_STATE(pxIpCp);
  IPCP_UNSET_COOKIE(pxIpCp);

  PppCpInstanceLLInterfaceDestroy(pxIpCp->hCp,pxIpCp->hCpIf);
  PppCpInstanceDestroy(pxIpCp->hCp);

  free(pxIpCp);

  return NETERR_NOERR;
}

/*
 * IpcpInstanceSet
 *   Set IPCP options
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceSet(H_NETINSTANCE hIpcp,OCTET oOption,
                      H_NETDATA hData)
{
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;
  IPCP_CHECK_STATE(pxIpCp);

  switch(oOption) {
  case NETOPTION_FREE:
  case NETOPTION_MALLOC:
  case NETOPTION_PAYLOADMUTEX:
  case NETOPTION_TRAILER:
  case NETOPTION_OFFSET:
    PppCpInstanceSet(pxIpCp->hCp,oOption,hData);
    break;

  case NETOPTION_NETCBK:
    pxIpCp->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case NETOPTION_NETCBKHINST:
    pxIpCp->hNetCbk = (H_NETINSTANCE)hData;
    break;

  case IPCPOPTION_IFIDX:
    PppCpInstanceSet(pxIpCp->hCp,PPPCPOPTION_IFIDX,hData);
    break;

  case IPCPOPTION_VLAN:
    PppCpInstanceSet(pxIpCp->hCp,PPPCPOPTION_VLAN,hData);
    break;

  case IPCPOPTION_LOCALIPADDR:
    pxIpCp->dwLocalIpAddr = (DWORD)hData;
    break;

  case IPCPOPTION_REMOTEIPADDR:
    pxIpCp->dwRemoteIpAddr = (DWORD)hData;
    break;

  case IPCPOPTION_PRIMARYDNS:
    pxIpCp->dwPrimaryDnsIpAddr = (DWORD)hData;
    break;

  case IPCPOPTION_SCNDARYDNS:
    pxIpCp->dwScndaryDnsIpAddr = (DWORD)hData;
    break;


  default:
    ASSERT(0);
  }

  return NETERR_NOERR;
}

/*
 * IpcpInstanceQuery
 *   Query IPCP options
 *
 *   Args:
 *     hIpcp            Handle to the instance to destroy
 *     oMsg             Option code
 *     phData           data handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceQuery(H_NETINSTANCE hIpcp,OCTET oOption,H_NETDATA * phData)
{
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;
  IPCP_CHECK_STATE(pxIpCp);

  switch(oOption) {
  case IPCPOPTION_LOCALIPADDR:
    *phData = (H_NETDATA)pxIpCp->dwLocalIpAddr;
    break;

  case IPCPOPTION_REMOTEIPADDR:
    *phData = (H_NETDATA)pxIpCp->dwRemoteIpAddr;
    break;

  case IPCPOPTION_PRIMARYDNS:
    *phData = (H_NETDATA)pxIpCp->dwPrimaryDnsIpAddr;
    break;

  case IPCPOPTION_SCNDARYDNS:
    *phData = (H_NETDATA)pxIpCp->dwPrimaryDnsIpAddr;
    break;

  default:
    break;
  }

  return NETERR_NOERR;
}

/*
 * IpcpInstanceMsg
 *   IPCP msg function
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceMsg(H_NETINSTANCE hIpcp,OCTET oMsg,H_NETDATA hData)
{
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;
  IPCP_CHECK_STATE(pxIpCp);

  PppCpInstanceMsg(pxIpCp->hCp,oMsg,hData);

  return NETERR_NOERR;
}

/*
 * IpcpInstanceLLInterfaceCreate
 *   Create IPCP LL interface
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE IpcpInstanceLLInterfaceCreate(H_NETINSTANCE hIpcp)
{
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;
  IPCP_CHECK_STATE(pxIpCp);

  ASSERT(pxIpCp->oLLNumber == 0);
  pxIpCp->oLLNumber = 1;

  return (H_NETINTERFACE)1;
}

/*
 * IpcpInstanceLLInterfaceDestroy
 *   Destroy IPCP LL interface
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceLLInterfaceDestroy(H_NETINSTANCE hIpcp, H_NETINTERFACE hIf)
{
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;
  IPCP_CHECK_STATE(pxIpCp);
  ASSERT(hIf == (H_NETINTERFACE)1);
  ASSERT(pxIpCp->oLLNumber == 1);
  pxIpCp->oLLNumber = 0;

  return NETERR_NOERR;
}

/*
 * IpcpInstanceLLInterfaceIoctl
 *   IPCP LL interface ioctl function
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceLLInterfaceIoctl(H_NETINSTANCE hIpcp, H_NETINTERFACE hIf,
                                  OCTET oIoctl,H_NETDATA hData)
{
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;
  IPCP_CHECK_STATE(pxIpCp);

  PppCpInstanceLLInterfaceIoctl(pxIpCp->hCp,pxIpCp->hCpIf,oIoctl,hData);

  return NETERR_NOERR;
}

/*
 * IpcpInstanceRcv
 *   IPCP instance rcv
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            NETIFID *
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceRcv(H_NETINSTANCE hIpcp, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;
  IPCP_CHECK_STATE(pxIpCp);

  return PppCpInstanceRcv(pxIpCp->hCp,pxIpCp->hCpIf,pxPacket,pxAccess,hData);
}

/*
 * IpcpInstanceProcess
 *   IPCP processing function
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG IpcpInstanceProcess(H_NETINSTANCE hIpcp)
{
  IPCPSTATE *pxIpCp = (IPCPSTATE *)hIpcp;
  IPCP_CHECK_STATE(pxIpCp);

  return PppCpInstanceProcess(pxIpCp->hCp);
}



