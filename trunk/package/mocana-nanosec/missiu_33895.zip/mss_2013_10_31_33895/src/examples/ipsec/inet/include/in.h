/*
 * in.h
 *
 * Definitions for the Socket API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef netinet_in_h
#define netinet_in_h

/***************************************************************************/
/*                             D E F I N E S                               */
/***************************************************************************/

/* Standard well-defined IP protocols.  */
enum {
  IPPROTO_IP = 0,        /* Dummy protocol for TCP        */
  IPPROTO_HOPOPTS = 0,        /* IPv6 Hop-by-Hop options.         */
  IPPROTO_ICMP = 1,        /* Internet Control Message Protocol    */
  IPPROTO_IGMP = 2,        /* Internet Group Management Protocol   */
  IPPROTO_GGP = 3,        /* Gateway-to-Gateway Protocol          */
  IPPROTO_IPIP = 4,        /* IP-in-IP (encapsulation: RFC-2003)   */
  IPPROTO_TCP = 6,        /* Transmission Control Protocol    */
  IPPROTO_EGP = 8,        /* Exterior Gateway Protocol        */
  IPPROTO_PUP = 12,        /* PUP protocol                */
  IPPROTO_UDP = 17,        /* User Datagram Protocol        */
  IPPROTO_IDP = 22,        /* XNS IDP protocol            */
  IPPROTO_IPV6 = 41,        /* IPv6 header.                */
  IPPROTO_ROUTING = 43,        /* IPv6 routing header.            */
  IPPROTO_FRAGMENT = 44,    /* IPv6 fragmentation header.        */
  IPPROTO_RSVP = 46,        /* Reservation Protocol.        */
  IPPROTO_ESP = 50,             /* IPSec Encapsulating Security Protocol*/
  IPPROTO_AH  = 51,             /* IPSec Authentication header          */
  IPPROTO_SWIPE  = 53,        /* IP with encryption             */
  IPPROTO_MOBILE  = 55,        /* IP mobility                */
  IPPROTO_TLSP  = 56,        /* Transport layer security protocol    */
  IPPROTO_ICMPV6 = 58,        /* ICMPv6.                */
  IPPROTO_NONE = 59,        /* IPv6 no next header.            */
  IPPROTO_ENCAP = 98,        /* Encapsulation Header.        */
  IPPROTO_PIM = 103,        /* Protocol Independent Multicast.    */
  IPPROTO_COMP = 108,        /* Compression Header Protocol.        */
  IPPROTO_RAW = 255,        /* Raw IP packets            */
  IPPROTO_MAX
};

/*
 * Definitions of the bits in an Internet address integer.
 * On subnets, host and network parts are found according
 * to the subnet mask, not these masks.
 */
#define    IN_CLASSA(a)        ((((int) (a)) & 0x80000000) == 0)
#define    IN_CLASSA_NET        0xff000000
#define    IN_CLASSA_NSHIFT    24
#define    IN_CLASSA_HOST        (0xffffffff & ~IN_CLASSA_NET)
#define    IN_CLASSA_MAX        128

#define    IN_CLASSB(a)        ((((int) (a)) & 0xc0000000) == 0x80000000)
#define    IN_CLASSB_NET        0xffff0000
#define    IN_CLASSB_NSHIFT    16
#define    IN_CLASSB_HOST        (0xffffffff & ~IN_CLASSB_NET)
#define    IN_CLASSB_MAX        65536

#define    IN_CLASSC(a)        ((((int) (a)) & 0xc0000000) == 0xc0000000)
#define    IN_CLASSC_NET        0xffffff00
#define    IN_CLASSC_NSHIFT    8
#define    IN_CLASSC_HOST        (0xffffffff & ~IN_CLASSC_NET)

#define    IN_CLASSD(a)        ((((int) (a)) & 0xf0000000) == 0xe0000000)
#define    IN_MULTICAST(a)        IN_CLASSD(a)

#define    IN_EXPERIMENTAL(a)    ((((int) (a)) & 0xe0000000) == 0xe0000000)
#define    IN_BADCLASS(a)        ((((int) (a)) & 0xf0000000) == 0xf0000000)

/* Address to accept any incoming messages. */
#define    INADDR_ANY        ((DWORD) 0x00000000)

/* Address to send to all hosts. */
#define    INADDR_BROADCAST    ((DWORD) 0xffffffff)

/* Address indicating an error return. */
#define    INADDR_NONE        0xffffffff

/* Network number for local host loopback.  */
#define IN_LOOPBACKNET          127
/* Address to loopback in software to local host.  */
#ifndef INADDR_LOOPBACK
# define INADDR_LOOPBACK        ((DWORD) 0x7f000001) /* Inet 127.0.0.1.  */
#endif

#define MULTICAST_ALLHOSTS_GROUP    "224.0.0.1"
#define MULTICAST_ALLROUTER_GROUP    "224.0.0.2"

/* IP options */
#define IP_MULTICAST_IF                 32
#define IP_MULTICAST_TTL                33
#define IP_MULTICAST_LOOP               34
#define IP_ADD_MEMBERSHIP               35
#define IP_DROP_MEMBERSHIP              36

#define IP_TOS                37
#define IPTOS_LOWDELAY            0x10
#define IPTOS_THROUGHPUT        0x08
#define IPTOS_RELIABILITY        0x04

#define IP_DEFAULT_MULTICAST_TTL        1
#define IP_DEFAULT_MULTICAST_LOOP       1
#define IP_MAX_MEMBERSHIPS              20

/***************************************************************************/
/*                  D A T A    S T R U C T U R E S                         */
/***************************************************************************/
typedef unsigned int   in_addr_t;   /* 32 bit */
typedef unsigned short in_port_t;   /* 16 bit */
typedef unsigned char  sa_family_t; /* 8 bit */

/* IPv4 Socket Address Structures */
struct in_addr {
    in_addr_t    s_addr;     /* 32 bit ip address */
};

struct sockaddr_in {
    unsigned char       sin_len;
    sa_family_t     sin_family;  /* AF_INET */
    in_port_t        sin_port;    /* 16 bit port number */
    struct in_addr     sin_addr;    /* 32 bit ip address */
    char               sin_zero[8]; /* Unused */
};

/* IPv6 Socket Address Structures */
struct in6_addr {
    unsigned char      s6_addr[16];     /* 128 bit IPv6 address */
};

struct sockaddr_in6 {
    unsigned char     sin6_len;     /* length of structure (24) */
    sa_family_t     sin6_family;  /* AF_INET6 */
    in_port_t        sin6_port;    /* 16 bit port number */
    unsigned long    sin6_flowinfo; /* priority and flow label */
    struct in6_addr     sin6_addr;    /* IPv6 address */
};

/* Structure for Multicast request */
struct ip_mreq {
  struct in_addr imr_multiaddr;
  struct in_addr imr_interface;
};

/***************************************************************************/
/*                       M A C R O S                                       */
/***************************************************************************/

/***************************************************************************/
/*           F U N C T I O N    P R O T O T Y P E S                        */
/***************************************************************************/
#endif

