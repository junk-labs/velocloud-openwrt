/*
 * dbg.c
 *
 * vars for debugging macro support
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "NNstyle.h"


/********************
 *
 * public variables
 *
 ********************/


int   dbg_nMarkLine = 0;
int   dbg_nChkPtLine = 0;
char  *dbg_pChkPtFile = NULL;
int   dbg_nPauseLine = 0;
char  *dbg_pPauseFile = NULL;
int   dbg_bPausePrint = TRUE;
int   dbg_bPauseHold = TRUE;
volatile int   dbg_nPauseGo = 0;
int   dbg_bPausing = FALSE;

ubyte2 g_aInetModDbg[INET_DBG_MOD_MAX];
ubyte2 g_aInetModDbgDflt[INET_DBG_MOD_MAX];

ubyte *g_aInetModDbgLevel[]=
{
    "off",
    "normal",
    "error",
    "repetitive",
    "detail"
};

ubyte *g_aInetModDbgStr[]=
{
    "udp",
    "tcp",
    "icmp",
    "igmp",
    "ip",
    "eth",
    "arp",
    "ip2eth",
    "ip1ton",
    "router",
    "nat",
    "ipsec",
    "ipfrag",
    "iptable",
    "ppp",
    "ppcp",
    "ipcp",
    "chap",
    "dns",
    "socket",
    "rttable",
    "intf",
    "meter",
};

/********************************************************************
 *
 * Private Functions
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Public Functions
 *
 ********************************************************************/

 /* none */






