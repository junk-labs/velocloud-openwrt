/*
 * inet_common.h
 *
 * Mocana IP Stack Header files.
 *
 * Copyright Mocana Corp 2003-2006. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*------------------------------------------------------------------*/

#ifndef __INET_COMMON_HEADER__
#define __INET_COMMON_HEADER__

#include "../../inet/common/dllist/dllist.h"
#endif /* __INET_COMMON_HEADER__ */
