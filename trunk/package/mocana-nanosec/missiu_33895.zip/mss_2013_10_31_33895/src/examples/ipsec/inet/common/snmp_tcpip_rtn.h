/*
 * snmp_tcpip_rtn.h
 *
 * SNMP TCPIP common defines & functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _SNMP_TCPIP_RTN_H_
#define _SNMP_TCPIP_RTN_H_

#include "snmp_tcpip_data.h"

/****************************************************************************
 *
 * defines
 *
 ****************************************************************************/

/*
 * Media types
 */
#define MediaTypeOther   1
#define MediaTypeInvalid 2
#define MediaTypeDynamic 3
#define MediaTypeStatic  4

/*
 * Ethernet link status
 */
#define IfLinkUp      1
#define IfLinkDown    2
#define IfLinkTesting 3

/*
 * TCP states
 */
#define TCPStateClosed         1
#define TCPStateListen         2
#define TCPStateSynSent        3
#define TCPStateSynReceived    4
#define TCPStateEstablished    5
#define TCPStateFinWait1       6
#define TCPStateFinWait2       7
#define TCPStateCloseWait      8
#define TCPStateLastAck        9
#define TCPStateClosing       10
#define TCPStateTimeWait      11
#define TCPStateDeleteTCB     12



/****************************************************************************
 *
 * Function prototypes
 *
 ****************************************************************************/
#ifndef NDEBUG
void PrintArpTable(struct ARP_TABLE_ENTRY *pxTable, int iNosRows);
void PrintAdEntTable(struct ADD_ENT_TABLE_ENTRY *pxTable, int iNosRows);
void PrintudpTable(struct UDP_TABLE_ENTRY *pxTable, int iNosRows);
void PrintTcpTable(struct TCPCONN_TABLE_ENTRY *pxTable, int iNosRows);
void PrintNet2MediaTable(struct NETTOMEDIA_TABLE_ENTRY *pxTable, int iNosRows);
#endif


#endif /* #ifndef _SNMP_TCPIP_RTN_H_ */
