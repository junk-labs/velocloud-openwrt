/*
 * nat_alg.c
 *
 * Routines to handle ALG support.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "nat.h"
#include "nat_defs.h"


/*****************************************************************************
Function:
        NatRegisterAlg()
Description:
        Registers an ALG for the given port. The ALG functionality
        will be invoked whenever the source or destination port
        in the packet matches the port for which the ALG is
        registered.
Arguments:
        NATSTATE*       pxNat                   NAT instance handle.
        WORD            wPort                   Port number to be watched.
        PFN_ALGPROCESS  pfnAlgProcess           Handler to be invoked
                                                for packets to/from the
                                                registered port.
Outputs:
        None
Returns:
        LONG            NAT_REG_ALG_OK          Registration successful.
                        NAT_REG_ALG_FULL        ALG registration table
                                                is full.
                        NAT_REG_ALG_EXISTS      Given port has already
                                                been registered.
Revisions:
        27-Oct-2001                             Initial
*****************************************************************************/
LONG NatRegisterAlg(NATSTATE* pxNat,
                    WORD wPort,
                    PFN_ALGPROCESS pfnAlgProcess)
{
  int i;

  if (pxNat->oNumAlg == NAT_MAX_NUM_ALG) {
    /*
     * ALG table full, NAT_MAX_NUM_ALG should be increased.
     */
    return (NAT_REG_ALG_FULL);
  }

  /*
   * Look for an already existing ALG on the given port.
   */
  for (i = 0; i < pxNat->oNumAlg; i++) {

    if (pxNat->axAlg[i].wPort == wPort) {
      return (NAT_REG_ALG_EXISTS);
    }
  }

  ASSERT(pxNat->axAlg[pxNat->oNumAlg].bInUse == FALSE);

  pxNat->axAlg[pxNat->oNumAlg].bInUse = TRUE;
  pxNat->axAlg[pxNat->oNumAlg].wPort = wPort;
  pxNat->axAlg[pxNat->oNumAlg].pfnAlgProcess = pfnAlgProcess;

  pxNat->oNumAlg ++;
  ASSERT(pxNat->oNumAlg <= NAT_MAX_NUM_ALG);

  return (NAT_REG_ALG_OK);
}


/*****************************************************************************
Function:
        NatUnregisterAlg()
Description:
        Unregsters an ALG. The specified port should have been
        previously registered using NATRegisterALG().
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        WORD            wPort           Port number to be unregistered.
Outputs:
        None
Returns:
        None
Revisions:
        27-Oct-2001                     Initial
*****************************************************************************/
void NatUnregisterAlg(NATSTATE* pxNat, WORD wPort)
{
  int i;

  for (i = 0; i < pxNat->oNumAlg; i++) {

    if (pxNat->axAlg[i].wPort == wPort) {
      pxNat->axAlg[i].bInUse = FALSE;

      pxNat->oNumAlg --;
      ASSERT ((CHAR) pxNat->oNumAlg >= 0);

      if (pxNat->oNumAlg != i) {
        MOC_MEMCPY((ubyte *) &pxNat->axAlg[i],
               (ubyte *) &pxNat->axAlg[i + 1],
               ((pxNat->oNumAlg - i) * sizeof(NAT_ALG)));
      }

      return;
    }
  }

  /*
   * ALG not found, error.
   */
  return;
}


/*****************************************************************************
Function:
        NatPortForwardAlg()
Description:
        ALGs can request dynamic port forwarding. This function
        handles that. The return value is a remapped port number.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        DWORD           dwLanIp         IP Address of LAN host.
        WORD            wPort           Port number to be forwarded.
        DWORD           dwTransIp       Translated IP, i.e IP address
                                        of the WAN leg on which the
                                        connection should be expected.
        OCTET           oIfIdx          Interface index.
        OCTET           oProtocol       Transport layer protocol.
                                        Could be TCP or UDP.
Outputs:
        None
Returns:
        WORD            0               Failure.
                        > 0             Remapped port.
Revisions:
        27-Oct-2001                     Initial
*****************************************************************************/
WORD NatPortForwardAlg(NATSTATE* pxNat, DWORD dwLanIp, WORD wPort,
                       DWORD dwTransIp, OCTET oIfIdx,
                       OCTET oProtocol)
{
  NAT_ENTRY* pxNatEntry;

  pxNatEntry = NatFindTUBindingTx(pxNat, dwLanIp, wPort, 0, 0, oProtocol);
  if (pxNatEntry) {
    return (pxNatEntry->u.xTUMapping.wTransPort);
  }

  pxNatEntry = NatCreateBindingTU(pxNat,
                                  0, 0,
                                  dwLanIp, wPort,
                                  dwTransIp, 0, oIfIdx,
                                  oProtocol, NAT_BINDING_L2W);
  /*
   * NOTE: Although, these bindings should be technically W2L
   *       bindings, they have been faked to look like a L2W
   *       so that we get a translated port number.
   */

  if (pxNatEntry) {
    return (pxNatEntry->u.xTUMapping.wTransPort);
  }

  return (0);
}


/*****************************************************************************
Function:
        NatFindAlg()
Description:
        For the given source and destination port numbers, finds out
        if an ALG is registered. If yes, returns the appropriate
        NAT_ALG handle.
Arguments:
        NATSTATE*       pxNat           NAT instance handle.
        WORD            wSrcPort        Source port number in the packet.
        WORD            wDstPort        Destination port number in the packet.
Outputs:
        None
Returns:
        NAT_ALG*        non-NULL        NAT_ALG handle if an ALG is
                                        registered.
                        NULL            If no ALG registration matches.
Revisions:
        27-Oct-2001                     Initial
*****************************************************************************/
NAT_ALG* NatFindAlg(NATSTATE* pxNat, WORD wSrcPort, WORD wDstPort)
{
  int i;

  for (i = 0; i < pxNat->oNumAlg; i++) {

    if ((pxNat->axAlg[i].wPort == wSrcPort) ||
        (pxNat->axAlg[i].wPort == wDstPort)) {
      return (&pxNat->axAlg[i]);
    }
  }

  /*
   * No registered ALG for the given ports.
   */
  return (NULL);
}


/*****************************************************************************
Function:
        NatCalcTUCheksumAlg()
Description:
        Given the IP header, the protocol header and the size of
        the packet, this routine calculates TCP/UDP style
        checksum. It is assumed that the payload immediately
        follows the protocol header.
Arguments:
        void*           pvProtocolHdr   Protocol (TCP/UDP) header.
        DWORD           dwSrcAddr       Source IP in the packet.
        DWORD           dwDstAddr       Dest IP in the packet.
        OCTET           oProtocol       Transport Layer protocol id.
        DWORD           dwLength        Size of the data which
                                        includes the TCP/UDP
                                        header and payload.
Outputs:
        WORD*           pwChecksum      The checksum field in
                                        the transport header is
                                        modified in place.
Returns:
        None
Revisions:
        27-Oct-2001                     Initial
        26-Mar-2001                     API change
*****************************************************************************/
void NatCalcTUChecksumAlg(void* pvProtocolHdr,
                          DWORD dwSrcAddr,
                          DWORD dwDstAddr,
                          OCTET oProtocol,
                          DWORD dwLength)
{
  WORD wChecksum;
  TCPPSH xPseudoHdr;
  OCTET* poTemp;

  wChecksum = (oProtocol == IPPROTO_TCP) ?
              (TCP_GET_CHECKSUM((TCPHDR*) pvProtocolHdr)) :
              (UDP_GET_CHECKSUM((UDPHDR*) pvProtocolHdr));

  if ((oProtocol == IPPROTO_UDP) && (wChecksum == 0))
    return;

  poTemp = (OCTET*) MALLOC(sizeof(TCPPSH) + dwLength);
  ASSERT(poTemp);

  /*
   * Create psuedo header
   */
  xPseudoHdr.dwSrcIP = dwSrcAddr;
  xPseudoHdr.dwDstIP = dwDstAddr;
  xPseudoHdr.oNull = 0;
  xPseudoHdr.oProt = oProtocol;
  xPseudoHdr.wLen = (WORD) dwLength;

  MOC_MEMCPY((ubyte *)poTemp,(ubyte *) &xPseudoHdr, sizeof(TCPPSH));


  /*
   * Set the checksum field to 0 for the purpose
   * of checksum calculation.
   */
  (oProtocol == IPPROTO_TCP) ?
  (TCP_SET_CHECKSUM((TCPHDR*) pvProtocolHdr, 0x0)) :
  (UDP_SET_CHECKSUM((UDPHDR*) pvProtocolHdr, 0x0));

  MOC_MEMCPY((ubyte *)(poTemp + sizeof(TCPPSH)),
            (ubyte *) pvProtocolHdr, dwLength);
  wChecksum = Checksum16((OCTET*) poTemp, (sizeof(TCPPSH) + dwLength));

  /*
   * Generate TCP/UDP checksum including the pseudoheader
   */
  (oProtocol == IPPROTO_TCP) ?
  (TCP_SET_CHECKSUM((TCPHDR*) pvProtocolHdr, wChecksum)) :
  (UDP_SET_CHECKSUM((UDPHDR*) pvProtocolHdr, wChecksum));

  FREE(poTemp);
}
