 /* ethlink.c
 *
 * ethernet link handling API shields any ethernet specific issues
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include <mqueue.h>
#include "netdb.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/if_types.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "netdefs.h"
#include "netconfig.h"
#include "netmain.h"
#include "ethernet.h"
#include "netif.h"
#include "ethlink.h"
#include "linkconf.h"

#include "mn_ndi.h"

/****************************************************************************
 *
 * API function
 *
 ****************************************************************************/

/*
 * EthLinkSetup
 *  ethernet specific driver opening setups
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   >=0 for success
 */
LONG EthLinkSetup(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hEth;
  int iFd,iRv;
  const OCTET aoAllHostGroupHwAddr[6] = {0x01,0x00,0x5e,0x00,0x00,0x01};

  /* NETMAIN_DBGP(NORMAL,"EthLinkSetup:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx); */
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL))
  {
          DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,
                                "EthLinkSetup:pxIfConf=0x",pxIfConf);
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,",oIfIdx=",oIfIdx);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, " ");
  }

  NETMAIN_ASSERT((pxIfConf != NULL) &&
                 (pxIfConf->ePhyLinkType == ETH));

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  /* Driver name sttings */
  if(oIfIdx == 0){
    (void*)MOC_MEMCPY((ubyte *)pxIfConf->acIfName,
                  (ubyte *)ETHERNET_DRIVERNAME0,
                  IF_NAMESIZE);
  }
#ifdef MHX
  else if(oIfIdx == 1){
    (void*)MOC_MEMCPY((ubyte *)pxIfConf->acIfName,
                  (ubyte *)ETHERNET_DRIVERNAME1,
                  IF_NAMESIZE);
  }
  else {
#if 0 /* RS removed assertion to support multiple interfaces */
    NETMAIN_ASSERT(0);
#endif
  }
#endif /*#ifdef MHX*/

#if 0
  pxIfConf->iFd = open(pxIfConf->acIfName,O_RDWR);
  ASSERT(pxIfConf->iFd > 0);
#else
  (((MnDeviceInstanceConf_t *)pxIfConf->pMnDeviceInstance)->MnDeviceInfo->MnDeviceCallbackFns.funcPtr_MnDeviceInstanceStart)(oIfIdx);
#endif

  hEth = NETGETINST_ETH;
  iFd = pxIfConf->iFd;
#ifndef LINK_AGGREGATION   /* move to EthConfSetup() */
  pxIfState->hBottomLinkIf = NETGETIF_ETHLL(pxIfState);
  pxIfState->hBottomLinkInst = hEth;
  pxIfState->pfnBottomLinkRxCbk = EthInstanceRcv;
  pxIfState->pfnBottomLinkLlIfIoctl = EthInstanceLLInterfaceIoctl;
#endif

/* Don't need to setup mac address..we get it from driver
      configuration.
*/

#if 0

/*
 The following ioctls will be changed to device Ioctls
*/
  /*Set mac address*/
  iRv = ioctl(pxIfConf->iFd,ETHERDRV_SET_MAC_ADDRESS, pxIfConf->aoHWAddr);
  /* ASSERT(iRv == 0); */

  /*Enable all host group multicast packet*/
  iRv = ioctl(iFd,ETHERDRV_ADD_MULTICAST,aoAllHostGroupHwAddr);
  /*ASSERT(iRv == 0); */

#ifdef NET_BR
  /* When in bridged mode, disable any filtering in the MAC */
  iRv = ioctl(iFd,(int) ETHERDRV_SET_ARC_CTL, (DWORD)ETHERDRV_AC_PROMISCUOUS);
  /*ASSERT(iRv == 0); */
#endif

  iRv = ioctl(iFd,(int) ETHERDRV_RX_OFFSET,NETRXOFFSET);
  /*ASSERT(iRv == 0); */
  iRv = ioctl(iFd,(int) ETHERDRV_RX_TRAILER,NETRXTRAILER);
  /*ASSERT(iRv == 0); */

  /* Sets up the local loopback */
  if (OK == ioctl(iFd,ETHERDRV_HW_LOOPBACK, ETHERDRV_LB_OFF)) {
    EthInstanceMsg(hEth,ETHMSG_LOCALLOOPBACK,(H_NETDATA)TRUE);
  }
  iRv = ioctl(iFd,(int) ETHERDRV_DATA_LINK_ENABLE);
  /*ASSERT(iRv == 0); */
#endif

#if 0
/* Do not send the fake packets. */
  {
    struct timespec xTimespec = {1,0}; /* 1s */
    NET_DRV_BUFFER xndbTxPacket;
    DLLIST xdllTx;
    DWORD wLength = 1000;

    init_DLLIST(&xdllTx);
    DLLIST_append(&xdllTx,&xndbTxPacket);

    xndbTxPacket.dwLength = wLength;
    xndbTxPacket.wSize = wLength;
    xndbTxPacket.wOffset = 0;
    xndbTxPacket.poData = (OCTET *) MALLOC(wLength *sizeof(OCTET));
    ASSERT(xndbTxPacket.poData != NULL);
    xndbTxPacket.pfnFree = NetFree;

    write(iFd,(char *)(&xdllTx),(int)wLength);

    nanosleep(&xTimespec,NULL);

    /* send a second fake packet */
    xndbTxPacket.poData = (OCTET *) MALLOC(wLength * sizeof(OCTET));
    ASSERT(xndbTxPacket.poData != NULL);

    write(iFd,(char *)(&xdllTx),(int)wLength);

    nanosleep(&xTimespec,NULL);

    clear_DLLIST(&xdllTx,NULL);
  }
#endif

  return NETERR_NOERR;
}

