/*
 * tcp.h
 *
 * TCP module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _TCP_H_
#define _TCP_H_

#ifdef NEW_ICMP_MSG_ADDED
#include "nettransport.h"
#endif

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

#define TCPCONN_FLAGMASK_FLAGS      0x3F
#define TCPCONN_FLAGMASK_FIN        0x1
#define TCPCONN_FLAGMASK_SYN        0x2
#define TCPCONN_FLAGMASK_RST        0x4
#define TCPCONN_FLAGMASK_PSH        0x8
#define TCPCONN_FLAGMASK_ACK        0x10
#define TCPCONN_FLAGMASK_URG        0x20
#define TCPCONN_FLAGMASK_PASOPEN    0x40 /* Passive open */

/*
 * TCP wide default
 */
#define TCPDEFAULT_2MSLTIMER       120 /* 120 seconds */
#define TCPDEFAULT_RTTTIMER        2  /* * 500ms = 1000 ms */
#define TCPDEFAULT_PERSISTIMER     3  /* * 500ms = 1500 ms */
#define TCPDEFAULT_KEEPALIVETIMER  0    /* == Not used */
#ifndef __TCP_OPT_ON__
#define TCPDEFAULT_MAXCONNNECTION  50000
#else
#define TCPDEFAULT_MAXCONNNECTION  30
#endif
#define TCPDEFAULT_HDRSIZE         20

/*
 * TCP UL INTERFACE default
 */
#define TCPULINTERFACEDEFAULT_MSS             536 /* bytes */
#define TCPULINTERFACEDEFAULT_WIN             1072 /* bytes */
#define MAX_TCP_WINDOW_SIZE                   (6 * MAX_TCP_SEGMENT_SIZE)

/*
 * Tcp UL Interface specific Ioctl
 *  A TCP UL interface corresponds to a connection (== socket).
 *  Connection may be listening (passive open), or
 *  Connecting (active open).
 *  Listening Connections, upon receiving SYN message (=>Active
 *  connect from peer), will "fork" and inform the management when the
 *  son connection is established through the interface Cbk defined below.
 *  The original connection will remain in a listen state.
 *  The RxCbk provided to a TCP UL interface will be given the TRANSPORT_ID
 *  of the remote-end as OoB data (see PFN_NETRXCBK def)
 */
/*
 * Connection Maximum segment size.
 *  Default == 536 bytes (RFC 793). Option Data is a WORD
 */
#define TCPULINTERFACEIOCTL_SETMSS \
  NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN
/*
 * Set Maximum Window size.
 * Size of the reassembly buffer. Default is 536. Option Data is a WORD
 */
#define TCPULINTERFACEIOCTL_SETWIN \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 1)
/*
 * Set the socket to the Listen Mode.
 * Note: this is not a Reversible setting. A listening socket will stay
 * listening for ever.
 */
#define TCPULINTERFACEIOCTL_LISTEN \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 2)
/*
 * Set the interface Cbk function.
 * Data is PFN_TCPULINTERFACECBK
 */
#define TCPULINTERFACEIOCTL_SETMSGCBK \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 3)
/*
 * Query the conection MSS. \
 * data is WORD *
 */
#define TCPULINTERFACEIOCTL_QUERYMSS \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 4)
/*
 * Query the connection window size
 * data is WORD *
 */
#define TCPULINTERFACEIOCTL_QUERYWIN \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 5)
/*
 * Query the header size.
 * data is WORD *
 */
#define TCPULINTERFACEIOCTL_QUERYHDRS \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 6)
/*
 * All PDU will have the PUSH flag set according to the data BOOL
 * (TRUE==PUSH), from then on
 */
#define TCPULINTERFACEIOCTL_SETPUSH \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 7)
/*
 * All PDU will have the URG flag set according to the data BOOL
 * (TRUE==URG) , from then on
 */
#define  TCPULINTERFACEIOCTL_SETURG \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 8)
/*
 * Abort the TCP connection by sending a RST
 */
#define  TCPULINTERFACEIOCTL_ABORT \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 9)
/*
 * Close the sendind side of a connection
 *  by sending a FIN to the remote end
 */
#define TCPULINTERFACEIOCTL_SHUTTX \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 10)

/*
 * Return the length of data ready to be read from TCP
 */
#define TCPULINTERFACEIOCTL_GETRXDATALENGTH \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 11)

/*
 * Get received TCP data
 */
#define TCPULINTERFACEIOCTL_GETRXDATA \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 12)

/*
 * Get received paylaod of TCP data
 */
#define TCPULINTERFACEIOCTL_GETRXDATA_PAYLOAD \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 13)

/*
 * Get available Tx data space
 */
#define TCPULINTERFACEIOCTL_GETTXAVAILSPACE \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 14)

/*
 * Set least reassembly unit
 * 0 (default) no action
 * 1 forward every segment
 * x forward when aggregate size >= x
 */
#define TCPULINTERFACEIOCTL_SETLRBLYU \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 15)

/*
 * Set reassembly timeout
 * 0 (default) no action
 * x forward when no rx after x msec.
 */
#define TCPULINTERFACEIOCTL_SETRBLYTO \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 16)

#ifndef __TCP_OPT_ON__
/*
 * Set Socket Fd Value
 */
#define TCPULINTERFACEIOCTL_SETFD \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 17)
#endif
/*
 * Get Remote MSS
 */
#define TCPULINTERFACEIOCTL_QUERYREMOTEMSS \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 18)
/*
 * Change Advertized Window
 * Values are Full/75%/50%/25%/0
 */
#define TCPULINTERFACEIOCTL_CHANGERXWIN \
  (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN  + 19)
/*
 * TCP LL Ioctls
 *  o All are covered in netcommon.h (LIBNETCOMMON) and
 *    nettransport.h (LIBNETTRANSPORT)
 *  o he PFN_NETWRITE provided with
 *    NETINTERFACEIOCTL_SETOUTPUTPFN will be given as hDstId a pointer
 *    to a TRANSPORT2NETWORKID (See nettransport.h for type definition)
 */



/*
 * TCP Instance Options
 *
 *  Note: TCPOPTION_NAGLE,
 *   TCPOPTION_2MSLTIMER, TCPOPTION_RTTIMER, TCPOPTION_PERSISTTIMER,
 *   TCPOPTION_KEEPALIVETIMER, TCPOPTION_MTUDISCOVERY, are set for
 *   the instance and not on a Connection (== socket == UL Interface) basis.
 *   At this stage (SB: Jul-2001) we do not think it is a problem.
 */
#define TCPOPTION_2MSLTIMER \
 (NETOPTION_MODULESPECIFICBEGIN) /* MSL Timer value, in ms. Default
                                        is 30 sec */
#define TCPOPTION_RTTIMER \
  (NETOPTION_MODULESPECIFICBEGIN + 1) /* Retransmission Timer initial
                                             value in ms. Each
                                             Connection will have its
                                             own freely evolving
                                             copy. Default 1 sec */
#define TCPOPTION_PERSISTTIMER \
  (NETOPTION_MODULESPECIFICBEGIN + 2) /* Persist timer in ms. Default is
                                             1.5 sec */
#define TCPOPTION_KEEPALIVETIMER \
  (NETOPTION_MODULESPECIFICBEGIN + 3)/* Keep Alive Timer. Default is 0
                                            which means that it is not used */
#define TCPOPTION_NAGLE \
  (NETOPTION_MODULESPECIFICBEGIN + 4) /* Uses Nagle algorithm. Default is
                                             No. Option Data is a BOOL
                                            !!! NOT SUPPORTED YET !!!*/
#define TCPOPTION_MTUDISCOVERY \
  (NETOPTION_MODULESPECIFICBEGIN + 5)/* Uses MTU discovery. Default is No.
                                            Option data is a BOOL
                                            !!! NOT SUPPORTED YET !!!*/
#define TCPOPTION_MAX \
  (NETOPTION_MODULESPECIFICBEGIN + 6)

#ifdef NEW_ICMP_MSG_ADDED
/*
 * TCP Specific callbacks
*/
#define TCPCBK_DSTUNREACHABLE \
  (NETCBK_MODULESPECIFICBEGIN)     /*TCP unreachable. Data is TCP_CBKDATA*/

/*
 * TCP Instance Message options
*/
#define TCPMSG_BEGIN \
          (NETNETWORKMSG_MODULESPECIFICBEGIN)
#define TCPMSG_ICMPERRORS \
          (TCPMSG_BEGIN + 1)
#endif

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * Tcp headers (for transportparser).
 */

/*
 * TCP header
 */
typedef struct {
  WORD  wSrcPort;
  WORD  wDstPort;
  DWORD dwSequencenumber;
  DWORD dwAcknowledgenumber;
  OCTET oTcpHdrLen;
  OCTET oFlags;
  WORD  wWindowsize;
  WORD  wChecksum;
  WORD  wUrgent;
} TCPHDR;

/*
 * TCP pseudo-header
 */
typedef struct {
  DWORD dwSrcIP;
  DWORD dwDstIP;
  OCTET oNull;
  OCTET oProt;
  WORD  wLen;
} TCPPSH;

#ifdef NEW_ICMP_MSG_ADDED
/*
 * TCP Cbk data definition
 */
typedef struct
{
  NETPACKET *pxNetPacket;
  NETPACKETACCESS *pxNetPacketAccess;
  TRANSPORTID xId;
} TCPCBKDATA;
#endif

/*
 * Tcp Interface Cbk Msgs
 */
typedef enum {
  TCPULINTERFACECBK_OPENED,  /* An interface is opened. If it is
                                a connect interface, it means the
                                connection to the remote end has succeeded*/
  TCPULINTERFACECBK_FORKED, /* A listen interface has forked. Data is
                               the interface handle. To get the IP and
                               port of the remote peer, one must query them
                               through the Coresponding Ioctl */
  TCPULINTERFACECBK_RST,        /* Connection has been reset */
  TCPULINTERFACECBK_TIMEDOUT,   /* Connection has timed out */
  TCPULINTERFACECBK_HALFCLOSED, /* Remote end has closed. See TCP RFC */
  TCPULINTERFACECBK_CLOSED,     /* result of a CLOSE Ioctl */
  TCPULINTERFACECBK_TXAVAILSPACE, /* tx space has become available */

  TCPULINTERFACECBK_RX_ERRS,   /* Problems in recv packets */
  TCPULINTERFACECBK_TX_ERRS,   /* Problems to transmit packets */

  TCPULINTERFACECBK_PASSIVECLOSE,   /* RST in SYN-RCV state in PASSIVE mode*/

  TCPULINTERFACE_ENUMMAX
} E_TCPULINTERFACECBK;


/*
 * Interface Call back
 */
typedef LONG (*PFN_TCPULINTERFACECBK) (H_NETINSTANCE,
                                       H_NETINTERFACE,
#ifndef __TCP_OPT_ON__
                                       LONG lFd,
#endif
                                       E_TCPULINTERFACECBK,
                                       H_NETDATA hData);
/*
 * Call back return codes
 */
#define TCPERR_FORKEDFAILED NETERR_MODULESPECIFICBEGIN

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * TcpInitialize
 *  Initialize the Tcp Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG TcpInitialize(void);

/*
 * TcpTerminate
 *  Terminate the Tcp Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG TcpTerminate(void);

/*
 * TcpInstanceCreate
 *  Creates a TCP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE TcpInstanceCreate(void);

/*
 * TcpInstanceDestroy
 *  Destroy a TCP Instance
 *
 *  Args:
 *   hTcp                       TCP instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG TcpInstanceDestroy(H_NETINSTANCE hTcp);

/*
 * TcpInstanceSet
 *  Set a TCP Instance Option
 *
 *  Args:
 *   hTcp                       TCP instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG TcpInstanceSet(H_NETINSTANCE hTcp,OCTET oOption,
                    H_NETDATA hData);

/*
 * TcpInstanceQuery
 *  Query a TCP Instance Option
 *
 *  Args:
 *   hTcp                       TCP instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG TcpInstanceQuery(H_NETINSTANCE hTcp,OCTET oOption,
                      H_NETDATA *phData);


/*
 * TcpInstanceMsg
 *  Send a msg to a TCP instance
 *
 *  Args:
 *   hTcp                       TCP instance
 *   oMsg                       Msg. See netcommon.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG TcpInstanceMsg(H_NETINSTANCE hTcp,OCTET oMsg,
                    H_NETDATA hData);


/*
 * TcpInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer. It corresponds
 *  to a socket.
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hTcp                       TCP instance
 *
 *  Return:
 *   H_NETINTERFACE                Interface handle
 */
H_NETINTERFACE TcpInstanceULInterfaceCreate(H_NETINSTANCE hTcp);

/*
 * TcpInstanceULInterfaceDestroy
 *  Destroy a TCP UL interface
 *
 *  Args:
 *   hTcp                       TCP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG TcpInstanceULInterfaceDestroy(H_NETINSTANCE hTcp,
                                   H_NETINTERFACE hInterface);


/*
 * TcpInstanceULInterfaceIoctl
 *  TCP UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions above, in netcommon.h and nettransport.h
 *  for precisions
 *
 *  Args:
 *   hTcp                         Tcp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG TcpInstanceULInterfaceIoctl(H_NETINSTANCE hTcp,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData);

/*
 * TcpInstanceWrite
 *  Tcp Instance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hTcp                        Tcp Instance handle
 *   hIf                         UL interface handle (socket). The interface
 *                               must be of the CONNECT type, and fully defined
 *                               (Local IP, Destination IP and Port set)
 *   pxPacket                    Packet pointer
 *   pxAccess                    Access info
 *   hData                       Useless
 *
 *  Note:
 *    At entry pxAccess->wOffset must be at least sizeof(TCPHDR)+sizeof(TCPPSH)
 *    regardless of lower layer usage.
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG TcpInstanceWrite(H_NETINSTANCE hTcp,
                      H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,
                      NETPACKETACCESS *pxAccess,
                      H_NETDATA hData);

/*
 * TcpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hTcp                       TCP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE TcpInstanceLLInterfaceCreate(H_NETINSTANCE hTcp);

/*
 * TcpInstanceLLInterfaceDestroy
 *  Destroy a TCP LL interface
 *
 *  Args:
 *   hTcp                       TCP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG TcpInstanceLLInterfaceDestroy(H_NETINSTANCE hTcp,
                                   H_NETINTERFACE hInterface);


/*
 * TcpInstanceLLInterfaceIoctl
 *  TCP LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and nettransport.h
 *  for precisions
 *
 *  Args:
 *   hTcp                         Tcp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG TcpInstanceLLInterfaceIoctl(H_NETINSTANCE hTcp,
                                 H_NETINTERFACE hLLInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData);

/*
 * TcpInstanceRcv
 *  Tcp Instance Rcv function
 *   Tcp Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hTcp                        Tcp Instance Handle
 *    hIf                         Interface Handle
 *    pxPacket                    packet
 *    pxAccess                    access info
 *    hData                       must be a pointer to a 64 bits
 *                                field, big-endian, containing in
 *                                the 1st DWORD the source IP address
 *                                and in the 2nd the destination IP address
 *  Note:
 *    At entry pxAccess->wOffset must be at least sizeof(TCPPSH)
 *    regardless of lower layer usage.
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG TcpInstanceRcv(H_NETINSTANCE hTcp,
                    H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,
                    NETPACKETACCESS *pxAccess,
                    H_NETDATA hData);

/*
 * TcpInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hTcp                        Tcp Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG TcpInstanceProcess(H_NETINSTANCE hTcp);

/*
 * TcpInstanceInterfaceShow
 *  Show all the interfaces currently active
 *
 *  Args:
 *   hTcp                        Tcp Instance Handle
 *
 *  Return:
 *   void
 */
void TcpInstanceInterfaceShow(H_NETINSTANCE hTcp);
#endif /* #ifndef _TCP_H_ */







