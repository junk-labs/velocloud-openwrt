/*
 * setupnet.h
 *
 * API header file for network configuration functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _SETUPNET_H_
#define _SETUPNET_H_

#include "NNstyle.h"
#include "configapi.h"

/****************************************************************************
 *
 * defines/typedefs/enums
 *
 *****************************************************************************/

typedef DWORD H_WEBDATA;

/*
 * return codes
 */
typedef enum {
  SETUPNET_OK=0,
  SETUPNET_BADMACECC,
  SETUPNET_MACMISSING,
  SETUPNET_NOFIXEDIPCFG,
  SETUPNET_ERROR
} SetupNetReturn;

/*
 * setup types for the LAN interface
 */
typedef enum {
  SETUPNET_AUTO,          /* Automatic setup based on config file */
  SETUPNET_FIXEDIP,       /* Forced fixed ip mode (no vlan) */
  SETUPNET_DHCP,          /* Forced DHCP mode (no vlan) */
  SETUPNET_10DOT1,        /* Forced 10.1.0.54 (no vlan) */
  SETUPNET_MACBURN,       /* Mac burn mode. Forced 192.168.1.199 & mac 0090a0ffffff */
  SETUPNET_PPP,           /* Forced PPP mode   */
} SetupNetType;

typedef struct {
  char *pcVarName;
  char acVarValue[CONFIG_MAXPARAMLENGTH + 1];
} CONFIG_PARAM;


/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * SetupNetStack
 *   Set up the network stack.
 *
 *   Args:
 *    eType                    Type of LAN interface
 *                             setup (see setupnet.h for def)
 *
 *   Return:
 *    SetupNetReturn           error code (see setupnet.h for def)
 */
SetupNetReturn SetupNetStack(SetupNetType eType);


/*
 * SetupNetGetIfNum
 *  Get the number of interfaces
 *
 *  Args:
 *   poIfNum            Number of interfaces (to be filled)
 *
 *  Return
 *   SetupNetReturn
 */
SetupNetReturn SetupNetGetIfNum(OCTET* poIfNum);


/*
 * SetupNetGetIfIPAddress
 *  Get the IP address of an interface
 *
 *  Args:
 *   oIfIdx                    Interface index
 *   pdwIPaddress              IP address to fill up
 *
 *  Return:
 *   SetupNetReturn            error code
 */
#define SetupNetGetIPAddress(A)  SetupNetGetIfIPAddress(0, (A))
SetupNetReturn SetupNetGetIfIPAddress(OCTET oIfIdx,
                                      DWORD* pdwIPAddress);


/*
 * SetupNetGetIfStatus
 *  Get the interface status
 *
 *  Args:
 *   oIfIdx               Interface index
 *   pdwStat              Stat to be filled up
 *
 *  Return:
 *   SetupNetReturn
 */
#define SetupNetGetStatus(A) SetupNetGetIfStatus(0,(A))
SetupNetReturn SetupNetGetIfStatus(OCTET oIfIdx,
                                   DWORD *pdwStat);


/*
 * SetupNetGetIfDomainName
 *  Get the domain name of an interface
 *
 *  Args:
 *   oIfIdx              Interface index
 *   poName              name pointer
 *   oNameLen            poName length
 *
 *  Return
 *   SetupNetReturn
 */
#define SetupNetGetDomainName(A,B) SetupNetGetIfDomainName(0,(A),(B))
SetupNetReturn SetupNetGetIfDomainName(OCTET oIfIdx,
                                       OCTET *poName,
                                       OCTET oNameLen);


/*
 * SetupNetGetIfHostName
 *  Get the host name used by an interface
 *
 *  Args:
 *   oIfIdx              Interface index
 *   poName              name pointer
 *   oNameLen            poName length
 *
 *  Return
 *   SetupNetReturn
 */
#define SetupNetGetHostName(A,B) SetupNetGetIfHostName(0,(A),(B))
SetupNetReturn SetupNetGetIfHostName(OCTET oIfIdx,
                                     OCTET *poName,
                                     OCTET oNameLen);


/*
 * SetupNetGetIfDNSIPAddr
 *  Get the interface DNS address
 *
 *  Args:
 *   oIfIdx               Interface index
 *   pdwAddr              IP address to be filled up
 *
 *  Return:
 *   SetupNetReturn
 */
#define SetupNetGetDNSIPAddr(A) SetupNetGetIfDNSIPAddr(0,(A))
SetupNetReturn SetupNetGetIfDNSIPAddr(OCTET oIfIdx,
                                      DWORD *pdwAddr);


/*
 * SetupNetGetIfNTPIPAddr
 *  Get the NTP address of an interface
 *
 *  Args:
 *   oIfIdx               Interface index
 *   pdwAddr              IP address to be filled up
 *
 *  Return:
 *   SetupNetReturn
 */
#define SetupNetGetNTPIPAddr(A) SetupNetGetIfNTPIPAddr(0,(A))
SetupNetReturn SetupNetGetIfNTPIPAddr(OCTET oIfIdx,
                                      DWORD *pdwAddr);


/*
 * SetupNetGetIfSubnetMask
 *  Get the subnet mask of an interface
 *
 *  Args:
 *   oIfIdx              Interface index
 *   pdwIPNetmask        IP address to be filled up
 *
 *  Return
 *   SetupNetReturn
 */
#define SetupNetGetSubnetMask(A) SetupNetGetIfSubnetMask(0,(A))
SetupNetReturn SetupNetGetIfSubnetMask(OCTET oIfIdx,
                                       DWORD* pdwIPNetmask);


/*
 * SetupNetGetIfGateway
 *  Get the default gateway of an interface
 *
 *  Args:
 *   oIfIdx              Interface index
 *   pdwIPGateway        IP address to be filled up
 *
 *  Return
 *   SetupNetReturn
 */
#define SetupNetGetGateway(A) SetupNetGetIfGateway(0,(A))
SetupNetReturn SetupNetGetIfGateway(OCTET oIfIdx,
                                    DWORD* pdwIPGateway);


/*
 * SetupNetGetIfDhcp
 *  Get whether interface is DHCP enabled or not
 *
 *  Args:
 *   oIfIdx               Interface index
 *
 *  Return:
 *   1 - DHCP enabled
 *   0 - DHCP disabled
 */
#define SetupNetGetDhcp() SetupNetGetIfDhcp(0)
BOOL SetupNetGetIfDhcp(OCTET oIfIdx);


/*
 * SetupNetGetMacAddress
 *  Read the mac address from flash file.
 *
 *  Args:
 *   poMac                     6 OCTET array
 *
 * Return:
 *  SETUPNET_OK                success
 *  SETUPNET_MACMISSING        no mac address in file system
 *  SETUPNET_BADMACECC         bad mac crc
 */
SetupNetReturn SetupNetGetMacAddress(OCTET* poMac /*6 octet array*/);


/*
 * SetupNetCheckBridgeOnly
 *  Check if the device is acting as a bridge only
 *
 *  Args:
 *   pbBridge             BOOL to be filled in
 *                        (TRUE = Bridge only, FALSE = Router)
 *
 *   iIfAvoidIdx          Interface number to avoid checking
 *                        Negative number to mean no avoidance.
 *
 *  Return:
 *   SetupNetReturn
 */
SetupNetReturn SetupNetCheckBridgeOnly(BOOL *pbBridge, int iIfAvoidIdx);


/*
 * SetupNetCheckIfNetCfg
 *  Check if the device is acting as a bridge or router or both
 *
 *  Args:
 *   poBridge             Number of Bridged legs to be filled in
 *   poRouter             Number of Routed legs to be filled in
 *   iIfAvoidIdx          Interface number to avoid checking
 *                        Negative number to mean no avoidance.
 *
 *  Return:
 *   SetupNetReturn
 */
SetupNetReturn SetupNetCheckIfNetCfg(OCTET *poBridge, OCTET *poRouter,
                                     int iIfAvoidIdx);


/*
 * SetupNetWebPostCallback
 *  Act upon HTTP posts containing pertainent network reconfiguration
 *  parameters
 *
 *  Args:
 *   hWebdata                  Pointer to HTTP post structure
 *
 * Return:
 *  SETUPNET_OK                success
 *  SETUPNET_MACMISSING        no mac address in file system
 *  SETUPNET_BADMACECC         bad mac crc
 */
int SetupNetWebPostCallback(H_WEBDATA hWebdata);


/*
 * SetupNetWebSubstCallback
 *  Obtain network information for substitution into web pages
 *
 *  Args:
 *   hWebdata                  Pointer to HTTP substitution structure
 *
 * Return:
 *  SETUPNET_OK                success
 *  SETUPNET_MACMISSING        no mac address in file system
 *  SETUPNET_BADMACECC         bad mac crc
 */
int SetupNetWebSubstCallback(H_WEBDATA hWebdata);


/*
 * SetupNetIPSec
 *  Configure the network IPSEC settings
 *
 *  Args:
 *
 * Return:
 *  SETUPNET_OK                success
 */
SetupNetReturn SetupNetIPSec(void);


/*
 * SetupNetRegisterWan2CpePortFwd
 *  On a router device, (de)register WAN ports which are to be
 *  be forwarded up to the CPE
 *  **********************************************************
 *  BY DEFAULT, WAN PORTS ARE NOT ACCESSIBLE VIA THE WAN
 *  **********************************************************
 *
 *  Args:
 *    wPortRangeBegin          WORD port range begin
 *    wPortRangeEnd            WORD port range end
 *    bAllowAccess             BOOL allow access?
 *
 * Return:
 *  SETUPNET_OK                success
 *  SETUPNET_ERROR             error
 */
SetupNetReturn SetupNetRegisterWan2CpePortFwd(WORD wPortRangeBegin,
                                              WORD wPortRangeEnd,
                                              BOOL bAllowAccess);

/*
 * SetupNetRegisterLan2CpePortBlock
 *  On a router device, (de)register LAN ports which are to be
 *  be blocked from reaching the CPE
 *  ***********************************************************
 *  BY DEFAULT, ALL LAN PORTS ARE ALWAYS ACCESSIBLE VIA THE LAN
 *  ************************************************************
 *
 *  Args:
 *    wPortRangeBegin          WORD port range begin
 *    wPortRangeEnd            WORD port range end
 *    bBlock                   BOOL block this port range?
 *
 * Return:
 *  SETUPNET_OK                success
 *  SETUPNET_ERROR             error
 */
SetupNetReturn SetupNetRegisterLan2CpePortBlock(WORD wPortRangeBegin,
                                                WORD wPortRangeEnd,
                                                BOOL bBlock);

#endif
