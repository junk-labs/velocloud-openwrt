/*
 * mn_ndi.c
 *
 * Network device interface and configuration API. This APIs are used by
 * the target system to create, attach and configure network devices to
 * Mocana IP Stack.
 *
 *
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include <NNstyle.h>
#include "dllist.h"
#include "ethbridge_flavor.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "ethernet.h"
#include "../include/sockio.h"
#include "../include/if_dl.h"
#include "../include/socket_inet.h"
#include "../common/netdefs.h"

#include "netcfg.h"
#include "mn_ndi.h"
#include "netmain.h"
#include "iptable.h"

extern pthread_cond_t cond_mac_rx ;
unsigned long gDLLIST_poolCount;
unsigned long gDLLIST_ITEM_poolCount;

/****f* src/inet/ifnet/mn_ndi_registerDevice
*
*  NAME
*   MN_NDI_registerDevice  -- Register Network device with Mocana IP Stack.
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG MN_NDI_registerDevice(WORD device_type, OCTET *device_name,
*                          MnDeviceCbacks_t MnDeviceCallbacks);`
*
*
*
*  FUNCTION
*  Register Network device to the IP Stack.
*
*  INPUTS
*   <device_type>      -- Type of the device
*   <device_name>      -- Name of the device
*   <mNDeviceCallbacks> -- registering Callback functions for this device
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

MSTATUS
MN_NDI_registerDevice (WORD device_type, OCTET *device_name, MnDeviceCbacks_t *
MnDeviceCallbacks)
{
    NETWRAPPER *pxNetWrapper;
    MnDevice_t *pDeviceInfo;

    pxNetWrapper = NETGETWRAPPER;
    /*NETMAIN_ASSERT(sizeof(TRANSPORT2NETWORKID) == sizeof(NETWORKID)); */

    if ((device_type != ETH) && (device_type != ATM)) {
        return -1;
    }

    /* Check if this type of device is already configured */

#if defined (__VXWORKS_RTOS__)
#else
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
    while ((pDeviceInfo =
                DLLIST_read(&pxNetWrapper->MnConfigNetDevices)) !=NULL)
    {
        if (pDeviceInfo->MnDeviceType == device_type)
        {
#if defined (__VXWORKS_RTOS__)
#else
            RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
            return -1;
        }
        DLLIST_next(&pxNetWrapper->MnConfigNetDevices);
    }
#if defined (__VXWORKS_RTOS__)
#else
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif

    pDeviceInfo = (MnDevice_t *)MALLOC(sizeof(MnDevice_t));

    if (NULL == pDeviceInfo)
        return -1;

    MOC_MEMSET((ubyte*)pDeviceInfo, 0, sizeof(MnDevice_t));
    MOC_STRCBCPY(pDeviceInfo->MnDeviceName, sizeof(pDeviceInfo->MnDeviceName),
                               device_name);
    pDeviceInfo->MnDeviceCallbackFns.funcPtr_MnDeviceInit =
                                   MnDeviceCallbacks->funcPtr_MnDeviceInit;
    pDeviceInfo->MnDeviceCallbackFns.funcPtr_MnDeviceWrite =
                                   MnDeviceCallbacks->funcPtr_MnDeviceWrite;
    pDeviceInfo->MnDeviceCallbackFns.funcPtr_MnDeviceInstanceInit =
                               MnDeviceCallbacks->funcPtr_MnDeviceInstanceInit;
    pDeviceInfo->MnDeviceCallbackFns.funcPtr_MnDeviceInstanceStart =
                               MnDeviceCallbacks->funcPtr_MnDeviceInstanceStart;
    pDeviceInfo->MnDeviceCallbackFns.funcPtr_MnDeviceInstanceReset =
                               MnDeviceCallbacks->funcPtr_MnDeviceInstanceReset;
    pDeviceInfo->MnDeviceCallbackFns.funcPtr_MnDeviceInstanceIoctl =
                               MnDeviceCallbacks->funcPtr_MnDeviceInstanceIoctl;
    pDeviceInfo->MnDeviceCallbackFns.funcPtr_MnDeviceInstanceClose =
                               MnDeviceCallbacks->funcPtr_MnDeviceInstanceClose;
    /* Initialize the device instance list */
    init_DLLIST(&pDeviceInfo->MnDeviceInstanceList);

#if defined (__VXWORKS_RTOS__)
#else
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
    /* Add the device to the configured list */
    (void *)DLLIST_append(&pxNetWrapper->MnConfigNetDevices,
                (void *)pDeviceInfo);
#if defined (__VXWORKS_RTOS__)
#else
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
    return OK;
}

/****f* src/inet/ifnet/mn_ndi_attachdeviceinstance
*
*  NAME
*   MN_NDI_attachDeviceInstance  --  Attach device instance to netStack
*
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  MSTATUS
*   MN_NDI_attachDeviceInstance(WORD device_type, OCTET *device_name,
*                          MnDeviceCbacks_t *MnDeviceCallbacks);
*
*
*  FUNCTION
*  Attach device instance to the netStack
*
*  INPUTS
*   <device_type>          -- device type
*   <unit_num>             -- unit number
*   <mnDeviceInstanceInfo> -- device instance info.

*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

ubyte4
MN_NDI_attachDeviceInstance (WORD device_type, WORD unit_num,
        MnDeviceInstanceInfo_t *MnDeviceInstanceInfo)
{
    NETWRAPPER *pxNetWrapper;
    MnDevice_t *pDeviceInfo;
    MnDeviceInstanceConf_t *pDeviceInstanceConf;
    WORD mnSock;
    WORD wIfIndex;

    pxNetWrapper = NETGETWRAPPER;
    /*NETMAIN_ASSERT(sizeof(TRANSPORT2NETWORKID) == sizeof(NETWORKID)); */

    if ((device_type != ETH) && (device_type != ATM))
        return -1;

#if defined (__VXWORKS_RTOS__)
#else
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
    /* Check if this type of device is already configured */
    while ((pDeviceInfo =
                DLLIST_read(&pxNetWrapper->MnConfigNetDevices)) !=NULL) {
        if (pDeviceInfo->MnDeviceType == device_type)
            break;
        DLLIST_next(&pxNetWrapper->MnConfigNetDevices);
    }
#if defined (__VXWORKS_RTOS__)
#else
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
    if (pDeviceInfo == NULL)
        return -1;

    /* Create device instance and attach it to the IP Stack */
    pDeviceInstanceConf =
        (MnDeviceInstanceConf_t *)MALLOC(sizeof(MnDeviceInstanceConf_t));
    if (pDeviceInstanceConf == NULL)
        return -1;
    MOC_MEMSET((ubyte *)pDeviceInstanceConf, 0, sizeof(MnDeviceInstanceConf_t));
    pDeviceInstanceConf->MnDeviceType = MnDeviceInstanceInfo->MnDeviceType;
    pDeviceInstanceConf->MnDeviceInstanceUnitNum =
                            MnDeviceInstanceInfo->MnDeviceInstanceUnitNum;
    if (MnDeviceInstanceInfo->MnDeviceInstanceName != NULL)
        MOC_MEMCPY ((ubyte *)pDeviceInstanceConf->MnDeviceInstanceName,
            (ubyte *)MnDeviceInstanceInfo->MnDeviceInstanceName,
                sizeof(MnDeviceInstanceInfo->MnDeviceInstanceName));
    else
        /* Convert device_name/unit num and take it as instance name */
    ;

    MOC_MEMCPY ((ubyte *)pDeviceInstanceConf->MnDeviceInstanceHWAddr,
                (ubyte *)MnDeviceInstanceInfo->MnDeviceInstanceHWAddr,
                         sizeof(pDeviceInstanceConf->MnDeviceInstanceHWAddr));

    pDeviceInstanceConf->MnDeviceInstanceHWAddrLen =
                            MnDeviceInstanceInfo->MnDeviceInstanceHWAddrLen;
    pDeviceInstanceConf->MnDeviceInstanceMtu =
                            MnDeviceInstanceInfo->MnDeviceInstanceMtu;
    if (MnDeviceInstanceInfo->MnDeviceInstanceLogicalFlag) {
        pDeviceInstanceConf->MnDeviceInstanceFlags |= MN_DEV_INSTANCE_LOGICAL;
        pDeviceInstanceConf->MnDeviceInstanceIPAddr =
                    MnDeviceInstanceInfo->MnDeviceInstanceIPAddr;
        pDeviceInstanceConf->MnDeviceInstanceIPMask =
                    MnDeviceInstanceInfo->MnDeviceInstanceIPMask;
        pDeviceInstanceConf->MnDeviceInstanceDfltGateway =
                    MnDeviceInstanceInfo->MnDeviceInstanceDfltGateway;
    }
    else
        pDeviceInstanceConf->MnDeviceInstanceFlags |= MN_DEV_INSTANCE_PHYSICAL;

    pDeviceInstanceConf->MnDeviceInfo = pDeviceInfo;

#if defined (__VXWORKS_RTOS__)
#else
     RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
    /* Add the device to the configured list */
    (void *)DLLIST_append(&pDeviceInfo->MnDeviceInstanceList,
                (void *)pDeviceInstanceConf);

    /* Get Next available ifIndex */
    wIfIndex = pxNetWrapper->wNextIfIndex++;
    pxNetWrapper->oIfNumber++;
#if defined (__VXWORKS_RTOS__)
#else
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif

    pDeviceInstanceConf->MnDeviceInstanceIndex = wIfIndex;

    /* Attach this device instance to the Net Stack */
    MN_NDI_attachToIP(pDeviceInstanceConf);

    return pDeviceInstanceConf->MnDeviceInstanceIndex;
}

/****f* src/inet/ifnet/MN_NDI_attachToIP
*
*  NAME
*   MN_NDI_attachToIP  -- create an IP instance
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG MN_NDI_attachToIP (WORD device_type, OCTET *device_name,
*                          MnDeviceCbacks_t MnDeviceCallbacks);`
*
*
*
*  FUNCTION
*  Attach Network device to the IP module of netStack.
*
*  INPUTS
*   <pDeviceInstanceConf> -- pointer to device instance info.
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

MSTATUS
MN_NDI_attachToIP(MnDeviceInstanceConf_t *pDeviceInstanceConf)
{
    int iSock;
    OCTET oIfIdx;
    int iRv;
    struct ifreq xIfReq;
    NETWRAPPER *pxNetWrapper;
    NETIFCONF *pxIfConf;
    mnIoctlArgList_t mnArgList;

    /* Open a socket */
    if ((iSock = mn_socket (AF_INET, SOCK_DGRAM, 0)) < 0) {
        ASSERT(0);
        return -1;
    }
    xIfReq.ifr_name[0] = pDeviceInstanceConf->MnDeviceInstanceIndex;
    oIfIdx = pDeviceInstanceConf->MnDeviceInstanceIndex;

    /* Set interface type */
    _SetNetIfParameter(iSock, oIfIdx, MO_SIOCSIFITYPE, "ETH");

    MOC_MEMCPY((ubyte *)((struct sockaddr_dl *)&(xIfReq.ifr_addr))->sdl_data,
        (ubyte *)pDeviceInstanceConf->MnDeviceInstanceHWAddr, 6);
    ((struct sockaddr_dl *)&(xIfReq.ifr_addr))->sdl_alen = 6;
    xIfReq.ifr_addr.sa_len = sizeof(struct sockaddr_dl);
     mnArgList.ifreq = (void *)&xIfReq;
    iRv = ioctl(iSock,MO_SIOCSIFIDLADDR,&mnArgList);
    ASSERT(iRv == 0);
    mn_close(iSock);

    /* Add the name to netIfConf and set pointer to mnDeviceInstance */
    pxNetWrapper = NETGETWRAPPER;
    /*NETMAIN_ASSERT(sizeof(TRANSPORT2NETWORKID) == sizeof(NETWORKID)); */

    /* Find the device instance */
    pxIfConf = NETGETIFCONF (pxNetWrapper,
            pDeviceInstanceConf->MnDeviceInstanceIndex);

    pxIfConf->pMnDeviceInstance = (void *)pDeviceInstanceConf;

    /* Initialize the Logical Instance index to -1 i.e. AVAILABLE for bonding */
    pxIfConf->iLogicalLinkIfIdx = -1; /* Atul */
    pxIfConf->iActivePhyLinkIfIdx = -1; /* Atul */

    xIfReq.ifr_name[0] = pDeviceInstanceConf->MnDeviceInstanceIndex;
    /* Now open the device instance */
    if (pDeviceInstanceConf->MnDeviceInstanceFlags & MN_DEV_INSTANCE_LOGICAL){
        MN_NDI_deviceSetLogical (oIfIdx);
        MN_NDI_deviceAddPhytoLogical(oIfIdx, oIfIdx);
    }
    iRv = MN_NDI_setDeviceInstanceParams(oIfIdx, MO_SIOCIFIOPEN,&xIfReq);

    xIfReq.ifr_name[0] = pDeviceInstanceConf->MnDeviceInstanceIndex;
    /* If it is logical device and IP address is assigned set IP address */
    if (pDeviceInstanceConf->MnDeviceInstanceFlags & MN_DEV_INSTANCE_LOGICAL) {
        iRv = MN_NDI_setDeviceInstanceIPAddr (oIfIdx,
                pDeviceInstanceConf->MnDeviceInstanceIPAddr,
                pDeviceInstanceConf->MnDeviceInstanceIPMask
            );

    xIfReq.ifr_name[0] = pDeviceInstanceConf->MnDeviceInstanceIndex;
        ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr =
                      pDeviceInstanceConf->MnDeviceInstanceDfltGateway;
        iRv = MN_NDI_setDeviceInstanceParams(oIfIdx, MO_SIOCSIFIGWADDR,&xIfReq);
    }

    /* Set the MTU for the IP instance */
    xIfReq.ifr_name[0] = pDeviceInstanceConf->MnDeviceInstanceIndex;
    xIfReq.ifr_ifru.ifru_mtu = pDeviceInstanceConf->MnDeviceInstanceMtu;
    iRv = MN_NDI_setDeviceInstanceParams(oIfIdx, MO_SIOCSIFIMTU,&xIfReq);
    return 0;
}


/****f* src/inet/ifnet/mn_ndi_devicesetlogical
*
*  NAME
*   MN_NDI_deviceSetLogical  -- set Device Instance to be a Logical device
*
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG MN_NDI_deviceSetLogical(WORD deviceInstanceIndex);
*
*
*  FUNCTION
*  Set the configured device to be Logical device.
*
*  INPUTS
*   <deviceInstanceIndex> -- application callback Handle

*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

MSTATUS
MN_NDI_deviceSetLogical (WORD deviceInstanceIndex)
{
    NETWRAPPER *pxNetWrapper;
    MnDevice_t *pDeviceInfo;
    MnDeviceInstanceConf_t *pDeviceInstanceConf;
    NETIFCONF *pxIfConf;
    OCTET oIfIdx;
    int iRv;
    struct ifreq xIfReq;

    xIfReq.ifr_name[0] = deviceInstanceIndex;
    oIfIdx = deviceInstanceIndex;

    pxNetWrapper = NETGETWRAPPER;

#if defined (__VXWORKS_RTOS__)
#else
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif

    /* Find the device instance */
    pxIfConf = NETGETIFCONF (pxNetWrapper, deviceInstanceIndex);
    pDeviceInstanceConf = (MnDeviceInstanceConf_t *)pxIfConf->pMnDeviceInstance;

    pDeviceInstanceConf->MnDeviceInstanceFlags |= MN_DEV_INSTANCE_LOGICAL;

#if defined (__VXWORKS_RTOS__)
#else
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif

    iRv = MN_NDI_setDeviceInstanceParams(deviceInstanceIndex,
            MO_SIOCGIFIFLAG,&xIfReq);
    xIfReq.ifr_flags |= IFF_LOGICAL;
    iRv = MN_NDI_setDeviceInstanceParams(deviceInstanceIndex,
                      MO_SIOCSIFIFLAG,&xIfReq);
}

/****f* src/inet/ifnet/MnRegisterDevice
*
*  NAME
*   MN_NDI_deviceAddPhytoLogical  -- Add physical device to logical
*
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG MN_NDI_deviceAddPhytoLogical(WORD phyDeviceInstanceIndex,
*               WORD logicalDeviceInstanceIndex);
*
*
*
*  FUNCTION
*  Add Physical device to Logical
*
*  INPUTS
* <phyDeviceInstanceIndex> -- Physical interface index to add
* <logicalDeviceInstanceIndex> -- Logical interface index
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

WORD
MN_NDI_deviceAddPhytoLogical (WORD phyDeviceInstanceIndex,
        WORD logicalDeviceInstanceIndex)
{
    NETWRAPPER *pxNetWrapper;
    MnDevice_t *pDeviceInfo;
    MnDeviceInstanceConf_t *pDeviceInstanceConfLogical;
    MnDeviceInstanceConf_t *pDeviceInstanceConfPhy;
    NETIFCONF *pxLogicalIfConf, *pxPhysicalIfConf;
    int iRv;
    struct ifreq xIfReq;


    pxNetWrapper = NETGETWRAPPER;
    /*NETMAIN_ASSERT(sizeof(TRANSPORT2NETWORKID) == sizeof(NETWORKID)); */

    /* Find the device instance */
    pxLogicalIfConf = NETGETIFCONF (pxNetWrapper, logicalDeviceInstanceIndex);
    if (!(pxLogicalIfConf->oFlags & IFF_LOGICAL)) {
        return -1;
    }
    pxPhysicalIfConf = NETGETIFCONF (pxNetWrapper, phyDeviceInstanceIndex);
    if ((pxPhysicalIfConf->oFlags & IFF_LOGICAL) &&
        (phyDeviceInstanceIndex != logicalDeviceInstanceIndex))
        return -1;

    /* Get the MnDeviceInstanceConf */
    pDeviceInstanceConfPhy = (MnDeviceInstanceConf_t *)
                pxPhysicalIfConf->pMnDeviceInstance;

    pDeviceInstanceConfLogical = (MnDeviceInstanceConf_t *)
                pxLogicalIfConf->pMnDeviceInstance;

    pDeviceInstanceConfLogical->MnPhysicalAggInstanances[
        pDeviceInstanceConfLogical->MnNumPhysicalInstances]
            = phyDeviceInstanceIndex;
    pDeviceInstanceConfLogical->MnNumPhysicalInstances++;

    /* Ioctl to update NETIFCONF data structures */
    xIfReq.ifr_value = phyDeviceInstanceIndex;
    xIfReq.ifr_name[0] = logicalDeviceInstanceIndex;

    iRv = MN_NDI_setDeviceInstanceParams(logicalDeviceInstanceIndex,
            MO_SIOCIFIAGGRADD, &xIfReq);
}

WORD
MN_NDI_deviceDelPhyFromLogical (WORD phyDeviceInstanceIndex,
        WORD logicalDeviceInstanceIndex)
{
    NETWRAPPER *pxNetWrapper;
    MnDevice_t *pDeviceInfo;
    MnDeviceInstanceConf_t *pDeviceInstanceConfLogical;
    MnDeviceInstanceConf_t *pDeviceInstanceConfPhy;
    NETIFCONF *pxLogicalIfConf, *pxPhysicalIfConf;
    int iRv;
    struct ifreq xIfReq;


    pxNetWrapper = NETGETWRAPPER;
    /*NETMAIN_ASSERT(sizeof(TRANSPORT2NETWORKID) == sizeof(NETWORKID)); */

    /* Find the device instance */
    pxLogicalIfConf = NETGETIFCONF (pxNetWrapper, logicalDeviceInstanceIndex);
    if (!(pxLogicalIfConf->oFlags & IFF_LOGICAL)) {
        return -1;
    }
    pxPhysicalIfConf = NETGETIFCONF (pxNetWrapper, phyDeviceInstanceIndex);
    if ((pxPhysicalIfConf->oFlags & IFF_LOGICAL) &&
        (phyDeviceInstanceIndex != logicalDeviceInstanceIndex))
        return -1;

    /* Get the MnDeviceInstanceConf */
    pDeviceInstanceConfPhy = (MnDeviceInstanceConf_t *)
                pxPhysicalIfConf->pMnDeviceInstance;

    pDeviceInstanceConfLogical = (MnDeviceInstanceConf_t *)
                pxLogicalIfConf->pMnDeviceInstance;

    pDeviceInstanceConfLogical->MnPhysicalAggInstanances[
        pDeviceInstanceConfLogical->MnNumPhysicalInstances]
            = phyDeviceInstanceIndex;
    pDeviceInstanceConfLogical->MnNumPhysicalInstances++;

    /* Ioctl to update NETIFCONF data structures */
    xIfReq.ifr_value = phyDeviceInstanceIndex;
    xIfReq.ifr_name[0] = logicalDeviceInstanceIndex;

    iRv = MN_NDI_setDeviceInstanceParams(logicalDeviceInstanceIndex,
            MO_SIOCIFIAGGRDEL, &xIfReq);
}

/****f* src/inet/ifnet/MN_NDI_setDeviceInstanceIPAddr
*
*  NAME
*   MN_NDI_setDeviceInstanceIPAddr  -- Set IP address of Device Instance.
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG MN_NDI_setDeviceInstanceIPAddr(WORD deviceInstanceIndex,
*                  LONG ip_addr, LONG net_mask)
*
*
*  FUNCTION
*  Set IP address/netmask of the device instnace.
*
*  INPUTS
*   <appSessionHandle> -- application callback Handle
*   <instanceId>       -- instance Id
*   <methodDef>        -- registering Callback functions for this session
*   <cfgParam>         -- Config Parameters for this session
*   <cfgParam>         -- Config Parameters for this session
*   <eapSessionHdl>    -- eap session handle returned  for this session

*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

WORD MN_NDI_setDeviceInstanceIPAddr(WORD deviceInstanceIndex, LONG ip_addr,
        LONG net_mask)
{
    int iRv;
    struct ifreq xIfReq;

    xIfReq.ifr_name[0] = deviceInstanceIndex;

    ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr = ip_addr;
    iRv = MN_NDI_setDeviceInstanceParams(deviceInstanceIndex,
            MO_SIOCSIFIADDR,&xIfReq);

    ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr = net_mask;
    iRv = MN_NDI_setDeviceInstanceParams (deviceInstanceIndex,
            MO_SIOCSIFINETMASK,&xIfReq);

    return iRv;
}

/****f* src/inet/ifnet/MN_NDI_openDeviceInstance
*
*  NAME
*   MN_NDI_openDeviceInstance  -- Open a device instance.
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG MN_NDI_openDeviceInstance(WORD device_type, OCTET *device_name,
*                          MnDeviceCbacks_t MnDeviceCallbacks);`
*
*
*
*  FUNCTION
*  Register Network device to the IP Stack.
*
*  INPUTS
*   <appSessionHandle> -- application callback Handle
*   <instanceId>       -- instance Id
*   <methodDef>        -- registering Callback functions for this session
*   <cfgParam>         -- Config Parameters for this session
*   <cfgParam>         -- Config Parameters for this session
*   <eapSessionHdl>    -- eap session handle returned  for this session

*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

WORD
MN_NDI_openDeviceInstance(WORD deviceInstanceIndex)
{
    int iRv;
    struct ifreq xIfReq;

    xIfReq.ifr_name[0] = deviceInstanceIndex;

    iRv = MN_NDI_setDeviceInstanceParams(deviceInstanceIndex,
            MO_SIOCIFIOPEN,&xIfReq);
}


/****f* src/inet/ifnet/mn_ndi_setDeviceInstanceParams
*
*  NAME
*   MN_NDI_setDeviceInstanceParams  -- Set device instance parameters.
*
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG
*       MN_NDI_setDeviceInstanceParams(WORD device_type, OCTET *device_name,
*                          MnDeviceCbacks_t MnDeviceCallbacks);`
*
*
*
*  FUNCTION
*  Register Network device to the IP Stack.
*
*  INPUTS
*   <oIfId>            -- Interface Index
*   <dwSocketIoctl>    -- opcode
*   <pxIfReq>          -- pointer to ifReq containing paramters
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

MSTATUS
MN_NDI_setDeviceInstanceParams (OCTET oIfIdx, DWORD dwSocketIoctl,
            struct ifreq *pxIfReq)
{
    NETWRAPPER *pxNetWrapper;
    MnDevice_t *pDeviceInfo;
    MnDeviceInstanceConf_t *pDeviceInstanceConf;
    NETIFCONF *pxIfConf;
    int iSock;
    int iRv;
    mnIoctlArgList_t mnArgList;

    /* Open a socket */
    if ((iSock = mn_socket (AF_INET, SOCK_DGRAM, 0)) < 0) {
        ASSERT(0);
        return -1;
    }
    pxNetWrapper = NETGETWRAPPER;
    /*NETMAIN_ASSERT(sizeof(TRANSPORT2NETWORKID) == sizeof(NETWORKID)); */

    mnArgList.ifreq = (void *)pxIfReq;
    iRv = ioctl(iSock, dwSocketIoctl, &mnArgList);

    mn_close(iSock);
}

/****f* src/inet/ifnet/mn_ndi_deviceInstanceParams
*
*  NAME
*   MN_NDI_deviceInstanceParams  -- Set/Get device instance parameters.
*
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG
*       MN_NDI_deviceInstanceParams(WORD device_type, OCTET *device_name,
*                          MnDeviceCbacks_t MnDeviceCallbacks);`
*
*
*
*  FUNCTION
*  Get/Set Parameters for IP Device Instance.
*
*  INPUTS
*   <oIfId>            -- Interface Index
*   <dwSocketIoctl>    -- opcode
*   <pxIfReq>          -- pointer to ifReq containing paramters
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

MSTATUS
MN_NDI_deviceInstanceParams (OCTET oIfIdx, DWORD dwSocketIoctl,
            struct ifreq *pxIfReq)
{
    MnDevice_t *pDeviceInfo;
    MnDeviceInstanceConf_t *pDeviceInstanceConf;
    NETIFCONF *pxIfConf;
    int iSock;
    int iRv;
    mnIoctlArgList_t mnArgList;

    /* Open a socket */
    if ((iSock = mn_socket (AF_INET, SOCK_DGRAM, 0)) < 0) {
        ASSERT(0);
        return -1;
    }

    mnArgList.ifreq = (void *)pxIfReq;
    iRv = ioctl(iSock, dwSocketIoctl, &mnArgList);

    mn_close(iSock);
}



/****f* src/inet/ifnet/mn_ndi_postdeviceinstanceevent
*
*  NAME
*   MN_NDI_postDeviceInstanceEvent  -- Post a event for device instance.
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG
*       MN_NDI_postDeviceInstanceEvent(WORD device_type, OCTET *device_name,
*           MnDeviceCbacks_t MnDeviceCallbacks);`
*
*
*
*  FUNCTION
*  Post the event for a device instance.
*
*  INPUTS
*   <oIfIdx>           -- Interface Index
*   <devEventFlags>    -- instance Id

*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

MSTATUS
MN_NDI_postDeviceInstanceEvent(OCTET oIfIdx, LONG devEventFlags)
{
    NETWRAPPER *pxNetWrapper;
    MnDeviceInstanceEvent_t *deviceInstanceEventNode;

    pxNetWrapper = NETGETWRAPPER;

    deviceInstanceEventNode = (MnDeviceInstanceEvent_t *)MALLOC(sizeof(
                MnDeviceInstanceEvent_t));

    deviceInstanceEventNode->MnDeviceInstanceIndex = oIfIdx;
    deviceInstanceEventNode->MnDeviceInstanceEventFlags
                                      = devEventFlags;

    /* Add the device to the configured list */
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
    (void *)DLLIST_append(&pxNetWrapper->dllMnDeviceInstanceEvents,
                (void *)deviceInstanceEventNode);
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return OK;
}

/****f* src/inet/ifnet/mn_ndi_allocFrameBuffer
*
*  NAME
*   MN_NDI_allocFrameBuffer  -- Allocate a buffer for storing received packet
*  SYNOPSIS
*
*   #include "ndic_api.h"
*
*   EXTERN  LONG MN_NDI_allocFrameBuffer(ubyte4 *mnFrameSize);
*
*
*  FUNCTION
*  Allocate frame buffer.
*
*  INPUTS
*
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

void *
MN_NDI_allocFrameBuffer(ubyte4 *MnframeSize)
{
    ubyte *MnFrameBuffer;
    ubyte4 dwFrameSize = 1536;

#ifdef __INET_USE_PAYLOAD_MEMPOOL__
    MSTATUS status ;
    status = NetAllocPayload(&MnFrameBuffer,dwFrameSize);
    if (OK > status) {
        return NULL;
    }
#else
    MnFrameBuffer = (ubyte *)MALLOC(dwFrameSize);
#endif
    *MnframeSize =  dwFrameSize - MN_ETHDRIVER_OFFSET;
    return ((void *)(MnFrameBuffer + MN_ETHDRIVER_OFFSET));
}

/****f* src/inet/ifnet/mn_ndi_enqueueRecvdFrame
*
*  NAME
*   MN_NDI_enqueueRecvdFrame  -- Enqueue received frame to interface queue.
*
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  MSTATUS
*        MN_NDI_enqueueRecvdFrame(ubyte oIfIdx, ubyte *frame, ubyte4 nBytes)
*
*  FUNCTION
*  Enqueue received frame to interface queue.
*
*  INPUTS
*   <oIfIdx>            -- Ifindex of the interface
*   <frame>             -- pointer to the received frame
*   <nBytes>            -- size of the frame in bytes
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
******/

MSTATUS
MN_NDI_dequeueRecvdFrame(ubyte4 oIfIdx)
{
    NETIFCONF  *pxIfConf;
    NETWRAPPER *pxNetWrapper;
    NETWRAPPERSTATE *pxWrapperState;
    NET_DRV_BUFFER * xndbRxPacket;
    MSTATUS status = OK;

    pxNetWrapper = NETGETWRAPPER;

    pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);

    pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);

    while (OK == (status = CIRCQ_deq(pxIfConf->pRxCq,&xndbRxPacket)))
    {
        NetIfProcessNetDrvBuffer(xndbRxPacket, oIfIdx);
    }


    return OK;
}


MSTATUS
MN_NDI_enqueueRecvdFrameNew(ubyte4 oIfIdx, ubyte *frame, ubyte4 nBytes)
{
    NETIFCONF  *pxIfConf;
    NETWRAPPER *pxNetWrapper;
    NETWRAPPERSTATE *pxWrapperState;
    NET_DRV_BUFFER * xndbRxPacket;
    MSTATUS status = OK;

    gEthPhyFramesEnqueued++;

    pxNetWrapper = NETGETWRAPPER;
    /*NETMAIN_ASSERT(sizeof(TRANSPORT2NETWORKID) == sizeof(NETWORKID)); */

    pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);
    /*NETMAIN_ASSERT(pxWrapperState != NULL); */

    pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);
    /*NETMAIN_ASSERT(pxIfConf != NULL); */

    /* Now Make the packet and send it */
#ifdef __INET_USE_NET_BUF_MEMPOOL__
   if( OK > (status = MEM_POOL_getPoolObject(&pxWrapperState->netDrvBufPool, (void **)&xndbRxPacket)))
   {
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: MN_NDI_enqueueRecvFrame - Unable to allocate Buffer");
    NetFree (frame - MN_ETHDRIVER_OFFSET);
    return OK;
   }
   pxWrapperState->netDrvBufPoolUsed++;

#else
    xndbRxPacket = (NET_DRV_BUFFER *)MALLOC (sizeof(NET_DRV_BUFFER));
#endif
    xndbRxPacket->dwLength = nBytes;
    xndbRxPacket->wSize = nBytes;
    xndbRxPacket->wOffset = MN_ETHDRIVER_OFFSET;
    xndbRxPacket->dwLength += MN_ETHDRIVER_OFFSET; /* Adding Offset Length */
    xndbRxPacket->wSize += MN_ETHDRIVER_OFFSET; /* Adding Offset Length */
    xndbRxPacket->pfnFree = NetFree;
    xndbRxPacket->poData = frame - MN_ETHDRIVER_OFFSET;

    if (OK > (status = CIRCQ_enq(pxIfConf->pRxCq,xndbRxPacket)))
    {
        printf("Unable to Enqueue Packet \n");
        return OK;
    }

    return OK;
}


MSTATUS
MN_NDI_enqueueRecvdFrame(ubyte4 oIfIdx, ubyte *frame, ubyte4 nBytes)
{
    NETIFCONF  *pxIfConf;
    NETIFSTATE *pxIfState;
    NETWRAPPER *pxNetWrapper;
    NETWRAPPERSTATE *pxWrapperState;
    NET_DRV_BUFFER * xndbRxPacket;
    MSTATUS status = OK;

    gEthPhyFramesEnqueued++;

    pxNetWrapper = NETGETWRAPPER;
    /*NETMAIN_ASSERT(sizeof(TRANSPORT2NETWORKID) == sizeof(NETWORKID)); */

    pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);
    /*NETMAIN_ASSERT(pxWrapperState != NULL); */

    pxIfConf = NETGETIFCONF(pxNetWrapper,oIfIdx);
    /*NETMAIN_ASSERT(pxIfConf != NULL); */

    /* RS keep the state of logical itself*/
    pxIfState = NETGETIFSTATE(pxIfConf);

#ifndef __LOCK_OPT_ON__
    RTOS_mutexWait((pxIfConf->xMutex));
#else
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
    /* Now Make the packet and send it */
#ifdef __INET_USE_NET_BUF_MEMPOOL__
   if( OK > (status = MEM_POOL_getPoolObject(&pxWrapperState->netDrvBufPool, (void **)&xndbRxPacket)))
   {
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: MN_NDI_enqueueRecvFrame - Unable to allocate Buffer");
    NetFree (frame - MN_ETHDRIVER_OFFSET);
#ifndef __LOCK_OPT_ON__
    RTOS_mutexRelease((pxIfConf->xMutex));
#else
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
      return OK;
   }
   pxWrapperState->netDrvBufPoolUsed++;

#else
    xndbRxPacket = (NET_DRV_BUFFER *)MALLOC (sizeof(NET_DRV_BUFFER));
#endif
#ifndef __LOCK_OPT_ON__
    RTOS_mutexRelease((pxIfConf->xMutex));
#else
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
    xndbRxPacket->dwLength = nBytes;
    xndbRxPacket->wSize = nBytes;
    xndbRxPacket->wOffset = MN_ETHDRIVER_OFFSET;
    xndbRxPacket->dwLength += MN_ETHDRIVER_OFFSET; /* Adding Offset Length */
    xndbRxPacket->wSize += MN_ETHDRIVER_OFFSET; /* Adding Offset Length */
    xndbRxPacket->pfnFree = NetFree;
    xndbRxPacket->poData = frame - MN_ETHDRIVER_OFFSET;

#ifdef __LOCK_QUEUE__
#ifndef __LOCK_OPT_ON__
    RTOS_mutexWait((pxIfConf->xMutex));
#else
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
    DLLIST_append(&pxIfConf->dllRxBuf,xndbRxPacket);
#ifndef __LOCK_OPT_ON__
    RTOS_mutexRelease((pxIfConf->xMutex));
#else
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
#else
    if (OK > (status = CIRCQ_enq(pxIfConf->pRxCq,xndbRxPacket)))
    {
        printf("Unable to Enqueue Packet \n");
        return OK;
    }

#endif
    pthread_cond_signal(&cond_mac_rx);

    return OK;
}

/****f* src/inet/ifnet/MN_NDI_deviceRemovePhyFromLogical
*
*  NAME
*   MN_NDI_deviceRemovePhyFromLogical  -- Remove physical device from logical
*
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG MN_NDI_deviceRemovePhyFromLogical(WORD phyDeviceInstanceIndex,
*               WORD logicalDeviceInstanceIndex);
*
*
*
*  FUNCTION
*  Remove Physical device from Logical
*
*  INPUTS
* <phyDeviceInstanceIndex> -- Physical interface index to remove
* <logicalDeviceInstanceIndex> -- Logical interface index
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/

WORD
MN_NDI_deviceRemovePhyFromLogical (WORD phyDeviceInstanceIndex,
        WORD logicalDeviceInstanceIndex)
{
    NETWRAPPER *pxNetWrapper;
    MnDevice_t *pDeviceInfo;
    MnDeviceInstanceConf_t *pDeviceInstanceConfLogical;
    MnDeviceInstanceConf_t *pDeviceInstanceConfPhy;
    NETIFCONF *pxLogicalIfConf, *pxPhysicalIfConf;
    int iRv;
    int i;
    struct ifreq xIfReq;

    pxNetWrapper = NETGETWRAPPER;

    /* Find the device instance */
    pxLogicalIfConf = NETGETIFCONF (pxNetWrapper, logicalDeviceInstanceIndex);
    if (pxLogicalIfConf->oFlags != IFF_LOGICAL) {
        return -1;
    }
    pxPhysicalIfConf = NETGETIFCONF (pxNetWrapper, phyDeviceInstanceIndex);
    if ((pxPhysicalIfConf->oFlags == IFF_LOGICAL) &&
        (phyDeviceInstanceIndex != logicalDeviceInstanceIndex))
        return -1;

    /* Get the MnDeviceInstanceConf */
    pDeviceInstanceConfPhy = (MnDeviceInstanceConf_t *)
                pxPhysicalIfConf->pMnDeviceInstance;

    pDeviceInstanceConfLogical = (MnDeviceInstanceConf_t *)
                pxLogicalIfConf->pMnDeviceInstance;

    /** Check if physical interface is part of the Logical interface and then remove it **/

    for(i=0;i < pDeviceInstanceConfLogical->MnNumPhysicalInstances; i++)
    {
        if(phyDeviceInstanceIndex ==
                pDeviceInstanceConfLogical->MnPhysicalAggInstanances[i])
        {
            /** found the physical instance**/
            int j=i;
            for (j=0;j<pDeviceInstanceConfLogical->MnNumPhysicalInstances;j++)             {
                /* move the remaining physical instances ahead so that *
                 * there are no empty spaces in the array *
                */
                pDeviceInstanceConfLogical->MnPhysicalAggInstanances[j] =
                      pDeviceInstanceConfLogical->MnPhysicalAggInstanances[(j+1) % MAX_AGGREGATION_PHY_INSTANCES];
            }
            /** decrement the count **/
            pDeviceInstanceConfLogical->MnNumPhysicalInstances--;
            break;
        }
    }

    /* Ioctl to update NETIFCONF data structures */
    xIfReq.ifr_value = phyDeviceInstanceIndex;
    xIfReq.ifr_name[0] = logicalDeviceInstanceIndex;

    iRv = MN_NDI_setDeviceInstanceParams(logicalDeviceInstanceIndex,
            MO_SIOCIFIAGGRDEL, &xIfReq);

}

/****f* src/inet/ifnet/MN_NDI_deviceConfig
*
*  NAME
*   MN_NDI_deviceConfig  -- Set/Get attributes for an IP interface
*
*  SYNOPSIS
*
*   #include "mn_ndi.h"
*
*   EXTERN  LONG MN_NDI_deviceSetConfig(WORD deviceInstanceIndex,
*               MnDeviceInstanceInfo_t *pDeviceInstanceInfo,
*                ENUM_MN_DEVICE_CONFIG configType);
*
*
*
*  FUNCTION
*  Set attributes for  device
*
*  INPUTS
* <deviceInstanceIndex> -- Interface index to configure
* <pDeviceInstanceConf> -- Configuration to be set
* <configType> -- type of information to be set - IP Addr, Netmask , Gw, etc.
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/
WORD
MN_NDI_deviceSetConfig(WORD deviceInstanceIndex,
                       MnDeviceInstanceInfo_t *pDeviceInstanceInfo,
                       ENUM_MN_DEVICE_CONFIG configType)
{
    int iRv;
    struct ifreq xIfReq;
    int configAll = 0;

    switch(configType)
    {

        case MN_DEVICE_ALL:
        {
            configAll = 1;
        }
        case MN_DEVICE_IPADDR:
        {
            xIfReq.ifr_name[0] = deviceInstanceIndex;

            ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr =
                                pDeviceInstanceInfo->MnDeviceInstanceIPAddr;

            iRv = MN_NDI_deviceInstanceParams(deviceInstanceIndex,
                    MO_SIOCSIFIADDR,&xIfReq);

            if(!configAll)
                break;
        }
        case MN_DEVICE_NETMASK:
        {
            xIfReq.ifr_name[0] = deviceInstanceIndex;

            ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr =
                                pDeviceInstanceInfo->MnDeviceInstanceBrdAddr;

            iRv = MN_NDI_deviceInstanceParams(deviceInstanceIndex,
                MO_SIOCSIFINETMASK,&xIfReq);

            if(!configAll)
                break;
        }
        case MN_DEVICE_GWADDR:
        {
            xIfReq.ifr_name[0] = deviceInstanceIndex;

            ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr =
                                pDeviceInstanceInfo->MnDeviceInstanceBrdAddr;

            iRv = MN_NDI_deviceInstanceParams(deviceInstanceIndex,
                MO_SIOCSIFIGWADDR,&xIfReq);

            if(!configAll)
                break;
        }
        case MN_DEVICE_BRDADDR:
        {
            xIfReq.ifr_name[0] = deviceInstanceIndex;

            ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr =
                                pDeviceInstanceInfo->MnDeviceInstanceBrdAddr;

            iRv = MN_NDI_deviceInstanceParams (deviceInstanceIndex,
                MO_SIOCSIFIBRDADDR,&xIfReq);

            if(!configAll)
                break;
        }
        default:
        {
            break;
        }
    }

    return iRv;
}

    /****f* src/inet/ifnet/MN_NDI_deviceGetConfig
*
*  NAME
*   MN_NDI_deviceGetConfig  -- Get current attributes for an IP interface
*
*  SYNOPSIS
*
       #include "mn_ndi.h"
*
*   EXTERN  LONG MN_NDI_deviceGetConfig(WORD deviceInstanceIndex,
*               MnDeviceInstanceInfo_t *pDeviceInstanceInfo,
*                ENUM_MN_DEVICE_CONFIG configType);
*
*
*
*  FUNCTION
*  Set attributes device from Logical
*
*  INPUTS
* <deviceInstanceIndex> -- Interface index to configure
* <pDeviceInstanceConf> -- Configuration to get
* <configType> -- type of information to be set - IP Addr, Netmask , Gw, etc.
*
*  RESULT
*  Returns an error code, or OK.
      SEE ALSO
*
*
*
*
******/
WORD
MN_NDI_deviceGetConfig(WORD deviceInstanceIndex,
            MnDeviceInstanceInfo_t *pDeviceInstanceInfo,
            ENUM_MN_DEVICE_CONFIG configType)
{
    int iRv;
    struct ifreq xIfReq;
    int configAll = 0;
     NETWRAPPERSTATE *pxWrapperState = NETGETWRAPPERSTATE(&xNetWrapper);

    switch(configType)
    {
        case MN_DEVICE_ALL:
       {
            configAll = 1;
        }
        case MN_DEVICE_IPADDR:
        {
            xIfReq.ifr_name[0] = deviceInstanceIndex;

            iRv = MN_NDI_deviceInstanceParams(deviceInstanceIndex,
                    MO_SIOCGIFIADDR,&xIfReq);

            pDeviceInstanceInfo->MnDeviceInstanceIPAddr =
                    ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr;

            if(!configAll)
                break;
        }
        case MN_DEVICE_NETMASK:
        {
            xIfReq.ifr_name[0] = deviceInstanceIndex;

            iRv = MN_NDI_deviceInstanceParams (deviceInstanceIndex,
                MO_SIOCGIFINETMASK,&xIfReq);

            pDeviceInstanceInfo->MnDeviceInstanceIPMask =
                ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr;

            if(!configAll)
                break;
        }
        case MN_DEVICE_GWADDR:
        {
            xIfReq.ifr_name[0] = deviceInstanceIndex;

            ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr =
                        pDeviceInstanceInfo->MnDeviceInstanceDfltGateway;

            iRv = MN_NDI_deviceInstanceParams (deviceInstanceIndex,
                MO_SIOCGIFIGWADDR,&xIfReq);

            pDeviceInstanceInfo->MnDeviceInstanceDfltGateway =
                ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr;

            if(!configAll)
                break;
        }
        case MN_DEVICE_BRDADDR:
        {
            xIfReq.ifr_name[0] = deviceInstanceIndex;

            iRv = MN_NDI_deviceInstanceParams(deviceInstanceIndex,
                MO_SIOCGIFIBRDADDR,&xIfReq);

            pDeviceInstanceInfo->MnDeviceInstanceBrdAddr =
                ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr;

            if(!configAll)
                break;
        }
        case MN_DEVICE_MEMPOOL:
        {
            /* Atul - TODO -This should not be here. Fix This */
            printf(" STATS for Mempools:\n");
#ifdef __INET_USE_MEMPOOL__
            printf("\tNETPAYLOAD POOL - In Use - %ld\n",
                   pxWrapperState->netPayloadPoolUsed);
#endif

#ifdef __INET_USE_PKT_MEMPOOL__
            printf("\tNETPACKET POOL - In Use - %ld\n",
                      pxWrapperState->netPacketPoolUsed);
#endif
#ifdef __INET_USE_NET_BUF_MEMPOOL__
            printf("\tNET DRIVER BUFFER POOL - In Use - %ld\n",
                      pxWrapperState->netDrvBufPoolUsed);
#endif
            printf("\tDLLIST POOL - In Use - %ld\n",
                      gDLLIST_poolCount);
            printf("\tDLLISTITEM POOL - In Use - %ld\n",
                      gDLLIST_ITEM_poolCount);
            break;
        }
        default:
        {
            break;
        }
    }
    return iRv;
}


/****f* src/inet/ifnet/mn_ndi_freeFrameBuffer
*
*  NAME
*   MN_NDI_freeFrameBuffer  -- Free a buffer allocated with MN_NDI_allocFrameBuffer.
*  SYNOPSIS
*
*   #include "ndic_api.h"
*
*   EXTERN  MN_NDI_freeFrameBuffer(ubyte4 **mnFrameBuffer);
*
*
*  FUNCTION
*  Allocate frame buffer.
*
*  INPUTS
*
*
*  RESULT
*  Returns an error code, or OK.
*  SEE ALSO
*
*
*
*
******/
MSTATUS
MN_NDI_freeFrameBuffer(DWORD *MnFrameBuffer)
{
    MnFrameBuffer -= MN_ETHDRIVER_OFFSET;
    NetFree(MnFrameBuffer);
}



#ifdef __ENABLE_MOCANA_ZEROCOPY__

poolHeaderDescr NetDrvPoolId;
RTOS_MUTEX      xDrvMutex = NULL;
/* For the NetDriver To Send packet To Us */
poolHeaderDescr    netPayloadPool;
ubyte4             netPayloadPoolUsed;

#ifdef __RTOS_VXWORKS__
/*TODO JJ Get a Better way of finding out whether IP Stack is UP or not . Currentlt its just a hack */
extern void *driverCookie_if1;

extern MSTATUS
MN_NDI_isIPStackReady()
{    NETWRAPPER *pxNetWrapper;

    pxNetWrapper = NETGETWRAPPER;

    /*if (&(pxNetWrapper->xMutex))*/
    if (driverCookie_if1)
        return OK;
    else
        return -1;
}
#endif

extern MSTATUS
MN_setNetPayloadLen (char * pNewMblk, int rLen)
{
    NETPAYLOAD *pxPayload = (NETPAYLOAD *)pNewMblk;
    /* Ensure that rLen < pxPayload->wSize */
    if (rLen > (pxPayload->wSize - MN_ETHDRIVER_OFFSET))
        return -1;    pxPayload->dwLength  = rLen;
    return OK;
}

extern char *
MN_allocNetPacket(char * poPayload, int wSize)
/* TODO Should Add Pool id here */
{
    NETPAYLOAD *pxPayload;
    NetPayloadCreateDrv(&pxPayload,NetFree,(&xNetWrapper.xMutex),
                        (poPayload),(wSize));
    return (char *)pxPayload;
}

extern char *
MN_allocDrvPacket(char * pPayload)
/* TODO Should Add Pool id here */
{
    NET_DRV_BUFFER *pxInPacket = (NET_DRV_BUFFER *)pPayload;
    NET_DRV_BUFFER *pndbTxPacket;
    MSTATUS status;

    RTOS_recursiveMutexWait(&(xDrvMutex));
    status = MEM_POOL_getPoolObject(&NetDrvPoolId, (void **)&pndbTxPacket);
    RTOS_recursiveMutexRelease(&(xDrvMutex));
    if (OK > status)
    {

#ifdef __TCP_SEND_SEGMENT__
        if ((pxInPacket->pTxSegment) && (pxInPacket->oUserCount == 0))
    {
            printf("Code Missing.. need to Send the TxSegment back to User\n");
    }
#else
        pxInPacket->pfnFree(pxInPacket->poData);
#endif
        return  NULL;
    }
    ASSERT (pndbTxPacket == NULL);
    pndbTxPacket->poData =  pxInPacket->poData;
    pndbTxPacket->dwLength =  pxInPacket->dwLength;
    pndbTxPacket->wSize =  pxInPacket->wSize;
    pndbTxPacket->wOffset =  pxInPacket->wOffset;
    pndbTxPacket->pfnFree =  pxInPacket->pfnFree;


    pndbTxPacket->oPriority = pxInPacket->oPriority;
#ifdef __TCP_SEND_SEGMENT__
    pndbTxPacket->pTxSegment = pxInPacket->pTxSegment;
    pndbTxPacket->oUserCount =  pxInPacket->oUserCount;
#endif
#ifdef CUSTOM_QUEUE
    pndbTxPacket->oClass  = pxInPacket->oClass;
#endif

    pndbTxPacket->dwMagicCookie = 0xdeadbeef;
    return (char *)pndbTxPacket;
}

extern MSTATUS
MN_freeNetPacket(char *pMblk) /* TODO Should Add Pool id here */
{
    NETPAYLOAD *pxPayload = (NETPAYLOAD *)pMblk;
    MSTATUS status = OK;
    NETPAYLOAD_CHECK(pxPayload);
    NetPayloadDelUserDrv(pxPayload);
        return OK;
}

extern MSTATUS
MN_freeDrvPacket(char *pMblk) /* TODO Should Add Pool id here */
{
    NET_DRV_BUFFER *pndbTxPacket = (NET_DRV_BUFFER *)pMblk;
#ifdef __TCP_SEND_SEGMENT__
    if (pndbTxPacket->pTxSegment)
    {
        if (pndbTxPacket->oUserCount == 0)
    {
            /* Need to return to user Code Missing */
            printf(" MN_freeDrvPacket JJ Need to return to user , code missing \n");
    }
    }
    else
    pndbTxPacket->pfnFree(pndbTxPacket->poData);
#else
    /* Base it on User count */
    pndbTxPacket->pfnFree(pndbTxPacket->poData);
#endif
    RTOS_recursiveMutexWait(&(xDrvMutex));
    MEM_POOL_putPoolObject(&NetDrvPoolId, (void **)&pndbTxPacket);
    RTOS_recursiveMutexRelease(&(xDrvMutex));
    return OK;
}


extern MSTATUS
MN_freeNetPacketOnly(ubyte *pMblk) /* TODO Should Add Pool id here */
{
    NETPAYLOAD *pxPayload = (NETPAYLOAD *)pMblk;
        MSTATUS status = OK;
    NETPAYLOAD_CHECK(pxPayload);
    pxPayload->poPayload = NULL;
        NetPayloadDelUserDrv(pxPayload);
        return OK;
}

extern char *
MN_getPayload (char *pMblk)
{
    NETPAYLOAD *pxPayload = (NETPAYLOAD *)pMblk;
    NETPAYLOAD_CHECK(pxPayload);
    return (char *)pxPayload->poPayload;
}

extern char *
MN_getDrvData (char *pMblk)
{
    NET_DRV_BUFFER *pxPayload = (NET_DRV_BUFFER *)pMblk;
    return (char *)pxPayload->poData + pxPayload->wOffset ;
}

extern int
MN_getPayloadLen (char *pMblk)
{
    NETPAYLOAD *pxPayload = (NETPAYLOAD *)pMblk;
    NETPAYLOAD_CHECK(pxPayload);
    return (char *)pxPayload->dwLength;
}

extern int
MN_getDrvDataLen (char *pMblk)
{
    NET_DRV_BUFFER *pxPayload = (NET_DRV_BUFFER *)pMblk;
    return pxPayload->dwLength;
}
extern int
MN_checkNetPayload(char *pMblk)
{
    NETPAYLOAD *pxPayload = (NETPAYLOAD *)pMblk;
    NETPAYLOAD_CHECK(pxPayload);
    if (pxPayload->dwMagicCookie == 0xdeadbeef)
        return 1;
    else
        return 0;
}

extern int
MN_checkDrvPayload(char *pMblk)
{
    NET_DRV_BUFFER *pxPayload = (NET_DRV_BUFFER *)pMblk;

    if (pxPayload->dwMagicCookie == 0xdeadbeef)
        return 1;
    else
        return 0;
}
extern MSTATUS
MN_NDI_checkMyAddr(ubyte4 oIfIdx, ubyte4 *dstIpAddrType, ubyte4 ipAddr)
{
      MSTATUS status = -1;
      IPTABLEENTRY xIpEntry;
      xIpEntry.oIfIdx = oIfIdx;
      xIpEntry.wDefaultVlan = NETVLAN_ANY;
      xIpEntry.dwAddr = ipAddr;
      *dstIpAddrType = IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry);
      switch (*dstIpAddrType)
      {
      case IPADDRT_MYADDR:
      case IPADDRT_BROADCAST:
          status = 0;
                  gMotEthPhyFramesEnqueued++;
          break;
      default:

          status = -1;
      }
      return status;
}

#define MAX_NETDRVPAYLOAD  128

extern MSTATUS
MN_NDI_initDrvMempool ()
{
  MSTATUS status;
  ubyte   *pTempMemBuffer;

  if (xDrvMutex)
      return OK;

  if (OK > (status = RTOS_recursiveMutexCreate((RTOS_MUTEX)&xDrvMutex, 0, 0)))
  {
      return status;
  }

  pTempMemBuffer = MALLOC (sizeof(NET_DRV_BUFFER) * MAX_NETDRVPAYLOAD) ;
  if (!pTempMemBuffer)
     return -1;

  if (OK > (status = MEM_POOL_initPool(&NetDrvPoolId, pTempMemBuffer, sizeof(NET_DRV_BUFFER) * MAX_NETDRVPAYLOAD,
         sizeof(NET_DRV_BUFFER))))
  {
      FREE(pTempMemBuffer);
      return status;
  }

  pTempMemBuffer = MALLOC (sizeof(NETPAYLOAD) * MAX_NETPAYLOAD_POOL) ;
  if (!pTempMemBuffer)
     return -1;

  if (OK > (status = MEM_POOL_initPool(&netPayloadPool, pTempMemBuffer, sizeof(NETPAYLOAD) * MAX_NETPAYLOAD_POOL,
         sizeof(NETPAYLOAD))))
  {
    FREE(pTempMemBuffer);
    return status;
  }

  printf("Initialized Mempool for Drivers NetPayload \n");
  return status;
}

#endif
