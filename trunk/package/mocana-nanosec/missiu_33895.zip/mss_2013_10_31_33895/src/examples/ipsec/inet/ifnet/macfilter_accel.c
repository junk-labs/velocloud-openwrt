/*
 * mac_table_accel.c
 *
 * Packet filtering based upon MAC address used for bridging (802.1d)
/*   MAC addresses are learnt from packets arriving from the local LAN
/*   These addresses can then be used to negatively filter packets
/*   arriving from the local LAN and positively filter packets arriving
/*   from the WAN
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include <NNstyle.h>
#include "ethbridge_flavor.h"
#include <strings.h>
#include <pthread.h>
#include "netcommon.h"
#include "ethernet.h"
#include "macfilter.h"


/***************************************************************************/
/*                     G L O B A L   V A R I A B L E S                     */
/***************************************************************************/
MACFILTERENTRY *apxFilterEntryHash[MAC_FILTER_HASH_SIZE];


/***************************************************************************
*       This will find an entry in the MAC table by looking at the MAC address.
*
*       par:    poMacAddpress           MAC address to look for
*
*       ret:    ptr to the mac entry (MACFILTERENTRY *)
*               or NULL if not found
****************************************************************************/
MACFILTERENTRY * MacFilterLookup(OCTET * poMacAddr)
{
  MACFILTERENTRY * pxFilterEntry;
  DWORD dwHash=0;

  /* Loop through the table for the desired address. */
  dwHash = poMacAddr[ETHADDRESS_LEN -1] & (MAC_FILTER_HASH_SIZE - 1);
  pxFilterEntry = apxFilterEntryHash[dwHash];

  while(pxFilterEntry != NULL) {
      if (!memcmp(pxFilterEntry->oMacAddr, poMacAddr, ETHADDRESS_LEN)) {
        return(pxFilterEntry);
      }
      pxFilterEntry = pxFilterEntry->next;
  }
  /* not found */
  return(NULL);
}




