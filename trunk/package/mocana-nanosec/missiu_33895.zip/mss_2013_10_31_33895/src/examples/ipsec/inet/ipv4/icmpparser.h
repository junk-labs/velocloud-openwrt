/*
 * icmpparser.h
 *
 * ICMP header parser macro definitions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __ICMPPARSER_H__
#define __ICMPPARSER_H__

#include <sys/socket.h>

#include "icmp.h"

#define ICMP_GET_CHECKSUM(x) (ntohs((x)->wChecksum))
#define ICMP_SET_CHECKSUM(x,y) ((x)->wChecksum = htons(y))

#define ICMP_GET_ECHOID(x) (ntohs((x)->u.xEcho.wId))
#define ICMP_SET_ECHOID(x,y) ((x)->u.xEcho.wId = htons(y))

#endif /* #ifndef __ICMPPARSER_H__*/
