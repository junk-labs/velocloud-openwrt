/*
 * ethdefs.h
 *
 * ethernet common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ETHDEFS_H_
#define _ETHDEFS_H_

/*****************************************************************************
 *
 * Constants
 *
 *****************************************************************************/

#define ETH_MAXULIF  (3 + 2) /*ARP,RARP,IP,PPPOE,PPPOE_SESSION*/

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * Ethernet UL module plug-in structure
 */
typedef struct {
  H_NETINTERFACE hUlIf; /* Id passed to the Rx Cbk */
  H_NETINSTANCE hUlInst;
  PFN_NETRXCBK pfnRxCbk;
  WORD wRoutingId;   /* Routing Id */
  OCTET oIfIdx;
} ETH_UL;


/*
 * Ethernet instance main structure
 */
typedef struct {
  /* Basic structure override protection */
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

  /* Options */
  OCTET aaoIfEthAddr[ETH_MAXNUM_IF][ETHADDRESS_LEN];
  WORD *pwSpecificVlan;
  OCTET oSpecificVlanNumber;
  /* Note (SB Sep-2001): no need for PAD and OFFSET, as there
     won't be any allocation in ethernet */
  OCTET obLocalLoopback;

  /* UL modules */
  ETH_UL *apxUl[ETH_MAXULIF];
  OCTET oUlNumber;

  /* LL interface */
  WORD wLlDefaultVlan;
  H_NETINTERFACE hLlIf;
  H_NETINSTANCE hLl;
  PFN_NETWRITE  pfnLlWrite;

} ETHSTATE;


#endif /* _ETHDEFS_H_ */
