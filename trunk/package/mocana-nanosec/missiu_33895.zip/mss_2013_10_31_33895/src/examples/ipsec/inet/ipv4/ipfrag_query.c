/*
 * ipfrag_query.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "ipfrag_defs.h"

/*****************************************************************************
 *
 * API
 *
 *****************************************************************************/

/*
 * IpFragInstanceQuery
 *  Query a IP fragmentation Instance Option
 *
 *  Args:
 *   hIpFrag                   IP fragmentation instance
 *   oOption                   Option
 *   phData                    Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpFragInstanceQuery(H_NETINSTANCE hIpFrag,
                         OCTET oOption,
                         H_NETDATA *phData)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
  LONG lReturn = 0;

  IPFRAG_CHECK_STATE(pxIpFrag);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_NORMAL))
  {
    /*IPFRAG_DBGP(NORMAL, "IpFragInstanceQuery: Option: %x\n", oOption);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpFragInstanceQuery: Option: ", oOption);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oOption) {

  case NETOPTION_PAYLOADMUTEX:
    *phData = (H_NETDATA)pxIpFrag->pxMutex;
    break;

  case NETOPTION_OFFSET:
    *phData = (H_NETDATA)pxIpFrag->wOffset;
    break;

  case NETOPTION_TRAILER:
    *phData = (H_NETDATA)pxIpFrag->wTrailer;
    break;

  case NETOPTION_NETCBK:
    *phData = (H_NETDATA)pxIpFrag->pfnNetCbk;
    break;

  case IPFRAGOPTION_MD:
    *phData = (H_NETDATA)pxIpFrag->wMD;
    break;

  case IPFRAGOPTION_TO:
    *phData = (H_NETDATA)pxIpFrag->dwTO;
    break;

  default:
    lReturn = -1;
    ASSERT(0);
  }

  return lReturn;
}

