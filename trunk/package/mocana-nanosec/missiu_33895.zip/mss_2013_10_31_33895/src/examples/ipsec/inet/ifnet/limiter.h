#ifndef __LIMITER_H__
#define __LIMITER_H__


#define ETH_LIMITER_PROCESS_TIME (1000) /* 1000ms */


#define ETH_LIMIT_BCAST_RCV(dwLength, pxLl)   \
    do {                                      \
        (pxLl)->dwBcastByteCount += (dwLength);  \
       } while(0);

#define ETH_LIMIT_MCAST_RCV(dwLength, pxLl)   \
    do {                                      \
        (pxLl)->dwMcastByteCount += (dwLength);  \
       } while(0);

#define ETH_LIMIT_BCAST_CHECK(pxLl) \
    ((pxLl)->dwBcastByteCount > (pxLl)->dwBcastLimit)
    
#define ETH_LIMIT_MCAST_CHECK(pxLl) \
    ((pxLl)->dwMcastByteCount > (pxLl)->dwMcastLimit)
    

#endif /*__LIMITER_H__*/
