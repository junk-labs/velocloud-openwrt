/*
 * linkconf.h
 *
 * Common internal API for link configuration
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _LINKCONF_H_
#define _LINKCONF_H_

/****************************************************************************
 *
 * Defines
 *
 ****************************************************************************/

/* Library indexes in the Link Library template */

#define LINKLIBIDXBOTTOM_MPOA                 0

#define LINKLIBIDX_MAX                  3

#define NETGETCONFINST_MPOA(pxIfState)     (pxIfState)->xNetConfLinkBottom.pxNetConfInstance[LINKLIBIDXBOTTOM_MPOA]
#define NETGETINST_MPOA(pxIfState)         (pxIfState)->xNetConfLinkBottom.pxNetConfInstance[LINKLIBIDXBOTTOM_MPOA].hInst
#define NETGETNETCONF_MPOA(pxIfState)      &(pxIfState)->xNetConfLinkBottom;
#define NETGETNEXTCALLTIME_MPOA(pxIfState) (pxIfState)->xNetConfLinkBottom.pxNetConfInstance[LINKLIBIDXBOTTOM_MPOA].dwNextCallTime


#define NETGETIF_ETHLL(pxIfState)             (pxIfState)->hEthUlIf
#define NETGETIF_ETHUL(pxIfState)             (pxIfState)->hEthLlIf
#define NETGETIF_MPOAUL(pxIfState)            (pxIfState)->xNetConfLinkBottom.pxNetConfInstance[LINKLIBIDXBOTTOM_MPOA].phULIf[0]
#define NETGETIF_MPOALL(pxIfState)            (pxIfState)->xNetConfLinkBottom.pxNetConfInstance[LINKLIBIDXBOTTOM_MPOA].phLLIf[0]

#define NETSETIF_ETHLL(pxIfState,hIf)             (pxIfState)->hEthUlIf = (hIf)
#define NETSETIF_ETHUL(pxIfState,hIf)             (pxIfState)->hEthLlIf = (hIf)

/****************************************************************************
 *
 * Typedef
 *
 ****************************************************************************/

/*
 * NETLINKLEG
 */

/****************************************************************************
 *
 * externs
 *
 ****************************************************************************/

/* Link Libraries template */

MOC_EXTERN NETCONFLIBRARYTEMPLATE *apxLinkLibTemplate[LINKLIBIDX_MAX];

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * LinkConfResetLibTemplate
 *  Set all libraries to inactive and instance template
 *  to NULL in NetConf
 *
 *  Args:
 *   pxNetConf               NetConf to reset
 *
 *  Return:
 *   0
 */
LONG LinkConfResetLibTemplate(NETCONF *pxNetConf);




void LibConfSetOffsetAndTrailer(NETCONF *pxNetConf,WORD wOffset,WORD wTrailer);

#endif /* ifndef _LINKCONF_H_ */
