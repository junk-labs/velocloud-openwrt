/*
 * ipsec.h
 *
 * Internal include file for IPSec interface module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#if !defined(__IPSEC_H__)
#define __IPSEC_H__


/*///////////////////////////////////////////////////////////////////////////
/* DEFINES */
///////////////////////////////////////////////////////////////////////////*/

/* IPSec specific Msg */
#define IPSECMSG_SETIFIDXLAN        \
  (NETNETWORKMSG_MODULESPECIFICBEGIN)           /* Sets the interface index
                                                   corresponding to the LAN */


/*///////////////////////////////////////////////////////////////////////////
/* TYPEDEFS */
///////////////////////////////////////////////////////////////////////////*/

/*///////////////////////////////////////////////////////////////////////////
/* PROTOTYPES */
///////////////////////////////////////////////////////////////////////////*/

/*
 * IPSecInitialize
 *  Initialize the IPSec library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IPSecInitialize(void);

/*
 * IPSecTerminate
 *  Terminate the IPSec library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IPSecTerminate(void);

/*
 * IPSecInstanceCreate
 *  Creates a IPSec Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IPSecInstanceCreate(void);

/*
 * IPSecInstanceDestroy
 *  Destroy a IPSec Instance
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IPSecInstanceDestroy(H_NETINSTANCE hIPSec);

/*
 * IPSecInstanceSet
 *  Set a IPSec Instance Option
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */

LONG IPSecInstanceSet(H_NETINSTANCE hIPSec,
                       OCTET oOption,
                       H_NETDATA hData);

/*
 * IPSecInstanceQuery
 *  Query a IPSec Instance Option
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IPSecInstanceQuery(H_NETINSTANCE hIPSec,
                         OCTET oOption,
                         H_NETDATA *phData);

/*
 * IPSecInstanceMsg
 *  Send a msg to a IPSec instance
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */

LONG IPSecInstanceMsg(H_NETINSTANCE hIPSec,
                       OCTET oMsg,
                       H_NETDATA hData);

/*
 * IPSecInstanceULInterfaceCreate
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hIPSec                       IPSec instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */

H_NETINTERFACE IPSecInstanceULInterfaceCreate(H_NETINSTANCE hIPSec);

/*
 * IPSecInstanceULInterfaceDestroy
 *  Destroy a IPSec UL interface
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   hULIf                      Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */

LONG IPSecInstanceULInterfaceDestroy(H_NETINSTANCE hIPSec,
                                      H_NETINTERFACE hULIf);

/*
 * IPSecInstanceULInterfaceIoctl
 *
 *  Args:
 *   hIPSec                      IPSec instance handle
 *   hULIf                        Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */

LONG IPSecInstanceULInterfaceIoctl(H_NETINSTANCE hIPSec,
                                    H_NETINTERFACE hULIf,
                                    OCTET oIoctl,
                                    H_NETDATA hData);

/*
 * IPSecInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIPSec                IPSec instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */

H_NETINTERFACE IPSecInstanceLLInterfaceCreate(H_NETINSTANCE hIPSec);

/*
 * IPSecInstanceLLInterfaceDestroy
 *  Destroy a IPSec LL interface
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   hLLIf                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */

LONG IPSecInstanceLLInterfaceDestroy(H_NETINSTANCE hIPSec,
                                      H_NETINTERFACE hLLIf);

/*
 * IPSecInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hIPSec                      IPSec instance handle
 *   hULIf                        Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IPSecInstanceLLInterfaceIoctl(H_NETINSTANCE hIPSec,
                                    H_NETINTERFACE hLLIf,
                                    OCTET oIoctl,
                                    H_NETDATA hData);

/*
 * IPSecInstanceRcv
 *   Decode IPSec headers and do necessary processing for AH and/or ESP,
 *     - Follows PFN_NETWORRXCBK def.
 *     - reconstruct packet with the decoded results and call right pfnRxCbk.
 *
 *       hInst     : IPSec instance handle
 *       hLLIf     : Interface on which the data is received,
 *                   in the receiving module.
 *       pxPacket  : packet pointer
 *       pxAccess  : NETPACKETACCESS pointer
 *       hData     : Out-of-Band data associated with the
 *                   received packet. SHOULD NOT BE USED
 *                   for signaling. Each layer will defined
 *                   what it is
 *  ret:
 *       Number of effectively received bytes (including the offset) or <0
 *       (error. see NETERR_XXX definitions and/or module APIs)
 */
LONG IPSecInstanceRcv(H_NETINSTANCE hInst,
                        H_NETINTERFACE hLLIf,
                        NETPACKET *pxPacket,
                        NETPACKETACCESS *pxAccess,
                        H_NETDATA hData);

/*
 * IPSecInstanceWrite
 *   Construct packets by adding authentication header and ESP
 *   based on the SA found from destination IP address.
 *
 *      hInst       IPSec instance handle
 *      hULIf       Interface to which the packet is given.
 *      pxPacket    packet pointer
 *      pxAccess    NETPACKETACCESS pointer
 *      hData       Destination identification,
 *                  as understood by the written-to
 *                  protocol
 *
 * ret: -1: if fail
 *       n: updated IP payload length(not include outer most IP header length)
 */
LONG IPSecInstanceWrite(H_NETINSTANCE hInst,
                          H_NETINTERFACE hULIf,
                          NETPACKET *pxPacket,
                          NETPACKETACCESS *pxAccess,
                          H_NETDATA hData);

/*
 * IPSecInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hIPSec                        IPSec Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG IPSecInstanceProcess(H_NETINSTANCE hIPSec);

/*
 * IPSecGetSP
 *   Find security policy from destination IP:port, source IP:port and
 *   protocol types
 *
 *      dwDestIP  : destination IP address
 *      wDestPort : destination port number
 *      dwSrcIP   : source IP address
 *      wSrcPort  : source port number
 *      oProto    : protocol type
 *      inBound   : TRUE if packet is coming in
 *
 * ret: pointer to security policy data structure
 *      0 if no SP found
 */
void* IPSecGetSP(DWORD dwDestIP, WORD wDestPort,
                   DWORD dwSrcIP, WORD wSrcPort, OCTET oProto, WORD inBound);

/*
 * IPSecGetHdrLen
 *   Find corresponding SA from destination IP address, and
 *   calculate required header space
 *
 *      pxSP   : pointer to security policy data structure
 *
 * ret: 0 if no SA found
 *      n (total length of IPSec headers to be added) if SA found
 */
int IPSecGetHdrLen(void* pxSP);

/*
 * IPSecGetTrailLen
 *   Find corresponding SA from destination IP address, and
 *   calculate space for padding and authentication data
 *
 *      pxSP    : pointer to security policy data structure
 *      wLength : length of payload(including transport layer header)
 *
 * ret: 0 if no SA found
 *      n (total length of padding and auth data to be added) if SA found
 */
int IPSecGetTrailLen(void* pxSP, WORD wLength);

/*
 * IPSecGetIfIdx
 *   Get Interface Index to use for this IPSec tunnel
 *
 *      pxSP   : pointer to security policy data structure
 *      oIfIdx : original ifIdx
 *
 * ret: 0 if error
 *      n interface index
 */
OCTET IPSecGetIfIdx(void* pxSP, OCTET oIfIdx);

/*
 * IPSecGetGateway
 *   Get gateway info to use for this IPSec tunnel
 *
 *      pxSP   : pointer to security policy data structure
 *      dwGateway : original gateway
 *
 * ret: 0 if error
 *      n gateway ip address
 */
DWORD IPSecGetGateway(void* pxSP, DWORD dwGateway);

/*
 * IPSecCheckSP
 *   Check Security Policy to decide how to handle IP packet
 *   If checking IPSec encoded packet, the result may not be accurate
 *   , but in this case correct checking will be made at later IPSec
 *   deciphering process
 *
 *      DWORD dwSrcIP  : src IP address
 *      DWORD dwDestIP : destination IP address
 *      OCTET oProtocol: transport layer protocol
 *
 * ret: 0 if decided to discard
 *      1 if pass
 */
int IPSecCheckSP(DWORD dwSrcIP, DWORD dwDestIP, OCTET oProtocol);


#endif /* __IPSEC_H__ */

