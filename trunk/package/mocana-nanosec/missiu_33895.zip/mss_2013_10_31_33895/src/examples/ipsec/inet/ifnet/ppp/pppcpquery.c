/*
 * pppcpquery.c
 *
 * PPPCP query function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"

#include "pppcp_flavor.h"
#include "string.h"
#include "stdlib.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h> /* ntoh macros */
#include <netinet/in.h> /* ntoh macros on Linux/Solaris */
#include <pthread.h>
#include <mqueue.h>
#include <stdio.h>
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"

#include "pppcp.h"
/*****************************************************************************
 *
 * API Function Implementation
 *
 *****************************************************************************/
/*
 * PppCpInstanceQuery
 *   Query PPPCP options
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     oMsg             Option code
 *     phData           data handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceQuery(H_NETINSTANCE hPppCp,OCTET oMsg,H_NETDATA * phData)
{
  return NETERR_NOERR;
}

