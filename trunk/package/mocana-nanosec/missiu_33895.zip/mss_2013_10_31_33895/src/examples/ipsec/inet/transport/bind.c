/*
 * bind.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"


/*
 * bind
 *  Assigns a local protocol address to a socket.
 *
 * Args:
 *  lSockfd                     The socket returned by the socket function.
 *  pxSockAddrLocal                 The structure in which the local IP address
 *                              and local port should be specified.
 *  addrlen                     size of the servaddr structure.
 *
 * Return:
 *  0 : Success. Addr successfully bound
 *  -1: Error
 */
int mn_bind(int lSockfd, const struct sockaddr *pxSockAddrLocal,
         socklen_t addrlen)
{
  struct sockaddr_in *pxSockAddrInLocal = NULL;
  DWORD dwAddr;
  SOCKET *pxSock;
  OCTET oProt;
  H_NETINSTANCE hInst;
  PFN_NETIOCTL pfnIoctl;
  TRANSPORTID *pxId;

  pxSockAddrInLocal = (struct sockaddr_in *)pxSockAddrLocal ;

#ifdef STRICT_POSIX
  if(pxLocalAddr_in == NULL) {
    mn_errno = MO_EFAULT;
    return -1;
  }

  /* A non-zero sockaddr structure */
  /* Length should be proper */
  if(addrlen != sizeof(struct sockaddr_in)) {
    mn_errno = MO_EBADARG;
    return -1;
  }

  /* Family should be proper */
  if(pxLocalAddr_in->sin_family != AF_INET) {
    mn_errno = MO_EAFNOSUPPORT;
    return -1;
  }
#else
  ASSERT((pxSockAddrLocal != NULL) &&
         (addrlen == sizeof(struct sockaddr_in)) &&
         (pxSockAddrInLocal->sin_family == AF_INET));
#endif

  dwAddr = ntohl(pxSockAddrInLocal->sin_addr.s_addr);

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(lSockfd);


  if (pxSock == NULL) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  /* Preliminary checks passed */

  oProt = SOCKTYPE2PROTINDEX(pxSock->lType);
  hInst = xSocketRep.axProtocols[oProt].hInst;
  pfnIoctl = xSocketRep.axProtocols[oProt].pfnIoctl;

  pxId = &(pxSock->xTransportId);

  if (dwAddr != 0) {
    /* We're provided with a local IP address. Check its validity:
       o either local
       o or UDP socket and either broadcast or multicast */
    OCTET oIf;
    IPTABLEENTRY xEntry;
    NETWORKID *pxNetId;

    pxNetId = (NETWORKID *) &(pxId->xNetId);

    xEntry.dwAddr = dwAddr;
    xEntry.oIfIdx = (pxSock->oBoundFlag & SOCKETBOUNDFLAG_IF) ?
      pxNetId->oIfIdx : NETIFIDX_ANY;
    xEntry.wDefaultVlan = (pxSock->oBoundFlag & SOCKETBOUNDFLAG_VLAN) ?
      pxNetId->wVlan : NETVLAN_ANY;
    xEntry.eAddrType = IPADDRT_MYADDR; /* Set it to MyAddr for a check */

    if ((oIf = (OCTET)IpTableMsg(IPTABLEMSG_GETIFIDX,(H_NETDATA)&xEntry))
        == NETIFIDX_ANY) {
      /* Does not corespond to an interface */
      if (pxSock->lType == SOCK_DGRAM) {
        LONG lAddrStatus;

        /* Use "slow" Ip table, as this is not time critical
           and it is safer */
        xEntry.eAddrType = IPADDRT_UNKNOWN;
        lAddrStatus = IpTableMsg(IPTABLEMSG_GETTYPE, (H_NETDATA) &xEntry);

        if ((lAddrStatus != IPADDRT_MULTICAST) &&
            (lAddrStatus != IPADDRT_MULTICASTJOINED)) {
          mn_errno = MO_EADDRNOTAVAIL;
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
          return -1;
        }
      }
      else {
        /* TCP: IP MUST BE A LOCAL ONE */
        mn_errno = MO_EADDRNOTAVAIL;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return -1;
      }
      oIf = pxNetId->oIfIdx;
    }

    SOCKET_ASSERT(oIf != NETIFIDX_ANY);

    /* Valid IP address: set it */
    pfnIoctl(hInst,pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_SETLOCALIP,
             (H_NETDATA) dwAddr);
    /* Automatically bind the interface. This assumes that
       IP address are not shared across interfaces. Which is fair */
    pxNetId->oIfIdx = oIf;
    pfnIoctl(hInst,pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_SETIF,
             (H_NETDATA)oIf);
    pxSock->oBoundFlag |= (SOCKETBOUNDFLAG_IP | SOCKETBOUNDFLAG_IF);

  }

  /* If the local address is not provided, Do nothing
     (wait till it becomes necessary to have it) */

  /* Take care of the port */
  if (pfnIoctl(hInst, pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_SETLOCALPORT,
               (H_NETDATA)(ntohs(pxSockAddrInLocal->sin_port))) < 0) {
    /* Can't set the port */
    mn_errno = MO_EADDRINUSE;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  pfnIoctl(hInst,pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT,
           (H_NETDATA)&(pxId->wSrcPort));

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  /* If we reach this point, successfull bind */
  return 0;
}
