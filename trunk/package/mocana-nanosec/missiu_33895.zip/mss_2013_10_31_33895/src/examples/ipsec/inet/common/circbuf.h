#ifndef __CIRC_BUF_H__
#define __CIRC_BUF_H__

#include <NNstyle.h>

#if (!defined(_LINUX)) && (!defined(_SUNOS))
#include <iovec.h>
#endif

typedef struct {
	OCTET	*pBuf;
	DWORD	dwWrite;
	DWORD	dwRead;
	DWORD	dwSize;
} CIRC_BUF;

CIRC_BUF *new_CIRC_BUF(DWORD dwBufSize);
void del_CIRC_BUF(CIRC_BUF *pCircBuf);
LONG CIRC_BUF_space(CIRC_BUF *pCircBuf);
LONG CIRC_BUF_filled(CIRC_BUF *pCircBuf);
void CIRC_BUF_updateptrs_wr(CIRC_BUF *pCircBuf, ubyte4 count);
LONG CIRC_BUF_setupiov_wr(CIRC_BUF *pCircBuf, struct iovec *pIov, ubyte4 count);
void CIRC_BUF_updateptrs_rd(CIRC_BUF *pCircBuf, ubyte4 count);
LONG CIRC_BUF_setupiov_rd(CIRC_BUF *pCircBuf, struct iovec *pIov, ubyte4 count);
LONG CIRC_BUF_read(CIRC_BUF *pCircBuf,OCTET *pBuf, DWORD dwCnt);
LONG CIRC_BUF_write(CIRC_BUF *pCircBuf,OCTET *pBuf, DWORD dwCnt);

#define CIRC_BUF_empty(pCircBuf)	(pCircBuf->dwWrite == pCircBuf->dwRead)

#endif
