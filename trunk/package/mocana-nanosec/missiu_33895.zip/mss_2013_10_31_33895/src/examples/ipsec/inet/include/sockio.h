/*
 * sockio.h
 *
 * public socket ioctls
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _SYS_SOCKIO_H_
#define _SYS_SOCKIO_H_

#define MO_SIOCBASE       0x8000

/*
 * RT ioctls
 */
#define MO_SIOCRT_START   (MO_SIOCBASE + 10)

#define MO_SIOCADDRT      (MO_SIOCRT_START + 0)    /* Add route */
#define MO_SIOCDELRT      (MO_SIOCRT_START + 1)    /* Del route */

#define MO_SIOCRT_END     (MO_SIOCDELRT)

/*
 * IF: interface ioctl
 */
#define MO_SIOCIF_START  (MO_SIOCRT_END + 1)      /* Indicates the 1st of the IF
                                               ioctls */
#define MO_SIOCGIFNUM    MO_SIOCIF_START          /* get the number of supported
                                               interfaces */
#define MO_SIOCIF_END   (MO_SIOCGIFNUM + 1)
/*
 * IFI : interface i: the interface index i must be given,
 *       instead of the interface name
 */
#define MO_SIOCIFI_START  (MO_SIOCIF_END + 1)      /* Indicates the 1st of the IFI ioctls */



/*
 * In the following MO_SIOCSIFIxxx ioctls,
 *    unless otherwise indicated the data is of type
 *        struct ifreq *
 *    where the value ifreq->ifr_name[0] is interpreted
 *    as the interface index.
 */

/*
 * Network Addresses:
 *         Interface = (OCTET)ifreq->ifr_name[0]
 *         Address   = in ifreq->ifr_addr
 */
#define MO_SIOCSIFIADDR      (MO_SIOCIFI_START + 0)     /* Set IP address */
#define MO_SIOCGIFIADDR      (MO_SIOCIFI_START + 1)     /* Get IP address */
#define MO_SIOCSIFIDSTADDR   (MO_SIOCIFI_START + 2)     /* Set p-p addr
                                                     Only valid in PP links */
#define MO_SIOCGIFIDSTADDR   (MO_SIOCIFI_START + 3)     /* Get p-p addr
                                                     Only valid in PP links */
#define MO_SIOCSIFIBRDADDR   (MO_SIOCIFI_START + 4)     /* Set broadcast address */
#define MO_SIOCGIFIBRDADDR   (MO_SIOCIFI_START + 5)     /* Get broadcast address */
#define MO_SIOCSIFINETMASK   (MO_SIOCIFI_START + 6)     /* Set Net mask */
#define MO_SIOCGIFINETMASK   (MO_SIOCIFI_START + 7)     /* Get Net mask */
#define MO_SIOCSIFIDNS       (MO_SIOCIFI_START + 8)     /* Set DNS address */
#define MO_SIOCGIFIDNS       (MO_SIOCIFI_START + 9)     /* Get DNS address */
#define MO_SIOCSIFINTP       (MO_SIOCIFI_START + 10)    /* Set NTP server address */
#define MO_SIOCGIFINTP       (MO_SIOCIFI_START + 11)    /* Get NTP server address */
#define MO_SIOCSIFIGWADDR    (MO_SIOCIFI_START + 12)    /* Set Gateway address
                                                     Only valid in MP links */
#define MO_SIOCGIFIGWADDR    (MO_SIOCIFI_START + 13)    /* Set Gateway address
                                                     Only valid in MP links */
/*
 * Network Values:
 *         Interface = (OCTET)ifreq->ifr_name[0]
 *         Value     = ifreq->ifr_value
 */
#define MO_SIOCSIFITYPE      (MO_SIOCIFI_START + 14)    /* Set If type */
#define MO_SIOCGIFITYPE      (MO_SIOCIFI_START + 15)    /* Get If type */
#define MO_SIOCSIFIMTU       (MO_SIOCIFI_START + 16)    /* Set If Mtu */
#define MO_SIOCGIFIMTU       (MO_SIOCIFI_START + 17)    /* Get If Mtu */
#define MO_SIOCSIFILTU       (MO_SIOCIFI_START + 18)    /* Set If Ltu */
#define MO_SIOCGIFILTU       (MO_SIOCIFI_START + 19)    /* Get If Ltu */
#define MO_SIOCSIFIFLAG      (MO_SIOCIFI_START + 20)    /* Set If status
                                                     flags set in ifreq->ifr_flags
                                                     Only IFF_DYNAMIC bit is used */
#define MO_SIOCGIFIFLAG      (MO_SIOCIFI_START + 21)    /* Get If status
                                                     return flags set in
                                                     ifreq->ifr_flags */
#define MO_SIOCSIFITOS       (MO_SIOCIFI_START + 22)    /* Set If TOS */
#define MO_SIOCSIFIVLAN      (MO_SIOCIFI_START + 23)    /* Set If VLAN */
#define MO_SIOCGIFIVLAN      (MO_SIOCIFI_START + 24)    /* Get If VLAN */
#define MO_SIOCIFICLOSE      (MO_SIOCIFI_START + 25)    /* Close interface */
#define MO_SIOCIFIOPEN       (MO_SIOCIFI_START + 26)    /* Open interface
                                                     (If type set in
                                                     ifreq->ifr_value) */
#define MO_SIOCIFIDISABLE    (MO_SIOCIFI_START + 27)    /* Disable an interface */
#define MO_SIOCIFIPINGDIS    (MO_SIOCIFI_START + 28)    /* Enable/Disable ping
                                                       on the if.
                                                       Uses the ifr_value
                                                       as a BOOL */
#define MO_SIOCSIFIPPPIDLETO (MO_SIOCIFI_START + 29)    /* Set If PPP idle timeout */
#define MO_SIOCGIFIPPPIDLETO (MO_SIOCIFI_START + 30)    /* Get If PPP idle timeout */

#define MO_SIOCSIFIPPPECHOTO (MO_SIOCIFI_START + 31)    /* Set If PPP echo timeout */
#define MO_SIOCGIFIPPPECHOTO (MO_SIOCIFI_START + 32)    /* Get If PPP echo timeout */
#define MO_SIOCSIFIPPPECHOCOUNT (MO_SIOCIFI_START + 33)    /* Set If PPP echo count */
#define MO_SIOCGIFIPPPECHOCOUNT (MO_SIOCIFI_START + 34)    /* Get If PPP echo count */

#define MO_SIOCIFIAGGRADD        (MO_SIOCIFI_START + 35)   /* associate
                                                     physical to logical
                                                     value : if index */
#define MO_SIOCIFIAGGRDEL        (MO_SIOCIFI_START + 36)   /* disassociate
                                                     physical from logical
                                                     value : if index */
/*
 * Ethernet Bridge values
 *         Interface = (OCTET)ifreq->ifr_name[0]
 *         Value     = ifreq->ifr_value
 */
#define MO_SIOCIFIBR_START      (MO_SIOCIFI_START + 37)        /* Indicates the
                                                          beginning of the
                                                          bridging ioctls */

#define    MO_SIOCIFIBRENABLE      (MO_SIOCIFIBR_START + 0)     /* Enables bridging on
                                                          an If */
#define    MO_SIOCGIFIBRENABLE     (MO_SIOCIFIBR_START + 1)     /* Get enable - TRUE if
                                                          bridging is enabled
                                                          on an If */
#define    MO_SIOCIFIBRPPPOE       (MO_SIOCIFIBR_START + 2)     /* Only forward PPPoE
                                                         packets */
#define    MO_SIOCSIFIBRLANIF      (MO_SIOCIFIBR_START + 3)     /* Set the LAN If */
#define    MO_SIOCSIFIBRBCASTLIMIT (MO_SIOCIFIBR_START + 4)     /* Set If broadcast
                                                         limit in % */
#define    MO_SIOCGIFIBRBCASTLIMIT (MO_SIOCIFIBR_START + 5)     /* Get If broadcast
                                                         limit in % */
#define    MO_SIOCSIFIBRMCASTLIMIT (MO_SIOCIFIBR_START + 6)     /* Set If multicast
                                                         limit in % */
#define    MO_SIOCGIFIBRMCASTLIMIT (MO_SIOCIFIBR_START + 7)     /* Get If multicast
                                                         limit in % */
#define    MO_SIOCGIFIBRIFSTATE    (MO_SIOCIFIBR_START + 8)     /* Get If spanning
                                                         tree state.
                                                         ifreq->ifr_value
                                                         is of type
                                                         enum E_ETHBRIFSTAT
                                                         defined in if.h */
#define MO_SIOCIFBRINITIALIFSTATE (MO_SIOCIFIBR_START + 9)   /* Set the initial
                                                         spanning tree state
                                                         of an if.
                                                         ifreq->ifr_value
                                                         is of type
                                                         enum E_ETHBRIFSTAT
                                                         defined in if.h */
/*
 * ATM interface Values:
 *         Interface = (OCTET)ifreq->ifr_name[0]
 *         Value     = ifreq->ifr_value
 */

#define MO_SIOCSIFIATMSTART  (MO_SIOCIFIBR_START + 10)
#define MO_SIOCSIFIATMVPI    (MO_SIOCSIFIATMSTART + 0)    /* Set If ATM VPI */
#define MO_SIOCGIFIATMVPI    (MO_SIOCSIFIATMSTART + 1)    /* Get If ATM VPI */
#define MO_SIOCSIFIATMVCI    (MO_SIOCSIFIATMSTART + 2)    /* Set If ATM VCI */
#define MO_SIOCGIFIATMVCI    (MO_SIOCSIFIATMSTART + 3)    /* Get If ATM VCI */
#define MO_SIOCSIFIATMMODE   (MO_SIOCSIFIATMSTART + 4)    /* Set If ATM Encapsulation
                                                     Mode. Modes defined in if.h */
#define MO_SIOCGIFIATMMODE   (MO_SIOCSIFIATMSTART + 5)    /* Get If ATM Encapsulation
                                                     Mode. Modes defined in if.h */
#define MO_SIOCSIFIATMLATENCY  (MO_SIOCSIFIATMSTART + 6)  /* Set If ATM Latency Mode
                                                     Latency modes defined in if.h */
#define MO_SIOCGIFIATMLATENCY  (MO_SIOCSIFIATMSTART + 7)  /* Get If ATM Latency Mode
                                                     Latency modes defined in if.h */

/*
 * Hardware address (array of octets)
 *         Interface = (OCTET)ifreq->ifr_name[0]
 *         ifreq->ifr_addr.sa_len = sizeof(struct sockaddr_dl);
 *         addr len  = ((struct sockaddr_dl *)&(ifreq->ifr_addr))->sdl_alen
 *         HW addr   = ((struct sockaddr_dl *)&(ifreq->ifr_addr))->sdl_data
 */
#define MO_SIOCSIFIDLADDRSTART (MO_SIOCSIFIATMSTART + 8)
#define MO_SIOCSIFIDLADDR    (MO_SIOCSIFIDLADDRSTART + 0)    /* Set hardware address */
#define MO_SIOCGIFIDLADDR    (MO_SIOCSIFIDLADDRSTART + 1)    /* Get hardware address */

/*
 * Other data types
 */
#define MO_SIOCIFOTHER       (MO_SIOCSIFIDLADDRSTART + 2)
#define MO_SIOCIFIBIND       (MO_SIOCIFOTHER + 0)    /* Bind the socket to this interface
                                                     Argument (DWORD) = If index */
#define MO_SIOCDIFADDR       (MO_SIOCIFOTHER + 1)    /* Delete p-p address*/

#define MO_SIOCIFI_END       (MO_SIOCIFOTHER + 2)


/* The following DNS,PPP and DHCP clientID ioctls below use 2 arguments:
 *  - 1st is interface number: OCTET
 *  - 2nd is struct ifconf *
 *        The ifconf->ifc_len member gives the string length
 *        and ifconf->ifc_buf points to the beginning of the string
 */
#define MO_SIOCIFISTR_START  (MO_SIOCIFI_END )        /* Indicates the beginning of
                                                      the ioctls used for setting
                                                      strings of variable lengths */

#define MO_SIOCGIFIDN        (MO_SIOCIFISTR_START + 0)   /* Get domain name */
#define MO_SIOCSIFIDN        (MO_SIOCIFISTR_START + 1)   /* Set domain name */
#define MO_SIOCGIFIHN        (MO_SIOCIFISTR_START + 2)   /* Get host name */
#define MO_SIOCSIFIHN        (MO_SIOCIFISTR_START + 3)   /* Set hostname */

#define MO_SIOCGIFIPPPNAME   (MO_SIOCIFISTR_START + 4)   /* Set If PPP username */
#define MO_SIOCSIFIPPPNAME   (MO_SIOCIFISTR_START + 5)   /* Set If PPP username */
#define MO_SIOCGIFIPPPPW     (MO_SIOCIFISTR_START + 6)   /* Set If PPP password */
#define MO_SIOCSIFIPPPPW     (MO_SIOCIFISTR_START + 7)   /* Set If PPP password */
#define MO_SIOCGIFIPPPSRV    (MO_SIOCIFISTR_START + 8)   /* Set If PPPoE service tag */
#define MO_SIOCSIFIPPPSRV    (MO_SIOCIFISTR_START + 9)   /* Set If PPPoE service tag */
#define MO_SIOCGIFIPPPAC     (MO_SIOCIFISTR_START + 10)   /* Set If PPPoE AC name */
#define MO_SIOCSIFIPPPAC     (MO_SIOCIFISTR_START + 11)   /* Set If PPPoE AC name */

#define MO_SIOCSIFICLIENTID  (MO_SIOCIFISTR_START + 12)   /* Set DHCP Client ID */
#define MO_SIOCGIFICLIENTID  (MO_SIOCIFISTR_START + 13)   /* Get DHCP Client ID */

#define MO_SIOCIFISTR_END    (MO_SIOCIFISTR_START + 14)

#ifdef DHCP_CUSTOM_OPTIONS
/* The following DHCP client ioctls below use 2 arguments:
 *  - 1st is interface number: OCTET
 *  - 2nd is struct dhcpCustoOpt *
 *        The ifconf->ifc_len member gives the string length
 *        and ifconf->ifc_buf points to the beginning of the string
 */
#define MO_SIOCIFIDHCPCUSTOM_START  (MO_SIOCIFISTR_END)          /* Indicates the beginning of
                                                              the ioctls used for setting
                                                              custom dhcp client options */

#define MO_SIOCSIFIDHCPCUSTOMOPT  (MO_SIOCIFIDHCPCUSTOM_START+0) /* set custom dhcp option
                                                              Two arguments:
                                                              1st = OCTET
                                                              2nd = struct dhcpCustomOpt * */
#define MO_SIOCGIFIDHCPCUSTOMOPT  (MO_SIOCIFIDHCPCUSTOM_START+1) /* get custom dhcp option list
                                                              Two arguments:
                                                              1st = OCTET
                                                              2nd = DLLIST * */

#define MO_SIOCIFIDHCPCUSTOM_END  (MO_SIOCIFIDHCPCUSTOM_START+2)
#endif /*DHCP_CUSTOM_OPTIONS */

/*
 * NAT configuration ioctls. Takes 1 argument:
 *  - pointer to one of the configuration structures defined in nat.h
 */
#ifdef DHCP_CUSTOM_OPTIONS
#define    MO_SIOCNAT_START           (MO_SIOCIFIDHCPCUSTOM_END)/* Indicates the
                                                          beginning of the
                                                          NAT ioctls */
#else
#define    MO_SIOCNAT_START           (MO_SIOCIFISTR_END)       /* Indicates the
                                                          beginning of the
                                                          NAT ioctls */
#endif /* DHCP_CUSTOM_OPTIONS */

#define    MO_SIOCNATREGFWDWAN2CPE    (MO_SIOCNAT_START + 0)    /* Register WAN ports
                                                          to be forwarded
                                                          to CPE */
#define    MO_SIOCNATUNREGFWDWAN2CPE  (MO_SIOCNAT_START + 1)    /* Unregister WAN ports
                                                          to be forwarded
                                                          to CPE */
#define    MO_SIOCNATREGBLKLAN2CPE    (MO_SIOCNAT_START + 2)    /* Register LAN ports
                                                          to be blocked
                                                          to CPE */
#define    MO_SIOCNATUNREGBLKLAN2CPE  (MO_SIOCNAT_START + 3)    /* Unregister LAN ports
                                                          to be blocked
                                                          to CPE */
#define    MO_SIOCNATREGFWDWAN2LAN    (MO_SIOCNAT_START + 4)    /* Configures WAN ports
                                                          to be forwarded
                                                          to LAN */
#define MO_SIOCNATGETFWDWAN2CPE    (MO_SIOCNAT_START + 5)    /* Get the list of
                                                          ports being forwarded
                                                          to the CPE */
#define MO_SIOCNATSETBINDINGSLIMIT (MO_SIOCNAT_START + 6)    /* Set the max number of
                                                          NAT bindings */

#define MO_SIOCNAT_END             (MO_SIOCNATSETBINDINGSLIMIT)


/*
 * Memory reservation ioctls
 */
#define MO_SIOCMEMRSRV_START       (MO_SIOCNAT_END + 1)      /* Indicates the
                                                          beginning of the
                                                          resource reservation
                                                          ioctls */
#define MO_SIOCMEMRSRV_AMT         (MO_SIOCMEMRSRV_START + 0)/* indicates amount
                                                          of memory to be
                                                          reserved for a
                                                          purpose */
#define MO_SIOCMEMRSRV_END         (MO_SIOCMEMRSRV_AMT)

/*
 * Routing table ioctls
 */
#define    MO_SIOCRTABLE_START       (MO_SIOCMEMRSRV_END + 1)   /* Indicates the
                                                          beginning of the
                                                          routing table
                                                          ioctls */
#define MO_SIOCRTABLESETSTATICRT  (MO_SIOCRTABLE_START + 0)  /* Set a static route
                                                          single argument of
                                                          type struct rtentry *
                                                          defined in route.h */
#define MO_SIOCRTABLEGETNUMRT     (MO_SIOCRTABLE_START + 1)  /* get number of routes
                                                          single argument of
                                                          type DWORD* */
#define MO_SIOCRTABLEGETALLRT     (MO_SIOCRTABLE_START + 2)  /* Get information
                                                          about all routes
                                                          Three arguments:
                                                          1st = DWORD
                                                          2nd = struct rtentry *
                                                          3rd = DWORD* */
#define MO_SIOCRTABLE_END         (MO_SIOCRTABLEGETALLRT)


/*
 * Interface close and open callbacks.
 */
#define MO_SIOCIFCBK_START        (MO_SIOCRTABLE_END + 1)    /* Indicates the
                                                          beginning of IF
                                                          callback ioctls. */
#define MO_SIOCADDCLOSECBK        (MO_SIOCIFCBK_START + 0)   /* Callback to be issued
                                                          when an interface is
                                                          closed. */
#define MO_SIOCREMCLOSECBK        (MO_SIOCIFCBK_START + 1)

#define MO_SIOCADDOPENCBK         (MO_SIOCIFCBK_START + 2)   /* Callback to be issued
                                                          when an interface is
                                                          opened. */
#define MO_SIOCREMOPENCBK         (MO_SIOCIFCBK_START + 3)

#define MO_SIOCSDHCPERRORCBK      (MO_SIOCIFCBK_START + 4)   /* Callback to be issued
                                                          when an interface's DHCP
                                                          client has an error */

#define MO_SIOCADDLINKCBK         (MO_SIOCIFCBK_START + 5)   /* Callback to be issued
                                                          when link status changed */

#define MO_SIOCIFCBK_END          (MO_SIOCADDLINKCBK)

/*
 * Limiter ioctl
 */
#define MO_SIOCLIMITER_START            (MO_SIOCIFCBK_END + 1)

#define MO_SIOCLIMITER_VLAN_ENABLE      (MO_SIOCLIMITER_START + 0)  /*Value is a BOOL*/

#define MO_SIOCLIMITER_VLAN_VALUE       (MO_SIOCLIMITER_START + 1)  /*Value is the vlan priority*/

#define MO_SIOCLIMITER_TOS_ENABLE       (MO_SIOCLIMITER_START + 2)  /*Value is a BOOL*/

#define MO_SIOCLIMITER_TOS_MASK         (MO_SIOCLIMITER_START + 3)  /*Value is the ToS mask*/

#define MO_SIOCLIMITER_PORT_ENABLE      (MO_SIOCLIMITER_START + 4)  /*Value is a BOOL*/

#define MO_SIOCLIMITER_PORT_ADD         (MO_SIOCLIMITER_START + 5)  /*Value is a PORT_RANGE*/

#define MO_SIOCLIMITER_PORT_REMOVE      (MO_SIOCLIMITER_START + 6)  /*Value is a PORT_RANGE*/

#define MO_SIOCLIMITER_END              (MO_SIOCLIMITER_PORT_REMOVE)

/*
 * IPSec configuration ioctls.
 */
#define MO_SIOCIPSEC_START        (MO_SIOCLIMITER_END + 1)    /* Indicates the
                                                         beginning of IPSEC
                                                         ioctls */
#define MO_SIOCIPSECCLEARSASP     (MO_SIOCIPSEC_START + 0)  /* Unlink and free
                                                         SP and SA
                                                         data structure */
#define MO_SIOCIPSECGETROUTE      (MO_SIOCIPSEC_START + 1)  /* Get interface index
                                                         and gateway info
                                                         for destination IP.
                                                         Two arguments:
                                                         1st = DWORD(IP addr)
                                                         2nd = struct rtdata
                                                         defined: ipsec_api.h */
#define MO_SIOCIPSECCREATESP      (MO_SIOCIPSEC_START + 2)  /* Create SP, clear
                                                         SA list and set
                                                         route info.
                                                         Three arguments:
                                                         1st = void** ppxSP
                                                         2nd = struct spdata
                                                         3rd = struct rtdata
                                                         defined: ipsec_api.h */
#define MO_SIOCIPSECCREATESA      (MO_SIOCIPSEC_START + 3)  /* Create SA and set data.
                                                         Three arguments:
                                                         1st = DWORD pxSP
                                                         2nd = struct spdata
                                                         3rd = struct sadata
                                                         defined: ipsec_api.h */
#define MO_SIOCIPSECSETSA         (MO_SIOCIPSEC_START + 4)  /* Set SA data.
                                                         Two arguments:
                                                         1st = struct spdata
                                                         2nd = struct sadata
                                                         defined: ipsec_api.h */
#define MO_SIOCIPSEC_END          (MO_SIOCIPSECSETSA)


/*
 * IP Filtering configuration ioctls.
 */
#define MO_SIOCIPFILTERING_START  (MO_SIOCIPSEC_END + 1)          /* Indicates the
                                                               beginning of IP
                                                               Filtering ioctls */

#define MO_SIOCIPFILTERINGCFG     (MO_SIOCIPFILTERING_START + 0)  /* Configure an
                                                               IP filtering
                                                               entry. */

#define MO_SIOCIPFILTERING_END    (MO_SIOCIPFILTERINGCFG)

#define MO_SIOCPUBLICIOCTL_END    (MO_SIOCIPFILTERING_END)         /* Last public ioctl
                                                                index */

#endif
