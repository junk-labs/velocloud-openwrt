/*
 * pppoeclient.h
 *
 * PPPoE client API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPPOECLIENT_H_
#define _PPPOECLIENT_H_

/*****************************************************************************
 *
 * defines
 *
 *****************************************************************************/


/*
 * PPPoE client options
 */
#define PPPOECLIENTOPTION_SERVICENAME    \
  (PPPOEOPTION_MODULESPECIFICBEGIN)        /* Service name. data is a
                                              null-terminate UC8 string */
#define PPPOECLIENTOPTION_ACNAME         \
  (PPPOEOPTION_MODULESPECIFICBEGIN + 1)    /* AC name. data is a
                                              null-terminate UC8 string */

/*
 * Interface Ioctl: all covered in netcommon.h and pppoecommon.h
 */

/*
 * PppoE client specific callbacks
 */
#define PPPOECLIENTCBK_COUNTEREXPIRED       \
 (NETCBK_MODULESPECIFICBEGIN)              /* The connection has not been
                                              established in the specified
                                              amount of trials. The client
                                              will reset the counter and
                                              carry on trying. It is up
                                              to the management to close it */

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * PppoEClientInitialize
 *  Initializes the library
 *
 *  Args:
 *
 *  Return:
 *   0
 */
LONG PppoEClientInitialize(void);

/*
 * PppoEClientTerminate
 *  Terminates the library
 *
 *  Args:
 *
 *  Return:
 *   0
 */
LONG PppoEClientTerminate(void);

/*
 * PppoEClientInstanceCreate
 *  Creates a PPPoE instance
 *
 *  Args:
 *
 *  Return:
 *   instance handle
 */
H_NETINSTANCE PppoEClientInstanceCreate(void);

/*
 * PppoEClientInstanceDestroy
 *  Creates a PPPoE instance
 *
 *  Args:
 *   hInst                   instance handle
 *
 *  Return:
 *   0
 */
LONG PppoEClientInstanceDestroy(H_NETINSTANCE hInst);

/*
 * PppoEClientInstanceSet
 *  Set an option value
 *
 *  Args:
 *   hInst                   instance handle
 *   oOption                 option code
 *   hDdata                  option value
 *
 *  Return:
 *   >=0 if success
 */
LONG PppoEClientInstanceSet(H_NETINSTANCE hInst,OCTET oOption,H_NETDATA hData);

/*
 * PppoEClientInstanceQuery
 *  Query an option value
 *
 *  Args:
 *   hInst                   instance handle
 *   oOption                 option code
 *   phDdata                  option value
 *
 *  Return:
 *   >=0 if success
 */
LONG PppoEClientInstanceQuery(H_NETINSTANCE hInst,OCTET oOption,
                              H_NETDATA *phData);

/*
 * PppoEClientInstanceMsg
 *  PPPoE client Msg function
 *
 *  Args:
 *   hInst                   instance handle
 *   oMsg                    msg code
 *   hData                   msg data
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceMsg(H_NETINSTANCE hInst,OCTET oMsg,H_NETDATA hData);

/*
 * PppoEClientInstanceULInterfaceCreate
 *  Create the UL interface. There can be only one of these.
 *
 *  Args:
 *   hInst                   instance handle
 *
 *  Return:
 *   interface handle
 */
H_NETINTERFACE PppoEClientInstanceULInterfaceCreate(H_NETINSTANCE hInst);

/*
 * PppoEClientInstanceULInterfaceDestroy
 *  Destroy the UL interface.
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     interface handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceULInterfaceDestroy(H_NETINSTANCE hInst,
                                           H_NETINTERFACE hIf);

/*
 * PppoEClientInstanceULInterfaceIoctl
 *  Destroy the UL interface.
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     interface handle
 *   oIoctl                  ioctl code
 *   hData                   data handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceULInterfaceIoctl(H_NETINSTANCE hInst,
                                         H_NETINTERFACE hIf,
                                         OCTET oIoctl,
                                         H_NETDATA hData);


/*
 * PppoEClientInstanceLLInterfaceCreate
 *  Create the LL interface. There can be only one of these.
 *
 *  Args:
 *   hInst                   instance handle
 *
 *  Return:
 *   interface handle
 */
H_NETINTERFACE PppoEClientInstanceLLInterfaceCreate(H_NETINSTANCE hInst);

/*
 * PppoEClientInstanceLLInterfaceDestroy
 *  Destroy the LL interface.
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     interface handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceLLInterfaceDestroy(H_NETINSTANCE hInst,
                                           H_NETINTERFACE hIf);

/*
 * PppoEClientInstanceLLInterfaceIoctl
 *  Destroy the LL interface.
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     interface handle
 *   oIoctl                  ioctl code
 *   hData                   data handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppoEClientInstanceLLInterfaceIoctl(H_NETINSTANCE hInst,
                                         H_NETINTERFACE hIf,
                                         OCTET oIoctl,
                                         H_NETDATA hData);

/*
 * PppoEClientInstanceWrite
 *  PPPoE client write function. packet based
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     UL interface handle
 *   pxPacket                packet
 *   pxAccess                Access information
 *   hData                   casted NETIFID *
 *
 *  Return:
 *   Length written if success
 */
LONG PppoEClientInstanceWrite(H_NETINSTANCE hInst,H_NETINTERFACE hIf,
                              NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                              H_NETDATA hData);

/*
 * PppoEClientInstanceRcv
 *  PPPoE client Rcv function. packet based
 *
 *  Args:
 *   hInst                   instance handle
 *   hIf                     UL interface handle
 *   pxPacket                packet
 *   pxAccess                Access information
 *   hData                   casted ETHID *
 *
 *  Return:
 *   Length written if success
 */
LONG PppoEClientInstanceRcv(H_NETINSTANCE hInst,H_NETINTERFACE hIf,
                            NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                            H_NETDATA hData);

/*
 * PppoEClientInstanceProcess
 *  PPPoE client process function.
 *
 *  Args:
 *   hInst                   instance handle
 *
 *  Return:
 *   Delay till next call
 */
LONG PppoEClientInstanceProcess(H_NETINSTANCE hInst);




#endif /* _PPPOECLIENT_H_ */

