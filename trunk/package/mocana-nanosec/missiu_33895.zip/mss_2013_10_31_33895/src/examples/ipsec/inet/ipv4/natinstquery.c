/*
 * natinstquery.c
 *
 * Implements NAT
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/

#include "nat.h"
#include "nat_defs.h"

/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * NatInstanceQuery
 *  Query a Nat Instance Option
 *
 *  Args:
 *   hNat                   NAT instance
 *   oOption                Option
 *   phData                 Option data pointer (to fill up)
 *
 *  Return:
 *   NETERR_NOERR success
 *   NETERR_UNKNOWN error
 */
LONG NatInstanceQuery(H_NETINSTANCE hNat,
                      OCTET oOption,
                      H_NETDATA *phData)
{
  NATSTATE *pxNat = (NATSTATE *)hNat;
  LONG lReturn = NETERR_NOERR;

  NAT_CHECK_STATE(pxNat);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_ERROR))
  {
    /*NAT_DBGP(DBGLVL_ERROR_RARE, "NatInstanceQuery: Option: %x\n", oOption);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NatInstanceQuery: Option: ", oOption);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oOption) {
  case NETOPTION_FREE:
  case NETOPTION_MALLOC:
    break;
  case NETOPTION_PAYLOADMUTEX:
    *phData = (H_NETDATA)pxNat->pxMutex;
    break;

  case NETOPTION_OFFSET:
    *phData = (H_NETDATA)pxNat->wOffset;
    break;

  case NETOPTION_TRAILER:
    *phData = (H_NETDATA)pxNat->wTrailer;
    break;

  case NETOPTION_NETCBK:
    *phData = (H_NETDATA)pxNat->pfnNetCbk;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
  }

  return lReturn;
}
