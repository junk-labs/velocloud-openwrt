/*
** Compute the H.223 Extended-BCH (16,5,8) coder/decoder.
**
**
** Hossein Sedarat   Nov 98
*/

#include <NNstyle.h>
#include <stdlib.h>
#include <stdio.h>

#include "ecc.h"

#include "weight.h"

#define DIM 5
#define CODLEN 16

#define REDND (CODLEN-DIM)



/* the parity check matrices */
static WORD awH1[CODLEN] = { 0x8000,  0x4000,  0x2000,  0x1000, 
							 0x0800,  0x0400,  0x0200,  0x0100, 
							 0x0080,  0x0040,  0x0020,  0xD360,
							 0x7AC0,  0x3D60,  0xCDC0,  0xA6E0 };

static WORD awH2[CODLEN] = { 0x0537,  0x07AC,  0x03D6,  0x01EB,
							 0x0759,  0x0400,  0x0200,  0x0100, 
							 0x0080,  0x0040,  0x0020,  0x0010, 
							 0x0008,  0x0004,  0x0002,  0x0001 };

static WORD eye[CODLEN]  = { 0x8000,  0x4000,  0x2000,  0x1000, 
							 0x0800,  0x0400,  0x0200,  0x0100, 
							 0x0080,  0x0040,  0x0020,  0x0010, 
							 0x0008,  0x0004,  0x0002,  0x0001 }; 

/*
   generates the redundant vector wR for
   the input data vector wD. The final 
   codeword is the concatenation of wD 
   and wR.
*/
WORD EccBCH5Encoder( WORD wD )
{
  WORD wR;
  int i;
  
  wR = 0;
  for (i=REDND; i<CODLEN; i++)
	if (0 != (wD & eye[i])) wR ^= awH1[i];

  return wR;
}


/*
  pwCode is the codeword to be corrected.

  returns  0 if no error in the data part, 
           1 if recoverable error, and
		  -1 if unrecoverable error.
*/
int EccBCH5Decoder( WORD *pwCode )
{
  int i, j, iW;
  WORD wSyndrom1, wSyndrom2;
  WORD wCode;

  wCode = *pwCode;

  wSyndrom1 = 0;
  wSyndrom2 = 0;
  for (i=0; i<CODLEN; i++) {
	if (0 != (wCode & eye[i])) wSyndrom1 ^= awH1[i];
	if (0 != (wCode & eye[i])) wSyndrom2 ^= awH2[i];
  }

  iW = WEIGHT16( wSyndrom1 );
/*
if( iW!=0 )	printf("input = %x    output = %x   syndrom1 = %x   weight = %d\n",(int)(wCode&0x7f), (int)wCode, (int)wSyndrom1, iW);
iW = WEIGHT16( wSyndrom2 );
if( iW!=0 )	printf("input = %x    output = %x   syndrom2 = %x   weight = %d\n",(int)(wCode&0x7f), (int)wCode, (int)wSyndrom2, iW);
return 0;
*/

  if (iW <= 3) {
	*pwCode ^= wSyndrom1;
	return 0;
  }

  iW = WEIGHT16( wSyndrom2 );
  if (iW <= 3) {
	*pwCode ^= wSyndrom2;
	return 1;
  }

  for (i=0, j=REDND; i<DIM; i++, j++) {
	if (WEIGHT16(wSyndrom1 ^ awH1[j]) <= 2) {
	  *pwCode ^= (wSyndrom1 ^ awH1[j]);
	  *pwCode ^= eye[j];
	  return 1;
	}
	if (WEIGHT16(wSyndrom2 ^ awH2[i]) <= 2) {
	  *pwCode ^= (wSyndrom2 ^ awH2[i]);
	  *pwCode ^= eye[i];
	  return 1;
	}
  }

  return -1;
}
