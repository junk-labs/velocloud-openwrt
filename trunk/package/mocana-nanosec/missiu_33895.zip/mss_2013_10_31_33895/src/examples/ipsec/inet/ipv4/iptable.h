/*
 * iptable.h
 *
 * ip info repository library. Gathers all info about
 *  IP in the unit
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _IPTABLE_H_
#define _IPTABLE_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * IPTABLEMSG
 */
#define IPTABLEMSG_ADDENTRY          0    /* Adds an IP entry. data is
                                             IPTABLEENTRY * */
#define IPTABLEMSG_DELENTRY          1    /* data is IPTABLEENTRY *.
                                             Delete all matching entries */
#define IPTABLEMSG_SETNETMASK        2    /* Sets an entry NetMask. data
                                             is IPTABLEENTRY *. The settings
                                             will apply to all entries that
                                             match. Returns the number of
                                             matches */
#define IPTABLEMSG_SETVLAN           3    /* Sets an entry default Vlan.
                                             data is IPTABLEENTRY *. The
                                             settings will apply to all
                                             entries that match. Returns
                                             the number of matches */
#ifdef IPTABLE_UNUSED /* Currently unused */
#define IPTABLEMSG_SETIF             4    /* Sets an entry if idx.
                                             data is IPTABLEENTRY. The
                                             settings will apply to all
                                             entries that match. Returns the
                                             number of matches */
#endif
#define IPTABLEMSG_SETADDR           5    /* Sets an entry Ip address.
                                             data is IPTABLEENTRY. The
                                             settings will apply to all
                                             entries that match. If no match
                                             is found, it will create a new
                                             entry. Returns the
                                             number of matches */
/* IPTABLEMSG_GETDEFAULT not available in single interface builds */
#define IPTABLEMSG_GETDEFAULT        6    /* Gets the default entry,
                                             using the passed IPTABLEENTRY *
                                             field as restrictions. The
                                             default is the 1st entry
                                             created. return NETERR_UNKNOWN
                                             if none find */
#ifdef IPTABLE_UNUSED /* Currently unused */
#define IPTABLEMSG_GETALL            7    /* data is IPTABLE *. Data is
                                             IPTABLE. allocates the pxTable
                                             member and fill it up with
                                             the entries matching the
                                             template */
#endif
#define IPTABLEMSG_GETTYPE           8    /* data is IPTABLEENTRY *.
                                             Returns the Ip Addr type,
                                             as defined above */
#define IPTABLEMSG_GETIFIDX          9    /* data is IPTABLEENTRY *.
                                             Returns the interface index */

/*****************************************************************************
 *
 * typedef
 *
 *****************************************************************************/

/*
 * Entry structure
 */
typedef struct {
  DWORD dwAddr;          /* Ip address. 0 means "any" */
  WORD  wDefaultVlan;    /* Default Vlan */
  OCTET oIfIdx;          /* Interface index */
  E_ADDRTYPE eAddrType;     /* Address type */
  union {
    DWORD dwIpNetMask;       /* Ip NetMask */
    struct {
      WORD wMcastUserCount;  /* Mcast user count */
    } xMcast;
  } u;
} IPTABLEENTRY;

/*
 * Entry repository structure
 */
typedef struct {
  IPTABLEENTRY *pxEntryTable;
  DWORD dwTableSize;
} IPTABLEREPOSITORY;

/*
 * Table structure
 */
typedef struct {
  IPTABLEENTRY xTemplate;  /* The template defines which field are
                              used for discrimination accross the table.
                              oAddrType == IPADDRT_ANY means "any IP addr"
                              dwNetMask == 0 means "any"
                              wDefaultVlan == NETVLAN_ANY means "any"
                              oIfIdx == NETIFIDX_ANY means "any"
                              */
  IPTABLEREPOSITORY xRepository;
} IPTABLE;

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * IpTableInitialize
 *  Initializes the ip tables
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpTableInitialize(void);

/*
 * IpTableTerminate
 *  Initializes the ip tables
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpTableTerminate(void);

/*
 * IpTableMsg
 *  Initializes the ip tables
 *
 *  Args:
 *   oMsg              Msg code. See defines above
 *   hData             Data handle. specifics defined for each messages
 *                     (see message definition above)
 *
 *  Return:
 *   < 0 == errors. For specific code, see message definition
 */
LONG IpTableMsg(OCTET oMsg,H_NETDATA hData);

#ifdef NETDBG_HI
/*
 * Debug routines
 */
void  IpTablePrint(void);
CHAR* IpAddressTypeToString(E_ADDRTYPE eIpAddrType);
#endif

#endif /* _IPTABLE_H_ */
