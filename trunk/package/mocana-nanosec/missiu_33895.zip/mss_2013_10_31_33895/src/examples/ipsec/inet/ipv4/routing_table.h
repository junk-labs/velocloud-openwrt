/*
 * routing_table.h
 *
 * routing table module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _ROUTING_TABLE_H_
#define _ROUTING_TABLE_H_

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"

#ifdef _RADIX_ROUTING_ON_
#include "radix.h"
#endif

/*****************************************************************************
 *
 * Enums and constants
 *
 *****************************************************************************/
/*Routing Table option */


/* Routing Table specific Msg */
#define ROUTINGTABLEMSG_ADDROUTE    \
          (NETMSG_MODULESPECIFICBEGIN)        /* Add a route, parameter is ROUTEENTRY*/

#define ROUTINGTABLEMSG_DELROUTE    \
          (NETMSG_MODULESPECIFICBEGIN + 1)    /* Delete a route, paramater is ROUTEENTRY*/

#define ROUTINGTABLEMSG_FINDROUTE    \
          (NETMSG_MODULESPECIFICBEGIN + 2)    /* Get a route, paramter is ROUTEENTRY, used as a value-return argument */


#define    ROUTINGTABLEMSG_SETSTATICROUTE  \
          (NETMSG_MODULESPECIFICBEGIN + 3)    /* Set a static route,
                                                 paramter is STATICROUTEENTRY */

#define    ROUTINGTABLEMSG_GETNUMROUTE  \
          (NETMSG_MODULESPECIFICBEGIN + 4)    /* Gets the number of routes */

#define    ROUTINGTABLEMSG_GETROUTE  \
          (NETMSG_MODULESPECIFICBEGIN + 5)    /* Gets all the routes.  */

#define    ROUTINGTABLEMSG_GETDEFAULTIDX  \
          (NETMSG_MODULESPECIFICBEGIN + 6)    /* Gets all the routes.  */

#define    ROUTINGTABLEMSG_SETBRIDGEDIDX  \
          (NETMSG_MODULESPECIFICBEGIN + 7)    /* Set an oIfIdx as bridged,
                                                 paramter is ROUTESETBRIDGEDIDX */

#define    ROUTINGTABLEMSG_SETLINKSTATUS  \
          (NETMSG_MODULESPECIFICBEGIN + 8)    /* Set an oIfIdx as bridged,
                                                 paramter is ROUTINGTABLELINKSTATUS */

#define ROUTINGTABLEMSG_CLI_GETALLROUTES \
          (NETMSG_MODULESPECIFICBEGIN + 9)    /*
                                               * Get all the entries within the Routing table for CLI module
                                               */
/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/

typedef struct {
#ifdef _RADIX_ROUTING_ON_
  RADIXNODE xRouteNodes[2]; /*Destination & Subnet Mask are stored within the RADIXNODE[0]*/
#else
  DWORD dwDstAddr;
  DWORD dwSubnetMask;
#endif
  DWORD dwGateway;
  WORD  wTOS;
  WORD  wMetric;
  WORD  wVlan;
  OCTET oIfIdx;
  OCTET oType;
  E_ADDRTYPE eDstAddrType;
} ROUTEENTRY;

typedef struct {
  DWORD dwIndex;
  BOOL bNullifyEntry;
  struct rtentry* pxRtEntry;
} STATICROUTEENTRY;

typedef struct {
  DWORD dwBufSize;
  struct rtentry* pxRtEntries;
  DWORD *pdwOutSize;
} ROUTEGETROUTE;

typedef struct {
  OCTET oIfIdx;
  BOOL bBridged;
} ROUTESETBRIDGEDIDX;

typedef struct {
  OCTET oIfIdx;
  BOOL bIsLinkUp;
} ROUTINGTABLESETLINKSTATUS;

#ifdef __MOC_CLI__
typedef struct
{
  ubyte *poSbuf;
  ubyte4 dwSbufLen;
} ROUTINGTABLECLIGET;
#endif

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * RoutingTableInitialize
 *  Initialize the Routing Table library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG RoutingTableInitialize(void);

/*
 * RoutingTableTerminate
 *  Terminate the Routing Table library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG RoutingTableTerminate(void);

/*
 * RoutingTableMsg
 *  Send a msg to a Routing Table instance
 *
 *  Args:
 *   hRoutingTable                    Routing Table instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG RoutingTableMsg(OCTET oMsg,H_NETDATA hData);

#endif /* #ifndef _ROUTING_TABLE_H_ */
