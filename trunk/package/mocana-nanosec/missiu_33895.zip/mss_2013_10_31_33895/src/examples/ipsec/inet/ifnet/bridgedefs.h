/*
 * ethdefs.h
 *
 * ethernet common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ETHDEFS_H_
#define _ETHDEFS_H_

/*
 * Internal defaults
 */
#define ETH_DEFAULTIFBITRATE             100000  /* 100Mbits/s in Kbits/s */
#define ETH_DEFAULTIFBCASTPERCENTLIMIT   100     /* 100% */
#define ETH_DEFAULTIFMCASTPERCENTLIMIT   100     /* 100% */

#define ETHTIME_MAXPROCESS    1000   /* Used in the process routine to determin
                                      * the maximum time between eth process calls */
#define ETHTIME_MINPROCESS    5      /* Same as above only minimum */

#define ETH_MAXULIF  (3 + 2*8) /*ARP,RARP,IP,PPPOE,PPPOE_SESSION*/

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * Ethernet UL module plug-in structure
 */
typedef struct {
  H_NETINTERFACE hUlIf; /* Id passed to the Rx Cbk */
  H_NETINSTANCE hUlInst;
  PFN_NETRXCBK pfnRxCbk;
  WORD wRoutingId;   /* Routing Id */
  OCTET oIfIdx;
} ETH_UL;

/*
 * Ethernet LL module plug-in structure
 */
typedef struct {
  /* The following are used in this module */
  WORD wDefaultVlan;
  OCTET obOpen;           /* Flag indicates if LL is open */
  OCTET obBridged;        /* Flag indicates if LL is to be included in the bridging */
  OCTET oPortNo;          /* Bridge port number - used with the spanning tree code */
  OCTET oIfIdx;           /* Net physical interface */
  OCTET obIngressFilter;  /* Enable lan filtering */
  DWORD dwBitRate;        /* Bit rate in kbits/s */
  OCTET oBcastPercent;    /* Broadcast percentage limit */
  OCTET oMcastPercent;    /* Multicast percentage limit */
  DWORD dwBcastLimit;     /* Broadcast limit in bytes/s */
  DWORD dwMcastLimit;     /* Multicast limit in bytes/s */
  DWORD dwBcastByteCount; /* Holds the number of broadcast bytes rcvd */
  DWORD dwMcastByteCount; /* Holds the number of multicast bytes rcvd */

  /* The following correspond to UL of the module beneath */
  H_NETINTERFACE hLlIf;   /* Id passed to pfnLlWrite */
  H_NETINSTANCE hLlInst;  /* Instance passed to pfnLlWrite */
  PFN_NETWRITE  pfnLlWrite;
} ETH_LL;


/*
 * Ethernet instance main structure
 */
typedef struct {
  /* Basic structure override protection */
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif
  /* Options */
  WORD wOffset;
  WORD wTrailer;

  PFN_NETFREE pfnFree;
  PFN_NETMALLOC pfnMalloc;
  pthread_mutex_t *pxMutex;

  OCTET aaoIfEthAddr[ETHBR_MAXNUM_IF][ETHADDRESS_LEN];

  WORD *pwSpecificVlan;
  OCTET oSpecificVlanNumber;
  OCTET obSpanningEnabled;
  OCTET obForwardPPPoEOnly;
  E_ETHIFSTAT aeInitialPortState[ETHBR_MAXNUM_IF];

  OCTET obLocalLoopback;
  OCTET obAdmitOnlyVlan;
  OCTET oLanIdx;            /* Indicates which net oIfidx is the LAN */

  /* UL modules */
  ETH_UL *apxUl[ETH_MAXULIF];
  OCTET oUlNumber;

  /* LL interface */
  ETH_LL *pxLl;
  OCTET oLlNumber;
  ETH_LL *apxIfToLlMap[ETHBR_MAXNUM_IF];

  /* Number of bridged LL if */
  OCTET oNumBridgePorts;

  /* Is packet being received one that has been sent from stack */
  BOOL bSendingPktIn;

} ETHSTATE;

/*****************************************************************************
 *
 * function
 *
 *****************************************************************************/

void _LearningProcess(ETH_LL *pxLl, OCTET *poSrcAddr, WORD wVlan);

LONG _ForwardingProcess(ETHSTATE *pxEth,
                        ETH_LL *pxLl,
                        NETPACKET *pxPacket,
                        NETPACKETACCESS *pxAccess,
                        WORD wVlan);

void _EgressProcess(ETHSTATE *pxEth,
                    ETH_LL *pxLl,
                    NETPACKET *pxPacket,
                    NETPACKETACCESS *pxAccess,
                    WORD wVlan);

#ifdef BRIDGEDBG_HI
CHAR *EthProtoToString(WORD wProtocol);
#endif
/*****************************************************************************
 *
 * extern
 *
 *****************************************************************************/

#ifdef BRIDGEDBG_HI
MOC_EXTERN const OCTET *apoEthOptionString[ETHOPTION_MAX];
MOC_EXTERN const OCTET *apoEthMsgString[ETHMSG_MAX];
MOC_EXTERN const OCTET *apoStpPortStateString[5];
#endif

#endif /* _ETHDEFS_H_ */
