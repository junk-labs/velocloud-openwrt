#ifndef __WEIGHT_H__
#define __WEIGHT_H__

/*
  utilities to calculate the Hamming weight of
  a binary vector.
*/


/* Hamming wieght for a 4-bit vector */
static OCTET aoWeight[16] = {
  0, 1, 1, 2, 1, 2, 2, 3, 
  1, 2, 2, 3, 2, 3, 3, 4 };

/* Hamming wieght for a 8-bit vector */
#define WEIGHT8(oX)  ( aoWeight[(oX)&0xF] + aoWeight[(oX)>>4] )
/* Hamming wieght for a 16-bit vector */
#define WEIGHT16(wX) ( WEIGHT8((wX)&0xFF) + WEIGHT8((wX)>>8) )
/* Hamming wieght for a 32-bit vector */
#define WEIGHT32(dwX) ( WEIGHT16((dwX)&0xFFFF) + WEIGHT16((dwX)>>16) )


#endif
