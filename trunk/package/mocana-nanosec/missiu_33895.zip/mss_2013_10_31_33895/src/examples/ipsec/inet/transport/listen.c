/*
 * listen.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"
                     /*
 * listen
 *  Used by a TCP server to start listening for connections.
 *
 *  Args:
 *    sockfd                     The socket returned by the socket function.
 *    backlog                    maximum number of connections that should be
 *                               queued; for this sockfd. Ignored, a value of
 *                               1 will be used.
 *  Return:
 *    0 : Success.
 *    -1: Error
 */
int mn_listen(int sockfd, int backlog)
{
  SOCKET *pxSock;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(sockfd);

  if ((pxSock == NULL) || (pxSock->lType != SOCK_STREAM)) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  if ((DWORD)backlog > SOCK_MAXBACKLOG) {
    backlog = SOCK_MAXBACKLOG;
  }

  /* At this stage we now this is a TCP socket */
  ASSERT((pxSock->u.pxTcp != NULL) &&
         (pxSock->u.pxTcp->u.pxListen == NULL));

  /* Create the listening sub member */
  pxSock->u.pxTcp->u.pxListen = (TCPLISTEN *)MALLOC(sizeof(TCPLISTEN));
  ASSERT(pxSock->u.pxTcp->u.pxListen != NULL);
  MOC_MEMSET((ubyte *)pxSock->u.pxTcp->u.pxListen, 0, sizeof(TCPLISTEN));
  pxSock->u.pxTcp->u.pxListen->oBackLogMax = backlog;

  {
    H_NETINSTANCE hTcp = xSocketRep.axProtocols[TCP_INDEX].hInst;

    TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                TCPULINTERFACEIOCTL_LISTEN,(H_NETDATA)0);

    /* Open the socket */
    TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                NETINTERFACEIOCTL_OPEN,(H_NETDATA)0);

    /* Open has forced TCP to set the local port: now get it */
    TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT,
                                (H_NETDATA)&(pxSock->xTransportId.wSrcPort));

  }

  /* The port can not be 0 */
  ASSERT(pxSock->xTransportId.wSrcPort != 0);

  pxSock->dwSockOptions |= SO_ACCEPTCONN;

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return 0;
}


