/*
 * router_ipfiltering.c
 *
 * Routines to handle IP filtering.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "router.h"
#include "router_defs.h"


#ifdef IP_FILTERING
/**********************************************************************************
Function:
        RouterConfigIpFiltering()
Description:
        Configures an IP filtering entry.
Arguments:
        ROUTERSTATE*            pxRouter                Router instance handle.
        ROUTERCFG_IPFILTERING*  pxRouterCfgIpFiltering  IP Filtering configuration.
Outputs:
        None
Returns:
        None
Revisions:
        10-Jan-2003                                     Initial
**********************************************************************************/
void RouterConfigIpFiltering(ROUTERSTATE* pxRouter,
                             ROUTERCFG_IPFILTERING* pxRouterCfgIpFiltering)
{
  IP_FILTERING_ENTRY* pxIpFilteringEntry;
  DWORD dwIndex = pxRouterCfgIpFiltering->dwIndex;

  ASSERT(dwIndex < IP_FILTERING_TABLE_SIZE);
  pxIpFilteringEntry = &pxRouter->axIpFilteringTable[dwIndex];

  /*
   * If this entry has been removed from configuration,
   * just nullify that entry and return.
   */
  if (pxRouterCfgIpFiltering->bNullifyEntry) {
    if (pxIpFilteringEntry->bInUse) {
      pxIpFilteringEntry->bInUse = FALSE;
      ASSERT(pxRouter->oNumIpFilteringEntries > 0);
      pxRouter->oNumIpFilteringEntries--;
    }
    return;
  }

  /*
   * Read the new configuration.
   */
  pxIpFilteringEntry->wFlags = pxRouterCfgIpFiltering->wFlags;
  {
    /*
     * Get the LAN IP address and use the network part of the
     * address.
     */
    IPTABLEENTRY xIpEntry;

    xIpEntry.dwAddr = 0x0;
    xIpEntry.eAddrType = IPADDRT_ANY;
    xIpEntry.wDefaultVlan = NETVLAN_ANY;
    xIpEntry.oIfIdx = pxRouter->oIfIdxLan;

    IpTableMsg(IPTABLEMSG_GETDEFAULT, (H_NETDATA) &xIpEntry);

    ASSERT(xIpEntry.dwAddr);
    pxIpFilteringEntry->dwIp =
      (xIpEntry.dwAddr & xIpEntry.u.dwIpNetMask) | pxRouterCfgIpFiltering->dwIp;
  }

  if (pxIpFilteringEntry->bInUse == FALSE) {
    pxIpFilteringEntry->bInUse = TRUE;
    ASSERT(pxRouter->oNumIpFilteringEntries < IP_FILTERING_TABLE_SIZE);
    pxRouter->oNumIpFilteringEntries ++;
  }
}


/*****************************************************************************
Function:
        RouterIsIpAddrFiltered()
Description:
        Checks if the given IP address is part of the filtered
        addresses list.
Arguments:
        ROUTERSTATE*    pxRouter        Router instance handle.
        DWORD           dwIP            IP address to be checked.
        OCTET           oProtocol       Protocol in the received packet.
Outputs:
        None
Returns:
        BOOL            TRUE            If IP address should be
                                        filtered.
                        FALSE           Otherwise.
Revisions:
        03-Jan-2003                     Initial
*****************************************************************************/
BOOL RouterIsIpAddrFiltered(ROUTERSTATE* pxRouter, DWORD dwIp, OCTET oProtocol)
{
  int i;
  WORD wFlags = (oProtocol == IPPROTO_TCP) ?
                (IP_FILTERING_PROT_TCP) : (IP_FILTERING_PROT_UDP);

  if ((oProtocol != IPPROTO_TCP) && (oProtocol != IPPROTO_UDP))
    return (FALSE);

  if (pxRouter->oNumIpFilteringEntries) {

    for (i = 0; i < IP_FILTERING_TABLE_SIZE; i++) {
      IP_FILTERING_ENTRY* pxIpFilteringEntry = &pxRouter->axIpFilteringTable[i];

      if (pxIpFilteringEntry->bInUse == TRUE) {

        if ((pxIpFilteringEntry->dwIp == dwIp) &&
            (pxIpFilteringEntry->wFlags & wFlags)) {
          return (TRUE);
        }
      }
    }
  }

  return (FALSE);
}
#endif    /* IP_FILTERING */
