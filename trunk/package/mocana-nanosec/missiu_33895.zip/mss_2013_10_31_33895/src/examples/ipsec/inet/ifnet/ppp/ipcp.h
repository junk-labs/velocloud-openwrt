/*
 * ipcp.h
 *
 * IPCP library API IPCP is the IP PPP Control Protocol, as specified in RFC 1332 It uses the PPPCP library as a core, and adds IPCP specific parts
 *     and option to it
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IPCP_H_
#define _IPCP_H_
/*****************************************************************************
 *
 * Constants
 *
 *****************************************************************************/
/*
 * Options
 */
#define IPCPOPTIONDNS_NONE  0xFFFFFFFF

#define IPCPOPTIONDEFAULT_DNS IPCPOPTIONDNS_NONE

/*
 * IPCP specific options
 */
#define IPCPOPTION_LOCALIPADDR \
 (NETOPTION_MODULESPECIFICBEGIN)      /* Local Ip address. Data is DWORD */
#define IPCPOPTION_REMOTEIPADDR \
 (NETOPTION_MODULESPECIFICBEGIN + 1)  /* Remote Ip address. Data is DWORD */
#define IPCPOPTION_PRIMARYDNS \
 (NETOPTION_MODULESPECIFICBEGIN + 2)  /* Primary DNS. Data is DWORD */
#define IPCPOPTION_SCNDARYDNS \
 (NETOPTION_MODULESPECIFICBEGIN + 3)  /* Secondary DNS. Data is DWORD */
#define IPCPOPTION_IFIDX \
 (NETOPTION_MODULESPECIFICBEGIN + 4)  /* physical interface index */
#define IPCPOPTION_VLAN \
 (NETOPTION_MODULESPECIFICBEGIN + 5)  /* Vlan */

/*****************************************************************************
 *
 * IPCP API functions
 *
 *****************************************************************************/

/*
 * IpcpInitialize
 *   Initialize the IPCP library
 *
 *   Args:
 *
 *   Return:
 *
 */
LONG IpcpInitialize(void);

/*
 * IpcpTerminate
 *   Terminate the IPCP library
 *
 *   Args:
 *
 *   Return:
 *
 */
LONG IpcpTerminate(void);

/*
 * IpcpInstanceCreate
 *   Create an IPCP instance
 *
 *   Args:
 *
 *   Return:
 *    instance handle
 */
H_NETINSTANCE IpcpInstanceCreate(void);

/*
 * IpcpInstanceDestroy
 *   Destroy a IPCP instance
 *
 *   Args:
 *    hIpcp                 instance handle
 *
 *   Return:
 *
 */
LONG IpcpInstanceDestroy(H_NETINSTANCE hIpcp);

/*
 * IpcpInstanceSet
 *   Set IPCP options
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceSet(H_NETINSTANCE hIpcp,OCTET oOption,
                      H_NETDATA hData);

/*
 * IpcpInstanceQuery
 *   Query IPCP options
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     oOptio          Option code
 *     phData          data handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceQuery(H_NETINSTANCE hIpcp,OCTET oOption,H_NETDATA * phData);

/*
 * IpcpInstanceMsg
 *   IPCP msg function
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceMsg(H_NETINSTANCE hIpcp,OCTET oMsg,H_NETDATA hData);

/*
 * IpcpInstanceLLInterfaceCreate
 *   Create IPCP LL interface
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE IpcpInstanceLLInterfaceCreate(H_NETINSTANCE hIpcp);

/*
 * IpcpInstanceLLInterfaceDestroy
 *   Destroy IPCP LL interface
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceLLInterfaceDestroy(H_NETINSTANCE hIpcp, H_NETINTERFACE hIf);

/*
 * IpcpInstanceLLInterfaceIoctl
 *   IPCP LL interface ioctl function
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceLLInterfaceIoctl(H_NETINSTANCE hIpcp, H_NETINTERFACE hIf,
                                    OCTET oIoctl,H_NETDATA hData);

/*
 * IpcpInstanceRcv
 *   IPCP instance rcv
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            NETIFID *
 *
 *   Return:
 *     >=0
 */
LONG IpcpInstanceRcv(H_NETINSTANCE hIpcp, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData);

/*
 * IpcpInstanceProcess
 *   IPCP processing function
 *
 *   Args:
 *     hIpcp           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG IpcpInstanceProcess(H_NETINSTANCE hIpcp);


#endif
