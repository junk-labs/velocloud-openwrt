#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void *DLLIST_add_sorted_fl(DLLIST *dllist, void *item, 
			   LONG (*sortfcn)(void *,void *), 
			   char *pFile, int nLine)
{
  DLLIST_ITEM *tmpitem,*headitem;

  if (sortfcn == NULL) sortfcn = this_item;

  headitem = dllist->head;
  
  if (headitem == NULL) {
    return DLLIST_append_fl(dllist, item, pFile, nLine);
  }

  while((sortfcn(headitem->item,item) <= 0) && (headitem->next))
    headitem = headitem->next;

  if ((headitem->next == NULL)
      && (sortfcn(headitem->item,item) <= 0)) {
    return DLLIST_append_fl(dllist, item, pFile, nLine);
  }

  if ((headitem->prev == NULL) && (sortfcn(headitem->item,item) > 0)) {
    return DLLIST_prepend_fl(dllist, item, pFile, nLine);
  }

  tmpitem = new_DLLIST_ITEM_fl(dllist, pFile, nLine);

  if (tmpitem == NULL) {
    return(NULL);
  }

  tmpitem->item = item;
  dllist->count++;
  dllist->cur = tmpitem;
  tmpitem->next = headitem;
  tmpitem->prev = headitem->prev;
  tmpitem->next->prev = tmpitem;
  tmpitem->prev->next = tmpitem;

  return(tmpitem->item);
}

