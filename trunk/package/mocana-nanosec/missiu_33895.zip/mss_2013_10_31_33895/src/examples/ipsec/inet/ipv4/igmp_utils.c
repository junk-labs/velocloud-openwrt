/*
 * igmp_utils.c
 *
 * IGMP module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "igmp_defs.h"
#include "igmp_proxy_defs.h"

/*****************************************************************************
 *
 * Global variables
 *
 *****************************************************************************/

IGMP_DBG_VAR(DWORD g_dwIgmpProxyDebugLevel = ERROR);
IGMP_DBG_VAR(DWORD g_dwIgmpDebugLevel = ERROR);

/*****************************************************************************
 *
 * functions
 *
 *****************************************************************************/
CHAR* IgmpTypeToString(OCTET oType);

/*****************************************************************************
 *
 * IgmpSendPacket
 *
 *****************************************************************************/
LONG IgmpSendPacket(IGMPSTATE *pxIgmp,
                    IPMCASTREQ *pxIpMreq,
                    DWORD dwDstAddr,
                    OCTET oType,
                    OCTET oMaxRespTime,
                    OCTET oTtl,
                    OCTET *poIpOption,
                    OCTET oIpOptionLen)
{
  NETPACKET xPacket;
  NETPACKETACCESS xNetPktAccess;
  OCTET *poPayload;
  IGMP_PKT *pxIgmpPkt;
  WORD wPacketLength;
  NETWORKID xNetworkId;
  LONG lRv;
  IPTABLEENTRY xIpEntry;
#ifdef IPSEC
  void* pxSP=NULL;              /* pointer for Security Policy data structure */
  int nHdrLen=0;
  int nTrailLen=0;
#endif /* IPSEC */

  ASSERT(pxIpMreq != NULL);

  /* Fill the NETWORKID structure */
  MOC_MEMSET((ubyte *)&xNetworkId,0x00,sizeof(NETWORKID));

  xNetworkId.oProtocol = IPPROTO_IGMP;
  xNetworkId.dwDstAddr = dwDstAddr;
  xNetworkId.oTtL = oTtl;
  xNetworkId.oToS = pxIgmp->oTos;
  xNetworkId.poIpOption = poIpOption;
  xNetworkId.oIpOptionLen = oIpOptionLen;
  xNetworkId.eDstAddrType = IPADDRT_MULTICASTJOINED;
  xNetworkId.wVlan = NETVLAN_DEFAULT;    /* VLAN stuff */
  xNetworkId.poIpOption = poIpOption;

  if (pxIpMreq->oPhyIf == NETIFIDX_ANY) {
    xNetworkId.oIfIdx = RoutingTableMsg(ROUTINGTABLEMSG_GETDEFAULTIDX,(H_NETDATA)0);
  } else {
    xNetworkId.oIfIdx = pxIpMreq->oPhyIf;
  }

  /*Source ip address*/
  xIpEntry.oIfIdx = xNetworkId.oIfIdx;
  xIpEntry.wDefaultVlan = xNetworkId.wVlan;
  xIpEntry.eAddrType = IPADDRT_ANY;
  xIpEntry.dwAddr = (DWORD)0;
  lRv = IpTableMsg(IPTABLEMSG_GETDEFAULT,(H_NETDATA)&xIpEntry);
  /* ASSERT(lRv == 0); RS: there may not be any interfaces yet */
  if ( lRv < 0 ) return lRv;

  xNetworkId.dwSrcAddr = xIpEntry.dwAddr;

  /* Payload creation and allocation */
  ASSERT(pxIgmp->wOffset != 0);
  wPacketLength = (WORD)(pxIgmp->wOffset +
                         oIpOptionLen +
                         sizeof(IGMP_PKT) +
                         pxIgmp->wTrailer);

  xNetPktAccess.wOffset = pxIgmp->wOffset + oIpOptionLen;
  xNetPktAccess.wLength = (WORD)(sizeof(IGMP_PKT));

#ifdef IPSEC
  /* check security policy */
  if ((pxSP = IPSecGetSP(xNetworkId.dwDstAddr, 0,
                         xNetworkId.dwSrcAddr, 0,
                         IPPROTO_IGMP, 0))) {
    /* allocate header space for AH or ESP */
    nHdrLen = IPSecGetHdrLen(pxSP);
    /* allocate more space for ESP trailer and ESP-Auth */
    nTrailLen = IPSecGetTrailLen(pxSP,xNetPktAccess.wLength);
    /* update length and offset */
    wPacketLength += (nHdrLen + nTrailLen);
    xNetPktAccess.wOffset += nHdrLen;
    /* store IPSec data into NETWORKID */
    xNetworkId.dwSecurityPolicy = (DWORD)pxSP;
    xNetworkId.wIpSecHdrLength = (WORD)nHdrLen;
    xNetworkId.wIpSecTrailLength = (WORD)nTrailLen;
  }
#endif /* IPSEC */

#ifdef __INET_USE_PAYLOAD_MEMPOOL__
  lRv = NetAllocPayload(&poPayload,wPacketLength);
  if (OK > lRv) {
      return lRv;
  }
#else
  poPayload = (OCTET*)MALLOC(wPacketLength);
#endif
  ASSERT(poPayload != NULL);

  NETPAYLOAD_CREATE(&(xPacket.pxPayload),
                    NetFree,
                    pxIgmp->pxMutex,
                    poPayload,
                    wPacketLength);
  if(NULL == xPacket.pxPayload)
  {
     lRv = NETERR_MEM;
     DEBUG_ERROR(DEBUG_MOC_IPV4, "Error:IgmpSendPacket - NETPAYLOAD_CREATE failed : %d",lRv);
     NetFree(poPayload);
     return(lRv);
  }
  /* Check for int alignment */
  ASSERT((xNetPktAccess.wOffset % sizeof(int)) == 0);
  ASSERT((oIpOptionLen % sizeof(int)) == 0);

  /* Set the Igmp packet pointer */
  pxIgmpPkt = (IGMP_PKT*)(xPacket.pxPayload->poPayload + xNetPktAccess.wOffset);

  /* Fill the packet */
  pxIgmpPkt->oType = oType;
  pxIgmpPkt->oMaxRespTime = oMaxRespTime;
  pxIgmpPkt->dwGroupAddr = pxIpMreq->dwMulticastAddr;
  pxIgmpPkt->wChecksum = 0;
  pxIgmpPkt->wChecksum = Checksum16((OCTET*)pxIgmpPkt, sizeof(IGMP_PKT));

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IGMP_DBGP(REPETITIVE,"IgmpSendPacket:oType=%s,Src=%ld.%ld.%ld.%ld,Dst=%ld.%ld.%ld.%ld,dwGroupAddr:%ld.%ld.%ld.%ld,oIfIdx=%d,Ttl=%d\n",
            IgmpTypeToString(oType),
            IPADDRDISPLAY(xNetworkId.dwSrcAddr),
            IPADDRDISPLAY(xNetworkId.dwDstAddr),
            IPADDRDISPLAY(pxIpMreq->dwMulticastAddr),
            xNetworkId.oIfIdx,
            xNetworkId.oTtL);*/
    DEBUG_PRINT2(DEBUG_MOC_IPV4, "IgmpSendPacket:oType = ", IgmpTypeToString(oType));
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ",Src= ", xNetworkId.dwSrcAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ",Dst=",  xNetworkId.dwDstAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ",dwGroupAddr:", xNetworkId.dwDstAddr);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ",oIfIdx=", xNetworkId.oIfIdx);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", Ttl= ", xNetworkId.oTtL);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /* send the packet */
  ASSERT(pxIgmp->pfnLLWrite != NULL);
  lRv = pxIgmp->pfnLLWrite(pxIgmp->hLL,
                           pxIgmp->hLLIf,
                           &xPacket,
                           &xNetPktAccess,
                           (H_NETDATA)&xNetworkId);
  return lRv;
}

/*********************************************************************
 * IgmpIpMcastLookup
 *
 *********************************************************************/
IP_MCAST* IgmpIpMcastLookup(IGMPSTATE *pxIgmp,IPMCASTREQ *pIpMreq)
{
  IP_MCAST *pIpMcast;

  DLLIST_head(&pxIgmp->dllIpMcast);
  while ((pIpMcast = (IP_MCAST*)DLLIST_read(&pxIgmp->dllIpMcast)) != NULL) {
    if (pIpMcast->xIpMreq.dwMulticastAddr == pIpMreq->dwMulticastAddr &&
        pIpMcast->xIpMreq.oPhyIf == pIpMreq->oPhyIf) {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
      {
        /*IGMP_DBGP(REPETITIVE,"IgmpIpMcastLookup: Found! for multiaddr:%ld.%ld.%ld.%ld,PhyIf:%d\n",
                IPADDRDISPLAY(pIpMreq->dwMulticastAddr),
                pIpMreq->oPhyIf);*/
        DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IgmpIpMcastLookup: Found! for multiaddr:", pIpMreq->dwMulticastAddr);
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ",PhyIf:", pIpMreq->oPhyIf);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }
      return pIpMcast;
    }
    DLLIST_next(&pxIgmp->dllIpMcast);
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IGMP_DBGP(REPETITIVE,"IgmpIpMcastLookup: Not Found (OK) for multiaddr:%ld.%ld.%ld.%ld,PhyIf:%d\n",
            IPADDRDISPLAY(pIpMreq->dwMulticastAddr),
            pIpMreq->oPhyIf);*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IgmpIpMcastLookup: Not Found (OK) for multiaddr:", pIpMreq->dwMulticastAddr);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ",PhyIf:", pIpMreq->oPhyIf);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  return NULL;
}

/*********************************************************************
 * IgmpIpMcastInit
 *
 *********************************************************************/
IP_MCAST* IgmpIpMcastInit(BOOL bJoinFromSocket, IPMCASTREQ *pIpMreq)
{
  IP_MCAST *pIpMcast;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IGMP_DBGP(REPETITIVE,"IgmpIpMcastInit from %s for multiaddr:%ld.%ld.%ld.%ld, interface:%d\n",
            bJoinFromSocket == TRUE ? "socket" : "proxy",
            IPADDRDISPLAY(pIpMreq->dwMulticastAddr),
            pIpMreq->oPhyIf);*/
    DEBUG_PRINT2(DEBUG_MOC_IPV4, "IgmpIpMcastInit from ", (bJoinFromSocket == TRUE ? "socket" : "proxy"));
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "for multiaddr : ", pIpMreq->dwMulticastAddr);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", interface :", pIpMreq->oPhyIf);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  pIpMcast = MALLOC(sizeof(IP_MCAST));
  ASSERT(pIpMcast != NULL);
  MOC_MEMSET((ubyte *)pIpMcast, 0, sizeof(IP_MCAST));

  if (bJoinFromSocket == TRUE) {
    pIpMcast->bJoinFromSocket = TRUE;
  } else {
    pIpMcast->bJoinFromProxy = TRUE;
  }

  pIpMcast->xIpMreq.dwMulticastAddr = pIpMreq->dwMulticastAddr;
  pIpMcast->xIpMreq.oPhyIf = pIpMreq->oPhyIf;
  pIpMcast->oNumMemberships = 1;
  pIpMcast->fpIgmpRcv = IgmpRcvStateIdle;
  pIpMcast->dwTimeResponse = NetGetMsecTime() + RAND(0,UNSOLICITED_REPORT_INTERVAL);

  return pIpMcast;
}

/*********************************************************************
 * IgmpTypeToString
 *
 *********************************************************************/

CHAR* IgmpTypeToString(OCTET oType)
{
  switch(oType) {
  case IGMP_MEMBERSHIP_QUERY :
    return "IGMP_MEMBERSHIP_QUERY";
  case IGMP_V1_MEMBERSHIP_REPORT :
    return "IGMP_V1_MEMBERSHIP_REPORT";
  case IGMP_V2_MEMBERSHIP_REPORT :
    return "IGMP_V2_MEMBERSHIP_REPORT";
  case IGMP_LEAVE_MEMBERSHIP :
    return "IGMP_LEAVE_MEMBERSHIP";
  default:
    return "???";
  }
}

/*********************************************************************
 *  IgmpPrintMcastGroup
 *
 *********************************************************************/
void IgmpPrintMcastGroup(IGMPSTATE *pxIgmp)
{
  IP_MCAST *pxIpMcast;
  int iDx = 0;

  printf("_IgmpPrintMcastGroup\n");

  DLLIST_head(&pxIgmp->dllIpMcast);
  while((pxIpMcast = DLLIST_read(&pxIgmp->dllIpMcast)) != NULL){
    printf("%d:%ld.%ld.%ld.%ld,PhyIf:%d,oNumMemberships:%d,dwTimeResponse:%ld,socket:%s,proxy:%s \n",
           iDx,
           IPADDRDISPLAY(pxIpMcast->xIpMreq.dwMulticastAddr),
           pxIpMcast->xIpMreq.oPhyIf,
           pxIpMcast->oNumMemberships,
           pxIpMcast->dwTimeResponse,
           pxIpMcast->bJoinFromSocket == TRUE ? "TRUE":"FALSE",
           pxIpMcast->bJoinFromProxy == TRUE ? "TRUE":"FALSE");
    iDx++;
    DLLIST_next(&pxIgmp->dllIpMcast);
  }
}

#ifdef IGMPPROXYDBG_HI

/*********************************************************************
 * _IgmpProxyPrintMcastGroup
 *
 *********************************************************************/
void _IgmpProxyPrintMcastGroup(IGMPSTATE *pxIgmp)
{
  MCAST_GROUP *pMcastGroup;
  int iDx = 0;

  printf("_IgmpProxyPrintMcastGroup\n");

  DLLIST_head(&pxIgmp->dllMcastGroups);
  while((pMcastGroup = DLLIST_read(&pxIgmp->dllMcastGroups)) != NULL){
    printf("%d:%ld.%ld.%ld.%ld,oGroupState:%d,dwGroupTimer:%ld,dwRTXTimer:%ld \n",
           iDx,
           IPADDRDISPLAY(pMcastGroup->dwGroupIPAddress),
           pMcastGroup->eGroupState,
           pMcastGroup->dwGroupTimer,
           pMcastGroup->dwRTXTimer);
    iDx++;
    DLLIST_next(&pxIgmp->dllMcastGroups);
  }
}

#endif /* #ifdef IGMPPROXYDBG_HI*/
