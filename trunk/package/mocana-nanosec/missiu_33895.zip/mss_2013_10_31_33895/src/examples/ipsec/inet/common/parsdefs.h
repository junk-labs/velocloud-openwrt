/*
 * parsdefs.h
 *
 * macros to help in parsing structs
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __PARSDEFS_H__
#define __PARSDEFS_H__



/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

#include "NNstyle.h"


/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/

#define SWAP_DWORD(ul) (bSwapEndian ?                     \
             (((unsigned long) (ul) << 24) |            \
              ((0x0000FF00 & (unsigned long) (ul)) << 8) |    \
              ((0x00FF0000 & (unsigned long) (ul)) >> 8) |    \
              ((0xFF000000 & (unsigned long) (ul)) >> 24))    \
            :                            \
             ((unsigned long) (ul)))

#define SWAP_ENUM(ul) SWAP_DWORD(ul)

#define SWAP_LONG(ul) SWAP_DWORD(ul)

#define SWAP_POINTER(ul) SWAP_DWORD(ul)

#define SWAP_HANDLE(ul) SWAP_DWORD(ul)

#define SWAP_DRAM_P(ul) SWAP_DWORD(ul)

#define SWAP_WORD(ul)  (bSwapEndian ?                     \
             (((0x000000FF & (unsigned long) (ul)) << 8) |    \
              ((0x0000FF00 & (unsigned long) (ul)) >> 8))    \
            :                            \
             ((unsigned long) (ul)))

#define SWAP_SHORT(ul) SWAP_WORD(ul)

#define SWAP_OCTET(ul)  (ul)


#define FORMAT_DWORD "0x%08lX"

#define FORMAT_LONG "%ld"

#define FORMAT_ENUM FORMAT_DWORD

#define FORMAT_POINTER FORMAT_DWORD

#define FORMAT_HANDLE FORMAT_DWORD

#define FORMAT_DRAM_P FORMAT_DWORD

#define FORMAT_WORD "0x%04lX"

#define FORMAT_SHORT FORMAT_WORD

#define FORMAT_OCTET "0x%02lX"


#define MAP_STATE(s) \
  fprintf(hOutFile, "           0x%03lX  " #s "\n", (DWORD) (s))

#define MAP_WFLAG(s) \
  fprintf(hOutFile, "           0x%04lX  " #s "\n", (DWORD) (s))

#define MAP_DWFLAG(s) \
  fprintf(hOutFile, "           0x%08lX  " #s "\n", (DWORD) (s))


#define PRINT_NAME(s, t, f)                        \
  fprintf(hOutFile, " 0x%03lX   " #t " " #f,                 \
      (DWORD) ((OCTET *) &(s.f) - (OCTET *) &(s)))

#define PRINT_PNAME(s, t, f)                        \
  fprintf(hOutFile, " 0x%03lX   " #t " *" #f,                 \
      (DWORD) ((OCTET *) &(s.f) - (OCTET *) &(s)))

#define PRINT_PPNAME(s, t, f)                        \
  fprintf(hOutFile, " 0x%03lX   " #t " **" #f,                 \
      (DWORD) ((OCTET *) &(s.f) - (OCTET *) &(s)))


#define PRINT_DWORD_VALUE(s, f)                        \
  fprintf(hOutFile, " " FORMAT_DWORD "\n", SWAP_DWORD(s.f))

#define PRINT_LONG_VALUE(s, f)                        \
  fprintf(hOutFile, " " FORMAT_LONG "\n", SWAP_LONG(s.f))

#define PRINT_ENUM_VALUE(s, f) PRINT_DWORD_VALUE(s, f)

#define PRINT_POINTER_VALUE(s, f) PRINT_DWORD_VALUE(s, f)

#define PRINT_DRAM_P_VALUE(s, f)                    \
  fprintf(hOutFile, " " FORMAT_DWORD " (" FORMAT_DWORD ")\n",        \
      SWAP_DWORD(s.f), 4 * SWAP_DWORD(s.f))

#define PRINT_WORD_VALUE(s, f)                        \
  fprintf(hOutFile, " " FORMAT_WORD "\n", SWAP_WORD(s.f))

#define PRINT_SHORT_VALUE(s, f) PRINT_WORD_VALUE(s, f)

#define PRINT_OCTET_VALUE(s, f)                        \
  fprintf(hOutFile, " " FORMAT_OCTET "\n", SWAP_OCTET(s.f))

#define PRINT_VECTOR_VALUE(s,  f)                    \
  fprintf(hOutFile, " (" FORMAT_WORD ", " FORMAT_WORD ")\n",         \
          SWAP_WORD(s.f.x), SWAP_WORD(s.f.y))

#define PRINT_QUEUE_VALUE(s,  f)                    \
  fprintf(hOutFile, " front:" FORMAT_POINTER                \
                    ", back:" FORMAT_POINTER                 \
                    ", cursor:" FORMAT_POINTER "\n",             \
          SWAP_POINTER(s.f.pFront),                    \
          SWAP_POINTER(s.f.pBack),                    \
      SWAP_POINTER(s.f.ppCursor))

#define PRINT_CQUEUE_VALUE(s,  f)                    \
  fprintf(hOutFile, " front:" FORMAT_POINTER                \
                    ", back:" FORMAT_POINTER                 \
                    ", cursor:" FORMAT_POINTER                 \
                    ", count:" FORMAT_WORD "\n",             \
          SWAP_POINTER(s.f.q.pFront),                    \
          SWAP_POINTER(s.f.q.pBack),                    \
      SWAP_POINTER(s.f.q.ppCursor),                    \
      SWAP_POINTER(s.f.wCnt))

#define PRINT_CLLIST_VALUE(s,  f)                    \
  fprintf(hOutFile, "\n         anchor:" FORMAT_POINTER            \
                    ", curr:" FORMAT_POINTER                 \
                    ", cnt:" FORMAT_DWORD                 \
                    ", flags:" FORMAT_DWORD "\n",             \
          SWAP_POINTER(s.f.pAnchor),                    \
          SWAP_POINTER(s.f.pCurr),                    \
      SWAP_DWORD(s.f.dwCount),                    \
      SWAP_DWORD(s.f.fFlags));                    \
  MAP_DWFLAG(CLL_FLAG_WAS_FOUND)

#define PRINT_SAHIST8_VALUE(s,  f)                    \
  fprintf(hOutFile, "\n         range shift:" FORMAT_WORD        \
                    ", bucket size:" FORMAT_DWORD            \
                    ", current limit:" FORMAT_DWORD            \
                    "\n           " FORMAT_DWORD             \
                    "\n           " FORMAT_DWORD             \
                    "\n           " FORMAT_DWORD             \
                    "\n           " FORMAT_DWORD             \
                    "\n           " FORMAT_DWORD             \
                    "\n           " FORMAT_DWORD             \
                    "\n           " FORMAT_DWORD             \
                    "\n           " FORMAT_DWORD             \
                    "\n",                         \
          SWAP_DWORD(s.f.wRangeShift),                    \
          (unsigned long) (1 << SWAP_DWORD(s.f.wRangeShift)),        \
          SWAP_DWORD(s.f.dwLimit),                    \
      SWAP_DWORD(s.f.adwBkt[0]),                    \
      SWAP_DWORD(s.f.adwBkt[1]),                    \
      SWAP_DWORD(s.f.adwBkt[2]),                    \
      SWAP_DWORD(s.f.adwBkt[3]),                    \
      SWAP_DWORD(s.f.adwBkt[4]),                    \
      SWAP_DWORD(s.f.adwBkt[5]),                    \
      SWAP_DWORD(s.f.adwBkt[6]),                    \
      SWAP_DWORD(s.f.adwBkt[7]))

#define PRINT_XSTAT_VALUE(s,  f)                    \
  fprintf(hOutFile, "\n         count:" FORMAT_DWORD            \
                    ", max:" FORMAT_DWORD                \
                    ", min:" FORMAT_DWORD                \
                    "\n         total: 0x%08lX%08lX"             \
                    "\n",                         \
          SWAP_DWORD(s.f.dwCnt),                    \
          SWAP_DWORD(s.f.dwMax),                    \
      SWAP_DWORD(s.f.dwMin),                    \
      SWAP_DWORD(s.f.ddTotal.dwHi),                    \
      SWAP_DWORD(s.f.ddTotal.dwLo));                \
  fprintf(hOutFile, "\n         histogram:");                \
  PRINT_SAHIST8_VALUE(s.f, xHist)


#define PRINT_FIELD(s, t, f)                        \
  PRINT_NAME(s, t, f);                            \
  PRINT_##t##_VALUE(s, f)

#define PRINT_EFIELD(s, t, f)                        \
  PRINT_NAME(s, t, f);                            \
  PRINT_ENUM_VALUE(s, f)

#define PRINT_PFIELD(s, t, f)                        \
  PRINT_PNAME(s, t, f);                            \
  PRINT_POINTER_VALUE(s, f)

#define PRINT_PPFIELD(s, t, f)                        \
  PRINT_PPNAME(s, t, f);                        \
  PRINT_POINTER_VALUE(s, f)

#define PRINT_HFIELD(s, t, f)                        \
  PRINT_NAME(s, t, f);                            \
  PRINT_DWORD_VALUE(s, f)

#define PRINT_QFIELD(s, t, f)                        \
  PRINT_NAME(s, t, f);                            \
  PRINT_QUEUE_VALUE(s, f)

#define PRINT_CQFIELD(s, t, f)                        \
  PRINT_NAME(s, t, f);                            \
  PRINT_CQUEUE_VALUE(s, f)

#define PRINT_CLLFIELD(s, t, f)                        \
  PRINT_NAME(s, t, f);                            \
  PRINT_CLLIST_VALUE(s, f)

#define PRINT_XSTFIELD(s, t, f)                        \
  PRINT_NAME(s, t, f);                            \
  PRINT_XSTAT_VALUE(s, f)

#define PRINT_SAH8FIELD(s, t, f)                    \
  PRINT_NAME(s, t, f);                            \
  PRINT_SAHIST8_VALUE(s, f)


#define PRINT_STATE(s, t, f)                        \
  PRINT_NAME(s, t, f);                            \
  fprintf(hOutFile, " " FORMAT_ENUM, SWAP_ENUM(s.f));            \
  fprintf(hOutFile, " = %s\n",                        \
      a_##t##_Names[SWAP_ENUM(s.f)].szName);


/********************************************************************
 *
 * Typedefs
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Functional API
 *
 ********************************************************************/

/* none */


#endif    /* __PARSDEFS_H__ */
