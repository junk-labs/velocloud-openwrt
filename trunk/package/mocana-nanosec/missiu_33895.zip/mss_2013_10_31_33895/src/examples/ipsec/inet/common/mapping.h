#ifndef __MAPPING_H__
#define __MAPPING_H__

#include "NNstyle.h"

typedef struct MAPPING_ENTRY_STRING {
  LONG lNumber;
  CHAR *pchString;
} MAPPING_ENTRY_STRING;

typedef struct MAPPING_ENTRY_OCTET {
  OCTET oFrom;
  OCTET oTo;
} MAPPING_ENTRY_OCTET;


OCTET *MappingNum2Str(const MAPPING_ENTRY_STRING *pTable, DWORD dwTableSize, 
                      LONG lNumber);

LONG MappingStr2Num(const MAPPING_ENTRY_STRING *pTable, DWORD dwTableSize, 
                    CHAR *pcString, LONG *plNumber);

LONG MappingOct2Oct(const MAPPING_ENTRY_OCTET *pTable,  DWORD dwTableSize, 
                    OCTET oFrom, OCTET *poTo, BOOL bReverse);

#endif
