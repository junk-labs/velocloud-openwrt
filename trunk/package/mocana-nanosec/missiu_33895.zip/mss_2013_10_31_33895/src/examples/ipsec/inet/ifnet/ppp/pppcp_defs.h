/*
 * pppcp_defs.h
 *
 * PPP Control Protocol definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

 /*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#ifndef PPPCP_DEFS_H
#define PPPCP_DEFS_H

#include "NNstyle.h"

#include "pppcp_flavor.h"
#include "string.h"
#include "stdlib.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h> /* ntoh macros */
#include <netinet/in.h> /* ntoh macros on Linux/Solaris */
#include <pthread.h>
/* #include <mqueue.h> */
#include <stdio.h>
#include <dllist.h>
#include "netcommon.h"
#include "netutils.h"
#include "netdbg.h"
#include "nettime.h"

#include "pppcp.h"
#include "pppcp_dbg.h"
/*****************************************************************************
 *
 * Defines & macros
 *
 *****************************************************************************/

#define PPPPACKET_MINSIZE 50

/*
 * Max number of event pending
 */
#define PPPCP_EVENTMAX           10

/*
 * PPPCP Actions
 */
#define PPPCPACTIONINDEX_TLU      0
#define PPPCPACTIONINDEX_TLD      1
#define PPPCPACTIONINDEX_TLS      2
#define PPPCPACTIONINDEX_TLF      3
#define PPPCPACTIONINDEX_IRC      4
#define PPPCPACTIONINDEX_ZRC      5
#define PPPCPACTIONINDEX_SCR      6
#define PPPCPACTIONINDEX_SCA      7
#define PPPCPACTIONINDEX_SCN      8
#define PPPCPACTIONINDEX_STR      9
#define PPPCPACTIONINDEX_STA      10
#define PPPCPACTIONINDEX_SCJ      11
#define PPPCPACTIONINDEX_RESTARTOPTION 12
#define PPPCPACTIONINDEX_TIMERDISABLE  13
#define PPPCPACTIONINDEX_SER      14
#define PPPCPACTIONINDEX_NONE     -1

#define PPPCPACTIONSET_MAXSIZE    3
#define PPPCPACTIONINDEX_MAX      15

/*
 * PPPCP Action set indexing
 */
#define PPPCPACTIONSETINDEX_TLS                   0
#define PPPCPACTIONSETINDEX_IRC_SCR               1
#define PPPCPACTIONSETINDEX_TLF                   2
#define PPPCPACTIONSETINDEX_STA                   3
#define PPPCPACTIONSETINDEX_SCJ                   4
#define PPPCPACTIONSETINDEX_RESTARTOPTION         5
#define PPPCPACTIONSETINDEX_IRC_SCR_SCA           6
#define PPPCPACTIONSETINDEX_IRC_SCR_SCN           7
#define PPPCPACTIONSETINDEX_TIMERDISABLE          8
#define PPPCPACTIONSETINDEX_STR                   9
#define PPPCPACTIONSETINDEX_TIMERDISABLE_TLF      10
#define PPPCPACTIONSETINDEX_IRC_STR               11
#define PPPCPACTIONSETINDEX_SCR                   12
#define PPPCPACTIONSETINDEX_SCA                   13
#define PPPCPACTIONSETINDEX_SCN                   14
#define PPPCPACTIONSETINDEX_TIMERDISABLE_IRC      15
#define PPPCPACTIONSETINDEX_SCA_TLU               16
#define PPPCPACTIONSETINDEX_IRC_TLU               17
#define PPPCPACTIONSETINDEX_TLD                   18
#define PPPCPACTIONSETINDEX_TLD_IRC_STR           19
#define PPPCPACTIONSETINDEX_TLD_SCR_SCA           20
#define PPPCPACTIONSETINDEX_TLD_SCR_SCN           21
#define PPPCPACTIONSETINDEX_TLD_SCR               22
#define PPPCPACTIONSETINDEX_TLD_ZRC_STA           23
#define PPPCPACTIONSETINDEX_TIMERDISABLE_IRC_TLU  24

#define PPPCPACTIONSETINDEX_NONE                  -1

#define PPPCPACTIONSETINDEX_MAX                   25


/*
 * PPPCP parsing
 */

/* Header length */
#define PPPCP_HLEN                  4

/* Command codes */
#define PPPCPCOMMAND_MIN              1
#define PPPCPCOMMAND_CONFIGUREREQUEST 1
#define PPPCPCOMMAND_CONFIGUREACK     2
#define PPPCPCOMMAND_CONFIGURENAK     3
#define PPPCPCOMMAND_CONFIGUREREJECT  4
#define PPPCPCOMMAND_TERMINATEREQUEST 5
#define PPPCPCOMMAND_TERMINATEACK     6
#define PPPCPCOMMAND_CODEREJECT       7
#define PPPCPCOMMAND_PROTOCOLREJECT   8
#define PPPCPCOMMAND_ECHOREQUEST      9
#define PPPCPCOMMAND_ECHOREPLY        10
#define PPPCPCOMMAND_DISCARDREQUEST   11
#define PPPCPCOMMAND_MAX              12


/* Command */
#define PPPCPOFFSET_COMMAND        0
#define PPPCPGET_COMMAND(poPacket) ( *(poPacket + PPPCPOFFSET_COMMAND))
#define PPPCPSET_COMMAND(poPacket,oCommand) do {(*(poPacket + PPPCPOFFSET_COMMAND)) = (OCTET)oCommand;} while(0);

/* ID */
#define PPPCPOFFSET_ID             1
#define PPPCPGET_ID(poPacket)       ((OCTET) *(poPacket + PPPCPOFFSET_ID))
#define PPPCPSET_ID(poPacket,oId) do {(*(poPacket + PPPCLPOFFSET_ID)) = (OCTET)oId;} while(0);


/* Length */

#define PPPCPOFFSET_LENGTH         2
#define PPPCPGET_LENGTH(poPacket)   ntohs(\
  ((*((OCTET *)poPacket + PPPCPOFFSET_LENGTH)) << 8) + \
   (*((OCTET *)poPacket + PPPCPOFFSET_LENGTH + 1)))

#define PPPCPOFFSET_DATA           PPPCP_HLEN
#define PPPCPGET_DATAPOINTER(poPacket) ((OCTET *)(poPacket + PPPCPOFFSET_DATA))


/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/
/*
 * Event enumeration
 */
typedef enum {
  PPPCPADMINEVENT_UP = 0,   /* signals to PPPCP that the link is up       */
  PPPCPADMINEVENT_DOWN,     /* signals to PPPCP that the link is down     */
  PPPCPADMINEVENT_OPEN,     /* Management wants to open the PPPCP link    */
  PPPCPADMINEVENT_CLOSE,    /* Management wants to close the PPPCP link   */
  PPPCPADMINEVENT_RUC,      /* Received unknown code. Anytime the protocol
                                 associated with the Control Protocol
                                 receives an undecipherable packet          */
  PPPCPADMINEVENT_TOPLUS,   /* Time-out with Counter > 0                  */
  PPPCPADMINEVENT_TOMINUS,  /* Time-out with Counter == 0                 */
  PPPCPPARSEEVENT_RCRPLUS,  /* Successfull Configure-Request              */
  PPPCPPARSEEVENT_RCRMINUS, /* Configure-Request failure                  */
  PPPCPPARSEEVENT_RCA,      /* Receive-Configure-Ack                      */
  PPPCPPARSEEVENT_RCN,      /* Receive-Configure-Nak                      */
  PPPCPPARSEEVENT_RTR,      /* Receive-Terminate-Request                  */
  PPPCPPARSEEVENT_RTA,      /* Receive-Terminate-Ack                      */
  PPPCPPARSEEVENT_RXJPLUS,  /* Receive-Code-Reject (minor)                */
  PPPCPPARSEEVENT_RXJMINUS, /* Receive-Code-Reject (major)                */
  PPPCPEVENT_ENUMMAX
} E_PPPCPEVENT;



/*
 * Generic event structure
 */
typedef struct {
  E_PPPCPEVENT eType;  /* Event type */
  H_NETDATA hData;     /* Event data handle */
} PPPCPEVENT;

/*
 * Option Action enum
 */
typedef enum {
  PPPCPOPTIONACTION_CODE,     /* code the local option field */
  PPPCPOPTIONACTION_CONFIGURE,/* configure request           */
  PPPCPOPTIONACTION_NAK,      /* Nak                         */
  PPPCPOPTIONACTION_REJECT    /* Reject                      */
} E_PPPCPOPTIONACTION;


/*
 * PPPCP Action
 */
typedef LONG (*PFN_PPPCPACTION)(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);

/*
 * PPPCP Action Set
 */
typedef struct {
  OCTET oActionNum;
  CHAR acActions[PPPCPACTIONSET_MAXSIZE];
} PPPCPACTIONSET;

/*
 * State transition
 */
typedef struct {
  OCTET oNextState;
  CHAR cActionSetIndex;
} PPPCPSTATETRANSITION;



/*
 * PPPCP States
 */
typedef enum {
  PPPCPSTATE_INITIAL = 0,
  PPPCPSTATE_STARTING,
  PPPCPSTATE_CLOSED,
  PPPCPSTATE_STOPPED,
  PPPCPSTATE_CLOSING,
  PPPCPSTATE_STOPPING,
  PPPCPSTATE_REQSENT,
  PPPCPSTATE_ACKRCVD,
  PPPCPSTATE_ACKSENT,
  PPPCPSTATE_OPENED,
  PPPCPSTATE_ENUMMAX
} E_PPPCPSTATE;

/*
 * PPPCP state structure
 */
typedef struct {
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif
  E_PPPCPSTATE eState;   /* State */

  DLLIST xdllEvent;

  DWORD dwCounter;        /* Counter. Used for Configure/Terminate Request */
  DWORD dwTimer;
  BOOL  bTimer;           /* (bTimer == TRUE) <=> the timer is running */

  OCTET *poCurrOptions;   /* Current Configure Request Option Field. It
                             is used for Configure Request Restransmission */
  WORD wCurrOptionsLength;/* Length of the above option Field */

  OCTET aoCurrRcvId[PPPCPCOMMAND_MAX -
                   PPPCPCOMMAND_CONFIGUREREQUEST];/* Last Id for all
                                                      received commands */
  OCTET aoCurrSndId[PPPCPCOMMAND_MAX -
                   PPPCPCOMMAND_CONFIGUREREQUEST];/* Last Is for all
                                                      sent commands */

  PFN_NETFREE pfnNetFree;
  PFN_NETMALLOC pfnNetMalloc;
  pthread_mutex_t *pxNetMutex;
  PFN_NETCBK pfnNetCbk;
  H_NETINSTANCE hNetInst;
  WORD wOffset;
  WORD wTrailer;

  /* Ll interface */
  OCTET oLLNumber;
  PFN_NETWRITE pfnLlWrite;
  H_NETINSTANCE hLl;
  H_NETINTERFACE hLlIf;
  OCTET oIfIdx;
  WORD wVlan;


 /* Settings */
  DWORD dwTimerInitial; /* Timer initial value */
  OCTET oMaxConfigure;         /* Max configure retransmission */
  OCTET oMaxTerminate;         /* Max terminate retransmission */



} PPPCPSTATE;

/* Variables */

MOC_EXTERN const PPPCPACTIONSET axActionSetTable[PPPCPACTIONSETINDEX_MAX];
MOC_EXTERN const PFN_PPPCPACTION axpfnActionTable[PPPCPACTIONINDEX_MAX];
MOC_EXTERN const PPPCPSTATETRANSITION aaxStateTransitionTable[PPPCPSTATE_ENUMMAX][PPPCPEVENT_ENUMMAX];
PPPCP_DBG_VAR(MOC_EXTERN const OCTET *apoPppCpStateString[PPPCPSTATE_ENUMMAX]);
PPPCP_DBG_VAR(MOC_EXTERN const OCTET *apoPppCpEventString[PPPCPEVENT_ENUMMAX]);
PPPCP_DBG_VAR(MOC_EXTERN const OCTET *apoPppCpCommandString[PPPCPCOMMAND_MAX]);

#ifndef NDEBUG
MOC_EXTERN const OCTET *apoPppCpOptionString[PPPCPOPTIONMAX];
MOC_EXTERN const OCTET *apoPppCpMsgString[PPPCPMSGMAX];
#endif
/*****************************************************************************
 *
 * Local function definitions
 *
 *****************************************************************************/

/*In ppp_action.c*/

LONG PppCpInstanceActionTlu(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionTld(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionTls(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionTlf(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionIrc(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionZrc(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionScr(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionSca(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionScn(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionStr(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionSta(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionScj(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionRestartOption(H_NETINSTANCE hPppCp,
                                      PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionTimerDisable(H_NETINSTANCE hPppCp,
                                     PPPCPEVENT *pxEvent);
LONG PppCpInstanceActionSer(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent);

/*In ppp_utils.c*/
LONG PppCpInstanceEvent(H_NETINSTANCE hPppCp,
                        PPPCPEVENT *pxEvent);
LONG PppCpInstanceTimerReset(H_NETINSTANCE hPppCp);
LONG PppCpSetHeader(OCTET *poPacket,
                    OCTET oCommand,OCTET oId,
                    WORD wLength);
LONG PppCpInstanceSendCommand(H_NETINSTANCE hPppCp,OCTET oCommand,
                              OCTET *poData, WORD wDataLength);
void PppCpFreeEvent(void *px);
LONG PppCpInstanceProcessEvent(H_NETINSTANCE hPppCp,
                               PPPCPEVENT *pxEvent);

#endif /*PPPCP_DEFS_H*/
