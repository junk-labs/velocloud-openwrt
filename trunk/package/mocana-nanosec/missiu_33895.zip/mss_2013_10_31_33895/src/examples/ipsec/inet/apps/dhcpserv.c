/*
 * dhcpserv.c
 *
 * The DHCP server application
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include <NNstyle.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <pthread.h>
#include <strings.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/time.h>
#include <net/if.h>
#include <netdb.h>
#include <stdio.h>
#include <ctype.h>

#include "dhcpapi.h"
#include "dhcpserv.h"
#include "configapi.h"
#include "setupnet.h"
#include "netstack.h"

/**************************************************************************
 * DEBUG
 **************************************************************************/
#ifndef NDEBUG
BOOL g_bDisplayDHCPClientTable = 0;
LONG DHCPServerDisplayTable(DHCP_SERVER *pDhcpServ);
#endif


/**************************************************************************
 * GLOBAL VARIABLES
 **************************************************************************/
DHCP_SERVER *pxDHCPServ = NULL;       /* DHCP server */


extern int ConfigGetParam(char * str,char *value,int len) ;

/************************************************************************n
 * LOCAL PRIVATE FUNCTIONS
 **************************************************************************/
/**************************************************************************
 * Append an entry to the linked list of client bindings
 **************************************************************************/
void ClientLinkListAdd(DHCP_SERVER *pDhcpServ,
                       DHCP_BOUND_CLIENT_ENTRY *pClientEntry)
{
  DHCP_BOUND_CLIENT_ENTRY *pSearch = pDhcpServ->pClientLinkListHead;

  /* Append to the end of the link list rather than the beginning. This
   * will make searching for older entries easier, as older entries will
   * typically reside at the head of the list */
  if (pSearch == NULL) {
    ASSERT(pDhcpServ->wClientCount == 0);
    pDhcpServ->pClientLinkListHead = pClientEntry;
  }
  else {
    while (pSearch->pNext != NULL) {
      pSearch = pSearch->pNext;
    }
    pSearch->pNext = pClientEntry;
  }

  pClientEntry->pNext = NULL;
  pDhcpServ->wClientCount++;
}


/**************************************************************************
 * Remove an entry from the linked list of client bindings
 **************************************************************************/
void ClientLinkListRemove(DHCP_SERVER *pDhcpServ,
                          DHCP_BOUND_CLIENT_ENTRY *pClientEntry)
{
  DHCP_BOUND_CLIENT_ENTRY *pPrevEntry = NULL;
  DHCP_BOUND_CLIENT_ENTRY *pSearch = pDhcpServ->pClientLinkListHead;

  while (pSearch != NULL) {
    if (pSearch == pClientEntry) {
      break;
    }
    pPrevEntry = pSearch;
    pSearch = pSearch->pNext;
  }

  ASSERT(pSearch != NULL);

  if (pSearch != NULL) {
    if (pPrevEntry != NULL) {
      pPrevEntry->pNext = pSearch->pNext;
    } else {
      pDhcpServ->pClientLinkListHead = pSearch->pNext;
    }

    pDhcpServ->wClientCount--;

#ifndef NDEBUG
    if (pDhcpServ->wClientCount == 0 &&
        pDhcpServ->pClientLinkListHead != NULL) {
      ASSERT(0);
    }
#endif
  }
}


/**************************************************************************
 * Free DHCP_PROCESS_CLIENT structure
 **************************************************************************/
void FreeDHCPProcessingClient(void *pxClient)
{
  DHCP_PROCESS_CLIENT *pClient = (DHCP_PROCESS_CLIENT *)pxClient;
  if (pClient->dwPingResponseTime > 0) {
    NetPingStat(0,
                (pxDHCPServ->dwDHCPServerIP & 0xFFFFFF00) |
                pClient->oOfferIP);
  }
  FREE(pxClient);
}


/**************************************************************************
 * Free DHCP_BOUND_CLIENT_ENTRY structure
 **************************************************************************/
#define FreeDHCPBoundClient(x)     FREE(x)


#ifndef NDEBUG
/**************************************************************************
 * Print the DHCP client binding information
 **************************************************************************/
LONG DHCPServerDisplayTable(DHCP_SERVER *pDhcpServ)
{
  DHCP_BOUND_CLIENT_ENTRY *pClientEntry = pDhcpServ->pClientLinkListHead;
  char pcClientIDStr[50] = {0};

  pthread_mutex_lock(&(pDhcpServ->xDHCPMutex));

  while (pClientEntry != NULL) {
    int i;
    OCTET *poClientID = CLIENTCID(pClientEntry);
    char *pcHostName = CLIENTHOSTNAME(pClientEntry);

    bzero(pcClientIDStr,50);
    for (i=0;i<pClientEntry->oClientIDLen;i++)
      sprintf((pcClientIDStr + (2*i)),"%02X",poClientID[i]);

    if (pClientEntry->dwLeaseTimer == INFINITE_LEASE) {
      printf("%s\t%s\t"IPFORM"\tInfinite\t%.20s\n",pcHostName,
             pcClientIDStr,IP(SUBNET_ADDRESS|pClientEntry->oCurrentIPAddress),
             pClientEntry->bPermanent?"YES":"NO");
    } else {
      printf("%s\t%s\t"IPFORM"\t%.8ld\t%s\n",pcHostName,
             pcClientIDStr,IP(SUBNET_ADDRESS|pClientEntry->oCurrentIPAddress),
             pClientEntry->dwLeaseTimer/10, pClientEntry->bPermanent?"YES":"NO");
    }

    pClientEntry = pClientEntry->pNext;
  }

  pthread_mutex_unlock(&(pDhcpServ->xDHCPMutex));

  return 0;
}
#endif /*NDEBUG */


/**************************************************************************
 * Find client being processed with the given MAC address
 *   Return: NULL if not found
 *           pointer to DHCP_PROCESS_CLIENT in DLLIST
 **************************************************************************/
DHCP_PROCESS_CLIENT *FindProcessingClient(DHCP_SERVER *pDhcpServ,
                                          OCTET *poClientID,
                                          OCTET oClientIDLen)
{
  DHCP_PROCESS_CLIENT *pClient = NULL;
  DLLIST_head(pDhcpServ->pDllProcessingClients);
  while ((pClient = DLLIST_read(pDhcpServ->pDllProcessingClients)) != NULL) {
    if (pClient->poClientID != NULL &&
        !memcmp(poClientID, pClient->poClientID, oClientIDLen)) {
      return pClient;
    }
    DLLIST_next(pDhcpServ->pDllProcessingClients);
  }

  return NULL;
}


/**************************************************************************
 * Find client with the given MAC address in the processing DLLIST
 *   Return: NULL if not found
 *           pointer to DHCP_BOUND_CLIENT_ENTRY in DLLIST
 **************************************************************************/
DHCP_BOUND_CLIENT_ENTRY *FindBoundClientEntryByCID(DHCP_SERVER *pDhcpServ,
                                                   OCTET *poClientID,
                                                   OCTET oClientIDLen)
{
  DHCP_BOUND_CLIENT_ENTRY *pClientEntry = pDhcpServ->pClientLinkListHead;

  pthread_mutex_lock(&(pDhcpServ->xDHCPMutex));

  while (pClientEntry != NULL) {
    if (pClientEntry->oClientIDLen != 0 &&
        !memcmp(poClientID, CLIENTCID(pClientEntry), oClientIDLen)) {
      pthread_mutex_unlock(&(pDhcpServ->xDHCPMutex));
      return pClientEntry;
    }

    pClientEntry = pClientEntry->pNext;
  }

  pthread_mutex_unlock(&(pDhcpServ->xDHCPMutex));

  return NULL;
}


/**************************************************************************
 * Finds a DHCP option (oOption) in the options list of pDhcpPacket
 *   Return: 'Length' of option
 *           -1 if option not found
 *
 * if bCopy == TRUE, option value is copied to address poOptionAddr_Value
 * else ppoOptionAddress contains the address of the option
 * ppoOptionAddress must not be a NULL input
 **************************************************************************/
LONG GetOption(DHCP_PACKET *pDhcpPacket,
               OCTET oOption,
               OCTET *poOptionValue,
               OCTET **ppoOptionAddress,
               BOOL bCopy)
{
  OCTET *poOptions = (OCTET *)(pDhcpPacket->options + 4);
                                  /* add 4 to pass magic cookie */
  int i = 0;

  if (!bCopy && ppoOptionAddress == NULL) {
    ASSERT(0);
    return -1;
  }

  while (i < (312 - 4)) {
    OCTET oCurrentOption = poOptions[i];
    OCTET oCurrentOptionLength = poOptions[i+1];
    OCTET *poCurrentOptionValue = &(poOptions[i+2]);

    if (oCurrentOption == 255) break;     /* last option */
    if (oCurrentOption == 0) {
      i++;
      continue;
    }

    if (oCurrentOption == oOption) {
      /* Found it */
      if (bCopy) {
        memcpy(poOptionValue, poCurrentOptionValue, oCurrentOptionLength);
      } else {
        ASSERT(ppoOptionAddress != NULL);
        *ppoOptionAddress = poCurrentOptionValue;
      }
      return oCurrentOptionLength;
    }

    /* Skip to next option */
    i += (oCurrentOptionLength + 2);
  }

  /* option not found */
  if (bCopy) {
    *poOptionValue = 0;
  }

  if (!bCopy) {
    *ppoOptionAddress = NULL;
  }
  return -1;
}


/**************************************************************************
 * Sets a DHCP option (oOption) in the options list of pDhcpPacket
 * Copies oOptionLength bytes from poOptionValue
 *   Return: 0 if successful
 *           -1 if not enough space for option
 **************************************************************************/
LONG SetOption(DHCP_PACKET *pDhcpPacket,
               OCTET oOption,
               OCTET *poOptionValue,
               OCTET oOptionLength)
{
  OCTET *poOptions = (OCTET *)(pDhcpPacket->options + 4);
  int i = 0;

  /* Look for end of options tag (255) and check enough space for option */
  while (poOptions[i] != 255) {
    i+=(poOptions[i+1] + 2);
    if ((i + oOptionLength + 3) > (312 - 4)) return -1;
  }

  /* Found the last position */
  poOptions[i] = oOption;
  poOptions[i+1] = oOptionLength;
  memcpy(&poOptions[i+2], poOptionValue, oOptionLength);
  /* Move last option tag */
  poOptions[i + oOptionLength + 2] = 255;

  return 0;
}


/**************************************************************************
 * Extract the clientID from the option, or use the hardware address
 * as clientID if no option is provided
 **************************************************************************/
void GetClientID(DHCP_PROCESS_CLIENT *pClient)
{
  ASSERT(pClient);
  pClient->oClientIDLen = (OCTET)GetOption(&(pClient->xDhcpPacket),
                                           DHCP_OPT_CLIENT_IDENTIFIER,
                                           NULL, &(pClient->poClientID), FALSE);
  if (pClient->poClientID == NULL) {
    /* Nothing provided, use the hardware address as client ID */
    pClient->poClientID = pClient->xDhcpPacket.chaddr;
    pClient->oClientIDLen = (OCTET)pClient->xDhcpPacket.hlen;
  }
}


/**************************************************************************
 * Check if a client has a static assignment
 *   Return: NULL if not found
 *           pointer to DHCP_BOUND_CLIENT_ENTRY in DLLIST
 **************************************************************************/
DHCP_BOUND_CLIENT_ENTRY *FindStaticAssignment(DHCP_SERVER *pDhcpServ,
                                              DHCP_PROCESS_CLIENT *pClient)
{
  DHCP_BOUND_CLIENT_ENTRY *pClientEntry = pDhcpServ->pClientLinkListHead;

  pthread_mutex_lock(&(pDhcpServ->xDHCPMutex));

  while (pClientEntry != NULL) {
    if (pClientEntry->bPermanent) {
      /* Check if the device MAC address matches */
      if (pClientEntry->oClientIDLen == 6 &&
          !memcmp(CLIENTCID(pClientEntry),
                  pClient->xDhcpPacket.chaddr,6)) {
        pthread_mutex_unlock(&(pDhcpServ->xDHCPMutex));
        return pClientEntry;
      }

      /* Check if device hostname matches */
      if (pClientEntry->oClientIDLen == 0 &&
          pClientEntry->pxClientInfo != NULL) {
        LONG lHostNameLen = 0;
        char *pcHostName = NULL;
        lHostNameLen = GetOption(&(pClient->xDhcpPacket), DHCP_OPT_HOST_NAME,
                                 NULL, (OCTET **)(&pcHostName), FALSE);
        if (lHostNameLen>0 && pcHostName!=NULL) {
          if (!strncasecmp(pcHostName, CLIENTHOSTNAME(pClientEntry), lHostNameLen)) {
            pthread_mutex_unlock(&(pDhcpServ->xDHCPMutex));
            return pClientEntry;
          }
        }
      }
    }

    pClientEntry = pClientEntry->pNext;
  }

  pthread_mutex_unlock(&(pDhcpServ->xDHCPMutex));

  return NULL;
}


/**************************************************************************
 * Fills all mandatory and requested options in a DHCP message
 **************************************************************************/
void DHCPMessageFillOptions(DHCP_SERVER *pDhcpServ,
                            DHCP_PROCESS_CLIENT *pClient,
                            DHCP_PACKET *pDhcpPacket,
                            OCTET *poRequestedOptions,
                            LONG lNumOpts,
                            OCTET oMsgType,
                            char *pcMessage)
{
  DWORD dwTmp;
  ASSERT(pDhcpPacket);

  /* Magic cookie */
  pDhcpPacket->options[0] = 99;
  pDhcpPacket->options[1] = 130;
  pDhcpPacket->options[2] = 83;
  pDhcpPacket->options[3] = 99;

  /* Set last option tag */
  pDhcpPacket->options[4] = 255;

  /* Always required */
  dwTmp = htonl(pDhcpServ->dwDHCPServerIP);
  SetOption(pDhcpPacket, DHCP_OPT_MESSAGE_TYPE, &oMsgType, 1);
  SetOption(pDhcpPacket, DHCP_OPT_SERVER_IDENTIFIER, (OCTET *)&dwTmp, 4);

  /* For DHCPNAK messages, only error message allowed */
  if (oMsgType == DHCPNAK && pcMessage != NULL) {
    SetOption(pDhcpPacket, DHCP_OPT_ERROR_MESSAGE, pcMessage, strlen(pcMessage));
    return;
  }

  /* Set client ID (if not same as MAC address) */
  if (memcmp(pDhcpPacket->chaddr, pClient->poClientID, pClient->oClientIDLen)) {
    SetOption(pDhcpPacket, DHCP_OPT_CLIENT_IDENTIFIER,
              pClient->poClientID, pClient->oClientIDLen);
  }

  /* For OFFER and ACK(DHCPREQUEST), we need to set IP lease time */
  if (oMsgType == DHCPOFFER || oMsgType == DHCPACK) {
    if (pClient->dwLeaseTime) {
      dwTmp = htonl(pClient->dwLeaseTime);
      SetOption(pDhcpPacket, DHCP_OPT_LEASE_TIME, (OCTET *)&dwTmp, 4);
    }
  }

  /* Start setting known (and requested) options */
  if (lNumOpts > 0) {
    int i;
    DHCPDEBUG(printf("DHCPServer: Client "MACFORM" has requested options:\n",
                     MAC(pDhcpPacket->chaddr)));

    for (i=0;i<lNumOpts;i++) {
      OCTET oOptionCode = poRequestedOptions[i];
      DHCPDEBUG(printf("  [%d] ", oOptionCode));

      /* For now, these are the only options we support */
      switch(oOptionCode) {
      case DHCP_OPT_SUBNET_MASK:
        dwTmp = htonl(pDhcpServ->dwSubnetMask);
        SetOption(pDhcpPacket, oOptionCode, (OCTET *)&dwTmp, 4);
        DHCPDEBUG(printf("Subnet mask: "IPFORM"\n",IP(dwTmp)));
        break;
      case DHCP_OPT_DNS_SERVER:
        {
          DWORD pdwDNSServers[3];
          OCTET oNumDNSServers = 0;

          /* We act as the DNS proxy */
          pdwDNSServers[oNumDNSServers++] = pDhcpServ->dwRouter;

          if (pDhcpServ->dwDNS1 != 0) {
            pdwDNSServers[oNumDNSServers++] = pDhcpServ->dwDNS1;
          }
          if (pDhcpServ->dwDNS2 != 0) {
            pdwDNSServers[oNumDNSServers++] = pDhcpServ->dwDNS2;
          }

#ifndef NDEBUG
          {
            int dnsi;
            DHCPDEBUG(printf("DNS Servers: "));
            for (dnsi=0;dnsi<oNumDNSServers;dnsi++) {
              DHCPDEBUG(printf(IPFORM"  ",IP(pdwDNSServers[dnsi])));
            }
            DHCPDEBUG(printf("\n"));
          }
#endif

          SetOption(pDhcpPacket, oOptionCode, (OCTET *)pdwDNSServers,
                    (4 * oNumDNSServers));
        }
        break;
      case DHCP_OPT_ROUTER:
        dwTmp = htonl(pDhcpServ->dwRouter);
        SetOption(pDhcpPacket, oOptionCode, (OCTET *)&dwTmp, 4);
        DHCPDEBUG(printf("Default Gateway: "IPFORM"\n",IP(dwTmp)));
        break;
      case DHCP_OPT_DOMAIN_NAME:
        DHCPDEBUG(printf("Domain Name: %s\n",pDhcpServ->pcDomainName));
        if (pDhcpServ->pcDomainName != NULL) {
          SetOption(pDhcpPacket, oOptionCode, (OCTET *)pDhcpServ->pcDomainName,
                    strlen(pDhcpServ->pcDomainName));
        }
        break;
      default:
        DHCPDEBUG(printf("(Not supported)\n"));
      }
    }
  }
}


/**************************************************************************
 * Sends a DHCP message of type oMessageType to pClient
 **************************************************************************/
LONG DHCPSendMessage(DHCP_SERVER *pDhcpServ,
                     DHCP_PROCESS_CLIENT *pClient,
                     char *pcMessage,
                     OCTET oMessageType)
{
  DHCP_PACKET xDhcpOutPacket;
  struct sockaddr_in client_addr;
  OCTET *poRequestedOptions = NULL;
  LONG lOptNum = 0;
  LONG lReturn = 0;

  bzero((char *)&client_addr, sizeof(struct sockaddr_in));
  bzero(&xDhcpOutPacket, sizeof(DHCP_PACKET));

  xDhcpOutPacket.op = BOOTREPLY;
  xDhcpOutPacket.htype = ETHERNET_TYPE;
  xDhcpOutPacket.hlen = ETHERNET_TYPELEN;
  xDhcpOutPacket.xid = pClient->xDhcpPacket.xid;
  xDhcpOutPacket.ciaddr = (oMessageType == DHCPACK)?(pClient->xDhcpPacket.ciaddr):0;
  xDhcpOutPacket.yiaddr = (oMessageType == DHCPACK)?(pClient->xDhcpPacket.yiaddr):
    (oMessageType == DHCPOFFER)?htonl(SUBNET_ADDRESS | pClient->oOfferIP):0;
  xDhcpOutPacket.flags = pClient->xDhcpPacket.flags;
  xDhcpOutPacket.giaddr = pClient->xDhcpPacket.giaddr;
  memcpy(xDhcpOutPacket.chaddr, pClient->xDhcpPacket.chaddr, 16);

  lOptNum = GetOption(&pClient->xDhcpPacket, DHCP_OPT_PARAMETER_REQUEST_LIST,
                      NULL, &poRequestedOptions, FALSE);
  DHCPMessageFillOptions(pDhcpServ, pClient,
                         &xDhcpOutPacket,
                         poRequestedOptions, lOptNum,
                         oMessageType, pcMessage);

  client_addr.sin_family = AF_INET;
  client_addr.sin_port = htons(DHCPCLIENTPORT);

  if (xDhcpOutPacket.giaddr != 0) {
    client_addr.sin_port = htons(DHCPSERVERPORT);
    client_addr.sin_addr.s_addr = xDhcpOutPacket.giaddr;
  } else if ((ntohs(xDhcpOutPacket.flags) & 0x8000) || (oMessageType == DHCPNAK)) {
    client_addr.sin_addr.s_addr = DEST_BROADCAST;
  } else if (xDhcpOutPacket.ciaddr != 0) {
    client_addr.sin_addr.s_addr = xDhcpOutPacket.ciaddr;
  } else if (pClient->dwOriginal_yiaddr != 0) {
    client_addr.sin_addr.s_addr = xDhcpOutPacket.yiaddr;
  } else {
    client_addr.sin_addr.s_addr = DEST_BROADCAST;
  }

  /* Send the DHCP message */
  lReturn = sendto(pDhcpServ->iDhcpSocket,
                   (char *)&xDhcpOutPacket,
                   DHCP_PACKET_SIZE, 0,
                   (struct sockaddr *)&(client_addr),
                   sizeof(struct sockaddr));

  ASSERT(lReturn >= 0);

  if (oMessageType == DHCPOFFER) {
    /* Start offer timeout. If client does not respond within this time,
       we will delete it from the offer process */
    pClient->dwResponseTimer = RESPONSE_TIMEOUT;
    DHCPDEBUG(printf("DHCPServer: Sent OFFER to "MACFORM", xid=%lu, IP="IPFORM"\n",
                     MAC(xDhcpOutPacket.chaddr), pClient->xDhcpPacket.xid,
                     IP(SUBNET_ADDRESS | pClient->oOfferIP)));
  } else {
    DHCPDEBUG(printf("DHCPServer: Sent %s to "MACFORM", xid=%lu, reason = %s\n",
                     (oMessageType == DHCPACK)?"DHCPACK":"DHCPNAK", MAC(xDhcpOutPacket.chaddr),
                     pClient->xDhcpPacket.xid,
                     pcMessage));
  }

  return 0;
}


/**************************************************************************
 * Releases a DHCP assignment in the 'bound' table
 * If bDelete == 1, the entry is removed from the DLLIST, otherwise the
 *   entry remains, and the lease time is set to ZERO
 **************************************************************************/
LONG DHCPReleaseAssignment(DHCP_SERVER *pDhcpServ,
                           DHCP_PACKET *pDhcpPacket,
                           OCTET *poClientID,
                           OCTET oClientIDLen,
                           BOOL bDelete)
{
  DHCP_BOUND_CLIENT_ENTRY *pClientEntry = FindBoundClientEntryByCID(pDhcpServ, poClientID, oClientIDLen);

  if (pClientEntry != NULL) {
    pClientEntry->dwLeaseTimer = 0;
    DHCPDEBUG(printf("DHCPServer: Client "MACFORM" ("IPFORM") unbound. ",
                     MAC(pDhcpPacket->chaddr),
                     IP(SUBNET_ADDRESS | pClientEntry->oCurrentIPAddress)));
    if (bDelete) {
      ClientLinkListRemove(pDhcpServ, pClientEntry);
      FreeDHCPBoundClient(pClientEntry);
      DHCPDEBUG(printf("Client deleted\n"));
    } else {
      DHCPDEBUG(printf("Lease set to ZERO\n"));
    }
  } else {
    DHCPDEBUG(printf("DHCPServer: Client "MACFORM" not found\n",
                     MAC(pDhcpPacket->chaddr)));
    return -1;
  }

  return 0;
}


/**************************************************************************
 * Commits (stores) DHCP assignment in the 'bound' table
 **************************************************************************/
#define min(A,B)     ((A)>(B)?B:A)
void DHCPCommitAssignment(DHCP_SERVER *pDhcpServ,
                          DHCP_PROCESS_CLIENT *pClient)
{
  DHCP_BOUND_CLIENT_ENTRY *pClientEntry = NULL;

  ASSERT(pDhcpServ);
  ASSERT(pClient);

  pClientEntry = FindStaticAssignment(pDhcpServ, pClient);

  if (pClientEntry == NULL) {
    pClientEntry = FindBoundClientEntryByCID(pDhcpServ,
                                             pClient->poClientID,
                                             pClient->oClientIDLen);
  }

  if (pClientEntry == NULL) {
    LONG lHostNameLen = 0;
    char *pcHostName = NULL;
    WORD wMemRequired = 0;

    /* If table limit size reached, throw away oldest user who's lease has
     * expired */
    if (pDhcpServ->wClientCount > MAX_BOUND_CLIENTS) {
      DHCP_BOUND_CLIENT_ENTRY *pOldest = pDhcpServ->pClientLinkListHead;

      while (pOldest != NULL) {
        if (pOldest->dwLeaseTimer == 0) {
          ClientLinkListRemove(pDhcpServ, pOldest);
          FreeDHCPBoundClient(pOldest);
          DHCPDEBUG(printf("DHCPServer: Table is full - Deleting oldest client with expired binding\n"));
          break;
        }
        pOldest = pOldest->pNext;
      }

      if (pOldest == NULL) {
        DEBUG(printf("DHCPServer: binding table full - client "MACFORM" NOT bound!\n",
              MAC(pClient->xDhcpPacket.chaddr)));
        return;
      }
    }

    /* Get the client's hostname */
    lHostNameLen = GetOption(&(pClient->xDhcpPacket), DHCP_OPT_HOST_NAME,
                             NULL, (OCTET **)(&pcHostName), FALSE);

    /* Compute the amount of memory we need to malloc for this client */
    wMemRequired = sizeof(DHCP_BOUND_CLIENT_ENTRY) - sizeof(void *) +
                   pClient->oClientIDLen + 1;
    if (lHostNameLen>0 && pcHostName != NULL) {
      lHostNameLen = min(18,lHostNameLen);   /* limit to 18 chars */
      wMemRequired += lHostNameLen;
    }

    pClientEntry = calloc(1,wMemRequired);
    ClientLinkListAdd(pDhcpServ, pClientEntry);

    pClientEntry->oClientIDLen = pClient->oClientIDLen;
    memcpy(CLIENTCID(pClientEntry), pClient->poClientID, pClient->oClientIDLen);

    if (lHostNameLen>0 && pcHostName != NULL) {
      memcpy(CLIENTHOSTNAME(pClientEntry),pcHostName,lHostNameLen);
    }
  }

  if (pClientEntry->oCurrentIPAddress != pClient->oOfferIP) {
    pClientEntry->oPreviousIPAddress = pClientEntry->oCurrentIPAddress;
  }
  pClientEntry->oCurrentIPAddress = pClient->oOfferIP;
  pClientEntry->dwLeaseTimer = (pClient->dwLeaseTime == INFINITE_LEASE)?INFINITE_LEASE:
    (pClient->dwLeaseTime * 10);

  ASSERT(pDhcpServ->wClientCount <= (MAX_BOUND_CLIENTS + 10));

  DEBUG(printf("DHCPCommitAssignment: Client "MACFORM" has been bound to IP address "IPFORM". Lease time = %lus\n",
               MAC(pClient->xDhcpPacket.chaddr), IP(SUBNET_ADDRESS | pClient->oOfferIP),
               pClient->dwLeaseTime));

  return;
}


/**************************************************************************
 * Searches the 'bound' table to see if an IP address is assigned.
 * Returns false if:
 *     IP address is assigned to "someone else" (different MAC)
 *  and
 *     1: the "someone else" has a permanent (static) assignment
 *  OR 2: the "someone else" still has a valid lease
 *  OR 3: the "someone else's" lease has expired but we still can't take it
 **************************************************************************/
BOOL CheckIfIPAssigned(DHCP_SERVER *pDhcpServ,
                       OCTET oIPAddress,
                       OCTET *poClientID,
                       OCTET oClientIDLen,
                       BOOL bTakeIfLeaseExpired)
{
  DHCP_BOUND_CLIENT_ENTRY *pClientEntry = pDhcpServ->pClientLinkListHead;

  pthread_mutex_lock(&(pDhcpServ->xDHCPMutex));

  while (pClientEntry != NULL) {
    if ((pClientEntry->oCurrentIPAddress == oIPAddress) &&
        (memcmp(poClientID, CLIENTCID(pClientEntry), oClientIDLen) != 0) &&
        ((pClientEntry->bPermanent) ||
         (pClientEntry->dwLeaseTimer > 0) ||
         ((pClientEntry->dwLeaseTimer == 0) && (!bTakeIfLeaseExpired)))) {
      /* Someone else has this IP and the lease is still valid (or can't be taken if expired) */
      pthread_mutex_unlock(&(pDhcpServ->xDHCPMutex));
      return TRUE;
    }

    pClientEntry = pClientEntry->pNext;
  }

  pthread_mutex_unlock(&(pDhcpServ->xDHCPMutex));

  return FALSE;
}


/**************************************************************************
 * Searches the 'bound' table to find the next 'available' IP address
 * Starts search from oAttemptedIP
 * If bTakeIfLeaseExpired==TRUE, we may use an IP address if the lease
 * on it has expired
 **************************************************************************/
OCTET FindNextCandidatePoolAddress(DHCP_SERVER *pDhcpServ,
                                   OCTET oAttemptedIP,
                                   OCTET *poClientID,
                                   OCTET oClientIDLen,
                                   BOOL bTakeIfLeaseExpired)
{
  OCTET oCandidateIP = 0;

  if (oAttemptedIP == 0)
    oCandidateIP = pDhcpServ->oPoolMin;
  else
    oCandidateIP = oAttemptedIP + 1;

  /* Find first unassigned or available address */
  while (oCandidateIP <= pDhcpServ->oPoolMax) {
    if (CheckIfIPAssigned(pDhcpServ, oCandidateIP, poClientID,
                          oClientIDLen, bTakeIfLeaseExpired) == FALSE) {
      return oCandidateIP;
    } else {
      oCandidateIP++;
    }
  }

  ASSERT(oCandidateIP == pDhcpServ->oPoolMax + 1);

  return 0;
}


/**************************************************************************
 * The main routine to determine an IP address to offer the client
 * Basic rules (RFC 2131)
 *     First: Try user's current assignment (if known)
 *     Second: Try user's previous assignment (if known)
 *     Third: Try user's requested IP address (if given)
 *     Fourth: Look for first available IP in pool (don't take expired leases)
 *     Fifth: Look for the first IP address that has an expired lease
 *
 * Return:  0 if found a candidate IP to offer
 *         -1 if no IP addresses available
 **************************************************************************/
LONG DHCPProcessOffer(DHCP_SERVER *pDhcpServ,
                      DHCP_PROCESS_CLIENT *pClient,
                      DHCP_PACKET *pDhcpPacket)
{
  DHCP_BOUND_CLIENT_ENTRY *pClientEntry = NULL;
  DWORD dwLeaseTime = 0;

  ASSERT(pDhcpServ);
  ASSERT(pDhcpPacket);

  if (pClient == NULL) {

    /* Need to limit the number of DISCOVER client's who are being processed. */
    if (DLLIST_count(pDhcpServ->pDllProcessingClients) > MAX_PROCESS_CLIENTS) {
      DHCPDEBUG(printf("DHCPServer: Too many clients being processed. Ignoring Client "MACFORM"\n",
                       MAC(pDhcpPacket->chaddr)));
      return -1;
    }

    pClient = calloc(1,sizeof(DHCP_PROCESS_CLIENT));
    DLLIST_append(pDhcpServ->pDllProcessingClients,pClient);
    memcpy(&(pClient->xDhcpPacket), pDhcpPacket, DHCP_PACKET_SIZE);
    pClient->dwOriginal_yiaddr = pDhcpPacket->yiaddr;
    GetClientID(pClient);
    pClient->oOfferState = OFFER_TRY_CURRENT;
    pClient->oOfferIP = 0;
  }

  /* Did the user specifically request a certain lease time? */
  GetOption(&pClient->xDhcpPacket, DHCP_OPT_LEASE_TIME, (OCTET *)&dwLeaseTime, NULL, TRUE);
  dwLeaseTime = ntohl(dwLeaseTime);

  /* Is there a static assignment for this client? */
  pClientEntry = FindStaticAssignment(pDhcpServ, pClient);
  if (pClientEntry != NULL) {
    pClient->oOfferState = OFFER_STATIC;
    pClient->dwLeaseTime = INFINITE_LEASE;
    pClient->oOfferIP = pClientEntry->oPreviousIPAddress;
  }

  if (pClientEntry == NULL) { /* no static assignment found */
    /* Does the client have a bind entry in the table? */
    pClientEntry = FindBoundClientEntryByCID(pDhcpServ, pClient->poClientID, pClient->oClientIDLen);
  }

  if (dwLeaseTime != 0) {
    /* Use user specified lease time */
    pClient->dwLeaseTime = dwLeaseTime;
  } else if (pClientEntry != NULL) {
    /* Use current lease expiration time (may be ZERO) */
    pClient->dwLeaseTime = (pClientEntry->dwLeaseTimer == INFINITE_LEASE)?INFINITE_LEASE:
      (pClientEntry->dwLeaseTimer/10);
  }

  if (pClient->dwLeaseTime == 0) {
    pClient->dwLeaseTime = DEFAULT_LEASE_TIME;
  }

  if (pClient->oOfferState == OFFER_TRY_CURRENT) {
    if (pClientEntry) {
      /* First, try the user's last known IP address */
      pClient->oOfferIP = pClientEntry->oCurrentIPAddress;
      if (pClient->oOfferIP == 0 || CheckIfIPAssigned(pDhcpServ,
                                                      pClient->oOfferIP,
                                                      pClient->poClientID,
                                                      pClient->oClientIDLen,
                                                      FALSE) == TRUE) {
        pClient->oOfferState = OFFER_TRY_PREVIOUS;
      }
    } else {
      pClient->oOfferState = OFFER_TRY_REQUESTED;
    }
  }

  if (pClient->oOfferState == OFFER_TRY_PREVIOUS) {
    if (pClientEntry) {
      /* Next, try user's previous known assigned IP address */
      pClient->oOfferIP = pClientEntry->oPreviousIPAddress;
      if (pClient->oOfferIP == 0 || CheckIfIPAssigned(pDhcpServ,
                                                      pClient->oOfferIP,
                                                      pClient->poClientID,
                                                      pClient->oClientIDLen,
                                                      FALSE) == TRUE) {
        pClient->oOfferState = OFFER_TRY_REQUESTED;
      }
    } else {
      pClient->oOfferState = OFFER_TRY_REQUESTED;
    }
  }

  if (pClient->oOfferState == OFFER_TRY_REQUESTED) {
    DWORD dwRequestedIP = 0;
    pClient->oOfferIP = 0;

    /* Next, try user's Requested IP address (if any) */
    if (4 == GetOption(&pClient->xDhcpPacket,DHCP_OPT_REQUEST_IP_ADDRESS,
                       (OCTET *)&dwRequestedIP,NULL,TRUE)) {
      OCTET oLastPart;
      dwRequestedIP = ntohl(dwRequestedIP);
      oLastPart = dwRequestedIP & 0x000000FF;

      /* Is the Requested address valid and unassigned ? */
      if (((dwRequestedIP & 0xFFFFFF00) == (pDhcpServ->dwDHCPServerIP & 0xFFFFFF00)) &&
          (oLastPart >= pDhcpServ->oPoolMin && oLastPart <= pDhcpServ->oPoolMax) &&
          (CheckIfIPAssigned(pDhcpServ,
                             oLastPart,
                             pClient->poClientID,
                             pClient->oClientIDLen,
                             FALSE) == FALSE)) {
        pClient->oOfferIP = oLastPart;
      }
    }
    if (pClient->oOfferIP == 0) {
      pClient->oOfferState = OFFER_SEARCH_POOL_UNASSIGNED;
    }
  }

  if (pClient->oOfferState == OFFER_SEARCH_POOL_UNASSIGNED) {
    /* Else, search the DHCP pool for the next unassigned IP address */
    pClient->oOfferIP = FindNextCandidatePoolAddress(pDhcpServ, pClient->oOfferIP,
                                                     pClient->poClientID,
                                                     pClient->oClientIDLen,
                                                     FALSE);
    if (pClient->oOfferIP == 0) {
      pClient->oOfferState = OFFER_SEARCH_POOL_EXPIRED;
    }
  }

  if (pClient->oOfferState == OFFER_SEARCH_POOL_EXPIRED) {
    /* Finally, try first available expired lease */
    pClient->oOfferIP = FindNextCandidatePoolAddress(pDhcpServ, pClient->oOfferIP,
                                                     pClient->poClientID,
                                                     pClient->oClientIDLen, TRUE);
  }

  if (pClient->oOfferIP != 0) {
    DHCPDEBUG(printf("DHCPServer: Found candidate address "IPFORM" (via option %d) ",
                     IP(SUBNET_ADDRESS | pClient->oOfferIP), pClient->oOfferState));
    DHCPDEBUG(printf("for Client "MACFORM", 'xid'=%lu.\n    'Pinging' "IPFORM"\n",
                     MAC(pClient->xDhcpPacket.chaddr), pClient->xDhcpPacket.xid,
                     IP(SUBNET_ADDRESS | pClient->oOfferIP)));

    /* Ping the IP address to see if anyone is using it */
    NetPingStat(pDhcpServ->dwDHCPServerIP, SUBNET_ADDRESS | pClient->oOfferIP);
    NetPing(pDhcpServ->dwDHCPServerIP, SUBNET_ADDRESS | pClient->oOfferIP);
    pClient->dwPingResponseTime = PING_RESPONSE_TIMEOUT;    /* Allow 2 seconds to reply with response */
  }
  else {
    /* Nothing available : TODO : Send NACK? */
    DEBUG(printf("DHCPProcessOffer: No more available IP addresses for client "MACFORM", 'xid'=%lu\n",
                 MAC(pClient->xDhcpPacket.chaddr), pClient->xDhcpPacket.xid));
    FreeDHCPProcessingClient(pClient);
    DLLIST_remove(pDhcpServ->pDllProcessingClients);
    return -1;
  }

  return 0;
}


/**************************************************************************
 * Process an incoming DHCPREQUEST message
 **************************************************************************/
LONG DHCPProcessRequest(DHCP_SERVER *pDhcpServ,
                        DHCP_PROCESS_CLIENT *pClient,
                        DHCP_PACKET *pDhcpPacket)
{
  DWORD dwChosenServerIP = 0;
  BOOL bOfferResponse = FALSE;   /* In response to an OFFER message? */
  DWORD dwRequestedIP = 0;

  ASSERT(pDhcpServ);
  ASSERT(pDhcpPacket);

  /* Is this REQUEST directed at this server? */
  GetOption(pDhcpPacket, DHCP_OPT_SERVER_IDENTIFIER, (OCTET *)&dwChosenServerIP, NULL, TRUE);
  dwChosenServerIP = ntohl(dwChosenServerIP);

  if (dwChosenServerIP != 0) {
    /* ServerID provided, so assume this is a REQUEST in response to an OFFER */
    bOfferResponse = TRUE;

    if (dwChosenServerIP == pDhcpServ->dwDHCPServerIP) {
      DHCPDEBUG(printf("DHCPServer: REQUEST from Client "MACFORM" is for us\n",
                       MAC(pDhcpPacket->chaddr)));
      if (pClient == NULL) {
        DHCPDEBUG(printf("DHCPServer: Client "MACFORM" sending REQUEST not known\n",
                         MAC(pDhcpPacket->chaddr)));
        return -1;
      }
    } else {
      /* The client must have chosen another server, discard */
      DHCPDEBUG(printf("DHCPServer: REQUEST from Client "MACFORM" not for us\n",
                       MAC(pDhcpPacket->chaddr)));
      if (pClient) {
        FreeDHCPProcessingClient(pClient);
        DLLIST_remove(pDhcpServ->pDllProcessingClients);
      }
      return -1;
    }
  }

  if (pClient != NULL && bOfferResponse == TRUE) {
    memcpy(&(pClient->xDhcpPacket), pDhcpPacket, DHCP_PACKET_SIZE);
    pClient->dwOriginal_yiaddr = pDhcpPacket->yiaddr;
    GetClientID(pClient);

    /* Check 'xid' */
    if (pClient->xDhcpPacket.xid != pDhcpPacket->xid) {
      DHCPDEBUG(printf("DHCPServer: REQUEST 'xid'=%lu does not match OFFER 'xid'=%lu for Client "MACFORM"\n",
                       pDhcpPacket->xid,pClient->xDhcpPacket.xid,MAC(pDhcpPacket->chaddr)));
      DHCPSendMessage(pDhcpServ, pClient, "xid does not match", DHCPNAK);
      FreeDHCPProcessingClient(pClient);
      DLLIST_remove(pDhcpServ->pDllProcessingClients);
      return -1;
    }

    /* Check 'Requested IP' */
    GetOption(pDhcpPacket, DHCP_OPT_REQUEST_IP_ADDRESS, (OCTET *)&dwRequestedIP, NULL, TRUE);
    dwRequestedIP = ntohl(dwRequestedIP);

    if (dwRequestedIP != (SUBNET_ADDRESS | pClient->oOfferIP)) {
      DHCPDEBUG(printf("DHCPServer: REQUEST 'requested IP' does not match 'offered IP' for client "MACFORM"\n",
                       MAC(pDhcpPacket->chaddr)));
      DHCPSendMessage(pDhcpServ, pClient, "requested IP does not match offered IP", DHCPNAK);
      FreeDHCPProcessingClient(pClient);
      DLLIST_remove(pDhcpServ->pDllProcessingClients);
      return -1;
    }
  }
  else {
    /* It is not a reponse to an OFFER */
    pClient = calloc(1,sizeof(DHCP_PROCESS_CLIENT));
    DLLIST_append(pDhcpServ->pDllProcessingClients,pClient);
    memcpy(&(pClient->xDhcpPacket), pDhcpPacket, DHCP_PACKET_SIZE);
    pClient->dwOriginal_yiaddr = pDhcpPacket->yiaddr;
    GetClientID(pClient);
  }

  if (dwRequestedIP != 0 && bOfferResponse == TRUE) {
    /* Check 'requested IP' subnet is correct */
    if ((dwRequestedIP & 0xFFFFFF00) != SUBNET_ADDRESS) {
      DHCPDEBUG(printf("DHCPServer: REQUEST 'requested IP' not on subnet for Client "MACFORM"\n",
                       MAC(pDhcpPacket->chaddr)));
      DHCPSendMessage(pDhcpServ, pClient, "requested IP not on this subnet", DHCPNAK);
      FreeDHCPProcessingClient(pClient);
      DLLIST_remove(pDhcpServ->pDllProcessingClients);
      return -1;
    }

    /* Final check to make sure 'requested IP' is not assigned to anyone else */
    /* Do NOT send PING here! */
    if (pClient->oOfferState != OFFER_STATIC &&
        TRUE == CheckIfIPAssigned(pDhcpServ, (OCTET)(dwRequestedIP & 0x000000FF),
                                  pClient->poClientID, pClient->oClientIDLen, TRUE)) {
      DHCPSendMessage(pDhcpServ, pClient, "requested IP already assigned", DHCPNAK);
      FreeDHCPProcessingClient(pClient);
      DLLIST_remove(pDhcpServ->pDllProcessingClients);
      return -1;
    }
  }
  else {
    /* It must be a RENEW request */
    DWORD dwLeaseTime = 0;
    DHCP_BOUND_CLIENT_ENTRY *pClientEntry;

    /* Client may be skipping DISCOVER process and requesting a known address */
    /* For now, hack in the requested IP address as the 'ciaddr' */
    if (pDhcpPacket->ciaddr == 0) {
      /* There should be a requested IP address */
      GetOption(pDhcpPacket, DHCP_OPT_REQUEST_IP_ADDRESS, (OCTET *)&dwRequestedIP, NULL, TRUE);
      dwRequestedIP = ntohl(dwRequestedIP);

      if (dwRequestedIP != 0) {
        pClient->bRequestFromNullIP = TRUE;
        pClient->xDhcpPacket.ciaddr = ntohl(dwRequestedIP);
      }
    }

    pClientEntry = FindStaticAssignment(pDhcpServ, pClient);

    if (pClientEntry == NULL) {
      pClientEntry = FindBoundClientEntryByCID(pDhcpServ,
                                               pClient->poClientID,
                                               pClient->oClientIDLen);
    }

    DEBUG(printf("DHCPProcessRequest: Client "MACFORM" trying to renew binding "IPFORM" 'xid'=%lu\n",
                 MAC(pDhcpPacket->chaddr),
                 IP(ntohl(pClient->xDhcpPacket.ciaddr)),
                 pClient->xDhcpPacket.xid));

    /* Confirm that the client is renewing the same IP address */
    if (bOfferResponse == FALSE && pClientEntry != NULL &&
        (ntohl(pClient->xDhcpPacket.ciaddr) == (SUBNET_ADDRESS | pClientEntry->oCurrentIPAddress))) {
      pClient->oOfferIP = pClientEntry->oCurrentIPAddress;

      if (pClientEntry->bPermanent) {
        pClient->dwLeaseTime = INFINITE_LEASE;
      } else {
        GetOption(&pClient->xDhcpPacket, DHCP_OPT_LEASE_TIME, (OCTET *)&dwLeaseTime, NULL, TRUE);
        dwLeaseTime = ntohl(dwLeaseTime);
      }

      if (dwLeaseTime != 0) {
        pClient->dwLeaseTime = dwLeaseTime;
      } else {
        pClient->dwLeaseTime = DEFAULT_LEASE_TIME;
      }
    } else {
      /* We don't know about this client's binding */
      DHCPDEBUG(printf("DHCPServer: Client "MACFORM" trying to renew unknown binding 'xid'=%lu\n",
                       MAC(pDhcpPacket->chaddr),pClient->xDhcpPacket.xid));
      DHCPSendMessage(pDhcpServ, pClient, "unknown binding", DHCPNAK);
      FreeDHCPProcessingClient(pClient);
      DLLIST_remove(pDhcpServ->pDllProcessingClients);
      return -1;
    }
  }

  if (pClient->bRequestFromNullIP == FALSE) {
    /* Everything else looks OK, send ACK */
    pClient->xDhcpPacket.yiaddr = htonl(SUBNET_ADDRESS | pClient->oOfferIP);
    DHCPSendMessage(pDhcpServ, pClient, NULL, DHCPACK);

    /* Commit the IP assignment to the local binding table */
    DHCPCommitAssignment(pDhcpServ, pClient);

    /* Done processing this client */
    FreeDHCPProcessingClient(pClient);
    DLLIST_remove(pDhcpServ->pDllProcessingClients);
  } else {
    /* Ping the IP address to see if anyone is using it */
    NetPingStat(pDhcpServ->dwDHCPServerIP, SUBNET_ADDRESS | pClient->oOfferIP);
    NetPing(pDhcpServ->dwDHCPServerIP, SUBNET_ADDRESS | pClient->oOfferIP);
    pClient->dwPingResponseTime = PING_RESPONSE_TIMEOUT;    /* Allow 2 seconds to reply with response */
  }

  return 0;
}


/**************************************************************************
 * Process an incoming DHCPINFORM message
 **************************************************************************/
LONG DHCPProcessInform(DHCP_SERVER *pDhcpServ,
                       DHCP_PROCESS_CLIENT *pClient,
                       DHCP_PACKET *pDhcpPacket)
{
  ASSERT(pDhcpServ);
  ASSERT(pDhcpPacket);

  /* Only process if ciaddr field is valid and not empty */
  if (pDhcpPacket->ciaddr != 0 &&
      ((ntohl(pDhcpPacket->ciaddr) & 0xFFFFFF00) == SUBNET_ADDRESS)) {
    if (pClient == NULL) {
      pClient = calloc(1,sizeof(DHCP_PROCESS_CLIENT));
      DLLIST_append(pDhcpServ->pDllProcessingClients,pClient);
    }
    memcpy(&(pClient->xDhcpPacket), pDhcpPacket, DHCP_PACKET_SIZE);
    GetClientID(pClient);
    pClient->dwOriginal_yiaddr = pDhcpPacket->yiaddr;
    pClient->xDhcpPacket.yiaddr = 0;
    pClient->dwLeaseTime = 0;
    DHCPSendMessage(pDhcpServ, pClient, NULL, DHCPACK);
  } else {
    DHCPDEBUG(printf("DHCPServer: INFORM message with invalid 'ciaddr' from client "MACFORM"\n",
                     MAC(pDhcpPacket->chaddr)));
    if (pClient) {
      DHCPSendMessage(pDhcpServ, pClient, "missing or invalid ciaddr", DHCPNAK);
    }
  }

  if (pClient) {
    FreeDHCPProcessingClient(pClient);
    DLLIST_remove(pDhcpServ->pDllProcessingClients);
  }

  return 0;
}


/**************************************************************************
 * Process an incoming DHCP message
 * Check it is a valid DHCP server and call corresponding function
 **************************************************************************/
LONG DHCPServRxPacket(DHCP_SERVER *pDhcpServ,
                      DHCP_PACKET *pDhcpPacket)
{
  DHCP_PROCESS_CLIENT *pClient = NULL;
  OCTET *poClientID = NULL;
  OCTET oClientIDLen = 0;
  OCTET oMsgType = 0;
  ASSERT(pDhcpPacket);

  /* Check it is a valid DHCP Request packet */
  if ((pDhcpPacket->op != BOOTREQUEST) ||
      (pDhcpPacket->options[0] != 99) ||
      (pDhcpPacket->options[1] != 130) ||
      (pDhcpPacket->options[2] != 83) ||
      (pDhcpPacket->options[3] != 99)) {
    /* It is not! */
    DHCPDEBUG(printf("DHCPServer: Not a valid BOOTREQUEST message\n"));
    return -1;
  }

  /* Get the DHCP message type */
  GetOption(pDhcpPacket,DHCP_OPT_MESSAGE_TYPE, &oMsgType, NULL, TRUE);

  /* Get the client identifier */
  oClientIDLen = (OCTET)GetOption(pDhcpPacket, DHCP_OPT_CLIENT_IDENTIFIER, NULL, &poClientID, FALSE);
  if (poClientID == NULL) {
    /* Nothing provided, use the hardware address as client ID */
    poClientID = pDhcpPacket->chaddr;
    oClientIDLen = (OCTET)pDhcpPacket->hlen;
  }

  /* Find the active client (if it exists) */
  pClient = FindProcessingClient(pDhcpServ, poClientID, oClientIDLen);

  /* Is this packet a retranmission of the last one */
  if (pClient) {
    OCTET oLastMsgType = 0;
    GetOption(&pClient->xDhcpPacket, DHCP_OPT_MESSAGE_TYPE, &oLastMsgType, NULL, TRUE);

    /* Just compare message types for now */
    if (oMsgType == oLastMsgType &&
        oMsgType == DHCPDISCOVER &&
        pClient->oOfferIP != 0 &&
        pClient->dwResponseTimer > 0) {
      /* Retransmit the offer message */
      DHCPDEBUG({
        printf("DHCPServer: Received retransmitted DISCOVER packet from Client "MACFORM", 'xid'=%lu\n",
               MAC(pDhcpPacket->chaddr), pDhcpPacket->xid);
        printf("DHCPServer: Retransmitting OFFER message\n");
      });
      memcpy(&(pClient->xDhcpPacket), pDhcpPacket, DHCP_PACKET_SIZE);
      DHCPSendMessage(pDhcpServ,pClient,NULL,DHCPOFFER);
      return 0;
    }
  }

  switch(oMsgType) {

  /************
   * DISCOVER *
   ************/
  case DHCPDISCOVER:
    DHCPDEBUG(printf("DHCPServer: Received DISCOVER packet from Client "MACFORM", 'xid'=%lu\n",
                     MAC(pDhcpPacket->chaddr), pDhcpPacket->xid));
    DHCPProcessOffer(pDhcpServ, pClient, pDhcpPacket);
    break;


  /************
   * REQUEST  *
   ************/
  case DHCPREQUEST:
    DHCPDEBUG(printf("DHCPServer: Received REQUEST packet from Client "MACFORM", 'xid'=%lu\n",
                     MAC(pDhcpPacket->chaddr), pDhcpPacket->xid));
    DHCPProcessRequest(pDhcpServ, pClient, pDhcpPacket);
    break;


  /************
   * INFORM   *
   ************/
  case DHCPINFORM:
    DHCPDEBUG(printf("DHCPServer: Received INFORM packet from Client "MACFORM", 'xid'=%lu\n",
                     MAC(pDhcpPacket->chaddr), pDhcpPacket->xid));
    DHCPProcessInform(pDhcpServ, pClient, pDhcpPacket);
    break;


  /************
   * DECLINE  *
   ************/
  case DHCPDECLINE:
    {
      DWORD dwDeclinedIP = 0;
      char pcReason[312];

      GetOption(&pClient->xDhcpPacket,DHCP_OPT_REQUEST_IP_ADDRESS,(OCTET *)&dwDeclinedIP, NULL, TRUE);
      dwDeclinedIP = ntohl(dwDeclinedIP);

      bzero(pcReason,312);
      GetOption(&pClient->xDhcpPacket,DHCP_OPT_ERROR_MESSAGE,(OCTET *)pcReason, NULL, TRUE);

      DHCPDEBUG(printf("DHCPServer: Received DECLINE packet from Client "MACFORM" for IP "IPFORM", reason = %s\n",
                       MAC(pDhcpPacket->chaddr), IP(ntohl(dwDeclinedIP)), pcReason));
      DHCPReleaseAssignment(pDhcpServ, pDhcpPacket, poClientID, oClientIDLen, TRUE);
    }
    break;


  /************
   * RELEASE  *
   ************/
  case DHCPRELEASE:
    DHCPDEBUG(printf("DHCPServer: Received RELEASE packet from Client "MACFORM" for IP "IPFORM"\n",
                     MAC(pDhcpPacket->chaddr), IP(ntohl(pDhcpPacket->ciaddr))));
    DHCPReleaseAssignment(pDhcpServ, pDhcpPacket, poClientID, oClientIDLen, FALSE);
    break;

  default:
    /* Ignore, don't know DHCP message type */
    break;
  }

  return 0;
}


/**************************************************************************
 * Main DHCP server task routine
 *   1: Listen on server port 68 for incoming DHCP messages
 *   2: Process each 'processing' client's response timer
 *   3: Process each 'processing' client's ping response timer
 *   4: Process each 'bound' client's lease timer
 **************************************************************************/
void* DHCPServTask()
{
  DHCP_SERVER *pDhcpServ = pxDHCPServ;

  ASSERT(pDhcpServ);

  if (pDhcpServ == NULL || pDhcpServ->oServState == DHCPSERV_STATE_TERMINATING) {
    return NULL;
  }

  pthread_mutex_lock(&(pDhcpServ->xDHCPMutex));

  /* Is the server enabled and processing clients? */
  if (pxDHCPServ->oServState == DHCPSERV_STATE_ENABLED) {
    /* Listen on DHCP server port for RX'ed packets */
    DHCP_PACKET *pDhcpPacket = calloc(1,sizeof(DHCP_PACKET));
    while (recvfrom(pDhcpServ->iDhcpSocket,
                    (char *)pDhcpPacket, DHCP_PACKET_SIZE, 0, 0, 0) > 0) {
      DHCPServRxPacket(pDhcpServ, pDhcpPacket);
      bzero((char *)pDhcpPacket,sizeof(DHCP_PACKET));
    }
    FREE(pDhcpPacket);
  }

  /* Process all active client's (i.e. client's who are making requests) */
  {
    DHCP_PROCESS_CLIENT *pClient = NULL;
    DLLIST_head(pDhcpServ->pDllProcessingClients);
    while ((pClient = DLLIST_read(pDhcpServ->pDllProcessingClients)) != NULL) {

      /* Is the server enabled and processing clients? */
      if (pxDHCPServ->oServState != DHCPSERV_STATE_ENABLED) {
        /* Delete the client being processed */
        FreeDHCPProcessingClient(pClient);
        DLLIST_remove(pDhcpServ->pDllProcessingClients);
        continue;
      }

      /* Process offer response timer */
      if (pClient->dwResponseTimer > 0) {
        if (--pClient->dwResponseTimer == 0) {
          /* Client has not responded to our offer? */
          FreeDHCPProcessingClient(pClient);
          DLLIST_remove(pDhcpServ->pDllProcessingClients);
          continue;
        }
      }

      /* Process ping response timer */
      if (pClient->dwPingResponseTime > 0) {

        DWORD dwPingCount = 0;

        /* Check to see if any ping responses have been received */
        if ((dwPingCount = NetPingStat(pDhcpServ->dwDHCPServerIP, SUBNET_ADDRESS | pClient->oOfferIP)) > 0) {
          DHCPDEBUG(printf("DHCPServer: Address already in use - %lu Ping response(s) from IP "IPFORM"\n",
                           dwPingCount, IP(SUBNET_ADDRESS | pClient->oOfferIP)));

          if (pClient->bRequestFromNullIP == FALSE) {
            /* Try next offer rule */
            if (pClient->oOfferState < OFFER_SEARCH_POOL_UNASSIGNED) pClient->oOfferState++;

            /* Start the offer process again by trying a new IP address */
            pClient->dwPingResponseTime = 0;
            if (-1 == DHCPProcessOffer(pDhcpServ, pClient,
                                       &pClient->xDhcpPacket)) {
              /* There are no more options, client has been deleted */
              continue;
            }
          } else {
            DHCPSendMessage(pDhcpServ, pClient, "Requested IP in use", DHCPNAK);
            FreeDHCPProcessingClient(pClient);
            DLLIST_remove(pDhcpServ->pDllProcessingClients);
            continue;
          }
        }
        else {
          if ((pClient->dwPingResponseTime % 5) == 0) {
            /* Send ping every 500ms */
            NetPing(pDhcpServ->dwDHCPServerIP, SUBNET_ADDRESS | pClient->oOfferIP);
          }

          if (--pClient->dwPingResponseTime == 0) {
            /* A ping has timed out, assume address is not in use */
            /* Send OFFER/ACK message to client with the address */
            NetPingStat(pDhcpServ->dwDHCPServerIP, SUBNET_ADDRESS | pClient->oOfferIP);
            if (pClient->bRequestFromNullIP == FALSE) {
              DHCPSendMessage(pDhcpServ,pClient,NULL,DHCPOFFER);
            } else {
              pClient->xDhcpPacket.yiaddr = htonl(SUBNET_ADDRESS | pClient->oOfferIP);
              DHCPSendMessage(pDhcpServ, pClient, NULL, DHCPACK);

              /* Commit the IP assignment to the local binding table */
              DHCPCommitAssignment(pDhcpServ, pClient);

              /* Done processing this client */
              FreeDHCPProcessingClient(pClient);
              DLLIST_remove(pDhcpServ->pDllProcessingClients);
              continue;
            }
          }
        }
      }

      DLLIST_next(pDhcpServ->pDllProcessingClients);
    }
  }

  /* Process all leases. This happens regardless of whether the DHCP
   * server is enabled or not */
  {
    DHCP_BOUND_CLIENT_ENTRY *pClientEntry = pDhcpServ->pClientLinkListHead;

    while (pClientEntry != NULL) {
      if ((!pClientEntry->bPermanent) && (pClientEntry->dwLeaseTimer > 0) &&
          (pClientEntry->dwLeaseTimer != INFINITE_LEASE)) {
        if (--pClientEntry->dwLeaseTimer == 0) {
          /* This user's lease has expired */
          pClientEntry->oPreviousIPAddress = pClientEntry->oCurrentIPAddress;
          DHCPDEBUG(printf("DHCPServer: Client "MACFORM"'s lease has expired. IP "IPFORM" returned to pool\n",
                           MAC(CLIENTCID(pClientEntry)),
                           IP(SUBNET_ADDRESS | pClientEntry->oCurrentIPAddress)));
        }
      }
      pClientEntry = pClientEntry->pNext;
    }
  }

  pthread_mutex_unlock(&(pDhcpServ->xDHCPMutex));


#ifndef NDEBUG
  /* Display table? */
  if (g_bDisplayDHCPClientTable == 1) {
    DHCPServerDisplayTable(pDhcpServ);
    g_bDisplayDHCPClientTable = 0;
  }
#endif

  return NULL;
}


#ifdef NETSRV_THREAD
/**************************************************************************
 * DHCP thread function - Calls DHCPServTask every 100ms
 **************************************************************************/
void *DHCPThreadRoutine(void *pArg)
{
  struct timespec rqtp = {0,DHCP_SLEEP_PERIOD};

  ASSERT(pxDHCPServ != NULL);
  while(pxDHCPServ->oServState != DHCPSERV_STATE_TERMINATING) {
    nanosleep(&rqtp, NULL);
    DHCPServTask(pxDHCPServ);
  }

  return NULL;
}
#endif

/**************************************************************************
 * Load the DHCP server settings from config file
 **************************************************************************/
LONG DHCPServerConfigure(DHCP_SERVER *pDhcpServ)
{
  char chParamValue[CONFIG_MAXPARAMLENGTH+1];

  pthread_mutex_lock(&(pxDHCPServ->xDHCPMutex));

  /* Defaults */
  pDhcpServ->oPoolMin = 100;
  pDhcpServ->oPoolMax = 100 + DHCP_MAX_ADDRESS_RANGE - 1;
  pDhcpServ->dwDNS1 = 0;
  pDhcpServ->dwDNS2 = 0;

  /* Get the DHCP pool size */
  if (ConfigGetParam("DHCPPOOLMIN",chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
    pDhcpServ->oPoolMin = atol(chParamValue);
  }
  if (ConfigGetParam("DHCPPOOLMAX",chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
    if (pDhcpServ->oPoolMax >= pDhcpServ->oPoolMin) {
      pDhcpServ->oPoolMax = atol(chParamValue);
    }
    pDhcpServ->oPoolMax = atol(chParamValue);
  }

  /* Range Sanity checks */
  if (pDhcpServ->oPoolMax >= pDhcpServ->oPoolMin + DHCP_MAX_ADDRESS_RANGE) {
    pDhcpServ->oPoolMax = pDhcpServ->oPoolMin + DHCP_MAX_ADDRESS_RANGE - 1;
  }
  if (pDhcpServ->oPoolMax == 255) {
    /* Can't use broadcast address */
    pDhcpServ->oPoolMax = 254;
  }
  if (pDhcpServ->oPoolMax < pDhcpServ->oPoolMin) {
    pDhcpServ->oPoolMax = pDhcpServ->oPoolMin;
  }

  DHCPDEBUG(printf("DHCPServer: Pool min = %d\n",pDhcpServ->oPoolMin));
  DHCPDEBUG(printf("DHCPServer: Pool max = %d\n",pDhcpServ->oPoolMax));

  /* Subnet mask */
  SetupNetGetIfSubnetMask(0, &(pxDHCPServ->dwSubnetMask));

  /* Router */
  pDhcpServ->dwRouter = pDhcpServ->dwDHCPServerIP;  /* Default router = ourself */

  /* Add statically assigned DNS servers to forward to clients */
  DHCPDEBUG(printf("DHCPServer: Adding static DNS servers\n"));
  if (ConfigGetParam("IPDNS1",chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
    pDhcpServ->dwDNS1 = inet_addr(chParamValue);
    DHCPDEBUG(printf("  DNS1: "IPFORM"\n",IP(pDhcpServ->dwDNS1)));
  }
  if (ConfigGetParam("IPDNS2",chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
    pDhcpServ->dwDNS2 = inet_addr(chParamValue);
    DHCPDEBUG(printf("  DNS2: "IPFORM"\n",IP(pDhcpServ->dwDNS2)));
  }

  /* LAN domain name */
  if (pDhcpServ->pcDomainName) FREE(pDhcpServ->pcDomainName);
  pDhcpServ->pcDomainName = NULL;
  if (ConfigGetParam("DHCPDOMAIN",chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
    pDhcpServ->pcDomainName = MALLOC((strlen(chParamValue)+1)*sizeof(char));
    strcpy(pDhcpServ->pcDomainName, chParamValue);
    DHCPDEBUG(printf("DHCPServer: DHCP LAN domain name = '%s'\n",
                     pDhcpServ->pcDomainName));
  }

  pthread_mutex_unlock(&(pxDHCPServ->xDHCPMutex));

  /* Set static assignments */
  DHCPServerUpdateStaticAssignments();

  return 0;
}


/**************************************************************************
 * EXTERNAL DHCP SERVER API FUNCTIONS
 **************************************************************************/

/**************************************************************************
 * Update the static assignments in the client binding table
 **************************************************************************/
LONG DHCPServerUpdateStaticAssignments(void)
{
  int i;
  char chParamValue[CONFIG_MAXPARAMLENGTH+1];
  DHCP_BOUND_CLIENT_ENTRY *pClientEntry = pxDHCPServ->pClientLinkListHead;

  pthread_mutex_lock(&(pxDHCPServ->xDHCPMutex));

  /* Remove all previous static assignments */
  while (pClientEntry != NULL) {
    if (pClientEntry->bPermanent) {

      ClientLinkListRemove(pxDHCPServ, pClientEntry);
      FreeDHCPBoundClient(pClientEntry);
      pClientEntry = pxDHCPServ->pClientLinkListHead;

      continue;
    }

    pClientEntry = pClientEntry->pNext;
  }

  /* Add new static assignments */
  for (i=1;i<9;i++) {
    char chStat[20];
    sprintf(chStat,"DHCPSTATICIP%d",i);
    if (ConfigGetParam(chStat,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {
      OCTET oIP = atoi(chParamValue);
      if (oIP <= 255) {
        char chID[CONFIG_MAXPARAMLENGTH+1];
        WORD wMemRequired = 0;

        sprintf(chStat,"DHCPSTATICID%d",i);
        if (ConfigGetParam(chStat,chID,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) {

          wMemRequired = sizeof(DHCP_BOUND_CLIENT_ENTRY) - sizeof(void *) + 1;

          sprintf(chStat,"DHCPSTATICIDTYPE%d",i);
          if ((ConfigGetParam(chStat,chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) &&
              (!strcmp(chParamValue,"HOSTNAME"))) {
            LONG lHostNameLen = min(18,strlen(chID));

            wMemRequired += lHostNameLen;
            pClientEntry = calloc(1,wMemRequired);
            memcpy(CLIENTHOSTNAME(pClientEntry), chID, lHostNameLen);
          }

          else {
            OCTET *poClientID = NULL;
            int iMac[6];
            int j;

            for (j=0;j<strlen(chID);j++) {
              chID[j] = toupper(chID[j]);
            }

            wMemRequired += 6;
            pClientEntry = calloc(1,wMemRequired);

            pClientEntry->oClientIDLen = 6;
            poClientID = CLIENTCID(pClientEntry);

            sscanf((char *)chID,"%02X%02X%02X%02X%02X%02X",
                   &iMac[0],&iMac[1],&iMac[2],&iMac[3],&iMac[4],&iMac[5]);

            poClientID[0] = iMac[0];
            poClientID[1] = iMac[1];
            poClientID[2] = iMac[2];
            poClientID[3] = iMac[3];
            poClientID[4] = iMac[4];
            poClientID[5] = iMac[5];
          }

          pClientEntry->oPreviousIPAddress = pClientEntry->oCurrentIPAddress = oIP;
          pClientEntry->dwLeaseTimer = INFINITE_LEASE;
          pClientEntry->bPermanent = TRUE;

          ClientLinkListAdd(pxDHCPServ, pClientEntry);
        }
      }
    }
  }

  pthread_mutex_unlock(&(pxDHCPServ->xDHCPMutex));

  return DHCP_SUCCESS;
}


/**************************************************************************
 * Initializes the DHCP server client binding table for binding extraction
 * IMPORTANT: This function will lock the server until function
 *            DHCPServerEndBindingTableQuery() is called. This is to ensure
 *            that the client binding table does not change during
 *            client binding extraction (by successively calling function
 *            DHCPServerGetNextBinding())
 **************************************************************************/
LONG DHCPServerInitBindingTableQuery(void)
{
  if (pxDHCPServ == NULL) return DHCP_BADCALL_FAIL;

  /*
   * Lock the mutex (server) so that the table cannot change
   * during binding extraction.
   */
  pthread_mutex_lock(&(pxDHCPServ->xDHCPMutex));
  pxDHCPServ->pCurrentBindQuery = pxDHCPServ->pClientLinkListHead;

  return DHCP_SUCCESS;
}


/**************************************************************************
 * Notify that no more client binding information is required.
 * Unlock the server to allow binding table updates.
 **************************************************************************/
LONG DHCPServerEndBindingTableQuery(void)
{
  if (pxDHCPServ == NULL) return DHCP_BADCALL_FAIL;

  /*
   * Unlock the mutex (server) so that the table can be updated
   */
  pthread_mutex_unlock(&(pxDHCPServ->xDHCPMutex));
  return DHCP_SUCCESS;
}


/**************************************************************************
 * Returns next client binding information to the calling application
 **************************************************************************/
LONG DHCPServerGetNextBinding(DWORD *pdwIPAddress,
                              char** pcName,
                              OCTET** poClientID,
                              OCTET *poClientIDLength)
{
  *pdwIPAddress = 0;
  *pcName = NULL;
  *poClientID = NULL;
  *poClientIDLength = 0;

  if (pxDHCPServ == NULL || pxDHCPServ->oServState == DHCPSERV_STATE_DISABLED) {
    return DHCP_BADCALL_FAIL;
  }

  /* Only report valid DHCP (non-static) client's with active leases */
  while (1) {
    if (pxDHCPServ->pCurrentBindQuery == NULL) {
      /* No more clients */
      return -1;
    }

    if (pxDHCPServ->pCurrentBindQuery->bPermanent ||
        pxDHCPServ->pCurrentBindQuery->dwLeaseTimer == 0) {
      pxDHCPServ->pCurrentBindQuery = pxDHCPServ->pCurrentBindQuery->pNext;
    }
    else break;
  }

  /* Send the client info back to the app */
  *pdwIPAddress = ((pxDHCPServ->dwDHCPServerIP) & 0xFFFFFF00) |
                    pxDHCPServ->pCurrentBindQuery->oCurrentIPAddress;
  *pcName = CLIENTHOSTNAME(pxDHCPServ->pCurrentBindQuery);
  *poClientID = CLIENTCID(pxDHCPServ->pCurrentBindQuery);
  *poClientIDLength = pxDHCPServ->pCurrentBindQuery->oClientIDLen;

  pxDHCPServ->pCurrentBindQuery = pxDHCPServ->pCurrentBindQuery->pNext;

  return DHCP_SUCCESS;
}


/**************************************************************************
 * Create, initialize, and allocate resources for the DHCP server
 *   Does NOT start it.
 *   Must be called before DHCPServerStart
 *     dwDHCPServerIP - IP Address of the DHCP server
 **************************************************************************/
LONG DHCPServerCreate(DWORD dwDHCPServerIP)
{
  if (pxDHCPServ != NULL) return DHCP_BADCALL_FAIL;

  /* Create DHCP structure */
  pxDHCPServ = calloc(1,sizeof(DHCP_SERVER));
  if (pxDHCPServ == NULL) {
    ASSERT(0);
    return DHCP_MEM_FAIL;
  }

  /* Load DHCP server parameters */
  pxDHCPServ->dwDHCPServerIP = dwDHCPServerIP;

  /* Start server in disabled mode */
  pxDHCPServ->oServState = DHCPSERV_STATE_DISABLED;

  /* Initialise DHCP mutex */
  {
    pthread_mutexattr_t attr;
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP);
    if (pthread_mutex_init(&(pxDHCPServ->xDHCPMutex), &attr) < 0) {
      FREE(pxDHCPServ);
      pxDHCPServ = NULL;
      pthread_mutexattr_destroy(&attr);
      ASSERT(0);
      return(DHCP_THR_FAIL);
    }
    pthread_mutexattr_destroy(&attr);
  }

  /* Create binding table link list head */
  pxDHCPServ->pClientLinkListHead = NULL;
  pxDHCPServ->wClientCount = 0;

  /* Create DLLIST for client's currently being processed */
  pxDHCPServ->pDllProcessingClients = new_DLLIST();

#ifdef NETSRV_THREAD
  /* Create DHCP server thread */
  if (pthread_create(&(pxDHCPServ->th_tThread), NULL,
                     DHCPThreadRoutine,
                     NULL) != 0) {
    ASSERT(0);
    return(DHCP_THR_FAIL);
  }
#else
  pxDHCPServ->hInst = ProtocolServiceRegister(DHCPServTask, 100);
  if (pxDHCPServ->hInst == 0) {
    ASSERT(0);
    return(DHCP_THR_FAIL);
  }
#endif

  DHCPDEBUG(printf("DHCPServer: DHCP server created\n"));

  return DHCP_SUCCESS;
}


/**************************************************************************
 * (Re)Enable the DHCP server - (Re)Configures and starts running it
 **************************************************************************/
LONG DHCPServerStart(void)
{
  struct sockaddr_in serv_addr;
  char chParamValue[CONFIG_MAXPARAMLENGTH+1];

  if (pxDHCPServ == NULL ||
      pxDHCPServ->oServState == DHCPSERV_STATE_ENABLED) {
    return DHCP_BADCALL_FAIL;
  }

  /* Only start up if DHCP server web setting is "ENABLED" */
  if ((ConfigGetParam("DHCPSERV",chParamValue,CONFIG_MAXPARAMLENGTH)==CONFIG_OK) &&
      strcmp(chParamValue,"ENABLED") != 0) {
    DEBUG(printf("DHCPServerStart: DHCP server not started - disabled\n"));
    return DHCP_BADCALL_FAIL;
  }

  pthread_mutex_lock(&(pxDHCPServ->xDHCPMutex));

  /* Open DHCP server socket */
  if ((pxDHCPServ->iDhcpSocket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    DHCPDEBUG(printf("DHCPServer: socket open error\n"));
    ASSERT(0);
    pthread_mutex_unlock(&(pxDHCPServ->xDHCPMutex));
    return DHCP_NTWK_FAIL;
  }

  /* Socket Configuration (non blocking) */
  if (fcntl(pxDHCPServ->iDhcpSocket,F_SETFL,
            fcntl(pxDHCPServ->iDhcpSocket,F_GETFL,0) |
            O_NONBLOCK) < 0) {
    DHCPDEBUG(printf("DHCPServer: socket configure error\n"));
    ASSERT(0);
    pthread_mutex_unlock(&(pxDHCPServ->xDHCPMutex));
    return DHCP_NTWK_FAIL;
  }

  /* Bind DHCP server socket */
  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = pxDHCPServ->dwDHCPServerIP;
  serv_addr.sin_port = htons(DHCPSERVERPORT);
  if (bind(pxDHCPServ->iDhcpSocket, (struct sockaddr *)(&serv_addr),
           sizeof(serv_addr)) < 0) {
    DHCPDEBUG(printf("DHCPServer: bind error\n"));
    close(pxDHCPServ->iDhcpSocket);
    ASSERT(0);
    pthread_mutex_unlock(&(pxDHCPServ->xDHCPMutex));
    return DHCP_NTWK_FAIL;
  }

  /* (Re)configure the DHCP server */
  DHCPServerConfigure(pxDHCPServ);

  /* Start the engines! */
  pxDHCPServ->oServState = DHCPSERV_STATE_ENABLED;

  pthread_mutex_unlock(&(pxDHCPServ->xDHCPMutex));

  DEBUG(printf("DHCPServerStart: DHCP server started\n"));

  return DHCP_SUCCESS;
}


/**************************************************************************
 * Clear the DHCP Server's binding table
 *   ALL bindings will be deleted
 **************************************************************************/
LONG DHCPServerClearBindingTable(void)
{
  if (pxDHCPServ == NULL) return DHCP_BADCALL_FAIL;

  pthread_mutex_lock(&(pxDHCPServ->xDHCPMutex));

  /* Delete client linked list */
  {
    DHCP_BOUND_CLIENT_ENTRY *pClientEntry = pxDHCPServ->pClientLinkListHead;

    while (pClientEntry != NULL) {
      pxDHCPServ->pClientLinkListHead = pClientEntry->pNext;
      FreeDHCPBoundClient(pClientEntry);
      pClientEntry = pxDHCPServ->pClientLinkListHead;
    }

    pxDHCPServ->pClientLinkListHead = NULL;
    pxDHCPServ->wClientCount = 0;
  }

  DEBUG(printf("DHCPServerClearBindingTable: Table cleared\n"));

  pthread_mutex_unlock(&(pxDHCPServ->xDHCPMutex));

  DHCPServerUpdateStaticAssignments();

  return DHCP_SUCCESS;
}


/**************************************************************************
 * Disable the DHCP server
 *   Does not completely disable the DHCP server
 *   Lease timers will still be decremented, but socket will be closed
 *   and no clients will be responded to
 **************************************************************************/
LONG DHCPServerStop(void)
{
  if (pxDHCPServ == NULL ||
      pxDHCPServ->oServState == DHCPSERV_STATE_DISABLED) {
    return DHCP_BADCALL_FAIL;
  }

  pthread_mutex_lock(&(pxDHCPServ->xDHCPMutex));

  /* Close DHCP server socket */
  close(pxDHCPServ->iDhcpSocket);
  pxDHCPServ->iDhcpSocket = -1;

  /* Disable the DHCP server */
  pxDHCPServ->oServState = DHCPSERV_STATE_DISABLED;

  pthread_mutex_unlock(&(pxDHCPServ->xDHCPMutex));

  DEBUG(printf("DHCPServerStop: DHCP server stopped (disabled)\n"));

  return DHCP_SUCCESS;
}


/**************************************************************************
 * Terminate the DHCP server and free all allocated resources
 **************************************************************************/
LONG DHCPServerTerminate(void)
{
  if (pxDHCPServ == NULL) return DHCP_BADCALL_FAIL;

  /* Stop the server */
  DHCPServerStop();

  pxDHCPServ->oServState = DHCPSERV_STATE_TERMINATING;

#ifdef NETSRV_THREAD
  /* Wait for DHCP server thread to die */
  pthread_join(pxDHCPServ->th_tThread,NULL);
#else
  ProtocolServiceUnregister(pxDHCPServ->hInst);
#endif

  /* Delete client linked list */
  DHCPServerClearBindingTable();

  /* Delete DLLISTs */
  del_DLLIST(pxDHCPServ->pDllProcessingClients,FreeDHCPProcessingClient);

  /* Free DHCP structure */
  if (pxDHCPServ->pcDomainName) FREE(pxDHCPServ->pcDomainName);
  FREE(pxDHCPServ);
  pxDHCPServ = NULL;

  pthread_mutex_destroy(&(pxDHCPServ->xDHCPMutex));

  DHCPDEBUG(printf("DHCPServerTerminate: DHCP server destroyed\n"));

  return DHCP_SUCCESS;
}


/**************************************************************************/
/*********************** END OF FILE **************************************/
/**************************************************************************/
