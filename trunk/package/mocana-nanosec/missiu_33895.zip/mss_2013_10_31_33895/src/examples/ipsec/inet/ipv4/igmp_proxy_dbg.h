/*
 * igmp_proxy_dbg.h
 *
 * IGMP Proxy module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IGMP_PROXY_DBG_H_
#define _IGMP_PROXY_DBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef IGMPPROXYDBG_HI
   #define IGMPPROXYDBG_HI
  #endif
 #endif

#else
 #ifdef IGMPPROXYDBG_HI
  #undef IGMPPROXYDBG_HI
 #endif
#endif

#include "netdbg.h"

/*#ifdef IGMPPROXYDBG_HI*/
#if defined(IGMPPROXYDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define IGMP_PROXY_DBGP(level, fmt, args...)    do {    \
    if (level <= g_dwIgmpProxyDebugLevel) {        \
      printf(fmt, ##args);                \
    }                            \
  } while (0)

  #define IGMP_PROXY_DBG(level, x)    do {        \
    if (level <= g_dwIgmpProxyDebugLevel) {        \
      x;                        \
    }                            \
  } while (0)

  #define IGMP_PROXY_DBG_VAR(x)        x

#else
#if defined (__RTOS_VXWORKS__)
  #define IGMP_PROXY_DBGP
#else
  #define IGMP_PROXY_DBGP(level, fmt, args...)
#endif
  #define IGMP_PROXY_DBG(level, x)
  #define IGMP_PROXY_DBG_VAR(x)
#endif

#endif  /* __IGMP_PROXY_DBG_H__ */
