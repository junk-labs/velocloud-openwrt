/*
 * iputils.c
 *
 * Implements IP utility functions to be used in various layers e.g. IP; UDP
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "utils_flavor.h"
#include "../include/in.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "netutils.h"
#include "../include/in.h"
#include "ip.h"


/*****************************************************************************
 *
 * API Functions
 *
 *****************************************************************************/

/*
 * IpAddrGetMask
 *  Get the default network mask for a given address.
 *
 *  Args:
 *   dwIpAddr                   IP address
 *
 *  Return:
 *   Type of address (IN_CLASSX_NET)
 */
DWORD IpAddrGetMask(DWORD dwIpAddr)
{
  DWORD dwDst=0;

  if (dwIpAddr == 0L)
    return(0L);    /* special case */

  dwDst = dwIpAddr;
  if (IN_CLASSA(dwDst))
    return(IN_CLASSA_NET);
  if (IN_CLASSB(dwDst))
    return(IN_CLASSB_NET);
  if (IN_CLASSC(dwDst))
    return(IN_CLASSC_NET);

  /* Something else, probably a subnet. */
  return(0);
}

/*
 * IpAddrGetType
 *  Identify type of address, based on its form:
 *  can only find out global broadcast, loopback
 *  and multicast
 *
 *
 *  Args:
 *   dwIpAddr                   IP address
 *
 *  Return:
 *   Type of address (IPADDRT_BROADCAST, IPADDRT_MULTICAST, IPADDRT_LOOPBACK,
 *   IPADDRT_UNKNOWN)
 */
INT IpAddrGetType(DWORD dwIpAddr)
{
  DWORD dwMask;

  /* Accept both `all ones' and `all zeros' as BROADCAST. */
  if ((dwIpAddr == INADDR_ANY) || (dwIpAddr == INADDR_BROADCAST)) {
    return IPADDRT_BROADCAST;
  }

  /* Multicast */
  if ((dwIpAddr & 0xf0000000) == 0xE0000000)
  {
    return IPADDRT_MULTICAST;
  }

  /* loopback */
  dwMask = IpAddrGetMask(dwIpAddr);
  /* Accept all of the `loopback' class A net. */
  if ((dwIpAddr & dwMask) == 0x7F000000L)
  {
    return IPADDRT_LOOPBACK;
  }

  return IPADDRT_UNKNOWN;
}

/*
 * IpBuildMCastEthAddr
 *  Build a multicast ethernet address from a multicast ip adress
 *
 *  Args:
 *   aoHwAddr : multicast ethernet address to be filled
 *   dwIpAddr : multicast IP address
 *
 */
void IpBuildMCastEthAddr(OCTET aoHwAddr[], DWORD dwIpAddr)
{
   aoHwAddr[0] = (OCTET)0x01;
   aoHwAddr[1] = (OCTET)0x00;
   aoHwAddr[2] = (OCTET)0x5e;
   aoHwAddr[3] = (OCTET)((dwIpAddr>>16)&0x7f);
   aoHwAddr[4] = (OCTET)((dwIpAddr>>8)&0xff);
   aoHwAddr[5] = (OCTET)(dwIpAddr&0xff);
}

#ifndef NDEBUG
/*
 * IpProtoToString
 *  Convert to a string(TCP,UDP,ICMP,...) the protocol in the ip header
 */

CHAR *IpProtoToString(OCTET oProtocol)
{
  switch(oProtocol){
  case IPID_ICMP:
    return "ICMP";

  case IPID_IGMP:
    return "IGMP";

  case IPID_TCP:
    return "TCP";

  case IPID_UDP:
    return "UDP";

  case IPID_ESP:
    return "ESP";

  case IPID_AH:
    return "AH";

  case IPID_RAW:
    return "RAW";

  default:
    return "???";
  }
}
#endif
