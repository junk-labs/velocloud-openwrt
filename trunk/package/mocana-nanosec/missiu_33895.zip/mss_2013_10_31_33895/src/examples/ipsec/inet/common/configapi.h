#ifndef _CONFIGAPI_H__
#define _CONFIGAPI_H__

MOC_EXTERN int ConfigGetParam(char * str,char *value,int len) ;
#ifndef JJ
#define CONFIG_MAXPARAMLENGTH 128
#define CONFIG_OK 0

#endif
#endif
