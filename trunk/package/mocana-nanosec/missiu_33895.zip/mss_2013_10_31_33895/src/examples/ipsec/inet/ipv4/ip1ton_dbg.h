/*
 * ip1ton_dbg.h
 *
 * Ip1toN module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IP1TON_DBG_H_
#define _IP1TON_DBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef IP1TONDBG_HI
   #define IP1TONDBG_HI
  #endif
 #endif

#else
 #ifdef IP1TONDBG_HI
  #undef IP1TONDBG_HI
 #endif
#endif

#include "netdbg.h"

#define IP1TON_MAGIC_COOKIE 0x69703174 /*"ip1t" = 0x69703174*/

/*#ifdef IP1TONDBG_HI*/
#if defined(IP1TONDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define IP1TON_CHECK_STATE(x) \
            ASSERT((x != NULL) && ((x)->dwMagicCookie == IP1TON_MAGIC_COOKIE));

  #define IP1TON_SET_COOKIE(x) (x)->dwMagicCookie = IP1TON_MAGIC_COOKIE
  #define IP1TON_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define IP1TON_DBGP(level, fmt, args...) do { \
    if (level <= g_dwIp1toNDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define IP1TON_DBG(level, x) do {  \
    if (level <= g_dwIp1toNDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define IP1TON_DBG_VAR(x)  x
#else
  #define IP1TON_CHECK_STATE(x)
  #define IP1TON_SET_COOKIE(x)
  #define IP1TON_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define IP1TON_DBGP
#else
  #define IP1TON_DBGP(level, fmt, args...)
#endif
  #define IP1TON_DBG(level, x)
  #define IP1TON_DBG_VAR(x)
#endif

IP1TON_DBG_VAR(MOC_EXTERN DWORD g_dwIp1toNDebugLevel);
IP1TON_DBG_VAR(MOC_EXTERN DWORD g_dwIp1toNLoopbackPktCnt);

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _IP1TON_DBG_H_ */
