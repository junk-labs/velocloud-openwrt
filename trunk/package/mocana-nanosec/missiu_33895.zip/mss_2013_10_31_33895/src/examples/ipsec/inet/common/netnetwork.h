/*
 * netnetwork.h
 *
 * network layer common api
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETNETWORK_H_
#define _NETNETWORK_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * Network Layer specific Msg
 */
#define NETNETWORKMSG_ADDADDRESS   \
  NETMSG_MODULESPECIFICBEGIN              /* Add a local IP address. The 1st
                                             address set will be the outgoing
                                             default. Data is if_req *. 1st
                                             octet of the ifrname member is
                                             the interface index
                                             The subnet is passed seperately
                                             via message NETNETWORKMSG_SETNETMASK
                                             */

#define NETNETWORKMSG_DELETEADDRESS   \
  (NETMSG_MODULESPECIFICBEGIN + 1)        /* Delete a local IP address. The 1st
                                             address set will be the outgoing
                                             default. Data is if_req *. 1st
                                             octet of the ifrname member is
                                             the interface index
                                             */

#define NETNETWORKMSG_SETNETMASK   \
  (NETMSG_MODULESPECIFICBEGIN + 2)        /* Set the netmask for an interface.
                                             Data is if_req *. 1st octet of the
                                             ifrname member is the interface
                                             index
                                             */

#define NETNETWORKMSG_MODULESPECIFICBEGIN \
  (NETMSG_MODULESPECIFICBEGIN + 3)


/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/


/*
 * NETWORKID
 *  NETWORK layer Id.
 */
typedef struct {
  DWORD dwSrcAddr;     /* If 0, default one is used */
  DWORD dwDstAddr;     /* MUST BE SET */
  E_ADDRTYPE eDstAddrType;
  OCTET oIfIdx;/* Interface index.
                 Default value: NETIFIDX_DEFAULT
                 (see common/include/netcommon.h)
                 Tx path: if it is not NETIFIDX_DEFAULT,
                 the packet must go to this interface, and this
                 interface alone.
                 Rx path: indicates on which interface the
                 packet has been received */
  WORD wVlan;  /* VLAN tag. Equivalent to the TAG CONTROL INFORMATION
                  specified in 802.1Q
                  Default value: NETVLAN_DEFAULT
                  (see common/include/netcommon.h) */
  DWORD dwGatewayAddr; /* Gateway addr. 0 means not set */
  DWORD dwSecurityPolicy;/* secuirity policy */
  WORD wIpSecHdrLength;  /* IPSEC header length */
  WORD wIpSecTrailLength;/* IPSEC trailer length */

  /* Network only fields */
  OCTET oIpHdrLen;
  WORD  wTotalLen;
  WORD  wDatagramId;   /*do we really need it? */
  WORD  wFragOffset;
  OCTET *poIpOption;   /* NULL if NO options */
  OCTET oIpOptionLen;  /* 0 if NO options */
  OCTET oProtocol;
  OCTET oToS;          /* MUST BE SET */
  OCTET oTtL;          /* MUST BE SET */
  OCTET oVersion;

  BOOL bTunnelled;     /* Is this packet IPSEC tunnelled? */
} NETWORKID;

#endif


