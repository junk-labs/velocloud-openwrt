/*
 * shutdown.c
 *
 * Rarely used shutdown() function. Separated from socket.c
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/ioctl.h"
#include "mqueue.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "ip.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * shutdown
 *  Shuts down part of a connection
 *
 *  Args:
 *   sockfd                        The socket returned by the socket function.
 *   howto                         Should be one of:
 *                                 SHUT_RD: The read half of the connection
 *                                  is closed; no more data can be received on
 *                                  the socket. No more read functions can be
 *                                  issued on the socket
 *                                 SHUT_WR: The write half of the connection
 *                                  is closed; no more data can be sent on the
 *                                  socket. No more write functions can be
 *                                  issued on the socket
 *                                 SHUT_RDWR: Both halves of the connection
 *                                  are closed. Equivalent to calling shutdown,
 *                                  first with SHUT_RD, then with SHUT_WR.
 *
 *  Return:
 *  0 : Success.
 *  -1: Error
 */
int mn_shutdown(int sockfd, int howto)
{
  SOCKET *pxSock;
  LONG lReturn = 0;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(sockfd);

  /* Early checks */
  if (pxSock == NULL) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  if(!(pxSock->dwSockState & SS_ISCONNECTED)) {
    mn_errno = MO_ENOTCONN;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }


  switch(howto) {
  case SHUT_RD:
  case SHUT_RDWR:
    pxSock->dwSockState |= SS_CANTRCVMORE;

#ifdef __MOCANA_IPC_LIBSOCK__
    if (pxSock->ipc_req)
    {
        SOCKSERVER_plainReply(pxSock->ipc_req);
        pxSock->ipc_req = NULL;
    }
#endif

    pthread_cond_broadcast(&(pxSock->xCond));
    if ((pxSock->lType == SOCK_DGRAM) &&
        (pxSock->oSelect > 0)) {
      SocketWakeSelect(pxSock,SELECT_RD);
    }

    if (howto == SHUT_RD) break;

  case SHUT_WR:
    pxSock->dwSockState |= SS_CANTSENDMORE;

    if (pxSock->lType == SOCK_STREAM) {
      TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                                  pxSock->hLL,
                                  TCPULINTERFACEIOCTL_SHUTTX,0);
    }
    break;

  default:
    mn_errno = EBADREQ;
    lReturn = -1;
    break;

  }
  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return lReturn;
}



