#ifndef _UDP_CLI_H_
#define _UDP_CLI_H_
ubyte4 UdpCliShow(ubyte *cmdRx, ubyte *sbuf, ubyte4 *sbuflen);
ubyte4 UdpCliConfig(ubyte *cmdRx);
#endif

