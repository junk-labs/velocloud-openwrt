/*
 * eaptls_defs.h
 *
 * EAP TLS definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

 /*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#ifndef EAP_TLS_DEFS_H
#define EAP_TLS_DEFS_H

#include "NNstyle.h"

#include "eaptlsclient_flavor.h"
#include "string.h"
#include "stdlib.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h> /* ntoh macros */
#include <netinet/in.h> /* ntoh macros on Linux/Solaris */
#include <pthread.h>
/* #include <mqueue.h> */
#include <stdio.h>
#include "netcommon.h"
#include "netutils.h"
#include "netdbg.h"
#include "nettime.h"
#include "cryptcommon.h"
#include "md5.h"
#include "eaptlsparser.h"
#include "eaptlsclient.h"
#include "eaptls_dbg.h"

/*****************************************************************************
 *
 * Defines & macros
 *
 *****************************************************************************/

#define EAPTLSCLIENTDEFAULT_TIMER          100 /* 100 Ms */
#define EAP_TLS_MAXMETHODS     6
#define EAP_TLS_MAXSESSIONIDLEN    32
#define EAP_TLS_MAXMASTERSECRET    256
#define EAP_TLS_MTU        1020
#define MAX_SSL_CONNECTIONS_ALLOWED        10
#define EAP_TLS_SESSION_TIMEOUT         600
/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/
/*
 * EAPTLS states
 */
typedef enum {
  EAPTLSCLIENTSTATE_DOWN = 0,
  EAPTLSCLIENTSTATE_UP
} E_EAPTLSCLIENTSTATE;


typedef enum {
  EAPTLSSTATE_INIT = 0,
  EAPTLSSTATE_INPROGRESS,
  EAPTLSSTATE_DONE
} E_EAPTLSSTATE;

/*
 * EAPTLSCLIENT main struture
 */
typedef struct {
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif
  E_EAPTLSCLIENTSTATE eState;   /* State */

  DWORD dwTimer; /* Timer */

  /* Secret */
  OCTET *poSecret;
  DWORD dwSecretLength;

  /* Name */
  OCTET *poName;     /* NULL terminated string */
  OCTET oNameLength; /* Must include the `0` */

  /* Challenge */
  OCTET *poCurrentChallenge;
  OCTET oCurrentChallengeLength;
  OCTET oCurrentChallengeId;
  OCTET obChallengeValid; /* Indicates that the challenge is valid */


  OCTET *eapSessionHdl;
  OCTET allowed_methods[EAP_TLS_MAXMETHODS];
  DWORD allowed_method_count;
  E_EAPTLSSTATE tlsState;
  DWORD instanceId;
  DWORD sessionIdLen;
  OCTET sessionId[EAP_TLS_MAXSESSIONIDLEN];
  OCTET masterSecret[EAP_TLS_MAXMASTERSECRET];
  OCTET *tls_connection;
  OCTET tlsOpen ;


  EAPTLSCLIENTENCRYPTIONSTATE xEncryption;

  PFN_NETCBK pfnNetCbk;
  H_NETINSTANCE hNetCbk;

  H_NETINSTANCE hLl;
  H_NETINTERFACE hLlIf;
  PFN_NETWRITE pfnLlWrite;
  NETIFID xNetIfId;

  PFN_NETFREE pfnNetFree;
  PFN_NETMALLOC pfnNetMalloc;
  pthread_mutex_t *pxNetMutex;

  WORD wOffset;
  WORD wTrailer;

} EAPTLSCLIENTSTATE;



/*****************************************************************************
 *
 * extern
 *
 *****************************************************************************/

#ifndef NDEBUG
MOC_EXTERN const OCTET *apoEapTlsOptionString[EAPTLSCLIENTOPTIONMAX];
MOC_EXTERN const OCTET *apoEapTlsMsgString[EAPTLSCLIENTMSGMAX];
#endif

/*****************************************************************************
 *
 * Local function definitions
 *
 *****************************************************************************/



#endif /*EAPTLS_DEFS_H*/
