#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void *DLLIST_insert_before_fl(DLLIST *dllist, void *item, 
			      char *pFile, int nLine)
{
  DLLIST_ITEM *tmpitem;

  tmpitem = new_DLLIST_ITEM_fl(dllist, pFile, nLine);
  
  if (tmpitem == NULL) {
    return NULL;
  }
  
  tmpitem->item = item;

  return DLLIST_insert_before_ITEM(dllist, tmpitem) -> item;
}

