/*
 * MpoaAtm.c
 *
 * MpoaAtm configuration code
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
/*#include "flavor.h" */
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "stdio.h"
#include "pthread.h"
#include <mqueue.h>
#include "netdb.h"
#include "sys/socket.h"
#include "net/if.h"
#include "limits.h"
#include "net/if_types.h"
#include "errno.h"

#include "netcommon.h"
#include "netconfig.h"
#include "netdefs.h"
#include "netmain.h"
#include "linkconf.h"
#include "netif.h"
#include "ethernet.h"
#include "arp.h"
#include "ip2eth.h"
#include "ethconf.h"
#include "ethlink.h"
#include "mpoa.h"
#include "aal5devapi.h"
#include "atm.h"
#include "mpoaconf.h"
#include "linkconf.h"
#include "ppplibs.h"
#include "ppp.h"
#include "pppoeclient.h"

#include "ip1ton.h"


void _CloseMpoaConnection(NETIFCONF *pxIfConf)
{
  NETMAIN_ASSERT(pxIfConf->iFd>0); /* ensure its open */
  close(pxIfConf->iFd);
  pxIfConf->iFd = -1;
}

void _OpenConfigMpoaConnection(NETIFCONF *pxIfConf)
{
  E_MPOAPROT eMpoaProt = MPOAPROT_ETH;
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hMpoaInst;
  H_NETINTERFACE hMpoaUlIf;
  int iAal5Fd,iRv;

  NETMAIN_ASSERT(pxIfConf->iFd==-1); /* ensure driver is closed */

  pxIfState = NETGETIFSTATE(pxIfConf);
  hMpoaInst = NETGETINST_MPOA(pxIfState);
  hMpoaUlIf = NETGETIF_MPOAUL(pxIfState);

  MpoaInstanceMsg(hMpoaInst, MPOAMSG_SETVCMUX,
                  pxIfConf->xAtmConf.oMode == IF_ATM_MODE_VCMUX ?
                  TRUE : FALSE);

  switch(pxIfConf->oType){
  case IFT_ETHER:
  case IFT_PPPOE:
    eMpoaProt = MPOAPROT_ETH;
    break;
  case IFT_PPP:
    eMpoaProt = MPOAPROT_PPP;
    break;
  case IFT_NULL:
    eMpoaProt = MPOAPROT_IP;
    break;
  default:
    NETMAIN_ASSERT(0);
  }

  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                               NETINTERFACEIOCTL_SETROUTINGID,
                               (H_NETDATA)eMpoaProt);

  /* If it's an ATM interface, we need to construct
   * the device driver name from the VPI/VCI */
  sprintf(pxIfConf->acIfName,"/adsl/aal5/pvcp%dc%d",
          pxIfConf->xAtmConf.oVpi,
          pxIfConf->xAtmConf.oVci);

  iAal5Fd = pxIfConf->iFd = open(pxIfConf->acIfName,O_RDWR);
  ASSERT(iAal5Fd != 0);

#if 0
  /* Set offset & padding appropriately */
  iRv = ioctl(iAal5Fd,AAL5_IOCTL_SET_OFFSET,NETRXOFFSET);
  ASSERT(iRv == 0);

  iRv = ioctl(iAal5Fd,AAL5_IOCTL_SET_PAD,NETRXTRAILER);
  ASSERT(iRv == 0);

  iRv = ioctl(iAal5Fd,AAL5_IOCTL_SET_CHANNELMODE,
              pxIfConf->xAtmConf.oLatency == IF_ATM_LATENCY_INTERLEAVED ?
              UIPORT_INTERLEAVED : UIPORT_FAST);
  ASSERT(iRv == 0);

  iRv = ioctl(iAal5Fd,AAL5_IOCTL_SET_SDU_SIZE,1510);
  ASSERT(iRv == 0);
#endif /* TBD */
}

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * IpoAConfSetup
 *  Specific setup for straight Ip over Atm interfaces
 *
 *  Args:
 *   pxIfConf               Interface conf structure
 *   oIfIdx                 Interface index
 *
 *  Return:
 *   NETLINKLEG
 */

LONG IpoAConfSetup(NETIFCONF *pxIfConf,OCTET oIfIdx)
{
#if 0
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hIp1toN;
  H_NETINTERFACE hMpoaUlIf;

  NETMAIN_DBGP(NORMAL,"IpaAConfSetup:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);



  /* Misc configuration */
  /* Eth UL interface to IP */
#endif
  return 0;
}

/*
 * IpoAConfProcess
 *  Ip over ATM link processing
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG IpoAConfProcess(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  return 0;
}

/*
 * MpoaAtmConfOpen
 *  Specific openings for ethernet over ATM interfaces
 *
 *  Args:
 *   pxIfConf           interface conf structure
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG MpoaAtmConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_MPOA(pxIfState);
  NETMAIN_ASSERT((pxNetConf != NULL)
                 && (pxNetConf->eState == NETCONFSTATE_SETUP));

  /* Open AAL5 driver and configure AAL5 & MPOA */
  _OpenConfigMpoaConnection(pxIfConf);

  NetConfOpen(pxNetConf);


  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_OPENED);

  return 0;
}
/*
 * IpoAConfOpen
 *  Specific openings for Ip over ATM interfaces
 *
 *  Args:
 *   pxIfConf           interface conf structure
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG IpoAConfOpen(NETIFCONF *pxIfConf,OCTET oIfIdx)
{
  return 0;
}
/*
 * MpoaAtmConfProcess
 *  ethernet over ATM link processing
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx                Interface index
 *
 *  Return:
 *   0
 */
LONG MpoaAtmConfProcess(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  return 0;
}
/*
 * MpoaConfClose
 *  Ethernet over ATM specific if close
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx             Interface index
 *
 *  Return 0
 */
LONG MpoaConfClose(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;
  H_NETINSTANCE hEthInst,hMpoaInst;

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_MPOA(pxIfState);
  NETMAIN_ASSERT((pxNetConf != NULL) &&
                 (pxNetConf->eState == NETCONFSTATE_OPENED));

  hEthInst  = NETGETINST_ETH;
  hMpoaInst = NETGETINST_MPOA(pxIfState);

  /* Close all instances & interfaces */
  NetConfClose(pxNetConf);

  /* Clsoe the driver - free AAL5 buffer */
  _CloseMpoaConnection(pxIfConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_CLOSED);

  return 0;
}

/*
 * IpoAConfClose
 *  Ip over ATM specific if close
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx             Interface index
 *
 *  Return 0
 */
LONG IpoAConfClose(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  return 0;
}

/*
 * MpoaAtmConfDestroy
 *  Ethernet over ATM specific if destroy
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG MpoaConfDestroy(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;
  H_NETINSTANCE hMpoaInst;

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_MPOA(pxIfState);
  NETMAIN_ASSERT((pxNetConf != NULL) &&
                 (pxNetConf->eState == NETCONFSTATE_SETUP));

  hMpoaInst = NETGETINST_MPOA(pxIfState);

  /* Setup all instances */
  NetConfTearDown(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_INIT);

  return 0;
}

/*
 * IpoAConfDestroy
 *  Ip over ATM specific if destroy
 *
 *  Args:
 *   pxIfConf           Interface conf structue
 *   oIfIdx             Interface index
 *
 *  Return:
 *   0
 */
LONG IpoAConfDestroy(NETIFCONF *pxIfConf, OCTET oIfIdx)
{
  return 0;
}


/****************************************************************************
 *
 * LONG MpoaLinkSetup(NETIFCONF *pxIfConf,OCTET oIfIdx)
 *
 ***************************************************************************/

LONG MpoaLinkSetup(NETIFCONF *pxIfConf,OCTET oIfIdx)
{
  NETIFSTATE *pxIfState;
  NETCONF *pxNetConf;
  H_NETINSTANCE hMpoaInst;
  H_NETINTERFACE hMpoaUlIf,hMpoaLlIf;

  NETMAIN_ASSERT((pxIfConf != NULL) && (pxIfConf->ePhyLinkType == ATM));

  NETMAIN_DBGP(NORMAL,"MpoaLinkSetup:pxIfConf=0x%p,oIfIdx=%d\n",
                       pxIfConf,oIfIdx);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  pxNetConf = NETGETNETCONF_MPOA(pxIfState);
  NETMAIN_ASSERT(pxNetConf != NULL);

  pxNetConf->eState = NETCONFSTATE_INIT;
  pxNetConf->ppxLibTemplate = apxMpoaLibTemplate;
  pxNetConf->dwLibNum = 1;

  /*
   * Allocate the pxLib, instances & all
   */
  /* Setup all instances */
  NetConfSetup(pxNetConf);

  NETMAIN_ASSERT(pxNetConf->eState == NETCONFSTATE_SETUP);

  LibConfSetOffsetAndTrailer(pxNetConf,NETRXOFFSET,NETRXTRAILER);

  hMpoaInst = NETGETINST_MPOA(pxIfState);
  hMpoaUlIf = NETGETIF_MPOAUL(pxIfState);
  hMpoaLlIf = NETGETIF_MPOALL(pxIfState);

  pxIfState->hBottomLinkInst = hMpoaInst;
  pxIfState->hBottomLinkIf   = hMpoaLlIf;
  pxIfState->pfnBottomLinkRxCbk = MpoaInstanceRcv;
  pxIfState->pfnBottomLinkLlIfIoctl = MpoaInstanceLLInterfaceIoctl;

  pxIfConf->iFd = -1; /* not yet set - on open */

  /* OpenConfigMpoaConnection() called from Open routine */
  /*OpenConfigMpoaConnection(hMpoaInst); */

  return 0;
}


/****************************************************************************
 *
 * LONG EthoAPlumbing(NETIFCONF *pxIfConf)
 *
 ***************************************************************************/

LONG EthoAPlumbing(NETIFCONF *pxIfConf)
{
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hMpoaInst,hEthInst;
  H_NETINTERFACE hMpoaUlIf,hEthLlIf;

  NETMAIN_DBGP(NORMAL,"EthoAPlumbing:pxIfConf=0x%p\n",pxIfConf);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  hEthInst  = NETGETINST_ETH;
  hMpoaInst = NETGETINST_MPOA(pxIfState);
  hEthLlIf  = NETGETIF_ETHLL(pxIfState);
  hMpoaUlIf = NETGETIF_MPOAUL(pxIfState);

  EthInstanceLLInterfaceIoctl(hEthInst,hEthLlIf,NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hMpoaInst);
  EthInstanceLLInterfaceIoctl(hEthInst,hEthLlIf,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hMpoaUlIf);
  EthInstanceLLInterfaceIoctl(hEthInst,hEthLlIf,NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)MpoaInstanceWrite);

  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                               NETINTERFACEIOCTL_SETHINST,(H_NETDATA)hEthInst);
  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                               NETINTERFACEIOCTL_SETIF,
                               (H_NETDATA)hEthLlIf);
  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                               NETINTERFACEIOCTL_SETOUTPUTPFN,
                               (H_NETDATA)EthInstanceRcv);


  return 0;
}

/****************************************************************************
 *
 * LONG PppoEoAPlumbing(NETIFCONF *pxIfConf)
 *
 ***************************************************************************/

LONG PppoEoAPlumbing(NETIFCONF *pxIfConf)
{
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hMpoaInst,hEthInst,hPppoEInst,hPppInst;
  H_NETINTERFACE hMpoaUlIf,hEthLlIf,hPppoEUlIf,hPppLlIf;

  NETMAIN_DBGP(NORMAL,"PppoEoAPlumbing:pxIfConf=0x%p\n",pxIfConf);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  hEthInst   = NETGETINST_ETH;
  hMpoaInst  = NETGETINST_MPOA(pxIfState);
  hPppoEInst = NETGETINST_PPPOE(pxIfState);
  hPppInst   = NETGETINST_PPP(pxIfState);

  hEthLlIf   = NETGETIF_ETHLL(pxIfState);
  hMpoaUlIf  = NETGETIF_MPOAUL(pxIfState);
  hPppoEUlIf = NETGETIF_PPPOEUL(pxIfState);
  hPppLlIf   = NETGETIF_PPPLL(pxIfState);

  PppInstanceLLInterfaceIoctl(hPppInst,hPppLlIf,NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hPppoEInst);
  PppInstanceLLInterfaceIoctl(hPppInst,hPppLlIf,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hPppoEUlIf);
  PppInstanceLLInterfaceIoctl(hPppInst,hPppLlIf,NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)PppoEClientInstanceWrite);

  PppoEClientInstanceULInterfaceIoctl(hPppoEInst,hPppoEUlIf,NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hPppInst);
  PppoEClientInstanceULInterfaceIoctl(hPppoEInst,hPppoEUlIf,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hPppLlIf);
  PppoEClientInstanceULInterfaceIoctl(hPppoEInst,hPppoEUlIf,NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)PppInstanceRcv);

  EthInstanceLLInterfaceIoctl(hEthInst,hEthLlIf,NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hMpoaInst);
  EthInstanceLLInterfaceIoctl(hEthInst,hEthLlIf,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hMpoaUlIf);
  EthInstanceLLInterfaceIoctl(hEthInst,hEthLlIf,NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)MpoaInstanceWrite);

  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                                 NETINTERFACEIOCTL_SETHINST,(H_NETDATA)hEthInst);
  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                                 NETINTERFACEIOCTL_SETIF,
                                 (H_NETDATA)hEthLlIf);
  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                                 NETINTERFACEIOCTL_SETOUTPUTPFN,
                                 (H_NETDATA)EthInstanceRcv);


  return 0;
}

/****************************************************************************
 *
 * LONG PppoAPlumbing(NETIFCONF *pxIfConf)
 *
 ***************************************************************************/

LONG PppoAPlumbing(NETIFCONF *pxIfConf)
{
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hMpoaInst,hPppInst;
  H_NETINTERFACE hMpoaUlIf,hPppLlIf;

  NETMAIN_DBGP(NORMAL,"PppoAPlumbing:pxIfConf=0x%p\n",pxIfConf);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  hMpoaInst  = NETGETINST_MPOA(pxIfState);
  hPppInst   = NETGETINST_PPP(pxIfState);

  hMpoaUlIf  = NETGETIF_MPOAUL(pxIfState);
  hPppLlIf   = NETGETIF_PPPLL(pxIfState);

  PppInstanceLLInterfaceIoctl(hPppInst,hPppLlIf,NETINTERFACEIOCTL_SETHINST,
                              (H_NETDATA)hMpoaInst);
  PppInstanceLLInterfaceIoctl(hPppInst,hPppLlIf,NETINTERFACEIOCTL_SETIF,
                              (H_NETDATA)hMpoaUlIf);
  PppInstanceLLInterfaceIoctl(hPppInst,hPppLlIf,NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)MpoaInstanceWrite);

  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                               NETINTERFACEIOCTL_SETHINST,(H_NETDATA)hPppInst);
  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                               NETINTERFACEIOCTL_SETIF,
                               (H_NETDATA)hPppLlIf);
  MpoaInstanceULInterfaceIoctl(hMpoaInst,hMpoaUlIf,
                               NETINTERFACEIOCTL_SETOUTPUTPFN,
                               (H_NETDATA)PppInstanceRcv);


  return 0;
}

/****************************************************************************
 *
 * LONG IpoAPlumbing(NETIFCONF *pxIfConf)
 *
 ***************************************************************************/

LONG IpoAPlumbing(NETIFCONF *pxIfConf)
{
  NETIFSTATE *pxIfState;
  H_NETINSTANCE hMpoaInst;
  H_NETINTERFACE hMpoaUlIf;

  NETMAIN_DBGP(NORMAL,"IpoAPlumbing:pxIfConf=0x%p\n",pxIfConf);

  pxIfState = NETGETIFSTATE(pxIfConf);
  NETMAIN_ASSERT(pxIfState != NULL);

  hMpoaInst   = NETGETINST_MPOA(pxIfState);
  hMpoaUlIf   = NETGETIF_MPOAUL(pxIfState);

  pxIfState->hTopLinkInst        = hMpoaInst;
  pxIfState->hTopLinkIf          = hMpoaUlIf;
  pxIfState->pfnTopLinkWrite     = MpoaInstanceWrite;
  pxIfState->pfnTopLinkUlIfIoctl = MpoaInstanceULInterfaceIoctl;

  return 0;
}
