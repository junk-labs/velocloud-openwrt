/*
 * eap_client_tls.c
 *
 * EAP TLS PEER
 * This code should work fine for Linux, Windows and VxWorks
 *
 * Copyright Mocana Corp 2003-2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/* Add to your makefile */
#include "../common/moptions.h"


#include "../common/mtypes.h"
#include "../common/mocana.h"
#include "../crypto/hw_accel.h"

#if (((defined(__ENABLE_MOCANA_EAP_PEER__) || defined(__ENABLE_MOCANA_EAP_AUTH__))) && (defined(__ENABLE_MOCANA_EAP_TLS__)))

#if defined( __ENABLE_MOCANA_SSL_ASYNC_CLIENT_API__ )

#include "../common/mdefs.h"
#include "../common/merrors.h"
#include "../common/mstdlib.h"
#include "../common/mrtos.h"
//#include "../common/vlong.h"
#include "../common/debug_console.h"
#include "../crypto/crypto.h"
#include "../crypto/ca_mgmt.h"
#include "../ssl/ssl.h"
#include "../eap/eap.h"
#include "../eap/eap_proto.h"
#include "../eap/eap_md5.h"
#include "../eap/eap_mschapv2.h"
#include "../eap/eap_tls.h"
#include "eaptls_defs.h"

#ifdef __RTOS_WIN32__
#include <windows.h>
#include <winbase.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <direct.h>
#include <fcntl.h>
#include <io.h>
#include <errno.h>
#endif

#ifdef __RTOS_VXWORKS__
#include <vxWorks.h>
#include <dirent.h>
#include <stat.h>
#endif

#ifdef __RTOS_LINUX__
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#endif

#ifdef __RTOS_OSX__
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>


/*------------------------------------------------------------------*/

extern void CA_MGMT_EXAMPLE_initUpcalls(void);
extern sbyte4  CA_MGMT_EXAMPLE_computeHostKeys(certDescriptor *pCert);
extern sbyte4  CA_MGMT_EXAMPLE_releaseHostKeys(certDescriptor *pCert);


/*------------------------------------------------------------------*/


#define MACFMT "%02x:%02x:%02x:%02x:%02x:%02x"
#define MACPRINT(x) (x)[0],(x)[1],(x)[2],(x)[3],(x)[4],(x)[5]



/*------------------------------------------------------------------*/

/*------------------------------------------------------------------*/


/*------------------------------------------------------------------*/


extern MSTATUS
EAP_ulReceivePktCallback(ubyte*         app_session_handle,
                         eapMethodType  method_type,
                         eapCode        code,
                         ubyte          id,
                         ubyte*         eap_data,
                         ubyte4         eap_data_len,
                         ubyte*         opaque_data);

extern MSTATUS
EAP_llTransmitPktCallback(ubyte*    appSessionHdl,
                          eapHdr_t* eap_hdr,
                          ubyte*    eap_data,
                          ubyte4    eap_data_len);

/*------------------------------------------------------------------*/

extern MSTATUS
EAP_UL_receiveIndication(ubyte* appSessionHdl,
                         eapIndication ind_type,
                         ubyte* data,
                         ubyte4 data_len)
{
    EAPTLSCLIENTSTATE *pxEapTlsClient = (EAPTLSCLIENTSTATE *)appSessionHdl;
    printf("Received Indication %d\n",ind_type);
    switch (ind_type) {
        default:
        pxEapTlsClient->eState = EAPTLSCLIENTSTATE_DOWN;
        pxEapTlsClient->pfnNetCbk(pxEapTlsClient->hNetCbk,NETCBK_TLD,(H_NETDATA)0);
    }
    return OK;
}


/*------------------------------------------------------------------*/


/*------------------------------------------------------------------*/

extern MSTATUS
EAP_UL_getMethodState(ubyte*  app_session_handle,
                      ubyte4* methodState)
{
    return OK;
}


/*------------------------------------------------------------------*/

extern MSTATUS EAP_UL_getDecision(ubyte*  app_session_handle,
                                  ubyte4* decision)
{
    return OK;
}


/*------------------------------------------------------------------*/

/*------------------------------------------------------------------*/

extern MSTATUS
EAPTLS_initSession(EAPTLSCLIENTSTATE *pxEapTlsClient)
{
    MSTATUS status = OK;
    sbyte4 result = -1;
    eapMethodDef_t methodDef;
    eapSessionConfig_t sessionConfig;
    ubyte *sessionHdl = NULL;

        /* Peer session */
    if (NULL == pxEapTlsClient->eapSessionHdl)
    {
            /* create a new session */
        MOC_MEMSET((ubyte *)&methodDef, 0, sizeof(eapMethodDef_t));
        methodDef.method_type = EAP_TYPE_NONE;
        methodDef.funcPtr_ulReceiveCallback =  EAP_ulReceivePktCallback;
        methodDef.funcPtr_llTransmitPacket =  EAP_llTransmitPktCallback;
        methodDef.funcPtr_ulReceiveIndication =  EAP_UL_receiveIndication;
        sessionConfig.eap_mtu = EAP_TLS_MTU;
        sessionConfig.eap_ul_timeout = EAP_TLS_SESSION_TIMEOUT;
        sessionConfig.eap_retrans_timeout = 0;
        sessionConfig.eap_max_retrans = 0;
        sessionConfig.sessionType =EAP_SESSION_TYPE_PEER;
        if (OK > (status = EAP_sessionCreate((ubyte *)pxEapTlsClient,
                                  pxEapTlsClient->instanceId,
                                  methodDef,
                                  sessionConfig,
                                  &pxEapTlsClient->eapSessionHdl)))
        {
            goto exit;
        }

        status = EAP_sessionEnable(pxEapTlsClient->eapSessionHdl,
                                   pxEapTlsClient->instanceId);
    }

exit:
    return status ;
}

/*------------------------------------------------------------------*/

/*------------------------------------------------------------------*/

static void
EAPTLS_initAllowedMethod(EAPTLSCLIENTSTATE *pxEapTlsClient)
{
    pxEapTlsClient->allowed_methods[0] = EAP_TYPE_TLS;
    pxEapTlsClient->allowed_method_count = 1;
}


/*------------------------------------------------------------------*/


static void
openStateClientUpcall1(sbyte4 connectionInstance)
{
    sbyte    pageName[] = "a";
    sbyte    buffer[38];
    sbyte4     bytesSent;

    printf("openStateClientUpcall: secure connection established! connectionInstance = %d\n", connectionInstance);

   /* appCB.tlsOpen = 1; */
    sprintf(buffer, "GET /%s HTTP/1.0\r\n\r\n", pageName);

/*****
    if (0 > SSL_EXAMPLE_sendMessage(connectionInstance, buffer, strlen(buffer)))
    {
        printf("openStateClientUpcall: SSL_EXAMPLE_sendMessage() failed.\n");
    }
****/
}

static void
startTimerClientUpcall(sbyte4 connectionInstance, ubyte4 msTimerExpire, sbyte4 future)
{
}




/*------------------------------------------------------------------*/
static void
receiveClientUpCall(sbyte4 connectionInstance, ubyte *pData, ubyte4 dataLen)
{
    MOC_UNUSED(connectionInstance);
    MOC_UNUSED(pData);

    /* this is a really dumb down example, but still a good proof of concept */
    if (0 < dataLen)
    {
        printf("receiveClientUpCall: TLS client received %d bytes.\n", dataLen);
    }
}

static certDescriptor  sslCert;

extern MSTATUS
EAPTLS_init(EAPTLSCLIENTSTATE *pxEapTlsClient)
{
    MSTATUS status = OK;
    ubyte4 instId;

    DEBUG_PRINTNL(DEBUG_EAP_MESSAGE, "EATLS_init: starting up.");


    if (OK > (status = EAP_init()))
    {
        DEBUG_ERROR(DEBUG_EAP_MESSAGE, "EAP Init Failed, status = ", status);
        goto exit;
    }

    if (OK > (status = EAP_initInstance(&instId)))
    {
        DEBUG_ERROR(DEBUG_EAP_MESSAGE, "EAP Instance Create Failed, status = ", status);
        goto exit;
    }

    pxEapTlsClient->instanceId = instId;
    EAPTLS_initAllowedMethod(pxEapTlsClient);


    if (0 > (status = CA_MGMT_computeHostKeys(&sslCert)))
        goto exit;

    if (0 > (status = SSL_ASYNC_init(MAX_SSL_CONNECTIONS_ALLOWED, MAX_SSL_CONNECTIONS_ALLOWED)))
        goto exit;

    CA_MGMT_initUpcalls();

    /* change default settings here */
    SSL_sslSettings()->funcPtrClientOpenStateUpcall     = openStateClientUpcall1;
    SSL_sslSettings()->funcPtrClientReceiveUpcall       = receiveClientUpCall;
    SSL_sslSettings()->funcPtrClientStartTimer          = startTimerClientUpcall;


#ifdef __ENABLE_MOCANA_SSL_PSK_SUPPORT__
    /* server side specific callbacks */
    SSL_sslSettings()->funcPtrGetHintPSK                = SSL_LOOPBACK_EXAMPLE_funcPtrGetHintPSK;
    SSL_sslSettings()->funcPtrLookupPSK                 = SSL_LOOPBACK_EXAMPLE_funcPtrLookupPSK;

    /* client side specific callback */
    SSL_sslSettings()->funcPtrChosePSK                  = SSL_LOOPBACK_EXAMPLE_funcPtrChosePSK;
#endif


#if 0
    while (1)
    {
       EAP_checkTimers();
       sleep(1);
    }

#endif
exit:

    return;
}


/*------------------------------------------------------------------*/

extern sbyte4
EAP_ulReceivePktCallback(ubyte *appSessionHdl,
                         eapMethodType type,
                         eapCode code, ubyte id,
                         ubyte *data, ubyte4 len,
                         ubyte *opaque_data)
{
    MSTATUS status = OK;
    ubyte *eapResponse = NULL, *temp_eapResponse = NULL;
    ubyte4 eapRespLen = 0, temp_eapRespLen = 0, sendResponse =0;
    ubyte freebuffer = 0;
    EAPTLSCLIENTSTATE *pxEapTlsClient = (EAPTLSCLIENTSTATE *)appSessionHdl;
    byteBoolean cmp;
    eapMethodType methodType = 0;
    eapMethodState methodState = EAP_METHOD_STATE_INIT;
    eapMethodDecision decision = EAP_METHOD_DECISION_NONE;
    ubyte4 expVendorId= 0,expMethodId=0;
    eapMethodDef_t methodDef;
    eapSessionConfig_t sessionConfig;
    ubyte4 modifiedFlag = 0;

    switch(code)
    {
        case EAP_CODE_REQUEST :
        status = OK;
        break;

        case EAP_CODE_RESPONSE :
        status = ERR_EAP_INVALID_CODE;
        DEBUG_ERROR(DEBUG_EAP_MESSAGE,"Invalid EAP Code",status);
        break;

        case EAP_CODE_SUCCESS :
            pxEapTlsClient->eState = EAPTLSCLIENTSTATE_UP;
            pxEapTlsClient->pfnNetCbk(pxEapTlsClient->hNetCbk,NETCBK_TLU,(H_NETDATA)0);
            goto exit;

        case EAP_CODE_FAILURE :
            pxEapTlsClient->eState = EAPTLSCLIENTSTATE_DOWN;
            pxEapTlsClient->pfnNetCbk(pxEapTlsClient->hNetCbk,NETCBK_TLD,(H_NETDATA)0);
            status = OK;
            goto exit;
    }

    if (EAP_CODE_RESPONSE == code|| OK != status )
        goto exit;

    switch(type)
    {
        case EAP_TYPE_NONE :
        /* set error code */
        status = ERR_EAP_INVALID_METHOD_TYPE;
        break;

        case EAP_TYPE_IDENTITY :
        /* Build IDENTITY response */
        methodType =  EAP_TYPE_IDENTITY;
        eapRespLen = pxEapTlsClient->oNameLength;
        eapResponse = (ubyte *) MALLOC(eapRespLen);
        if (NULL == eapResponse)
        {
            status = ERR_MEM_ALLOC_FAIL;
            goto exit;
        }
        MOC_MEMCPY(eapResponse, pxEapTlsClient->poName, eapRespLen);
        methodState = EAP_METHOD_STATE_CONT;
        decision = EAP_METHOD_DECISION_FAIL;
        sendResponse = 1;
        freebuffer = 1;
        break;

        case EAP_TYPE_NOTIFICATION :
        /* Log msg */
        methodType = EAP_TYPE_NOTIFICATION;
        break;

#if defined(__ENABLE_MOCANA_EAP_PEER__)
        case EAP_TYPE_TLS :
         if (pxEapTlsClient->tlsState )
         {

            if (2 !=len)
            {
                printf("Error in the message. Expecting Start Msg \n");
                break;
            }

            if (*(data+1) != EAP_TLS_START_FLAG)
            {
                printf("Error in the message. Expecting Start Msg \n");
                break;
            }

            status = EAP_TLSPeerStart (appSessionHdl,&pxEapTlsClient->tls_connection,
                  (ubyte4 *)&pxEapTlsClient->sessionIdLen,
                  pxEapTlsClient->sessionId, pxEapTlsClient->masterSecret,"sslexample.mocana.com",
          0,0,0,0,0,0,0, /* RS TBD: port to new EAP */
                  &eapResponse, &eapRespLen);
            if (OK == status)
            {
                methodType = EAP_TYPE_TLS;
                methodState = EAP_METHOD_STATE_CONT;
                decision = EAP_METHOD_DECISION_FAIL;
                sendResponse = 1;
                freebuffer = 1;
                pxEapTlsClient->tlsState = 1;
            }
        }
        else
        {
            status = EAP_TLSProcessMsg (appSessionHdl,pxEapTlsClient->tls_connection,
                  data,len,
                  &eapResponse, &eapRespLen);
            if (OK == status)
            {
                ubyte4 sessionStatus;
                methodType = EAP_TYPE_TLS;

                status = EAP_TLSgetSessionStatus (appSessionHdl,pxEapTlsClient->tls_connection,&sessionStatus);
                if ((OK == status ) && (SSL_CONNECTION_OPEN == sessionStatus))
                {
                   pxEapTlsClient->tlsOpen = 1;
                   status = EAP_TLSgetClientSessionInfo (appSessionHdl,
                                              pxEapTlsClient->tls_connection,
                                              (ubyte4 *)&pxEapTlsClient->sessionIdLen,
                                              pxEapTlsClient->sessionId,
                                              pxEapTlsClient->masterSecret );
                   if ( OK == status)
                       printf("Session Id Len is %X\n",(ubyte4) pxEapTlsClient->sessionIdLen);
                }
                if (!(pxEapTlsClient->tlsOpen))
                {
                    decision = EAP_METHOD_DECISION_FAIL;
                    methodState = EAP_METHOD_STATE_CONT;
                }
                else
                {
                    methodState = EAP_METHOD_STATE_DONE;
                    decision = EAP_METHOD_DECISION_UNCOND_SUCC;
                }
                sendResponse = 1;
                freebuffer = 1;
                pxEapTlsClient->tlsState = 1;
            }

        }
        break;
        default :
        /* send NAK response */
        status = EAP_buildNAK(pxEapTlsClient->eapSessionHdl,
                              pxEapTlsClient->instanceId,
                              (ubyte *)pxEapTlsClient->allowed_methods,
                              pxEapTlsClient->allowed_method_count,
                              &eapResponse,
                              &eapRespLen);
        if (OK == status)
        {
            methodType = EAP_TYPE_NAK;
            decision = EAP_METHOD_DECISION_FAIL;
            sendResponse = 1;
            freebuffer = 1;
        }
        break;
#endif
    }
    if (sendResponse)
    {
        status = EAP_ulTransmit(pxEapTlsClient->eapSessionHdl,
                                 pxEapTlsClient->instanceId,
                                 methodType, EAP_CODE_RESPONSE,
                                 decision, methodState, eapResponse,
                                 eapRespLen);

    }
    if (freebuffer && NULL != eapResponse)
    {
        FREE(eapResponse);
    }
exit:
    return status;
}


/*------------------------------------------------------------------*/

extern  MSTATUS
EAP_llTransmitPktCallback(ubyte*    appSessionHdl,
                          eapHdr_t* eap_hdr,
                          ubyte*    eap_data,
                          ubyte4    eap_data_len)
{
    MSTATUS status = OK;
    status =  EapTlsClientInstanceCreateRspMsg( appSessionHdl,
                                    eap_hdr,eap_data, eap_data_len);

    return status;
}


#endif /*(defined(__ENABLE_MOCANA_SSL_ASYNC_SERVER_API__) && defined( __ENABLE_MOCANA_SSL_ASYNC_CLIENT_API__ )) */
#endif /* ((defined(__ENABLE_MOCANA_EAP_PEER__) || defined(__ENABLE_MOCANA_EAP_AUTH__)) */
