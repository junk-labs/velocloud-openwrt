/*
 * meterdbg.h
 *
 * Meter debug defines
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _METERDBG_H_
#define _METERDBG_H_

#ifndef NDEBUG

  #ifdef NETDBG_HI
    #ifndef METERDBG_HI
      #define METERDBG_HI
    #endif
  #endif

#else

  #ifdef METERDBG_HI
    #undef METERDBG_HI
  #endif

#endif

/*
 * Constants
 */
#define METER_MAGIC_COOKIE 0x6D657472 /*"metr" = 0x6D657472*/


/*
 * Debug macros
 */
/*#ifdef METERDBG_HI*/
#if defined(METERDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define METER_DBGP(level, fmt, args...) do { \
    if (level <= g_dwMeterDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define METER_DBG(level, x) do {  \
    if (level <= g_dwMeterDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define METER_DBG_VAR(x)  x

  #define CHECKPOINT(A) A = __LINE__
#else
#if defined (__VXWORKS_RTOS__)
   #define METER_DBGP(level, fmt, args)
#else
  #define METER_DBGP(level, fmt, args...)
#endif
  #define METER_DBG(level, x)
  #define METER_DBG_VAR(x)
  #define CHECKPOINT(A)
#endif

METER_DBG_VAR(MOC_EXTERN DWORD g_dwMeterDebugLevel);

/*
 * Debug levels
 */
#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _METERDBG_H_ */
