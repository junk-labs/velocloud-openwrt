#include "NNstyle.h"
#include "udp_flavor.h"
#include "snmp_tcpip_data.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "netnetwork.h"
#include "../include/in.h"
#include "netutils.h"
#include "nettransport.h"
#include "ecc.h"
#include "udp.h"
#include "udpdefs.h"
#include "udp_dbg.h"

/***************************************************************************
*    called from by SNMP Agent to retrieve an entire Address Entry table
*
*    par:    DWORD *pxUdpEntry - area of memory for placing the Address Entry table
*
*    ret:    DWORD - nos bytes in pValue
****************************************************************************/
DWORD TcpipSnmpGetUdpEntryTable(void **ppvData, DWORD *pdwNosStructs, DWORD *pdwStructSize)
{
  extern UDPSTATE **ppxUdpInstanceList;
  extern OCTET oUdpInstances;
  struct UDP_TABLE_ENTRY  *pxUdpEntry;
  UDPSTATE *pxUdp;
  UDPCONN *pxConn;
  OCTET oCurUdpInst;
  DWORD dwConnectionCnt = 0;

  ASSERT(ppvData != NULL);
  ASSERT(pdwNosStructs != NULL);
  ASSERT(pdwStructSize != NULL);

  /* Find the dimension of the array, and the size of each element */
  *pdwStructSize = sizeof(struct UDP_TABLE_ENTRY);
  *pdwNosStructs = 0;
  for (oCurUdpInst = 0; oCurUdpInst < oUdpInstances; oCurUdpInst++) {
    pxUdp = ppxUdpInstanceList[oCurUdpInst];
    DLLIST_head(&pxUdp->dllConns);
    while ((pxConn = (UDPCONN *) DLLIST_read(&pxUdp->dllConns)) != NULL) {
      (*pdwNosStructs)++;
      DLLIST_next(&pxUdp->dllConns);
    }
  }

  /* Allocate memory for the array (freed by snmp agent) */
  *ppvData = MALLOC((*pdwNosStructs) * (*pdwStructSize));
  ASSERT(*ppvData != NULL);

  /* Fill the array */
  pxUdpEntry = (struct UDP_TABLE_ENTRY *)(*ppvData);
  for (oCurUdpInst = 0; oCurUdpInst < oUdpInstances; oCurUdpInst++) {
    pxUdp = ppxUdpInstanceList[oCurUdpInst];
    DLLIST_head(&pxUdp->dllConns);
    /* ensure connection copies don't exceed malloc'd space */
    while ( ((pxConn = (UDPCONN *) DLLIST_read(&pxUdp->dllConns)) != NULL) &&
            (*pdwNosStructs > dwConnectionCnt) ) {
      dwConnectionCnt++;
      pxUdpEntry->dwIP = pxConn->xId.xNetId.dwSrcIpAddr;
      pxUdpEntry->dwPort = pxConn->xId.wSrcPort;

      pxUdpEntry++;
      DLLIST_next(&pxUdp->dllConns);
    }
  }

  /* if prove to be less connections than predicted initially reduce count reported */
  *pdwNosStructs = dwConnectionCnt;

  return TCPIPSNMPGETDATAOK;
}
