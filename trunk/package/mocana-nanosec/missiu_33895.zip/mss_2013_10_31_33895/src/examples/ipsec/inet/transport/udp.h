/*
 * udp.h
 *
 * UDP module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _UDP_H_
#define _UDP_H_

#include "nettransport.h"

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * UDP wide default
 */
#define UDPDEFAULT_OFFSET          0
#define UDPDEFAULT_TRAILER         0

#define UDPDEFAULT_HDRSIZE         8


/*
 * UDP UL ioctls
 *  o All are covered in netcommon.h (LIBNETCOMMON) and
 *    nettransport.h (LIBNETTRANSPORT), except below
 *  o The RxCbk provided to a UL interface will be passed the TRANSPORT_ID
 *    of the remote end as a OoB data (see PFN_NETRXCBK for def)
 */
/* UDP UL interface ioctls */

#define UDPULINTERFACEIOCTL_TXCHECK \
   NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN         /* enable
                                                               checksum */

#define UDPULINTERFACEIOCTL_MCASTJOIN \
   (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN+1)     /* Multicast join.
                                                               Data is
                                                               IPMCASTREQ * */
#define UDPULINTERFACEIOCTL_MCASTDROP \
   (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN+2)     /* Multicast drop.
                                                               Data is
                                                               IPMCASTREQ * */
#define UDPULINTERFACEIOCTL_MCASTADDR \
   (NETTRANSPORTULINTERFACEIOCTL_MODULESPECIFICBEGIN+3)     /* Multicast
                                                               address.
                                                               Data is DWORD */
/*
 * UDP LL Ioctls
 *  o All are covered in netcommon.h (LIBNETCOMMON) and
 *    nettransport.h (LIBNETTRANSPORT)
 *  o the PFN_NETWRITE provided with
 *    NETINTERFACEIOCTL_SETOUTPUTPFN will be given as hDstId a pointer
 *    to a TRANSPORT2NETWORKID (See nettransport.h for type definition)
 */

/*
 * UDP specific options
 */
#define UDPOPTION_MAX \
  (NETOPTION_MODULESPECIFICBEGIN)

/*
 * UDP specific callbacks
 */
#define   UDPCBK_DSTUNREACHABLE \
  (NETCBK_MODULESPECIFICBEGIN)  /* UDP unreachable. Data is UDP_CBKDATA */

#define UDPCBK_MAX \
  (NETCBK_MODULESPECIFICBEGIN + 1)

#ifdef NEW_ICMP_MSG_ADDED
/*
 * UDP Instance Message options
*/

#define UDPMSG_BEGIN \
          (NETNETWORKMSG_MODULESPECIFICBEGIN)
#define UDPMSG_ICMPERRORS \
          (UDPMSG_BEGIN + 1)
#endif

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * Udp headers (for transportparser).
 */

/*
 * UDP header
 */
typedef struct {
  WORD  wSrcport;
  WORD  wDstport;
  WORD  wLen;
  WORD  wCheck;
} UDPHDR;

/*
 * UDP pseudo-header
 */
typedef struct {
  DWORD  dwSrcIP;
  DWORD  dwDstIP;
  OCTET  oNull;
  OCTET  oProt;
  WORD  wLen;
} UDPPSH;

/*
 * UDP Cbk data definition
 */
typedef struct {
  NETPACKET *pxNetPacket;
  NETPACKETACCESS *pxNetPacketAccess;
  TRANSPORTID xId;
} UDPCBKDATA;

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * UdpInitialize
 *  Initialize the Udp Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG UdpInitialize(void);

/*
 * UdpTerminate
 *  Terminate the UDP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG UdpTerminate(void);

/*
 * UdpInstanceCreate
 *  Creates a UDP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE UdpInstanceCreate(void);

/*
 * UdpInstanceDestroy
 *  Destroy a UDP Instance
 *
 *  Args:
 *   hUdp                       UDP instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG UdpInstanceDestroy(H_NETINSTANCE hUdp);

/*
 * UdpInstanceSet
 *  Set a UDP Instance Option
 *
 *  Args:
 *   hUdp                       UDP instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG UdpInstanceSet(H_NETINSTANCE hUdp,OCTET oOption,
                    H_NETDATA hData);

/*
 * UdpInstanceQuery
 *  Query a UDP Instance Option
 *
 *  Args:
 *   hUdp                       UDP instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG UdpInstanceQuery(H_NETINSTANCE hUdp,OCTET oOption,
                      H_NETDATA *phData);

/*
 * UdpInstanceMsg
 *  Send a msg to a UDP instance
 *
 *  Args:
 *   hUdp                       UDP instance
 *   oMsg                       Msg. See netcommon.h for definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG UdpInstanceMsg(H_NETINSTANCE hUdp,OCTET oMsg,
                    H_NETDATA hData);


/*
 * UdpInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer. It corresponds
 *  to a socket.
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hUdp                       UDP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE UdpInstanceULInterfaceCreate(H_NETINSTANCE hUdp);

/*
 * UdpInstanceULInterfaceDestroy
 *  Destroy a UDP UL interface
 *
 *  Args:
 *   hUdp                       UDP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG UdpInstanceULInterfaceDestroy(H_NETINSTANCE hUdp,
                                   H_NETINTERFACE hInterface);


/*
 * UdpInstanceULInterfaceIoctl
 *  Udp UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and nettransport.h
 *  for precisions
 *
 *  Args:
 *   hUdp                         UDP instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG UdpInstanceULInterfaceIoctl(H_NETINSTANCE hUdp,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData);

/*
 * UdpInstanceWrite
 *  Udp Instance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hUdp                        Udp Instance handle
 *   hIf                         must be the UL interface handle
 *   pxPacket                    Packet pointer
 *   pxAccess                    Access info
 *   hData                       casted UDPID *
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG UdpInstanceWrite(H_NETINSTANCE hUdp,
              H_NETINSTANCE hIf,
              NETPACKET *pxPacket,
              NETPACKETACCESS *pxAccess,
              H_NETDATA hData);

/*
 * UdpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hUdp                       UDP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE UdpInstanceLLInterfaceCreate(H_NETINSTANCE hUdp);

/*
 * UdpInstanceLLInterfaceDestroy
 *  Destroy a UDP LL interface
 *
 *  Args:
 *   hUdp                       UDP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG UdpInstanceLLInterfaceDestroy(H_NETINSTANCE hUdp,
                                   H_NETINTERFACE hInterface);


/*
 * UdpInstanceLLInterfaceIoctl
 *  UDP LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and netransport.h
 *  for precisions
 *
 *  Args:
 *   hUdp                         Udp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG UdpInstanceLLInterfaceIoctl(H_NETINSTANCE hUdp,
                                 H_NETINTERFACE hLLInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData);


/*
 * UdpInstanceRcv
 *  Udp Instance Rcv function
 *   Udp Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hUdp                        Ud Instance Handle
 *    hIf                         Interface handle
 *    pxPacket                    packet
 *    pxAccess                    access info
 *    hData                       must be a pointer to a 64 bits
 *                                field, big-endian, containing in
 *                                the 1st DWORD the source IP address
 *                                and in the 2nd the destination IP address
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG UdpInstanceRcv(H_NETINSTANCE hUdp,
            H_NETINSTANCE hIf,
            NETPACKET *pxPacket,
            NETPACKETACCESS *pxAccess,
            H_NETDATA hData);

#ifndef NDEBUG
/*
 * UdpInstanceProcess
 *  Used to print Connection status whenever needed.
 *  No real processing
 *
 *  Args:
 *   hUdp                        Udp Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 5 ms)
 */
LONG UdpInstanceProcess(H_NETINSTANCE hUdp);
#endif

#endif /* #ifndef _UDP_H_ */







