/*
 * ntpint.h
 *
 * Ntp internal header file. Contains packet structure
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/* macro for filling li_vn_mode */
#define    PKT_LI_VN_MODE(li, vn, md) \
    ((OCTET)((((li) << 6) & 0xc0) | (((vn) << 3) & 0x38) | ((md) & 0x7)))

/*
 * NTP protocol parameters.
 */
#define    NTP_VERSION    ((OCTET)3) /* current version number */
#define    NTP_OLDVERSION    ((OCTET)1) /* oldest credible version */
#define    NTP_PORT    123    /* included for sake of non-unix machines */

/*
 * NTP uses two fixed point formats.  The first (l_fp) is the "long" format
 * and is 64 bits long with the decimal between bits 31 and 32.  This
 * is used for time stamps in the NTP packet header (in network byte
 * order) and for internal computations of offsets (in local host byte
 * order).  We use the same structure for both signed and unsigned values,
 * which is a big hack but saves rewriting all the operators twice.  Just
 * to confuse this, we also sometimes just carry the fractional part in
 * calculations, in both signed and unsigned forms.  Anyway, an l_fp looks
 * like:
 *
 *    0              1              2              3
 *    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *   |                   Integral Part                 |
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *   |                   Fractional Part                 |
 *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 */
typedef struct {
    DWORD Xl_i;
    DWORD Xl_f;
} l_fp;

/*
 * Values for mode
 */
#define    MODE_UNSPEC    0    /* unspecified (probably old NTP version) */
#define    MODE_ACTIVE    1    /* symmetric active */
#define    MODE_PASSIVE    2    /* symmetric passive */
#define    MODE_CLIENT    3    /* client mode */
#define    MODE_SERVER    4    /* server mode */
#define    MODE_BROADCAST    5    /* broadcast mode */
#define    MODE_CONTROL    6    /* control mode packet */
#define    MODE_PRIVATE    7    /* implementation defined function */

#define    MODE_BCLIENT    8    /* a pseudo mode, used internally */
#define MODE_MCLIENT    9    /* multicast mode, used internally */

typedef struct _tagNtpPacket {
    OCTET li_vn_mode;        /* contains leap indicator, version and mode */
    OCTET stratum;        /* peer's stratum */
    OCTET ppoll;        /* the peer polling interval */
    CHAR  precision;        /* peer clock precision */
    LONG  rootdelay;        /* distance to primary clock */
    DWORD rootdispersion;    /* clock dispersion */
    DWORD refid;        /* reference clock ID */
    l_fp reftime;        /* time peer clock was last updated */
    l_fp org;            /* originate time stamp */
    l_fp rec;            /* receive time stamp */
    l_fp xmt;            /* transmit time stamp */
} NtpPacket;

#define NTP_PKT_LEN sizeof(NtpPacket)

/* NTP Query states */
typedef enum
{
    NTP_START,
    NTP_SEND,
    NTP_WAIT_FOR_REPLY,
    NTP_DONE,
    NTP_RESYNC
} NtpState;

#define NTP_BUFFER_MAX NTP_PKT_LEN


