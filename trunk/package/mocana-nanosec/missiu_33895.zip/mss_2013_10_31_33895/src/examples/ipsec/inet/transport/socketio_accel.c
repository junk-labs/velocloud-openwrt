/*
 * socketio_accel.c
 *
 * Socket IO functions to go into internal memory
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#ifdef __TCP_USE_SEGMENTS__
#include "../include/netsegment.h"
#endif
#include "mqueue.h"
#include "nettime.h"
#include "netmain.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "nettransport.h"
#include "netnetwork.h"
#include "netnetwork.h"
#include "ip.h"
#include "udp.h"
#include "tcp.h"
#include "netdefs.h"
#include "routing_table.h"
#include "iptable.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#ifdef IPSEC
#include "ipsec.h"
#endif /* IPSEC */

/****************************************************************************
 *
 * DEBUG
 *
 ****************************************************************************/

SOCKET_DBG_VAR(DWORD dbg_dwsendto = 0);

ubyte4
mn_recvfrom_func(int lSockfd, void *pvBuff, ubyte4 nbytes, int Flags,
         struct sockaddr *pxSockAddrFrom, socklen_t *addrlen,
     mn_sock_recv_cb_t pfCb, void *pvCbArg, /* async stuff */
         void **ppvBuff, void **ppFreeArg,ubyte *ipc_req);
ubyte4 _SocketReadTcp(SOCKET *pxSock, void *pvBuff, ubyte4 nbytes,
                 struct sockaddr *pxSockAddrFrom, socklen_t *addrlen,
            void **ppvBuff, void **ppFreeArg);

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * TcpRxCbk
 *  Rx Cbk function provided to a TCP UL interface
 *
 *  Args:
 *   hULInst                   UL instance handle. In fact a socket
 *                             structure pointer
 *   hIf                       unused
 *   pxPacket                  packet pointer
 *   pxAccess                  access info
 *   hData                     cast TRANSPORTID of the remote end
 *
 *  Return:
 *   length accepted or -1 (error)
 */
LONG TcpRxCbk(H_NETINSTANCE hULInst,H_NETINTERFACE hIf,
              NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
              H_NETDATA hData)
{
  SOCKET *pxSock = (SOCKET *)hULInst;
  WORD wLength;

#if 0
  SOCKET_ASSERT((pxPacket != NULL) &&
         (pxPacket->pxPayload != NULL) &&
         (pxPacket->pxPayload->poPayload != NULL));
#endif
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
        DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "TcpRxCbk:pxSock 0x",
            (sbyte4)pxSock,"xCond: 0x", (sbyte4)pxSock);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," locking \n");
    }
#if defined (__RECURSIVE_MUTEX__)
  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
        DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "TcpRxCbk:pxSock  0x",
            (sbyte4)pxSock,", xCond: 0x", (sbyte4)pxSock);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," locked\n");
    }

  SOCKET_CHECK_STATE(pxSock);

  SOCKET_ASSERT((pxSock->u.pxTcp != NULL) &&
                ((pxSock->dwSockOptions & SO_ACCEPTCONN) == 0) &&
                (pxSock->u.pxTcp->u.pxConnect != NULL));

  /* In debug mode: the If must be set to the
     socket id. This should not assert, as a socket must
     be valid if we get here, but extra checks do not hurt :*/
  DEBUG ({
    DWORD dwCurrId = pxSock->dwSocketId;

    SOCKET_CHECKFD(pxSock->lFd);
    if ( ((pxSock = RETRIEVE_SOCKET(pxSock->lFd)) == NULL) ||
         (pxSock->dwSocketId != dwCurrId)) {
      ASSERT(0);
    }
  });

#ifndef __MOCANA_ASYNC_API__
  if ( pxSock->pfRecvCb ){
        struct sockaddr_in pxSockAddrFrom;
        socklen_t addrlen;
        void *pvBuff, *pFreeArg;
      wLength = _SocketReadTcp(pxSock, NULL, 0,
                                (struct sockaddr *)&pxSockAddrFrom, &addrlen,
                &pvBuff, &pFreeArg);
        pxSock->pfRecvCb(pxSock->lFd, pvBuff, wLength,
            (struct sockaddr *)&pxSockAddrFrom,
                        sizeof(pxSockAddrFrom),
            pxSock->pvRecvCbArg , pxSock->dwSockOptions & MN_ZEROCOPY ? pFreeArg : NULL);
        if (!(pxSock->dwSockOptions & MN_ZEROCOPY))
        {
          NETPAYLOAD_CHECK(pFreeArg);
          NETPAYLOAD_DELUSER(pFreeArg);
             /*  mn_sock_free_recvbuf(pFreeArg); */
        }
#if defined (__RECURSIVE_MUTEX__)
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
        /* in async mode, don't wake up recv or select if there are any */
        /* Need to Inform the TCP About the Window Size to Advertize TODO JJ */
    return wLength;
   }
#endif

#ifdef __MOCANA_IPC_LIBSOCK__
  if ( pxSock->ipc_req ){
        struct sockaddr_in pxSockAddrFrom;
        socklen_t addrlen;
        void *pvBuff, *pFreeArg;
      wLength = _SocketReadTcp(pxSock, NULL, 0,
                          (struct sockaddr *)&pxSockAddrFrom, &addrlen,
               &pvBuff, &pFreeArg);
        SOCKSERVER_recvReply(pxSock->ipc_req,pxSock->lFd, pvBuff, wLength,
            &pxSockAddrFrom, sizeof(pxSockAddrFrom));

        pxSock->ipc_req  = NULL;
          /*  mn_sock_free_recvbuf(pFreeArg); */
        NETPAYLOAD_CHECK(pFreeArg);
        NETPAYLOAD_DELUSER(pFreeArg);
#if defined (__RECURSIVE_MUTEX__)
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
        /* in async mode, don't wake up recv or select if there are any */
    return wLength;
  }
#endif

  pthread_cond_signal(&(pxSock->xCond));
  /*pthread_cond_broadcast(&(pxSock->xCond)); */
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
        DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "TcpRxCbk:pxSock 0x",
            (sbyte4)pxSock," xCond:  0x", (sbyte4)pxSock);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," signalled\n");
    }
  /*NetPrintPayload(&(pxSock->xCond), sizeof(pxSock->xCond)); */

  /* If a select has been issued on this socket, wake it up */
  if (pxSock->oSelect > 0) {
    SocketWakeSelect(pxSock,SELECT_RD);
  }

#if defined (__RECURSIVE_MUTEX__)
  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif

  /* Always return 0: the data will be retrieve within
     the recvfrom call */
  return 0;
}


/*
 * UdpRxCbk
 *  Rx Cbk function provided to a UDP UL interface
 *
 *  Args:
 *   hULInst                   UL instance handle. In fact a socket
 *                             structure pointer
 *   hIf                       Unused
 *   pxPacket                  packet pointer
 *   pxAccess                  access info
 *   hData                     Cast UDPID of the remote end
 *
 *  Return:
 *   length accepted or -1 (error)
 */
LONG UdpRxCbk(H_NETINSTANCE hULInst,
              H_NETINTERFACE hIf,
              NETPACKET *pxNetPacket,
              NETPACKETACCESS *pxAccess,
              H_NETDATA hData)
{
  SOCKET *pxSock = (SOCKET *)hULInst;
  WORD wLength = pxAccess->wLength;
  TRANSPORTID *pxId = (TRANSPORTID *)hData;
  int iRv, zero_copy = 0;

  SOCKET_ASSERT((pxNetPacket != NULL) &&
                (pxId != NULL) &&
                (pxNetPacket->pxPayload != NULL) &&
                (pxNetPacket->pxPayload->poPayload != NULL));

#if defined (__RECURSIVE_MUTEX__)
  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif

  SOCKET_CHECK_STATE(pxSock);

  SOCKET_ASSERT(pxSock->u.pxUdp != NULL);

  if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
  {
   DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "UdpRxCbk:hULInst=", (int)hULInst,
      ", oIfIdx=", pxId->xNetId.oIfIdx);
   DEBUG_PRINT(DEBUG_MOC_IPV4,", srcIP:destIP ");
   /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4, pxId->xNetId.dwSrcIpAddr);*/
   DEBUG_INT(DEBUG_MOC_IPV4, pxId->xNetId.dwSrcIpAddr);
   DEBUG_PRINT(DEBUG_MOC_IPV4," : ");
   /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4, pxId->xNetId.dwDstIpAddr);*/
   DEBUG_INT(DEBUG_MOC_IPV4, pxId->xNetId.dwDstIpAddr);
   DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4,"SrcPort=", ntohs(pxId->wSrcPort),
      ",DstPort=", ntohs(pxId->wDstPort));
   DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
  }

 /* In debug mode: the If must be set to the
    socket id. This should not assert, as a socket must
    be valid if we get here, but extra checks do not hurt :*/
  SOCKET_DBG(0,{
    DWORD dwCurrId = pxSock->dwSocketId;
    if ( ((pxSock = RETRIEVE_SOCKET(pxSock->lFd)) == NULL) ||
         (pxSock->dwSocketId != dwCurrId)) {
      ASSERT(0);
    }
  });

  if ((pxSock->dwSockState & SS_CANTRCVMORE) == 0) {
    UDPSOCKET *pxUdpSocket = pxSock->u.pxUdp;

#ifndef __MOCANA_ASYNC_API__
    if ( pxSock->pfRecvCb ){
      struct sockaddr_in pxSockAddrFrom;
      /* Copy the data over */
#if 0 /* do zero-copy */
      wLength = (pxSock->wAppBufferSize > wLength) ?
            wLength : pxSock->wAppBufferSize;
      MOC_MEMCPY((ubyte *)pxSock->poAppBuffer,
             (ubyte *)(pxNetPacket->pxPayload->poPayload + pxAccess->wOffset), wLength);
#endif

      /* fill in from addr info */
      pxSockAddrFrom.sin_len = sizeof(pxSockAddrFrom);
      pxSockAddrFrom.sin_family = AF_INET;
      pxSockAddrFrom.sin_addr.s_addr = htonl(pxId->xNetId.dwSrcIpAddr);
      pxSockAddrFrom.sin_port = htons(pxId->wSrcPort);

      /* call app cb */
#if 0 /* do zero-copy */
      pxSock->pfRecvCb(pxSock->lFd, pxSock->poAppBuffer, wLength,
            &pxSockAddrFrom, sizeof(pxSockAddrFrom),
            pxSock->pvRecvCbArg);
#else
      pxSock->pfRecvCb(pxSock->lFd,
            pxNetPacket->pxPayload->poPayload + pxAccess->wOffset,
            wLength, (struct sockaddr *)&pxSockAddrFrom,
                        sizeof(pxSockAddrFrom),
            pxSock->pvRecvCbArg, pxSock->dwSockOptions & MN_ZEROCOPY ? pxNetPacket->pxPayload : NULL);
#endif
      if (!(pxSock->dwSockOptions & MN_ZEROCOPY))
      {
          NETPAYLOAD_CHECK(pxNetPacket->pxPayload);
          NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
      }

#if defined (__RECURSIVE_MUTEX__)
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif

      /* in async mode, don't wake up recv or select if there are any */
      return wLength;

    }else
#endif /* __MOCANA_ASYNC_API__*/
#ifdef __MOCANA_IPC_LIBSOCK__
  if ( pxSock->ipc_req ){
      struct sockaddr_in pxSockAddrFrom;
      /* fill in from addr info */
      pxSockAddrFrom.sin_len = sizeof(pxSockAddrFrom);
      pxSockAddrFrom.sin_family = AF_INET;
      pxSockAddrFrom.sin_addr.s_addr = pxId->xNetId.dwSrcIpAddr;
      pxSockAddrFrom.sin_port = pxId->wSrcPort;

      SOCKSERVER_recvReply(pxSock->ipc_req,pxSock->lFd,
               pxNetPacket->pxPayload->poPayload + pxAccess->wOffset,
               wLength, &pxSockAddrFrom, sizeof(pxSockAddrFrom));
      NETPAYLOAD_CHECK(pxNetPacket->pxPayload);
      NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
      pxSock->ipc_req = NULL;

#if defined (__RECURSIVE_MUTEX__)
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif

      /* in async mode, don't wake up recv or select if there are any */
      return wLength;
  }
#endif
    if ((pxSock->ppoAppBuffer != NULL) &&
        (pxSock->wAppBufferUsedLength == 0)) {
      /* The app provided a ptr to buffer and it has not been used yet :
         use it */
      pxSock->wAppBufferUsedLength = wLength;
      /* save the ptr */
      *(pxSock->ppoAppBuffer) = pxNetPacket->pxPayload->poPayload +
                pxAccess->wOffset;
      *(pxSock->ppFreeArg) = pxNetPacket->pxPayload;
      /* Copy the transport id */
      MOC_MEMCPY((ubyte *)&(pxUdpSocket->xRxTransportId),(ubyte *)pxId,sizeof(TRANSPORTID));
      zero_copy = 1;
    }else
    if ((pxSock->poAppBuffer != NULL) &&
        (pxSock->wAppBufferUsedLength == 0)) {
      /* The app provided a buffer and it has not been used yet :
         use it */
      pxSock->wAppBufferUsedLength = (pxSock->wAppBufferSize > wLength) ?
        wLength : pxSock->wAppBufferSize;
      /* Copy the data over */
      MOC_MEMCPY((ubyte *)pxSock->poAppBuffer,
             (ubyte *)(pxNetPacket->pxPayload->poPayload + pxAccess->wOffset),
             pxSock->wAppBufferUsedLength);
      /* Copy the transport id */
      MOC_MEMCPY((ubyte *)&(pxUdpSocket->xRxTransportId),(ubyte *)pxId,sizeof(TRANSPORTID));
    }
    else if ((pxUdpSocket->wBufferedLength + wLength) < UDP_MAX_BUFFER) {
      /* No room in app buffer, but there is still some buffering space */
      UDPPACKET *pxUdpPacket;

      /* Allocate the packet with the data in-line */
      pxUdpPacket = (UDPPACKET *)MALLOC(sizeof(UDPPACKET) + wLength);
      ASSERT(pxUdpPacket != NULL);
      MOC_MEMSET((ubyte *)pxUdpPacket, 0, sizeof(UDPPACKET) + wLength);

      /* copy the transport id */
      MOC_MEMCPY((ubyte *)&(pxUdpPacket->xId),(ubyte *)pxId,sizeof(TRANSPORTID));

      pxUdpPacket->wLength = wLength;
#if 0 /* zero-copy */
      pxUdpPacket->poPayload = ((OCTET *)pxUdpPacket) + sizeof(UDPPACKET);
      MOC_MEMCPY((ubyte *)pxUdpPacket->poPayload,
             (ubyte *)(pxNetPacket->pxPayload->poPayload + pxAccess->wOffset),
             wLength);
#else
      pxUdpPacket->pxPayload = pxNetPacket->pxPayload;
      pxUdpPacket->wOffset = pxAccess->wOffset;
      zero_copy = 1;
#endif /* if 0 */

      pxUdpSocket->wBufferedLength += wLength;
      ASSERT(pxUdpSocket->wBufferedLength <= UDP_MAX_BUFFER);

      DLLIST_append(pxUdpSocket->pDllPackets,pxUdpPacket);

    }
  }
  if ( ! zero_copy ){
      NETPAYLOAD_CHECK(pxNetPacket->pxPayload);
      NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
  }

  if ((pxSock->dwSockState & SS_NBIO) == 0){
    /* This socket is a blocking socket wake up the thread */
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
        /* This socket is a blocking socket wake up the thread */
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "UdpRxCbk: wait up the sleeping thread\n");
    }
    /* JJ TODO We have to check whteher we havea waiting IPC Message */
    if ( pxSock->ipc_req ){

    }
    iRv = pthread_cond_signal(&(pxSock->xCond));
    ASSERT(iRv == 0);
  }

  /* If a select has been issued on this socket, wake it up */
  if (pxSock->oSelect > 0) {
    SocketWakeSelect(pxSock,SELECT_RD);
  }

#if defined (__RECURSIVE_MUTEX__)
  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif

  return wLength;
}

/*
 * SocketGetRxDataLength
 *  Query the amount of available Rx data
 *
 *  Args:
 *   pxSock             Socket structure pointer
 *
 *  Return:
 *   WORD               amount of available Rx data
 */
WORD SocketGetRxDataLength(SOCKET *pxSock)
{
  WORD wRxLength=0;

  if (pxSock->lType == SOCK_STREAM) {
    TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                                pxSock->hLL,
                                TCPULINTERFACEIOCTL_GETRXDATALENGTH,
                                (H_NETDATA)
                                &wRxLength);
  }
  else {
    wRxLength = pxSock->wAppBufferUsedLength;
    if (wRxLength == 0) {
      wRxLength = pxSock->u.pxUdp->wBufferedLength;
    }
  }

  return wRxLength;
}
/*
 * recvfrom
 *  Used to receive a message.
 *  Async operation is always zero-copy.
 *
 * Args:
 *  lSockfd          The socket returned by the socket function.
 *  pvBuff           The buffer into which data will be stored.
 *  nbytes           Maximum number of bytes to be received.
 *  Flags            Ignored. Future Implementation.
 *  pxSockAddrFrom   On return, filled with the protocol address of the sender.
 *  addrlen          On return, this pointer has the length of
 *                   the structure 'pxSockAddrFrom' points to.
 *  ppBuff           Zero-copy sync operation. Ptr to ptr to
 *                   data is stored here on return. Free that pointer using
                     mn_sock_free_recvbuf().
 *  ppFreeArg         Arg to be passed to mn_sock_free_recvbuf();
 *
 * Return:
 *  0 or more : Number of bytes read.
 *  -1: Error
 */
#ifndef  __MOCANA_ASYNC_API__
ubyte4
mn_recvfrom(int lSockfd, void *pvBuff, ubyte4 nbytes, int Flags,
         struct sockaddr *pxSockAddrFrom, socklen_t *addrlen,
     mn_sock_recv_cb_t pfCb, void *pvCbArg, /* async stuff */
         void **ppvBuff, void **ppFreeArg) /* zero-copy stuff */
{
    return(mn_recvfrom_func(lSockfd, pvBuff, nbytes, Flags,
                       pxSockAddrFrom, addrlen,
                   pfCb, pvCbArg,
                       ppvBuff, ppFreeArg,NULL)); /* zero-copy stuff */

}
#else
ubyte4
mn_recvfrom(int lSockfd, void *pvBuff, ubyte4 nbytes, int Flags,
         struct sockaddr *pxSockAddrFrom, socklen_t *addrlen)
{
    return(mn_recvfrom_func(lSockfd, pvBuff, nbytes, Flags,
                       pxSockAddrFrom, addrlen,
                   NULL, NULL,
                       NULL, NULL, NULL)); /* zero-copy stuff */

}
#endif

ubyte4
mn_recvfrom_func(int lSockfd, void *pvBuff, ubyte4 nbytes, int Flags,
         struct sockaddr *pxSockAddrFrom, socklen_t *addrlen,
     mn_sock_recv_cb_t pfCb, void *pvCbArg, /* async stuff */
         void **ppvBuff, void **ppFreeArg,ubyte *ipc_req) /* zero-copy stuff */
{
  DWORD dwCurrSocketId;
  WORD wRxLength;
  SOCKET *pxSock;
  BOOL bValid = TRUE;
  struct sockaddr_in sockAddrFrom_sub;
  socklen_t addrlen_sub;
#if 0
  RTOS_MUTEX tmp_mutex;
#endif

#ifdef STRICT_POSIX
  if ( ppvBuff == NULL ){
     if ((pvBuff == 0x00 || nbytes <= 0x00)) {
        /* addrlen == 0  or pxSockAddrFrom == 0 is not an error, only means
         * 'pxSockAddrFrom' structure should not be filled. So we dont check for those */
        mn_errno = MO_EFAULT;
        return -1;
     }
  }else if ( ppFreeArg == NULL ){
     mn_errno = MO_EFAULT;
     return -1;
  }
#else
  if ( ppvBuff == NULL )
      ASSERT ((pvBuff != 0x00) && (nbytes > 0x00));
  else
      ASSERT ((ppFreeArg != 0x00));
#endif
  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(lSockfd);

  if (pxSock == NULL) {
    bValid = FALSE;
    mn_errno = MO_EBADF;
    ASSERT(0);
  }
  else if ((pxSock->lType == SOCK_STREAM) &&
           (!(pxSock->dwSockState &
              (SS_ISCONNECTED | SS_ISRESET | SS_ISCONNECTING)))) {
    bValid = FALSE;
    mn_errno = MO_ENOTCONN;
  }

  if (bValid == FALSE) {
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  dwCurrSocketId = pxSock->dwSocketId;

  pxSock->poAppBuffer = (OCTET *)pvBuff;
  pxSock->wAppBufferSize = (WORD)nbytes;
  pxSock->ppoAppBuffer = (OCTET **)ppvBuff;
  pxSock->ppFreeArg = ppFreeArg;

  while ((wRxLength = SocketGetRxDataLength(pxSock)) == 0) {

    /* async recv requested, do not block */
#ifndef  __MOCANA_ASYNC_API__
    if ( pfCb ){
      pxSock->pfRecvCb = pfCb;
      pxSock->pvRecvCbArg = pvCbArg;
#ifdef __TCP_SEND_SEGMENT__
      /* Need to set it at the creation state JJ */
      pxSock->dwSockState  |= SS_NBIO;
#endif
      if (ppFreeArg)
          pxSock->dwSockOptions  |= MN_ZEROCOPY;
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return 0;
    }
#endif


    if (pxSock->dwSockState & SS_NBIO) {
      /* No data received */
      /* Non blocking socket: just returns with no data */
      bValid = FALSE;
      mn_errno = MO_EWOULDBLOCK;
    }

    if (pxSock->dwSockState & SS_CANTRCVMORE) {
      /* No data received and remote closed socket */
      bValid = FALSE;
      mn_errno = MO_EPIPE;
    }

    if (bValid != TRUE) {
      pxSock->poAppBuffer = NULL;
      pxSock->wAppBufferSize = 0;
      pxSock->wAppBufferUsedLength = 0;
      pxSock->ppoAppBuffer = NULL;
      pxSock->ppFreeArg = NULL;
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return -1;
    }

#ifndef  __MOCANA_LIBSOCK__
    if ( ipc_req ){
      pxSock->ipc_req = ipc_req;
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return 0;
    }
#endif
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
        /* Blocking socket: set it to sleep */
        DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4,"mn_recvfrom:pxSock 0x", (sbyte4)pxSock,
            "xCond: 0x", (sbyte4)pxSock);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"  waiting 4 signal\n");
    }
    /*NetPrintPayload(&(pxSock->xCond), sizeof(pxSock->xCond)); */
#if 1
    pthread_cond_wait(&(pxSock->xCond), &(xNetWrapper.xMutex));
#else
    pthread_mutex_init(&tmp_mutex, NULL);
    pthread_mutex_unlock(&(xNetWrapper.xMutex));
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4,"mn_recvfrom:pxSock 0x", pxSock,
        ", xCond: 0x", pxSock->xCond);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4," waiting 4 signal\n");
    }
    pthread_mutex_lock(&tmp_mutex);
    pthread_cond_wait(&(pxSock->xCond), &tmp_mutex);
    pthread_mutex_unlock(&tmp_mutex);
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
        DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4,"mn_recvfrom:pxSock 0x", pxSock,
            ", xCond: 0x", pxSock->xCond);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," got signal\n");
    }
    pthread_mutex_lock(&(xNetWrapper.xMutex));
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
        DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4,"mn_recvfrom:pxSock 0x",
            pxSock, ", xCond: 0x", pxSock->xCond);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4," got signal\n");
    }
#endif

    /* Just been woke up: something happened */
    /* Check for socket validity */
    if ( ((pxSock = RETRIEVE_SOCKET(lSockfd)) == NULL) ||
         (pxSock->dwSocketId != dwCurrSocketId)) {
      mn_errno = MO_EBADF;
      bValid = FALSE;
    }
    else if ((pxSock->lType == SOCK_STREAM) &&
             (!(pxSock->dwSockState & SS_ISCONNECTED))) {
      /* TCP Socket should definitely be connected */
      if(pxSock->dwSockState & SS_ISRESET)
        /* check if the reset falg is set, RFC1122 s4.2.2.13 p87, RFC 793 3.5 , ANVL 11.19*/
        mn_errno = MO_ECONNRESET;
      else
        mn_errno = MO_ENOTCONN;
      bValid = FALSE;
    }

    if (bValid != TRUE) {
      pxSock->poAppBuffer = NULL;
      pxSock->wAppBufferSize = 0;
      pxSock->wAppBufferUsedLength = 0;
      pxSock->ppoAppBuffer = NULL;
      pxSock->ppFreeArg = NULL;
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return -1;
    }
  }

#ifndef  __MOCANA_ASYNC_API__
  if ( pfCb && (pxSockAddrFrom == NULL || addrlen == NULL) ){
    /* for async case, we always need to pass fromaddr & addrlen to cb
     * So, if the caller didn't specify his own, use our own
     */
    addrlen_sub = sizeof(sockAddrFrom_sub);
    pxSockAddrFrom = (struct sockaddr *)&sockAddrFrom_sub;
    addrlen = &addrlen_sub;
  }
#endif

  /* UDP specific stuff */
  if (pxSock->lType == SOCK_DGRAM) {
    /* UDP socket */
    UDPSOCKET *pxUdp = pxSock->u.pxUdp;
    UDPPACKET *pxPacket = NULL;
    TRANSPORTID *pxId;
    ubyte4 lReturn;

    SOCKET_ASSERT(pxUdp != NULL);

    pxPacket = NULL;
    lReturn = 0;

    /* Check App buffer 1st */
    if (pxSock->wAppBufferUsedLength > 0) {
      /* Stuff is stored in app buffer already */
      pxId = &(pxUdp->xRxTransportId);
      lReturn = pxSock->wAppBufferUsedLength;
    }
    else {
      SOCKET_ASSERT(pxUdp->wBufferedLength > 0);
      SOCKET_ASSERT(pxUdp->wBufferedLength < UDP_MAX_BUFFER);
      SOCKET_ASSERT(DLLIST_count_inline(pxUdp->pDllPackets) > 0);
      /* stored in dllist: needs to copy it over */
      DLLIST_head(pxUdp->pDllPackets);
      pxPacket = DLLIST_remove(pxUdp->pDllPackets);

      ASSERT((pxPacket != NULL) && (pxPacket->pxPayload != NULL) &&
        (pxPacket->pxPayload->poPayload != NULL));
      pxId = &(pxPacket->xId);

      if ( ppvBuff ) {
          lReturn = pxPacket->wLength;
        *ppvBuff = pxPacket->pxPayload->poPayload + pxPacket->wOffset;
        *ppFreeArg = pxPacket->pxPayload;
      }else{
          lReturn = (pxPacket->wLength < nbytes) ? pxPacket->wLength: nbytes;
          MOC_MEMCPY((ubyte *)pvBuff,
            (ubyte *)(pxPacket->pxPayload->poPayload + pxPacket->wOffset),
            lReturn);
          /* mn_sock_free_recvbuf(pxPacket->pxPayload); */

          NETPAYLOAD_CHECK(pxPacket->pxPayload);
          NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      }

      SOCKET_ASSERT(pxUdp->wBufferedLength >= pxPacket->wLength);
      pxUdp->wBufferedLength -= pxPacket->wLength;
    }

    if (pxSockAddrFrom != NULL) {
      pxSockAddrFrom->sa_len = *addrlen = sizeof(struct sockaddr_in);
      pxSockAddrFrom->sa_family = AF_INET;
      ((struct sockaddr_in *)pxSockAddrFrom)->sin_addr.s_addr =
        htonl(pxId->xNetId.dwSrcIpAddr);
      ((struct sockaddr_in *)pxSockAddrFrom)->sin_port =
        htons(pxId->wSrcPort);
    }

    if (pxPacket != NULL) {
      /* Free the packet */
      FREE(pxPacket); /* payload is in-line: no need to free it
                         separately */
    }

    /* Reset the app buffer members */
    pxSock->poAppBuffer = NULL;
    pxSock->wAppBufferSize = 0;
    pxSock->wAppBufferUsedLength = 0;
    pxSock->ppoAppBuffer = NULL;
    pxSock->ppFreeArg = NULL;

#ifndef  __MOCANA_ASYNC_API__
    if ( pfCb ){
      pxSock->pfRecvCb = pfCb;
      pxSock->pvRecvCbArg = pvCbArg;
      if (ppFreeArg)
          pxSock->dwSockOptions  |= MN_ZEROCOPY;
      pfCb(pxSock->lFd, (ppvBuff ? *ppvBuff : pvBuff), lReturn,
        pxSockAddrFrom, *addrlen, pvCbArg,ppvBuff ?*ppFreeArg : NULL);
#if 0 /* JJ Added Async Zero Copy */
      if ( ppvBuff )
        mn_sock_free_recvbuf(*ppFreeArg);
#endif
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      return 0;
    }else{
#endif
#ifdef __MOCANA_IPC_LIBSOCK__
        if (ipc_req)
        {
            socklen_t addrLen = 0;
            if (NULL == pxSockAddrFrom ) {
                addrlen = &addrLen;
            }

            SOCKSERVER_recvReply(ipc_req,pxSock->lFd, ppvBuff ? *ppvBuff : pvBuff,
                                 lReturn, pxSockAddrFrom, *addrlen);
        if ( ppvBuff )
                      mn_sock_free_recvbuf(*ppFreeArg);
            RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return 0;
        }
#endif
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return lReturn;
#ifndef  __MOCANA_ASYNC_API__
    }
#endif
  }
  else {
    ubyte4 lReturn;
#if 0 /* RS: carved out to a function so that it can be used in TcpRxCb() */
    /* TCP socket */
    TCPSOCKET *pxTcp;
    TCPCONNECT *pxConnect;
    H_NETINSTANCE hTcp;
    NETPACKET xPacket;
    NETPAYLOAD xPayload;

    SOCKET_ASSERT(pxSock->lType == SOCK_STREAM);


    pxTcp = pxSock->u.pxTcp;
    SOCKET_ASSERT(pxTcp != NULL);

    pxConnect = pxTcp->u.pxConnect;
    SOCKET_ASSERT(pxConnect != NULL);

    hTcp = xSocketRep.axProtocols[TCP_INDEX].hInst;

    xPacket.hMarker = (H_NETDATA)pxSock;
    /* SB Feb-2002. Use local variables for payload !!! We know it is
       not going to be kept. !!! Maybe that must change !!! */
    xPacket.pxPayload = &(xPayload);
    xPayload.pfnFree = NetFree;
#ifdef NET_ASYNC
    xPayload.pxMutex = &(xNetWrapper.xMutex);
#endif
    xPayload.poPayload = (OCTET *)pvBuff;
    xPayload.wSize = nbytes;

    TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                TCPULINTERFACEIOCTL_GETRXDATA,
                                (H_NETDATA) &(xPacket));
    /* No need to lock the payload: we are the owner and user */
    lReturn = xPacket.pxPayload->wSize;

    pxSock->poAppBuffer = NULL;
    pxSock->wAppBufferUsedLength = 0;
    pxSock->wAppBufferSize = 0;
    pxSock->ppoAppBuffer = NULL;
    pxSock->ppFreeArg = NULL;

    if (pxSockAddrFrom != NULL) {
      /* should happen rarely, as recv is used in tcp, more than
         recvfrom. Needs to ask the TCP module for this info.
         (If it was happening more often: 1. tell the app implementers
         it is bad policy 2. keep a local copy)
         */
      pxSockAddrFrom->sa_len = *addrlen = sizeof(struct sockaddr_in);
      pxSockAddrFrom->sa_family = AF_INET;
      TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                  NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEIP,
                                  (H_NETDATA)
                                  &(((struct sockaddr_in *)pxSockAddrFrom)->sin_addr.s_addr));

      TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                  NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEPORT,
                                  (H_NETDATA)
                                  &(((struct sockaddr_in *)pxSockAddrFrom)->sin_port));
      ((struct sockaddr_in *)pxSockAddrFrom)->sin_addr.s_addr =
        htonl(((struct sockaddr_in *)pxSockAddrFrom)->sin_addr.s_addr);
      ((struct sockaddr_in *)pxSockAddrFrom)->sin_port =
        htons(((struct sockaddr_in *)pxSockAddrFrom)->sin_port);
    }
#else
    lReturn = _SocketReadTcp(pxSock, pvBuff, nbytes, pxSockAddrFrom, addrlen,
                    ppvBuff, ppFreeArg);
    pxSock->poAppBuffer = NULL;
    pxSock->wAppBufferUsedLength = 0;
    pxSock->wAppBufferSize = 0;
    pxSock->ppoAppBuffer = NULL;
    pxSock->ppFreeArg = NULL;
#endif
#ifndef  __MOCANA_ASYNC_API__
    if ( pfCb ){
      pxSock->pfRecvCb = pfCb;
      pxSock->pvRecvCbArg = pvCbArg;
      if (ppFreeArg)
          pxSock->dwSockOptions  |= MN_ZEROCOPY;
      pfCb(pxSock->lFd, (ppvBuff ? *ppvBuff : pvBuff), lReturn,
             pxSockAddrFrom, *addrlen, pvCbArg, ppvBuff ? *ppFreeArg: NULL);
#if 0 /* JJ Did for Async Zero Copy */
      if ( ppvBuff )
        mn_sock_free_recvbuf(*ppFreeArg);
#endif
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return 0;
    }else{
#endif
#ifdef __MOCANA_IPC_LIBSOCK__
        if (ipc_req)
        {
            socklen_t addrLen = 0;
            if (NULL == pxSockAddrFrom ) {
                addrlen = &addrLen;
            }
            SOCKSERVER_recvReply(ipc_req,pxSock->lFd, ppvBuff ? *ppvBuff : pvBuff,
                                 lReturn, pxSockAddrFrom, *addrlen);
        if ( ppvBuff )
                      mn_sock_free_recvbuf(*ppFreeArg);
            RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return 0;
        }
#endif
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return lReturn;
#ifndef  __MOCANA_ASYNC_API__
    }
#endif
  }

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return 0;
}

/*
 * sendto
 *  Send a message.
 *  If MN_ZEROCOPY flags bit is set in iFlags,
 *    -  pvBuff should have been alloced using mn_sock_alloc_sendbuf().
 *    -  nbytes should be <= nbytes passed to mn_sock_alloc_sendbuf()
 *    -  pvBuff will be freed upon return i.e. it can not be reused by app.
 *
 *  Args:
 *   lSockfd                       The socket returned by the socket function.
 *   pvBuff                          The buffer that needs to be sent.
 *   nbytes                        Number of bytes to be sent.
 *   Flags                         Ignored. Future Implementation.
 *   pxSockAddr                    The protocol address of the remote host
 *                                 should be specified.
 *   addrlen                       The length of the structure 'to' points to.
 *
 *  Return:
 *   0 or more : Number of bytes sent.
 *   -1: Error
 */
ubyte4 mn_sendto(int iSockfd, void *pvBuff, ubyte4 nbytes, int iFlags,
              const struct sockaddr *pxSockAddr, socklen_t addrlen)
{
  SOCKET *pxSock;
  DWORD dwTxAvailableSpace;
  WORD wTransportHdrSize;
  PFN_NETWRITE pfnWrite;
  H_NETINSTANCE hInst;
  TRANSPORTID *pxId;
  NETWORKID *pxNetId;
#ifdef __TCP_SEND_SEGMENT__
  txSegmentStructure *pTxSegment = NULL;
  DWORD wTxSent = 0;
  DWORD wTxSentSegments = 0;
#endif
  MSTATUS status;

#ifdef STRICT_POSIX
  /* if invalid buffer ptr, return err */
  if (pvBuff == 0x00 || nbytes <= 0x00) {
    SOCKET_CHECKPOINT(dbg_dwsendto);
    mn_errno = MO_EFAULT;
#ifndef __TCP_SEND_SEGMENT__
    if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
    return -1;
  }

  /* Family should be proper */
  if (pxSockAddr) {
    if (pxSockAddr->sa_family != AF_INET) {
      SOCKET_CHECKPOINT(dbg_dwsendto);
      mn_errno = MO_EAFNOSUPPORT;
#ifndef __TCP_SEND_SEGMENT__
      if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
      return -1;
    }
    /* Length should be proper */
    if (addrlen < sizeof(struct sockaddr_in)) {
      SOCKET_CHECKPOINT(dbg_dwsendto);
      mn_errno = EBADARG;
#ifndef __TCP_SEND_SEGMENT__
      if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
      if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
      return -1;
    }
  }
  /* pxSockAddr can be NULL for sendto() since it might be a connected UDP socket */

#else
  ASSERT((pvBuff != 0x00) &&
         (nbytes > 0x00) &&
         ((pxSockAddr == NULL) ||
          ((pxSockAddr->sa_family == AF_INET) &&
           (addrlen >= sizeof(struct sockaddr_in)))));
#endif

  /* Early checks passed */

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
  SOCKET_CHECKPOINT(dbg_dwsendto);

  pxSock = RETRIEVE_SOCKET(iSockfd);

  if (pxSock == NULL) {
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    mn_errno = MO_EBADF;
    SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
    if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
    if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
    return -1;
  }

  /* Check whether it is ok pxSockAddr send data */
  if (pxSock->dwSockState & SS_CANTSENDMORE) {
    mn_errno = MO_EPIPE;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
    if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
    if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
    return -1;
  }

  pxId = &(pxSock->xTransportId);
  pxNetId = (NETWORKID *)&(pxId->xNetId);

  if (pxSock->lType == SOCK_DGRAM) {
    /* UDP socket */
    UDPSOCKET *pxUdp;
    DWORD dwDstAddr;
    WORD wDstPort;

    pxUdp = pxSock->u.pxUdp;
    ASSERT(pxUdp != NULL);

    /* Handle unreachable problems */
    if ((pxSockAddr == NULL) && (pxUdp->lErrno == MO_EHOSTUNREACH)) {
      pxUdp->lErrno = 0; /* allow next call */
      mn_errno = MO_EHOSTUNREACH;
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
      SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
      if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
      if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
      return -1;
    }

    hInst = xSocketRep.axProtocols[UDP_INDEX].hInst;

    if (pxSock->dwSockState & SS_ISCONNECTED) {
      if (pxSockAddr != NULL) {
        /* Connected socket with pxSockAddr not null : bad */
        mn_errno = MO_EISCONN;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
        if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
        if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
        return -1;
      }
      /* No need to set the xDst fields, as it is connected */
    }
    else {
#ifdef IPSEC
      OCTET obUpdateIpSec = TRUE;
#endif

      if (pxSockAddr == NULL) {
        /* Unconnected socket with to null : bad too */
        mn_errno = MO_ENOTCONN;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
        if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
        if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
        return -1;
      }

      dwDstAddr = ntohl(((struct sockaddr_in *)pxSockAddr)->sin_addr.s_addr);
      wDstPort = ntohs(((struct sockaddr_in *)pxSockAddr)->sin_port);

    /* check that addresses and port are valid */
      if ((dwDstAddr == 0) || (wDstPort == 0)) {
        mn_errno = MO_EDESTADDRREQ;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
        if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
        if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
        return -1;
      }

      /* Check that the local port is set */
      if (pxId->wSrcPort == 0) {
        /* The source port is not set: Force automatic setting */
        if (UdpInstanceULInterfaceIoctl(hInst,pxSock->hLL,
                                        NETTRANSPORTULINTERFACEIOCTL_SETLOCALPORT,(H_NETDATA)0) < 0) {
          mn_errno = MO_EADDRINUSE;
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
          SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
          if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
          if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
          return -1;
        }
        UdpInstanceULInterfaceIoctl(hInst,pxSock->hLL,
                                    NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT,
                                    (H_NETDATA)&(pxId->wSrcPort));
        ASSERT(pxId->wSrcPort != 0);
      }

#ifndef ROUTER /* RS let every packet go out of whatever interface is up */
      if (dwDstAddr != pxNetId->dwDstAddr)
#endif
      {
        /* The destination address has changed: check the route */
        ROUTEENTRY xRoute;

        xRoute.eDstAddrType = IPADDRT_UNKNOWN;
#ifdef _RADIX_ROUTING_ON_
        xRoute.xRouteNodes->RadixNodeKey  = dwDstAddr;
        xRoute.xRouteNodes->RadixNodeMask = 0;
#else
        xRoute.dwDstAddr = dwDstAddr;
#endif
        xRoute.oIfIdx =
          (pxSock->oBoundFlag & SOCKETBOUNDFLAG_IF) ? pxNetId->oIfIdx:
          NETIFIDX_ANY;
        xRoute.wVlan =
          (pxSock->oBoundFlag & SOCKETBOUNDFLAG_VLAN) ? pxNetId->wVlan:
          NETVLAN_ANY;

        if (RoutingTableMsg(ROUTINGTABLEMSG_FINDROUTE,
                            (H_NETDATA)&(xRoute)) <0) {
          mn_errno = MO_EHOSTUNREACH;
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
          SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
          if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
          if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
          return -1;
        }

        /* Can only happen on non-connected sockets */
        if (pxNetId->oIfIdx == NETIFIDX_ANY) {
          mn_errno = MO_EBADF;
          SOCKET_CHECKPOINT(dbg_dwsendto);
          /* Not interface defined for this send: return error */
          RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
          SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
          if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
          if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
          return -1;
        }

        pxNetId->eDstAddrType = xRoute.eDstAddrType;
        pxNetId->oIfIdx = xRoute.oIfIdx;
        pxNetId->wVlan = xRoute.wVlan;
        pxNetId->dwDstAddr = dwDstAddr;
        pxNetId->dwGatewayAddr = xRoute.dwGateway;

        if ((pxSock->oBoundFlag & SOCKETBOUNDFLAG_IP) == 0) {
          pxNetId->dwSrcAddr =
            (xNetWrapper.pxIfConf[pxNetId->oIfIdx].pxIPAlias[0].dwAddr);

        }
        if ((pxSock->oBoundFlag & SOCKETBOUNDFLAG_TOS) == 0) {
          pxNetId->oToS = xNetWrapper.pxIfConf[pxNetId->oIfIdx].oTos;
        }

        /*Set Ttl*/
        if (pxNetId->eDstAddrType == IPADDRT_MULTICAST) {
          pxNetId->oTtL = pxSock->u.pxUdp->oMcastTtl;
        }
      }
#ifdef IPSEC
#ifndef ROUTER /* RS let every packet go out of whatever interface is up */
      else if (wDstPort == pxId->wDstPort) {
        obUpdateIpSec = FALSE; /* No need to update the IPSec info */
      }
#endif

      if (obUpdateIpSec == TRUE) {
        /* look up security policy */
        if ((pxNetId->dwSecurityPolicy = (DWORD)
             IPSecGetSP(pxNetId->dwDstAddr,wDstPort,
                        pxNetId->dwSrcAddr,
                        pxId->wSrcPort, IPPROTO_UDP, 0))) {
          /* allocate header space for AH or ESP */
          pxNetId->wIpSecHdrLength =
            IPSecGetHdrLen((void *)pxNetId->dwSecurityPolicy);
        }
      }
#endif
      pxId->wDstPort = wDstPort;
      pxNetId->oProtocol = IPPROTO_UDP;
    }
    dwTxAvailableSpace = nbytes; /* UDP always takes everything */
    wTransportHdrSize = UDPDEFAULT_HDRSIZE;
    pfnWrite = UdpInstanceWrite;
  }
  else {
    /* TCP socket */
    DWORD dwCurrSocketId;

    SOCKET_ASSERT(pxSock->lType == SOCK_STREAM);
    /* Socket should definitely be connected */
    if (!(pxSock->dwSockState & SS_ISCONNECTED)) {
      SOCKET_CHECKPOINT(dbg_dwsendto);
      mn_errno = MO_ENOTCONN;
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#ifndef __TCP_SEND_SEGMENT__
      if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
      if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
      return -1;
    }
    if (pxSockAddr != NULL) {
        mn_errno = MO_EISCONN;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        SOCKET_CHECKPOINT(dbg_dwsendto);
#ifndef __TCP_SEND_SEGMENT__
        if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
        if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
        return -1;
    }
    hInst = xSocketRep.axProtocols[TCP_INDEX].hInst;

    dwCurrSocketId = pxSock->dwSocketId;

    TcpInstanceULInterfaceIoctl(hInst,pxSock->hLL,
                                TCPULINTERFACEIOCTL_GETTXAVAILSPACE,
                                (H_NETDATA)&dwTxAvailableSpace);

    /*printf("Avaialble Space %ld  \n",dwTxAvailableSpace);*/

    while (dwTxAvailableSpace == 0) {
      /* No space available for sending yet */

      if (pxSock->dwSockState & SS_NBIO) {
        SOCKET_CHECKPOINT(dbg_dwsendto);
        mn_errno = MO_EWOULDBLOCK;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#ifndef __TCP_SEND_SEGMENT__
        if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
        if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
        return -1;
      }

      /* blocking socket : set it to sleep */
      pthread_cond_wait(&(pxSock->xCond), &(xNetWrapper.xMutex));

      /* Just woke up. Check that it is still valid, etc */
      /* Check for socket validity */

      SOCKET_CHECKFD(iSockfd);

      if ( ((pxSock = RETRIEVE_SOCKET(iSockfd)) == NULL) ||
           (pxSock->dwSocketId != dwCurrSocketId)) {
        SOCKET_CHECKPOINT(dbg_dwsendto);
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        mn_errno = MO_EBADF;
#ifndef __TCP_SEND_SEGMENT__
        if ( iFlags & MN_ZEROCOPY )mn_sock_free_sendbuf(iSockfd, pvBuff);
#else
        if ( iFlags & MN_ASYNCBUF )mn_sock_free_sendbuf(iSockfd, pvBuff);
#endif
        return -1;
      }

      TcpInstanceULInterfaceIoctl(hInst,pxSock->hLL,
                                  TCPULINTERFACEIOCTL_GETTXAVAILSPACE,
                                  (H_NETDATA)&dwTxAvailableSpace);
    }

    wTransportHdrSize = TCPDEFAULT_HDRSIZE;
    pfnWrite = TcpInstanceWrite;
    if (dwTxAvailableSpace > nbytes) {
      dwTxAvailableSpace = nbytes;
    }

  } /* End TCP socket */


  /* Now Make the packet and send it */
  {
    NETPACKET xPacket;
    NETPACKETACCESS xAccess;
    OCTET oIfIdx;

    oIfIdx = pxNetId->oIfIdx;
    ASSERT(oIfIdx != NETIFIDX_ANY);

    /* Allocate and send the packet */
    xPacket.hMarker = (H_NETDATA)pxSock;
    xPacket.wVlan   =  NETVLAN_ANY;
    xAccess.wOffset = IPDEFAULT_HDRSIZE + wTransportHdrSize +
      xNetWrapper.pxIfConf[oIfIdx].oL3AddrLength;

#ifdef IPSEC
    xAccess.wOffset += pxNetId->wIpSecHdrLength;
#endif /* IPSEC */

    /*Adjust the offset to be int aligned*/
    if( (xAccess.wOffset % sizeof(int)) != 0) {
      xAccess.wOffset+=(sizeof(int) - (xAccess.wOffset % sizeof(int)));
    }

    ASSERT( (xAccess.wOffset % sizeof(int)) == 0);

    {
      WORD wSize;
      OCTET *poPayload;

      wSize = dwTxAvailableSpace + xAccess.wOffset +
        xNetWrapper.pxIfConf[oIfIdx].oL3TrailerLength;

#ifdef IPSEC
      /* allocate more space for ESP trailer and ESP-Auth */
      pxNetId->wIpSecTrailLength =
        IPSecGetTrailLen((void *)pxNetId->dwSecurityPolicy,
                         dwTxAvailableSpace + wTransportHdrSize);
      wSize += pxNetId->wIpSecTrailLength;
#endif /* IPSEC */

      /* Make sure it is big enough */
      if (wSize < xNetWrapper.pxIfConf[oIfIdx].wLtu) {
        wSize = xNetWrapper.pxIfConf[oIfIdx].wLtu;
      }

      xAccess.wLength = dwTxAvailableSpace;

      /* RS add begin */
      if ( iFlags & MN_ZEROCOPY  ){
        /* alloced using mn_sock_alloc_sendbuf() */
      if ( !(iFlags & MN_ASYNCBUF) ){
         /* Was Alloced using SendSegment */
#ifdef __TCP_SEND_SEGMENT__
        if (pxSock->lType == SOCK_STREAM)
        {
           pTxSegment = (txSegmentStructure *)pvBuff;
           wTxSentSegments = dwTxAvailableSpace;
           while (pTxSegment)
           {
               /* Send only till TxAvailableSpace */
               printf("Avaialble Window %ld , Segment to Send %ld \n",wTxSentSegments ,  pTxSegment->lengthOfSegment);
               if ((wTxSentSegments <  pTxSegment->lengthOfSegment))
               {
                   break;
               }

               wTxSentSegments =  wTxSentSegments - pTxSegment->lengthOfSegment;
                 xAccess.wOffset = pTxSegment->offset;
               xAccess.wLength = pTxSegment->lengthOfSegment;
               NETPAYLOAD_CREATE((&(xPacket.pxPayload)),NetFree,(&xNetWrapper.xMutex),
                               (pTxSegment->pSegment - pTxSegment->offset),(pTxSegment->lengthOfSegment + pTxSegment->offset + MAX_TXBUFFER_TRAILER));
               if(NULL == xPacket.pxPayload)
               {
                   ubyte4 lRv = 0;
                   DEBUG_ERROR(DEBUG_MOC_IPV4,
                      "Error: SOCK_STREAM and MN_ZEROCOPY - mn_sendto - NETPAYLOAD_CREATE failed : %d",lRv);
                   return lRv;
               }

               xPacket.pxPayload->pTxSegment = (OCTET *)pTxSegment;
               wTxSent += (WORD)
                        pfnWrite(hInst,pxSock->hLL,&xPacket,&xAccess,(H_NETDATA)pxId);
               pTxSegment = pTxSegment->pNextSegment;

           }
           RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
           SOCKET_CHECKPOINT(dbg_dwsendto);
           return (LONG)wTxSent;
        }
#endif
        } /* If Alloced using send Segment */
          poPayload = ((OCTET *)pvBuff) - xAccess.wOffset;
        NETPAYLOAD_CREATE((&(xPacket.pxPayload)),NetFree,(&xNetWrapper.xMutex),
                        (poPayload),(wSize));
        if(NULL == xPacket.pxPayload)
        {
              ubyte4 lRv = 0;
              DEBUG_ERROR(DEBUG_MOC_IPV4,
                      "Error: SOCK_DGRAM and MN_ZEROCOPY - mn_sendto - NETPAYLOAD_CREATE failed : %d",lRv);
              return lRv;
        }
      }
      else
      {
      /* RS add end */
#ifdef __INET_USE_PAYLOAD_MEMPOOL__
        status = NetAllocPayload(&poPayload,wSize);
        if (OK > status)
             return status;
#else
          poPayload = (OCTET *)MALLOC(wSize);
#endif
        ASSERT(poPayload != NULL);

        NETPAYLOAD_CREATE((&(xPacket.pxPayload)),NetFree,(&xNetWrapper.xMutex),
                        (poPayload),(wSize));

        if(NULL == xPacket.pxPayload)
        {
              ubyte4 lRv = 0;
              DEBUG_ERROR(DEBUG_MOC_IPV4, "Error: mn_sendto - NETPAYLOAD_CREATE failed : %d",lRv);
              NetFree(poPayload);
              return lRv;
        }
        /*copy payload*/
        MOC_MEMCPY((ubyte *)(poPayload + xAccess.wOffset),
                    (ubyte *)pvBuff,dwTxAvailableSpace);
      }
    }

    dwTxAvailableSpace = (WORD)
      pfnWrite(hInst,pxSock->hLL,&xPacket,&xAccess,(H_NETDATA)pxId);

    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    SOCKET_CHECKPOINT(dbg_dwsendto);
    return (LONG)dwTxAvailableSpace;
  }


  SOCKET_CHECKPOINT(dbg_dwsendto);

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return 0;
}

#ifdef __TCP_SEND_SEGMENT__
/*
 * MN_sock_alloc_sendSegment
 *  Allocate a buffer to send data in. Used for zero copy transmission.
 *  Application fills the buffer gotten from this API and sends using
 *  send()/sendto() with a flag MN_ZEROCOPY flag set. Allocated buffer will
 *  be freed by send()/sendto(). No separate routine to free is provided.
 *
 *  Args:
 *   iSockfd      The socket returned by the socket function.
 *   nbytes       Number of bytes required
 *
 *  Return:
 *   Pointer to allocated buffer: Success.
 *   NULL: Error
 */
MSTATUS MN_sock_get_sendSegment(E_INET_TXBUFFER_POOLS poolType,
                        ubyte4 numSegments ,
                        ubyte **ppSegment,/* Pointer to tcSegmentStructure*/
                        mn_sock_release_segment_cb_t pfCb, void *pvCbArg)
{
  txSegmentStructure *pTxSegment = NULL;
  txSegmentStructure *pPrevTxSegment = NULL;
  NETWRAPPER *pxNetWrapper;
  NETWRAPPERSTATE *pxWrapperState;
  ubyte i;
  MSTATUS lRc;

  pxNetWrapper = NETGETWRAPPER;

  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);

  RTOS_recursiveMutexWait(&(pxNetWrapper->xMutex));

  if ((INET_TXMAX_BUFFER_POOL < poolType) ||
     (pxWrapperState->xSendBufferPools[poolType].segmentsFree < numSegments))
  {
    RTOS_recursiveMutexRelease(&(pxNetWrapper->xMutex));
    mn_errno = MO_EBADF;
    SOCKET_CHECKPOINT(dbg_dwsendto);
    return -1;
  }

  for (i=0;i < numSegments; i++)
  {
      lRc = MEM_POOL_getPoolObject(&pxWrapperState->txSegmentPoolId, (void **)&(pTxSegment));
      if (OK > lRc)
      {
          DEBUG_ERROR(DEBUG_MOC_IPV4,"Unable to Get Memory for Buffer ",lRc);
          /* Free what has been allocated already */
          MN_sock_put_sendSegment( *ppSegment);
          *ppSegment = NULL;
          return lRc;
      }

      lRc = MEM_POOL_getPoolObject(&pxWrapperState->xSendBufferPools[poolType].poolId, (void **)&(pTxSegment->pSegment));
      if (OK > lRc)
      {
          DEBUG_ERROR(DEBUG_MOC_IPV4,"Unable to Get Memory for Buffer ",lRc);
          /* Free what has been allocated already */
          MN_sock_put_sendSegment( *ppSegment);
          *ppSegment = NULL;
          return lRc;
      }
      pTxSegment->pNextSegment      = NULL;
      pTxSegment->offset            = pxWrapperState->xSendBufferPools[poolType].offset;
      pTxSegment->pSegment         += pTxSegment->offset; /* Move it to the correct offset*/
      pTxSegment->lengthOfSegment   = 0;
      pTxSegment->maxLengthOfSegment= pxWrapperState->xSendBufferPools[poolType].lengthOfSegment;
      pTxSegment->poolType          = poolType;
      pTxSegment->pfCb              = pfCb;
      pTxSegment->pvCbArg           = pvCbArg ;

      if ( 0 == i) /* First Segment */
      {
          *ppSegment = (ubyte *)pTxSegment;
      }
      if (pPrevTxSegment)
          pPrevTxSegment->pNextSegment = pTxSegment;

      pPrevTxSegment = pTxSegment;
      pxWrapperState->xSendBufferPools[poolType].segmentsFree--;

    }

    RTOS_recursiveMutexRelease(&(pxNetWrapper->xMutex));

    return 0;
}

MSTATUS MN_sock_put_sendSegment(ubyte *pSegment)
{
  txSegmentStructure *pTxSegment = (txSegmentStructure *)pSegment;
  txSegmentStructure *pNextTxSegment = NULL;
  NETWRAPPER *pxNetWrapper;
  NETWRAPPERSTATE *pxWrapperState;
  MSTATUS status ;

  pxNetWrapper = NETGETWRAPPER;

  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);

  if (!pTxSegment)
      return 0;

  RTOS_recursiveMutexWait(&(pxNetWrapper->xMutex));

  while (pTxSegment)
  {
      pNextTxSegment = pTxSegment->pNextSegment;
      pxWrapperState->xSendBufferPools[pTxSegment->poolType].segmentsFree++;
      status = MEM_POOL_putPoolObject(&pxWrapperState->xSendBufferPools[pTxSegment->poolType].poolId, (void **)&(pTxSegment->pSegment));
      if (OK > status)
      {
          DEBUG_ERROR(DEBUG_MOC_IPV4,"Error Freeing Segment Payload",status);
      }
      status = MEM_POOL_putPoolObject(&pxWrapperState->txSegmentPoolId, (void **)&(pTxSegment));
      if (OK > status)
      {
          DEBUG_ERROR(DEBUG_MOC_IPV4,"Error Freeing Segment ",status);
      }

      pTxSegment = pNextTxSegment;

    }

    RTOS_recursiveMutexRelease(&(pxNetWrapper->xMutex));

    return 0;
}

#endif /* __TCP_SEND_SEGMENT__*/
/*
 * mn_sock_alloc_sendbuf
 *  Allocate a buffer to send data in. Used for zero copy transmission.
 *  Application fills the buffer gotten from this API and sends using
 *  send()/sendto() with a flag MN_ZEROCOPY flag set. Allocated buffer will
 *  be freed by send()/sendto(). No separate routine to free is provided.
 *
 *  Args:
 *   iSockfd      The socket returned by the socket function.
 *   nbytes       Number of bytes required
 *
 *  Return:
 *   Pointer to allocated buffer: Success.
 *   NULL: Error
 */
void *mn_sock_alloc_sendbuf(int iSockfd, ubyte4 nbytes)
{
  /* code copied from sendto() */
  SOCKET *pxSock;
  TRANSPORTID *pxId;
  NETWORKID *pxNetId;
  WORD wTxAvailableSpace;
  WORD wTransportHdrSize;
  MSTATUS status;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
  pxSock = RETRIEVE_SOCKET(iSockfd);

  if (pxSock == NULL) {
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    mn_errno = MO_EBADF;
    SOCKET_CHECKPOINT(dbg_dwsendto);
    return NULL;
  }

  wTxAvailableSpace = nbytes; /* always alloacte for everything - RS */
  if (pxSock->lType == SOCK_DGRAM)
      wTransportHdrSize = UDPDEFAULT_HDRSIZE;
  else
      wTransportHdrSize = TCPDEFAULT_HDRSIZE;

  pxId = &(pxSock->xTransportId);
  pxNetId = (NETWORKID *)&(pxId->xNetId);
  {
    NETPACKET xPacket;
    NETPACKETACCESS xAccess;
    OCTET oIfIdx;

    oIfIdx = pxNetId->oIfIdx;
    ASSERT(oIfIdx != NETIFIDX_ANY);
#if 0
    /* Allocate and send the packet */
    xPacket.hMarker = (H_NETDATA)pxSock;
    xPacket.wVlan   =  NETVLAN_ANY;
#endif
    xAccess.wOffset = IPDEFAULT_HDRSIZE + wTransportHdrSize +
      xNetWrapper.pxIfConf[oIfIdx].oL3AddrLength;

#ifdef IPSEC
    xAccess.wOffset += pxNetId->wIpSecHdrLength;
#endif /* IPSEC */

    /*Adjust the offset to be int aligned*/
    if( (xAccess.wOffset % sizeof(int)) != 0) {
      xAccess.wOffset+=(sizeof(int) - (xAccess.wOffset % sizeof(int)));
    }

    ASSERT( (xAccess.wOffset % sizeof(int)) == 0);

    {
      WORD wSize;
      OCTET *poPayload;

      wSize = wTxAvailableSpace + xAccess.wOffset +
        xNetWrapper.pxIfConf[oIfIdx].oL3TrailerLength;

#ifdef IPSEC
      /* allocate more space for ESP trailer and ESP-Auth */
      pxNetId->wIpSecTrailLength =
        IPSecGetTrailLen((void *)pxNetId->dwSecurityPolicy,
                         wTxAvailableSpace + wTransportHdrSize);
      wSize += pxNetId->wIpSecTrailLength;
#endif /* IPSEC */

      /* Make sure it is big enough */
      if (wSize < xNetWrapper.pxIfConf[oIfIdx].wLtu) {
        wSize = xNetWrapper.pxIfConf[oIfIdx].wLtu;
      }

#ifdef __INET_USE_PAYLOAD_MEMPOOL__
      status = NetAllocPayload(&poPayload,wSize);
      if (OK > status)
          return NULL;
#else
      poPayload = (OCTET *)MALLOC(wSize);
#endif
      ASSERT(poPayload != NULL);

#if 0
      xAccess.wLength = wTxAvailableSpace;
#endif

      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

      return (void*)(poPayload + xAccess.wOffset); /* return - RS */
    }
  }
}

/*
 * mn_sock_free_sendbuf
 *  Free the buffer alloced by mn_sock_alloc_sendbuf().
 *
 *  Args:
 *   iSockfd      The socket returned by the socket function.
 *   pvBuff       The buffer that needs to be sent.
 *
 *  Return:
 *   void:
 */
void mn_sock_free_sendbuf(int iSockfd, void *pvBuff)
{
  /* code copied from sendto() */
  SOCKET *pxSock;
  TRANSPORTID *pxId;
  NETWORKID *pxNetId;
  /*WORD wTxAvailableSpace; */
  WORD wTransportHdrSize;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  pxSock = RETRIEVE_SOCKET(iSockfd);

  if (pxSock == NULL) {
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    mn_errno = MO_EBADF;
    SOCKET_CHECKPOINT(dbg_dwsendto);
    return;
  }

  /*wTxAvailableSpace = nbytes;  *//* always alloacte for everything - RS */
  if (pxSock->lType == SOCK_DGRAM)
      wTransportHdrSize = UDPDEFAULT_HDRSIZE;
  else
      wTransportHdrSize = TCPDEFAULT_HDRSIZE;

  pxId = &(pxSock->xTransportId);
  pxNetId = (NETWORKID *)&(pxId->xNetId);
  {
    NETPACKET xPacket;
    NETPACKETACCESS xAccess;
    OCTET oIfIdx;

    oIfIdx = pxNetId->oIfIdx;
    ASSERT(oIfIdx != NETIFIDX_ANY);

    /* Allocate and send the packet */
#if 0
    xPacket.hMarker = (H_NETDATA)pxSock;
    xPacket.wVlan   =  NETVLAN_ANY;
#endif
    xAccess.wOffset = IPDEFAULT_HDRSIZE + wTransportHdrSize +
      xNetWrapper.pxIfConf[oIfIdx].oL3AddrLength;

#ifdef IPSEC
    xAccess.wOffset += pxNetId->wIpSecHdrLength;
#endif /* IPSEC */

    /*Adjust the offset to be int aligned*/
    if( (xAccess.wOffset % sizeof(int)) != 0) {
      xAccess.wOffset+=(sizeof(int) - (xAccess.wOffset % sizeof(int)));
    }

    ASSERT( (xAccess.wOffset % sizeof(int)) == 0);

    {
      OCTET *poPayload;
#if 0
      WORD wSize;

      wSize = wTxAvailableSpace + xAccess.wOffset +
        xNetWrapper.pxIfConf[oIfIdx].oL3TrailerLength;

#ifdef IPSEC
      /* allocate more space for ESP trailer and ESP-Auth */
      pxNetId->wIpSecTrailLength =
        IPSecGetTrailLen((void *)pxNetId->dwSecurityPolicy,
                         wTxAvailableSpace + wTransportHdrSize);
      wSize += pxNetId->wIpSecTrailLength;
#endif /* IPSEC */

      /* Make sure it is big enough */
      if (wSize < xNetWrapper.pxIfConf[oIfIdx].wLtu) {
        wSize = xNetWrapper.pxIfConf[oIfIdx].wLtu;
      }

      poPayload = (OCTET *)MALLOC(wSize);
      ASSERT(poPayload != NULL);

      xAccess.wLength = wTxAvailableSpace;

      return (void*)(poPayload + xAccess.wOffset); /* return - RS */
#else
      poPayload = ((OCTET *)pvBuff) - xAccess.wOffset;
      NetFree(poPayload);
#endif
    }
  }
  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
}

/*
 * mn_sock_free_recvbuf
 *  Free the buffer pointer retruned in recv()/recvfrom() for zero-copy
 *
 *  Args:
 *  pFreeArg         Arg returned in recv()/recvfrom()
 *
 *  Return:
 *   void:
 */

void mn_sock_free_recvbuf(void *pFreeArg)
{
   NETPAYLOAD *pxPayload  = (NETPAYLOAD *)pFreeArg;
   NETPAYLOAD_CHECK(pxPayload);
   RTOS_recursiveMutexWait(&xNetWrapper.xMutex);
   NETPAYLOAD_DELUSER(pxPayload);
   RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
}


#ifdef __TCP_USE_SEGMENTS__
/*
 * mn_sock_free_recvsegment
 *  Free the segment pointer retruned in recv()/recvfrom() for zero-copy
 *
 *  Args:
 *  pFreeArg         Arg returned in recv()/recvfrom()
 *
 *  Return:
 *   void:
 */

void mn_sock_free_recvsegment(void *pFreeArg)
{
   segmentStructure *pxSegment = (segmentStructure *)pFreeArg;
   segmentStructure *pxNextSegment  = NULL;
   NETPAYLOAD *pxPayload  ;
   while (pxSegment) {
       pxPayload  = (NETPAYLOAD *) pxSegment->pFreeArg;
       NETPAYLOAD_CHECK(pxPayload);
#ifdef __TCP_SEND_SEGMENT__
       RTOS_recursiveMutexWait(&xNetWrapper.xMutex);
#endif
       NETPAYLOAD_DELUSER(pxPayload);
#ifdef __TCP_SEND_SEGMENT__
       RTOS_recursiveMutexRelease(&xNetWrapper.xMutex);
#endif
       pxNextSegment = pxSegment->pNextSegment;
       FREE (pxSegment);
       pxSegment = pxNextSegment;
   }
}
#endif
/*
 * SocketRecv
 *  Supports read() on fd returned from socket operation
 *
 *  Args:
 *   pxInode                     the inode read from
 *   pxFile                      file structure for inode
 *   pBuf                        buffer for rx packet
 *   dwCnt                       buffer size
 *
 *  Return:
 *   result of recv
 */
LONG SocketRecv(INODE *pxInode, struct file *pxFile, void *pBuf, ubyte4 dwCnt)
{
#ifndef  __MOCANA_ASYNC_API__
  return(mn_recv((int)pxFile->private_data, pBuf, dwCnt,0, NULL, NULL,
        NULL, NULL));
#else
  return(mn_recv((int)pxFile->private_data, pBuf, dwCnt,0));
#endif
}

/*
 * SocketSend
 *  Supports write() on fd returned from socket operation
 *
 *  Args:
 *   pxInode                       the inode written to
 *   pxFile                        file structure for inode
 *   pBuf                          tx packet
 *   dwCnt                         packet size
 *
 *  Return:
 *   result of send
 */
LONG SocketSend(INODE *pxInode, struct file *pxFile, void *pBuf, ubyte4 dwCnt)
{
  return send((int)pxFile->private_data, pBuf, dwCnt,0);
}









ubyte4 _SocketReadTcp(SOCKET *pxSock, void *pvBuff, ubyte4 nbytes,
                 struct sockaddr *pxSockAddrFrom, socklen_t *addrlen,
            void **ppvBuff, void **ppFreeArg)
{
    /* TCP socket */
    TCPSOCKET *pxTcp;
    TCPCONNECT *pxConnect;
    H_NETINSTANCE hTcp;
    NETPACKET xPacket;
    NETPAYLOAD xPayload;
    ubyte4 lReturn;

    SOCKET_ASSERT(pxSock->lType == SOCK_STREAM);


    pxTcp = pxSock->u.pxTcp;
    SOCKET_ASSERT(pxTcp != NULL);

    pxConnect = pxTcp->u.pxConnect;
    SOCKET_ASSERT(pxConnect != NULL);

    hTcp = xSocketRep.axProtocols[TCP_INDEX].hInst;

    xPacket.hMarker = (H_NETDATA)pxSock;
    /* SB Feb-2002. Use local variables for payload !!! We know it is
       not going to be kept. !!! Maybe that must change !!! */
    xPacket.pxPayload = &(xPayload);
    xPayload.pfnFree = NetFree;
#ifdef NET_ASYNC
    xPayload.pxMutex = &(xNetWrapper.xMutex);
#endif

    if ( ppvBuff ) {

       /* we send in our payload struct with ppvBuff, TCP stores data begin
        * in ppvBuff, and then saves its own payload ptr in packet struct
        */
       xPayload.poPayload = (OCTET *)ppvBuff;
       xPayload.wSize = 0;

       TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                TCPULINTERFACEIOCTL_GETRXDATA_PAYLOAD,
                                (H_NETDATA) &(xPacket));

       *ppFreeArg = xPacket.pxPayload;

    } else{
       xPayload.poPayload = (OCTET *)pvBuff;
       xPayload.wSize = nbytes;

       TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                TCPULINTERFACEIOCTL_GETRXDATA,
                                (H_NETDATA) &(xPacket));
    }
    /* No need to lock the payload: we are the owner and user */
    lReturn = xPacket.pxPayload->wSize;
#if 0
    pxSock->poAppBuffer = NULL;
    pxSock->wAppBufferUsedLength = 0;
    pxSock->wAppBufferSize = 0;
#endif

    if (pxSockAddrFrom != NULL) {
      /* should happen rarely, as recv is used in tcp, more than
         recvfrom. Needs to ask the TCP module for this info.
         (If it was happening more often: 1. tell the app implementers
         it is bad policy 2. keep a local copy)
         */
      pxSockAddrFrom->sa_len = *addrlen = sizeof(struct sockaddr_in);
      pxSockAddrFrom->sa_family = AF_INET;
      TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                  NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEIP,
                                  (H_NETDATA)
                                  &(((struct sockaddr_in *)pxSockAddrFrom)->sin_addr.s_addr));

      TcpInstanceULInterfaceIoctl(hTcp,pxSock->hLL,
                                  NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEPORT,
                                  (H_NETDATA)
                                  &(((struct sockaddr_in *)pxSockAddrFrom)->sin_port));
      ((struct sockaddr_in *)pxSockAddrFrom)->sin_addr.s_addr =
        htonl(((struct sockaddr_in *)pxSockAddrFrom)->sin_addr.s_addr);
      ((struct sockaddr_in *)pxSockAddrFrom)->sin_port =
        htons(((struct sockaddr_in *)pxSockAddrFrom)->sin_port);
    }

#if 0
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
    return lReturn;
}
