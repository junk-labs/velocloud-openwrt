/*
 * hmac_md5.h
 *
 * HMAC-MD5 algorithm API.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _HMAC_MD5_H_
#define _HMAC_MD5_H_


/*****************************************************************************
 *
 * Function prototypes
 *
 *****************************************************************************/

/*****************************************************************************
 * hmac_md5
 * generate message digest using HMAC-MD5 algorithm
 *   poText : pointer to data stream
 *   dwTextLen :length of data stream
 *   poKey : pointer to authentication key
 *   dwKeyLen : length of authentication key
 *   poDigest : pointer to caller digest to be filled in (should be allocated)
 *****************************************************************************/
void hmac_md5(OCTET* poText,
              DWORD dwTextLen,
              OCTET* poKey,
              DWORD dwKeyLen,
              OCTET* poDigest);

#endif
/* //////////////////////////////// End of File //////////////////////////////// */

