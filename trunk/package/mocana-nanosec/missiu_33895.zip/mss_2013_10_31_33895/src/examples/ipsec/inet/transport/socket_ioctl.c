/*
 * socket_ioctl.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"

#ifdef IPSEC
#include "ipsec.h"
#if 0
/* IPSEC is not configed by us */
#include "ipsec_api.h"
#endif
#endif /* IPSEC */

#ifdef SOCK_RT
  #include "router.h"
  #include "nat.h"
#endif

#ifdef SOCK_BR
  #include "ethernet.h"
#endif

#ifdef DHCP_CUSTOM_OPTIONS
  #include "dhcpclient.h"
#endif /*DHCP_CUSTOM_OPTIONS */

#ifdef IPFRAG
  #include "netmain.h"
  #include "ipfrag.h"
#endif /*#ifdef IPFRAG*/


/****************************************************************************
 *
 * local function
 *
 ****************************************************************************/
LONG SocketIoctlCallBack(DWORD dwRequest, mnIoctlArgList_t *xArgList);
LONG SocketIoctlLimiter(DWORD dwRequest, mnIoctlArgList_t *xArgList);

/*
 * SocketIoctl
 *  Handle ioctl requests for socket file descriptors
 *
 *  Arg:
 *   inode                           the inode for the ioctled fd
 *   pxFile                          file structure for ioctled fd.
 *   dwRequest                       ioctl request code
 *   pArgList                        variable argument list
 *
 *  Return:                          0 success, -1 failure
 */
LONG SocketIoctl(INODE* inode, struct file *pxFile, DWORD dwRequest,
                 mnIoctlArgList_t *pArgList)
{
  LONG lReturn = 0;
  LONG lFd;

  /*
   * lock the mutex for the all function.
   * Despite its length, there is not much processing,
   * and all bits need protection
   */
  /* RS: whith multiple interfaces, we deadlock with dns if we call DnsMsg() */
  /*RTOS_recusiveMutexWait(&(xNetWrapper.xMutex)); */

  if ((dwRequest == MO_SIOCOPEN) || (dwRequest == MO_SIOCACCEPT)) {
    LONG lFamily,lType,lProtocol;
    H_NETINTERFACE hIf = (H_NETINTERFACE)0;

    /* Open the socket. Can do without, as that's where the
       file descriptor private data is set */

    lFd =       pArgList->lFd;
    lFamily =   pArgList->lFamily;
    lType =     pArgList->lType;
    lProtocol = pArgList->lProtocol;

    if (dwRequest == MO_SIOCACCEPT) {
      hIf = (H_NETINTERFACE)pArgList->hIf;
    }

    pxFile->private_data = (void *)lFd;

    if (SocketCreate(lFd,lFamily,lType,lProtocol,hIf) < 0) {
      ASSERT(0);
      mn_errno = MO_ENOBUFS;
      lReturn = -MO_ENOBUFS;
    }
  }
  else {
    SOCKET *pxSock;

    /* Early check : check if the socket is valid */
    lFd = (int) (pxFile->private_data);

    if ((pxSock = RETRIEVE_SOCKET(lFd)) == NULL) {
      /* Can't find socket, or wrong type (UDP/TCP) */
       /* RS: with multiple interfaces, we deadlock with dns if we call DnsMsg() */
       /*RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex)); */
      mn_errno = MO_EBADF;
      return -MO_EBADF;
    }

    if (dwRequest == FIONBIO) {
      /* Set a socket to blocking type */
      LONG lFlag;

      lFlag = pArgList->lFlag;

      if(lFlag) {
        pxSock->dwSockState |= SS_NBIO;
      } else {
        pxSock->dwSockState &= ~SS_NBIO;
      }
    }

    else
    if (dwRequest == MO_SIOCIFIBIND) {
      OCTET oIfIdx;
      OCTET oProtIdx;
      H_NETINSTANCE hInst;
      PFN_NETIOCTL pfnIoctl;

      oIfIdx = pArgList->oIfIdx;

#ifndef SOCK_MULTIF
      ASSERT(oIfIdx == 0);
#endif
      pxSock->xTransportId.xNetId.oIfIdx = oIfIdx;
      pxSock->oBoundFlag |= SOCKETBOUNDFLAG_IF;

      oProtIdx = SOCKTYPE2PROTINDEX(pxSock->lType);
      hInst = xSocketRep.axProtocols[oProtIdx].hInst;
      pfnIoctl = xSocketRep.axProtocols[oProtIdx].pfnIoctl;

      pfnIoctl(hInst,pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_SETIF,
               (H_NETDATA)oIfIdx);
    }

    else if (dwRequest == MO_SIOCGIFNUM) {
      OCTET *poIfNum;

      /* Get the number of interfaces */
      poIfNum = (OCTET *)pArgList->oIfNum;
      *poIfNum = xNetWrapper.oIfNumber;

    }
    else if (dwRequest < MO_SIOCIF_START) {
      /*
       * Route Add/Delete message
       */
      struct rtentry *pxRtEntry;
      ROUTEENTRY xRouteEntry;

      pxRtEntry = (struct rtentry*)pArgList->pxRtEntry;
      ASSERT(pxRtEntry);

      xRouteEntry.dwGateway =
        ((struct sockaddr_in*) &pxRtEntry->rt_gateway)->sin_addr.s_addr;
#ifdef _RADIX_ROUTING_ON_
      xRouteEntry.xRouteNodes->RadixNodeMask =
        ((struct sockaddr_in*) &pxRtEntry->rt_genmask)->sin_addr.s_addr;
      xRouteEntry.xRouteNodes->RadixNodeKey =
        ((struct sockaddr_in*) &pxRtEntry->rt_dst)->sin_addr.s_addr;
#else
      xRouteEntry.dwSubnetMask =
        ((struct sockaddr_in*) &pxRtEntry->rt_genmask)->sin_addr.s_addr;
      xRouteEntry.dwDstAddr =
        ((struct sockaddr_in*) &pxRtEntry->rt_dst)->sin_addr.s_addr;
#endif
      xRouteEntry.wMetric = pxRtEntry->rt_metric;
      xRouteEntry.wTOS = pxRtEntry->rt_tos;
      xRouteEntry.oIfIdx = pxRtEntry->rt_ifindex;
      xRouteEntry.wVlan = NETVLAN_ANY;

      (dwRequest == MO_SIOCADDRT) ?
        (RoutingTableMsg(ROUTINGTABLEMSG_ADDROUTE,
                         (H_NETDATA)&xRouteEntry)) :
        (RoutingTableMsg(ROUTINGTABLEMSG_DELROUTE,
                         (H_NETDATA)&xRouteEntry));
    }
    else if (dwRequest < MO_SIOCIFISTR_START) {

      /*
       * SCIOIFI ioctls
       *   Interface ioctls based on ifreq structure
       *   Used for setting addresses and integer values
       */

      OCTET oIfIdx;      /* Interface index */

      struct ifreq *pxIfReq =  NULL;

      pxIfReq = (struct ifreq *)pArgList->ifreq;

      ASSERT(pxIfReq != NULL);

      oIfIdx = 0xFF;

      /* JJ oIfIdx = pxIfReq->ifr_name[0]; */
      /* DOnt knwo why the struct is getting corrupted */
      /*oIfIdx =  0; */
      oIfIdx = pxIfReq->ifr_name[0];

      if (oIfIdx >= xNetWrapper.oIfNumber) {
        ASSERT(0);
        lReturn = -MO_EINVAL;
        mn_errno = MO_EINVAL;
      }
      else {
        int iValue;
        int *piValue;
        DWORD dwAddr;
        DWORD *pdwAddr;
        NETIFCONF *pxIfConf;
        IPCONF *pxIPConf;

        /* Variable factorisation */
        pdwAddr = (DWORD *)
          &(((struct sockaddr_in *) &(pxIfReq->ifr_addr))->sin_addr.s_addr);
        dwAddr = *pdwAddr;
        piValue = &(pxIfReq->ifr_value);
        iValue = *piValue;

        pxIfConf = xNetWrapper.pxIfConf + oIfIdx;

        if(pxIfConf->pxIPAlias == NULL){
          pxIfConf->pxIPAlias = (IPCONF*)MALLOC(sizeof(IPCONF));
          MOC_MEMSET((ubyte *)(pxIfConf->pxIPAlias), 0, sizeof(IPCONF));
          pxIfConf->oIPAliasNumber = 1;
        }

        pxIPConf = pxIfConf->pxIPAlias;
        SOCKET_ASSERT(pxIPConf != NULL);

        switch(dwRequest) {

        case MO_SIOCSIFIADDR:
          {
            pxIPConf->dwAddr = dwAddr;

           if (dwAddr == 0) {
             NETIF_UNSETFLAG(pxIfConf->oFlags,IFF_IPUP);
           } else {
             IPTABLEENTRY xEntry;
             xEntry.dwAddr = dwAddr;
             xEntry.oIfIdx = oIfIdx;
             xEntry.wDefaultVlan = NETVLAN_ANY;
             xEntry.u.dwIpNetMask = 0;
             xEntry.eAddrType = IPADDRT_MYADDR;
             IpTableMsg(IPTABLEMSG_SETADDR,(H_NETDATA)&xEntry);
             NetMainMsg(NETMAINMSG_IFIPUP,(H_NETDATA)oIfIdx);
           }
          }
          break;

#ifdef SOCK_PPP
        case MO_SIOCDIFADDR:
          {
            ROUTEENTRY xRouteEntry;
#ifdef _RADIX_ROUTING_ON_
            xRouteEntry.xRouteNodes->RadixNodeMask = dwAddr;
            xRouteEntry.xRouteNodes->RadixNodeKey  = 0;
#else
            xRouteEntry.dwGateway = dwAddr;
            xRouteEntry.dwDstAddr = 0;
#endif
            xRouteEntry.oIfIdx = oIfIdx;
            xRouteEntry.wVlan = NETVLAN_ANY;

            RoutingTableMsg(ROUTINGTABLEMSG_DELROUTE,
                            (H_NETDATA)&xRouteEntry);
           }
          break;
        case MO_SIOCSIFIDSTADDR:
          /* Set the PPP peer address in the Ip Table */
          {
            IPTABLEENTRY xEntry;

            xEntry.oIfIdx = (OCTET)oIfIdx;
            xEntry.wDefaultVlan = NETVLAN_ANY;
            xEntry.u.dwIpNetMask = 0xFFFFFFFF;
            xEntry.eAddrType = IPADDRT_PPPPEER;
            xEntry.dwAddr = dwAddr;
            IpTableMsg(IPTABLEMSG_SETADDR,(H_NETDATA)&xEntry);
          }
        /* Fall through */
#endif
        case MO_SIOCSIFIGWADDR:/* Set Gateway address */
          /* !!! Dst and Gw address coincide !!! */
          {
            ROUTEENTRY xRouteEntry;
            static sbyte oSysRoute = 1;

#ifdef _RADIX_ROUTING_ON_
            xRouteEntry.xRouteNodes->RadixNodeMask = 0;
            xRouteEntry.xRouteNodes->RadixNodeKey = 0;
#else
            xRouteEntry.dwSubnetMask = 0;
            xRouteEntry.dwDstAddr = 0;
#endif
            xRouteEntry.wMetric = 2;
            xRouteEntry.wTOS = 0;
            xRouteEntry.oIfIdx = oIfIdx;
            xRouteEntry.wVlan = NETVLAN_ANY;

            if (pxIPConf->uLink.xPppData.dwDstAddr != dwAddr) {
              xRouteEntry.dwGateway = pxIPConf->uLink.xPppData.dwDstAddr;
#ifndef _RADIX_ROUTING_ON_
              /* Delete current route */
              RoutingTableMsg(ROUTINGTABLEMSG_DELROUTE,
                              (H_NETDATA)&xRouteEntry);
#endif
            }

            pxIPConf->uLink.xPppData.dwDstAddr = dwAddr;

            printf("*************Added GW Route *********%x\n",dwAddr);
            /* Add new route if the interface is up and the address
               is valid */
            if (dwAddr != 0) {
              xRouteEntry.dwGateway = dwAddr;
#ifdef _RADIX_ROUTING_ON_
              xRouteEntry.xRouteNodes->RadixNodeMask = pxIPConf->dwNetMask;
              xRouteEntry.xRouteNodes->RadixNodeKey  = pxIPConf->dwAddr;
#else
              xRouteEntry.dwSubnetMask = 0;
              xRouteEntry.dwDstAddr = 0;
#endif
              xRouteEntry.wMetric = 2;
              xRouteEntry.wTOS = 0;
              xRouteEntry.oIfIdx = oIfIdx;
              xRouteEntry.wVlan = NETVLAN_ANY;

              RoutingTableMsg(ROUTINGTABLEMSG_ADDROUTE,
                              (H_NETDATA)&xRouteEntry);
#ifdef _RADIX_ROUTING_ON_
              /*IP 0.0.0.0 & Mask 0.0.0.0 added once, and the first gateway addr is taken
                Needs to change once we have configuration with sets the default g/w*/
              if(oSysRoute)
              {
                xRouteEntry.xRouteNodes->RadixNodeMask = 0;
                xRouteEntry.xRouteNodes->RadixNodeKey  = 0;
                RoutingTableMsg(ROUTINGTABLEMSG_ADDROUTE,
                                (H_NETDATA)&xRouteEntry);
                oSysRoute = 0;
              }
#endif
            }
          }
          break;

        case MO_SIOCSIFIBRDADDR: /* Set broadcast address */
            pxIPConf->dwBroadcast = dwAddr;
          break;

        case MO_SIOCSIFINETMASK: /* Set Net mask */
          pxIPConf->dwNetMask = dwAddr;

          {
            IPTABLEENTRY xEntry;

            xEntry.dwAddr = pxIPConf->dwAddr;
            xEntry.oIfIdx = oIfIdx;
            xEntry.wDefaultVlan = NETVLAN_ANY;
            xEntry.eAddrType = IPADDRT_ANY;
            xEntry.u.dwIpNetMask = dwAddr;
            IpTableMsg(IPTABLEMSG_SETNETMASK,(H_NETDATA)&xEntry);
          }
          break;

        case MO_SIOCGIFIADDR:   /* Get IP Addr */
          if (pxIfConf->oFlags & IFF_IPUP) {
            *pdwAddr = pxIPConf->dwAddr;
          }
          else {
            *pdwAddr = 0;
          }
          break;

#ifdef SOCK_PPP
        case MO_SIOCGIFIDSTADDR:
#endif
        case MO_SIOCGIFIGWADDR:
          /* !!! Dst and Gw address coincide !!! */
          *pdwAddr = pxIPConf->uLink.xPppData.dwDstAddr;
          break;

        case MO_SIOCGIFIBRDADDR:/* Get broadcast address */
          *pdwAddr = pxIPConf->dwBroadcast;
          break;

        case MO_SIOCGIFINETMASK: /* Get NetMask */
          *pdwAddr = pxIPConf->dwNetMask;
          break;

        case MO_SIOCGIFIMTU:/* Get Mtu */
          *piValue = pxIfConf->wMtu;
          break;

        case MO_SIOCSIFIMTU:/* Set Mtu */
          pxIfConf->wMtu = (WORD)iValue;
#ifdef IPFRAG
         {
             MTUREQUEST xMtuRequest;
             H_NETINSTANCE hIpFragInst = NETGETINST_IPFRAG;

             xMtuRequest.oIfIndex = oIfIdx;
             xMtuRequest.wMtu     = xNetWrapper.pxIfConf[oIfIdx].wMtu;
             (LONG)IpFragInstanceSet(hIpFragInst,IPFRAGOPTION_MTU,(H_NETDATA)&xMtuRequest);
         }
#endif /*#ifdef IPFRAG*/
#ifdef ROUTER
         /*
          * Inform the router about the MTU of the interface
          */
         {
            ROUTERSETIFMTU xRouterSetIfMtu;
            H_NETINSTANCE hRouterInst = NETGETINST_ROUTER;

            xRouterSetIfMtu.oIfIdx = oIfIdx;
            xRouterSetIfMtu.wMtu   = xNetWrapper.pxIfConf[oIfIdx].wMtu;
            (LONG)RouterInstanceMsg(hRouterInst, ROUTERMSG_SETIFMTU, (H_NETDATA)&xRouterSetIfMtu);
         }
#endif

          break;

        case MO_SIOCGIFIDLADDR:/* Get hardware address */
          {
            struct sockaddr_dl * pxDLAddr;

            ASSERT(pxIfReq->ifr_addr.sa_len == sizeof(struct sockaddr_dl));

            pxDLAddr = (struct sockaddr_dl *)&(pxIfReq->ifr_addr);

            /* Set the interface name length to 0, as it is not needed */
            pxDLAddr->sdl_nlen = 0;
            pxDLAddr->sdl_index = oIfIdx;

            pxDLAddr->sdl_type = pxIfConf->oType;
            pxDLAddr->sdl_alen = pxIfConf->oHWAddrLength;
            MOC_MEMCPY((ubyte *)pxDLAddr->sdl_data,
                   (ubyte *)pxIfConf->aoHWAddr,
                   pxIfConf->oHWAddrLength);

          }
          break;

        case MO_SIOCSIFIDLADDR:/* Set hardware address */
          {
            struct sockaddr_dl * pxDLAddr;

            ASSERT(pxIfReq->ifr_addr.sa_len == sizeof(struct sockaddr_dl) &&
              ((struct sockaddr_dl *)&(pxIfReq->ifr_addr))->sdl_alen <= MAX_HWADDR);

            pxDLAddr = (struct sockaddr_dl *)&(pxIfReq->ifr_addr);

            pxIfConf->oHWAddrLength = pxDLAddr->sdl_alen;

            MOC_MEMCPY((ubyte *)pxIfConf->aoHWAddr,
                  (ubyte *)pxDLAddr->sdl_data,
                  pxIfConf->oHWAddrLength);
            if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, NORMAL))
            {
                DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"Setting interface ",
                    (WORD)oIfIdx);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," HW addr ",
                    pxIfConf->aoHWAddr[0]);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,".",
                    pxIfConf->aoHWAddr[1]);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,".",
                    pxIfConf->aoHWAddr[2]);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,".",
                    pxIfConf->aoHWAddr[3]);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,".",
                    pxIfConf->aoHWAddr[4]);
                DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,".",
                    pxIfConf->aoHWAddr[5]);
                DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
            }
          }
          break;

        case MO_SIOCGIFIDNS:       /* Get DNS */
          *pdwAddr = pxIPConf->dwDNSIPAddr;
          break;

#ifdef _ENABLE_DNS_
        case MO_SIOCSIFIDNS:       /* Set DNS */
          pxIPConf->dwDNSIPAddr = dwAddr;

          /* Update the interface DNS settings, if the
             interface is UP */
          /* JJ DHCP Shoudl have brough the inyterface UP */
          /*  if (pxIfConf->oFlags & IFF_UP) */
          if (pxIfConf->oFlags & IFF_UP) /* RS put it back */
      {
            DnsMsg(DNSMSG_IFUPDATE,oIfIdx);
          }
          break;
#endif /* _ENABLE_DNS_ */

        case MO_SIOCSIFINTP:       /* Set Ntp */
          pxIPConf->dwNTPIPAddr = dwAddr;
          break;

        case MO_SIOCGIFINTP:       /* Get Ntp */
          *pdwAddr = pxIPConf->dwNTPIPAddr;
          break;

        case MO_SIOCSIFILTU:       /* Set Ltu */
          pxIfConf->wLtu = (WORD)iValue;
          break;

        case MO_SIOCGIFILTU:       /* Get Ltu */
          *piValue = pxIfConf->wLtu;
          break;

        case MO_SIOCSIFITYPE:/* Set If type */
#ifndef SOCK_EP0
          if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, NORMAL))
          {
              DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,"Setting interface ",
                  (WORD)oIfIdx);
              DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, " type to ",
                  (DWORD)pxIfReq->ifr_type);
              DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
          }
          if (pxIfConf->oType != (OCTET) iValue) {

            if ((pxIfConf->oFlags & (OCTET)IFF_UP) != 0x00) {
              /* Can't change the type of an opened if */
              ASSERT(0);
              lReturn = -MO_EINVAL;
              mn_errno = MO_EINVAL;
              break;
            }

            NetMainMsg(NETMAINMSG_IFTEARDOWN,(H_NETDATA)oIfIdx);

#ifndef SOCK_ATM
            ASSERT((iValue == IFT_ETHER) ||
                   (iValue == IFT_PPPOE));
#else
            ASSERT((iValue == IFT_ETHER) ||
                   (iValue == IFT_PPPOE) ||
                   ((oIfIdx != 0) &&
                    ((iValue == IFT_NULL) ||
                     (iValue == IFT_PPP))));
#endif
            pxIfConf->oType = (OCTET) iValue;

            if ((pxIfConf->oType == IFT_PPPOE) ||
                (pxIfConf->oType == IFT_PPP)) {
              pxIfConf->oFlags |= IFF_PP | IFF_DYNAMIC;
            }
            else {
              pxIfConf->oFlags &= ~IFF_PP;
            }
          }
#else
          ASSERT(iValue == IFT_ETHER);
          pxIfConf->oType = IFT_ETHER;
#endif
          break;

        case MO_SIOCGIFITYPE:/* Get If type */
          *piValue = (int)pxIfConf->oType;
          break;

        case MO_SIOCIFIOPEN: /* Open If */
          NetMainMsg(NETMAINMSG_IFOPEN,(H_NETDATA)oIfIdx);
          break;

        case MO_SIOCIFICLOSE:/* Close If */
          NetMainMsg(NETMAINMSG_IFCLOSE,(H_NETDATA)oIfIdx);
          break;

        case MO_SIOCIFIDISABLE:/* Disable If */
          NetMainMsg(NETMAINMSG_IFTEARDOWN,(H_NETDATA)oIfIdx);
          break;

        case MO_SIOCSIFIFLAG:/* Set If flag */
          /*
           * For now, the only flag which may be set
           * is the IFF_DYNAMIC flag to indicate whether
           * an interface should use DHCP or not
           */
          if (iValue & IFF_DYNAMIC) {
            pxIfConf->oFlags |= IFF_DYNAMIC;
          } else {
            pxIfConf->oFlags &= ~IFF_DYNAMIC;
          }
          if (iValue & IFF_LOGICAL) {
            pxIfConf->oFlags |= IFF_LOGICAL;
          } else {
            pxIfConf->oFlags &= ~IFF_LOGICAL;
          }
          break;

        case MO_SIOCGIFIFLAG:  /* Get If flag */
          *piValue = (int) pxIfConf->oFlags;
          break;

        case MO_SIOCSIFITOS:       /* Set If TOS */
          pxIfConf->oTos = (OCTET) iValue;
          break;

        case MO_SIOCSIFIVLAN:      /* Set If VLAN */
          pxIfConf->wVlan = (WORD) iValue;
          break;

        case MO_SIOCGIFIVLAN:      /* Get If VLAN */
          *piValue = (int) pxIfConf->wVlan;
          break;

        case MO_SIOCIFIPINGDIS:/* Set If PING disable */
          {
            DWORD dwData = (iValue & 0xFFFF);
            ASSERT(oIfIdx < 16);
            dwData = dwData | (oIfIdx << 16);
            IcmpInstanceMsg(xSocketRep.hIcmp,ICMPMSG_DONTREPLYTOPING,
                            (H_NETDATA)dwData);
          }
          break;

#ifdef SOCK_ATM
        /*
         * ATM set ioctls
         */
        case MO_SIOCSIFIATMVPI:
        case MO_SIOCSIFIATMVCI:
        case MO_SIOCSIFIATMMODE:
        case MO_SIOCSIFIATMLATENCY:
          {
            OCTET* poValue;

            poValue =
              (dwRequest == MO_SIOCSIFIATMVPI) ? &(pxIfConf->xAtmConf.oVpi) :
              (dwRequest == MO_SIOCSIFIATMVCI) ? &(pxIfConf->xAtmConf.oVci) :
              (dwRequest == MO_SIOCSIFIATMMODE) ? &(pxIfConf->xAtmConf.oMode) :
              &(pxIfConf->xAtmConf.oLatency);

            *poValue = (OCTET)iValue;
          }
          break;


        /*
         * ATM get ioctls
         */
        case MO_SIOCGIFIATMVPI:
        case MO_SIOCGIFIATMVCI:
        case MO_SIOCGIFIATMMODE:
        case MO_SIOCGIFIATMLATENCY:
          *piValue =
            (dwRequest == MO_SIOCGIFIATMVPI) ? (int)pxIfConf->xAtmConf.oVpi :
            (dwRequest == MO_SIOCGIFIATMVCI) ? (int)pxIfConf->xAtmConf.oVci :
            (dwRequest == MO_SIOCGIFIATMMODE) ? (int)pxIfConf->xAtmConf.oMode :
            (int)pxIfConf->xAtmConf.oLatency;

          break;
#endif

#ifdef SOCK_PPP
        /*
         * PPP ioctls
         */
        case MO_SIOCGIFIPPPIDLETO:
          *piValue = pxIfConf->xPppConf.dwPppIdleTO;
          break;
        case MO_SIOCSIFIPPPIDLETO: /* PPP idle timeout */
          pxIfConf->xPppConf.dwPppIdleTO = (DWORD) iValue;
          break;
        case MO_SIOCGIFIPPPECHOTO:
          *piValue = pxIfConf->xPppConf.dwPppEchoTO;
          break;
        case MO_SIOCSIFIPPPECHOTO: /* PPP echo timeout */
          pxIfConf->xPppConf.dwPppEchoTO = (DWORD) iValue;
          break;
        case MO_SIOCGIFIPPPECHOCOUNT:
          *piValue = pxIfConf->xPppConf.dwPppEchoCount;
          break;
        case MO_SIOCSIFIPPPECHOCOUNT: /* PPP echo count */
          pxIfConf->xPppConf.dwPppEchoCount = (DWORD) iValue;
          break;
#endif

#ifdef SOCK_BR
        case MO_SIOCIFIBRENABLE:
          /* Enable bridging on an interface
           * N.B. Two or more interface must have bridging enabled for any
           * bridge activity to occur */
          pxIfConf->xEthConf.obBridge = (OCTET)iValue;
#ifdef SOCK_RT
          {
            ROUTERSETROUTINGSTATUS xRouterSetRoutingStatus;

            xRouterSetRoutingStatus.oIfIdx = oIfIdx;
            xRouterSetRoutingStatus.bDisabled = (BOOL)iValue;

            RouterInstanceMsg(xSocketRep.hRouter,
                              ROUTERMSG_SETROUTINGSTATUS,
                              (H_NETDATA) &xRouterSetRoutingStatus);
          }
          {
            ROUTESETBRIDGEDIDX xRouteSetBridgedIdx;

            xRouteSetBridgedIdx.oIfIdx = oIfIdx;
            xRouteSetBridgedIdx.bBridged = (BOOL)iValue;

            RoutingTableMsg(ROUTINGTABLEMSG_SETBRIDGEDIDX,
                                    (H_NETDATA) &xRouteSetBridgedIdx);
          }
#endif
          break;

        case MO_SIOCGIFIBRENABLE:
          *piValue = pxIfConf->xEthConf.obBridge;
          break;

        /* Specify the interface that corresponds to the LAN */
        case MO_SIOCSIFIBRLANIF:
          lReturn = EthInstanceMsg(xSocketRep.hEth,ETHMSG_SETLANIF,
                                   (H_NETDATA)oIfIdx);
          break;

        /* Set the broadcast limit on an interface (in %) */
        case MO_SIOCSIFIBRBCASTLIMIT:
          pxIfConf->xEthConf.oBcastLimit = (OCTET)iValue;
          break;

        case MO_SIOCGIFIBRBCASTLIMIT:
          *piValue = pxIfConf->xEthConf.oBcastLimit;
          break;

        /* Set the multicast limit on an interface (in %) */
        case MO_SIOCSIFIBRMCASTLIMIT:
          pxIfConf->xEthConf.oMcastLimit = (OCTET)iValue;
          break;

        case MO_SIOCGIFIBRMCASTLIMIT:
          *piValue = pxIfConf->xEthConf.oMcastLimit;
          break;

        /* Get the state of a bridged interface
         * e.g. Blocking, Forwarding etc.*/
        case MO_SIOCGIFIBRIFSTATE:
          {
            ETHIFSTATE xEthState;
            xEthState.oIfIdx = oIfIdx;
            EthInstanceMsg(xSocketRep.hEth,ETHMSG_GETIFSTATE,
                           (H_NETDATA)(&xEthState));
            *piValue = xEthState.eState;
          }
          break;

        /* Enable/disable the PPPoE filter.  If enabled,
         * the bridge will only forward PPPoE packets.*/
        case MO_SIOCIFIBRPPPOE:
          EthInstanceMsg(xSocketRep.hEth,ETHMSG_FORWARDPPPOEONLY,
                         (H_NETDATA)iValue);
          break;

        /* Set the initial Spanning tree state of an if. NB: The state
         * may change after the spanning tree is started. */
        case MO_SIOCIFBRINITIALIFSTATE:
          {
            ETHIFSTATE xEthState;
            xEthState.oIfIdx = oIfIdx;
            xEthState.eState = (E_ETHIFSTAT)iValue;

            EthInstanceMsg(xSocketRep.hEth,ETHMSG_SETINITIALIFSTATE,
                           (H_NETDATA)&xEthState);
          }
          break;

#endif
#ifdef LINK_AGGREGATION
          case MO_SIOCIFIAGGRADD:
          {
             NETIFAGGR aggr;
             aggr.oLIfIdx = oIfIdx;
             aggr.oPIfIdx = iValue;
             NetMainMsg(NETMAINMSG_IFAGGRADD,(H_NETDATA)&aggr);
          }
          break;
          case MO_SIOCIFIAGGRDEL:
          {
             NETIFAGGR aggr;
             aggr.oLIfIdx = oIfIdx;
             aggr.oPIfIdx = iValue;
             NetMainMsg(NETMAINMSG_IFAGGRDEL,(H_NETDATA)&aggr);
          }
          break;
#endif
        default:
          lReturn = -MO_EINVAL;
          mn_errno = MO_EINVAL;
          ASSERT(0);
          break;

        } /* end if ioctl switch */
      }
    }
    else if (dwRequest < MO_SIOCIFISTR_END) {

      /*
       * SCIOIFI name ioctls
       *   Interface ioctls based on ifconf structure
       *   Used for setting string values and arrays
       *   of variable length
       */

      OCTET oIfIdx;
      struct ifconf *pxIfConf;

      printf(" MO_SIOCIFISTR_END %x dwReq %x \n", MO_SIOCIFISTR_END,dwRequest);
      /* JJ oIfIdx = va_arg(pArgList, OCTET); */
      oIfIdx = pArgList->oIfIdx;
      pxIfConf = (struct ifconf *)pArgList->ifconf;

      if (oIfIdx >= xNetWrapper.oIfNumber) {
        ASSERT(0);
        lReturn = -MO_EINVAL;
        mn_errno = MO_EINVAL;
      }
      else {
        NETIFCONF *pxNetIfConf;
        IPCONF *pxIPConf;

        pxNetIfConf = xNetWrapper.pxIfConf + oIfIdx;

        if(pxNetIfConf->pxIPAlias == NULL){
          pxNetIfConf->pxIPAlias = (IPCONF*)MALLOC(sizeof(IPCONF));
          MOC_MEMSET((ubyte *)(pxNetIfConf->pxIPAlias), 0, sizeof(IPCONF));
          pxNetIfConf->oIPAliasNumber = 1;
        }

        pxIPConf = pxNetIfConf->pxIPAlias;
        SOCKET_ASSERT(pxIPConf != NULL);

        switch (dwRequest) {

        /*
         * Get Ioctls
         */
        case MO_SIOCGIFIDN:       /* Get If Domain name  */
        case MO_SIOCGIFIHN:       /* Get If Host name */
        case MO_SIOCGIFICLIENTID: /* Get If DHCP Client ID */
          {
            char *pcName = NULL;
            LONG lLength = 0;
            pcName =
              (dwRequest == MO_SIOCGIFIDN) ? pxIPConf->pcDomainName:
              (dwRequest == MO_SIOCGIFIHN) ? pxIPConf->pcHostName:
              (char *)pxNetIfConf->pcDhcpClientId;

            if (pcName != NULL) {

              lLength = 1 + strlen(pcName);

              if (lLength > pxIfConf->ifc_len) {
                lLength = pxIfConf->ifc_len;
              }

              MOC_MEMCPY((ubyte *)pxIfConf->ifc_buf, (ubyte *)pcName, lLength);

              pxIfConf->ifc_len = lLength;

            }
            else {
              ASSERT(pxIfConf->ifc_len > 0);
              pxIfConf->ifc_buf[0] = 0;
              pxIfConf->ifc_len = 0;
            }
          }
          break;

        /*
         * Set Ioctls
         */
        case MO_SIOCSIFIDN:        /* Set If Domain name */
        case MO_SIOCSIFIHN:        /* Set If Host name */
        case MO_SIOCSIFICLIENTID:  /* Set If DHCP Client ID */
          {
            LONG lLength;
            char **ppcName = NULL;

            ppcName =
              (dwRequest == MO_SIOCSIFIDN) ? &(pxIPConf->pcDomainName):
              (dwRequest == MO_SIOCSIFIHN) ? &(pxIPConf->pcHostName):
              (char **)&(pxNetIfConf->pcDhcpClientId);

            if (*ppcName != NULL) {
              FREE(*ppcName);
              *ppcName = NULL;
            }

            if (pxIfConf->ifc_buf != NULL &&
                pxIfConf->ifc_len > 0 &&
                pxIfConf->ifc_len < MAX_NAME_LEN) {

              lLength = 1 + pxIfConf->ifc_len;

              if (lLength > MAX_NAME_LEN) {
                lLength = MAX_NAME_LEN;
              }

              *ppcName = (char *)MALLOC(lLength);

              MOC_MEMCPY((ubyte *)*ppcName,
                  (ubyte *)pxIfConf->ifc_buf,lLength-1);

              /* Make sure it is null terminated */
              *(*ppcName + lLength - 1) = 0;
            }

#ifdef _ENABLE_DNS_
            /* Update the DNS host name in the DNS client */
            if (dwRequest == MO_SIOCSIFIDN && pxNetIfConf->oFlags & IFF_UP) {
              DnsMsg(DNSMSG_IFUPDATE,oIfIdx);
            }
#endif /* _ENABLE_DNS_ */
          }
          break;

#if defined(SOCK_PPP)
        /*
         * PPP Ioctls
         */
        case MO_SIOCSIFIPPPNAME:   /* Set If PPP username */
        case MO_SIOCSIFIPPPPW:     /* Set If PPP password */
        case MO_SIOCSIFIPPPSRV:    /* Set If PPPoE service name */
        case MO_SIOCSIFIPPPAC:     /* Set If PPPoE AC name */
          {
            LONG lLength;
            char **ppcName = NULL;

            ppcName =
              (dwRequest == MO_SIOCSIFIPPPNAME) ? &(pxNetIfConf->xPppConf.pcPppUsername) :
              (dwRequest == MO_SIOCSIFIPPPPW) ? &(pxNetIfConf->xPppConf.pcPppPassword) :
              (dwRequest == MO_SIOCSIFIPPPSRV) ? &(pxNetIfConf->xPppConf.pcPppoESrv) :
              &(pxNetIfConf->xPppConf.pcPppoEAC);

            if (*ppcName != NULL) {
              FREE(*ppcName);
              *ppcName = NULL;
            }

            if (pxIfConf->ifc_buf != NULL &&
                pxIfConf->ifc_len > 0 &&
                pxIfConf->ifc_len < MAX_NAME_LEN) {

              lLength = 1 + pxIfConf->ifc_len;

              if (lLength > MAX_NAME_LEN) {
                lLength = MAX_NAME_LEN;
              }

              *ppcName = (char *)MALLOC(lLength);

              MOC_MEMCPY((ubyte *)*ppcName,
                  (ubyte *)pxIfConf->ifc_buf,lLength-1);

              /* Make sure it is null terminated */
              *(*ppcName + lLength - 1) = 0;
            }

          }
          break;

        /*
         * PPP Get Ioctls
         */
        case MO_SIOCGIFIPPPNAME:   /* Get If PPP username */
        case MO_SIOCGIFIPPPPW:     /* Get If PPP password */
        case MO_SIOCGIFIPPPSRV:    /* Get If PPPoE service name */
        case MO_SIOCGIFIPPPAC:     /* Get If PPPoE AC name */
          {
            char *pcName = NULL;

            pcName =
              (dwRequest == MO_SIOCGIFIPPPNAME) ? (pxNetIfConf->xPppConf.pcPppUsername) :
              (dwRequest == MO_SIOCGIFIPPPPW) ? (pxNetIfConf->xPppConf.pcPppPassword) :
              (dwRequest == MO_SIOCGIFIPPPSRV) ? (pxNetIfConf->xPppConf.pcPppoESrv) :
              (pxNetIfConf->xPppConf.pcPppoEAC);

            pxIfConf->ifc_buf = (caddr_t)pcName;
            pxIfConf->ifc_len = strlen(pcName);

          }
          break;

#endif /*#if defined(SOCK_PPP)*/

        default:
          lReturn = -MO_EINVAL;
          mn_errno = MO_EINVAL;
          ASSERT(0);
          break;
        }
      }
    }

#ifdef DHCP_CUSTOM_OPTIONS
    else if (dwRequest < MO_SIOCIFIDHCPCUSTOM_END) {

      /*
       * SCIOIFI custom dhcp client ioctls
       *   Interface ioctls used to manage the customising
       *   of a dhcp client on an interface
       */

      OCTET oIfIdx = va_arg(pArgList, OCTET);

      if (oIfIdx >= xNetWrapper.oIfNumber) {
        ASSERT(0);
        lReturn = -MO_EINVAL;
        mn_errno = MO_EINVAL;
      }
      else {
        NETIFCONF *pxNetIfConf;

        pxNetIfConf = xNetWrapper.pxIfConf + oIfIdx;

        switch (dwRequest) {

          /*
           * Add a custom dhcp option to the DLLIST
           */
        case MO_SIOCSIFIDHCPCUSTOMOPT:
          {
            DHCP_CUSTOM_OPTION *pxCustomOpt = va_arg(pArgList,DHCP_CUSTOM_OPTION *);
            DHCP_CUSTOM_OPTION *pxDLLCustomOpt;

            /* create DLLIST if it doesn't exist */
            if (!pxNetIfConf->pdllDhcpClientCustomOpts) {
              pxNetIfConf->pdllDhcpClientCustomOpts = new_DLLIST();
            }
            /* create new DHCP_CUSTOM_OPTION and append to DLLIST */
            pxDLLCustomOpt = (DHCP_CUSTOM_OPTION *) MALLOC(sizeof(DHCP_CUSTOM_OPTION));
            ASSERT(pxDLLCustomOpt);
            MOC_MEMSET((ubyte *)pxDLLCustomOpt, 0, sizeof(DHCP_CUSTOM_OPTION));
            pxDLLCustomOpt->oPktType = pxCustomOpt->oPktType;

            /* if "report only" PktType selected ensure other types are disabled */
            if (pxDLLCustomOpt->oPktType & DHCP_CPT_REPORT_ONLY)
              pxDLLCustomOpt->oPktType = DHCP_CPT_REPORT_ONLY;

            pxDLLCustomOpt->oCustomOption = pxCustomOpt->oCustomOption;
            if (pxCustomOpt->oBufSize) {
              pxDLLCustomOpt->poCustomOptionBuf = (char *)MALLOC(pxCustomOpt->oBufSize);
              ASSERT(pxDLLCustomOpt->poCustomOptionBuf);
              MOC_MEMCPY((ubyte *)pxDLLCustomOpt->poCustomOptionBuf,
                  (ubyte *)pxCustomOpt->poCustomOptionBuf,
                  pxCustomOpt->oBufSize);
            }
            pxDLLCustomOpt->oBufSize = pxCustomOpt->oBufSize;
            pxDLLCustomOpt->pfnCB = pxCustomOpt->pfnCB;
            DLLIST_append(pxNetIfConf->pdllDhcpClientCustomOpts, (void *)pxDLLCustomOpt);
          }
          break;

          /*
           * Return the pointer to the custom option DLLIST
           */
        case MO_SIOCGIFIDHCPCUSTOMOPT:
          {
            DLLIST **ppdllDhcpCustomOpts = va_arg(pArgList,DLLIST **);

            *ppdllDhcpCustomOpts = pxNetIfConf->pdllDhcpClientCustomOpts;
          }
          break;
        }
      }
    }
#endif /*DHCP_CUSTOM_OPTIONS */

    else if (dwRequest < MO_SIOCMEMRSRV_START) {
/*#ifdef SOCK_RT */
#ifdef NAT
      /*
       * NAT port forwarding ioctls
       */
      H_NETDATA hNetData;

      hNetData = (H_NETDATA) va_arg(pArgList, H_NETDATA);

      switch (dwRequest) {

      /*
       * Register WAN ports forwarded to the CPE.
       */
      case MO_SIOCNATREGFWDWAN2CPE:
        NatInstanceMsg(xSocketRep.hNat, NATMSG_REGPORTFWDWANTOCPE, hNetData);
        break;

      /*
       * Unregister WAN ports forwarded to the CPE.
       */
      case MO_SIOCNATUNREGFWDWAN2CPE:
        NatInstanceMsg(xSocketRep.hNat, NATMSG_UNREGPORTFWDWANTOCPE, hNetData);
        break;

      /*
       * Register LAN ports to be blocked to the CPE.
       */
      case MO_SIOCNATREGBLKLAN2CPE:
        NatInstanceMsg(xSocketRep.hNat, NATMSG_REGPORTBLKLANTOCPE, hNetData);
        break;

      /*
       * Unregister LAN ports to be blocked to the CPE.
       */
      case MO_SIOCNATUNREGBLKLAN2CPE:
        NatInstanceMsg(xSocketRep.hNat, NATMSG_UNREGPORTBLKLANTOCPE, hNetData);
        break;

      /*
       * Configures the LAN port forwarding table.
       */
      case MO_SIOCNATREGFWDWAN2LAN:
        lReturn = NatInstanceMsg(xSocketRep.hNat, NATMSG_CFGPORTFWDLAN, hNetData);
        break;

      /*
       * Get the list of WAN ports being forwarded to the CPE
       */
      case MO_SIOCNATGETFWDWAN2CPE:
        NatInstanceMsg(xSocketRep.hNat, NATMSG_GETPORTFWDWANTOCPELIST, hNetData);
        break;

      /*
       * Set the max number of NAT bindings
       */
      case MO_SIOCNATSETBINDINGSLIMIT:
        NatInstanceMsg(xSocketRep.hNat, NATMSG_SETBINDINGSLIMIT, hNetData);
        break;
      }
#endif
    }

    else if (dwRequest < MO_SIOCRTABLE_START) {

      /* memory reservation ioctls */
      switch (dwRequest) {

      case MO_SIOCMEMRSRV_AMT:
/*#ifdef SOCK_RT */
#ifdef NAT
        {
          H_NETDATA hNetData;

          hNetData = (H_NETDATA) va_arg(pArgList, H_NETDATA);

          NatInstanceMsg(xSocketRep.hNat, NATMSG_SETBINDINGSLIMIT, hNetData);
        }
#endif
        break;

      }
    }

    else if (dwRequest < MO_SIOCIFCBK_START) {
#ifdef SOCK_RT
      /*
       * Routing table ioctls
       */
      switch (dwRequest) {

      /*
       * Set a static route.
       */
      case MO_SIOCRTABLESETSTATICRT:
        {
          STATICROUTEENTRY xStaticRouteEntry;

          xStaticRouteEntry.dwIndex = pArgList->dwIndex;
          /* RS: BOOL is causing crash related to alignment, using DWORD instead */
          /*xStaticRouteEntry.bNullifyEntry = pArgList->bNullifyEntry; */
          xStaticRouteEntry.bNullifyEntry = pArgList->bNullifyEntry;
          xStaticRouteEntry.pxRtEntry = (struct rtentry*)pArgList->pxRtEntry;

          lReturn = RoutingTableMsg(ROUTINGTABLEMSG_SETSTATICROUTE,
                                    (H_NETDATA) &xStaticRouteEntry);
        }
        break;


      /*
       * Gets the number of routes.
       */
      case MO_SIOCRTABLEGETNUMRT:
        {
          DWORD *pdwNumRoutes;

          pdwNumRoutes = pArgList->pdwNumRoutes;

          lReturn = RoutingTableMsg(ROUTINGTABLEMSG_GETNUMROUTE,
                                    (H_NETDATA) pdwNumRoutes);
        }
        break;


      /*
       * Get the routing table info.
       */
      case MO_SIOCRTABLEGETALLRT:
        {
          ROUTEGETROUTE xRouteGetRoute;

          xRouteGetRoute.dwBufSize = pArgList->dwBufSize;
          xRouteGetRoute.pxRtEntries = (struct rtentry*)pArgList->pxRtEntry;
          xRouteGetRoute.pdwOutSize = pArgList->pdwOutSize;

          lReturn = RoutingTableMsg(ROUTINGTABLEMSG_GETROUTE,
                                    (H_NETDATA) &xRouteGetRoute);
        }
        break;
      }
#endif
    }


    else if ((MO_SIOCIFCBK_START <= dwRequest) && (dwRequest <= MO_SIOCIFCBK_END)) {
      SocketIoctlCallBack(dwRequest, pArgList );
    }
    else if ((MO_SIOCLIMITER_START <= dwRequest) && (dwRequest <= MO_SIOCLIMITER_END)){
      SocketIoctlLimiter(dwRequest,pArgList);
    }
    else if (dwRequest < MO_SIOCIPSEC_END + 1) {
/*#ifdef IPSEC */
#if 0 /* IPSEC is not configed by us */
      switch (dwRequest) {

      case MO_SIOCIPSECCLEARSASP:
        {
          IPSecSadbDelSAAll();
          IPSecSadbDelSPAll();
        }
        break;

      case MO_SIOCIPSECGETROUTE:
        {
          DWORD dwGWIP = pArgList->dwGWIP;
          RTDATA* pxRoute = (struct rtdata*)pArgList->pRtData;
          if (pxRoute) {
            IPSecSadbGetRoute(dwGWIP, &pxRoute->oIfIdx, &pxRoute->dwGateway);
          }
        }
        break;

      case MO_SIOCIPSECCREATESP:
        {
          void** ppxSP= (void**)pArgList->pxSp;
          SPDATA* pxSpdata = (struct spdata*)pArgList->pxSpData;
          RTDATA* pxRoute = (struct rtdata*)pArgList->pRtData;
          DWORD dwErr;

          /* create security policy */
          if (ppxSP && pxSpdata && pxRoute) {
            if (NULL==(*ppxSP=IPSecSadbFindSP(pxSpdata->dwDestIPSt,
                                              pxSpdata->dwDestIPEd,
                                              pxSpdata->wDestPort,
                                              pxSpdata->dwSrcIPSt,
                                              pxSpdata->dwSrcIPEd,
                                              pxSpdata->wSrcPort,
                                              pxSpdata->oTransProto))) {

              *ppxSP=IPSecSadbCreateSP(pxSpdata->dwDestIPSt,
                                       pxSpdata->dwDestIPEd,
                                       pxSpdata->dwDestMask,
                                       pxSpdata->dwSrcIPSt,
                                       pxSpdata->dwSrcIPEd,
                                       pxSpdata->dwSrcMask,
                                       pxSpdata->wDestPort,
                                       pxSpdata->wSrcPort,
                                       pxSpdata->oTransProto,
                                       &dwErr);
            }

            /* set GW address(for encapsulating IP header) */
            IPSecSadbSetTunnelAddr(*ppxSP,
                                   pxSpdata->dwTunSrcIP,
                                   pxSpdata->dwTunDestIP);

            /* save route info(interface index and gateway) */
            IPSecSadbSetRoute(*ppxSP, pxRoute->oIfIdx, pxRoute->dwGateway);

            /* clear SA entries list */
            IPSecSadbClearSAList(*ppxSP);
          }
        }
        break;

      case MO_SIOCIPSECCREATESA:
        {
          void* pxSP=(void*)pArgList->pxSp;
          SPDATA* pxSpdata = (struct spdata*)pArgList->pxSpData;
          SADATA* pxSadata = (struct sadata*)pArgList->pxSaData;
          DWORD dwErr;

          if (pxSP && pxSpdata && pxSadata) {
            if (NULL==IPSecSadbFindSA(pxSadata->dwSpi,
                                      pxSpdata->dwDestIPSt,
                                      pxSadata->oIPSecProto)) {
              pxSadata->dwSpi=IPSecSadbCreateSA(pxSadata->dwSpi,
                                                pxSpdata->dwDestIPSt,
                                                pxSadata->oIPSecProto,
                                                &dwErr);
            }

            /* link to security policy */
            IPSecSadbPushSA(pxSP, pxSadata->dwSpi);
          }

        }
        break;

      case MO_SIOCIPSECSETSA:
        {
          SPDATA* pxSpdata = (struct spdata*)pArgList->pxSpData;
          SADATA* pxSadata = (struct sadata*)pArgList->pxSaData;

          if (pxSpdata && pxSadata) {
            /* set security association parameters */
            IPSecSadbSetSA(pxSadata->dwSpi,
                           pxSpdata->dwDestIPSt,
                           pxSadata->oIPSecProto,
                           FALSE, TRUE,            /* disable SA */
                           pxSpdata->dwSrcIPSt,
                           pxSpdata->oIPSecMode,
                           pxSadata->oAuthAlgo,
                           pxSadata->oEncAlgo,
                           pxSadata->aoKey,
                           pxSadata->wAuthKeyOctets,
                           pxSadata->adwKey,
                           pxSadata->wEncKeyDwords,
                           pxSadata->wOrgDigestLen,
                           pxSadata->wIcvLen,
                           pxSadata->adwIv,
                           pxSadata->wIvDwords,
                           pxSadata->wBlockLen,
                           pxSadata->wMaxPadLen,
                           pxSadata->pfnAuth,
                           pxSadata->pfnEnc,
                           pxSadata->pfnDec);

            /* enable SA */
            IPSecSadbEnableSA(pxSadata->dwSpi,
                              pxSpdata->dwDestIPSt,
                              pxSadata->oIPSecProto,TRUE);
          }
        }
        break;

      }
#endif /* IPSEC */
    }
    else if (dwRequest < MO_SIOCPUBLICIOCTL_END + 1) {
#ifdef SOCK_RT
      H_NETDATA hNetData;

      hNetData = (H_NETDATA)pArgList->hNetData;

      switch (dwRequest) {

#ifdef IP_FILTERING
      case MO_SIOCIPFILTERINGCFG:
        /*
         * Configures an IP Filtering entry.
         */
        RouterInstanceMsg(xSocketRep.hRouter, ROUTERMSG_CFGIPFILTERING, hNetData);
        break;
#endif
      }
#endif /* SOCK_RT */
    }

  }
  /* RS: with multiple interfaces, we deadlock with dns if we call DnsMsg() */
  /*RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex)); */

  return (lReturn);
}

/*
 * LONG SocketIoctlCallBack(DWORD dwRequest,va_list pArgList)
 */

LONG SocketIoctlCallBack(DWORD dwRequest, mnIoctlArgList_t *xArgList)
{
  NETWRAPPER * pxNetWrapper = NETGETWRAPPER;
  LONG lRv = 0;

  switch ( dwRequest ) {

  case MO_SIOCADDCLOSECBK:
  case MO_SIOCADDOPENCBK:
    {
      NETIF_CBK pfnNetCbk = (NETIF_CBK)xArgList->pfnNetIfCbk;
      DLLIST *pdllPfnNetIfCbk;

      if(dwRequest == MO_SIOCADDCLOSECBK){
        pdllPfnNetIfCbk = &pxNetWrapper->dllPfnIfCloseCbk;
      } else {
        pdllPfnNetIfCbk = &pxNetWrapper->dllPfnIfOpenCbk;
      }

      /* Don't add a the same callback twice*/
      DLLIST_head(pdllPfnNetIfCbk);
      if (DLLIST_find(pdllPfnNetIfCbk, pfnNetCbk, NULL) == NULL){
        DLLIST_append(pdllPfnNetIfCbk, pfnNetCbk);
      }

    }
    break;

  case MO_SIOCREMCLOSECBK:
  case MO_SIOCREMOPENCBK:
    {
      NETIF_CBK pfnNetCbk = (NETIF_CBK)xArgList->pfnNetIfCbk;
      DLLIST *pdllPfnNetIfCbk;

      if(dwRequest == MO_SIOCREMCLOSECBK){
        pdllPfnNetIfCbk = &pxNetWrapper->dllPfnIfCloseCbk;
      } else {
        pdllPfnNetIfCbk = &pxNetWrapper->dllPfnIfOpenCbk;
      }

      DLLIST_head(pdllPfnNetIfCbk);
      if (DLLIST_find(pdllPfnNetIfCbk, pfnNetCbk, NULL) == NULL){
       /* Can't find the callback to remove*/
       return -1;
      }
      DLLIST_remove(pdllPfnNetIfCbk);
    }
    break;

  case MO_SIOCSDHCPERRORCBK:
    {
      NETIF_DHCPERROR_CBK pfnDhcpErrorCbk = (NETIF_DHCPERROR_CBK)xArgList->pfnDhcpErrorCbk;
      xNetWrapper.pfnIfDhcpErrorCbk = pfnDhcpErrorCbk;
    }
    break;

  case MO_SIOCADDLINKCBK:
    {
      NETIF_LINKSTATUS_CBK pfnLinkStatusCbk = (NETIF_DHCPERROR_CBK)xArgList->pfnLinkStatusCbk;
    }
    break;

  default:
    lRv = -1;
    ASSERT(0);

  }
  return lRv;
}

/*
 * LONG SocketIoctlLimiter(DWORD dwRequest,va_list pArgList)
 */


LONG SocketIoctlLimiter(DWORD dwRequest,mnIoctlArgList_t *xArgList)
{
  LONG lRv = 0;
#if 0
  switch(dwRequest){
    case MO_SIOCLIMITER_VLAN_ENABLE:
      lRv = NetIfLimiterSet(NETIFLIMITEROPTION_VLAN_ENABLE,(H_NETDATA)va_arg(xArgList, BOOL));
      break;
    case MO_SIOCLIMITER_VLAN_VALUE:
      lRv = NetIfLimiterSet(NETIFLIMITEROPTION_VLAN_VALUE,(H_NETDATA)va_arg(xArgList, OCTET));
      break;
    case MO_SIOCLIMITER_TOS_ENABLE:
      lRv = NetIfLimiterSet(NETIFLIMITEROPTION_TOS_ENABLE,(H_NETDATA)va_arg(xArgList, BOOL));
      break;
    case MO_SIOCLIMITER_TOS_MASK:
      lRv = NetIfLimiterSet(NETIFLIMITEROPTION_TOS_MASK,(H_NETDATA)va_arg(xArgList, OCTET));
      break;
    case MO_SIOCLIMITER_PORT_ENABLE:
      lRv = NetIfLimiterSet(NETIFLIMITEROPTION_PORT_ENABLE,(H_NETDATA)va_arg(xArgList, BOOL));
      break;
    case MO_SIOCLIMITER_PORT_ADD:
      lRv = NetIfLimiterSet(NETIFLIMITEROPTION_PORT_ADD,(H_NETDATA)va_arg(xArgList, PORT_RANGE*));
      break;
    case MO_SIOCLIMITER_PORT_REMOVE:
      lRv = NetIfLimiterSet(NETIFLIMITEROPTION_PORT_REMOVE,(H_NETDATA)va_arg(xArgList, PORT_RANGE*));
      break;
    default:
      ASSERT(0);
      lRv = -1;
  }

#endif
  return lRv;
}

