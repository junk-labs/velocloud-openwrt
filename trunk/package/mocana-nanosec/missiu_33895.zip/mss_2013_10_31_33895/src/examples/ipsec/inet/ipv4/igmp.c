/*
 * igmp.c
 *
 * IGMP module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "igmp_defs.h"
#include "igmp_proxy_defs.h"

/*****************************************************************************
 *
 * Define
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Local Functions
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * IgmpInitialize
 *  Initialize the IGMP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IgmpInitialize(void)
{
  /* Nothing to do */

  /* Initialise the debug variable to Error */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_ERROR);
  return 0;
}

/*
 * IgmpTerminate
 *  Terminate the IGMP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IgmpTerminate(void)
{
  /* Nothing to do */
  return 0;
}

/*
 * IgmpInstanceCreate
 *  Creates a IGMP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IgmpInstanceCreate(void)
{
  IGMPSTATE *pxIgmp;

  /* Allocate memory for the IGMPSTATE */
  pxIgmp = (IGMPSTATE *)MALLOC(sizeof(IGMPSTATE));
  ASSERT(pxIgmp != NULL);
  MOC_MEMSET((ubyte *)pxIgmp, 0, sizeof(IGMPSTATE));

  /* Set the Igmp cookie */
  IGMP_SET_COOKIE(pxIgmp);

  /* Initialize the multicast ip dll */
  init_DLLIST(&pxIgmp->dllIpMcast);

#ifdef STACK_MULTICAST_ROUTER
  init_DLLIST(&pxIgmp->dllMcastGroups);
#endif /* #ifdef STACK_MULTICAST_ROUTER */

  return (H_NETINSTANCE)pxIgmp;
}

/*
 * IgmpInstanceDestroy
 *  Destroy a IGMP Instance
 *
 *  Args:
 *   hIgmp                      instance handle
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IgmpInstanceDestroy(H_NETINSTANCE hIgmp)
{
  IGMPSTATE *pxIgmp;

  pxIgmp = (IGMPSTATE *)hIgmp;
  IGMP_CHECK_STATE(pxIgmp);

  clear_DLLIST(&pxIgmp->dllIpMcast,NetFree);

#ifdef STACK_MULTICAST_ROUTER
  clear_DLLIST(&pxIgmp->dllMcastGroups,NetFree);
#endif /* #ifdef STACK_MULTICAST_ROUTER */

  IGMP_UNSET_COOKIE(pxIgmp);

  FREE(pxIgmp);

  return 0;
}

/*
 * IgmpInstanceSet
 *  Set a IGMP Instance Option
 *
 *  Args:
 *   hIgmp                      instance handle
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IgmpInstanceSet(H_NETINSTANCE hIgmp,
                     OCTET oOption,
                     H_NETDATA hData)
{
  IGMPSTATE *pxIgmp;
  LONG lReturn = NETERR_NOERR;

  pxIgmp = (IGMPSTATE *)hIgmp;
  IGMP_CHECK_STATE(pxIgmp);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_NORMAL))
  {
    /*IGMP_DBGP(NORMAL,"IgmpInstanceSet option = %d, hData = 0x%x\n",oOption,(int)hData);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IgmpInstanceSet option = ", oOption);
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, " hData = 0x", (int)hData);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oOption){

  case NETOPTION_FREE:
    pxIgmp->pfnNetFree = (PFN_NETFREE)hData;
    break;

  case NETOPTION_MALLOC:
    pxIgmp->pfnNetMalloc = (PFN_NETMALLOC)hData;
    break;

  case NETOPTION_PAYLOADMUTEX:
    ASSERT((void*)hData != NULL);
    pxIgmp->pxMutex = (RTOS_MUTEX)hData;
    break;

  case NETOPTION_OFFSET:
    pxIgmp->wOffset = (WORD)hData;
    break;

  case NETOPTION_TRAILER:
    pxIgmp->wTrailer = (WORD)hData;
    break;

  case NETOPTION_NETCBK:
    pxIgmp->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case IGMPOPTION_SETTOS:
    /* Set the type of service */
    pxIgmp->oTos = (OCTET)hData;
    break;

  default:
    lReturn = NETERR_BADVALUE;
    ASSERT(0);
  }

  return lReturn;
}


/*
 * IgmpInstanceMsg
 *  Send a msg to a IGMP instance
 *
 *  Args:
 *   hIgmp                      instance handle
 *   oMsg                       Msg. See netcommon.h and igmp.h for definition
 *   hData                      Msg data. See message definition
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IgmpInstanceMsg(H_NETINSTANCE hIgmp,OCTET oMsg,
                     H_NETDATA hData)
{
  IGMPSTATE *pxIgmp;
  LONG lReturn = NETERR_NOERR;

  pxIgmp = (IGMPSTATE *)hIgmp;
  IGMP_CHECK_STATE(pxIgmp);

  switch(oMsg) {
  case NETMSG_OPEN:
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    break;

  case IGMPMSG_JOIN:
    {
      IPMCASTREQ *pxIpMreq = (IPMCASTREQ*)hData;
      lReturn = IgmpMsgJoin(pxIgmp,pxIpMreq,TRUE);
    }
    break;

  case IGMPMSG_LEAVE:
    {
      IPMCASTREQ *pxIpMreq = (IPMCASTREQ*)hData;
      lReturn = IgmpMsgLeave(pxIgmp,pxIpMreq,TRUE);
    }
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}

/*
 * IgmpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIgmp                      instance handle
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IgmpInstanceLLInterfaceCreate(H_NETINSTANCE hIgmp)
{
  /* Only one is supported: nothing to do */
  return 1;
}

/*
 * IgmpInstanceLLInterfaceDestroy
 *  Destroy a IGMP LL interface
 *
 *  Args:
 *   hIgmp                      IGMP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG IgmpInstanceLLInterfaceDestroy(H_NETINSTANCE hIgmp,
                                    H_NETINTERFACE hInterface)
{
  ASSERT((DWORD)hInterface == 1);
  return 0;
}

/*
 * IgmpInstanceLLInterfaceIoctl
 *  IGMP LL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h
 *  for precisions
 *
 *  Args:
 *   hIgmp                        Igmp instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IgmpInstanceLLInterfaceIoctl(H_NETINSTANCE hIgmp,
                                  H_NETINTERFACE hLLInterface,
                                  OCTET oIoctl,
                                  H_NETDATA hData)
{
  IGMPSTATE *pxIgmp;
  LONG lReturn = NETERR_NOERR;

  pxIgmp = (IGMPSTATE *)hIgmp;
  IGMP_CHECK_STATE(pxIgmp);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
    ASSERT(pxIgmp->pfnLLWrite != NULL);

  case NETINTERFACEIOCTL_CLOSE:
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxIgmp->hLL = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIgmp->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIgmp->hLLIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}

/*
 * IgmpInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hIgmp                        Igmp Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG IgmpInstanceProcess(H_NETINSTANCE hIgmp)
{
  IGMPSTATE *pxIgmp;

  pxIgmp = (IGMPSTATE *)hIgmp;
  IGMP_CHECK_STATE(pxIgmp);

  IgmpXmt(pxIgmp);

#ifdef STACK_MULTICAST_ROUTER
  IgmpProxyXmt(pxIgmp);
#endif /* #ifdef STACK_MULTICAST_ROUTER */

  return (LONG)IGMP_PROCESS_NEXT_CALL;
}

/*
 * IgmpMsgJoin
 *
 * Join the multicast address to a particular interface
 *
 *  Return:
 *   >= 0 if success
 */
LONG IgmpMsgJoin(IGMPSTATE *pxIgmp,
                 IPMCASTREQ *pxIpMreq,
                 BOOL bJoinFromSocket)
{
  LONG lReturn = NETERR_NOERR;
  IP_MCAST *pxIpMcast;

  /* Check if the host has already joined */
  pxIpMcast = IgmpIpMcastLookup(pxIgmp,pxIpMreq);

  if(pxIpMcast == NULL){
    /* the host hasn't joined yet */
    pxIpMcast = IgmpIpMcastInit(bJoinFromSocket,pxIpMreq);

    if(pxIpMcast == NULL){
      ASSERT(0);
      return -1;
    }

    DLLIST_append(&pxIgmp->dllIpMcast,pxIpMcast);

    pxIpMcast->fpIgmpRcv = IgmpRcvStateIdle;

    IgmpSendReport(pxIgmp,
                   pxIpMreq,
                   IGMP_V2_MEMBERSHIP_REPORT);
  }

  else {
    /* the host has already joined, either from a
     * socket or from the igmp proxy */
    ASSERT((pxIpMcast->bJoinFromSocket == TRUE) ||
           (pxIpMcast->bJoinFromProxy == TRUE));
#ifdef STACK_MULTICAST_ROUTER
    if (((pxIpMcast->bJoinFromSocket == TRUE) && (bJoinFromSocket == TRUE)) ||
        ((pxIpMcast->bJoinFromProxy == TRUE) && (bJoinFromSocket == FALSE))) {
      /* cannot join twice from a socket or a proxy */
      ASSERT(0);
      return (LONG)NETERR_JOIN;
    } else {
      if(bJoinFromSocket == TRUE){
        pxIpMcast->bJoinFromSocket = TRUE;
      } else {
        pxIpMcast->bJoinFromProxy = TRUE;
      }
      pxIpMcast->oNumMemberships++;
      ASSERT((pxIpMcast->bJoinFromSocket == TRUE) &&
             (pxIpMcast->bJoinFromProxy == TRUE));
    }
#else
    /* cannot join twice from a socket */
    ASSERT(0);
    return (LONG)NETERR_JOIN;
#endif /* #ifdef STACK_MULTICAST_ROUTER */
  }

  return lReturn;
}


/*
 * IgmpMsgLeave
 *
 * Leave the multicast address to a particular interface
 *
 *  Return:
 *   >= 0 if success
 */
LONG IgmpMsgLeave(IGMPSTATE *pxIgmp,
                  IPMCASTREQ *pxIpMreq,
                  BOOL bJoinFromSocket)
{
  LONG lReturn = NETERR_NOERR;
  IP_MCAST *pxIpMcast;

  /* Check if the host has already joined */
  pxIpMcast = IgmpIpMcastLookup(pxIgmp,pxIpMreq);

  if (pxIpMcast == NULL) {
    /* the group does not exist */
    return NETERR_LEAVE;
  }

  else {
#ifdef STACK_MULTICAST_ROUTER
    /* the host had joined the group */
    ASSERT(pxIpMcast->oNumMemberships >= 1);

    if (pxIpMcast->oNumMemberships == 1) {
      /* the host had joined with either a socket or the proxy */
      IgmpSendReport(pxIgmp,
                     pxIpMreq,
                     IGMP_LEAVE_MEMBERSHIP);

      DLLIST_remove(&pxIgmp->dllIpMcast);
      FREE(pxIpMcast);

    } else {
      /* the host had joined the group with a socket and a proxy */
      pxIpMcast->oNumMemberships--;

      ASSERT(pxIpMcast->oNumMemberships == 1 &&
             pxIpMcast->bJoinFromSocket == TRUE &&
             pxIpMcast->bJoinFromProxy == TRUE);

      if (bJoinFromSocket == TRUE) {
        pxIpMcast->bJoinFromSocket = FALSE;
      } else {
        pxIpMcast->bJoinFromProxy = FALSE;
      }
    }
#else
    ASSERT(pxIpMcast->oNumMemberships == 1);

    IgmpSendReport(pxIgmp,
                   pxIpMreq,
                   IGMP_LEAVE_MEMBERSHIP);

    DLLIST_remove(&pxIgmp->dllIpMcast);
    FREE(pxIpMcast);
#endif
  }

  return lReturn;
}
