/*
 * netmain.c
 *
 * Network Wrapper Main
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "../common/mbitmap.h"
#include "../include/socket_inet.h"
#include "../include/netsegment.h"
#include "netmain.h"
#include "mn_ndi.h"
#include <mqueue.h>
#include "netdb.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/if_types.h"
#include "netutils.h"
#include "nettime.h"
#include "iptable.h"
#include "netconfig.h"
#include "sockapi.h"
#include "nettransport.h"
#include "tcp.h"
#include "udp.h"
#include "netnetwork.h"
#include "ip.h"
#include "ip2eth.h"
#include "ethernet.h"
#include "arp.h"
#include "icmp.h"
#include "igmp.h"
#include "ip1ton.h"
#include "linkconf.h"
#include "netif.h"
#include "snmp_tcpip_data.h"
#include "routing_table.h"
#include "dnsapi.h"
#include "ping.h"
#include "netif_limiter.h"

#ifdef ROUTER
  #include "router.h"
#endif /*#ifdef ROUTER*/
#ifdef NAT
  #include "nat.h"
#endif /*#ifdef NAT*/
#ifdef IPFRAG
#include "ipfrag.h"
#endif /*#ifdef IPFRAG*/
#ifdef NET_DSL
  #include "adslmgr.h"
  #include "aal5devapi.h"
  #include "aal5.h" /* For Port change routine */
#endif /*#ifdef NET_DSL*/
#ifdef IPSEC
#include "ipsec.h"
#endif /*#ifdef IPSEC*/
#ifdef NET_DSL
#include "adslmgr.h"
#endif
#ifdef NET_MULTIF
#include "meter.h"
#endif

/****************************************************************************
 *
 * defines
 *
 ****************************************************************************/
#define NETMAIN_SLEEP               1
#ifdef NET_DSL
#define NETMAIN_DSLPROCESSINTERVAL (500/NETMAIN_SLEEP) /* 500ms */
#endif
#define NETMAIN_50MSPROCESSINTERVAL  (50/NETMAIN_SLEEP) /* 50ms */
#define NETMAIN_METERPROCCESS        100

NETMAIN_DBG_VAR(DWORD g_dwNetmainDebugLevel = 2);

#ifdef __INET_USE_PAYLOAD_MEMPOOL__
  poolHeaderDescr    netPoPayloadPool_1536;
  ubyte4             netPoPayloadPoolUsed_1536;
  RTOS_MUTEX         poPayloadMutex_1536;
  poolHeaderDescr    netPoPayloadPool_512;
  ubyte4             netPoPayloadPoolUsed_512;
  RTOS_MUTEX         poPayloadMutex_512;
#endif /* __INET_USE_PAYLOAD_MEMPOOL__ */

#ifndef NDEBUG
DWORD dbg_dwNetMainLoopSleepCnt = 0;
DWORD dbg_dwNetMainLoopCondTimedOutCnt = 0;
#endif

DWORD dwNetIfLimiterHitCnt;

volatile int nCondMacRxReady = 0;
pthread_cond_t cond_mac_rx = PTHREAD_COND_INITIALIZER;

unsigned long gEthPhyFramesEnqueued = 0;
unsigned long gMotEthPhyFramesEnqueued = 0;


poolHeaderDescr gDLLIST_pool;
poolHeaderDescr gDLLIST_ITEM_pool;


/****************************************************************************
 *
 * Local function declaration
 *
 ****************************************************************************/

void  InetDbgLevelInitialize(void);
void NetMainStartRoutine(sbyte4 pArg);
#ifdef NET_DSL
void DslStateHandler(BOOL bUp);
#endif
void IdLibraryInitialize(void);

/****************************************************************************
 *
 * Local functions
 *
 ****************************************************************************/

void NetMainStartRoutine(sbyte4 pArg)
{
  NETWRAPPER *pxNetWrapper;
  NETWRAPPERSTATE *pxWrapperState;
  NETIFLIMITER *pxNetIfLimiter;
  static  DWORD dwNetMainLoopCnt = 0;
  DWORD dwCurrentTime,dwMeterNextCallTime;
  struct timespec xtsStart/*,xtsCurrent*/;
  int iRv;
  pthread_mutexattr_t attr;
  pthread_mutex_t *pxMutex;

#ifdef PROFILE
  H_PROFILE_THREAD hProfNetMain;

  hProfNetMain = ProfileRegisterThread("NET",pthread_self());
#endif

#if defined (__VXWORKS_RTOS__)
  /* For testing only */
  taskDelay(1000);
#endif

  pxNetWrapper = NETGETWRAPPER;

  pxMutex = &pxNetWrapper->xMutex;

#if defined (__VXWORKS_RTOS__)
  if (RTOS_recursiveMutexCreate((RTOS_MUTEX)&pxMutex, 0, 0) !=OK) {
#if 0
      DEBUG_PRINT(DEBUG_MOC_IPV4, "RTOS_recursiveMutexCreate Failed....");
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
#endif
  }
#endif

#if defined (__VXWORKS_RTOS__)
#else
  pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP);
#if defined (__RECURSIVE_MUTEX__)
  pthread_mutex_init(&pxNetWrapper->xMutex,&attr);
#else /* No Recursive Mutex */
  pthread_mutex_init(&pxNetWrapper->xMutex,NULL);
#endif /* RECURSIVE_MUTEX */
#endif

  /* set the Debug Level to NORMAL */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_NETMAIN, INET_DBG_LEVEL_NORMAL);

  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);
  NETMAIN_ASSERT(pxWrapperState != NULL);

  pxNetIfLimiter = NETGETLIMITER(pxNetWrapper);
  NETMAIN_ASSERT(pxNetIfLimiter != NULL);

#if 0
  clock_gettime(CLOCK_REALTIME, &xtsStart);
#endif

  dwMeterNextCallTime = NetGetMsecTime() + NETMAIN_METERPROCCESS;

  while(pxWrapperState->obDone != TRUE) {

    dwNetMainLoopCnt ++;

#if 0
    /* Get the current time and set the global timer */
    clock_gettime(CLOCK_REALTIME, &xtsStart);
#endif

    NetGlobalTimerSet();
    dwCurrentTime = NetGlobalTimerGet();

    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  /* Interface processing */
  {
    NETIFCONF  *pxIfConf;
    NETIFSTATE *pxIfState;
    OCTET o;

    /* Do this every 50ms */
    if (0==(dwNetMainLoopCnt % NETMAIN_50MSPROCESSINTERVAL)) {
      LONG lPhyBitrate;
      static LONG lOldRate[IFNUMMAX];
      MnDeviceInstanceEvent_t *pDeviceInstanceEvent;

        while ((pDeviceInstanceEvent = (MnDeviceInstanceEvent_t *)
            DLLIST_remove(&pxNetWrapper->dllMnDeviceInstanceEvents)) !=NULL) {

            /* Process interfaces */
            pxIfConf  = NETGETIFCONF(pxNetWrapper,
                                pDeviceInstanceEvent->MnDeviceInstanceIndex);
            pxIfState = NETGETIFSTATE(pxIfConf);
            o = pDeviceInstanceEvent->MnDeviceInstanceIndex;
            if (pxIfState != NULL && pxIfState->eStatus == NETIFSTATUS_OPENED) {
            if (pDeviceInstanceEvent->MnDeviceInstanceEventFlags == IFF_UP) {
            /* link is up */
            if ((pxIfConf->oFlags & IFF_PHYUP) == 0) {
              NetIfPhyUp(&xNetWrapper,o);
              NetLIfNewActivePhy(o);
            }
            }
            else
            {
            /* link is down */
            if (pxIfConf->oFlags & IFF_PHYUP) {
              NetIfPhyDown_2(&xNetWrapper,o);
              /* Force config of bitrate when the link is next up */
              lOldRate[o] = -1;
            }
          }
        }
        }
    }

#ifdef NET_MULTIF
    /*
     * Round Robin processing
     */
    {
      static OCTET oStartIdx = 0;
      /* Enable all interfaces to be processed the first time around */
      DWORD dwProcessInterfaceFlags = (DWORD)-1;
      DWORD dwNumTotalPacketsRead = 0;
      DWORD dwNumPacketsRead;
      BOOL bOneRead;
      OCTET oIdx;


      pxNetWrapper->oEReady = 1;
      /* Start at a different index every time */
      if (pxNetWrapper->oIfNumber)
          oStartIdx = (oStartIdx + 1) % pxNetWrapper->oIfNumber;

/* VxWorks , Nettask can directly process the incoing packets */
#if (!defined(__RTOS_VXWORKS__))
      do {
        bOneRead = FALSE;
        for (o = 0; o < pxNetWrapper->oIfNumber; o++) {
          oIdx = (oStartIdx + o) % pxNetWrapper->oIfNumber;
          pxIfConf  = NETGETIFCONF(pxNetWrapper,oIdx);
          pxIfState = NETGETIFSTATE(pxIfConf);

          if (pxIfState != NULL && pxIfState->eStatus == NETIFSTATUS_OPENED &&
              dwProcessInterfaceFlags & (1 << oIdx)) {
            dwNumPacketsRead = (DWORD)NetIfProcessDrv(pxNetWrapper,oIdx);

            NetMutexUnlockLock(&pxNetWrapper->xMutex);

            if (dwNumPacketsRead > 0) {
              dwNumTotalPacketsRead += dwNumPacketsRead;
              bOneRead = TRUE;
            } else {
              /* No packets read -
               * don't bother to process this interface again */
              dwProcessInterfaceFlags  &= ~(1 << oIdx);
            }
          }
        }
      } while ((dwNumTotalPacketsRead <= NETIFPROCESS_MAXPACKETREAD) &&
                (bOneRead == TRUE) &&
                (pxNetIfLimiter->bHit == FALSE));
#endif

      if(pxNetIfLimiter->bHit == TRUE){
        dwNetIfLimiterHitCnt++;
      }

      for (o = 0; o < pxNetWrapper->oIfNumber; o++) {
        oIdx = (oStartIdx + o) % pxNetWrapper->oIfNumber;

        pxIfConf  = NETGETIFCONF(pxNetWrapper,oIdx);
        pxIfState = NETGETIFSTATE(pxIfConf);

        /* Only process interfaces which are open */
        if (pxIfState != NULL &&
            pxIfState->eStatus == NETIFSTATUS_OPENED) {
          NetIfProcessLnk(pxNetWrapper,oIdx);
        }
      }
    }

#else
    NetIfProcessDrv(pxNetWrapper,0);
    NetIfProcessLnk(pxNetWrapper,0);
#endif
  }

  (LONG)NetIfLimiterProcess(pxNetIfLimiter);

  NetMutexUnlockLock(&pxNetWrapper->xMutex);

  /* Process Main trunk modules */
  NetConfProcess(&pxNetWrapper->xNetConf); /* Will do the close too */

#ifdef NET_DSL
    /* Unlock mutex here as AdslMgrProcess does not
     * need it */
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

    /* Deal with potential loss of modem connection */
    /* Should be performed twice a second when no UART support required... */
    if (0 == (dwNetMainLoopCnt % NETMAIN_DSLPROCESSINTERVAL)) {
      AdslMgrProcess();
    }

    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif

#if __ENABLE_IPV4_METERING__
#ifdef NET_MULTIF
    /* Call the meter proccess function every 100ms */
    if (dwCurrentTime > dwMeterNextCallTime) {
      dwMeterNextCallTime += NETMAIN_METERPROCCESS;
      MeterProcess();
    }

#endif
#endif /* ENABLE_METERING__*/

    /* Go to sleep */
    clock_gettime(CLOCK_REALTIME, &xtsStart);
    TimespecAddNsec(&xtsStart, NETMAIN_SLEEP * 5000000);
    while (!nCondMacRxReady){
      DEBUG(dbg_dwNetMainLoopSleepCnt ++;);
      iRv = pthread_cond_timedwait(&cond_mac_rx,
                                   &pxNetWrapper->xMutex, &xtsStart);
      /*RS : RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex)); */
       break;
      if (MO_ETIMEDOUT == iRv) {
        DEBUG(dbg_dwNetMainLoopCondTimedOutCnt ++;);
       break;
      }
    }
    if (nCondMacRxReady) {
      DISABLE_INTERRUPTS;
      nCondMacRxReady--;
      RESTORE_INTERRUPTS;
    }

    /*RS: while(pthread_mutex_unlock(&pxNetWrapper->xMutex) == 0); */
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  }

#ifdef PROFILE
  ProfileUnregisterThread(hProfNetMain);
#endif
}

/*
 * IdLibraryInitialize
 *  Initialize the ID module and create a 32 bit id map to be
 *  used for FD.
 *
 *  Args:
 *
 *  Return:
 *
 */
void IdLibraryInitialize(void)
{
  int status = OK;
  NETWRAPPER *pxNetWrapper;

  pxNetWrapper = NETGETWRAPPER;
  /* init the ID module */

  /* Create an id map to be used for FD */
  status = MBITMAP_createMap(&pxNetWrapper->pFdMap, 1,MN_OPEN_MAX);
  if (OK != status)
  {
      printf("Unable to create FD map %d\n", status);
      goto exit;
  }

#if 0
  DEBUG_PRINT(DEBUG_MOC_IPV4, "Initialized MBITMAP library and FD map");
  DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
#endif

exit:
  ASSERT(OK == status);
  return;
}


#ifdef __TCP_SEND_SEGMENT__
DWORD TxSendMempoolInit()
{
  WORD idx;
  MSTATUS status;
  NETWRAPPER *pxNetWrapper;
  NETWRAPPERSTATE *pxWrapperState;
  OCTET *pTempMemBuffer ;

  pxNetWrapper = NETGETWRAPPER;

  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);
  /* INitialize each of the pools */

  pxWrapperState->xSendBufferPools[0].lengthOfSegment = MAX_TXBUFFER_50_POOL_SIZE ;
  pxWrapperState->xSendBufferPools[0].segmentsFree = MAX_TXBUFFER_50_POOL;
  pxWrapperState->xSendBufferPools[0].offset = MAX_TXBUFFER_OFFSET;

  pxWrapperState->xSendBufferPools[1].lengthOfSegment = MAX_TXBUFFER_250_POOL_SIZE ;
  pxWrapperState->xSendBufferPools[1].segmentsFree = MAX_TXBUFFER_250_POOL;
  pxWrapperState->xSendBufferPools[1].offset = MAX_TXBUFFER_OFFSET;

  pxWrapperState->xSendBufferPools[2].lengthOfSegment = MAX_TXBUFFER_600_POOL_SIZE ;
  pxWrapperState->xSendBufferPools[2].segmentsFree = MAX_TXBUFFER_600_POOL;
  pxWrapperState->xSendBufferPools[2].offset = MAX_TXBUFFER_OFFSET;

  pxWrapperState->xSendBufferPools[3].lengthOfSegment = MAX_TXBUFFER_1100_POOL_SIZE ;
  pxWrapperState->xSendBufferPools[3].segmentsFree = MAX_TXBUFFER_1100_POOL;
  pxWrapperState->xSendBufferPools[3].offset = MAX_TXBUFFER_OFFSET;

  pxWrapperState->xSendBufferPools[4].lengthOfSegment = MAX_TXBUFFER_1600_POOL_SIZE ;
  pxWrapperState->xSendBufferPools[4].segmentsFree = MAX_TXBUFFER_1600_POOL;
  pxWrapperState->xSendBufferPools[4].offset = MAX_TXBUFFER_OFFSET;

  pTempMemBuffer = MALLOC (sizeof(txSegmentStructure) * MAX_TXSEND_BUFFER) ;
  if (!pTempMemBuffer)
     return -1;

  if (OK > (status = MEM_POOL_initPool(&pxWrapperState->txSegmentPoolId, pTempMemBuffer, sizeof(txSegmentStructure) * MAX_TXSEND_BUFFER,
         sizeof(txSegmentStructure))))
    return status;

  for (idx=0; idx<MAX_TXBUFFER_POOL;idx++)
  {
    pTempMemBuffer = MALLOC (pxWrapperState->xSendBufferPools[idx].segmentsFree *
                             pxWrapperState->xSendBufferPools[idx].lengthOfSegment
                             );

    if (!pTempMemBuffer)
      return -1;

    status = MEM_POOL_initPool(&pxWrapperState->xSendBufferPools[idx].poolId, pTempMemBuffer,pxWrapperState->xSendBufferPools[idx].segmentsFree * pxWrapperState->xSendBufferPools[idx].lengthOfSegment, pxWrapperState->xSendBufferPools[idx].lengthOfSegment );

    if (0 > status)
      return status;
  }

  return 0;
}

#endif
/* #ifdef __INET_USE_MEMPOOL__ */

MSTATUS NetInitPayloadMempool()
{
#ifdef __INET_USE_PAYLOAD_MEMPOOL__
  MSTATUS status;
  OCTET *pTempMemBuffer ;

  if (poPayloadMutex_1536)
      return OK;

  if (OK > (status = RTOS_mutexCreate((RTOS_MUTEX)&poPayloadMutex_1536, 0, 0)))
  {
      return status;
  }
  /* Allocate MEMPOOL for POPAYLOAD  */
#ifdef __RTOS_VXWORKS__
  pTempMemBuffer = vxWorksAllocPayloadBuffer( (1536 + 32 + 32 )* MAX_NETPAYLOAD_POOL);
#else
  pTempMemBuffer = MALLOC ((1536 + 32 + 32) * MAX_NETPAYLOAD_POOL) ;
#endif
  if (!pTempMemBuffer)
     return -1;

  /* Initialize MEMPOOL for NETPAYLOAD structure */
  if (OK > (status = MEM_POOL_initPool(&netPoPayloadPool_1536, pTempMemBuffer, (1536 + 32 + 32)  * MAX_NETPAYLOAD_POOL, (1536 + 32 + 32))))
   if( status < 0)
      return status;
  netPoPayloadPoolUsed_1536 = 0;

  if (OK > (status = RTOS_mutexCreate((RTOS_MUTEX)&poPayloadMutex_512, 0, 0)))
  {
      return status;
  }
  /* Allocate MEMPOOL for POPAYLOAD  */
  pTempMemBuffer = MALLOC ((512 + 32 + 32) * MAX_NETPAYLOAD_POOL) ;
  if (!pTempMemBuffer)
     return -1;

  /* Initialize MEMPOOL for NETPAYLOAD structure */
  if (OK > (status = MEM_POOL_initPool(&netPoPayloadPool_512, pTempMemBuffer, (512 + 32 + 32)  * MAX_NETPAYLOAD_POOL, (512 + 32 + 32))))
   if( status < 0)
      return status;
  netPoPayloadPoolUsed_512 = 0;
#endif /* __INET_USE_MEMPOOL__ */

}

DWORD InetMempoolInit()
{
  MSTATUS status = 0;
  NETWRAPPER *pxNetWrapper;
  NETWRAPPERSTATE *pxWrapperState;
  OCTET *pTempMemBuffer ;

  pxNetWrapper = NETGETWRAPPER;
  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);


  NetInitPayloadMempool();

#ifdef __INET_USE_MEMPOOL__
  /* Allocate MEMPOOL for NETPAYLOAD structure */
  pTempMemBuffer = MALLOC (sizeof(NETPAYLOAD) * MAX_NETPAYLOAD_POOL) ;
  if (!pTempMemBuffer)
     return -1;

  /* Initialize MEMPOOL for NETPAYLOAD structure */
  if (OK > (status = MEM_POOL_initPool(&pxWrapperState->netPayloadPool, pTempMemBuffer, sizeof(NETPAYLOAD) * MAX_NETPAYLOAD_POOL, sizeof(NETPAYLOAD))))
   if( status < 0)
      return status;
  pxWrapperState->netPayloadPoolUsed = 0;
#endif /* __INET_USE_MEMPOOL__ */

#ifdef __INET_USE_PKT_MEMPOOL__
  /* Allocate MEMPOOL for NETPACKET structure */
  pTempMemBuffer = MALLOC (sizeof(NETPACKET) * MAX_NETPACKET_POOL) ;
  if (!pTempMemBuffer)
     return -1;

  /* Initialize MEMPOOL for NETPACKET structure */
  if (OK > (status = MEM_POOL_initPool(&pxWrapperState->netPacketPool, pTempMemBuffer, sizeof(NETPACKET) * MAX_NETPACKET_POOL, sizeof(NETPACKET))))

   if( status < 0)
      return status;

  pxWrapperState->netPacketPoolUsed = 0;
#endif

#ifdef __INET_USE_NET_BUF_MEMPOOL__
  /* Allocate MEMPOOL for NET_DRV_BUFFER structure */
  pTempMemBuffer = MALLOC (sizeof(NET_DRV_BUFFER) * MAX_NET_DRV_BUFFER_POOL) ;
  if (!pTempMemBuffer)
     return -1;

  /* Initialize MEMPOOL for NET_DRV_BUFFER structure */
  if (OK > (status = MEM_POOL_initPool(&pxWrapperState->netDrvBufPool, pTempMemBuffer, sizeof(NET_DRV_BUFFER) * MAX_NET_DRV_BUFFER_POOL, sizeof(NET_DRV_BUFFER))))
  if (!pTempMemBuffer)
     return -1;

  pxWrapperState->netDrvBufPoolUsed = 0;
#endif

    return status;
}
/* #endif */ /* __INET_USE_MEMPOOL__ */

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * NetInitialize
 *  This function inits the stack.
 *
 *  Args:
 *
 *  Return:
 *   TRUE - success,
 *   FALSE - error
 */
LONG  NetInitialize(void)
{
  NETWRAPPER *pxNetWrapper;
  NETWRAPPERSTATE *pxWrapperState;
  NETIFLIMITER *pxNetIfLimiter;
  NETCONFINSTANCE  *pxArpInst,*pxEthInst;
  H_NETINSTANCE hTcpInst,hUdpInst,hIcmpInst,hIgmpInst,hIpInst,hEthInst;
  int lRc;
  OCTET *pTempMemBuffer;
  MSTATUS status;

  pxNetWrapper = NETGETWRAPPER;


  NETMAIN_ASSERT(sizeof(TRANSPORT2NETWORKID) == sizeof(NETWORKID));

  /* Initialize the debug levels for all Macros to ERROR */
  InetDbgLevelInitialize();
  pxNetWrapper->oEReady = 0;

  /* Allocate MEMPOOL for DLLIST structure */
  pTempMemBuffer = MALLOC (sizeof(DLLIST) * 50000) ;
  if (!pTempMemBuffer)
     return 0;

  /* Initialize MEMPOOL for DLLIST structure */
  if (OK > (status = MEM_POOL_initPool(&gDLLIST_pool, pTempMemBuffer, sizeof(DLLIST) * 50000, sizeof(DLLIST))))
   if( status < 0)
      return status;

  /* Allocate MEMPOOL for DLLIST ITEM structure */
  pTempMemBuffer = MALLOC (sizeof(DLLIST_ITEM) * 200000) ;
  if (!pTempMemBuffer)
     return 0;

  /* Initialize MEMPOOL for DLLIST ITEM structure */

  if (OK > (status = MEM_POOL_initPool(&gDLLIST_ITEM_pool, pTempMemBuffer, sizeof(DLLIST_ITEM) * 200000, sizeof(DLLIST_ITEM))))
   if( status < 0)
      return status;

  init_DLLIST(&pxNetWrapper->MnConfigNetDevices);
  init_DLLIST(&pxNetWrapper->dllMnDeviceInstanceEvents);

  /*
   * Driver Initialization
   */

#ifdef NET_DSL
  Aal5DevInit();
  /* Until moved to wrapper based on flavor */
  AdslMgrRegisterPortChangeHandler(AAL5AllInstancesSetUtopiaPort);
#endif /*#ifdef NET_DSL*/

  pxNetWrapper->xNetConf.eState         = NETCONFSTATE_INIT;
  pxNetWrapper->xNetConf.ppxLibTemplate = (NETCONFLIBRARYTEMPLATE**)apxMainTrunkLibTemplate;
  pxNetWrapper->xNetConf.dwLibNum       = MAINTRUNKLIBIDX_MAX;

  NetConfSetup(&pxNetWrapper->xNetConf);

  MainTrunkSetNetOffset(NETRXOFFSET);
  MainTrunkSetNetTrailer(NETRXTRAILER);

  /*
   * Initializes state in xNetWrapper
   */
  pxWrapperState = (NETWRAPPERSTATE *)MALLOC(sizeof(NETWRAPPERSTATE));
  MOC_MEMSET((ubyte *)pxWrapperState, 0, sizeof(NETWRAPPERSTATE));
  NETMAIN_ASSERT(pxWrapperState != NULL);
  NETSETWRAPPERSTATE(pxNetWrapper,pxWrapperState);

  pxWrapperState->hNetBottomInst = NETGETINST_IP1TON;

  /* Initialize the limiter*/
  pxNetIfLimiter = NETGETLIMITER(pxNetWrapper);
  NetIfLimiterInitialize(pxNetIfLimiter);

  DLLIST_append(&(pxWrapperState->dllTxBuf),(void *) &(pxWrapperState->xndbTxPacket));

/* #ifdef __INET_USE_MEMPOOL__ */
  lRc = InetMempoolInit();
  if (lRc)
     return FALSE;
/* #endif */

  /* 2. misc */
  /* route table */
  RoutingTableInitialize();


#ifdef __TCP_SEND_SEGMENT__
  lRc = TxSendMempoolInit();
  if (lRc)
     return FALSE;
#endif

  /*
   * Instance fetching, must occurs after NetConfSetup.
   */

  hIpInst   = NETGETINST_IP;
  hEthInst  = NETGETINST_ETH;
  hTcpInst  = NETGETINST_TCP;
  hUdpInst  = NETGETINST_UDP;
  hIcmpInst = NETGETINST_ICMP;
  hIgmpInst = NETGETINST_IGMP;

  pxArpInst = NETGETCONFINST_ARP;
  NETMAIN_ASSERT(pxArpInst != NULL);

  pxEthInst = NETGETCONFINST_ETH;
  NETMAIN_ASSERT(pxEthInst != NULL);

  /* Transport LL interfaces */


  ArpInstanceLLInterfaceIoctl(pxArpInst->hInst,pxArpInst->phLLIf[0],
                              ARPLLINTERFACEIOCTL_SETRARPIF,
                              (H_NETDATA)pxEthInst->phULIf[ETHULIFIDX_RARP]);



  /*
   * Misc initialization
   */


  /* Id library Initialize */
  IdLibraryInitialize();

  /* Sockets */
  SocketLibraryInitialize();
  SocketLibrarySet(SOCKETLIBOPTION_HUDP,(H_NETDATA)hUdpInst);
  SocketLibrarySet(SOCKETLIBOPTION_HTCP,(H_NETDATA)hTcpInst);
  SocketLibrarySet(SOCKETLIBOPTION_HNETWORK,(H_NETDATA)hIpInst);
  SocketLibrarySet(SOCKETLIBOPTION_HICMP,(H_NETDATA)hIcmpInst);
  SocketLibrarySet(SOCKETLIBOPTION_HIGMP,(H_NETDATA)hIgmpInst);
  SocketLibrarySet(SOCKETLIBOPTION_HETH,(H_NETDATA)hEthInst);

  IpTableInitialize();

#ifdef _ENABLE_DNS_
  DnsInit();
#endif /* _ENABLE_DNS_ */

#ifdef ROUTER
  {
    H_NETINSTANCE hRouterInst;
    hRouterInst = NETGETINST_ROUTER;

    SocketLibrarySet(SOCKETLIBOPTION_HROUTER,(H_NETDATA)hRouterInst);
    RouterInstanceMsg(hRouterInst,ROUTERMSG_SETIFIDXLAN,(H_NETDATA) 0);  /* TODO - set proper LAN index. */
  }
#endif

#ifdef NAT
  {
    H_NETINSTANCE hNatInst;
    hNatInst = NETGETINST_NAT;

    SocketLibrarySet(SOCKETLIBOPTION_HNAT,(H_NETDATA)hNatInst);
    NatInstanceMsg(hNatInst,NATMSG_SETIFIDXLAN,(H_NETDATA) 0);  /* TODO - set proper LAN index. */
  }
#endif

#ifdef IPSEC
  {
    H_NETINSTANCE hIPSecInst;
    hIPSecInst = NETGETINST_IPSEC;

    SocketLibrarySet(SOCKETLIBOPTION_HIPSEC,(H_NETDATA)hIPSecInst);
#ifdef ROUTER
    IPSecInstanceMsg(hIPSecInst,IPSECMSG_SETIFIDXLAN,(H_NETDATA) 0);  /* TODO - set proper LAN index. */
#else /* if ROUTER */
    IPSecInstanceMsg(hIPSecInst,IPSECMSG_SETIFIDXLAN,(H_NETDATA) -1); /* there's no LAN  */
#endif /* if ROUTER else */
  }
#endif /* IPSEC */

  {
    OCTET oIdx;
    /* Set the default vlan for all possible interfaces */
    for (oIdx=0; oIdx<IFNUMMAX; oIdx++) {
      pxNetWrapper->pxIfConf[oIdx].wVlan = NETVLAN_DEFAULT;
    }
  }

  /* Open all main trunk modules */
  NetConfOpen(&pxNetWrapper->xNetConf);

  /* Open the configuration socket */
  /* Used by PPP...so commenting it for now
  pxWrapperState->iSocket = socket(AF_INET,SOCK_DGRAM,0);
  NETDBG_ASSERT(pxWrapperState->iSocket >= 0);
  */

#ifdef NET_DSL
  /* Register the Dsl state handler */
  AdslMgrRegisterDslStateHandler(DslStateHandler);
#endif


  /* Start up the stack thread */
  {
    int iRv;

    iRv = RTOS_createThread(NetMainStartRoutine, 0, MOC_IPV4,
            &(pxWrapperState->xThread));
    ASSERT(iRv == OK);
  }


  return TRUE;
}

/*
 * MainTrunkSetNetOffset
 *  Set the offset information for the interface
 *  in main trunk modules
 *
 *  Args:
 *   oIfIdx                interface index
 *   wOffset               Net layer offset
 *
 *  Return:
 *   0
 */
LONG MainTrunkSetNetOffset(WORD wOffset)
{
  ArpInstanceSet(NETGETINST_ARP,NETOPTION_OFFSET,(H_NETDATA)wOffset);
  EthInstanceSet(NETGETINST_ETH,NETOPTION_OFFSET,(H_NETDATA)wOffset);

  wOffset += IPDEFAULT_HDRSIZE;

  TcpInstanceSet(NETGETINST_TCP,NETOPTION_OFFSET,(H_NETDATA)wOffset);
  IgmpInstanceSet(NETGETINST_IGMP,NETOPTION_OFFSET,(H_NETDATA)wOffset);
  IcmpInstanceSet(NETGETINST_ICMP,NETOPTION_OFFSET,(H_NETDATA)wOffset);
#ifdef IPFRAG
  IpFragInstanceSet(NETGETINST_IPFRAG,NETOPTION_OFFSET,(H_NETDATA)wOffset);
#endif /*#ifdef IPFRAG*/
  return 0;
}

/*
 * MainTrunkSetNetTrailer
 *  Set the trailer information for the interface
 *  in main trunk modules
 *
 *  Args:
 *   oIfIdx                interface index
 *   wOffset               Net layer offset
 *
 *  Return:
 *   0
 */
LONG MainTrunkSetNetTrailer(WORD wTrailer)
{
  ArpInstanceSet(NETGETINST_ARP,NETOPTION_TRAILER,(H_NETDATA)wTrailer);
  EthInstanceSet(NETGETINST_ETH,NETOPTION_TRAILER,(H_NETDATA)wTrailer);

  wTrailer += IPDEFAULT_HDRSIZE;

  TcpInstanceSet(NETGETINST_TCP,NETOPTION_TRAILER,(H_NETDATA)wTrailer);
  IgmpInstanceSet(NETGETINST_IGMP,NETOPTION_TRAILER,(H_NETDATA)wTrailer);
  IcmpInstanceSet(NETGETINST_ICMP,NETOPTION_TRAILER,(H_NETDATA)wTrailer);
#ifdef IPFRAG
  IpFragInstanceSet(NETGETINST_IPFRAG,NETOPTION_TRAILER,(H_NETDATA)wTrailer);
#endif /*#ifdef IPFRAG*/
  return 0;
}

/*
 * NetMainMsg
 *  Netmain library message function
 *
 *  Args:
 *   oCode              Msg code
 *   hData              data handle
 *
 *  return:
 *   NETERR_NOERR
 */
LONG NetMainMsg(OCTET oMsgCode,H_NETDATA hData)
{
  NETWRAPPER *pxNetWrapper;
  OCTET oIfIdx = (OCTET)hData;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  switch(oMsgCode) {
    /* SB March 2002. Would gain about 40 bytes (nd) by replacing
       the 4 1st cases by an pfnAction array  */
  case NETMAINMSG_IFSETUP:
    NetIfSetup(pxNetWrapper,oIfIdx);
    break;

  case NETMAINMSG_IFOPEN:
    NetIfOpen(pxNetWrapper,oIfIdx);
    break;

  case NETMAINMSG_IFCLOSE:
    NetIfClose(pxNetWrapper,oIfIdx);
    break;

  case NETMAINMSG_IFTEARDOWN:
    NetIfTearDown(pxNetWrapper,oIfIdx);
    break;

  case NETMAINMSG_IFIPUP:
    NetIfIpUp(pxNetWrapper,oIfIdx);
    break;

#ifdef LINK_AGGREGATION
  case NETMAINMSG_IFAGGRADD:
    NetIfAggr(pxNetWrapper, 1, (NETIFAGGR *)hData);
    break;
  case NETMAINMSG_IFAGGRDEL:
    NetIfAggr(pxNetWrapper, 0, (NETIFAGGR *)hData);
    break;
#endif

  default:
    NETMAIN_ASSERT(0);
  }

  return NETERR_NOERR;
}


#ifdef NET_DSL
void DslStateHandler(BOOL bUp)
{
  NETWRAPPER *pxNetWrapper;
  NETWRAPPERSTATE *pxWrapperState;

  pxNetWrapper = NETGETWRAPPER;
  NETMAIN_ASSERT(pxNetWrapper != NULL);

  pxWrapperState = NETGETWRAPPERSTATE(pxNetWrapper);

  pxWrapperState->oAtmUp = bUp;
}
#endif

void NetMutexUnlockLock(RTOS_MUTEX pxMutex)
{
  /* if(NN_pthread_mutex_status(pxMutex) >= 1){  */
    RTOS_recursiveMutexRelease(pxMutex);
    RTOS_recursiveMutexWait(pxMutex);
  /*} */
}

void InetDbgLevelInitialize()
{
    ubyte4 i;
    for(i=0; i < INET_DBG_MOD_MAX; i++)
    {
        g_aInetModDbg[i]=0;
        INET_DBG_LEVEL_SET(i,INET_DBG_LEVEL_ERROR);
    }
}

#if defined (__VXWORKS_RTOS__)

/* This is temporary fix. We'll use Mocana macros throughout the inet code
   base.
 */

ubyte4 ntohl(ubyte4 a)
{
#if defined (MOC_LITTLE_ENDIAN)
    return ((a << 24) |
            ((a << 8) & 0x00ff0000) |
            ((a >> 8) & 0x0000ff00) |
            (a >> 24));
#else
    return a;
#endif
}

ubyte4 htonl(ubyte4 a)
{
#if defined (MOC_LITTLE_ENDIAN)
    return ((a << 24) |
            ((a << 8) & 0x00ff0000) |
            ((a >> 8) & 0x0000ff00) |
            (a >> 24));
#else
    return a;
#endif
}

ubyte2 htons(ubyte2 a)
{
#if defined (MOC_LITTLE_ENDIAN)
  return (ubyte2)((a << 8) | (a >> 8));
#else
  return a;
#endif
}

ubyte2 ntohs(ubyte2 a)
{
#if defined (MOC_LITTLE_ENDIAN)
  return (ubyte2)((a << 8) | (a >> 8));
#else
 return a;
#endif
}

#endif
