/*
 * snmp_tcpip_test.c
 *
 * SNMP protocol
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/* Test and Display for the TCP IP SNMP aware data                         *
****************************************************************************/

/*--- include, define, macro, typedef -------------------------------------*/
#include <NNstyle.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "snmp_flavor.h"
/*#include "mib2_structs.h" */
#include "snmp_tcpip_rtn.h"
#include "snmp_tcpip_data.h"
#include "snmp_tcpip_api.h"



extern char *in_ntoa(DWORD in);

OCTET *readable_mac(OCTET *ptr)
{
  static OCTET buf[64];
  DWORD idx;
  OCTET o, *op = buf;

  if (NULL == ptr) return("[NONE]");
  for (idx = 0; idx < 6; idx++) {
    if (idx) *op++ = ':';
    o = 0x0F & (ptr[idx] >> 4);
    *op++ = (o > 9) ? (o - 10) + 'A' : o + '0';
    o = 0x0F & ptr[idx];
    *op++ = (o > 9) ? (o - 10) + 'A' : o + '0';
  }
  *op++ = '\0';
  return (buf);
}




void PrintArpTable(struct ARP_TABLE_ENTRY *pxTable, int iNosRows)
{
  int i;

  for (i=0; i<iNosRows; i++) {
    if (pxTable->dwIfNos!=0 && pxTable->dwIP!=0) {
      printf("TCPIP LIB : GetSnmpArpTable : Entry = %02d  dwIfNos=%ld  dwIP=%s  oMacAddr=%s\n",
             i,
             pxTable->dwIfNos,
             in_ntoa(pxTable->dwIP),
             readable_mac(pxTable->oMacAddr));
    }
    pxTable++;
  }
}

void PrintAdEntTable(struct ADD_ENT_TABLE_ENTRY *pxTable, int iNosRows)
{
  int i=0;

  for (i=0 ;i<iNosRows; i++) {
    printf("TCPIP LIB : GetSnmpAdEntTable : Entry=%02d  dwIfIndex=%ld  dwIP=%s  ",
           i,
           pxTable->dwIfIndex,
           in_ntoa(pxTable->dwIP) );
    printf("dwNetMask=%s  dwBcastAdd=%ld  dwReasmMaxSize=%ld\n",
           in_ntoa(pxTable->dwNetMask),
           pxTable->dwBcastAdd,
           pxTable->dwReasmMaxSize);

    pxTable++;
  }
}

void PrintudpTable(struct UDP_TABLE_ENTRY *pxTable, int iNosRows)
{
  int i=0;

  for (i=0 ;i<iNosRows; i++) {
    printf("TCPIP LIB : PrintUdpTable : Entry=%02d  dwIP=%s  dwPort=%ld  \n",
           i,
           in_ntoa(pxTable->dwIP),
           pxTable->dwPort );
    pxTable++;
  }
}


void PrintTcpTable(struct TCPCONN_TABLE_ENTRY *pxTable, int iNosRows)
{
  int i=0;

  for (i=0 ;i<iNosRows; i++) {
    printf("TCPIP LIB : GetSnmpTcpConnEntryTable : Entry=%02d  wState=%ld  dwLocalIP=%s  wLocalPort=%ld  \n",
           i, pxTable->wState,
           in_ntoa(pxTable->dwLocalIP),
           pxTable->wLocalPort );
    printf("dwIP=%s  wLocalPort=%ld  \n",
           in_ntoa(pxTable->dwRemoteIP),
           pxTable->wRemotePort );
    pxTable++;
  }
}


void PrintNet2MediaTable(struct NETTOMEDIA_TABLE_ENTRY *pxTable, int iNosRows)
{
  int i=0;
  const char *poNet2MediaType[5]={"blank",
                                  "other",
                                  "invalid",
                                  "dynamic",
                                  "static"};

  for (i=0 ;i<iNosRows; i++) {
    printf("TCPIP LIB : GetSnmpNet2MediaTable : Entry=%02d  dwIfIndex=%ld  dwIP=%s  oMacAddr=%s  dwType=%s \n",
           i,
           pxTable->dwIfIndex,
           in_ntoa(pxTable->dwIP),
           readable_mac(pxTable->oMacAddr),
           poNet2MediaType[pxTable->dwType] );
    pxTable++;
  }
}

