/*
 * ppp.c
 *
 * PPP main
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "pppdefs.h"

/***************************************************************************
 *
 * global variables
 *
 ***************************************************************************/

PPP_DBG_VAR(DWORD g_dwPppDebugLevel = 1);

/***************************************************************************
 *
 * statics variables
 *
 ***************************************************************************/



/***************************************************************************
 *
 * Local functions
 *
 ***************************************************************************/


/***************************************************************************
 *
 * API functions
 *
 ***************************************************************************/

/*
 * PppInitialize
 *   PPP main library initialization.
 *
 *   Args:
 *
 *   Return:
 *     >=0
 */
LONG PppInitialize(void)
{
  return NETERR_NOERR;
}

/*
 * PppTerminate
 *   Terminate the PPP main library
 *
 *   Args:
 *
 *   Return:
 *
 */
LONG PppTerminate(void)
{
  return NETERR_NOERR;
}

/*
 * PppInstanceCreate
 *  Creates a PPP instance
 *
 *  Args:
 *
 *  Return:
 *   handle to the instance
 */
H_NETINSTANCE PppInstanceCreate(void)
{
  PPPSTATE *pxState;

  pxState = (PPPSTATE *)calloc(1,sizeof(PPPSTATE));
  PPP_SET_COOKIE(pxState);

  /* PPPCP configuration */
  pxState->hCp = PppCpInstanceCreate();
  pxState->hCpIf = PppCpInstanceLLInterfaceCreate(pxState->hCp);

  PppCpInstanceSet(pxState->hCp,NETOPTION_NETCBK,(H_NETDATA)PppInstanceLcpCbk);
  PppCpInstanceSet(pxState->hCp,NETOPTION_NETCBKHINST,(H_NETDATA)pxState);

  PppCpInstanceLLInterfaceIoctl(pxState->hCp,pxState->hCpIf,
                                NETINTERFACEIOCTL_SETHINST,
                                (H_NETDATA)pxState);
  PppCpInstanceLLInterfaceIoctl(pxState->hCp,pxState->hCpIf,
                                NETINTERFACEIOCTL_SETOUTPUTPFN,
                                (H_NETDATA)PppInstanceWrite);
  PppCpInstanceLLInterfaceIoctl(pxState->hCp,pxState->hCpIf,
                                NETINTERFACEIOCTL_SETIF,
                                (H_NETDATA)PPPID_LCP);


  pxState->oTunnelMode = PPPDEFAULT_TUNNELMODE;

  pxState->dwIdleTOCurrent = PPPIDLETO_NONE;
  pxState->dwEchoTOCurrent = PPPECHOTO_NONE;
  pxState->dwEchoCount = PPPECHOTO_COUNT;

  pxState->dwNextIdleTO = pxState->dwIdleTOCurrent + NetGlobalTimerGet();
  pxState->dwNextEchoTO = pxState->dwEchoTOCurrent + NetGlobalTimerGet();

  PppInstanceOptionResetDefault(pxState);

  return (H_NETINSTANCE)pxState;
}

/*
 * PppInstanceDestroy
 *  Destroy a PPP instance
 *
 *  Args:
 *   hPpp                  Handle of the instance to destroy
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceDestroy(H_NETINSTANCE hPpp)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;

  PPP_CHECK_STATE(pxState);

  PppCpInstanceLLInterfaceDestroy(pxState->hCp,pxState->hCpIf);
  PppCpInstanceDestroy(pxState->hCp);

  if (pxState->pxUlTable != NULL) {
    free(pxState->pxUlTable);
  }

  PPP_SET_COOKIE(pxState);

  free(pxState);

  return NETERR_NOERR;
}

/*
 * PppInstanceSet
 *  Set an instance option
 *
 *  Args:
 *   hPpp                  Handle of the instance
 *   oOption               option code
 *   hData                 data handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceSet(H_NETINSTANCE hPpp,OCTET oOption,H_NETDATA hData)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;
  OCTET obRemote = FALSE;

  PPP_CHECK_STATE(pxState);
  ASSERT(oOption < (NETOPTION_MODULESPECIFICBEGIN + PPPOPTIONMAX));

  PPP_DBGP(REPETITIVE,"PppInstanceSet:hPpp=%d,oOption=%s,hData=%d\n",
           (int)hPpp,
           ((oOption >= NETOPTION_MODULESPECIFICBEGIN) ?
           apoPppOptionString[oOption - NETOPTION_MODULESPECIFICBEGIN]:
           apoNetOptionString[oOption]),
           (int)hData);

  switch(oOption) {
  case NETOPTION_FREE:
  case NETOPTION_MALLOC:
    PppCpInstanceSet(pxState->hCp,oOption,hData);
    break;

  case NETOPTION_PAYLOADMUTEX:
    pxState->pxMutex = (pthread_mutex_t *)hData;
    PppCpInstanceSet(pxState->hCp,oOption,hData);
    break;
  case NETOPTION_TRAILER:
    pxState->wTrailer = (WORD)hData;
    PppCpInstanceSet(pxState->hCp,oOption,hData);
    break;

  case PPPOPTION_RETRANSMISSIONTIMER:
    PppCpInstanceSet(pxState->hCp,PPPCPOPTION_TIMER,hData);
    break;

  case PPPOPTION_MAXCONFRETRIES:
    PppCpInstanceSet(pxState->hCp,PPPCPOPTION_MAXCONF,hData);
    break;

  case PPPOPTION_MAXTERMRETRIES:
    PppCpInstanceSet(pxState->hCp,PPPCPOPTION_MAXTERM,hData);
    break;

  case NETOPTION_OFFSET:
    {
      WORD wOffset = (WORD)hData;

      pxState->wOffset = wOffset;

      if (pxState->oTunnelMode == PPPTUNNELMODE_PPTP) {
        wOffset += PPPPPTP_HDRLEN;
      }
      else {
        wOffset += PPPDEFAULT_HDRLEN;
      }

      PppCpInstanceSet(pxState->hCp,NETOPTION_OFFSET,(H_NETDATA) wOffset);

    }
    break;

  case NETOPTION_NETCBK:
    pxState->pfnNetCbk = (PFN_NETCBK)hData;
    break;

  case NETOPTION_NETCBKHINST:
    pxState->hNetCbk = (H_NETINSTANCE)hData;
    break;


  case PPPOPTION_REMOTEMRU:
  case PPPOPTION_REMOTEMAGICNUMBER:
  case PPPOPTION_REMOTEACFC:
  case PPPOPTION_REMOTEPFC:
    obRemote = TRUE;
    /* Fall through */
  case PPPOPTION_LOCALMRU:
  case PPPOPTION_LOCALMAGICNUMBER:
  case PPPOPTION_LOCALACFC:
  case PPPOPTION_LOCALPFC:
    {
      H_NETDATA *phOptionTable;
      phOptionTable = (obRemote == TRUE) ? pxState->ahLcpRemoteOption:
        pxState->ahLcpLocalOption;
      phOptionTable[(oOption - PPPOPTION_LOCALMRU)>>1] =
        (H_NETDATA)hData;
    }
  break;

  case PPPOPTION_REMOTEAP:
  case PPPOPTION_REMOTELQP:
    obRemote = TRUE;
    /* Fall through */
  case PPPOPTION_LOCALAP:
  case PPPOPTION_LOCALLQP:
    {
      H_NETDATA *phOptionTable;

      phOptionTable = (obRemote == TRUE) ? pxState->ahLcpRemoteOption:
        pxState->ahLcpLocalOption;

     if ((WORD)hData != PPPID_NONE) {
       WORD wIdx;
       E_PPPLCPOPTION eOption;

        wIdx = PppInstanceFindUlIdxFromProtocolId(pxState, (WORD)hData);

        eOption = (E_PPPLCPOPTION)((oOption - PPPOPTION_LOCALMRU) >> 1);

        if (eOption == PPPLCPOPTION_AP) {
          pxState->oApNum++;
        }
        else {
          pxState->oLqpNum ++;
        }


        if (wIdx != PPPPROTIDX_NONE) {
          /* If the coresponding protocol is already registered,
             use the index as the value */
          phOptionTable[oOption - PPPLCPOPTION_MRU] = (H_NETDATA)wIdx;
        }
        else {
          /* Otherwise, use the protocol id till the interface
             is registered. This works because the indexing
             and the protocol ids do not collide  */
          phOptionTable[oOption - PPPLCPOPTION_MRU] = (H_NETDATA) hData;
        }
     }
     else {
       phOptionTable[oOption - PPPLCPOPTION_MRU] =
         (H_NETDATA) PPPPROTIDX_NONE;
     }
    }
  break;

  case PPPOPTION_TUNNELMODE:
    pxState->oTunnelMode = (OCTET)hData;
    /* Reset the Cp offset, if needed */
    {
      WORD wOffset = pxState->wOffset;

      if (pxState->oTunnelMode == PPPTUNNELMODE_PPTP) {
        wOffset += PPPPPTP_HDRLEN;
      }
      else {
        wOffset +=PPPDEFAULT_HDRLEN;
      }

      PppCpInstanceSet(pxState->hCp,NETOPTION_OFFSET,(H_NETDATA) wOffset);
    }
    break;

  case PPPOPTION_IFIDX:
    PppCpInstanceSet(pxState->hCp,PPPCPOPTION_IFIDX,hData);
    break;

  case PPPOPTION_VLAN:
    PppCpInstanceSet(pxState->hCp,PPPCPOPTION_VLAN,hData);
    break;

  case PPPOPTION_IDLETO:
    /* Convert minutes to ms */
    if (0 != (DWORD) hData) {
      pxState->dwIdleTOCurrent = NetGetMsecTime();
      pxState->dwIdleTO = (60000 * (DWORD) hData); /* 60 sec * time specified */
      pxState->dwNextIdleTO = pxState->dwIdleTOCurrent + pxState->dwIdleTO;  /* Timeout horizon */
    } else
      pxState->dwIdleTOCurrent = PPPIDLETO_NONE; /* Prevent timeout */
    break;

  case PPPOPTION_ECHOTO:
    /* Convert seconds to millisec */
    if (0 != (DWORD) hData) {
      pxState->dwEchoTOCurrent = NetGetMsecTime();
      pxState->dwEchoTO = (1000 * (DWORD) hData); /* 1 sec * time specified */
      pxState->dwNextEchoTO = pxState->dwEchoTOCurrent + pxState->dwEchoTO;  /* Timeout horizon */
    } else
      pxState->dwEchoTOCurrent = PPPECHOTO_NONE; /* Prevent timeout */
    break;

  case PPPOPTION_ECHOCOUNT:
    pxState->dwEchoCount = (DWORD) hData;
    break;

  default:
    ASSERT(0);
  }

  return NETERR_NOERR;
}

/*
 * PppInstanceMsg
 *  Instance Msg function
 *
 *  Args:
 *   hPpp                  Handle of the instance to destroy
 *   oOption               option code
 *   hData                 data handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceMsg(H_NETINSTANCE hPpp,OCTET oMsg,H_NETDATA hData)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;
  PPP_CHECK_STATE(pxState);

  PPP_DBGP(REPETITIVE,"PppInstanceMsg:hPpp=%d,oMsg=%s,hData=%d\n",
           (int)hPpp,
           ((oMsg >= NETMSG_MODULESPECIFICBEGIN) ?
           apoPppMsgString[oMsg - NETMSG_MODULESPECIFICBEGIN]:
           apoNetMsgString[oMsg]),
           (int)hData);

  switch(oMsg) {
  case NETMSG_LOWERLAYERUP:
    pxState->ePhase = PPPPHASE_ESTABLISH;
    /* Fall through */
  case NETMSG_OPEN:
    PppCpInstanceMsg(pxState->hCp,oMsg,hData);
    break;

  case NETMSG_CLOSE:
    pxState->ePhase = PPPPHASE_TERMINATE;
    /* Fall through */
  case NETMSG_LOWERLAYERDOWN:
    PppInstanceOptionResetDefault(pxState);
    PppCpInstanceMsg(pxState->hCp,oMsg,hData);
    break;

  case PPPMSG_AUTHSUCCESS:
    pxState->ePhase = PPPPHASE_NETWORK;
    pxState->pfnNetCbk(pxState->hNetCbk,NETCBK_TLU,hData);
    break;

  case PPPMSG_AUTHFAILURE:
    pxState->ePhase = PPPPHASE_TERMINATE;
    pxState->pfnNetCbk(pxState->hNetCbk,NETCBK_TLD,hData);
    break;

  default:
    ASSERT(0);
  }


  return NETERR_NOERR;
}

/*
 * PppInstanceULInterfaceCreate
 *  Creates a UL interface on the instance
 *
 *  Args:
 *   hPpp              instance handle
 *
 *  Return:
 *   Interface handle
 */
H_NETINTERFACE PppInstanceULInterfaceCreate(H_NETINSTANCE hPpp)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;
  PPP_CHECK_STATE(pxState);

  pxState->pxUlTable = (PPPULIF *)
    realloc(pxState->pxUlTable,
            (++pxState->wUlTableSize) * sizeof(PPPULIF));
  ASSERT(pxState->pxUlTable != NULL);

  return (H_NETINTERFACE)pxState->wUlTableSize;
}

/*
 * PppInstanceULInterfaceDestroy
 *  Creates a UL interface on the instance
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceULInterfaceDestroy(H_NETINSTANCE hPpp,H_NETINTERFACE hIf)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;
  PPPULIF *pxUlIf;
  PPP_CHECK_STATE(pxState);

  ASSERT((WORD)hIf > 0);
  ASSERT((WORD)hIf <= pxState->wUlTableSize);

  pxUlIf = &(pxState->pxUlTable[(WORD)hIf - 1]);

  /* This should only happen when tearing down the instance:
     just mark the protocol id field with PPPID_NONE, and set
     bUp to FALSE */

  pxUlIf->wProtocolId = PPPID_NONE;
  pxUlIf->obUp = FALSE;

  return NETERR_NOERR;
}

/*
 * PppInstanceULInterfaceIoctl
 *  UL interface ioctl function
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *   oIoctl            ioctl code
 *   hData             data handle
 *
 *  Return:
 *   >=0 for success
 */
LONG PppInstanceULInterfaceIoctl(H_NETINSTANCE hPpp,H_NETINTERFACE hIf,
                                 OCTET oIoctl,H_NETDATA hData)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;
  PPPULIF *pxUlIf;
  PPP_CHECK_STATE(pxState);

  ASSERT((WORD)hIf > 0);
  ASSERT((WORD)hIf <= pxState->wUlTableSize);

  PPP_DBGP(REPETITIVE,"PppInstanceULInterfaceIoctl:hPpp=%d,hIf=%d,oIoctl=%d,hData=%d\n",
           (int)hPpp,(int)hIf,oIoctl,(int)hData);

  pxUlIf = &(pxState->pxUlTable[(WORD)hIf - 1]);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
    /* Open the interface to traffic */
    pxUlIf->obUp = TRUE;
    break;

  case NETINTERFACEIOCTL_CLOSE:
    /* Open the interface to traffic */
    pxUlIf->obUp = FALSE;
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxUlIf->hUl = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxUlIf->pfnRxCbk = (PFN_NETRXCBK)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxUlIf->hUlIf = (H_NETINTERFACE)hData;
    break;

  case NETINTERFACEIOCTL_SETROUTINGID:
    pxUlIf->wProtocolId = (WORD)hData;

    /* Check for local/remote AP/LQP settings */
    if (pxUlIf->wProtocolId > 0xC000) {
      if (pxUlIf->wProtocolId ==
          (WORD)pxState->ahLcpLocalOption[PPPLCPOPTION_AP]) {
        pxState->ahLcpLocalOption[PPPLCPOPTION_AP] =
          (H_NETDATA) (hIf -1);
      }
      if (pxUlIf->wProtocolId ==
          (WORD)pxState->ahLcpLocalOption[PPPLCPOPTION_LQP]) {
        pxState->ahLcpLocalOption[PPPLCPOPTION_LQP] =
          (H_NETDATA) (hIf -1);
      }
      if (pxUlIf->wProtocolId ==
          (WORD)pxState->ahLcpRemoteOption[PPPLCPOPTION_AP]) {
        pxState->ahLcpRemoteOption[PPPLCPOPTION_AP] =
          (H_NETDATA) (hIf -1);
      }
      if (pxUlIf->wProtocolId ==
          (WORD)pxState->ahLcpRemoteOption[PPPLCPOPTION_LQP]) {
        pxState->ahLcpRemoteOption[PPPLCPOPTION_LQP] =
          (H_NETDATA) (hIf -1);
      }
    }
    break;

  default:
    ASSERT(0);
  }

  return NETERR_NOERR;
}

/*
 * PppInstanceLLInterfaceCreate
 *  Creates the Ppp LL interface
 *
 *  Args:
 *   hPpp              instance handle
 *
 *  Return:
 *   Interface handle
 */
H_NETINTERFACE PppInstanceLLInterfaceCreate(H_NETINSTANCE hPpp)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;

  PPP_CHECK_STATE(pxState);
  ASSERT(pxState->oLLNumber == 0);

  PPP_DBGP(REPETITIVE,"PppInstanceLLInterfaceCreate:hPpp=%d\n",(int)hPpp);

  pxState->oLLNumber = 1;

  return (H_NETINTERFACE) 1;
}

/*
 * PppInstanceLLInterfaceDestroy
 *  Destroy the Ppp LL interface
 *
 *  Args:
 *   hPpp              instance handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceLLInterfaceDestroy(H_NETINSTANCE hPpp,H_NETINTERFACE hIf)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;

  PPP_CHECK_STATE(pxState);
  ASSERT(pxState->oLLNumber == 1);

  pxState->oLLNumber = 0;

  PPP_DBGP(REPETITIVE,"PppInstanceLLInterfaceDestroy:hPpp=%d\n",(int)hPpp);

  PppInstanceMsg(hPpp,NETMSG_LOWERLAYERDOWN,(H_NETDATA)0);

  return NETERR_NOERR;
}

/*
 * PppInstanceLLInterfaceIoctl
 *  LL interface ioctl
 *
 *  Args:
 *   hPpp              instance handle
 *   hIf               interface handle
 *   oIoctl            ioctl code
 *   hData             data handle
 *
 *  Return:
 *   >=0
 */
LONG PppInstanceLLInterfaceIoctl(H_NETINSTANCE hPpp,H_NETINTERFACE hIf,
                                 OCTET oIoctl,H_NETDATA hData)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;
  PPP_CHECK_STATE(pxState);
  ASSERT(1 == (OCTET)hIf);

  switch(oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_SETROUTINGID:
    break;

  case NETINTERFACEIOCTL_CLOSE:
    PppInstanceMsg(hPpp,NETMSG_LOWERLAYERDOWN,(H_NETDATA)0);
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxState->hLl = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxState->pfnNetWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxState->hLlIf = (H_NETINTERFACE)hData;
    break;

  default:
    ASSERT(0);
  }

  return NETERR_NOERR;
}

/*
 * PppInstanceProcess
 *  Ppp Process function
 *
 *  Args:
 *   hPpp              instance handle
 *
 *  Return:
 *   delay till next call
 */
LONG PppInstanceProcess(H_NETINSTANCE hPpp)
{
  PPPSTATE *pxState = (PPPSTATE *)hPpp;

  LONG lReturn = 50, lRv= 0x7FFFFFFF;
  DWORD dwTime;

  PPP_CHECK_STATE(pxState);
  ASSERT(pxState->pfnNetCbk != NULL);
  dwTime = NetGlobalTimerGet();

  if (pxState->ePhase != PPPPHASE_DEAD) {
    lRv = PppCpInstanceProcess(pxState->hCp);
    if (lRv < lReturn) {
      lReturn = lRv;
    }

    if (pxState->dwIdleTOCurrent != PPPIDLETO_NONE) {
        /* Check idle Time out */
        if (pxState->dwNextIdleTO < dwTime) {
          pxState->pfnNetCbk(pxState->hNetCbk,PPPCBK_IDLETO,(H_NETDATA)0);
        }
        else {
          lRv = pxState->dwNextIdleTO - dwTime;
          if (lRv < lReturn) {
            lReturn = lRv;
          }
        }
    }

    /* Check the status of the echo */
    if (pxState->dwEchoTOCurrent != PPPECHOTO_NONE) {
        /* Check Echo Time out */
        if (pxState->dwNextEchoTO < dwTime) {
          if (pxState->dwEchoCount > 0) {
        /* Send an LCP echo request */
        PppCpInstanceMsg(pxState->hCp,PPPCPMSG_ECHOREQUEST,(H_NETDATA)0);
            pxState->dwEchoCount--;

        /* Figure out when next to send a request */
        pxState->dwEchoTOCurrent = NetGetMsecTime();
        pxState->dwNextEchoTO = (pxState->dwEchoTOCurrent + pxState->dwEchoTO);
            PPP_DBGP(REPETITIVE,"PppInstanceProcess: Echo Request, dwEchoCount=%ld, time=%ld, pxState->dwEchoTO=%ld, pxState->dwNextEchoTO=%ld\n", pxState->dwEchoCount, pxState->dwEchoTOCurrent, pxState->dwEchoTO, pxState->dwNextEchoTO);
          }
          else if (pxState->dwEchoCount == 0) {
            PPP_DBGP(REPETITIVE,"PppInstanceProcess: Echo Timeout\n");
            /* Too many requests have been sent unanswered, signal up to close the link */
            pxState->pfnNetCbk(pxState->hNetCbk,PPPCBK_ECHOTO,(H_NETDATA)0);
          }
      else {
            /* This should be case where we don't want to use the echo timer */
            /* Do nothing */
      }
        }
        else {
          lRv = pxState->dwNextEchoTO - dwTime;
          if (lRv < lReturn) {
            lReturn = lRv;
          }
        }
    }

  }

  return lReturn;
}

