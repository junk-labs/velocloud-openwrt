#ifndef __IPSEC_FLAVOR_H__
#define __IPSEC_FLAVOR_H__

/* Map the build flavor into more meaningful constants internal
 * to the library.  The constant _FLAVOR_myflavor where myflavor is
 * the build flavor will be defined by the build environment.
 *
 * Be sure to check that a valid build flavor is defined.
 *
 * This file should be included by all source files.
*/

#if defined(_FLAVOR_gn)

#else
 #  error Unknown Build Flavor 
#endif

#endif
