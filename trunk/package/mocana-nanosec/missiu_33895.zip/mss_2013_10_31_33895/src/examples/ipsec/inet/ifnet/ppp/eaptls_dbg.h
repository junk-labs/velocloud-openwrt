/*
 * eaptls_dbg.h
 *
 * eaptls module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _EAPTLS_DBG_H_
#define _EAPTLS_DBG_H_

#ifndef NDEBUG

  #ifdef NETDBG_HI
    #ifndef EAPTLSDBG_HI
      #define EAPTLSDBG_HI
    #endif
  #endif

#else

  #ifdef EAPTLSDBG_HI
    #undef EAPTLSDBG_HI
  #endif

#endif

#include "netdbg.h"


/*
 * Constants
 */
#define EAPTLS_MAGIC_COOKIE 0x65617000 /*"eaptls" = 0x63686170*/


/*
 * Debug macros
 */
/*#ifdef EAPTLSDBG_HI*/
#if defined(EAPTLSDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define EAPTLS_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == EAPTLS_MAGIC_COOKIE));

  #define EAPTLS_SET_COOKIE(x) (x)->dwMagicCookie = EAPTLS_MAGIC_COOKIE
  #define EAPTLS_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define EAPTLS_DBGP(level, fmt, args...) do { \
    if (level <= g_dwEapTlsDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define EAPTLS_DBG(level, x) do {  \
    if (level <= g_dwEapTlsDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define EAPTLS_DBG_VAR(x)  x
#else
  #define EAPTLS_CHECK_STATE(x)
  #define EAPTLS_SET_COOKIE(x)
  #define EAPTLS_UNSET_COOKIE(x)
  #define EAPTLS_DBGP(level, fmt, args...)
  #define EAPTLS_DBG(level, x)
  #define EAPTLS_DBG_VAR(x)
#endif

EAPTLS_DBG_VAR(MOC_EXTERN DWORD g_dwEapTlsDebugLevel);

/*
 * Debug levels
 */
#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _EAPTLS_DBG_H_ */
