/*
 * sockopts.c
 *
 * Provides functions for socket manipulation, utility functions.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/in.h"
#include "mqueue.h"
#include "dllist.h"
#include "../include/ioctl.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "igmp.h"
#include "netdefs.h"
#include "netutils.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "ethernet.h"
#include "routing_table.h"



/****************************************************************************
 *
 * Local functions
 *
 ****************************************************************************/

LONG _MulticastFindIpMcastReq(void* pvIpMReq,void* pvIpMReqRef)
{
  IP_MREQ *pxIpReq    = (IP_MREQ*)pvIpMReq;
  IP_MREQ *pxIpReqRef = (IP_MREQ*)pvIpMReqRef;

  SOCKET_ASSERT((pxIpReq    != NULL) &&
                (pxIpReqRef != NULL));

  if((pxIpReq->imr_multiaddr.s_addr == pxIpReqRef->imr_multiaddr.s_addr) &&
     (pxIpReq->imr_interface.s_addr == pxIpReqRef->imr_interface.s_addr)){
    return 0;
  } else {
    return -1;
  }
}

/*
 * MulticastJoin
 *  Join a multicast group. Socket must be UDP
 *
 *  Args:
 *   pxSock                    Socket
 *   pxMReq                    Multicast req
 *
 *  Return:
 *   >=0 if successfull
 */
LONG MulticastJoin(SOCKET *pxSock,IP_MREQ *pxMReq)
{
  NETWRAPPER *pxNetWrapper = NETGETWRAPPER;
  LONG lReturn = 0;
  IPMCASTREQ xIpMcastReq = {(DWORD)0,NETIFIDX_ANY},*pxIpMcastReq = NULL;
#ifdef SOCK_IPTABLEMCAST
  IPTABLEENTRY xEntry;
#endif

  SOCKET_ASSERT(pxNetWrapper != NULL);

  xIpMcastReq.dwMulticastAddr = (DWORD)pxMReq->imr_multiaddr.s_addr;
  xIpMcastReq.dwMulticastIf   = (DWORD)pxMReq->imr_interface.s_addr;

  if ((DWORD)pxMReq->imr_interface.s_addr == INADDR_ANY) {
    xIpMcastReq.oPhyIf = RoutingTableMsg(ROUTINGTABLEMSG_GETDEFAULTIDX,(H_NETDATA)0);
  } else {
#ifdef SOCK_IPTABLEMCAST
    xEntry.dwAddr = (DWORD)pxMReq->imr_interface.s_addr;
    xEntry.eAddrType = IPADDRT_MYADDR;
    xEntry.oIfIdx = (pxSock->oBoundFlag & SOCKETBOUNDFLAG_IF) ?
      pxSock->xTransportId.xNetId.oIfIdx : NETIFIDX_ANY;
    xEntry.wDefaultVlan = (pxSock->oBoundFlag & SOCKETBOUNDFLAG_VLAN) ?
      pxSock->xTransportId.xNetId.wVlan : NETVLAN_ANY;

    xIpMcastReq.oPhyIf =
      (OCTET)IpTableMsg(IPTABLEMSG_GETIFIDX, (H_NETDATA)&xEntry);
#else
    xIpMcastReq.oPhyIf = RoutingTableMsg(ROUTINGTABLEMSG_GETDEFAULTIDX,(H_NETDATA)0);
#endif
  }

  if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, NORMAL))
  {
      DEBUG_PRINT(DEBUG_MOC_IPV4, "MulticastJoin: addr =  ");
      /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4, xIpMcastReq.dwMulticastAddr);*/
      DEBUG_INT(DEBUG_MOC_IPV4, xIpMcastReq.dwMulticastAddr);
      DEBUG_PRINT(DEBUG_MOC_IPV4, " on if = ");
      /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4, xIpMcastReq.dwMulticastIf);*/
      DEBUG_INT(DEBUG_MOC_IPV4, xIpMcastReq.dwMulticastIf);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", oIfIdx = ", xIpMcastReq.oPhyIf);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
  }

  if (xIpMcastReq.oPhyIf != NETIFIDX_ANY) {

#ifdef SOCK_IPTABLEMCAST
    xEntry.dwAddr = xIpMcastReq.dwMulticastAddr;
    xEntry.eAddrType = IPADDRT_MULTICASTJOINED;

    if((pxSock != NULL) && (pxSock->oBoundFlag & SOCKETBOUNDFLAG_VLAN)){
      xEntry.wDefaultVlan = pxSock->xTransportId.xNetId.wVlan;
    } else {
      xEntry.wDefaultVlan = NETVLAN_ANY;
    }

    lReturn = IpTableMsg(IPTABLEMSG_ADDENTRY, (H_NETDATA)&xEntry);
    ASSERT(lReturn == 0);
#endif

    lReturn = IgmpInstanceMsg(xSocketRep.hIgmp,IGMPMSG_JOIN,(H_NETDATA) &xIpMcastReq);
    ASSERT(lReturn == 0);

    if(pxSock != NULL){
      lReturn = UdpInstanceULInterfaceIoctl(xSocketRep.axProtocols[UDP_INDEX].hInst,
                                            pxSock->hLL,
                                            UDPULINTERFACEIOCTL_MCASTJOIN,
                                            (H_NETDATA) &xIpMcastReq);
      ASSERT(lReturn == 0);
    }

/* JJ Made ifndef to ifdef */
#ifdef MAC_DRIVER_NO_FILTERING
    if (ETH == pxNetWrapper->pxIfConf[xIpMcastReq.oPhyIf].ePhyLinkType) {
      int iFd = pxNetWrapper->pxIfConf[xIpMcastReq.oPhyIf].iFd;
      OCTET aoHwAddr[6];
      IpBuildMCastEthAddr(aoHwAddr,xIpMcastReq.dwMulticastAddr);
      lReturn = ioctl(iFd,ETHERDRV_DATA_LINK_DISABLE);
      ASSERT(lReturn == 0);

      lReturn = ioctl(iFd,ETHERDRV_ADD_MULTICAST,aoHwAddr);
      ASSERT(lReturn == 0);

      lReturn = ioctl(iFd,ETHERDRV_DATA_LINK_ENABLE);
      ASSERT(lReturn == 0);
    }
#endif /*#ifdef MAC_DRIVER_FILTERING*/

      pxIpMcastReq = (IPMCASTREQ *)MALLOC(sizeof(IPMCASTREQ));
      ASSERT(pxIpMcastReq != NULL);
      MOC_MEMSET((ubyte *)pxIpMcastReq, 0, sizeof(IPMCASTREQ));

      MOC_MEMCPY((ubyte *)pxIpMcastReq,(ubyte *)&xIpMcastReq,sizeof(IPMCASTREQ));
      (void*)DLLIST_append(&pxNetWrapper->dllIpMcastReq,(void*)pxIpMcastReq);

  }
  else {
    ASSERT(0);
    lReturn = -1;
  }

  return lReturn;
}

/*
 * MulticastLeave
 *  Leaves a multicast group
 *
 *  Args:
 *   pxSock             Socket
 *   pxMReq             Multicast req
 *
 *  Return:
 *   >=0 if successfull
 */
LONG MulticastLeave(SOCKET *pxSock,IP_MREQ *pxMReq)
{
  NETWRAPPER *pxNetWrapper = NETGETWRAPPER;
  NETIFCONF *pxNetIfConf;
  OCTET oPhyIf;
  DLLIST *pdllIpMcastReq;
  LONG lReturn = -1;
  IPMCASTREQ *pxIpMcastReq,xIpMcastReq;
#ifdef SOCK_IPTABLEMCAST
  IPTABLEENTRY xEntry;
#endif

  SOCKET_ASSERT(pxNetWrapper != NULL);

  pdllIpMcastReq = &pxNetWrapper->dllIpMcastReq;

  xIpMcastReq.dwMulticastAddr = (DWORD)pxMReq->imr_multiaddr.s_addr;
  xIpMcastReq.dwMulticastIf   = (DWORD)pxMReq->imr_interface.s_addr;

  DLLIST_head(pdllIpMcastReq);
  pxIpMcastReq = DLLIST_find(pdllIpMcastReq,&xIpMcastReq,_MulticastFindIpMcastReq);

  if(pxIpMcastReq == NULL){
    ASSERT(0);
    return -1;
  }

  if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, NORMAL))
  {
      DEBUG_PRINT(DEBUG_MOC_IPV4, "MulticastLeave: addr =  ");
      /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4, pxIpMcastReq->dwMulticastAddr);*/
      DEBUG_INT(DEBUG_MOC_IPV4, pxIpMcastReq->dwMulticastAddr);
      DEBUG_PRINT(DEBUG_MOC_IPV4, " on if = ");
      /*DEBUG_ASCIPADDR(DEBUG_MOC_IPV4, pxIpMcastReq->dwMulticastIf);*/
      DEBUG_INT(DEBUG_MOC_IPV4, pxIpMcastReq->dwMulticastIf);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", oIfIdx = ", pxIpMcastReq->oPhyIf);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
  }

  oPhyIf = pxIpMcastReq->oPhyIf;
  pxNetIfConf = NETGETIFCONF(pxNetWrapper,oPhyIf);

  if (oPhyIf != NETIFIDX_ANY) {

/* JJ Made ifndef ifdef */
#ifdef MAC_DRIVER_NO_FILTERING
    if (ETH == pxNetIfConf->ePhyLinkType) {
      int iFd = pxNetIfConf->iFd;
      OCTET aoHwAddr[6];
      IpBuildMCastEthAddr(aoHwAddr,pxIpMcastReq->dwMulticastAddr);

      lReturn = ioctl(iFd,ETHERDRV_DATA_LINK_DISABLE);
      ASSERT(lReturn == 0);

      lReturn = ioctl(iFd,ETHERDRV_DROP_MULTICAST,aoHwAddr);
      ASSERT(lReturn == 0);

      lReturn = ioctl(iFd,ETHERDRV_DATA_LINK_ENABLE);
      ASSERT(lReturn == 0);
    }
#endif /*#ifdef MAC_DRIVER_FILTERING*/

#ifdef SOCK_IPTABLEMCAST
    /* Delete entry from the Ip Table */
    xEntry.oIfIdx = oPhyIf;
    ASSERT(oPhyIf < IFNUMMAX);
    xEntry.dwAddr = pxIpMcastReq->dwMulticastAddr;
    xEntry.wDefaultVlan = (pxSock->oBoundFlag & SOCKETBOUNDFLAG_VLAN) ?
      pxSock->xTransportId.xNetId.wVlan : NETVLAN_ANY;
    xEntry.eAddrType = IPADDRT_MULTICASTJOINED;

    lReturn = IpTableMsg(IPTABLEMSG_DELENTRY, (H_NETDATA)&xEntry);
    ASSERT(lReturn == 0);
#endif

    /* Tell igmp to leave the group */
    lReturn = IgmpInstanceMsg(xSocketRep.hIgmp,IGMPMSG_LEAVE,(H_NETDATA) pxIpMcastReq);
    ASSERT(lReturn == 0);

    if(pxSock != NULL){
      /* Tell Udp that that multicast address has been dropped */
      lReturn = UdpInstanceULInterfaceIoctl(xSocketRep.axProtocols[UDP_INDEX].hInst,
                                            pxSock->hLL,
                                            UDPULINTERFACEIOCTL_MCASTDROP,
                                            (H_NETDATA) pxIpMcastReq);
      ASSERT(lReturn == 0);
    }
  }
  else {
    ASSERT(0);
    lReturn = -1;
  }

  DLLIST_remove(pdllIpMcastReq);
  FREE(pxIpMcastReq);

  return lReturn;
}

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * inet_pton
 *  Convert IP address from representation ASCII dot separated format
 *  to binary format
 *
 *  Arg:
 *   lFamily                      protocol family: AF_INET, AF_INET6 (IPV6)
 *   strptr                       string address
 *   addrptr                      pointer to fill up with the address
 *
 *  Return:
 *   1 - success,
 *   0 - bad address format
 *   -1 unknown protocol family
 */
int inet_pton(int lFamily, const char *strptr, void * addrptr)
{

  if(lFamily == AF_INET) {
    struct in_addr in_value;
    /* Need a stricter inet_aton, check posix */
#ifdef __RTOS_VXWORKS__
    if( (inet_aton(strptr, &in_value)) == 0) {
#else
    if( (inet_aton(strptr, &in_value)) != 0) {
#endif
      MOC_MEMCPY((ubyte *)addrptr,(ubyte *) &in_value, sizeof(struct in_addr));
      return 1;
    }
    return 0;
  }

  mn_errno = MO_EAFNOSUPPORT;
  return -1;
}

/*
 * mo_inet_addr
 *  Convert IP address in ASCII dot notation to DWORD
 *  NOTE:
 *   mo_inet_aton is preferred over inet_addr  UNP Steven v1 p71
 *
 *  Arg:
 *   strptr                       IP address to convert
 *
 *  Return:
 *   IPv4 address as DWORD (in_addr_t)
 */
in_addr_t mo_inet_addr(const char *strptr)
{

 struct in_addr inaddr;

#ifdef __RTOS_VXWORKS__
 if( (inet_aton(strptr, &inaddr)) == 0) {
#else
 if( (inet_aton(strptr, &inaddr)) != 0) {
#endif
   return inaddr.s_addr;
 }

  return INADDR_NONE;
}


/*
 * inet_ntoa
 *  Convert IP address to ASCII dot notation
 *      !!! FUNCTION IS NOTE RE ENTRANT !!!
 *
 * Arg:
 *  inaddr                        IP address to convert
 *
 * Return:
 *  pointer to ASCII string
 */
static char szAscBuf[16];
char *mo_inet_ntoa(struct in_addr inaddr)
{
  in_addr_t s_addr = inaddr.s_addr;
  sprintf(szAscBuf, "%d.%d.%d.%d", ((OCTET *) &s_addr)[0],
         ((OCTET *)&s_addr)[1],
         ((OCTET *)&s_addr)[2],
         ((OCTET *)&s_addr)[3]);

  return szAscBuf;
}

/*
 * inet_aton
 *  Convert IP address in ASCII dot notation, to in_addr structure
 *
 *  Arg:
 *   strptr                       address to convert
 *   addrptr                      destination for converted address
 *
 *  Return:
 *   1 on success, 0 on failure
 */
int mo_inet_aton(const char *strptr, struct in_addr *addrptr)
{
  register char c;
  register unsigned long dwBase, dwValue, dwNum;
  unsigned long dwUnits[4], *pPtr = dwUnits;

  for (;;) {
    dwValue = 0;
    dwBase = 10;
    if (*strptr == '0') {
      if (*++strptr == 'x' || *strptr == 'X') {
    dwBase = 16;
    strptr++;
      }
      else {
    dwBase = 8;
      }
    }
    while ((c = *strptr) != '\0') {
      if (MOC_ISASCII((unsigned char) c) && MOC_ISDIGIT((unsigned char) c)) {
    dwValue = (dwValue * dwBase) + (c - '0');
    strptr++;
    continue;
      }
      if (dwBase == 16 && MOC_ISASCII((unsigned char) c)
          && MOC_ISXDIGIT((unsigned char) c)) {
    dwValue = (dwValue << 4) +
      (c + 10 - (MOC_ISLOWER((unsigned char) c) ? 'a' : 'A'));
    strptr++;
    continue;
      }
      break;
    }
    if (*strptr == '.') {
      if (dwValue > 0xff || pPtr >= dwUnits + 3)
    return (0);
      *pPtr++ = dwValue;
      strptr++;
    }
    else {
      break;
    }
  }

  if (*strptr && (!MOC_ISASCII((unsigned char) *strptr) ||
                  !MOC_ISSPACE((unsigned char) *strptr))) {
    return (0);
  }

  dwNum = pPtr - dwUnits + 1;
  switch (dwNum) {

  case 1:                /* a */
    break;

  case 2:                /* a.b */
    if (dwValue > 0xffffff)
      return (0);
    dwValue |= dwUnits[0] << 24;
    break;

  case 3:                /* a.b.c */
    if (dwValue > 0xffff)
      return (0);
    dwValue |= (dwUnits[0] << 24) | (dwUnits[1] << 16);
    break;

  case 4:                /* a.b.c.d */
    if (dwValue > 0xff)
      return (0);
    dwValue |= (dwUnits[0] << 24) | (dwUnits[1] << 16) |
      (dwUnits[2] << 8);
    break;
  }
  if (addrptr) {
    addrptr->s_addr = htonl(dwValue);
  }

  return (1);

}

/*
 * mo_inet_getpeername
 *  Gets remote protocol address associated with a socket
 *
 *  Args:
 *   lsockfd                       The socket returned by the socket function.
 *   peeraddr                      Pointer to structure into which the remote
 *                                 address information is stored.
 *   addrlen:                      On return, pointer to the length of the
 *                                 structure 'peeraddr' points to.
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int mo_inet_getpeername(int lSockfd, struct sockaddr *peeraddr, socklen_t *addrlen)
{
  SOCKET *pxSock;
  struct sockaddr_in *peeraddr_in=NULL;

#ifdef STRICT_POSIX
  if (peeraddr == 0 || addrlen == 0) {
    mn_errno = EFAULT;
    return -1;
  }
#else
  ASSERT((peeraddr != 0) && (addrlen != 0));
#endif

  SOCKET_CHECKFD(lSockfd);

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  if ((pxSock = RETRIEVE_SOCKET(lSockfd)) == NULL) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  if(!(pxSock->dwSockState & SS_ISCONNECTED)) {
    mn_errno = MO_ENOTCONN;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  peeraddr_in = (struct sockaddr_in *) peeraddr;

  peeraddr_in->sin_family = pxSock->lFamily;

  {
    OCTET oProt;
    H_NETINSTANCE hInst;
    PFN_NETIOCTL pfnIoctl;

    oProt = SOCKTYPE2PROTINDEX(pxSock->lType);
    hInst = xSocketRep.axProtocols[oProt].hInst;
    pfnIoctl = xSocketRep.axProtocols[oProt].pfnIoctl;

    pfnIoctl(hInst,pxSock->hLL,
             NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEIP,
             (H_NETDATA) (&peeraddr_in->sin_addr.s_addr));
    pfnIoctl(hInst,pxSock->hLL,
             NETTRANSPORTULINTERFACEIOCTL_QUERYREMOTEPORT,
             (H_NETDATA) (&peeraddr_in->sin_port));
  }

  *addrlen = sizeof(struct sockaddr_in);

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return 0;
}

/****************************************************************************
 *
 * Socket option handling
 *
 ****************************************************************************/

/****************************************************************************
 *Table 1.1: Option Name table
 *level           optname              Description
 *
 *SOL_SOCKET
 *                SO_ERROR             get and clear error code
 *
 ****************************************************************************/


/*
 * setsockopt
 *  Set options that affect a socket
 *
 *  Args:
 *   sockfd                       The socket returned by the socket function.
 *   level                        level at which the option is interpreted.
 *                              Should be SOL_SOCKET. IPPROTO_IP ,
 *                                IP_PROTO_TCP : Future implementation.
 *   optname                      The name of the option itself.
 *                                See table 1.1 below.
 *   optval                       Pointer to a variable from which the new
 *                                value of the option is retrieved.
 *   optlen                       Pointer to the size of the data stored in
 *                               'optval'.
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int mn_setsockopt(int lSockfd, int level, int optname, const void *optval,
               socklen_t optlen)
{
  int lRet=-1;
  SOCKET *pxSock;
  NETWORKID *pxNetId;

#ifdef STRICT_POSIX
  /* If length of the option is too big, return error */
  if (optlen > MLEN) {
    mn_errno = MO_EBADARG;
    return -1;
  }

  /* If pointer is NULL, return error */
  if (optval == 0 ) {
    mn_errno = MO_EFAULT;
    return -1;
  }
#else
  ASSERT((optlen <= MLEN) && (optval != 0 ));
#endif

  SOCKET_CHECKFD(lSockfd);

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
  if ((pxSock = RETRIEVE_SOCKET(lSockfd)) == NULL) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  pxNetId = (NETWORKID *) &(pxSock->xTransportId.xNetId);

  switch(level) {
  case SOL_SOCKET:
    switch(optname) {
    case SO_LINGER:
      /* check struct linger len etc */
      if (optlen != sizeof(struct linger)) {
        mn_errno = EBADARG;
        break;
      }
      if (pxSock->lType == SOCK_STREAM) {
        pxSock->dwLingerTimeOut = ((struct linger *) optval)->l_linger;
        if (((struct linger *) optval)->l_onoff) {
          pxSock->dwSockOptions |= optname;
        }
        else  {
          pxSock->dwSockOptions &=~optname;
        }
      }
      lRet = 0;
      break;

      /* Boolean options */
    case SO_DEBUG:
    case SO_KEEPALIVE:
    case SO_DONTROUTE:
    case SO_USELOOPBACK:
    case SO_BROADCAST:
    case SO_REUSEADDR:
    case SO_OOBINLINE:

      if (optlen < sizeof(int)) {
        mn_errno = EBADARG;
        break;
      }
      if (*((int *) optval)) {
        /* Set the option */
        pxSock->dwSockOptions |= optname;
      } else {
        /* Clear the option */
        pxSock->dwSockOptions &=~optname;
      }

      if (SO_REUSEADDR == optname) {
        OCTET oProtIdx;
        H_NETINSTANCE hInst;
        PFN_NETIOCTL pfnIoctl;

        oProtIdx = SOCKTYPE2PROTINDEX(pxSock->lType);
        hInst = xSocketRep.axProtocols[oProtIdx].hInst;
        pfnIoctl = xSocketRep.axProtocols[oProtIdx].pfnIoctl;

        pfnIoctl(hInst,pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_SETREUSEADDR,
                 (H_NETDATA) (* (int*)optval));
      }
      lRet = 0;
      break;

    case SO_RCVBUF:
      if (pxSock->lType == SOCK_STREAM) {
        if (optlen != sizeof(int)) {
          mn_errno = EBADARG;
        } else {
          TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                                      pxSock->hLL,
                                      TCPULINTERFACEIOCTL_SETWIN, *(int*)optval);
          lRet = 0;
        }
      } else {
        mn_errno = MO_EINVAL;
      }
      break;

    case SO_SNDBUF:
    case SO_SNDLOWAT:
    case SO_RCVLOWAT:
    case SO_SNDTIMEO:
    case SO_RCVTIMEO:
      mn_errno = MO_EINVAL;
      /* Not implemented */
      break;

    case SO_VLAN:
      /* check struct length */
      if (optlen != sizeof(struct vlan)) {
        lRet = -1;
        ASSERT(0);
        mn_errno = EBADARG;
        break;
      }

      ASSERT(ETHVLAN_TYPE == ((struct vlan *) optval)->wVlanProto);

      if (((struct vlan *) optval)->bVlanOnOff) {
        pxNetId->wVlan = ((struct vlan *) optval)->wVlanTCI;
        pxSock->dwSockOptions |= optname;
        pxSock->oBoundFlag |= SOCKETBOUNDFLAG_VLAN;
        if (NETERR_MEM ==
            EthInstanceMsg(xSocketRep.hEth,ETHMSG_ADDSPECIFICVLAN,
                           (H_NETDATA)pxNetId->wVlan)) {
          lRet = -1;
          mn_errno = MO_ENOMEM;
          break;
        }
      }
      else  {
        if (NETERR_NOERR != EthInstanceMsg(xSocketRep.hEth,
                                           ETHMSG_REMOVESPECIFICVLAN,
                                           (H_NETDATA)pxNetId->wVlan)) {
          lRet = -1;
          mn_errno = EBADARG;
          break;
        }
        pxSock->dwSockOptions &=~optname;
        pxSock->oBoundFlag &= ~SOCKETBOUNDFLAG_VLAN;
        pxNetId->wVlan = NETVLAN_ANY;
      }

      {
        OCTET oProtIdx;
        H_NETINSTANCE hInst;
        PFN_NETIOCTL pfnIoctl;

        oProtIdx = SOCKTYPE2PROTINDEX(pxSock->lType);
        hInst = xSocketRep.axProtocols[oProtIdx].hInst;
        pfnIoctl = xSocketRep.axProtocols[oProtIdx].pfnIoctl;

        pfnIoctl(hInst,pxSock->hLL,NETTRANSPORTULINTERFACEIOCTL_SETVLAN,
                 (H_NETDATA)pxNetId->wVlan);
      }
      lRet = 0;
      break;

    default:
      mn_errno = MO_ENOPROTOOPT;
      break;
    }
    break;

  case IPPROTO_IP:
    {
      switch (optname) {

      case IP_ADD_MEMBERSHIP:
        ASSERT((sizeof(struct ip_mreq) == optlen) &&
               (pxSock->lType == SOCK_DGRAM));
        lRet = MulticastJoin(pxSock,(struct ip_mreq *)optval);
        break;

      case IP_DROP_MEMBERSHIP:
        /* leave a multicast group */
        ASSERT((sizeof(struct ip_mreq) == optlen) &&
               (pxSock->lType == SOCK_DGRAM));
        lRet = MulticastLeave(pxSock, (struct ip_mreq *)optval);
        break;

      case IP_MULTICAST_IF:
        /* specify default interface for outgoing multicasts */
        ASSERT((optlen == sizeof(struct in_addr)) &&
               (pxSock->lType == SOCK_DGRAM) &&
               (pxSock->u.pxUdp != NULL));

        UdpInstanceULInterfaceIoctl(xSocketRep.axProtocols[UDP_INDEX].hInst,
                                    pxSock->hLL,
                                    UDPULINTERFACEIOCTL_MCASTADDR,
                                    (H_NETDATA)
                                    ((struct in_addr *) optval)->s_addr);

        lRet = 0;
        break;

      case IP_MULTICAST_TTL:
        /* specify TTL for outgoing multicasts */
        ASSERT((optlen == sizeof(OCTET)) &&
               (pxSock->lType == SOCK_DGRAM) &&
               (pxSock->u.pxUdp != NULL));

        pxSock->u.pxUdp->oMcastTtl = *((OCTET *)optval);
        lRet = 0;
        break;

#if TRIM_CODE
      case IP_MULTICAST_LOOP:
        /* enable or disable loopback of outgoing multicasts */
        ASSERT((optlen == sizeof(OCTET)) &&
               (pxSock->lType == SOCK_DGRAM);
               (pSock->u.pxUdp != NULL))

        pxSock->u.pxUdp->oMcastLoop = *((OCTET *)optval);
        lRet = 0;
        break;
#endif

      case IP_TOS:
        pxNetId->oToS = *((int *) optval);
        pxSock->oBoundFlag |= SOCKETBOUNDFLAG_TOS;
        lRet = 0;
        break;

    default:
      mn_errno = MO_ENOPROTOOPT;
      break;

      break;
      }
    }
  break;

  case IPPROTO_TCP:
  default:
    mn_errno = MO_ENOPROTOOPT;
    break;
  }

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return lRet;
}



