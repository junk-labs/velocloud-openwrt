/*
 * nat_rport.c
 *
 * Routines to handle random port binding.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "nat.h"
#include "nat_defs.h"


/*****************************************************************************
Function:
        NatRegisterRandomPortBinding()
Description:
        Registers a random port binding. A random port binding allows
        data to go thru' if only one of the ports matches an
        existing binding.
        eg.  TFTP servers listen on port 69. Once they get a
        request, they use a different (random) port for the
        data connection. In such cases a random port binding is
        required to facilitate a connection.
Arguments:
        NATSTATE*       pxNat                   NAT instance handle.
        WORD            wPortBeg                Start of port range
                                                (inclusive).
        WORD            wPortEnd                End of port range
                                                (inclusive).
        WORD            wFlags                  Specifies which
                                                protocol(s) should be
                                                forwarded.
Outputs:
        None
Returns:
        LONG            < 0                     If registration fails.
                                                Registration will fail
                                                if the port binding
                                                table is full.
                        0                       If registration succeeds.
Revisions:
        21-Nov-2001                             Initial
*****************************************************************************/
LONG NatRegisterRandomPortBinding(NATSTATE* pxNat,
                                  WORD wPortBeg,
                                  WORD wPortEnd,
                                  WORD wFlags)
{
  int i;
  NAT_RANDOM_PORT_BINDING* pxNatRandomPortBinding;

  /*
   * Look for a matching entry.
   * NOTE: This should never find a matching entry.
   *       Just being paranoid about duplicate entries
   *       taking up space.
   */
  for (i = 0; i < NAT_RANDOM_PORT_BINDING_SIZE; i++) {
    pxNatRandomPortBinding = &pxNat->axRandomPortBinding[i];

    if ((pxNatRandomPortBinding->bInUse == TRUE) &&
        (pxNatRandomPortBinding->wPortBeg == wPortBeg) &&
        (pxNatRandomPortBinding->wPortEnd == wPortEnd)) {
      break;
    }
  }

  if (i != NAT_RANDOM_PORT_BINDING_SIZE) {
    /*
     * Found a match, do nothing.
     */
    return (0);
  }


  /*
   * Find a free entry.
   */
  for (i = 0; i < NAT_RANDOM_PORT_BINDING_SIZE; i++) {
    pxNatRandomPortBinding = &pxNat->axRandomPortBinding[i];

    if (pxNatRandomPortBinding->bInUse == FALSE) {
      break;
    }
  }

  if (i == NAT_RANDOM_PORT_BINDING_SIZE) {
    /*
     * No free space. Need to increase the constant
     * NAT_RANDOM_PORT_BINDING_SIZE.
     */
    return (-1);
  }

  pxNatRandomPortBinding->bInUse = TRUE;
  pxNatRandomPortBinding->wPortBeg = wPortBeg;
  pxNatRandomPortBinding->wPortEnd = wPortEnd;
  pxNatRandomPortBinding->wFlags = wFlags;

  return (0);
}



/*****************************************************************************
Function:
        NatUnregisterRandomPortBinding()
Description:
        Unregisters a random port binding. The
        given range of ports should have been previously
        registered using NATRegisterRandomPortBinding().
Arguments:
        NATSTATE*       pxNat                   NAT instance handle.
        WORD            wPortBeg                Start of port range
                                                (inclusive).
        WORD            wPortEnd                End of port range
                                                (inclusive).
                                                forwarded.
Outputs:
        None
Returns:
        None
Revisions:
        21-Nov-2001                             Initial
*****************************************************************************/
void NatUnregisterRandomPortBinding(NATSTATE* pxNat,
                                    WORD wPortBeg,
                                    WORD wPortEnd)
{
  int i;
  NAT_RANDOM_PORT_BINDING* pxNatRandomPortBinding;


  /*
   * Look for a matching entry.
   */
  for (i = 0; i < NAT_RANDOM_PORT_BINDING_SIZE; i++) {
    pxNatRandomPortBinding = &pxNat->axRandomPortBinding[i];

    if ((pxNatRandomPortBinding->bInUse == TRUE) &&
        (pxNatRandomPortBinding->wPortBeg == wPortBeg) &&
        (pxNatRandomPortBinding->wPortEnd == wPortEnd)) {
      break;
    }
  }

  if (i != NAT_RANDOM_PORT_BINDING_SIZE) {
    pxNatRandomPortBinding->bInUse = FALSE;
  }

  return;
}


/*****************************************************************************
Function:
        NatIsRandomPortBinding()
Description:
        Check if the given port has been configured for a random
        port binding feature.
Arguments:
        NATSTATE*               pxNat           NAT instance handle.
        WORD                    wPort           Port number to be checked
                                                for forwarding match.
        OCTET                   oProtocol       Protocol used in the
                                                packet.
                                                Could be one of
                                                IPPROTO_TCP
                                                IPPROTO_UDP
Outputs:
        None
Returns:
        BOOL                    TRUE            If the binding is found.
                                FALSE           If the binding cannot be
                                                found.
Revisions:
        21-Nov-2001                             Initial
*****************************************************************************/
BOOL NatIsRandomPortBinding(NATSTATE* pxNat, WORD wPort, OCTET oProtocol)
{
  int i;
  WORD wFlags = (oProtocol == IPPROTO_TCP) ?
                (NAT_PORT_FORWARD_PROT_TCP) : (NAT_PORT_FORWARD_PROT_UDP);


  for (i = 0; i < NAT_RANDOM_PORT_BINDING_SIZE; i ++) {
    NAT_RANDOM_PORT_BINDING* pxNatRandomPortBinding = &pxNat->axRandomPortBinding[i];

    if (pxNatRandomPortBinding->bInUse == FALSE) {
      continue;
    }

    if ((pxNatRandomPortBinding->wPortBeg <= wPort) &&
        (pxNatRandomPortBinding->wPortEnd >= wPort) &&
        (pxNatRandomPortBinding->wFlags & wFlags)) {
      return (TRUE);
    }
  }

  return (FALSE);
}
