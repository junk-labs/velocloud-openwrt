/*
 * radix.c
 *
 * Radix module, with PATRICIA trees implementation
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*
 * Allocate and initialise an empty tree. At start the tree has 3 nodes all of which are
 * marked as "ROOT" so as to avoid deletion.
*/

#include "../../common/mdefs.h"
#include "../../common/mtypes.h"
#include "../../common/merrors.h"

#include "radix.h"

#define MAX_LIM 4
#define min(x, y) x - y

static RADIXNODEHEAD *pxRadNodeHeadMask = 0;
static ubyte *poZeros, *poOnes, *poAddMaskKey;
static ubyte4 dwZeros = 0x00000000, dwOnes = 0xFFFFFFFF;

static RADIXMASK* RadixCreateMask(RADIXNODE *pxRadixNode, RADIXMASK *pxRadixMask);
static sbyte4 RadixLexOBetter(ubyte4 dwMask1, ubyte4 dwMask2);
static RADIXNODE* RadixSearch(ubyte4 dwNetmask, RADIXNODE *pxHead);
static RADIXNODE* RadixSearchWithAdditionalMask(ubyte4 dwIpAddr, ubyte4 dwNetmask,
                                                RADIXNODE *pxHead);
static ubyte4 RadixSatisfiesLeaf(ubyte4 dwIpAddr, RADIXNODE *pxRadNodeLeaf,
                                 sbyte4 dwSkip);
static RADIXNODE* RadixInsertNode(ubyte4 dwIpAddr, RADIXNODEHEAD *pxHead,
                                  sbyte4 *pdwDupEntry, RADIXNODE xNodes[2]);
static RADIXNODE* RadixNewPair(ubyte4 dwNodeKey, sbyte2 wOffset,
                               RADIXNODE xNodes[2]);
static ubyte4 LEN (ubyte4 dwSize);

static sbyte4 RadixInitHead(RADIXNODEHEAD **ppxHead, sbyte4 wOffset);
static RADIXNODE* RadixAddMask(ubyte4 dwNetmask, sbyte4 dwSearch,
                               sbyte4 dwSkip);
static sbyte4 RadixRefines(ubyte4 dwNetmask, ubyte4 dwRadNodeNetmask);
static RADIXNODE* RadixMatch(ubyte4 dwIpAddr, RADIXNODEHEAD *pxRadNodeHead);


ubyte4
LEN(ubyte4 dwSize)
{
  if( dwSize == dwZeros )
    return 0;
  else if (dwSize == dwOnes)
    return 1;
  else
    return MAX_LIM;
}

RADIXNODEHEAD *
RadixInit()
{
  poZeros = (ubyte *)&dwZeros;
  poOnes  = (ubyte *)&dwOnes;
  MOC_MALLOC((void **)&poAddMaskKey, sizeof(ubyte4));
  MOC_MEMCPY(poAddMaskKey, &dwZeros, sizeof(ubyte4));
  RadixInitHead(&pxRadNodeHeadMask, 0);
  return pxRadNodeHeadMask;
}

static sbyte4
RadixInitHead(RADIXNODEHEAD **ppxHead, sbyte4 wOffset)
{
  MSTATUS mRetAlloc;
  RADIXNODEHEAD *pxRadNodeHead = 0;
  RADIXNODE     *pxRadNodeCenter, *pxRadNodeLeft, *pxRadNodeRight;

  if (*ppxHead)
    return 1;

  if(OK != MOC_MALLOC((void**)&pxRadNodeHead, sizeof(RADIXNODEHEAD)))
  {
     printf ("ERROR: unable to allocate memory \n");
     return 0;
  }

  *ppxHead = pxRadNodeHead;

  pxRadNodeCenter = RadixNewPair(dwZeros, wOffset, pxRadNodeHead->xNodes);

  pxRadNodeRight  = pxRadNodeHead->xNodes + 2;
  pxRadNodeCenter->RadixNodeRight = pxRadNodeRight;
  pxRadNodeCenter->pxParent = pxRadNodeCenter;
  pxRadNodeLeft = pxRadNodeCenter->RadixNodeLeft;

  pxRadNodeLeft->oNodeFlag = pxRadNodeCenter->oNodeFlag = RAD_ROOT | RAD_ACTIVE;
  pxRadNodeLeft->wBitOffset = -1 - wOffset;

  pxRadNodeRight->pxParent      = pxRadNodeCenter;
  pxRadNodeRight->wBitOffset    = pxRadNodeLeft->wBitOffset;
  pxRadNodeRight->oBMask        = pxRadNodeLeft->oBMask;
  pxRadNodeRight->oNodeFlag     = pxRadNodeLeft->oNodeFlag;
  pxRadNodeRight->RadixNodeKey  = dwOnes;

  pxRadNodeHead->pxTreeTop = pxRadNodeCenter;

  LIST_INIT(&(pxRadNodeHead->xRadixNodeList));
  LIST_INSERT_HEAD(&(pxRadNodeHead->xRadixNodeList), pxRadNodeLeft, xRadixNodeLink);
  LIST_INSERT_HEAD(&(pxRadNodeHead->xRadixNodeList), pxRadNodeRight, xRadixNodeLink);

  return 1;
}

RADIXNODE*
RadixAddRoute(ubyte4 dwIpAddr,
              ubyte4 dwNetmask,
              RADIXNODEHEAD *pxHead,
              RADIXNODE xTreeNodes[2])
{
  /*
   * AAGh!!!!! change the ip and mask to n/w order.
   */

  sbyte2 wLeaf = 0, wBitOffset = 0;
  RADIXNODE *pxRadNode = 0, *pxRadNodeInsert = 0, *pxRadNodeInsertTmp = 0;
  RADIXNODE *pxRadNodeIter = 0, *pxRadNodeTreeTop = pxHead->pxTreeTop;
  RADIXMASK *pxRadixMask = 0, **ppxRadixMask = 0;
  sbyte4 dwKeyDuplicated = 0;
  ubyte4 dwRadixNodeMask;

  dwIpAddr = htonl(dwIpAddr);
  dwNetmask = htonl(dwNetmask);

  /*
   * In dealing with non-contiguous masks, there may be
   * many different routes which have the same mask.
   * We will find it useful to have a unique pointer to
   * the mask to speed avoiding duplicate references at
   * nodes and possibly save time in calculating indices.
   */
  if (dwNetmask)
  {
    if ((pxRadNode = RadixAddMask(dwNetmask, 0, pxRadNodeTreeTop->RadixNodeOffset)) == 0)
      return (0);
    wLeaf = pxRadNode->wBitOffset;
    wBitOffset = -1 - pxRadNode->wBitOffset;
    dwNetmask = pxRadNode->RadixNodeKey;
  }
  /*
   * Deal with duplicated keys: attach node to previous instance
   */
  pxRadNodeInsert = pxRadNodeInsertTmp = RadixInsertNode(dwIpAddr, pxHead, &dwKeyDuplicated, xTreeNodes);
  if (dwKeyDuplicated)
  {
    for (pxRadNodeIter = pxRadNodeInsertTmp;
         pxRadNodeInsertTmp;
         pxRadNodeIter = pxRadNodeInsertTmp, pxRadNodeInsertTmp = pxRadNodeInsertTmp->RadixNodeDupedKey)
    {
      /*
       * Check if the mask are same and if the RadixNode is of RAD_ROOT type
       */
      if ((pxRadNodeInsertTmp->RadixNodeMask == dwNetmask) && !(pxRadNodeInsertTmp->oNodeFlag & RAD_ROOT))
        return (0);
      /*
       * On further continuation to the above comment, special handling for ip 0.0.0.0 with mask 0.0.0.0
       */
      if(dwNetmask == 0 && dwIpAddr == 0)
        continue;
      if (dwNetmask == 0 ||
          (pxRadNodeInsertTmp->RadixNodeMask &&
          ((wLeaf < pxRadNodeInsertTmp->wBitOffset)
          || RadixRefines(dwNetmask, pxRadNodeInsertTmp->RadixNodeMask)
          || RadixLexOBetter(dwNetmask, pxRadNodeInsertTmp->RadixNodeMask))))
            break;
    }
    /*
     * If the mask is not duplicated, we wouldn't
     * find it among possible duplicate key entries
     * anyway, so the above test doesn't hurt.
     *
     * We sort the masks for a duplicated key the same way as
     * in a masklist -- most specific to least specific.
     * This may require the unfortunate headache of relocating
     * the head of the list.
     *
     * We also reverse, or doubly link the list through the
     * parent pointer.
     */
     if ( pxRadNodeInsertTmp == pxRadNodeInsert)
     {
       RADIXNODE *pxRadNodeCpy = pxRadNode;
       /* link in at head of list */
       (pxRadNodeInsertTmp = xTreeNodes)->RadixNodeDupedKey = pxRadNodeIter;
       pxRadNodeInsertTmp->oNodeFlag  = pxRadNodeInsert->oNodeFlag;
       pxRadNodeInsertTmp->pxParent = pxRadNode = pxRadNodeInsert->pxParent;
       pxRadNodeInsert->pxParent = pxRadNodeInsertTmp;                      /* parent */
       if (pxRadNode->RadixNodeLeft == pxRadNodeIter)
         pxRadNode->RadixNodeLeft = pxRadNodeInsertTmp;
       else
         pxRadNode->RadixNodeRight = pxRadNodeInsertTmp;
       pxRadNodeInsert = pxRadNodeInsertTmp;
       pxRadNode = pxRadNodeCpy;
     }
     else
     {
       (pxRadNodeInsertTmp = xTreeNodes)->RadixNodeDupedKey = pxRadNodeIter->RadixNodeDupedKey;
       pxRadNodeIter->RadixNodeDupedKey = pxRadNodeInsertTmp;
       pxRadNodeInsertTmp->pxParent = pxRadNodeIter;                       /* parent */
       if (pxRadNodeInsertTmp->RadixNodeDupedKey)                              /* parent */
         pxRadNodeInsertTmp->RadixNodeDupedKey->pxParent = pxRadNodeInsertTmp; /* parent */
     }
     pxRadNodeInsertTmp->RadixNodeKey   = dwIpAddr;
     pxRadNodeInsertTmp->wBitOffset = -1;
     pxRadNodeInsertTmp->oNodeFlag  = RAD_ACTIVE;
     LIST_INSERT_HEAD(&(pxHead->xRadixNodeList), pxRadNodeInsertTmp, xRadixNodeLink);
  }
  else
  {
    LIST_INSERT_HEAD(&(pxHead->xRadixNodeList), pxRadNodeInsert, xRadixNodeLink);
  }

  /*
   * Put mask in tree.
  */
  if (dwNetmask)
  {
    pxRadNodeInsertTmp->RadixNodeMask = dwNetmask;
    pxRadNodeInsertTmp->wBitOffset = pxRadNode->wBitOffset;
    pxRadNodeInsertTmp->oNodeFlag |= pxRadNode->oNodeFlag & RAD_NORMAL;
  }
  pxRadNodeIter = pxRadNodeInsert->pxParent;

  if (dwKeyDuplicated)
    goto on2;

  wLeaf = -1 - pxRadNodeIter->wBitOffset;
  if (pxRadNodeIter->RadixNodeRight == pxRadNodeInsert)
    pxRadNode = pxRadNodeIter->RadixNodeLeft;
  else
    pxRadNode = pxRadNodeIter->RadixNodeRight;

  /* Promote general routes from below */
  if (pxRadNode->wBitOffset < 0)
  {
    for (ppxRadixMask = &pxRadNodeIter->pxMaskLst; pxRadNode; pxRadNode = pxRadNode->RadixNodeDupedKey)
      if (pxRadNode->RadixNodeMask && (pxRadNode->wBitOffset >= wLeaf) && pxRadNode->pxMaskLst == 0)
      {
        *ppxRadixMask = pxRadixMask = RadixCreateMask(pxRadNode, 0);
        if (pxRadixMask)
          ppxRadixMask = &pxRadixMask->pxMaskLst;
      }
  }
  else if (pxRadNode->pxMaskLst)
  {
    /*
     * Skip over masks whose index is > that of new node
     */
    for (ppxRadixMask = &pxRadNode->pxMaskLst; (pxRadixMask = *ppxRadixMask); ppxRadixMask = &pxRadixMask->pxMaskLst)
      if (pxRadixMask->wBitOffset >= wLeaf)
        break;
    pxRadNodeIter->pxMaskLst = pxRadixMask; *ppxRadixMask = 0;
  }

  on2:
  /*
   * Add new route to highest possible ancestor's list.
   * Check if the Radix Node is a ROOT node.
   */
  if (((dwNetmask == 0) || (wBitOffset > pxRadNodeIter->wBitOffset)) && !(pxRadNodeInsert->oNodeFlag & RAD_ROOT))
    return pxRadNodeInsertTmp;
  wLeaf = pxRadNodeInsertTmp->wBitOffset;
  do
  {
    /*Going up the ladder*/
    pxRadNode = pxRadNodeIter;
    pxRadNodeIter = pxRadNodeIter->pxParent;
  } while (wBitOffset <= pxRadNodeIter->wBitOffset && pxRadNode != pxRadNodeTreeTop);
  /*
   * Search through routes associated with node to
   * insert new route according to index.
   * Need same criteria as when sorting dupedkeys to avoid
   * double loop on deletion.
  */
  for (ppxRadixMask = &pxRadNode->pxMaskLst; (pxRadixMask = *ppxRadixMask); ppxRadixMask = &pxRadixMask->pxMaskLst)
  {
    if (pxRadixMask->wBitOffset < wLeaf)
      continue;
    if (pxRadixMask->wBitOffset > wLeaf)
      break;
    if (pxRadixMask->oNodeFlag & RAD_NORMAL)
    {
      dwRadixNodeMask = pxRadixMask->RadixMaskLeaf->RadixNodeMask;
      if (pxRadNodeInsertTmp->oNodeFlag & RAD_NORMAL)
      {
        /* printf("Non-unique normal route, mask not entered\n"); */
        return pxRadNodeInsertTmp;
      }
    }
    else
      dwRadixNodeMask = pxRadixMask->RadixMaskMask;
    if (dwRadixNodeMask == dwNetmask)
    {
      pxRadixMask->dwReferences++;
      pxRadNodeInsertTmp->pxMaskLst = pxRadixMask;
      return pxRadNodeInsertTmp;
    }
    if (RadixRefines(dwNetmask, dwRadixNodeMask)
        || RadixLexOBetter(dwNetmask, dwRadixNodeMask))
      break;
  }
  *ppxRadixMask = RadixCreateMask(pxRadNodeInsertTmp, *ppxRadixMask);
  return pxRadNodeInsertTmp;
}

RADIXNODE*
RadixDelete(ubyte4 dwIpAddress, ubyte4 dwNetmask,
            RADIXNODEHEAD *pxHead)
{
  /*
   * AAGh!!!!! change the ip and mask to n/w order.
   */

  RADIXNODE *pxRadNodeTreeTop = 0, *pxRadNodeSearch = 0, *pxRadNodeParent = 0;
  RADIXNODE *pxRadNodeSearchTmp = 0, *pxRadNodeTreeTopTmp = 0, *pxRadNodeDupedKey = 0;
  RADIXNODE *pxRadNodePredSearch = 0;
  RADIXMASK *pxRadixMask = 0, *pxRadixMaskTmp = 0, **ppxRadixMask = 0;
  sbyte4 dwHeadOffset = 0, wBitOffset = 0;

  dwIpAddress = htonl(dwIpAddress);
  dwNetmask = htonl(dwNetmask);
  pxRadNodeTreeTop = pxHead->pxTreeTop;
  /*
   * Search for the specfic-closest leaf
   */
  pxRadNodeSearch = RadixSearch(dwIpAddress, pxRadNodeTreeTop);

  dwHeadOffset = pxRadNodeTreeTop->RadixNodeOffset;
  if ((pxRadNodeSearch == 0) || (dwIpAddress != pxRadNodeSearch->RadixNodeKey)) /*Indicates that the node is not an exact match*/
    return (0);
  pxRadNodeSearchTmp = pxRadNodeSearch;
  pxRadNodeTreeTopTmp = pxRadNodeTreeTop;

  /*
   * Delete our route from mask lists.
   */
  if (dwNetmask)
  {
    if ((pxRadNodeTreeTop = RadixAddMask(dwNetmask, 1, dwHeadOffset)) == 0)
      return (0);
    dwNetmask = pxRadNodeTreeTop->RadixNodeKey;
    while (pxRadNodeSearch->RadixNodeMask != dwNetmask)
      if ((pxRadNodeSearch = pxRadNodeSearch->RadixNodeDupedKey) == 0)
        return (0);
  }

  if (pxRadNodeSearch->RadixNodeMask == 0 || (pxRadixMaskTmp = pxRadixMask = pxRadNodeSearch->pxMaskLst) == 0)
    goto on1;

  if (pxRadNodeSearch->oNodeFlag & RAD_NORMAL)
  {
    if (pxRadixMask->RadixMaskLeaf != pxRadNodeSearch || pxRadixMask->dwReferences > 0)
    {
      /* printf("RadixDelete: inconsistent annotation\n"); */
      return 0;  /* dangling ref could cause disaster */
    }
  }
  else
  {
    if (pxRadixMask->RadixMaskMask != pxRadNodeSearch->RadixNodeMask)
    {
      /* printf("RadixDelete: inconsistent annotation\n"); */
      goto on1;
    }
    if (--pxRadixMask->dwReferences >= 0)
      goto on1;
  }

  wBitOffset = -1 - pxRadNodeSearch->wBitOffset;
  pxRadNodeParent = pxRadNodeSearchTmp->pxParent;
  if (wBitOffset > pxRadNodeParent->wBitOffset)
    goto on1; /* Wasn't lifted at all */
  do
  {
    pxRadNodeTreeTop = pxRadNodeParent;
    pxRadNodeParent = pxRadNodeParent->pxParent;
  } while (wBitOffset <= pxRadNodeParent->wBitOffset && pxRadNodeTreeTop != pxRadNodeTreeTopTmp);

  for (ppxRadixMask = &pxRadNodeTreeTop->pxMaskLst; (pxRadixMask = *ppxRadixMask); ppxRadixMask = &pxRadixMask->pxMaskLst)
    if (pxRadixMask == pxRadixMaskTmp)
    {
      *ppxRadixMask = pxRadixMask->pxMaskLst;
      MOC_FREE((void **)&pxRadixMask);
      pxRadixMask = 0;
      break;
    }
  if (pxRadixMask == 0)
  {
    /* printf("RadixDelete: couldn't find our annotation\n"); */
    if (pxRadNodeSearch->oNodeFlag & RAD_NORMAL)
      return (0); /* Dangling ref to us */
  }

  on1:
  /*
   * Eliminate us from tree
   */
  if (pxRadNodeSearch->oNodeFlag & RAD_ROOT)
  {
    if(pxRadNodeSearch->RadixNodeDupedKey)
      pxRadNodeSearch = pxRadNodeSearch->RadixNodeDupedKey;
    else
      return (0);
  }

  pxRadNodeParent = pxRadNodeSearch->pxParent;
  pxRadNodeDupedKey = pxRadNodeSearchTmp->RadixNodeDupedKey;
  if (pxRadNodeDupedKey)
  {
    /*
     * Here, pxRadNodeSearch is the deletion target and
     * pxRadNodeSearchTmp is the head of the dupekey chain.
     */
    if ( pxRadNodeSearch == pxRadNodeSearchTmp )
    {
      /* remove from head of chain */
      pxRadNodeTreeTop = pxRadNodeDupedKey;
      pxRadNodeTreeTop->pxParent = pxRadNodeParent;
      if (pxRadNodeParent->RadixNodeLeft == pxRadNodeSearch)
        pxRadNodeParent->RadixNodeLeft = pxRadNodeTreeTop;
      else
        pxRadNodeParent->RadixNodeRight = pxRadNodeTreeTop;
    }
    else
    {
      /* find node in front of  pxRadNodeSearch on the chain */
      for (pxRadNodeTreeTop = pxRadNodePredSearch = pxRadNodeSearchTmp;
           pxRadNodePredSearch && pxRadNodePredSearch->RadixNodeDupedKey != pxRadNodeSearch;)
        pxRadNodePredSearch = pxRadNodePredSearch->RadixNodeDupedKey;
      if (pxRadNodePredSearch)
      {
        pxRadNodePredSearch->RadixNodeDupedKey = pxRadNodeSearch->RadixNodeDupedKey;
        if (pxRadNodeSearch->RadixNodeDupedKey)            /* parent */
          pxRadNodeSearch->RadixNodeDupedKey->pxParent = pxRadNodePredSearch;
      }
      else
        printf("RadixDelete: couldn't find us\n");
    }
    pxRadNodeParent = pxRadNodeSearch + 1;
    /*
     * Re-arranging the tree so that we remove out the contigous memory
     * location. Avoids garbage allocations within the tree.
     */
    if  (pxRadNodeParent->oNodeFlag & RAD_ACTIVE)
    {
      *++pxRadNodeTreeTop = *pxRadNodeParent;
      pxRadNodePredSearch = pxRadNodeParent->pxParent;
      if (pxRadNodePredSearch->RadixNodeLeft == pxRadNodeParent)
        pxRadNodePredSearch->RadixNodeLeft = pxRadNodeTreeTop;
      else
        pxRadNodePredSearch->RadixNodeRight = pxRadNodeTreeTop;
      pxRadNodeTreeTop->RadixNodeLeft->pxParent  = pxRadNodeTreeTop;
      pxRadNodeTreeTop->RadixNodeRight->pxParent = pxRadNodeTreeTop;
    }

    goto out;
  } /*end of duped Key*/

  if (pxRadNodeParent->RadixNodeLeft == pxRadNodeSearch)
    pxRadNodeTreeTop = pxRadNodeParent->RadixNodeRight;
  else
    pxRadNodeTreeTop = pxRadNodeParent->RadixNodeLeft;

  pxRadNodePredSearch = pxRadNodeParent->pxParent;

  if (pxRadNodePredSearch->RadixNodeRight == pxRadNodeParent)
    pxRadNodePredSearch->RadixNodeRight = pxRadNodeTreeTop;
  else
    pxRadNodePredSearch->RadixNodeLeft  = pxRadNodeTreeTop;

  pxRadNodeTreeTop->pxParent = pxRadNodePredSearch;

  /*
   * Demote routes attached to us.
   */
  if (pxRadNodeParent->pxMaskLst)
  {
    if (pxRadNodeTreeTop->wBitOffset >= 0)
    {
      for (ppxRadixMask = &pxRadNodeTreeTop->pxMaskLst; (pxRadixMask = *ppxRadixMask);)
        ppxRadixMask = &pxRadixMask->pxMaskLst;
      *ppxRadixMask = pxRadNodeParent->pxMaskLst;
    }
    else
    {
      /* If there are any key,mask pairs in a sibling
         duped-key chain, some subset will appear sorted
         in the same order attached to our mklist */
      for (pxRadixMask = pxRadNodeParent->pxMaskLst; pxRadixMask && pxRadNodeTreeTop; pxRadNodeTreeTop = pxRadNodeTreeTop->RadixNodeDupedKey)
        if (pxRadixMask == pxRadNodeTreeTop->pxMaskLst)
        {
          RADIXMASK *pxRadixMaskLst = pxRadixMask->pxMaskLst;
          pxRadNodeTreeTop->pxMaskLst = 0;
          if (--(pxRadixMask->dwReferences) < 0)
          {
            MOC_FREE((void**)&pxRadixMask);
            pxRadixMask = 0;
          }
          pxRadixMask = pxRadixMaskLst;
        }
      /*
      if (pxRadixMask)
        printf(
              "RadixDelete: Orphaned Mask %p at %p\n",
              (void *)pxRadixMask, (void *)pxRadNodeTreeTop);*/
    }
  }
  /*
   * We may be holding an active internal node in the tree.
   */
  pxRadNodeTreeTop = pxRadNodeSearch + 1;
  if (pxRadNodeParent != pxRadNodeTreeTop)
  {
    /*
     * Re-arranging the tree so that we remove out the contigous memory
     * location. Avoids garbage allocations within the tree.
     */
    *pxRadNodeParent = *pxRadNodeTreeTop;
    pxRadNodeParent->RadixNodeLeft->pxParent  = pxRadNodeParent;
    pxRadNodeParent->RadixNodeRight->pxParent = pxRadNodeParent;
    pxRadNodePredSearch = pxRadNodeTreeTop->pxParent;
    if (pxRadNodePredSearch->RadixNodeLeft == pxRadNodeTreeTop)
      pxRadNodePredSearch->RadixNodeLeft = pxRadNodeParent;
    else
      pxRadNodePredSearch->RadixNodeRight = pxRadNodeParent;
  }

  out:
  pxRadNodeSearch->oNodeFlag   &= ~RAD_ACTIVE;
  pxRadNodeSearch[1].oNodeFlag &= ~RAD_ACTIVE;
  if(pxRadNodeSearch->xRadixNodeLink.le_next != 0)
    LIST_REMOVE(pxRadNodeSearch, xRadixNodeLink);
  return (pxRadNodeSearch);
}

static RADIXMASK*
RadixCreateMask(RADIXNODE *pxRadixNode, RADIXMASK *pxRadixMask)
{
  RADIXMASK *pxRadixMaskCreate = 0;

  if (OK != MOC_MALLOC((void**)&pxRadixMaskCreate, sizeof(RADIXMASK)))
  {
    /* printf("Mask for route not entered\n"); */
    return NULL;
  }
  MOC_MEMSET((ubyte*)pxRadixMaskCreate, 0x00, sizeof *pxRadixMaskCreate);
  pxRadixMaskCreate->wBitOffset = pxRadixNode->wBitOffset;
  pxRadixMaskCreate->oNodeFlag = pxRadixNode->oNodeFlag;
  if (pxRadixNode->oNodeFlag & RAD_NORMAL)
    pxRadixMaskCreate->RadixMaskLeaf = pxRadixNode;
  else
    pxRadixMaskCreate->RadixMaskMask = pxRadixNode->RadixNodeMask;
  pxRadixMaskCreate->pxMaskLst = pxRadixMask;
  pxRadixNode->pxMaskLst = pxRadixMaskCreate;
  return pxRadixMaskCreate;
}

static sbyte4
RadixLexOBetter(ubyte4 dwMask1, ubyte4 dwMask2)
{
  ubyte *poMask1 = (ubyte *)&dwMask1, *poMask2 = (ubyte *)&dwMask2, *poLim;
  for (poLim = poMask1 + MAX_LIM; poMask1 < poLim; )
    if(*poMask1++ > *poMask2++)
      return 1;
  return 0;
}

static RADIXNODE*
RadixAddMask(ubyte4 dwNetmask, sbyte4 dwSearch, sbyte4 dwSkip)
{
  ubyte *poNetmask = (ubyte *) &dwNetmask;
  ubyte4 dwLen;
  sbyte4 m0, dwMaskDuplicated;
  ubyte *cp;
  static sbyte4 dwLastZeroed = 0;
  RADIXNODE *pxRadNodeSearch = 0, *pxRadNodeSaved = 0;
  ubyte *cplim;
  ubyte2 j = 0, dwIsNormal = 0;
  ubyte4 b =0;
  sbyte4 dwResult = -1;

  dwLen = LEN(dwNetmask);
  MOC_MEMCPY(poAddMaskKey, poNetmask, sizeof(ubyte4));

  pxRadNodeSearch = RadixSearch(dwNetmask, pxRadNodeHeadMask->pxTreeTop);

  MOC_MEMCMP(poAddMaskKey, (ubyte*)&pxRadNodeSearch->RadixNodeKey, dwLen, &dwResult);
  if (0 != dwResult)
    pxRadNodeSearch = 0;
  if (pxRadNodeSearch || dwSearch)
    return (pxRadNodeSearch);
  if (OK != MOC_MALLOC((void**)&pxRadNodeSearch, 2 * sizeof(RADIXNODE)))
    return 0;

  pxRadNodeSaved = pxRadNodeSearch;
  pxRadNodeSearch = RadixInsertNode(dwNetmask, pxRadNodeHeadMask, &dwMaskDuplicated, pxRadNodeSearch);

  if (dwMaskDuplicated)
  {
    /*printf("RadixAddMask: mask impossibly already in tree");*/
    MOC_FREE((void**)&pxRadNodeSaved);
    return (pxRadNodeSearch);
  }

  /*
   * Calculate index of mask, and check for normalcy.
   * First find the first byte with a 0 bit, then if there are
   * more bits left, the pattern must be one of those in normal_chars[], or we have
   * a non-contiguous mask.
   */
  cplim = poNetmask + dwLen;
  dwIsNormal = 1;
  for (cp = poNetmask + dwSkip; (cp < cplim) && *(ubyte *)cp == 0xff;)
    cp++;
  if (cp != cplim)
  {
    static sbyte oNormalChars[] = {0, 0x80, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe, 0xff};
    for (j = 0x80; (j & *cp) != 0; j >>= 1)
      b++;
    if (*cp != oNormalChars[b] || cp != (cplim - 1))
      dwIsNormal = 0;
  }
  b += (cp - poNetmask) << 3;
  pxRadNodeSearch->wBitOffset = -1 - b;
  if (dwIsNormal)
    pxRadNodeSearch->oNodeFlag |= RAD_NORMAL;
  return (pxRadNodeSearch);
}

static RADIXNODE*
RadixSearch(ubyte4 dwNetmask, RADIXNODE *pxHead)
{
  RADIXNODE *pxRadIter;
  ubyte *podwNetmask = 0;

  for (pxRadIter = pxHead, podwNetmask = (ubyte *) &dwNetmask; pxRadIter->wBitOffset >= 0;)
  {
    if (pxRadIter->oBMask & podwNetmask[pxRadIter->RadixNodeOffset])
      pxRadIter = pxRadIter->RadixNodeRight;
    else
      pxRadIter = pxRadIter->RadixNodeLeft;
  }
  return (pxRadIter);
}

static RADIXNODE*
RadixSearchWithAdditionalMask(ubyte4 dwIpAddr, ubyte4 dwNetmask,
                              RADIXNODE *pxHead)
{
  RADIXNODE *pxRadIter;
  ubyte *poIpAddr = (ubyte *)&dwIpAddr, *poNetmask = (ubyte *)&dwNetmask;
  for (pxRadIter = pxHead; pxRadIter->wBitOffset >= 0;)
  {
    if((pxRadIter->oBMask & poNetmask[pxRadIter->RadixNodeOffset]) &&
       (pxRadIter->oBMask & poIpAddr[pxRadIter->RadixNodeOffset]))
         pxRadIter = pxRadIter->RadixNodeRight;
    else
      pxRadIter = pxRadIter->RadixNodeLeft;
  }
  return pxRadIter;
}

static sbyte4
RadixRefines(ubyte4 dwNetmask, ubyte4 dwRadNodeNetmask)
{
  ubyte *pom = (ubyte *)&dwNetmask, *pon = (ubyte *)&dwRadNodeNetmask;
  ubyte *lim = pon + MAX_LIM;
  sbyte4 dwMasks_are_equal = 1;

  while (pon < lim)
  {
    if (*pon & ~(*pom))
      return 0;
    if (*pon++ != *pom++)
      dwMasks_are_equal = 0;
  }
  return (!dwMasks_are_equal);
}

RADIXNODE*
RadixLookUp(ubyte4 dwIpAddr,
            ubyte4 dwNetmask,
            RADIXNODEHEAD *pxHead)
{
  RADIXNODE *pxRadNode;
  ubyte4 dwNetmask_t = 0;
  /*AAAGH ...convert ip addr/ netmask to n/w order */
  dwIpAddr = htonl(dwIpAddr);
  dwNetmask = htonl(dwNetmask);

  if (dwNetmask)
  {
    pxRadNode = RadixAddMask(dwNetmask, 1, pxHead->pxTreeTop->RadixNodeOffset);
    if (pxRadNode == 0)
      return (0);
    dwNetmask_t = pxRadNode->RadixNodeKey;
  }
  pxRadNode = RadixMatch(dwIpAddr, pxHead);
  if (pxRadNode && dwNetmask_t)
  {
    while (pxRadNode && pxRadNode->RadixNodeMask != dwNetmask_t)
      pxRadNode = pxRadNode->RadixNodeDupedKey;
  }
  return pxRadNode;
}

static ubyte4
RadixSatisfiesLeaf(ubyte4 dwIpAddr, RADIXNODE *pxRadNodeLeaf, sbyte4 dwSkip)
{
  ubyte *poIpAddr = (ubyte *) &dwIpAddr;
  ubyte *poNodeKey = (ubyte *) &(pxRadNodeLeaf->RadixNodeKey);
  ubyte *poRadNodeMask = (ubyte *) &(pxRadNodeLeaf->RadixNodeMask);
  ubyte *cplim;
  sbyte dwLength = 0;

  if ( poRadNodeMask == 0)
    poRadNodeMask = poOnes;
  dwLength = LEN(dwIpAddr);
  cplim = poIpAddr + dwLength;
  for (; poIpAddr < cplim; poIpAddr++, poNodeKey++, poRadNodeMask++)
    if ((*poIpAddr ^ *poNodeKey) & *poRadNodeMask)
      return 0;
  return 1;
}


static RADIXNODE*
RadixMatch(ubyte4 dwIpAddr, RADIXNODEHEAD *pxRadNodeHead)
{
  RADIXNODE *pxRadNodeTreeTop = pxRadNodeHead->pxTreeTop;
  RADIXNODE *pxRadNodeSearch = NULL;
  ubyte *poBaseIpAddr = NULL;
  ubyte *cp = poBaseIpAddr = (ubyte *) &dwIpAddr, *cp2 = NULL;

  RADIXNODE *pxRadNodeTmp, *pxRadNodeTop = pxRadNodeTreeTop;

  sbyte4 dwOffset = pxRadNodeTreeTop->RadixNodeOffset;
  sbyte4 dwVlen = LEN(dwIpAddr);
  sbyte4 dwMatchedOff;
  ubyte *pocpLim;

  sbyte4 dwBitDiff, b;
  sbyte2 wBitOffset;

  for (; pxRadNodeTreeTop->wBitOffset >= 0; )
  {
    if (pxRadNodeTreeTop->oBMask & cp[pxRadNodeTreeTop->RadixNodeOffset])
      pxRadNodeTreeTop = pxRadNodeTreeTop->RadixNodeRight;
    else
      pxRadNodeTreeTop = pxRadNodeTreeTop->RadixNodeLeft;
  }
  /*
   * See if we match exactly as a host destination
   * or at least learn how many bits match, for normal mask finesse.
   *
   * It doesn't hurt us to limit how many bytes to check
   * to the length of the mask, since if it matches we had a genuine
   * match and the leaf we have is the most specific one anyway;
   * if it didn't match with a shorter length it would fail
   * with a long one.  This wins big for class B&C netmasks which
   * are probably the most common case...
   */
  if (pxRadNodeTreeTop->RadixNodeMask)
    dwVlen = LEN(pxRadNodeTreeTop->RadixNodeMask);

  cp += dwOffset; cp2 = (ubyte *)&pxRadNodeTreeTop->RadixNodeKey; cp2 += dwOffset;
  pocpLim = (ubyte *)&dwIpAddr; pocpLim += dwVlen;

  for (; cp < pocpLim; cp++, cp2++)
    if (*cp != *cp2)
      goto on1;
  /*
   * Never return the root node itself
   */
  if (pxRadNodeTreeTop->oNodeFlag & RAD_ROOT)
    pxRadNodeTreeTop = pxRadNodeTreeTop->RadixNodeDupedKey;
  return pxRadNodeTreeTop;

  on1:
    dwBitDiff = (*cp ^ *cp2) & 0xff; /* find first bit that differs */
    for (b = 7; (dwBitDiff >>= 1) > 0;)
      b--;
    dwMatchedOff = cp - poBaseIpAddr;
    b += dwMatchedOff << 3;
    wBitOffset = -1 - b;
  /*
   * If there is a host route in a duped-key chain, it will be first.
   */
  if ((pxRadNodeTmp = pxRadNodeTreeTop)->RadixNodeMask == 0)
    pxRadNodeTreeTop = pxRadNodeTreeTop->RadixNodeDupedKey;
  for (; pxRadNodeTreeTop; pxRadNodeTreeTop = pxRadNodeTreeTop->RadixNodeDupedKey)
  {
    /*
     * Even if we don't match exactly as a host,
     * we may match if the leaf we wound up at is
     * a route to a net.
     */
    if (pxRadNodeTreeTop->oNodeFlag & RAD_NORMAL)
    {
      if (wBitOffset <= pxRadNodeTreeTop->wBitOffset)
        return pxRadNodeTreeTop;
    }
    else if (RadixSatisfiesLeaf(dwIpAddr, pxRadNodeTreeTop, dwMatchedOff))
      return pxRadNodeTreeTop;
  }
  pxRadNodeTreeTop = pxRadNodeTmp;
  /* start searching up the tree */
  do
  {
    RADIXMASK *pxRadixMask;
    pxRadNodeTreeTop = pxRadNodeTreeTop->pxParent;
    pxRadixMask = pxRadNodeTreeTop->pxMaskLst;
    /*
     * If non-contiguous masks ever become important
     * we can restore the masking and open coding of
     * the search and satisfaction test and put the
     * calculation of "off" back before the "do".
     */
    while (pxRadixMask)
    {
      if (pxRadixMask->oNodeFlag & RAD_NORMAL)
      {
        if (wBitOffset <= pxRadixMask->wBitOffset)
          return (pxRadixMask->RadixMaskLeaf);
      }
      else
      {
        dwOffset = min(pxRadNodeTreeTop->RadixNodeOffset, dwMatchedOff);
        pxRadNodeSearch = RadixSearchWithAdditionalMask(dwIpAddr, pxRadixMask->RadixMaskMask, pxRadNodeTreeTop);
        while (pxRadNodeSearch && pxRadNodeSearch->RadixNodeMask != pxRadixMask->RadixMaskMask)
          pxRadNodeSearch = pxRadNodeSearch->RadixNodeDupedKey;
        if (pxRadNodeSearch && RadixSatisfiesLeaf(dwIpAddr, pxRadNodeSearch, dwOffset))
        {
          if((pxRadNodeSearch->oNodeFlag & RAD_ROOT)) /*to take care of the default route*/
            pxRadNodeSearch = (pxRadNodeSearch->RadixNodeDupedKey ? pxRadNodeSearch->RadixNodeDupedKey : pxRadNodeSearch);
          return pxRadNodeSearch;
        }
      }
      pxRadixMask = pxRadixMask->pxMaskLst;
    }
  } while (pxRadNodeTreeTop != pxRadNodeTop);
  return NULL;
}

static RADIXNODE*
RadixInsertNode(ubyte4 dwIpAddr, RADIXNODEHEAD *pxHead, sbyte4 *pdwDupEntry, RADIXNODE xNodes[2])
{
  RADIXNODE *pxRadNodeTreeTop = pxHead->pxTreeTop;
  RADIXNODE *pxRadNodeSearch = RadixSearch(dwIpAddr, pxRadNodeTreeTop);
  RADIXNODE *pxRadNodeInsert = NULL;
  sbyte4 dwHeadOffset = pxRadNodeTreeTop->RadixNodeOffset;
  sbyte2 wLoop;
  ubyte *poIpAddr = 0;
  ubyte *poIpAddrOrig = poIpAddr = (ubyte *) &dwIpAddr;

  {
    ubyte *poRadNodeKey = (ubyte *) &pxRadNodeSearch->RadixNodeKey;
    ubyte *poIpAddrLim = poIpAddr + MAX_LIM;
    sbyte4 dwCmpRes;

    while (poIpAddr < poIpAddrLim)
      if (*poRadNodeKey++ != *poIpAddr++)
        goto on1;
    *pdwDupEntry = 1;
    return pxRadNodeSearch;

    on1:
    *pdwDupEntry = 0;
    dwCmpRes = (poIpAddr[-1] ^ poRadNodeKey[-1]) & 0xff;
    for (wLoop = (poIpAddr - poIpAddrOrig) << 3; dwCmpRes; wLoop--)
      dwCmpRes >>= 1;
  }
  {
    RADIXNODE *pxRadNodeIter1, *pxRadNodeIter2 = pxRadNodeTreeTop;
    poIpAddr = poIpAddrOrig;
    do
    {
      pxRadNodeIter1 = pxRadNodeIter2;
      if (poIpAddr[pxRadNodeIter2->RadixNodeOffset] & pxRadNodeIter2->oBMask)
        pxRadNodeIter2 = pxRadNodeIter2->RadixNodeRight;
      else
        pxRadNodeIter2 = pxRadNodeIter2->RadixNodeLeft;
    } while ((pxRadNodeIter2) && ( wLoop > pxRadNodeIter2->wBitOffset) && (pxRadNodeIter2->wBitOffset >= 0));

    pxRadNodeSearch = RadixNewPair(dwIpAddr, wLoop, xNodes);
    /*
     * Exactly where to insert the "new" pair within the tree.
     */
    pxRadNodeInsert = pxRadNodeSearch->RadixNodeLeft;
    if ((poIpAddr[pxRadNodeIter1->RadixNodeOffset] & pxRadNodeIter1->oBMask) == 0)
      pxRadNodeIter1->RadixNodeLeft = pxRadNodeSearch;
    else
      pxRadNodeIter1->RadixNodeRight = pxRadNodeSearch;
    if(pxRadNodeIter2) pxRadNodeIter2->pxParent = pxRadNodeSearch;
    pxRadNodeSearch->pxParent = pxRadNodeIter1; /* frees pxRadNodeIter1, pxRadNodeIter2 as temp vars below */
    if ((poIpAddr[pxRadNodeSearch->RadixNodeOffset] & pxRadNodeSearch->oBMask) == 0)
    {
      pxRadNodeSearch->RadixNodeRight = pxRadNodeIter2;
    }
    else
    {
      pxRadNodeSearch->RadixNodeRight = pxRadNodeInsert;
      pxRadNodeSearch->RadixNodeLeft = pxRadNodeIter2;
    }
  }
  return (pxRadNodeInsert);
}

static RADIXNODE*
RadixNewPair(ubyte4 dwNodeKey,sbyte2 wOffset, RADIXNODE xNodes[2])
{
  RADIXNODE *pxRadixNodeBase = xNodes, *pxRadixNodeNxt = pxRadixNodeBase + 1;

  pxRadixNodeNxt->wBitOffset      = wOffset;
  pxRadixNodeNxt->oBMask          = 0x80 >> (wOffset & 7);
  pxRadixNodeNxt->RadixNodeLeft   = pxRadixNodeBase;
  pxRadixNodeNxt->RadixNodeOffset = wOffset >> 3;
  pxRadixNodeNxt->pxParent        = pxRadixNodeNxt->RadixNodeRight = NULL;

  pxRadixNodeBase->RadixNodeMask       = NULL;
  pxRadixNodeBase->RadixNodeDupedKey   = NULL;
  pxRadixNodeBase->oBMask              = 0;
  pxRadixNodeBase->wBitOffset          = -1;
  pxRadixNodeBase->RadixNodeKey        = dwNodeKey;
  pxRadixNodeBase->pxParent            = pxRadixNodeNxt;
  pxRadixNodeBase->oNodeFlag           = pxRadixNodeNxt->oNodeFlag = RAD_ACTIVE;
  pxRadixNodeBase->pxMaskLst           = pxRadixNodeNxt->pxMaskLst = 0;

   return pxRadixNodeNxt;
}

sbyte2
printRadixTree(RADIXNODEHEAD *pxRadNodeHead)
{
  RADIXNODE *pxRadixNodeBase = 0;
  RADIXNODE *pxRadixNodeNext = 0;
  RADIXNODE *pxTreeTop = pxRadNodeHead->pxTreeTop;
  sbyte oPrintOnce = 1;
  while (pxTreeTop->wBitOffset >= 0)
  {
    printf("NODE : wBitOffset = %d, oBMask = 0x%2x, dwOffset = %d .... moving left <= \n",
           pxTreeTop->wBitOffset, pxTreeTop->oBMask, pxTreeTop->RadixNodeOffset);
    pxTreeTop = pxTreeTop->RadixNodeLeft;
  }
  for (;;)
  {
    pxRadixNodeBase = pxTreeTop;
    /* If at right child go back up, otherwise, go right */
    while (pxTreeTop->pxParent->RadixNodeRight == pxTreeTop
           && (pxTreeTop->oNodeFlag & RAD_ROOT) == 0)
    {
      pxTreeTop = pxTreeTop->pxParent;
      printf("back-tracking, checking the (RIGHT) NODE =>, moving up (PARENT) ^ node  wBitOffset = %d, oBMask = 0x%2x, dwOffset = %d \n",
              pxTreeTop->wBitOffset, pxTreeTop->oBMask, pxTreeTop->RadixNodeOffset);
    }
    /* Find the next *leaf* since next node might vanish, too */
    for (pxTreeTop = pxTreeTop->pxParent->RadixNodeRight; pxTreeTop->wBitOffset >= 0;)
    {
      if(oPrintOnce)
      {
        printf("RIGHT ");
        oPrintOnce = 0;
      }
      else
        printf("LEFT ");
      printf("NODE : wBitOffset = %d, oBMask = 0x%2x, dwOffset = %d having PARENT wBitOffset = %d, oBMask = 0x%2x, dwOffset = %d .... moving left <= \n",
             pxTreeTop->wBitOffset, pxTreeTop->oBMask, pxTreeTop->RadixNodeOffset,
             pxTreeTop->pxParent->wBitOffset, pxTreeTop->pxParent->oBMask, pxTreeTop->pxParent->RadixNodeOffset);
      pxTreeTop = pxTreeTop->RadixNodeLeft;
    }
    oPrintOnce = 1;
    pxRadixNodeNext = pxTreeTop;
    /* Process leaves */
    while ((pxTreeTop = pxRadixNodeBase))
    {
      pxRadixNodeBase = pxTreeTop->RadixNodeDupedKey;
      printf("LEAF: wBitOffset = %d, key = 0x%x, mask = 0x%x ",
              pxTreeTop->wBitOffset, pxTreeTop->RadixNodeKey, pxTreeTop->RadixNodeMask);
      if(pxTreeTop->pxParent->wBitOffset >= 0)
      {
        printf (" having PARENT: wBitOffset = %d, oBMask = 0x%2x, dwOffset = %d \n",
                pxTreeTop->pxParent->wBitOffset, pxTreeTop->pxParent->oBMask, pxTreeTop->pxParent->RadixNodeOffset);
      }
      else
        printf("\n");

      if(pxRadixNodeBase)
        printf ("Entries correspond to the Duped Key within key = 0x%x \n", pxTreeTop->RadixNodeKey);
    }
    pxTreeTop = pxRadixNodeNext;
    if (pxTreeTop->oNodeFlag & RAD_ROOT)
      return (0);
  }
}

void printRadixElement(RADIXNODE *pxRadixNode)
{
  if(pxRadixNode == 0)
  {
    printf("input parameter not ok . \n");
    return;
  }
  printf("requested radixElement is : ");
  if(pxRadixNode->wBitOffset >= 0)
  {
    printf("node \n\t dwOffset = %d \n\t wBitOffset = %d \n\t oBMask = 0x%2x \n\t oNodeFlag = %d \n",
           pxRadixNode->RadixNodeOffset, pxRadixNode->wBitOffset, pxRadixNode->oBMask, pxRadixNode->oNodeFlag);
  }
  else
  {
    printf("leaf \n\t wBitOffset = %d \n\t oBMask = 0x%2x \n\t oNodeFlag = %d \n\t key = 0x%x \n\t mask = 0x%x \n",
           pxRadixNode->wBitOffset, pxRadixNode->oBMask, pxRadixNode->oNodeFlag,
           pxRadixNode->RadixNodeKey, pxRadixNode->RadixNodeMask);
  }
}

void FreeRadixTree(RADIXNODEHEAD *pxRadixNodeHead,
                   void (*RadixTreeFreeLeaf)(RADIXNODE **ppxRadixNodeLeaf))
{
  RADIXNODE *pxRadixNodeBase = 0;
  RADIXNODE *pxRadixNodeNext = 0;
  RADIXNODE *pxTreeTop = pxRadixNodeHead->pxTreeTop;

  /*Moving to the left most leaf*/
  while (pxTreeTop->wBitOffset >= 0)
    pxTreeTop = pxTreeTop->RadixNodeLeft;

  for (;;)
  {
    pxRadixNodeBase = pxTreeTop;

    /* If at right child go back up, otherwise, go right */
    while (pxTreeTop->pxParent->RadixNodeRight == pxTreeTop
           && (pxTreeTop->oNodeFlag & RAD_ROOT) == 0)
      pxTreeTop = pxTreeTop->pxParent;

    /* Find the next leaf */
    for (pxTreeTop = pxTreeTop->pxParent->RadixNodeRight; pxTreeTop->wBitOffset >= 0;)
      pxTreeTop = pxTreeTop->RadixNodeLeft;

    pxRadixNodeNext = pxTreeTop;

    /* Process leaves */
    while ((pxTreeTop = pxRadixNodeBase))
    {
      pxRadixNodeBase = pxTreeTop->RadixNodeDupedKey;
      if (!(pxTreeTop->oNodeFlag & RAD_ROOT))
      {
        RADIXMASK **ppxRadixMask = NULL, *pxRadixMask = NULL;
        RADIXNODE *pxTreeTopTmp = NULL;
        RADIXNODE *pxRadNodeParent = NULL;
        RADIXNODE *pxRadNodePredParent = NULL;
        for (ppxRadixMask = &pxTreeTop->pxMaskLst; (pxRadixMask = *ppxRadixMask);)
        {
          *ppxRadixMask = pxRadixMask->pxMaskLst;
          if(--pxRadixMask->dwReferences <= 0)
          {
            MOC_FREE((void**)&pxRadixMask);
            pxRadixMask = NULL;
          }
        }
        /*we might need to have a check for the validity of node ( in case if it is not attached in the list )*/
        if(pxTreeTop->xRadixNodeLink.le_next != 0)
          LIST_REMOVE(pxTreeTop, xRadixNodeLink);

        /*Process of freeing up Leafs + Nodes from the tree*/
        pxRadNodeParent = pxTreeTop->pxParent;
        if(pxRadixNodeBase)
        {
          /* Case 1 : For duplicate key leafs*/
          pxTreeTopTmp = pxRadixNodeBase;
          pxTreeTopTmp->pxParent = pxRadNodeParent;

          if (pxRadNodeParent->RadixNodeLeft == pxTreeTop)
            pxRadNodeParent->RadixNodeLeft = pxTreeTopTmp;
          else
            pxRadNodeParent->RadixNodeRight = pxTreeTopTmp;

          pxRadNodeParent = pxTreeTop + 1;
          if(pxRadNodeParent->oNodeFlag & RAD_ACTIVE)
          {
            *++pxTreeTopTmp = *pxRadNodeParent;
            pxRadNodePredParent = pxRadNodeParent->pxParent;
            if (pxRadNodePredParent->RadixNodeLeft == pxRadNodeParent)
              pxRadNodePredParent->RadixNodeLeft = pxTreeTopTmp;
            else
              pxRadNodePredParent->RadixNodeRight = pxTreeTopTmp;
            pxTreeTopTmp->RadixNodeLeft->pxParent  = pxTreeTopTmp;
            pxTreeTopTmp->RadixNodeRight->pxParent = pxTreeTopTmp;
          }
        }
        else
        {
          if(pxRadNodeParent->oNodeFlag & RAD_ROOT)
            /*Case 2: For Leafs attached to ROOT nodes*/
            pxRadNodeParent->RadixNodeDupedKey = 0;
          else
          {
            /*Case 3: For all the Leafs, other than Case 2*/
            if (pxRadNodeParent->RadixNodeLeft == pxTreeTop)
              pxTreeTopTmp = pxRadNodeParent->RadixNodeRight;
            else
              pxTreeTopTmp = pxRadNodeParent->RadixNodeLeft;

            pxRadNodePredParent = pxRadNodeParent->pxParent;

            if (pxRadNodePredParent->RadixNodeRight == pxRadNodeParent)
              pxRadNodePredParent->RadixNodeRight = pxTreeTopTmp;
            else
              pxRadNodePredParent->RadixNodeLeft  = pxTreeTopTmp;

            pxTreeTopTmp->pxParent = pxRadNodePredParent;

            pxTreeTopTmp = pxTreeTop + 1;
            if (pxRadNodeParent != pxTreeTopTmp)
            {
              *pxRadNodeParent = *pxTreeTopTmp;
              pxRadNodeParent->RadixNodeLeft->pxParent  = pxRadNodeParent;
              pxRadNodeParent->RadixNodeRight->pxParent = pxRadNodeParent;
              pxRadNodePredParent = pxTreeTopTmp->pxParent;
              if (pxRadNodePredParent->RadixNodeLeft == pxTreeTopTmp)
                pxRadNodePredParent->RadixNodeLeft = pxRadNodeParent;
              else
                pxRadNodePredParent->RadixNodeRight = pxRadNodeParent;
            }
          }
        }

        MOC_MEMSET((ubyte*)(pxTreeTop + 1), 0x00, sizeof(RADIXNODE));
        RadixTreeFreeLeaf(&pxTreeTop);
      }
    }
    pxTreeTop = pxRadixNodeNext;
    if (pxTreeTop->oNodeFlag & RAD_ROOT)
      break ;
  }
  return;
}
