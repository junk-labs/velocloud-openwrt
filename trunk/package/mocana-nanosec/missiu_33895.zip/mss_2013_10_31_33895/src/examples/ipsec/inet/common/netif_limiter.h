/*
 * netif_limiter.h
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _NETIF_LIMITER_H_
#define _NETIF_LIMITER_H_

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "netmain.h"
#include "netdefs.h"
#include "netutils.h"

/****************************************************************************
 *
 * define
 *
 ****************************************************************************/

#define PACKET_RX_MIN 5
#define PACKET_RX_MAX 50

/****************************************************************************
 *
 * API function
 *
 ****************************************************************************/
LONG NetIfLimiterInitialize(NETIFLIMITER *pxNetIfLimiter);
LONG NetIfLimiterTerminate(NETIFLIMITER *pxNetIfLimiter);
LONG NetIfLimiterProcess(NETIFLIMITER *pxNetIfLimiter);

LONG NetIfLimiter(NETIFLIMITER *pxNetIfLimiter,DLLIST *pdllNetPacket);
E_PRIORITY NetPacketDefaultSortingMethod(NETPACKET *pxNetPacket);


#endif /*#ifndef _NETIF_LIMITER_H_*/
