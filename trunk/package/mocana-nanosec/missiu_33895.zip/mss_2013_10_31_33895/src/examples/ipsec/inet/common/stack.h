/*
 * stack.h
 *
 * Implements Stacks in MACROs. The Stack operations are:
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _STACK_H
#define _STACK_H

**
**    STACK(t) stk;                  declare stk as a stack of type t
**    ClearStack(stk);             initialize stack to empty
**    Push(stk, pElement);         push an element
**    pElement = PeekStackTop(stk);  peek at top stack element
**    DiscardStackTop(stk);         remove top element
**    Pop(stk, *pElement);         get (& remove from stack) top
**
**  (pElement == NO_ENTRY) after PeekStackTop() or Pop()
**  implies the queue was empty.
**
**  See comments before each MACRO definition for a more complete
**  description of each one.
**
**  In order for a typed structure to be eligible for use in
**  a stack, it MUST include the pointer pNext defined as
**  a pointer to the structure it belongs to.
**
**
**  Example:
**
**    typedef struct FOO {
**      struct FOO *pNext;
**      DWORD dwFoo;
**    } FOO;
**
**    FOO aFooArray[20];
**
**    STACK(FOO) stkFoo;
**    STACK(FOO) stkFooBar;
**
**    void FooBar(void)
**    {
**      int i;
**      FOO *pThisFoo;
**
**      ClearStack(stkFoo);
**      ClearStack(stkFooBar);
**      for (i = 0; i < 20; i++) {
**        aFooArray[i].dwFoo = i;
**        Push(qFoo, &(aFooArray[i]));
**      }
**
**      while (1) {
**        pThisFoo = Pop(stkFoo);
**        if (pThisFoo == NO_ENTRY)
**          break;
**        pThisFoo->dwFoo += 100;
**        Push(stkFooBar, pThisFoo);
**      }
**    }
**

#include "NNstyle.h"

#ifndef NO_ENTRY
#  define NO_ENTRY ((void *) 0)
#endif

/*---------------------------------------------------------------------------
 *  TYPEDEFS
 */
#define STACK(t) t *


/*---------------------------------------------------------------------------
 *  MACROs
 */

/*
 * Clear a stack, any contents of the stack are lost!
 *
 * parms:    stk    a structure of type STACK
 */
#define ClearStack(stk) ((stk) = NO_ENTRY)


/*
 * Add an element onto the stack
 *
 * parms:    stk    a structure of type STACK
 *        pe    pointer to element to add
 */
#define Push(stk, pe) do {            \
            (pe)->pNext = (stk);    \
            (stk) = (pe);        \
              } while (0)



/*
 * peek at the top of the stack
 *
 * parms:    stk    a structure of type STACK
 *
 */
#define PeekStackTop(stk) (stk)


/*
 * discard the top element of the stack, the element is
 * LOST unless a PeekStackTop() is done first to get it.
 *
 * parms:    stk    a structure of type STACK
 *
 */
#define DiscardStackTop(stk)            \
           do {                \
             if ((stk) != NO_ENTRY)     \
               (stk) = (stk)->pNext;    \
           } while (0)


/*
 * remove and return the top element of the stack
 *
 * parms:    stk    a structure of type STACK
 *        ppe    pointer to pointer to element
 *
 */
#define Pop(stk, ppe)                 \
           do {                \
             *(ppe) = (stk);        \
             if ((stk) != NO_ENTRY)     \
               (stk) = (stk)->pNext;    \
           } while (0)


#endif
