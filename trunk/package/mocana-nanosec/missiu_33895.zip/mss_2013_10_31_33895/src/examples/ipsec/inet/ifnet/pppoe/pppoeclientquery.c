/*
 * pppoeclientquery.c
 *
 * PPPoE Client Query function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "stdlib.h"
#include "pthread.h"
#include "netcommon.h"
#include "ethernet.h"
#include "pppoecommon.h"
#include "pppoeparser.h"
#include "pppoeclient.h"
#include "pppoeclientdefs.h"
#include "pppoeclientdbg.h"

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * PppoEClientInstanceQuery
 *  Query an option value
 *
 *  Args:
 *   hInst                   instance handle
 *   oOption                 option code
 *   phDdata                  option value
 *
 *  Return:
 *   >=0 if success
 */
LONG PppoEClientInstanceQuery(H_NETINSTANCE hInst,OCTET oOption,
                              H_NETDATA *phData)
{
  PPPOECLIENTSTATE *pxState = (PPPOECLIENTSTATE *)hInst;

  PPPOECLIENT_CHECKSTATE(pxState);

  switch(oOption) {
  case PPPOEOPTION_RETRANSMISSIONCOUNTER:
    *((DWORD *)phData) = pxState->dwRetranmissionCounterBase;

    break;

    /* !!! SB. March-2002. Add the rest when they become needed !!! */

  default:
  }

  return NETERR_NOERR;
}

