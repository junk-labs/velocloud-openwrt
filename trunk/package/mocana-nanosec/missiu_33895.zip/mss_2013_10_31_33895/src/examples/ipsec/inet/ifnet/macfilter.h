/*
 * macfilter.h
 *
 * Definitions for the mac filter module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef macfilter_h
#define macfilter_h

/***************************************************************************/
/*                             D E F I N E S                               */
/***************************************************************************/

#define MAC_FILTER_HASH_SIZE         32   /* size of MAC hash table (must be power of 2) */
#define MAC_FILTER_MAX_ENTRIES       128  /* Total no. of MAC entries allowed */
#define MAC_FILTER_TIMEOUT_DEFAULT  300000 /* five minutes */
#define MAC_FILTER_PROCESS_TIME     1000   /* one second */

/***************************************************************************/
/*                  D A T A    S T R U C T U R E S                         */
/***************************************************************************/

/* This structure defines the MAC mapping cache. */
typedef struct mac_filter_entry {
  struct mac_filter_entry *next; /* must be first */
  DWORD    dwLastUsed;       /* optimisation - change to relative time WORD */
  OCTET    oMacAddr[ETHADDRESS_LEN];
  OCTET oIfIdx;
} MACFILTERENTRY;

/***************************************************************************/
/*                     E X T E R N   V A R I A B L E S                     */
/***************************************************************************/

MOC_EXTERN DWORD dwRefreshMacTicks;

/***************************************************************************/
/*           F U N C T I O N    P R O T O T Y P E S                        */
/***************************************************************************/

LONG MacFilterCreate(void);
void MacFilterDestroy(void);

MACFILTERENTRY * MacFilterLookup(OCTET *poMacAddr);
void MacFilterRefresh(DWORD dwTimeout);
void MacFilterAdd(OCTET *poMacAddr, OCTET oBridgePort);

#ifdef BRIDGEDBG_HI
void dbgPrintMacFilterHash(void);
void dbgPrintMacFilterEntries(void);
MOC_EXTERN OCTET oDbgPrintMacTable;
#endif

#endif
