/*
 * routing_table_cli.h
 *
 * Implements the CLI callbacks for Routing Table.
 *
 * Copyright Mocana Corp 2007. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ROUTE_TABLE_CLI_H_
#define _ROUTE_TABLE_CLI_H_
/*
 * RouteCliShow
 * Displays all the routes present within the Routing table. Invoked when the user
 * fires in "show route all" command.
 * Input Parameters:
 * ubyte * : command specified, "show" in this case
 * ubyte * : out parameter, the result is stored as a string
 * ubyte4 * : out parameter, the length of the buffer.
 * NOTE : the CLI module passes in the pointer "allocated" with a memory. This task should be
 * handled by the respective modules. There is no way that the individual module knows about
 * how many memory bytes that could be written.
 * Return values:
 * 0 indicates success
 */
ubyte4 RouteCliShow(ubyte *cmdRx, ubyte *sbuf, ubyte4 *sbuflen);

/*
 * RouteCliConfig
 * Configuring the route table, i.e: allows the CLI module to add and delete routing entries from
 * the route table.
 * command :
 * config route add ip <ip_addr> mask <mask_addr> gw <gateway_addr> if <interface_index>
 * config route del ip <ip_addr>
 * ip OR mask has to be present within the command, <ip_addr> & <gateway_addr> cannot be 0
 * Input parameters :
 * ubyte * : command line parameters initiated from the CLI module.
 * Return values:
 * 0 : indicates success.
 */
ubyte4 RouteCliConfig(ubyte *cmdRx);
#endif
