/*
 * ealtlsclient.h
 *
 * EAPTLS (Challenge Handshake Authentification Protocol) client API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _EAPTLSCLIENT_H_
#define _EAPTLSCLIENT_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * EAPTLS options
 */
#define EAPTLSCLIENTOPTIONENCRYPTIONID_MD5   5

#define EAPTLSCLIENTOPTION_ENCRYPTION \
 (NETOPTION_MODULESPECIFICBEGIN)    /* Encryption algorithm supported.
                                       Each calls add a new one. data
                                       is EAPTLSCLIENTENCRYPTIONSTATE * */
#define EAPTLSCLIENTOPTION_NAME \
 (NETOPTION_MODULESPECIFICBEGIN + 1) /* User name. data is EAPTLSCLIENTCONF *.
                                        Must be a null terminated string.
                                        length must include the `0`*/
#define EAPTLSCLIENTOPTION_SECRET \
 (NETOPTION_MODULESPECIFICBEGIN + 2) /* Secret. data is EAPTLSCLIENTCONF *.
                                        Must be a null terminated string.
                                        length must include the `0`*/
#define EAPTLSCLIENTOPTIONMAX 3

/*
 * EAPTLSCLIENT specific message
 */
#define EAPTLSCLIENTMSG_CONFREQ \
 (NETMSG_MODULESPECIFICBEGIN)      /* Config Request. data is EAPTLSCLIENTCONF * */

#define EAPTLSCLIENTMSGMAX 1

/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/
typedef struct {
  OCTET oId;
  PFN_CRYPT_INIT pfnCryptInit;
  PFN_CRYPT_UPDATE pfnCryptUpdate;
  PFN_CRYPT_FINISH pfnCryptFinish;
} EAPTLSCLIENTENCRYPTIONSTATE;

typedef struct {
  OCTET *poConf;
  WORD wConfLength;
} EAPTLSCLIENTCONF;

/*****************************************************************************
 *
 * Function Prototypes
 *
 *****************************************************************************/

/*
 * EapTlsClientInitialize
 *  Initialize the EAPTLS library
 *
 *  Args:
 *
 *  Return:
 *    >=0
 */
LONG EapTlsClientInitialize(void);

/*
 * EapTlsClientTerminate
 *  Terminate the EapTlsClient library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG EapTlsClientTerminate(void);

/*
 * EapTlsClientInstanceCreate
 *  Create a EAPTLS instance
 *
 *  Args:
 *
 *  Return:
 *   instance handle
 */
H_NETINSTANCE EapTlsClientInstanceCreate(void);

/*
 * EapTlsClientInstanceDestroy
 *  Destroy a ealtls instance
 *
 *  Args:
 *   hEapTlsClient              EapTlsClient instance handle
 *
 *  Return:
 *   >=0
 */
LONG EapTlsClientInstanceDestroy(H_NETINSTANCE hEapTlsClient);


/*
 * EapTlsClientInstanceSet
 *   Set EAPTLS options
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceSet(H_NETINSTANCE hEapTlsClient,OCTET oOption,
                      H_NETDATA hData);

/*
 * EapTlsClientInstanceQuery
 *   Query EAPTLS options
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     oOptio          Option code
 *     phData          data handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceQuery(H_NETINSTANCE hEapTlsClient,OCTET oOption,H_NETDATA * phData);

/*
 * EapTlsClientInstanceMsg
 *   EAPTLS msg function
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceMsg(H_NETINSTANCE hEapTlsClient,OCTET oMsg,H_NETDATA hData);

/*
 * EapTlsClientInstanceLLInterfaceCreate
 *   Create EAPTLS LL interface
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE EapTlsClientInstanceLLInterfaceCreate(H_NETINSTANCE hEapTlsClient);

/*
 * EapTlsClientInstanceLLInterfaceDestroy
 *   Destroy EAPTLS LL interface
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceLLInterfaceDestroy(H_NETINSTANCE hEapTlsClient, H_NETINTERFACE hIf);

/*
 * EapTlsClientInstanceLLInterfaceIoctl
 *   EAPTLS LL interface ioctl function
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceLLInterfaceIoctl(H_NETINSTANCE hEapTlsClient, H_NETINTERFACE hIf,
                                    OCTET oIoctl,H_NETDATA hData);

/*
 * EapTlsClientInstanceRcv
 *   EAPTLS instance rcv
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            NETIFID *
 *
 *   Return:
 *     >=0
 */
LONG EapTlsClientInstanceRcv(H_NETINSTANCE hEapTlsClient, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData);

/*
 * EapTlsClientInstanceProcess
 *   EAPTLS processing function
 *
 *   Args:
 *     hEapTlsClient           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG EapTlsClientInstanceProcess(H_NETINSTANCE hEapTlsClient);


#endif /* #ifndef _EAPTLSCLIENT_H_ */
