/*
 * nat.c
 *
 * Implements NAT
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/

#include "nat.h"
#include "nat_defs.h"
#include "alg_ftp.h"
#include "alg_rtsp_audio.h"

/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * Natnitialize
 *  Initialize the NAT library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG NatInitialize(void)
{
  /* Initialise DEBUG to ERROR */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_ERROR);
  return NETERR_NOERR;
}



/*
 * NatTerminate
 *  Terminate the NAT library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG NatTerminate(void)
{
  return NETERR_NOERR;
}



/*
 * NatInstanceCreate
 *  Creates a NAT Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE NatInstanceCreate(void)
{
  NATSTATE *pxNat;

  /*
   * Allocate memory for the the NAT state
   */
  pxNat = (NATSTATE *)MALLOC(sizeof(NATSTATE));
  if(pxNat == NULL){
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
    return (H_NETINSTANCE)NULL;
  }
  MOC_MEMSET((ubyte *)pxNat, 0, sizeof(NATSTATE));

  /*
   * set the magic cookie
   */
  NAT_SET_COOKIE(pxNat);


  /*
   * Register ALGs
   */
  NatRegisterAlg(pxNat, 21, AlgFtp);
  NatRegisterAlg(pxNat, RTSP_AUDIO_PORT, AlgRTSPAudio);


  /*
   * Register random port bindings.
   */
  NatRegisterRandomPortBinding(pxNat, 69, 69, NAT_PORT_FORWARD_PROT_BOTH);     /* TFTP */


  pxNat->oNumAllowedChunks = NAT_CHUNK_MAX_NUM;
  pxNat->wNumBindingsMax = NAT_CHUNK_MAX_NUM * NAT_CHUNK_NUM_BINDINGS;

  return (H_NETINSTANCE)pxNat;
}



/*
 * NatInstanceDestroy
 *  Destroy a NAT Instance
 *
 *  Args:
 *   hNat                       NAT instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG NatInstanceDestroy(H_NETINSTANCE hNat)
{
  DWORD dwIdx;
  NATSTATE *pxNat = (NATSTATE *)hNat;

  NAT_CHECK_STATE(pxNat);
  NAT_UNSET_COOKIE(pxNat);

  /*
   * Clear the binding table.
   */
  NatClearBindingTable(pxNat);

  /*
   * Delete all the NAT chunks.
   */
  for (dwIdx = 0; dwIdx < NAT_CHUNK_MAX_NUM_LOCAL; dwIdx++) {
    if (pxNat->apxNatChunksLocal[dwIdx] != NULL) {
      NatDeleteChunk(pxNat, pxNat->apxNatChunksLocal[dwIdx]);
      pxNat->apxNatChunksLocal[dwIdx] = NULL;
    }
  }

  for (dwIdx = 0; dwIdx < NAT_CHUNK_MAX_NUM; dwIdx++) {
    if (pxNat->apxNatChunks[dwIdx] != NULL) {
      NatDeleteChunk(pxNat, pxNat->apxNatChunks[dwIdx]);
      pxNat->apxNatChunks[dwIdx] = NULL;
    }
  }

  /*
   * Unregister ALGs
   */
  NatUnregisterAlg(pxNat, 21);
  NatUnregisterAlg(pxNat, RTSP_AUDIO_PORT);

  /*
   * Unregister random port bindings.
   */
  NatUnregisterRandomPortBinding(pxNat, 69, 69);       /* TFTP */

  FREE(pxNat);

  return 0;
}


/*
 * NatInstanceMsg
 *  Send a msg to a NAT instance
 *
 *  Args:
 *   hNat                    NAT instance
 *   oMsg                    Msg. See netcommon.h and ipfrag.h for definition
 *   hData                   Option data. None is defined at this stage
 *
 *  Return:
 *   NETERR_NOERR: success
 *   <-1 error
 */
LONG NatInstanceMsg(H_NETINSTANCE hNat,
                    OCTET oMsg,
                    H_NETDATA hData)
{
  NATSTATE *pxNat = (NATSTATE *)hNat;

  LONG lReturn = NETERR_NOERR;

  NAT_CHECK_STATE(pxNat);
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
  {
    /*NAT_DBGP(DBGLVL_REPETITIVE, "NatInstanceMsg: oMsg: %x\n", oMsg);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NatInstanceMsg: oMsg: ", oMsg);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oMsg) {
  case NETMSG_OPEN:
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
    {
      /*NAT_DBGP(DBGLVL_REPETITIVE, "Nothing to do in Nat for msg: %x\n", oMsg);*/
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "Nothing to do in Nat for msg: ", oMsg);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
    break;
  case NATMSG_SETIFIDXLAN:
    pxNat->oIfIdxLan = (OCTET) hData;
    break;
  case NATMSG_DOWNIFIDX:
    NatClearIfBindings(pxNat, (OCTET) hData);
    break;
  case NATMSG_REGPORTFWDWANTOCPE:
    NatRegisterPortForwardWanToCpe(pxNat, (NATCFG_PORTS2CPE*) hData);
    break;
  case NATMSG_UNREGPORTFWDWANTOCPE:
    NatUnregisterPortForwardWanToCpe(pxNat, (NATCFG_PORTS2CPE*) hData);
    break;
  case NATMSG_CFGPORTFWDLAN:
    lReturn = NatConfigPortForwardToLan(pxNat, (NATCFG_PORTFWDLAN*) hData);
    break;
  case NATMSG_GETPORTFWDWANTOCPELIST:
    NatGetPortForwardWanToCpeList(pxNat, (NATCFG_PORTS2CPE*) hData);
    break;
  case NATMSG_REGPORTBLKLANTOCPE:
    NatRegisterPortBlockLanToCpe(pxNat, (NATCFG_PORTS2CPE*) hData);
    break;
  case NATMSG_UNREGPORTBLKLANTOCPE:
    NatUnregisterPortBlockLanToCpe(pxNat, (NATCFG_PORTS2CPE*) hData);
    break;
  case NATMSG_SETBINDINGSLIMIT:
    {
      OCTET oMaxAllowedChunks = NAT_CHUNK_MAX_NUM -
                                (((DWORD) hData + sizeof(NAT_CHUNK) - 1) / sizeof(NAT_CHUNK));
      NatTrimChunks(pxNat, oMaxAllowedChunks);
      pxNat->wNumBindingsMax = oMaxAllowedChunks * NAT_CHUNK_NUM_BINDINGS;
    }
    break;
  case NATMSG_SETIFMTU:
    {
      NATSETIFMTU* pxNatSetIfMtu = (NATSETIFMTU*) hData;
      pxNat->awMtu[pxNatSetIfMtu->oIfIdx] = pxNatSetIfMtu->wMtu;
    }
    break;
  default:
    lReturn = NETERR_UNKNOWN;
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
  }
  return lReturn;
}

/*
 * NatInstanceULInterfaceCreate
 *
 *  Args:
 *   hNat                NAT instance
 *
 *  Return:
 *   H_NETINTERFACE      Interface handle
 */
H_NETINTERFACE NatInstanceULInterfaceCreate(H_NETINSTANCE hNat)
{
  NAT_CHECK_STATE((NATSTATE*) hNat);

  return (H_NETINTERFACE)1;
}

/*
 * NatInstanceULInterfaceDestroy
 *  Destroy a NAT UL interface
 *
 *  Args:
 *   hNat                       NAT instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successful
 */
LONG NatInstanceULInterfaceDestroy(H_NETINSTANCE hNat,
                                   H_NETINTERFACE hInterface)
{
  NAT_CHECK_STATE((NATSTATE*) hNat);

  if((OCTET)hInterface != 1){
    /*check if the interface is out of range*/
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
    return NETERR_BADVALUE;
  }

  return NETERR_NOERR;
}

/*
 * NatInstanceULInterfaceIoctl
 *  NAT UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and nettransport.h
 *  for precisions
 *
 *  Args:
 *   hNat                      NAT instance handle
 *   hULInterface              Interface handle
 *   oIoctl                    Ioctl msg
 *   hData                     data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG NatInstanceULInterfaceIoctl(H_NETINSTANCE hNat,
                                 H_NETINTERFACE hULIf,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  NATSTATE *pxNat = (NATSTATE *)hNat;
  LONG lReturn = 0;

  NAT_CHECK_STATE(pxNat);

  if((OCTET)hULIf != 1){
    /*check if the interface is out of range*/
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
    return NETERR_BADVALUE;
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
  {
    /*NAT_DBGP(DBGLVL_REPETITIVE, "NatInstanceULInterfaceIoctl: oIoctl: %x\n", oIoctl);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NatInstanceULInterfaceIoctl: oIoctl : ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* ignore those */
    break;
  case NETINTERFACEIOCTL_SETHINST:
    pxNat->hULInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxNat->pfnRxCbk = (PFN_NETRXCBK)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxNat->hULIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = -1;
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
  }


  return lReturn;
}




/*
 * NatInstanceLLInterfaceCreate
 *
 *  Args:
 *   hNat                NAT instance
 *
 *  Return:
 *   H_NETINTERFACE      Interface handle
 */
H_NETINTERFACE NatInstanceLLInterfaceCreate(H_NETINSTANCE hNat)
{
  NAT_CHECK_STATE((NATSTATE*) hNat);

  return (H_NETINTERFACE)1;
}

/*
 * NatInstanceLLInterfaceDestroy
 *  Destroy a NAT LL interface
 *
 *  Args:
 *   hNat                    NAT instance
 *   hInterface              Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG NatInstanceLLInterfaceDestroy(H_NETINSTANCE hNat,
                                   H_NETINTERFACE hInterface)
{
  NAT_CHECK_STATE((NATSTATE*) hNat);

  if((OCTET)hInterface != 1){
    /*check if the interface is out of range*/
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
    return NETERR_BADVALUE;
  }

  return NETERR_NOERR;
}

/*
 * NatInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hNat                      NAT instance handle
 *   hULInterface              Interface handle
 *   oIoctl                    Ioctl msg
 *   hData                     data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG NatInstanceLLInterfaceIoctl(H_NETINSTANCE hNat,
                                 H_NETINTERFACE hLLIf,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  NATSTATE *pxNat = (NATSTATE *)hNat;
  LONG lReturn = NETERR_NOERR;

  NAT_CHECK_STATE(pxNat);

  /*
   * Check if the LL Interface is valid
   */
  if((OCTET)hLLIf != 1){
    /*check if the interface is out of range*/
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
    return NETERR_BADVALUE;
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_NAT, INET_DBG_LEVEL_REPETITIVE))
  {
    /*NAT_DBGP(DBGLVL_REPETITIVE, "NatInstanceLLInterfaceIoctl: oIoctl: %x\n", oIoctl);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "NatInstanceLLInterfaceIoctl: oIoctl: ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oIoctl) {

  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* Ignore these */
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxNat->hLLInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxNat->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxNat->hLLIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = -1;
    NAT_DBG(DBGLVL_REPETITIVE, ASSERT(0));
  }

  return lReturn;
}
