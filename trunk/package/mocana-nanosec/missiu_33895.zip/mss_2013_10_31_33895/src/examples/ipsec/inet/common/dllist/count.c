#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"


/* ** NOTE ** If you change this function remember also to change the
// macro DLLIST_count_inline to match
*/

DWORD DLLIST_count(DLLIST *dllist)
{
  if (dllist == NULL) 
    return(0);
  
  return(dllist->count);
}

