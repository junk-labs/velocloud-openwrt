/*
 * trackingh
 *
 * tracking constants and prototypes
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _TRACKING_H
#define _TRACKING_H

**
**   30-jun-94  JK    Initial Version
**   08-jul-94  JK    add TRACK_ON/OFF and an example
**   11-jul-94  JK    add 2nd track (TRACK2*), TRACK_FAST()
**             (which does not checking for skip,
**               TRACK*_ON, or wrap at end) and
**                alloc some slop over requested
**                 to cover TRACK_FAST not wrapping
**   13-oct-94  JK    clear the slop as well
**   21-oct-94  JK      do ASSERTs only if requested
**   10-nov-94  JK      use globals for the constants
**   02-dec-94  JK      move track vars into a structure, and
**             base everything off of that structure
**   13-jan-95  JK    add pdwTrkWrapFrom, fill it when wrap,
**             change pdwTrkWrap to pdwTrkWrapTo
**   10-mar-95  JK    make TRACK_FAST wrap properly
**   02-aug-95  JK    change to subroutines to save space (except TRACK_FAST)
**   20-sep-95  JK    truncate TRACK_TAG args to bytes
**   24-oct-95  JK    added TRACK_MEM() (but it is inefficient!)
**   21-nov-95    JK    get TRKVARS and buffer in one malloc
**   17-jan-96    JK    init WrapFrom so that tracker.exe doesn't complain
**   14-may-96    JK    add TRACK_MEMW() function to dump possibly wrapped data
**   28-may-96    JK    cast (po) to (OCTET *) in MEM macros
**
**  TO DO:
**   - fix TRACK_SUPPRESS (very low priority, it has never been a problem)
**
**  To use, include "TRACK_DEFS;" to define the globals and
**  then call "TRACK_INIT;" to alloc the track buffer and clear it.
**  Once this is done, "TRACK(value);" will save the given value (as
**  a DWORD) in the tracking buffer and advance to the next buffer
**  location. Call "TRACK_RESET;" to reinitialize the buffer, this
**  overwrites any tags in the buffer with TRACK_VOID. Tracking may
**  be turned off by calling "TRACK_OFF;" in the code, and turned back
**  on by calling "TRACK_ON;" (Note that initially tracking is on,
**  also that TRACK_RESET has no effect on whether or not tracking is
**  on or off). For an example of tracking, see trktst.c.
**
**  Tracking is enabled if TRACKING_ON is defined. Interrupts are
**  suspended over tracking operations (other than TRACK_INIT) if
**  TRACK_SUPPRESS is defined. The buffer is surrounded by DWORDs of
**  TRACK_SENTINEL, and the next available (and all unused entries)
**  are marked by TRACK_AVAIL.
**
**  TRACK_SIZE defines the # of DWORDs in the buffer, TRACK_WRAP_TO
**  specifies where to wrap to in the buffer once the end is reached
**  (this can preserve the 1st entries in the buffer, this *MUST* be
**  less than TRACK_SIZE and greater than 0), TRACK_SKIP specifies
**  the # of tracking entries to skip before saving any (TRACK_RESET
**  has no effect on this, i.e. if the skip count has been satisfied
**  then a reset does not restart the skip count). If a wrap has occurred
**  then the entry before the 1st wrapped entry is filled with the value
**  TRACK_WRAPPED.
**
**  If track tags are use, the tracker.exe program can be used to
**  convert a track buffer within a dump into a ASCII hex dump
**  with each tag on a newline and all of the tag entries for each
**  tag grouped after the tag. To use track tags, precede each
**  bunch of TRACK()s with a TRACK_TAG(cc, tt, nn), where
**  cc and tt are each 1 byte values which identify the
**  following group of tracked data and where nn specifies
**  the number of TRACK()s in the group. The tag goes into
**  the track buffer as 0xDBccttnn.
*/
#ifndef TRACKING_ON
/*
 * no tracking
 */
#define TRACK_DEFS
#define TRACK_INIT
#define TRACK_RESET
#define TRACK_FAST(dw)
#define TRACK(dw)
#define TRACK_TAG(t,s,n)
#define TRACK_MEM(po,l)
#define TRACK_MEMW(po,l, poT, poB)
#define TRACK_4B(po)
#define TRACK_OFF
#define TRACK_ON
#define TRACK2(dw)
#define TRACK2_TAG(t,s,n)
#define TRACK2_MEM(po,l)
#define TRACK2_MEMW(po,l, poT, poB)
#define TRACK2_4B(po)
#define TRACK2_OFF
#define TRACK2_ON

#else
/*
 * tracking on
 */
#include "NNstyle.h"
#include <stdlib.h>

#ifdef TRACK_DO_ASSERTS
#  define TRKASSERT(c) ASSERT(c)
#else
#  define TRKASSERT(c) ((void) (c))
#endif

#ifdef TRACK_SUPPRESS
#include "h320.h"
#endif

#ifndef TRACK_SIZE
#define TRACK_SIZE    4096        /* # entries in buffer        */
#endif


#ifndef TRACK_SKIP
#define TRACK_SKIP    0        /* # entries to skip        */
#endif

#ifndef TRACK_WRAP_TO
#define TRACK_WRAP_TO    2048            /* entry to wrap to         */
#endif

#if (TRACK_WRAP_TO >= TRACK_SIZE)
#error "wrap must be < TRACK_SIZE"
#endif
#if (TRACK_WRAP_TO <= 0)
#error "wrap must be > 0"
#endif


#ifndef TRACK_SLOP
#define TRACK_SLOP    20        /* alloc extra entries as slop     */
#endif                    /*  (TRACK_FAST used to not    */
                    /*    check for the end!)    */

#define TRACK_MARK    0xDBDBDBDBL

#define TRACK_SENTINEL    0xAAAAAAAAL    /* buffer sentinels        */
#define TRACK_AVAIL    0xBBBBBBBBL    /* available buffer space    */
                    /*  (also marks pdwTrkNext)    */
#define TRACK_WRAPPED    0xCCCCCCCCL    /* wrap location             */
#define TRACK_VOID    0xDDDDDDDDL    /* voided entry              */

#define TRACK_ENDIAN    0x000000FFL
#define TRACK_SW_ENDIAN    0xFF000000L

#define TRACK_MEMW_EXT    0xDBDBDBFFL    /* marks wrap for TRACK_MEMW    */


/* this is not correct, because no NOPs after supress */
#ifdef TRACK_SUPPRESS
#define TRACK_SUPPRESS_SHORT     PUT_VCP_REG(riface_irqsupress, 0x0000000A)
#define TRACK_SUPPRESS_LONG     PUT_VCP_REG(riface_irqsupress, 0x00000000)
#else
#define TRACK_SUPPRESS_SHORT
#define TRACK_SUPPRESS_LONG
#endif

typedef struct {
  DWORD dwTrkMark;
  DWORD *pdwTrkTop;        /* addr of 1st data entry        */
  DWORD *pdwTrkBot;        /* addr past last data entry        */
  DWORD *pdwTrkNext;
  DWORD *pdwTrkWrapTo;
  DWORD *pdwTrkWrapFrom;
  DWORD dwTrkSkip;
  DWORD bTrk1On;
  DWORD bTrk2On;
  DWORD dwTrkSentinel;
  DWORD dwTrkAvail;
  DWORD dwTrkWrapped;
  DWORD dwTrkVoid;
  DWORD dwTrkDataLen;        /* #bytes of track data            */
  DWORD dwTrkEndian;        /* shows Endian used            */
  DWORD dwPad1;            /* brings TRKVARS up to 2**n        */
                /* data immediately follows TRKVARS    */
} TRKVARS, *PTRKVARS;


MOC_EXTERN PTRKVARS pTrkVars;
MOC_EXTERN void TrkInit(void);
MOC_EXTERN void TrkReset(void);
MOC_EXTERN void Trk0(DWORD, DWORD);
MOC_EXTERN void Trk0Tag(DWORD, DWORD, DWORD, DWORD);
MOC_EXTERN void Trk04B(DWORD, OCTET *);
MOC_EXTERN void Trk0Mem(DWORD, OCTET *, int);
MOC_EXTERN void Trk0MemW(DWORD, OCTET *, int, OCTET *, OCTET *);


/*
 * This macro defines the base Track Buffer pointer and the
 * subroutines used for tracking. These subroutines should not
 * be used directly, use the macros defined later to call these
 * subroutines.
 */
#define TRACK_DEFS                                  \
                                          \
PTRKVARS pTrkVars = NULL;                              \
                                          \
void TrkInit(void)                                  \
{                                          \
  DWORD dwDataLen, dwHdrLen, dwTotalLen;                      \
  TRKASSERT(NULL == pTrkVars);                              \
  dwHdrLen = sizeof(TRKVARS);                              \
  dwDataLen = 4 * (TRACK_SIZE + 2 + TRACK_SLOP);                  \
  dwTotalLen = dwHdrLen + dwDataLen;                          \
  pTrkVars = (PTRKVARS) MALLOC(dwTotalLen);                       \
  TRKASSERT(NULL != pTrkVars);                              \
  pTrkVars->dwTrkMark = TRACK_MARK;                          \
  pTrkVars->dwTrkDataLen = dwDataLen;                          \
  pTrkVars->pdwTrkTop = (DWORD *) (dwHdrLen + (DWORD) pTrkVars);          \
  pTrkVars->bTrk1On = TRUE;                              \
  pTrkVars->bTrk2On = TRUE;                              \
  pTrkVars->dwTrkSentinel = TRACK_SENTINEL;                      \
  pTrkVars->dwTrkAvail = TRACK_AVAIL;                          \
  pTrkVars->dwTrkWrapped = TRACK_WRAPPED;                      \
  pTrkVars->dwTrkVoid = TRACK_VOID;                          \
  pTrkVars->dwTrkEndian = TRACK_ENDIAN;                          \
  *pTrkVars->pdwTrkTop++ = pTrkVars->dwTrkSentinel;                  \
  pTrkVars->pdwTrkBot = pTrkVars->pdwTrkTop + TRACK_SIZE;              \
  *pTrkVars->pdwTrkBot = pTrkVars->dwTrkSentinel;                  \
  *(pTrkVars->pdwTrkBot + TRACK_SLOP) = pTrkVars->dwTrkSentinel;          \
  pTrkVars->pdwTrkWrapTo = pTrkVars->pdwTrkTop + TRACK_WRAP_TO;              \
  pTrkVars->pdwTrkWrapFrom = pTrkVars->pdwTrkBot;                  \
  pTrkVars->dwTrkSkip = TRACK_SKIP;                          \
  pTrkVars->pdwTrkNext = pTrkVars->pdwTrkTop;                      \
  while (pTrkVars->pdwTrkNext <    (pTrkVars->pdwTrkBot + TRACK_SLOP))          \
    *pTrkVars->pdwTrkNext++ = pTrkVars->dwTrkAvail;                  \
  pTrkVars->pdwTrkNext = pTrkVars->pdwTrkTop;                      \
}                                          \
                                          \
void TrkReset(void)                                  \
{                                          \
  TRKASSERT(NULL != pTrkVars->pdwTrkTop);                      \
  TRACK_SUPPRESS_LONG;                                  \
  *(pTrkVars->pdwTrkNext) = pTrkVars->dwTrkVoid;                  \
  pTrkVars->pdwTrkNext = pTrkVars->pdwTrkTop;                      \
  TRACK_SUPPRESS_LONG;                                  \
  *pTrkVars->pdwTrkNext = pTrkVars->dwTrkAvail;                      \
  *(pTrkVars->pdwTrkWrapTo - 1) = pTrkVars->dwTrkVoid;                  \
  *(pTrkVars->pdwTrkWrapFrom) = pTrkVars->dwTrkVoid;                  \
}                                          \
                                          \
void Trk0(DWORD tn, DWORD dw)                              \
{                                          \
  TRKASSERT(NULL != pTrkVars->pdwTrkTop);                      \
  TRACK_SUPPRESS_SHORT;                                  \
  if (tn == 1) {                                  \
    if (!pTrkVars->bTrk1On) return;                          \
  }                                          \
  else {                                      \
    if (!pTrkVars->bTrk2On) return;                          \
  }                                          \
  TRACK_SUPPRESS_SHORT;                                  \
  if (0 == pTrkVars->dwTrkSkip) {                          \
    TRACK_SUPPRESS_LONG;                              \
    *pTrkVars->pdwTrkNext++ = (DWORD) (dw);                      \
    TRACK_SUPPRESS_LONG;                              \
    if (pTrkVars->pdwTrkNext >= pTrkVars->pdwTrkBot) {                  \
      pTrkVars->pdwTrkWrapFrom = pTrkVars->pdwTrkNext;                  \
      *(pTrkVars->pdwTrkWrapFrom) = pTrkVars->dwTrkWrapped;              \
      pTrkVars->pdwTrkNext = pTrkVars->pdwTrkWrapTo;                  \
      TRACK_SUPPRESS_LONG;                              \
      *(pTrkVars->pdwTrkNext - 1) = pTrkVars->dwTrkWrapped;              \
    }                                          \
    *pTrkVars->pdwTrkNext = pTrkVars->dwTrkAvail;                  \
  }                                          \
  else {                                      \
    TRACK_SUPPRESS_SHORT;                              \
    pTrkVars->dwTrkSkip--;                              \
    (void) (dw);                                  \
  }                                          \
}                                          \
                                          \
void Trk0Tag(DWORD tn, DWORD t, DWORD s, DWORD n)                  \
{                                          \
  DWORD dw4h5hgg3;                                  \
  dw4h5hgg3  = 0xDB000000L | ((OCTET) t << 16) | ((OCTET) s << 8) | (OCTET) n;\
  TRACK0(tn, dw4h5hgg3);                              \
}                                          \
                                          \
void Trk04B(DWORD tn, OCTET *po)                          \
{                                          \
  DWORD dw4h5hgg3;                                  \
  dw4h5hgg3  = ((DWORD) *((OCTET *) (po) + 0)) << 24;                  \
  dw4h5hgg3 |= ((DWORD) *((OCTET *) (po) + 1)) << 16;                  \
  dw4h5hgg3 |= ((DWORD) *((OCTET *) (po) + 2)) <<  8;                  \
  dw4h5hgg3 |= ((DWORD) *((OCTET *) (po) + 3));                      \
  TRACK0(tn, dw4h5hgg3);                              \
}                                          \
                                          \
void Trk0Mem(DWORD tn, OCTET *po, int nLen)                      \
{                                          \
  DWORD dw4h5hgg3;                                  \
                                          \
  while (nLen > 0) {                                  \
    dw4h5hgg3  = ((DWORD) *((OCTET *) (po) + 0)) << 24;                  \
    dw4h5hgg3 |= ((DWORD) *((OCTET *) (po) + 1)) << 16;                  \
    dw4h5hgg3 |= ((DWORD) *((OCTET *) (po) + 2)) <<  8;                  \
    dw4h5hgg3 |= ((DWORD) *((OCTET *) (po) + 3));                  \
    TRACK0(tn, dw4h5hgg3);                              \
    po += 4;                                      \
    nLen -= 4;                                      \
  }                                          \
}                                          \
                                          \
void Trk0MemW(DWORD tn, OCTET *po, int nLen, OCTET *poT, OCTET *poB)          \
{                                          \
  DWORD dwLenToBot;                                  \
                                          \
  dwLenToBot = poB - po;                              \
  if (nLen > dwLenToBot) {                              \
    Trk0Mem(tn, po, dwLenToBot);                          \
    nLen -= dwLenToBot;                                  \
    po = poT;                                      \
    Trk0(tn, TRACK_MEMW_EXT);                              \
  }                                          \
  Trk0Mem(tn, po, nLen);                              \
}                                          \
                                          \








/*
 * macros used for tracking
 */
#define TRACK_INIT TrkInit()
#define TRACK_RESET TrkReset()
#define TRACK0(tn, dw) Trk0((DWORD) (tn), (DWORD) (dw))
#define TRACK0_TAG(tn, t, s, n) Trk0Tag((DWORD) (tn),(DWORD) (t),(DWORD) (s),(DWORD) (n))
#define TRACK0_4B(tn, po) Trk04B((DWORD) (tn), (OCTET *) (po))

#define TRACK_FAST(dw)                                   \
        do {                               \
          register PTRKVARS pT = pTrkVars;               \
          *pT->pdwTrkNext++ = (DWORD) (dw);               \
          if (pT->pdwTrkNext >= pT->pdwTrkBot) {           \
            pT->pdwTrkWrapFrom = pT->pdwTrkNext;           \
            pT->pdwTrkNext = pT->pdwTrkWrapTo;               \
          }                               \
        } while (0)

#define TRACK0_ON(tn, b)  do {pTrkVars->bTrk##tn##On = (b);} while (0)

#define TRACK(dw)        TRACK0(1, (dw))
#define TRACK_TAG(t,s,n)    TRACK0_TAG(1, (t), (s), (n))
#define TRACK_MEM(po,l)        Trk0Mem(1, (OCTET *) (po), (l))
#define TRACK_MEMW(po,l, poT, poB)                          \
                Trk0MemW(1, (OCTET *) (po), (l),          \
                        (OCTET *) (poT), (OCTET *) (poB))
#define TRACK_4B(po)        TRACK0_4B(1, (OCTET *) (po))
#define TRACK_OFF        TRACK0_ON(1, FALSE)
#define TRACK_ON        TRACK0_ON(1, TRUE)

#define TRACK2(dw)        TRACK0(2, (dw))
#define TRACK2_TAG(t,s,n)    TRACK0_TAG(2, (t), (s), (n))
#define TRACK2_MEM(po,l)    Trk0Mem(2, (OCTET *) (po), (l))
#define TRACK2_MEMW(po,l, poT, poB)                          \
                Trk0MemW(2, (OCTET *) (po), (l),          \
                        (OCTET *) (poT), (OCTET *) (poB))
#define TRACK2_4B(po)        TRACK0_4B(2, (OCTET *) (po))
#define TRACK2_OFF        TRACK0_ON(2, FALSE)
#define TRACK2_ON        TRACK0_ON(2, TRUE)




#endif

#endif
