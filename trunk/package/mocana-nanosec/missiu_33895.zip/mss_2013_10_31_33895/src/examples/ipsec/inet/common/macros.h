#ifndef __MACROS_H__
#define __MACROS_H__

#define abs(x)	((x) < 0 ? -(x) : (x))

#define max(a,b)	((a) >= (b) ? (a) : (b))
#define min(a,b)	((a) <= (b) ? (a) : (b))

#define ABS(x)		abs(x)
#define MAX(a,b)	max(a,b)
#define MIN(a,b)	min(a,b)

#endif
