/*
 * dnsdbg.h
 *
 * DNS module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __DNSDBG_H__
#define __DNSDBG_H__

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef DNSDBG_HI
   #define DNSDBG_HI
  #endif

 #endif

#else

 #ifdef DNSDBG_HI
  #undef DNSDBG_HI
 #endif

#endif

#include "netdbg.h"

#define DNS_MAGIC_COOKIE 0x646e7300 /*"dns" = 0x646e7300*/

/*#ifdef DNSDBG_HI*/
#if defined(DNSDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define DNS_CHECK_STATE(x) \
            ASSERT((x) && ((x)->dwMagicCookie == DNS_MAGIC_COOKIE));

  #define DNS_SET_COOKIE(x) (x)->dwMagicCookie = DNS_MAGIC_COOKIE
  #define DNS_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define DNS_DBGP(level, fmt, args...) do { \
    if (level <= g_dwDnsDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define DNS_DBG(level, x) do {  \
    if (level <= g_dwDnsDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define DNS_DBG_VAR(x)  x

  #define DNS_CHECKPOINT(x)  (x = __LINE__)
#else
  #define DNS_CHECK_STATE(x)
  #define DNS_SET_COOKIE(x)
  #define DNS_UNSET_COOKIE(x)
#if defined (__VXWORKS_RTOS__)
  #define DNS_DBGP
#else
  #define DNS_DBGP(level, fmt, args...)
#endif
  #define DNS_DBG(level, x)
  #define DNS_DBG_VAR(x)
  #define DNS_CHECKPOINT(x)
#endif

DNS_DBG_VAR(MOC_EXTERN DWORD g_dwDnsDebugLevel);

#define DNS_DBGLVL_ERROR_RARE 1
#define DNS_DBGLVL_NORMAL     2
#define DNS_DBGLVL_REPETITIVE 3

#endif /* #ifndef __DNSDBG_H__ */

