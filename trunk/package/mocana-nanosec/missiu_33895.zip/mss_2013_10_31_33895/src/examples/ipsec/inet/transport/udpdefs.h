/*
 * udpdefs.h
 *
 * UDP module common definitions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef __UDPDEFS_H__
#define __UDPDEFS_H__

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "nettransport.h"

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

#define UDP_USRPORT 1024
#define UDP_MAXPORT 5000

/*
 * UDP LL interface instance handle value
 */
#define UDPLLINTERFACEHANDLE 1

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * UDP connection structure
 */
typedef struct {
  TRANSPORTID xId;
  OCTET oRemoteNotVolatile; /* 1 == Remote not volatile (connect case) */

  BOOL bTxCheck;
  BOOL bWithInAddrAny;

  BOOL bIsReuseAllowed;

  H_NETINSTANCE hUL;
  H_NETINTERFACE hIf;

  PFN_NETRXCBK pfnRxCbk;

  /* Multicast info. Used to reside in UDPSOCKET */
  IPMCASTREQ *pxIpMcastReq;
  DWORD dwMcastIf;
} UDPCONN;

/*
 * UDP instance structure
 */
typedef struct {

  /* UDP instance options. !!! Must follow the enum order !!! */
  WORD wOffset;
  WORD wTrailer;
  /* END UDP instance options */
  #ifndef NDEBUG
  DWORD dwMagicCookie;
  #endif

  PFN_NETCBK pfnNetCbk;
  H_NETINSTANCE hNetCbk;

  DLLIST dllConns;

  pthread_mutex_t *pxMutex;

  /* LL interface */
  H_NETINTERFACE hUdpLLIf;
  H_NETINSTANCE hLL;
  PFN_NETWRITE pfnLLWrite;

} UDPSTATE;

#endif /* #ifndef __UDPDEFS_H__*/

