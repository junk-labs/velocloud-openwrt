/*
 * gethostbyaddr.c
 *
 * Function of Domain Name Server client
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "NNstyle.h"
#include "dns_flavor.h"
#include "../include/ioctl.h"
#include "../include/socket_inet.h"
#include "../include/socket.h" /* sockaddr */
#include "../include/in.h" /* sockaddr_in */
#include "nettime.h"
#include "../include/netselect.h" /* FD_xxx */
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdb.h"
#include "sockapi.h"
#include "dnsdbg.h"
#include "dnsapi.h"
#include "dns.h"

/*
 * gethostbyaddr
 *  Standard API DNS resolver function - see man
 *  page for complete description
 *
 * Args:
 *  pcAddr                       ptr to address to resolve (DWORD cast to char *)
 *  iLength                        length of pcAddr.  MUST be 4.
 *  iType                        must be AF_INET
 *
 * Return:
 *  struct hostent * (see netdb.h or man page)
 */
struct hostent * gethostbyaddr(char *pcAddr, int iLength, int iType)
{
  struct hostent *pxHostent = NULL;
  OCTET *poName;
  OCTET *poTmp;
  DWORD dwAddr;
  DWORD dwIdx;
  struct sockaddr_in xServAddr;

  ASSERT((pcAddr != NULL) &&
         (AF_INET == iType) &&
         (IP_ADDR_LEN == iLength));

#ifdef _ENABLE_DNS_
  if (NETERR_NOERR != DnsWaitForInit()) {
    mn_errno = EDNSSERVERNOTSET;
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_DNS, ERROR))
    {
        DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "gethostbyaddr:Failed mn_errno = ",
            mn_errno);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
    }
    return ((void *)NULL);
  }
#endif /* _ENABLE_DNS_ */

#if defined(STRICT_POSIX)
  if (AF_INET != iType || IP_ADDR_LEN != iLength || NULL == pcAddr) {
    mn_errno = EDNSILLEGALPARMS;
    return ((void *)NULL);
  }
#endif

  poName = MALLOC(32);
  ASSERT(poName);
  MOC_MEMSET((ubyte *)poName,0,32);

  /* ??? go through proper endian code rather than doing this !!!!! */
  poTmp = (OCTET*)&dwAddr;
  poTmp[0] = pcAddr[3];
  poTmp[1] = pcAddr[2];
  poTmp[2] = pcAddr[1];
  poTmp[3] = pcAddr[0];

  xServAddr.sin_addr.s_addr = (in_addr_t)dwAddr;
  MOC_STRCBCPY((sbyte *)poName,
        MOC_STRLEN((sbyte *)inet_ntoa(xServAddr.sin_addr)),
            (sbyte *)inet_ntoa(xServAddr.sin_addr));
  MOC_STRCBCPY((sbyte *)(poName + MOC_STRLEN((sbyte *)inet_ntoa(xServAddr.sin_addr)) -1), MOC_STRLEN(".in-addr.arpa"), ".in_addr.arpa");

#ifdef _ENABLE_DNS_
  pxHostent = gethostbyeither(poName, DNS_LOOKUP_ADDR);
  if (pxHostent) {
    for (dwIdx = 0; pxHostent->h_addr_list[dwIdx]; dwIdx++) {
      *(DWORD *)pxHostent->h_addr_list[dwIdx] = *(DWORD *)pcAddr;
        if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_DNS, ERROR))
        {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "gethostbyaddr:Result iIdx ",
                dwIdx);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," pcAddr ",
                *(DWORD *)pxHostent->h_addr_list[dwIdx]);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
        }
    }
  }
#endif /* _ENABLE_DNS_ */
  FREE(poName);
  return pxHostent;
}

