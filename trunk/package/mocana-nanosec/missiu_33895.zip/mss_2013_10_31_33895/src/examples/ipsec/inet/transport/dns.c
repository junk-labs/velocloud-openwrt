/*
 * dns.c
 *
 * Domain Name Server client (resolver)
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "NNstyle.h"
#include "dns_flavor.h"
#include <sys/ioctl.h>
#include "sys/socket_inet.h"
#include <sys/socket.h> /* sockaddr */
#include "netinet/in.h" /* sockaddr_in */
#include "nettime.h"
#include <sys/select.h> /* FD_xxx */
#include <sys/sockio.h>
#include <net/if.h>
#include <arpa/inet.h>
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdb.h"
#include "netdbg.h"
#include "sockapi.h"
#include "dnsdbg.h"
#include "dnsapi.h"
#include "dns.h"


/****************************************************************************
 *
 * Definitions
 *
 ****************************************************************************/

struct timeval
  {
    long int tv_sec;            /* Seconds.  */
    long int tv_usec;      /* Microseconds.  */
  };

DNS_DBG_VAR(DWORD g_dwDnsDebugLevel = 3);
DNS_DBG_VAR(DWORD dbg_dwDnsLineA=0);
DNS_DBG_VAR(DWORD dbg_dwDnsLineB=0);


/****************************************************************************
 *
 * Global variables
 *
 ****************************************************************************/
DNSSTATE       xDNSState;
pthread_mutex_t xDnsMutex         = PTHREAD_MUTEX_INITIALIZER;



/****************************************************************************
 *
 * Utility functions
 *
 ****************************************************************************/


/*
 * DnsWaitForInit
 *  Make thread sleep while DNS not initialized.
 *
 *  Args:
 *   None
 *
 *  Return:
 *   NETERR_UNKNOWN|NETERR_NOERR
 */
int
DnsWaitForInit(void)
{
  struct timespec xTime = {0,200*1000000};/* 200ms */
  while (xDNSState.oInitState == DNSINITSTATE_NONE) {
    nanosleep(&xTime, NULL);
  }

  return (xDNSState.oInitState != DNSINITSTATE_OK) ? NETERR_UNKNOWN :
    NETERR_NOERR;
}

/*
 * DnsFreeHostEntMembers
 *  Free all the members of a hostent structure if allocated
 *
 *  Args:
 *   pxHostEnt            Ptr to a hostent structure
 *
 *  Return:
 *   None
 */
void
DnsFreeHostEntMembers(struct hostent * pxHostEnt)
{
  INT i;
  /* free all dynamically allocated buffers */

  if (pxHostEnt->h_name) {
    DNS_DBGP(DNS_DBGLVL_REPETITIVE, "free_hostent_members:REL1: %p (%d)\n",
             pxHostEnt->h_name, pthread_self());
    FREE(pxHostEnt->h_name);
  }
  if (pxHostEnt->h_aliases) {
    for (i = 0; pxHostEnt->h_aliases[i]; i++) {
      DNS_DBGP(DNS_DBGLVL_REPETITIVE, "free_hostent_members:REL2: %p (%d)\n",
               pxHostEnt->h_aliases[i], pthread_self());
      FREE(pxHostEnt->h_aliases[i]);
    }
    FREE(pxHostEnt->h_aliases);
  }
  if (pxHostEnt->h_addr_list) {
    if (pxHostEnt->h_addr_list[0]) {
      FREE(pxHostEnt->h_addr_list[0]);
    }
    FREE(pxHostEnt->h_addr_list);
  }
}

/*
 * DnsClearHostlist
 *  Performs functions:
 *   - If hostentry for this process id in hostlist (for this interface)
 *      - Free hostlist for DNS running on current process.
 *   - ... else allocate host list entry & add to head of the host list
 *
 *  Args:
 *   pxHostEnt              Host entry structure reference
 *   pxDnsControlLocal      DNS control structure ref. used to supply info. req.
 *
 *  Return:
 *   Ptr to host entry pxHostEnt with empty content (as either cleared
 *    or created
 */
struct hostent *
DnsClearHostlist(struct hostent   *pxHostEnt,
                 STRUCTDNSCONTROL *pxDnsControlLocal)
{
  HOSTENT_LIST  *pxHlist;

  /* Search for an existing hostent for this pid  */
  pxHlist = pxDnsControlLocal->pxHostEntList;
  while (pxHlist) {
    if (pxHlist->wPId == pthread_self()) {
      pxHostEnt = &pxHlist->xHostEnt;
      break;
    }
    pxHlist = pxHlist->pxNext;
  }

  if (!pxHostEnt) {
    pxHlist = MALLOC(sizeof(HOSTENT_LIST));
    ASSERT(pxHlist);
    MOC_MEMSET((ubyte *)pxHlist, 0, sizeof(HOSTENT_LIST));
    pxHlist->wPId = pthread_self();
    pxHlist->pxNext = pxDnsControlLocal->pxHostEntList;  /* put new entry on head of list */
    pxDnsControlLocal->pxHostEntList = pxHlist;
    pxHostEnt = &pxHlist->xHostEnt;
  } else {
    DnsFreeHostEntMembers(pxHostEnt);
#if 0
    /* free all previously dynamically allocated buffers */
    if (pxHostEnt->h_name) {
      DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsClearHostlist:REL1: %p (%d)\n",
               pxHostEnt->h_name, pthread_self());
      FREE(pxHostEnt->h_name);
    }
    if (pxHostEnt->h_aliases) {
      for (i = 0; pxHostEnt->h_aliases[i]; i++) {
        DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsClearHostlist:REL2: %p (%d)\n",
                 pxHostEnt->h_aliases[i], pthread_self());
        FREE(pxHostEnt->h_aliases[i]);
      }
      FREE(pxHostEnt->h_aliases);
    }
    if (pxHostEnt->h_addr_list) {
      if (pxHostEnt->h_addr_list[0]){
        FREE(pxHostEnt->h_addr_list[0]);
      }
      FREE(pxHostEnt->h_addr_list);
    }
#endif
  }
  bzero(pxHostEnt, sizeof(struct hostent));
  return pxHostEnt;
}


/*
 * ParseHostname
 *  Parse a host name
 *
 *  Args:
 *   pxDnsControlLocal      DNS control structure reference
 *   poHost                 Ptr to start of the hostname to parse
 *   poMsgTop               Ptr to start of DNS msg (the ID field in header)
 *   pwType                 Ptr to Type field to fill in with type field
 *
 *  Return:
 *   iCount                 Offset of subsequent hostname
 */
INT
ParseHostname(STRUCTDNSCONTROL  *pxDnsControlLocal,
              OCTET             *poHost,
              OCTET             *poMsgTop,
              WORD              *pwType)
{
  int iRedirect = 0, iCount = 0;
  int i, j, k=0;
  OCTET *poTmp = poHost;

  if (0 == *poHost) {
    pxDnsControlLocal->szHost[0] = '\0';
    return (1 + 10);
  }

  /* Check for name compression (pointers to domain names) and change number to "."  */
  while (0 != *poHost) {
    if (0xC0 == (*poHost & 0xC0)) {
      poHost = poMsgTop + ((*poHost & 0x3F) << 8) + *(poHost + 1);
      if (!iRedirect)
        iCount += 2;  /* only do this the first time */
      iRedirect++;
      continue;
    }
    for (i=0, j = *poHost++; i < j; i++) {
      if (k >= (sizeof(pxDnsControlLocal->szHost)-1) ) {
        break;
      }
      pxDnsControlLocal->szHost[k++] = *poHost++;
      if (!iRedirect)
        iCount++;
    }
    if (0 != *poHost) {
      if (k >= (sizeof(pxDnsControlLocal->szHost)-1) ) {
        break;
      }
      pxDnsControlLocal->szHost[k++] = '.';
      if (!iRedirect) iCount++;
    }
  }
  pxDnsControlLocal->szHost[k] = '\0';
  if (!iRedirect) iCount += 2;

  poTmp += iCount;
  *pwType  = (poTmp[0] << 8) + poTmp[1];

  return (iCount + 10); /* 10 as type=2,class=2,ttl=4,rdlength=2 */
}


/*
 * GetNameLen
 *  Get the length of a name & retrieve the resource data length
 *
 *  Args:
 *   poHere                 Ptr to start of resource record
 *   piRdLen                Ptr to value where resource data length
 *                          is to be placed
 *
 *  Return:
 *   Length of the resource record pointed to by poHere
 */
int
GetNameLen(OCTET  *poHere,
           int    *piRdLen)
{
  int n=0;

  while (poHere[n]) {
    if (0xC0 == (poHere[n] & 0xC0)) {
      n++;
      break;
    }
    n++;
  }
  n += 9;    /* '\0', type, class, & ttl - now points to rdlength */
  *piRdLen = (poHere[n] << 8) + poHere[n + 1];
  return (n + 2 + *piRdLen);
}


/*
 * GetPastRecord
 *
 *  Args:
 *   pxDnsControlLocal      DNS control structure reference
 *   poHere                 Ptr to question section of msg
 *   poMsg                  Ptr to start of DNS message
 *   wNum                   Number of questions to skip
 *
 *  Return:
 *   Ptr to data after wNum questions in the DNS message
 */
OCTET*
GetPastRecord(STRUCTDNSCONTROL *pxDnsControlLocal,
              OCTET            *poHere,
              OCTET            *poMsg,
              WORD             wNum)
{
  WORD i, wTmp;
  for (i=0; i<wNum; i++) {
    /* -10 to remove overhead & then +4 to accound for
     * type & class in question
     */
    poHere += ParseHostname(pxDnsControlLocal,
                            poHere, poMsg, &wTmp) - 10;
    poHere += 4;
  }
  return poHere;
}

static LONG debugNetPrintPayload(OCTET *poPayload, WORD wLength)
{
  int i,j;

  ASSERT(poPayload != NULL);

#define ISPRINT(x) ((x>=48) && (x<='z'))

#ifdef _ENABLE_DNS_
  printf("===========network payload begin===============\n");
  for (i=0;i<wLength;i++) {
    if ((i%16) == 0) {
      printf("%08lx\t", (DWORD)(poPayload+i));
    }
    printf("%02x:",*(poPayload + i));
    if (((i + 1)%16) == 0) {
      printf("   ");
      for (j=(i-15);j<=i;j++) {
        printf("%c",ISPRINT(*(poPayload+j)) ?  *(poPayload+j) : '.');
      }
      printf("\n");
    }
  }
  printf("\n");
  printf("===========network payload end=================\n");
#endif /* _ENABLE_DNS_ */

#if 0
  fflush(stdout);
#endif /* TBD */

  return 0;
}


/*
 * DnsParseReply
 *  Parse reply and attain response information
 *
 *  Args:
 *   pxDnsControlLocal      DNS control structure reference
 *   poMsg                  Ptr to start of DNS message
 *   iLen                   Length of the reply to parse
 *   ppxReplyList           Ptr to array of replies to be allocated by
 *                          this routine
 *   pwReplyCnt             Number of answers provided in the DNS reply
 *   eQueryType             Type of DNS query that had been requested
 *
 *  Return:
 *   DNS_PARSE_REPLY_TYPE   Result of parsing
 */
DNS_PARSE_REPLY_TYPE
DnsParseReply(STRUCTDNSCONTROL    *pxDnsControlLocal,
              OCTET               *poMsg,
              INT                 iLen,
              DNS_PARSE_REPLY     **ppxReplyList,
              WORD                *pwReplyCnt,
              ENUM_DNS_LOOKUP     eQueryType)
{
#ifdef DNSDBG_HI
  WORD wId   = (poMsg[0] << 8) + poMsg[1];
#endif
  WORD wFlags = (poMsg[2] << 8) + poMsg[3];

  WORD wNumQ = (poMsg[4] << 8) + poMsg[5];
  WORD wNumA = (poMsg[6] << 8) + poMsg[7];
#if defined(DNS_INDIRECT)
  WORD wNumAuth = (poMsg[8] << 8) + poMsg[9];
  WORD wNumAddl = (poMsg[10] << 8) + poMsg[11];
#endif
  WORD wType; /*, wFlags; */

  OCTET *poHere = poMsg;
  OCTET *poResp = poMsg;
  OCTET *poTmp;
  OCTET *poMsgEnd = poMsg + iLen;
  int i, j, iReadLen;
  DNS_PARSE_REPLY_TYPE nRetval = DNS_PARSE_NOT_FOUND;

  ASSERT(ppxReplyList);

#if defined(DNS_INDIRECT)
  DNS_DBG(DNS_DBGLVL_REPETITIVE,
  {
    puts("\nDnsParseReply:Header:");
    NetPrintPayload(poHere, sizeof(DNS_HEADER));
    printf(" ID     %d\n Flags  0x%04X\n #Qs    %d\n"
       " #As    %d\n #Auth  %d\n #Add'l %d\n\n",
       wId, wFlags,
       wNumQ, wNumA, wNumAuth, wNumAddl);
  });
#else
  DNS_DBG(DNS_DBGLVL_REPETITIVE,
  {
    puts("\nDnsParseReply:Header:");
    NetPrintPayload(poHere, sizeof(DNS_HEADER));
    printf(" ID     %d\n Flags  0x%04X\n #Qs    %d\n"
       " #As    %d\n\n",
       wId, wFlags,
       wNumQ, wNumA);
  });
#endif

  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "NumQ NumA %u %u \nquerytype %d \n,poHere %p \n",
           wNumQ, wNumA,eQueryType,poHere);


  if (wNumA==0) { /*No Answer  */
    nRetval = EDNSINVALIDREPLY;
    DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsParseReply: NO ANSWER in RESPONSE \n");
    /*    return nRetval;  */
  }

  /*Reply Count */
  *pwReplyCnt = wNumA;

  poHere += sizeof(DNS_HEADER);
  /* Get past Question Section   */
  poHere = GetPastRecord(pxDnsControlLocal,poHere ,poMsg, wNumQ);

  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsParseReply: eQueryType %d \n", eQueryType);

  /* Reverse Query */
  if (wNumA && (DNS_LOOKUP_ADDR == eQueryType ||
                DNS_LOOKUP_SRV ==  eQueryType ||
                DNS_LOOKUP_TXT ==  eQueryType)) {

    *ppxReplyList = (DNS_PARSE_REPLY *)MALLOC(wNumA*sizeof(DNS_PARSE_REPLY));
    ASSERT(*ppxReplyList);
    MOC_MEMSET((ubyte *)*ppxReplyList, 0, wNumA*sizeof(DNS_PARSE_REPLY));
    nRetval = DNS_PARSE_ANSWER;

    DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsParseReply: eQueryType %d\n", eQueryType);

    for (i = 0; i < wNumA; i++) {
      j = GetNameLen(poHere, &iReadLen);
      poHere += (j-iReadLen);

      DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsParseReply:poHere A %p\n", poHere);

      if (DNS_LOOKUP_SRV == eQueryType) {
        OCTET *poT;
        poResp = poHere;
        poTmp   = poHere + sizeof(DNS_SRV);
        /*Replace dot format of name */
        ParseHostname(pxDnsControlLocal,poTmp, poMsg, &wType);
        DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsParseReply:Srv parsednsrep poHere %p::%s::%s::\n" ,
                 (poTmp-1), (poTmp-1), pxDnsControlLocal->szHost);

        (*ppxReplyList)[i].szHostname =
            MALLOC(strlen(pxDnsControlLocal->szHost)+1+sizeof(DNS_SRV));
        poT = (OCTET *)(*ppxReplyList)[i].szHostname;
        ASSERT(poT);
        MOC_MEMSET((ubyte *)(*ppxReplyList)[i].szHostname, 0,
            strlen(pxDnsControlLocal->szHost)+1+sizeof(DNS_SRV));
        MOC_MEMCPY((ubyte *)poT, (ubyte *)poHere, sizeof(DNS_SRV));
        MOC_MEMCPY((ubyte *)(poT+sizeof(DNS_SRV)),
            (ubyte *)pxDnsControlLocal->szHost,
            strlen(pxDnsControlLocal->szHost)+1);
        DNS_DBGP(DNS_DBGLVL_REPETITIVE, "Txt>> %p %s\nTxt>>  %s\n",
                 poT+6, poT+6,(char *)((*ppxReplyList)[i].szHostname)+6);
      } else if (DNS_LOOKUP_TXT == eQueryType) {
        DNS_DBGP(DNS_DBGLVL_REPETITIVE, "Txt parsednsrep poHere  %s\n", poHere+1);
        (*ppxReplyList)[i].szHostname = MALLOC(iReadLen+1);
        ASSERT((*ppxReplyList)[i].szHostname);
        MOC_MEMSET((ubyte *)((*ppxReplyList)[i].szHostname), 0, iReadLen+1);
        MOC_MEMCPY((ubyte *)((*ppxReplyList)[i].szHostname),
                (ubyte *)(poHere+1), iReadLen-1 );
        DNS_DBGP(DNS_DBGLVL_REPETITIVE, "Txt>> %p %s\n",
                 (*ppxReplyList)[i].szHostname, (*ppxReplyList)[i].szHostname);
      } else {  /*Reverse Lookup */
        DNS_DBGP(DNS_DBGLVL_REPETITIVE, "Txt parsednsrep poHere  %s\n", poHere+1);
        ParseHostname(pxDnsControlLocal,poHere, poMsg, &wType);
        (*ppxReplyList)[i].szHostname = strdup(pxDnsControlLocal->szHost);
        DNS_DBGP(DNS_DBGLVL_REPETITIVE, "dup1: %p (%d)\n",
                 (*ppxReplyList)[i].szHostname, pthread_self());
        (*ppxReplyList)[i].dwIpAddr = 255; /* any non zero  value */
        DNS_DBGP(DNS_DBGLVL_REPETITIVE, "Txt>> %p %s\n",
                 (*ppxReplyList)[i].szHostname, (*ppxReplyList)[i].szHostname);
      }
      poHere += iReadLen;
    }
    return nRetval;
  }

  DNS_DBGP(DNS_DBGLVL_REPETITIVE, " eQueryType %d \n", eQueryType);

  /*poHere now points to answer RR  */
  if (wNumA) {
    DNS_DBGP(DNS_DBGLVL_REPETITIVE, " eQueryType %d \n", eQueryType);

    if (DNS_LOOKUP_NAME  == eQueryType) {
      DNS_DBGP(DNS_DBGLVL_REPETITIVE, " eQueryType %d \n", eQueryType);
      *ppxReplyList = MALLOC(wNumA *sizeof(DNS_PARSE_REPLY));
      ASSERT(*ppxReplyList);
      MOC_MEMSET((ubyte *)*ppxReplyList, 0, wNumA *sizeof(DNS_PARSE_REPLY));
      nRetval = DNS_PARSE_ANSWER;
    }

    for (i = 0; i < wNumA; i++) {
      j = GetNameLen(poHere, &iReadLen);
      poHere += ParseHostname(pxDnsControlLocal, poHere, poMsg, &wType);

      if (DNS_PARSE_ANSWER == nRetval) {
          DNS_DBGP(DNS_DBGLVL_REPETITIVE, " szhost %s \n",pxDnsControlLocal->szHost);
        (*ppxReplyList)[i].szHostname = strdup(pxDnsControlLocal->szHost);
          DNS_DBGP(DNS_DBGLVL_REPETITIVE, " szhost %s \n",pxDnsControlLocal->szHost);
        (*ppxReplyList)[i].dwIpAddr = (DNSTYPE_A == wType) ?
          (poHere[0] << 24) + (poHere[1] << 16) +
          (poHere[2] << 8) + poHere[3] : 0;
          DNS_DBGP(DNS_DBGLVL_REPETITIVE, " szhost %lx \n", (*ppxReplyList)[i].dwIpAddr);
      }

      poHere += iReadLen;
    }
  }


#if !defined(DNS_INDIRECT)
  ASSERT(pxDnsControlLocal->oDnsRecurse == 1);
#else

  /*poHere now points to authority RR  */
  for (i=0; i<wNumAuth; i++) {
    if (poHere >= poMsgEnd) {
      return DNS_PARSE_ERROR;
    }
    j = GetNameLen(poHere, &iReadLen);
    poHere += ParseHostname(pxDnsControlLocal,poHere, poMsg, &wType);
    poHere += iReadLen;
  }

  /* poHere now points to additional RR  */
  if (wNumAddl) {
    if (DNS_LOOKUP_NAME == eQueryType && DNS_PARSE_ANSWER != nRetval) {
      *ppxReplyList = MALLOC(wNumAddl * sizeof(DNS_PARSE_REPLY));
      ASSERT(*ppxReplyList);
      MOC_MEMSET((ubyte *)*ppxReplyList, 0, wNumAddl *sizeof(DNS_PARSE_REPLY));
      *pwReplyCnt = wNumAddl;
      nRetval = DNS_PARSE_REFERRAL;
    }

    if (DNS_PARSE_REFERRAL == nRetval) {
      for (i = 0; i < wNumAddl; i++) {
        if (poHere >= poMsgEnd) {
          return DNS_PARSE_ERROR;
        }
          j = GetNameLen(poHere, &iReadLen);
          poHere += ParseHostname(pxDnsControlLocal,poHere, poMsg, &wType);
          /*poHere += 10; */
          (*ppxReplyList)[i].szHostname = strdup(pxDnsControlLocal->szHost);
          DNS_DBGP(DNS_DBGLVL_REPETITIVE, "dup3: %p (%d)\n",
                   (*ppxReplyList)[i].szHostname, pthread_self());
          /* should really use centralised endian convertor */
          (*ppxReplyList)[i].dwIpAddr =    (poHere[0] << 24) + (poHere[1] << 16) +
                                        (poHere[2] <<  8) +  poHere[3];

          poHere += iReadLen;
      }
    }
  }
#endif /*#if !defined(DNS_INDIRECT) */

  DNS_DBGP(DNS_DBGLVL_REPETITIVE, " eQueryType %d \n", eQueryType);

  if (wFlags & TC_MASK) {
    pxDnsControlLocal->dwGotTruncated++;
    DNS_DBGP(DNS_DBGLVL_REPETITIVE, "ERROR Flags Truncated %x %ld\n", wFlags,
             pxDnsControlLocal->dwGotTruncated);
  }

  if (DNS_PARSE_NOT_FOUND == nRetval ||
      !(wFlags & (QR_MASK | AA_MASK)) ||  (wFlags &  OPCODE_IQUERY)  ) {
    DNS_DBGP(DNS_DBGLVL_REPETITIVE, " ERROR Flags %x Retv %d \n", wFlags, nRetval);
    return (DNS_PARSE_ERROR);
  } else {
    return nRetval;
  }
}

typedef struct _DnsRecvArg_t {
  OCTET *poReply;
  INT   *iReplyLen;
} DnsRecvArg_t;

void _DnsRcvCb(int lsockfd, void *buff,
        ubyte4 nbytes, struct sockaddr *from, socklen_t addrlen, void *arg)
{
  DnsRecvArg_t          *recvArg = (DnsRecvArg_t *)arg;

  *(recvArg->iReplyLen) = nbytes;
  MOC_MEMCPY((ubyte *)recvArg->poReply,(ubyte *) buff, nbytes);

  /* We have a response */
  DNS_DBGP(DNS_DBGLVL_ERROR_RARE,
    "DnsSendRcv: Reply len = %d (poReply = 0x%lX)\n",
        *(recvArg->iReplyLen), (LONG)recvArg->poReply);
  printf("DnsSendRcv: Reply len = %d (poReply = 0x%lX)\n",
        *(recvArg->iReplyLen), (LONG)recvArg->poReply);
  DNS_DBG(DNS_DBGLVL_REPETITIVE, NetPrintPayload(recvArg->poReply,
        (int)*(recvArg->iReplyLen)));
}


/*
 * DnsSendRcv
 *  Send a DNS message & wait for the response.
 *
 *  Args:
 *   pxDnsControlLocal      DNS control structure reference
 *   poMsg                  Ptr to start of DNS message to send
 *   nLen                   Length of message to send
 *   poReply                Ptr to location to store received packet
 *
 *  Return:
 *   iReplyLen              Length of the reply
 */
INT DnsSendRcv(STRUCTDNSCONTROL   *pxDnsControlLocal,
               OCTET              *poMsg,
               INT                nLen,
               OCTET              *poReply)
{
  WORD                wRetry;
  fd_set              rset;
  struct timeval      xTimeout;
  INT                 iReplyLen;
  DWORD               iDnsSockFd;
  socklen_t           xSockAddrFromLen;
  struct in_addr      xIpAddr;
  struct sockaddr     xSockAddrFrom;
  struct sockaddr_in  xSockAddrInClient,
                      xSockAddrInServ;
  int iRv;
  DnsRecvArg_t          recvArg;


  xSockAddrInServ.sin_family = AF_INET;
  xSockAddrInServ.sin_port = htons(DNS_PORT);
  xIpAddr.s_addr = (in_addr_t)pxDnsControlLocal->dwDomainNameServerIP;
  /*xIpAddr.s_addr = inet_addr("1.1.1.1"); */

#if defined(DNS_INDIRECT)
  if(pxDnsControlLocal->oDnsUseRefServer == 1){
    xIpAddr.s_addr = pxDnsControlLocal->dwDnsRefServer;
    pxDnsControlLocal->oDnsUseRefServer = 0;
  }
#endif
    MOC_MEMCPY((ubyte *)&xSockAddrInServ.sin_addr,
        (ubyte *) &xIpAddr, sizeof(xSockAddrInServ.sin_addr));

  xSockAddrInClient.sin_family = AF_INET;
  xSockAddrInClient.sin_port = 0;
  xIpAddr.s_addr = htonl(INADDR_ANY);
  xSockAddrInClient.sin_addr = xIpAddr;

  iDnsSockFd = socket(AF_INET, SOCK_DGRAM, 0);
  ASSERT(iDnsSockFd >= 0);

  iReplyLen = bind(iDnsSockFd, (struct sockaddr *)&xSockAddrInClient,
                   sizeof(xSockAddrInClient));
  ASSERT(iReplyLen>=0);


  DNS_DBGP(DNS_DBGLVL_NORMAL,
           "DnsSendRcv (%d): Outgoing message to %s (len = %ld):\n", pthread_self(),
           inet_ntoa(((struct sockaddr_in *)&xSockAddrInServ)->sin_addr),
           (ubyte4)nLen);

  DNS_DBG(DNS_DBGLVL_REPETITIVE, NetPrintPayload(poMsg, nLen));
  debugNetPrintPayload(poMsg,nLen);


#ifdef ASYNC_MODEL

  iReplyLen = 0;
  recvArg.poReply = poReply;
  recvArg.iReplyLen = &iReplyLen;

  /* register cb */
  iRv = recvfrom(iDnsSockFd, poReply, DNS_MAX_REPLY_LEN, 0, &xSockAddrFrom,
                         &xSockAddrFromLen, _DnsRcvCb, &recvArg, NULL, NULL);
  ASSERT(iRv != -1);

  for (wRetry=0;
    wRetry < pxDnsControlLocal->xDnsParms.oNumRetries && iReplyLen == 0;
    wRetry++){

#if 0
    iRv = sendto(iDnsSockFd, poMsg, (ubyte4)nLen, 0,
                 (struct sockaddr *)&xSockAddrInServ,sizeof(struct sockaddr));
#else

    iRv = mn_sendto(iDnsSockFd, poMsg, (ubyte4)nLen, 0,
                 (struct sockaddr *)&xSockAddrInServ,sizeof(struct sockaddr));
#endif
    ASSERT(iRv != -1);

    for(iRv=0; iReplyLen == 0 && iRv < 100; iRv++)
    usleep(pxDnsControlLocal->xDnsParms.wSleepTime*1000);
  }

  close(iDnsSockFd);
  return (iReplyLen);

#else

  /* Sometimes it takes a long time to get a response */
  xTimeout.tv_sec = 3;
  xTimeout.tv_usec = (pxDnsControlLocal->xDnsParms.wSleepTime * 1000);

  /* JJ */
  /* Set it to be blocking for now till we fix select SET_FD stuff */
  /*iRv = ioctl(iDnsSockFd, FIONBIO, 1); */
  iRv = 0;
  ASSERT(iRv == 0);

  for (wRetry=0; wRetry < pxDnsControlLocal->xDnsParms.oNumRetries; wRetry++) {

#if 0
    iRv = sendto(iDnsSockFd, poMsg, (ubyte4)nLen, 0,
                 (struct sockaddr *)&xSockAddrInServ,sizeof(struct sockaddr));
#else

    iRv = mn_sendto(iDnsSockFd, poMsg, (ubyte4)nLen, 0,
                 (struct sockaddr *)&xSockAddrInServ,sizeof(struct sockaddr));
#endif
    ASSERT(iRv != -1);

    FD_ZERO(&rset);
    /* JJ  Will get to select later ...  The fd_set ize is becoming a problem  */
    /* as we have put a mask to distingusih the various fd causing the fd to  */
    /* be greater than the default value */
    FD_SET(iDnsSockFd, &rset);

    /* Wait for response */
    iRv = select(iDnsSockFd + 1, &rset, NULL, NULL, &xTimeout);
    ASSERT(iRv != -1);

    iReplyLen = 0;
    if ( iRv > 0 )
        iReplyLen = recvfrom(iDnsSockFd, poReply, DNS_MAX_REPLY_LEN, 0, &xSockAddrFrom,
                         &xSockAddrFromLen, NULL, NULL);

    if (iReplyLen > 0) {
      /* We have a response */
      DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsSendRcv: Reply len = %d (poReply = 0x%lX)\n",
               iReplyLen, (LONG)poReply);
      printf("DnsSendRcv: Reply len = %d (poReply = 0x%lX)\n",
               iReplyLen, (LONG)poReply);
      DNS_DBG(DNS_DBGLVL_REPETITIVE, NetPrintPayload(poReply, (int)iReplyLen));
      close(iDnsSockFd);
      return (iReplyLen);
    }
  } /* for loop, retry some more */

  close(iDnsSockFd);
  ASSERT(wRetry == pxDnsControlLocal->xDnsParms.oNumRetries);
  mn_errno = EDNSNOSRVRESP;
  return NETERR_UNKNOWN;
#endif /* not ASYNC_MODEL */
}



/*
 * DnsGetHostByEither
 *  Performs gethostbyeither on 1 interface
 *
 *  Args:
 *   pxDnsControlLocal      DNS core structure corresponding to the interface
 *   szName                 Domain name from gethostbyname() or gethostbyaddr()
 *   eQueryType             Type of DNS query to perform
 *
 *  Return:
 *   Ptr to struct hostent * to be returned to client
 */
struct hostent *
DnsGetHostByEither(STRUCTDNSCONTROL   *pxDnsControlLocal,
                   OCTET              *szName,
                   ENUM_DNS_LOOKUP    eQueryType)
{
  OCTET           *poDNSMessage, *poDNSReply;   /* Messages to/from Domain Name Server */
  OCTET           *szHostName, *poTmp;
  INT             nDnsReply = 0;
  WORD            i, j, nNameLen;
  INT             nMsgLen;
  DNS_MSG         xDnsMsg;                      /* Message Structure */
  struct hostent  *pxHostEnt = NULL,
                  *pxHostEntRetval = NULL;

  ASSERT(xDNSState.oInitState == DNSINITSTATE_OK);

  /* Return NULL if control structure is not configured */
  if (pxDnsControlLocal == NULL ||
      pxDnsControlLocal->dwDomainNameServerIP == 0) {
    return NULL;
  }

  ASSERT(NULL != szName);

  pxHostEnt = DnsClearHostlist(pxHostEnt, pxDnsControlLocal);
  ASSERT(pxHostEnt != NULL);

  MOC_MEMSET((ubyte *)&xDnsMsg, 0, sizeof(DNS_MSG));

  /********************* Build message *******************/
  xDnsMsg.xDnsHeader.wId = htons(pxDnsControlLocal->wDnsNextId++);
  xDnsMsg.xDnsHeader.wMisc = htons(pxDnsControlLocal->oDnsRecurse ? RD_MASK : 0);
  xDnsMsg.xDnsHeader.wQdCount = htons(1);
  xDnsMsg.xDnsHeader.wAnCount = 0;
  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsGetHostByEither:misc %d \n", xDnsMsg.xDnsHeader.wMisc);
  nNameLen = strlen(szName);
  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsGetHostByEither:name '%s' len:%d\n", szName, nNameLen);
  /* If name doesn't contain any '.', append domain name */
  /* Also check there is a domain name specified or bogus pkt is sent, MikeG */
  if (!strchr(szName, '.') && strlen(pxDnsControlLocal->szDomainName)>0) {
    nNameLen += strlen(pxDnsControlLocal->szDomainName) + 1; /*Length + '.'  */
    szHostName = MALLOC(nNameLen + 1); /*Length + EOS  */
    ASSERT(szHostName);
    MOC_MEMSET((ubyte *)szHostName, 0, nNameLen+1);
    strcpy(szHostName, szName);
    strcat(szHostName, ".");
    strcat(szHostName, pxDnsControlLocal->szDomainName);
  } else {
    szHostName = strdup(szName);
  }

  ASSERT(szHostName);
  xDnsMsg.xDnsQuestion.szDomainName = MALLOC(nNameLen + 2); /*Add count and EOS  */
  ASSERT(xDnsMsg.xDnsQuestion.szDomainName);
  *xDnsMsg.xDnsQuestion.szDomainName = '\0';

  /* Copy inc. +1 so that the NULL terminator gets copied over too! */
  MOC_MEMCPY((ubyte *)(xDnsMsg.xDnsQuestion.szDomainName + 1),
        (ubyte *)szHostName, nNameLen + 1);

  poTmp = xDnsMsg.xDnsQuestion.szDomainName;
  i=1; j=0;

  while (j<nNameLen) {
    if (poTmp[i] != '.') {
      (*poTmp)++;       /* increment count for this label  */
    } else {
      poTmp = &poTmp[i];  /* set pointer to next label  */
      *poTmp = i = 0;
    }
    i++; j++;
  }

  xDnsMsg.xDnsQuestion.wQType  = htons(eQueryType);
  xDnsMsg.xDnsQuestion.wQClass = htons(DNSCLASS_IN);

  nMsgLen = sizeof(DNS_MSG) - sizeof(DNS_RR) - sizeof(OCTET *) + nNameLen + 2;

  /* Now write to the real packet */
  poDNSMessage = MALLOC(nMsgLen);
  ASSERT(poDNSMessage);
  MOC_MEMSET((ubyte *)poDNSMessage, 0, nMsgLen);

  MOC_MEMCPY((ubyte *)poDNSMessage,
        (ubyte *)&xDnsMsg.xDnsHeader, sizeof(DNS_HEADER));
  poTmp = poDNSMessage + sizeof(DNS_HEADER);

  MOC_MEMCPY((ubyte *)poTmp,
        (ubyte *) xDnsMsg.xDnsQuestion.szDomainName, nNameLen + 2);
  poTmp += nNameLen + 2; /* ONLY 1??? as already at next label !!!!!! */

  MOC_MEMCPY((ubyte *)poTmp, (ubyte *)&xDnsMsg.xDnsQuestion.wQType, 2*sizeof(WORD)); /* type & class please */
  /* Make Reply Buffer */
  poDNSReply = MALLOC(DNS_MAX_REPLY_LEN);
  ASSERT(poDNSReply);
  MOC_MEMSET((ubyte *)poDNSReply, 0, DNS_MAX_REPLY_LEN);


  /********************* Send/Receive message *******************/
  {
    OCTET oNumtry = 0;
    BOOL  bOK = FALSE;
    WORD wFlags;
    while (oNumtry++ < 3) {
      nDnsReply = DnsSendRcv(pxDnsControlLocal, poDNSMessage, nMsgLen,
                             poDNSReply);
      /* First, do some rudimentary verification */
      wFlags = (poDNSReply[2] << 8) + poDNSReply[3];

      if ( *((WORD *)poDNSReply) != xDnsMsg.xDnsHeader.wId ||
          !(*((WORD *)(poDNSReply+2)) & QR_MASK)) {
          DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:Dns reply - invalid ID or response bit (%8lX)\n",
                  *((LONG *)poDNSReply));
          bOK = FALSE;
      }
      if (wFlags & RCODE_MASK) {
          bOK = FALSE;
          DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:Response ERROR :RCODE %x \n", (wFlags & RCODE_MASK));
          mn_errno = EDNSILLEGALNAME;
          break;
      }
      if (nDnsReply>0) {
          bOK = TRUE; /* Got a good response */
          break;
      }
    } /* End while */

    if (oNumtry == 3 && bOK == FALSE) {
      DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:Response ERROR: EDNSINVALIDREPLY \n");
      mn_errno = EDNSINVALIDREPLY;
    }
  }


#if defined(DNS_INDIRECT)
  /* Set recurse flag if local server supports recursion */
  if (nDnsReply >= sizeof(DNS_HEADER)) {
    pxDnsControlLocal->oDnsRecurse  =
      ((DNS_MSG *)poDNSReply)->xDnsHeader.wMisc & RA_MASK;
  }
  DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsGetHostByEither:Recursion %d ", pxDnsControlLocal->oDnsRecurse);
#else
  ASSERT(pxDnsControlLocal->oDnsRecurse);
#endif


  /* NOTE: IF nDnsReply < 0 than mn_errno has been set by DnsSendRcv()  */
  {
    DWORD                 *pdwIpAddr = NULL;
    DNS_PARSE_REPLY       *pParseReplyList;
    DNS_PARSE_REPLY_TYPE  eParseReplyType;
    WORD                  nParseReplyNum;

    while (nDnsReply >= 0) {
      /* Parse the reply */
      pParseReplyList = NULL;
      nParseReplyNum  = 0;
      eParseReplyType = DnsParseReply(pxDnsControlLocal,
                                      poDNSReply, nDnsReply,
                                      &pParseReplyList, &nParseReplyNum,
                                      eQueryType);

      DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsGetHostByEither:eParseReplyType %d\n", eParseReplyType);

      switch (eParseReplyType) {

    /***************************************************/
      case DNS_PARSE_ANSWER:
    /***************************************************/
        {
          int k;  /* count of unique aliases */
            int iList[nParseReplyNum];  /* which ones are unique */

      if ( pParseReplyList )
          pxHostEnt->h_name = pParseReplyList[0].szHostname;

          /*Count unique aliases         */
          bzero(iList, nParseReplyNum * sizeof(int));
            DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsGetHostByEither:%d entries\n", nParseReplyNum);
            for (i = 1, k = 0; i < nParseReplyNum; i++) {
              for (j = 0; j < i; j++)
                if (!MOC_STRCMP((sbyte *)pParseReplyList[i].szHostname,
                            (sbyte *)pParseReplyList[j].szHostname))
                    break;
              if (j == i) {
                iList[i]++;
                k++;
              }
          }
          if (DNS_LOOKUP_SRV == eQueryType) {
            k = nParseReplyNum - 1;
          }
            DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsGetHostByEither:%d unique\n", k);
            pxHostEnt->h_aliases = MALLOC((k+1)* sizeof(char *)); /* null terminate the list */
            ASSERT(pxHostEnt->h_aliases);
          MOC_MEMSET((ubyte *)pxHostEnt->h_aliases, 0, (k+1)*sizeof(char *));

            for (i=1, j=0; i < nParseReplyNum; i++) {
            if (iList[i] || DNS_LOOKUP_SRV == eQueryType) {
                pxHostEnt->h_aliases[j++] = pParseReplyList[i].szHostname;
                ASSERT(pParseReplyList[i].szHostname);
              } else {
                FREE(pParseReplyList[i].szHostname);
              }
            }
            pxHostEnt->h_aliases[j] = NULL;
            ASSERT(j == k);
            pxHostEnt->h_addrtype = AF_INET;
            pxHostEnt->h_length = 4;

                /* Count of non-NULL addresses */
            for (i=0, k=0; i < nParseReplyNum; i++) {
            if (pParseReplyList[i].dwIpAddr) {
                k++;  /* k is the count of non-zero addresses  */
              }
            }

            pxHostEnt->h_addr_list = MALLOC((k + 1)*sizeof(DWORD));
            ASSERT(pxHostEnt->h_addr_list);
          MOC_MEMSET((ubyte *)pxHostEnt->h_addr_list, 0, (k+1)*sizeof(DWORD));
            if (k) {
              pdwIpAddr = MALLOC(k*sizeof(DWORD));
              ASSERT(pdwIpAddr);
            MOC_MEMSET((ubyte *)pdwIpAddr, 0, k*sizeof(DWORD));
            }
            /* Copy dwIpAddr so pParseReplyList can be freed */
            for (i = 0, j = 0; i < nParseReplyNum; i++) {
              if (pParseReplyList[i].dwIpAddr) {
                ASSERT(k && pdwIpAddr);
                pdwIpAddr[j] = pParseReplyList[i].dwIpAddr;
                pxHostEnt->h_addr_list[j] = (char *)&pdwIpAddr[j];
                j++;
              }
            }

            pxHostEnt->h_addr_list[j] = NULL;
            ASSERT(j == k);
          FREE(pParseReplyList);
            nDnsReply = -1; /* Terminate the while loop */
            pxHostEntRetval = pxHostEnt;
            break;
        }


      /***************************************************/
      case DNS_PARSE_REFERRAL:
      /***************************************************/
        {
#if defined(DNS_INDIRECT)
            WORD  wReferralCount=0;
            DWORD dwLastServerErr=0;

          nDnsReply = -1;
            wReferralCount++;
            for (j=0; j < pxDnsControlLocal->xDnsParms.oNumRetries; j++) {
              for (i=0; i < nParseReplyNum; i++) {
                if (dwLastServerErr == pParseReplyList[i].dwIpAddr && 0 == j &&
                  nParseReplyNum > 2) {     /* ?????????? */
                DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:Skipping suspected down server %s (%lx)\n",
                                pParseReplyList[i].szHostname,
                                (pParseReplyList[i].dwIpAddr));
                continue;  /* Skip suspected down server */
                }

                xDnsMsg.xDnsHeader.wId = pxDnsControlLocal->wDnsNextId++;
                poDNSMessage[0] = xDnsMsg.xDnsHeader.wId >> 8;
                poDNSMessage[1] = xDnsMsg.xDnsHeader.wId & 0xFF;

                DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:Requerying for %s to referred server %s (%lx)\n",
                             szHostName, pParseReplyList[i].szHostname,
                             (pParseReplyList[i].dwIpAddr));

              pxDnsControlLocal->dwDnsRefServer =
                (DWORD)pParseReplyList[i].dwIpAddr;
              pxDnsControlLocal->oDnsUseRefServer = 1;

                nDnsReply = DnsSendRcv(pxDnsControlLocal,
                                     poDNSMessage, nMsgLen, poDNSReply);
                if (nDnsReply < 0 && EDNSNOSRVRESP == mn_errno) {
                dwLastServerErr = pParseReplyList[i].dwIpAddr;
                continue;
                } else {
                break;
              }
            }
#ifdef DNSDBH_HI
            if (EDNSNOSRVRESP != mn_errno) {
                DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:ERROR\n" );
              }
#endif
              break;
            }

            for (i = 0; i < nParseReplyNum; i++) {
              FREE(pParseReplyList[i].szHostname);
            }
            FREE(pParseReplyList);
            if (++wReferralCount >= DNS_MAX_REFERRALS && nDnsReply > 0) {
              nDnsReply = -1;
              DNS_DBGP(DNS_DBGLVL_REPETITIVE, "DnsGetHostByEither:ERROR\n" );
              mn_errno = EDNSHOSTNOTFOUND;
            }
#endif
          break;
        }


        /***************************************************/
      case DNS_PARSE_QUESTION: /* Inverse query only - unused */
        /***************************************************/
      default:
          {
            DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:Error eParseReplyType %d \n", eParseReplyType);
            if (DNS_PARSE_NOT_FOUND == eParseReplyType) {
              DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:ERROR\n");
              mn_errno = EDNSHOSTNOTFOUND;
            }
            else{
              DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:ERROR\n");
              mn_errno = EDNSPARSEFAILED;
            }
            if (pParseReplyList)
              FREE(pParseReplyList);
            nDnsReply = -1; /* terminate the while loop */
            break;
          }
      } /* End Switch */
    } /* End While */
  }


  /* Free all and return */
  FREE(szHostName);

  FREE(xDnsMsg.xDnsQuestion.szDomainName);

  FREE(poDNSMessage);

  FREE(poDNSReply);

#ifdef DNSDBG_HI
 if(pxHostEntRetval==NULL){
    DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "DnsGetHostByEither:ERROR\n");
  }
#endif

  return pxHostEntRetval;
}


/*
 * gethostbyeither
 *  Common code shared by gethostbyname & gethostbyaddr
 *
 *  Args:
 *   szName                 from gethostbyname() or gethostbyaddr()
 *   eQueryType             Type of query to perform
 *
 *  Return:
 *   Ptr to host entry pxHostEnt to be returned to client
 */
struct hostent *
gethostbyeither(OCTET           *szName,
                ENUM_DNS_LOOKUP eQueryType)
{
  int i;
  struct hostent *pxHostEntRetval = NULL;

  if (NETERR_NOERR != DnsWaitForInit()) {
    mn_errno = EDNSSERVERNOTSET;
    DNS_DBGP(DNS_DBGLVL_ERROR_RARE, "gethostbyeither:Failed mn_errno = %d \n", mn_errno);
    return ((void *)NULL);
  }

  /* Go through the DNS controls, trying to find the answer */

  RTOS_mutexWait((RTOS_MUTEX)&xDnsMutex);

  for (i=0; i<xDNSState.oDnsNum; i++) {
    pxHostEntRetval = DnsGetHostByEither(xDNSState.pxDnsControl + i,
                                         szName, eQueryType);
    if (pxHostEntRetval != NULL)
      break;
  }
  RTOS_mutexRelease((RTOS_MUTEX)&xDnsMutex);

  return pxHostEntRetval;
}

/*
 * DnsFindIfControl
 *  Find Control structure corresponding to interface
 *
 *  Args:
 *   oIfIdx              interface index. Must be != NETIFIDX_ANY
 *
 *  Return:
 *   index or < 0 if failure
 */
SHORT _DnsFindIfControl(OCTET oIfIdx)
{
  OCTET o;

  for (o=0;o< xDNSState.oDnsNum;o++) {
    if (oIfIdx == xDNSState.pxDnsControl[o].oIfIdx) {
      /* it is already there: return: */
      return o;
    }
  }

  return NETERR_UNKNOWN;
}

/*
 * DnsUpdateInformation
 *  Obtain or update DNS information (server and domain name)
 *  for the interface & fill in relavent pxDnsControlLocal structure members
 *
 *  Args:
 *   pxDnsControlLocal      DNS core structure corresponding to the interface
 *
 *  Return:
 *   0 success or < 0 if failure
 */
SHORT DnsUpdateInformation(STRUCTDNSCONTROL  *pxDnsControlLocal)
{
  DWORD               iDNSSocket;
  OCTET               szDomainName[DNS_MAX_NAME_LEN];
  DWORD               dwDnsIp;
  struct ifconf       xIfConf;
  struct ifreq        xIfReq;
  struct sockaddr_in  *pxSockAddr;
  int iRv;
  mnIoctlArgList_t    mnIoctlArgList;

  if (pxDnsControlLocal == NULL ||
      _DnsFindIfControl(pxDnsControlLocal->oIfIdx) < 0) {
    ASSERT(0);
    return NETERR_UNKNOWN;
  }

  DNS_DBGP(DNS_DBGLVL_ERROR_RARE,
           "Updating DNS information for interface %d\n",
       pxDnsControlLocal->oIfIdx);

  /* Creates the DNS socket */
  iDNSSocket=socket(AF_INET, SOCK_DGRAM, 0);

  ASSERT(iDNSSocket > 0);

  xIfReq.ifr_name[0] = pxDnsControlLocal->oIfIdx;

  mnIoctlArgList.ifreq = &xIfReq;
  /* Get the interface Dns server address */
  iRv = ioctl(iDNSSocket, MO_SIOCGIFIDNS, &mnIoctlArgList);
  ASSERT(iRv == 0);
  pxSockAddr = (struct sockaddr_in*)&(xIfReq.ifr_ifru.ifru_addr);
  dwDnsIp = (DWORD)pxSockAddr->sin_addr.s_addr;
  pxDnsControlLocal->dwDomainNameServerIP = dwDnsIp;

  /* Get the interface Domain name */
  if (pxDnsControlLocal->szDomainName) {
      FREE(pxDnsControlLocal->szDomainName);
  }

  /* ifc_buf must be allocated & we set length */
  MOC_MEMSET(&szDomainName[0], 0, DNS_MAX_NAME_LEN);
  xIfConf.ifc_buf = &szDomainName[0];
  xIfConf.ifc_len = DNS_MAX_NAME_LEN - 1;
  mnIoctlArgList.oIfIdx = pxDnsControlLocal->oIfIdx;
  mnIoctlArgList.ifconf = (void *)&xIfConf;
  iRv = ioctl(iDNSSocket, MO_SIOCGIFIDN, &mnIoctlArgList);
  ASSERT(iRv == 0);
  /*  malloc & copy across for req. length only */
  pxDnsControlLocal->szDomainName = strdup(szDomainName);

  iRv = close(iDNSSocket);
  ASSERT(iRv == 0);

  return NETERR_NOERR;
}


/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * DnsInit
 *  Initializes DNS, should be called before DNS is used.
 *
 *  Args:
 *   NONE
 *
 *  Return:
 *   NETERR_NOERR if OK
 *   NETERR_XXX on error
 */
int DnsInit(void)
{
  MOC_MEMSET((ubyte *)&xDNSState, 0x00, sizeof(DNSSTATE));

  return 0;
}

/*
 * DnsMsg
 *  Dns message function
 *
 *  Args:
 *   oMsg              Message code. see DNSMSG_XXX definition
 *   dwData            Interface index cast as a DWORD
 *
 *  Return:
 *   >=0 for success
 */
LONG DnsMsg(OCTET oMsg,DWORD dwData)
{
  STRUCTDNSCONTROL  *pxDnsControlLocal;
  OCTET oIfIdx = (OCTET)dwData;
  int iRv;
  mnIoctlArgList_t mnIoctlArgList;

  RTOS_mutexWait((RTOS_MUTEX)&xDnsMutex);

  switch(oMsg) {
  case DNSMSG_IFENABLE:
    /* Enable DNS on an interface */
    {
      DWORD               iDNSSocket;
      struct ifreq        xIfReq;

      ASSERT(oIfIdx != NETIFIDX_ANY);
      if (_DnsFindIfControl(oIfIdx) >=0) {
        /* Already exists: return */
        RTOS_mutexRelease((RTOS_MUTEX)&xDnsMutex);
        return NETERR_NOERR;
      }

      /* Creates the DNS socket */
      iDNSSocket=socket(AF_INET, SOCK_DGRAM, 0);

      ASSERT(iDNSSocket > 0);
      DNS_DBGP(DNS_DBGLVL_REPETITIVE,
               "DnsInit: opened socket %d \n", iDNSSocket);

      xIfReq.ifr_name[0] = oIfIdx;

      /* This message should only be used when the
         if is up */
       mnIoctlArgList.ifreq = (void *)&xIfReq;
      iRv = ioctl(iDNSSocket, MO_SIOCGIFIFLAG, &mnIoctlArgList);
      ASSERT(iRv == 0);
      if (!((xIfReq.ifr_flags & IFF_UP) &&
            (xIfReq.ifr_flags & IFF_IPUP))) {  /* Link & IP must be up  */
        DNS_DBGP(DNS_DBGLVL_ERROR_RARE,
                 "Interface not up - DnsInit() failed\n");
        RTOS_mutexRelease((RTOS_MUTEX)&xDnsMutex);
        close(iDNSSocket);
        return NETERR_NOERR;
      }

      /* All is correct: add the DNS control structure */

      /* The Control structure does not exist: add it */
    {
        STRUCTDNSCONTROL *pxTempDnsControl;

        pxTempDnsControl = (STRUCTDNSCONTROL *)MALLOC((xDNSState.oDnsNum+1) *sizeof(STRUCTDNSCONTROL));
        ASSERT(pxTempDnsControl);
        MOC_MEMCPY((ubyte *)pxTempDnsControl,
                   (ubyte *)xDNSState.pxDnsControl,
                   xDNSState.oDnsNum*sizeof(STRUCTDNSCONTROL));
        xDNSState.pxDnsControl = pxTempDnsControl;
        xDNSState.oDnsNum++;
    }

      /* points to the newly created control structure */
      pxDnsControlLocal = xDNSState.pxDnsControl + xDNSState.oDnsNum -1;

      MOC_MEMSET((ubyte *)pxDnsControlLocal,0x00,sizeof(STRUCTDNSCONTROL));


      pxDnsControlLocal->oIfIdx = oIfIdx;

      /* Initialize Contrl Variables */
      pxDnsControlLocal->xDnsParms.wRetryInterval = 1000;
      pxDnsControlLocal->xDnsParms.wSleepTime     = 30;
      pxDnsControlLocal->xDnsParms.oNumRetries    = 10;
      pxDnsControlLocal->xDnsParms.oRecurse       = TRUE;

      /* Think about locking here check mg, in a cleaner way yes */

      /* Update Interface DNS interface information */
      DnsUpdateInformation(pxDnsControlLocal);


      if (pxDnsControlLocal->dwDomainNameServerIP == 0) {
        DNS_DBGP(DNS_DBGLVL_ERROR_RARE,
                 "Warning - Domain Name Server not set\n");
      }

      if (strlen(pxDnsControlLocal->szDomainName) == 0) {
        DNS_DBGP(DNS_DBGLVL_ERROR_RARE,
                 "Warning - Domain Name not set\n");
      }


#if !defined(DNS_INDIRECT)
      pxDnsControlLocal->oDnsRecurse = 1;
      /*  server should recurse */
      DNS_DBGP(DNS_DBGLVL_REPETITIVE,
               "Recursion %d\n", pxDnsControlLocal->oDnsRecurse);
#endif
      close(iDNSSocket);
      xDNSState.oInitState = DNSINITSTATE_OK;
    }
  break;

  case DNSMSG_IFDISABLE:
    /* Disable DNS on the interface */
    {
      SHORT sCtrlIdx;
      HOSTENT_LIST *pxHel, *pxHel2;

      sCtrlIdx = _DnsFindIfControl(oIfIdx);
      if (sCtrlIdx < 0) {
        RTOS_mutexRelease((RTOS_MUTEX)&xDnsMutex);
        return NETERR_UNKNOWN;
      }

      /* Free the hostent list */
      pxHel = xDNSState.pxDnsControl[sCtrlIdx].pxHostEntList;
      while (pxHel) {
        pxHel2 = pxHel->pxNext;
        DnsFreeHostEntMembers(&(pxHel->xHostEnt));
        FREE(pxHel);
        pxHel = pxHel2;
      }

      /* Free the domain name */
      ASSERT(xDNSState.pxDnsControl[sCtrlIdx].szDomainName != NULL);
      FREE(xDNSState.pxDnsControl[sCtrlIdx].szDomainName);

      --xDNSState.oDnsNum; /* decrement the number of entry */
      /* Found the control structure */
      if (sCtrlIdx != (xDNSState.oDnsNum)) {
        /* It is not the last entry:
           Copy the last one into the free spot*/
        MOC_MEMCPY((ubyte *)(xDNSState.pxDnsControl + sCtrlIdx),
               (ubyte *)(xDNSState.pxDnsControl + xDNSState.oDnsNum),
               sizeof(STRUCTDNSCONTROL));

      }
#ifdef _PORTABLE_IP_MEM_
      /* Realloc smaller */
      xDNSState.pxDnsControl =
        realloc(xDNSState.pxDnsControl,
                xDNSState.oDnsNum*sizeof(STRUCTDNSCONTROL));
#endif /* _PORTABLE_IP_MEM_ */

      if (xDNSState.oDnsNum == 0) {
        /* No Dns bindings remaining: go back to NONE state */
        xDNSState.oInitState = DNSINITSTATE_NONE;
      }
    }
    break;

  case DNSMSG_IFUPDATE:
    /* Update DNS information for the interface */
    {
      SHORT sCtrlIdx;

      sCtrlIdx = _DnsFindIfControl(oIfIdx);
      if (sCtrlIdx < 0) {
        RTOS_mutexRelease((RTOS_MUTEX)&xDnsMutex);
        return NETERR_UNKNOWN;
      }

      DnsUpdateInformation(&(xDNSState.pxDnsControl[sCtrlIdx]));
    }
    break;
  }

  RTOS_mutexRelease((RTOS_MUTEX)&xDnsMutex);

  return NETERR_NOERR;
}


