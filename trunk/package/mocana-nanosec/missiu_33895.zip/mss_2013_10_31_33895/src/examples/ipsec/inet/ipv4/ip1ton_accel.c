/*
 * ip1ton_accel.c
 *
 * Implements the Ip1toN module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/

#include "ip1ton_defs.h"

/*
 * Ip1toNInstanceRcv
 *  Ip fragmentation Instance Rcv function
 *   Ip fragmentation Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIp1toN                    Ip1toN Instance Handle
 *    hLLIf                      Interface handle
 *    pxPacket                   packet
 *    wOffset                    Ip PDU offset.
 *    hData                      unused
 *
 *   Return:
 *    Number of byte received or -1(error)
 */

LONG Ip1toNInstanceRcv(H_NETINSTANCE hIp1toN,H_NETINTERFACE hLLIf,
                       NETPACKET *pxPacket,NETPACKETACCESS *pxAccess,
                       H_NETDATA hData)
{
  IP1TONSTATE *pxIp1toN = (IP1TONSTATE *)hIp1toN;
  NETPAYLOAD      *pxPayload;
  OCTET           *poPayload;
  WORD            wOffset;
  IPHDR           *pxIpHdr;
  NETWORKID       xNetworkId;
  NETIFID         *pxNetIfId = (NETIFID*)hData;

  IP1TON_CHECK_STATE(pxIp1toN);
  NETPACKET_CHECK(pxPacket);
  ASSERT((pxAccess != NULL) &&
         (pxNetIfId != 0) &&
         ((OCTET)hLLIf <= pxIp1toN->oLLNumberIf) &&
         (pxNetIfId->oIfIdx < IP1TON_MAXIF) &&
         (pxIp1toN->pfnRxCbk != NULL));

  /*Set the NetPayload and the Payload*/
  pxPayload = pxPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  /*Check if the offset is DWORD aligned*/
  if ((pxAccess->wOffset & 0x3) != 0) {
    /* Packet is not aligned: shift it left */
    ASSERT(pxAccess->wOffset > (4 - (pxAccess->wOffset & 0x3)));
    MOC_MEMMOVE((ubyte *)(poPayload + (pxAccess->wOffset & 0xFFFC)),
            (ubyte *)(poPayload + pxAccess->wOffset), pxAccess->wLength);
    pxAccess->wOffset = (pxAccess->wOffset & 0xFFFC);
  }

  ASSERT((pxAccess->wOffset & 0x3) == 0);

  /*Set the offset*/
  wOffset = pxAccess->wOffset;

  /*Set the pointer to the ip header*/
  pxIpHdr = (IPHDR*)(poPayload + wOffset);

  /*fill the NETWORK structure */

  /* MOC_MEMSET((ubyte *)&xNetworkId,0x00,sizeof(NETWORKID)); */ /*Atul- commented for perf */

  xNetworkId.dwSrcAddr = ntohl(pxIpHdr->dwSrcAddr);
  xNetworkId.dwDstAddr = ntohl(pxIpHdr->dwDstAddr);
  xNetworkId.oIpHdrLen = (pxIpHdr->oIpHdrLen & 0x0F)<<2;
  xNetworkId.oVersion  = (pxIpHdr->oVersion);
  xNetworkId.oProtocol = pxIpHdr->oProtocol;
  xNetworkId.wTotalLen = ntohs(pxIpHdr->wTotalLen);
  xNetworkId.oToS = pxIpHdr->oToS;
  xNetworkId.oTtL = pxIpHdr->oTtL;
  xNetworkId.oIfIdx   = pxNetIfId->oIfIdx;
  xNetworkId.wVlan = pxNetIfId->wVlan;

  xNetworkId.bTunnelled = FALSE;

  if(Checksum16((OCTET*)pxIpHdr, xNetworkId.oIpHdrLen) != 0){
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP1TON, INET_DBG_LEVEL_ERROR))
    {
      /*IP1TON_DBGP(ERROR,"Ip1toNInstanceRcv: bad ip checksum\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Ip1toNInstanceRcv: bad ip checksum");
    }
    NETPAYLOAD_DELUSER(pxPayload);
    return -1;

  }

  {
    IPTABLEENTRY xIpEntry;

    xIpEntry.dwAddr = xNetworkId.dwDstAddr;
    xIpEntry.oIfIdx = NETIFIDX_ANY;
    xIpEntry.wDefaultVlan = NETVLAN_ANY;

    xNetworkId.eDstAddrType =
      IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry);
  }

  if( xNetworkId.oIpHdrLen != (OCTET)IPDEFAULT_HDRSIZE){
    xNetworkId.poIpOption = (OCTET*)pxIpHdr + IPDEFAULT_HDRSIZE;
    xNetworkId.oIpOptionLen = xNetworkId.oIpHdrLen - IPDEFAULT_HDRSIZE;
  } else {
    xNetworkId.poIpOption = NULL;
    xNetworkId.oIpOptionLen = 0;
  }

  /* Set the packet priority if it has not been set lower down */
  if (pxAccess->oPriority == (OCTET)LOW_PRIORITY &&
      (xNetworkId.oToS & NETTOS_PRIORITY_MASK)) {
    pxAccess->oPriority = HIGH_PRIORITY;
  }

  /*convert from network to host byte order*/
  xNetworkId.wFragOffset = ntohs(pxIpHdr->wFragOffset);
  xNetworkId.wDatagramId = ntohs(pxIpHdr->wDatagramId);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP1TON, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IP1TON_DBGP(REPETITIVE,
              "Ip1toNRcv:hIp1toN=%d,oIfIdx=%d,Src=%ld.%ld.%ld.%ld,Dst=%ld.%ld.%ld.%ld,DstAddrType=%s,Prot=%s,wOffset=%d,wLength=%d\n",
              (int)hIp1toN,xNetworkId.oIfIdx,
              IPADDRDISPLAY(xNetworkId.dwSrcAddr),
              IPADDRDISPLAY(xNetworkId.dwDstAddr),
              IpAddressTypeToString(xNetworkId.eDstAddrType),
              IpProtoToString(xNetworkId.oProtocol),
              pxAccess->wOffset,pxAccess->wLength);*/
    DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "Ip1toNRcv:hIp1toN=", (int)hIp1toN,
                        ", oIfIdx= ", xNetworkId.oIfIdx);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Src= ", xNetworkId.dwSrcAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Dst= ", xNetworkId.dwDstAddr);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, ", DstAddrType= ", IpAddressTypeToString(xNetworkId.eDstAddrType));
    DEBUG_PRINT2(DEBUG_MOC_IPV4, ", Prot= ", IpProtoToString(xNetworkId.oProtocol));
    DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ", wOffset= ", pxAccess->wOffset, ", wLength= ", pxAccess->wLength);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  return pxIp1toN->pfnRxCbk(pxIp1toN->hULInst,pxIp1toN->hULIf,
                            pxPacket,pxAccess,
                            (H_NETDATA)&xNetworkId);
}

IP1TON_DBG_VAR(DWORD g_dwIp1toNLoopbackPktCnt);

/*
 * Ip1toNInstanceWrite
 *  Ip1toN Instance Write function. Follows PFN_NETWORKWRITE
 *  typedef.
 *
 *  Args:
 *   hIp1toN                    Ip1toN Instance handle
 *   hULIf                      Interface handle
 *   pxPacket                   Packet pointer
 *   wOffset                    Ip PDU offset
 *   hData                      pointer to a NETWORKID structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG Ip1toNInstanceWrite(H_NETINSTANCE hIp1toN,
                         H_NETINTERFACE hULIf,
                         NETPACKET *pxNetPacket,
                         NETPACKETACCESS *pxNetPacketAccess,
                         H_NETDATA hData)
{
  IP1TONSTATE *pxIp1toN = (IP1TONSTATE *)hIp1toN;
  IP1TON_LL *pxLl;
  H_NETINSTANCE hLLInst;
  H_NETINTERFACE hLLIf;
  PFN_NETWRITE  pfnLLWrite;
  NETWORKID *pxNetworkId = (NETWORKID*)hData;
  NETIFID xNetIfId;
  OCTET oIfIdx;
  OCTET oLlIdx;
  NETPAYLOAD *pxPayload;
  OCTET *poPayload;
  IPHDR *pxIpHdr = NULL;

  IP1TON_CHECK_STATE(pxIp1toN);
  NETPACKET_CHECK(pxNetPacket);
  ASSERT(pxNetworkId != NULL);

  pxPayload = pxNetPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  ASSERT( (pxNetPacketAccess->wOffset + pxNetPacketAccess->wLength) <= pxPayload->wSize );

  /* Set the oIfIdx*/
  oIfIdx = pxNetworkId->oIfIdx;
  ASSERT(oIfIdx < IP1TON_MAXIF);
  oLlIdx = pxIp1toN->aIfIdxToLlMap[oIfIdx];

  if (oLlIdx == IP1TONLLIDX_INVALID) {
    /* Dump the packet */
    NETPAYLOAD_DELUSER(pxPayload);
    return pxNetPacketAccess->wLength;
  }

  /* Check that oIfIdx are  of range*/
  ASSERT(pxIp1toN->aIfIdxToLlMap[oIfIdx] < pxIp1toN->oLLNumberIf);

  /*Fill the NETIFID structure*/
  /* MOC_MEMSET((ubyte *)&xNetIfId,0x00,sizeof(NETIFID)); */ /* Atul - Commenting for performance */
  xNetIfId.oIfIdx    = pxNetworkId->oIfIdx;
  xNetIfId.wVlan     = pxNetworkId->wVlan;
  xNetIfId.dwGatewayAddr = pxNetworkId->dwGatewayAddr;
  xNetIfId.dwSrcIpAddr = pxNetworkId->dwSrcAddr;
  xNetIfId.dwDstIpAddr = pxNetworkId->dwDstAddr;
  xNetIfId.eDstAddrType = pxNetworkId->eDstAddrType;

  /*Do we have enough room to write the ip header ?*/
  ASSERT(pxNetPacketAccess->wOffset
         >= IPDEFAULT_HDRSIZE + pxNetworkId->oIpOptionLen);

  /*Modify wOffset and wLength*/
  pxNetPacketAccess->wOffset -=
    (IPDEFAULT_HDRSIZE + pxNetworkId->oIpOptionLen);
  pxNetPacketAccess->wLength +=
    (IPDEFAULT_HDRSIZE + pxNetworkId->oIpOptionLen);

  /*Set the ip header pointer*/
  pxIpHdr = (IPHDR *)(poPayload + pxNetPacketAccess->wOffset);

  /* Check the int alignment. Tx side, that should always be
     true */
  ASSERT( (pxNetPacketAccess->wOffset % sizeof(int)) == 0);

  /*Copy NETWORKID to the payload */

  pxIpHdr->oVersion   = pxNetworkId->oVersion;
  pxIpHdr->oIpHdrLen  = pxNetworkId->oIpHdrLen >> 2;
  pxIpHdr->dwDstAddr  = htonl(pxNetworkId->dwDstAddr);
  pxIpHdr->dwSrcAddr  = htonl(pxNetworkId->dwSrcAddr);
  pxIpHdr->oToS       = pxNetworkId->oToS;
  pxIpHdr->wTotalLen  = MOC_NTOHS((ubyte *)&pxNetworkId->wTotalLen);
  pxIpHdr->wFragOffset= htons(pxNetworkId->wFragOffset);
  pxIpHdr->oTtL       = pxNetworkId->oTtL;
  pxIpHdr->oProtocol  = pxNetworkId->oProtocol;
  pxIpHdr->wDatagramId= htons(pxNetworkId->wDatagramId);

  /*The options start here. */
  if (pxNetworkId->oIpOptionLen != (OCTET)0) {
    ASSERT(pxNetworkId->poIpOption != NULL);
    MOC_MEMCPY((ubyte *)((OCTET*)pxIpHdr + IPDEFAULT_HDRSIZE),
                  (ubyte *)pxNetworkId->poIpOption,
                  (ubyte4)pxNetworkId->oIpOptionLen);
  }

  /*Set the ip checksum*/
  pxIpHdr->wCheck = 0;
  pxIpHdr->wCheck = Checksum16((OCTET*)pxIpHdr,pxNetworkId->oIpHdrLen);

  /* Check whether the packet is being sent to our own IP address */
  if (pxNetworkId->dwDstAddr != pxNetworkId->dwSrcAddr) {
    /* This is the normal case, i.e. it's going somewhere else */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP1TON, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IP1TON_DBGP(REPETITIVE,
                "Ip1toNWrite:hIp1toN=%d,oIfIdx=%d,Src=%ld.%ld.%ld.%ld,Dst=%ld.%ld.%ld.%ld,Prot=%s,wOffset=%d,wLength=%d\n",
                (int)hIp1toN,pxNetworkId->oIfIdx,
                IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
                IPADDRDISPLAY(pxNetworkId->dwDstAddr),
                IpProtoToString(pxNetworkId->oProtocol),
                pxNetPacketAccess->wOffset,pxNetPacketAccess->wLength);*/
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "Ip1toNWrite:hIp1toN=", (int)hIp1toN,
                          ", oIfIdx= ", pxNetworkId->oIfIdx);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Src = ", pxNetworkId->dwSrcAddr);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Dst = ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ",Prot = ", pxNetworkId->oProtocol);
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ", wOffset = ", pxNetPacketAccess->wOffset, ", wLength= ", pxNetPacketAccess->wLength);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }

    /*Set the LL inst, LL if and LL write function*/
    pxLl = pxIp1toN->pxLl + oLlIdx;

    hLLInst    = pxLl->hLLInst;
    hLLIf      = pxLl->hLLIf;
    pfnLLWrite = pxLl->pfnLLWrite;

    ASSERT((pxLl->obUsed == TRUE) &&
           ((int)hLLInst != 0) &&
           ((int)hLLIf != 0) &&
           (pfnLLWrite != NULL));


    return pfnLLWrite(hLLInst,hLLIf,pxNetPacket,pxNetPacketAccess,
                      (H_NETDATA)&xNetIfId);
  }
  else {
    /* This is the hairpin case, send the packet back from whence it came */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP1TON, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IP1TON_DBGP(REPETITIVE,
                "Ip1toNWrite:hIp1toN=%d,oIfIdx=%d,Src=Dst=%ld.%ld.%ld.%ld,Prot=%s,wOffset=%d,wLength=%d\n",
                (int)hIp1toN,pxNetworkId->oIfIdx,
                IPADDRDISPLAY(pxNetworkId->dwDstAddr),
                IpProtoToString(pxNetworkId->oProtocol),
                pxNetPacketAccess->wOffset,pxNetPacketAccess->wLength);*/
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "Ip1toNWrite:hIp1toN= ", (int)hIp1toN,
                          ", oIfIdx= ", pxNetworkId->oIfIdx);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Src=Dst= ", pxNetworkId->dwDstAddr);
      DEBUG_PRINT2(DEBUG_MOC_IPV4, ", Prot = ", (pxNetworkId->oProtocol));
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ", wOffset = ", pxNetPacketAccess->wOffset,
                          ", wLength = ", pxNetPacketAccess->wLength);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }

    pxLl = pxIp1toN->pxLl + oLlIdx;
    hLLIf = pxLl->hLLIf;

    IP1TON_DBG_VAR(g_dwIp1toNLoopbackPktCnt++);
    return Ip1toNInstanceRcv(hIp1toN,hLLIf,pxNetPacket,pxNetPacketAccess,
                    (H_NETDATA)&xNetIfId);
  }
}


