/*
 * ipsec_dbg.h
 *
 * IPSec module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IPSEC_DBG_H_
#define _IPSEC_DBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef IPSECDBG_HI
   #define IPSECDBG_HI
  #endif
 #endif

#else
 #ifdef IPSECDBG_HI
  #undef IPSECDBG_HI
 #endif
#endif

#include "netdbg.h"

#define IPSEC_MAGIC_COOKIE 0x49505365 /*"IPSe" = 0x49505365*/

/*#ifdef IPSECDBG_HI*/
#if defined(IPSECDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define IPSEC_CHECK_STATE(x) \
            ASSERT((x) && ((x)->dwMagicCookie == IPSEC_MAGIC_COOKIE));

  #define IPSEC_SET_COOKIE(x) (x)->dwMagicCookie = IPSEC_MAGIC_COOKIE
  #define IPSEC_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define IPSEC_DBGP(level, fmt, args...) do { \
    if (level <= g_dwIPSecDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define IPSEC_DBG(level, x) do {  \
    if (level <= g_dwIPSecDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define IPSEC_DBG_VAR(x)  x

  #define IPSEC_ASSERT(x) ASSERT(x)

#else
  #define IPSEC_CHECK_STATE(x)
  #define IPSEC_SET_COOKIE(x)
  #define IPSEC_UNSET_COOKIE(x)
  #define IPSEC_DBGP(level, fmt, args...)
  #define IPSEC_DBG(level, x)
  #define IPSEC_DBG_VAR(x)
  #define IPSEC_ASSERT(x)
#endif

IPSEC_DBG_VAR(MOC_EXTERN DWORD g_dwIPSecDebugLevel);

#define ERROR 1
#define NORMAL 2
#define REPETITIVE 3

#endif /* #ifndef _IPSEC_DBG_H_ */
