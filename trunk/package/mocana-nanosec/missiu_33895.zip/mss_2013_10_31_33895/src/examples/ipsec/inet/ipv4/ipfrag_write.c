/*
 * ip_frag_write.c
 *
 * Ip frag Tx function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/

#include "ipfrag_defs.h"
#include "icmp.h"

/*****************************************************************************
 *
 * DEBUG
 *
 *****************************************************************************/

#ifndef NDEBUG
DWORD dbg_dwIpFragTxDFPacketCount = 0;
#endif

#ifdef IPFRAG
#define FRAGMENT_OFFSET_MASK 0x1FF8
#endif

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * IpFragInstanceWrite
 *  IpFragInstance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hIpFrag                   Ip fragmentation Instance handle
 *   hIf                        Upper Layer interface handle
 *   pxPacket                   Packet pointer
 *   wOffset                    IP PDU offset
 *   hData                      pointer to a NETWORKID structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG IpFragInstanceWrite(H_NETINSTANCE    hIpFragInst,
                         H_NETINTERFACE   hULIf,
                         NETPACKET        *pxNetPacket,
                         NETPACKETACCESS  *pxNetPacketAccess,
                         H_NETDATA        hData)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFragInst;
  NETWORKID *pxNetworkId = (NETWORKID *)hData;
  H_NETINTERFACE hLLIf;
  H_NETINSTANCE hLLInst;
  PFN_NETWRITE  pfnLLWrite;
  WORD wIpPayloadLength = pxNetPacketAccess->wLength;
  WORD wIpPayloadMaxLength;
  WORD wBytesWritten = 0;
  LONG lRv;
  OCTET oIfIdx;

  IPFRAG_CHECK_STATE(pxIpFrag);

  ASSERT(((OCTET)hULIf <= pxIpFrag->oULNumberIf) &&
         (pxNetPacketAccess->wOffset > pxNetworkId->oIpHdrLen));
  hLLIf = pxIpFrag->hLLIf;
  hLLInst = pxIpFrag->hLLInst;
  pfnLLWrite = pxIpFrag->pfnLLWrite;
  ASSERT(pfnLLWrite != NULL);

  /*Find the mtu of the LL interface*/
  oIfIdx = pxNetworkId->oIfIdx;
  ASSERT(oIfIdx < MAX_LEG);

  ASSERT(pxIpFrag->awMtu[oIfIdx] > pxNetworkId->oIpHdrLen);
  wIpPayloadMaxLength = pxIpFrag->awMtu[oIfIdx] - pxNetworkId->oIpHdrLen;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IPFRAG_DBGP(REPETITIVE,"IpFragInstanceWrite:packet,oIfDx=%d,length=%d,max length=%d\n",
      oIfIdx,wIpPayloadLength,wIpPayloadMaxLength);*/
    DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "IpFragInstanceWrite:packet,oIfDx = ", oIfIdx, ",  length = ", wIpPayloadLength);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", max length = ", wIpPayloadMaxLength);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  if(wIpPayloadLength <= wIpPayloadMaxLength){
    /*don't need to fragment the packet*/
    ASSERT(pfnLLWrite != NULL);
    lRv = pfnLLWrite(hLLInst,hLLIf,pxNetPacket,pxNetPacketAccess,hData);
    return lRv;
  }


#if 0    /* fragmentation check done in router */
  /*the packet need to be fragmented*/
  /* 1 check the DF bit in the Ip Header is set */
  if ((pxNetworkId->wFragOffset & (WORD)IPFRAGMASK_DF) != (WORD)0x0000) {
    ICMPMSGDATA xIcmpMsgData;

    /*fill the IPFRAGCBKDATA structure*/
    xIcmpMsgData.pxNetPacket       = pxNetPacket;
    xIcmpMsgData.pxNetPacketAccess = pxNetPacketAccess;
    xIcmpMsgData.dwDstAddr         = pxNetworkId->dwSrcAddr;
    xIcmpMsgData.dwSrcAddr         = pxNetworkId->dwDstAddr;
    xIcmpMsgData.wVlan             = pxNetworkId->wVlan;
    xIcmpMsgData.oIfIdx            = pxNetworkId->oIfIdx;

    NETPAYLOAD_ADDUSER(pxNetPacket->pxPayload);

    /*send a ICMP Host Unreachable message to the source address */
    ASSERT(pxIpFrag->pfnNetCbk != NULL);
    pxIpFrag->pfnNetCbk((H_NETINSTANCE)pxIpFrag,(OCTET)IPFRAGCBK_FRAG_NEEDED,(H_NETDATA)&xIcmpMsgData);

    DEBUG(dbg_dwIpFragTxDFPacketCount ++;);
    SNMP(xTcpipData.ipFragFails ++;)
    /*TODO return 0 or -1 ?*/
    return -1;
  }
#endif

  /*the packet needs to be fragmented and can be fragmented*/

  ASSERT(wIpPayloadLength > wIpPayloadMaxLength);

  while( wBytesWritten < wIpPayloadLength ){
    NETPACKET xNetPacket;
    NETPACKETACCESS xNetPacketAccess;
    NETWORKID xNetworkId;
    OCTET *poPayload;
    WORD wFragLength,wNetPayloadLength;

    /*copy the NETPACKET*/
    MOC_MEMCPY((ubyte *)&xNetPacket,
                  (ubyte *)pxNetPacket,
                  sizeof(NETPACKET));



    /*set the datagram length*/
    wFragLength = (wIpPayloadLength - wBytesWritten > wIpPayloadMaxLength) ?
                      (wIpPayloadMaxLength & FRAGMENT_OFFSET_MASK) : (wIpPayloadLength - wBytesWritten);

    /*set the payload length*/
    wNetPayloadLength = pxIpFrag->wOffset + pxNetworkId->oIpHdrLen + wFragLength + pxIpFrag->wTrailer;

    /*Allocate memory for the payload*/
    poPayload = NetMalloc((ubyte4)wNetPayloadLength);

    /*create and set the payload*/
    /*TODO which mutex to use*/
    NETPAYLOAD_CREATE(&xNetPacket.pxPayload,
                      NetFree,
                      pxIpFrag->pxMutex,
                      poPayload,
                      wNetPayloadLength);
    if(NULL == xNetPacket.pxPayload)
    {
        lRv = NETERR_MEM;
        DEBUG_ERROR(DEBUG_MOC_IPV4, "Error:IpFragInstanceWrite - NETPAYLOAD_CREATE failed : %d",lRv);
        NetFree(poPayload);
        return lRv;
    }

    /*Fill the NETPACKETACCESS structure*/
    xNetPacketAccess.wOffset = pxIpFrag->wOffset;
    xNetPacketAccess.wLength = wFragLength;

    /*set the NETWORKID structure*/
   MOC_MEMCPY((ubyte *)&xNetworkId,
                  (ubyte *)pxNetworkId,
                  sizeof(NETWORKID));

    /*copy the ip payload*/
    MOC_MEMCPY((ubyte *)(xNetPacket.pxPayload->poPayload + xNetPacketAccess.wOffset),
                  (ubyte *)(pxNetPacket->pxPayload->poPayload + pxNetPacketAccess->wOffset + wBytesWritten),
                  (ubyte4)(wFragLength));

    /*Update the ip header*/
    xNetworkId.wTotalLen = wFragLength + pxNetworkId->oIpHdrLen;
    xNetworkId.wDatagramId = pxIpFrag->wDatagramId;

    if((wBytesWritten + wFragLength) < pxNetPacketAccess->wLength){
      /*It's not the last packet of the datagram*/
      /*xNetworkId.wFragOffset = (WORD)htons(IPFRAGMASK_MF | (IPFRAGMASK_OFFSET & wBytesWritten>>3));*/
      xNetworkId.wFragOffset = (WORD)(IPFRAGMASK_MF | (IPFRAGMASK_OFFSET & wBytesWritten>>3));
    } else {
      /*This is the last packet of the datagram*/
      /*xNetworkId.wFragOffset = (WORD)htons(IPFRAGMASK_OFFSET & wBytesWritten>>3);*/
      xNetworkId.wFragOffset = (WORD)(IPFRAGMASK_OFFSET & wBytesWritten>>3);
      /*Increment the datagram Id*/
      pxIpFrag->wDatagramId++;
    }

    SNMP(xTcpipData.ipFragCreates++);

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_REPETITIVE))
    {
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "IpFragInstanceWrite: fragment packet, with dgramId = ", xNetworkId.wDatagramId, ", dgramOffset = ", xNetworkId.wFragOffset);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", fragment length = ", wFragLength);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }

    /*Write the packet to the LL interface*/
    lRv = pfnLLWrite(hLLInst,hLLIf,&xNetPacket,&xNetPacketAccess,(H_NETDATA)&xNetworkId);

    wBytesWritten += wFragLength;

  }

  SNMP(xTcpipData.ipFragOKs++);

  NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);
  return (LONG)wIpPayloadLength;
}


