/*
 * gethostbyname.c
 *
 * Function of Domain Name Server client
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "NNstyle.h"
#include "dns_flavor.h"
#include "../include/ioctl.h"
#include "../include/socket_inet.h"
#include "../include/socket.h" /* sockaddr */
#include "../include/in.h" /* sockaddr_in */
#include "nettime.h"
#include "../include/netselect.h" /* FD_xxx */
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdb.h"
#include "sockapi.h"
#include "dnsdbg.h"
#include "dnsapi.h"
#include "dns.h"

/*
 * gethostbyname
 *  standard API DNS resolver function - see man
 *  page for complete description
 *
 *  Args:
 *   name                      pointer to name to resolve
 *
 *  Return:
 *   struct hostent * (see netdb.h or man page)
 */
struct hostent * mn_gethostbyname(char *szName)
{
  int iIdx;
  struct sockaddr_in xSockAddr;
  DWORD dwTmpIP;

  if(szName != NULL){
#ifdef _ENABLE_DNS_
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_DNS, NORMAL))
    {
        DEBUG_PRINT(DEBUG_MOC_IPV4,"gethostbyname: ");
        DEBUG_PRINT(DEBUG_MOC_IPV4,szName);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
    }
#endif /* _ENABLE_DNS_ */
    iIdx = inet_pton(AF_INET, szName, &xSockAddr.sin_addr);
    if (iIdx !=0) {
      dwTmpIP = (DWORD)xSockAddr.sin_addr.s_addr;
#ifdef _ENABLE_DNS_
      if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_DNS, NORMAL))
      {
          DEBUG_PRINT(DEBUG_MOC_IPV4,"gethostbyname:  returns ");
          DEBUG_ASCIPADDR(DEBUG_MOC_IPV4,dwTmpIP);
          DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4," ret= ", iIdx);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
      }
#endif /* _ENABLE_DNS_ */
      return (gethostbyaddr((char *)&dwTmpIP, 4, AF_INET));
    } else {
#ifdef _ENABLE_DNS_
      return (gethostbyeither(szName, DNS_LOOKUP_NAME));
#else
      return NULL;
#endif /* _ENABLE_DNS_ */
    }
  } else {
    ASSERT(0);
    return NULL;
  }
}

