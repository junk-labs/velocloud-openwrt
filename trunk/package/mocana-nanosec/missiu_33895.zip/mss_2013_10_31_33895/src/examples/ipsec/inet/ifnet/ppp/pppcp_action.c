 /*
 * pppcp_action.c
 *
 * PPPCP action functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "pppcp_defs.h"

/*
 * PppCpInstanceActionTlu
 *   Action This-Layer-Up (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionTlu(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT(pxCpState != NULL);
  ASSERT(pxCpState->pfnNetCbk != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionTlu:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  return (pxCpState->pfnNetCbk(pxCpState->hNetInst,NETCBK_TLU,(H_NETDATA)0));
}

/*
 * PppCpInstanceActionTld
 *   Action This-Layer-Down (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionTld(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT((pxCpState != NULL) &&
         (pxCpState->pfnNetCbk != NULL) &&
         (pxEvent != NULL));

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionTld:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  return (pxCpState->pfnNetCbk(pxCpState->hNetInst,NETCBK_TLD,pxEvent->hData));
}

/*
 * PppCpInstanceActionTls
 *   Action This-Layer-Started (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionTls(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT(pxCpState != NULL);
  ASSERT(pxCpState->pfnNetCbk != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionTls:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  return (pxCpState->pfnNetCbk(pxCpState->hNetInst,NETCBK_TLS,(H_NETDATA)0));
}

/*
 * PppCpInstanceActionTlf
 *   Action This-Layer-Finished (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionTlf(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT(pxCpState != NULL);
  ASSERT(pxCpState->pfnNetCbk != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionTlf:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  return (pxCpState->pfnNetCbk(pxCpState->hNetInst,NETCBK_TLF,pxEvent->hData));
}

/*
 * PppCpInstanceActionIrc
 *   Action Initialize-Restart-Counter (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionIrc(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT(pxCpState != NULL);
  ASSERT(pxEvent != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionIrc:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  if ((pxEvent->eType == PPPCPADMINEVENT_UP) ||
      (pxEvent->eType == PPPCPADMINEVENT_OPEN) ||
      (pxEvent->eType == PPPCPPARSEEVENT_RCRPLUS) ||
      (pxEvent->eType == PPPCPPARSEEVENT_RCRMINUS) ||
      (pxEvent->eType == PPPCPPARSEEVENT_RCA) ||
      (pxEvent->eType == PPPCPPARSEEVENT_RCN)) {
    pxCpState->dwCounter = pxCpState->oMaxConfigure;
  }
  else if ((pxEvent->eType == PPPCPADMINEVENT_CLOSE) ||
           (pxEvent->eType == PPPCPPARSEEVENT_RXJMINUS)) {
    pxCpState->dwCounter = pxCpState->oMaxTerminate;
  } else {
    ASSERT(0);
  }

  return 0;
}

/*
 * PppCpInstanceActionZrc
 *   Action Zero-Restart-Counter (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionZrc(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT(pxCpState != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionZrc:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  PppCpInstanceTimerReset(hPppCp);

  pxCpState->dwCounter = 0;

  return 0;
}

/*
 * PppCpInstanceActionScr
 *   Action Send-Configure-Request (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionScr(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT(pxCpState != NULL);
  ASSERT(pxEvent != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionScr:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  if (pxCpState->dwCounter > 0) {
    if (pxEvent->eType != PPPCPADMINEVENT_TOPLUS) {
      PPPCPOPTIONFIELDS xFields;
      /* Change the ID & get the latest options
         if it is not a retransmission */

      memset (&xFields,0x00,sizeof(PPPCPOPTIONFIELDS));

      if (pxCpState->poCurrOptions != NULL) {
        free(pxCpState->poCurrOptions);
      }
      ASSERT(pxCpState->pfnNetCbk != NULL);
      pxCpState->pfnNetCbk(pxCpState->hNetInst,PPPCPCBK_OPTIONCODE,
                           (H_NETDATA)&xFields);
      pxCpState->poCurrOptions = xFields.poReq;
      pxCpState->wCurrOptionsLength = xFields.wReqLength;

      pxCpState->aoCurrSndId[PPPCPCOMMAND_CONFIGUREREQUEST -
                            PPPCPCOMMAND_CONFIGUREREQUEST] ++;
    }


    pxCpState->dwCounter --;

    PppCpInstanceSendCommand(hPppCp,PPPCPCOMMAND_CONFIGUREREQUEST,
                             pxCpState->poCurrOptions,
                             pxCpState->wCurrOptionsLength);

    PppCpInstanceTimerReset(hPppCp);
  }
  return 0;
}

/*
 * PppCpInstanceActionSer
 *   Action Send-Echo-Request (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionSer(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  PPPCPOPTIONFIELDS xFields;

  ASSERT(pxCpState != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionSer:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  memset (&xFields,0x00,sizeof(PPPCPOPTIONFIELDS));

  if (pxCpState->poCurrOptions != NULL) {
    free(pxCpState->poCurrOptions);
  }
  ASSERT(pxCpState->pfnNetCbk != NULL);
  pxCpState->pfnNetCbk(pxCpState->hNetInst,PPPCPCBK_OPTIONCODE,
                       (H_NETDATA)&xFields);
  pxCpState->poCurrOptions = xFields.poReq;
  pxCpState->wCurrOptionsLength = xFields.wReqLength;

  pxCpState->aoCurrSndId[PPPCPCOMMAND_ECHOREQUEST -
                        PPPCPCOMMAND_CONFIGUREREQUEST] ++;


  PppCpInstanceSendCommand(hPppCp,PPPCPCOMMAND_ECHOREQUEST,
                         pxCpState->poCurrOptions,
                         pxCpState->wCurrOptionsLength);

  return 0;
}


/*
 * PppCpInstanceActionSca
 *   Action Send-Configure-Ack (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionSca(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  PPPCPOPTIONFIELDS *pxData;

  ASSERT(pxCpState != NULL);
  ASSERT(pxEvent != NULL);
  ASSERT(pxEvent->eType == PPPCPPARSEEVENT_RCRPLUS);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionSca:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  pxData = (PPPCPOPTIONFIELDS *) pxEvent->hData;
  ASSERT(pxData != NULL);


  /* Set the ID */
  pxCpState->aoCurrSndId[PPPCPCOMMAND_CONFIGUREACK -
                         PPPCPCOMMAND_CONFIGUREREQUEST] =
    pxCpState->aoCurrRcvId[PPPCPCOMMAND_CONFIGUREREQUEST -
                           PPPCPCOMMAND_CONFIGUREREQUEST];

  PppCpInstanceSendCommand(hPppCp,PPPCPCOMMAND_CONFIGUREACK,
                           pxData->poReq,
                           pxData->wReqLength);

  return 0;
}

/*
 * PppCpInstanceActionScn
 *   Action Send-Configure-Nak (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionScn(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  PPPCPOPTIONFIELDS *pxData;

  ASSERT(pxCpState != NULL);

  ASSERT(pxEvent != NULL);
  ASSERT(pxEvent->eType == PPPCPPARSEEVENT_RCRMINUS);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionScn:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);

  pxData = (PPPCPOPTIONFIELDS *)pxEvent->hData;
  ASSERT(pxData != NULL);

  if (pxData->wNakLength > 0) {
    /* Nak */
    /* Set the ID */
    pxCpState->aoCurrSndId[PPPCPCOMMAND_CONFIGURENAK -
                             PPPCPCOMMAND_CONFIGUREREQUEST] =
      pxCpState->aoCurrRcvId[PPPCPCOMMAND_CONFIGUREREQUEST -
                               PPPCPCOMMAND_CONFIGUREREQUEST];

    PppCpInstanceSendCommand(hPppCp,PPPCPCOMMAND_CONFIGURENAK,
                             pxData->poNak,
                             pxData->wNakLength);

  }

  if (pxData->wRejLength > 0) {
    /* Reject */
    pxCpState->aoCurrSndId[PPPCPCOMMAND_CONFIGUREREJECT -
                           PPPCPCOMMAND_CONFIGUREREQUEST] =
      pxCpState->aoCurrRcvId[PPPCPCOMMAND_CONFIGUREREQUEST -
                             PPPCPCOMMAND_CONFIGUREREQUEST];

    PppCpInstanceSendCommand(hPppCp,PPPCPCOMMAND_CONFIGUREREJECT,
                             pxData->poRej,
                             pxData->wRejLength);

  }

  return 0;
}

/*
 * PppCpInstanceActionStr
 *   Action Send-Terminate-Request (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionStr(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT(pxCpState != NULL);
  ASSERT(pxEvent != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionStr:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);


  if (pxCpState->dwCounter > 0) {
    /* Change the ID first if it is not a retransmission */
    if (pxEvent->eType != PPPCPADMINEVENT_TOPLUS) {
      pxCpState->aoCurrSndId[PPPCPCOMMAND_TERMINATEREQUEST -
                            PPPCPCOMMAND_CONFIGUREREQUEST] ++;
    }

    pxCpState->dwCounter --;

    PppCpInstanceSendCommand(hPppCp,PPPCPCOMMAND_TERMINATEREQUEST,
                             NULL,
                             0);

    PppCpInstanceTimerReset(hPppCp);

  }

  return 0;

}

/*
 * PppCpInstanceActionSta
 *   Action Send-Terminate-Ack (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionSta(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  ASSERT(pxCpState != NULL);
  ASSERT(pxEvent != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionSta:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);


  if (pxEvent->eType == PPPCPPARSEEVENT_RTR) {
    pxCpState->aoCurrSndId[PPPCPCOMMAND_TERMINATEACK -
                             PPPCPCOMMAND_CONFIGUREREQUEST] =
      pxCpState->aoCurrRcvId[PPPCPCOMMAND_TERMINATEREQUEST -
                            PPPCPCOMMAND_CONFIGUREREQUEST];
  }
  else {
    /* This only happen after reception of a CONFIGURE-REQUEST */
    pxCpState->aoCurrSndId[PPPCPCOMMAND_TERMINATEACK -
                             PPPCPCOMMAND_CONFIGUREREQUEST] =
      pxCpState->aoCurrRcvId[PPPCPCOMMAND_CONFIGUREREQUEST -
                               PPPCPCOMMAND_CONFIGUREREQUEST];
  }


  PppCpInstanceSendCommand(hPppCp,PPPCPCOMMAND_TERMINATEACK,
                           NULL,
                           0);

  return 0;
}

/*
 * PppCpInstanceActionScj
 *   Action Send-Code-Reject (see RFC 1661 for definition)
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionScj(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  PPPCPPACKET *pxData;

  ASSERT(pxCpState != NULL);
  ASSERT(pxEvent != NULL);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionScj:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);


  pxData =  (PPPCPPACKET *)pxEvent->hData;

  ASSERT(pxData != NULL);

  /* Increment the Identifier */
  pxCpState->aoCurrSndId[PPPCPCOMMAND_CODEREJECT -
                         PPPCPCOMMAND_CONFIGUREREQUEST] ++;

  NETPAYLOAD_LOCK(pxData->pxPacket->pxPayload);
  PppCpInstanceSendCommand(hPppCp,PPPCPCOMMAND_CODEREJECT,
                           pxData->pxPacket->pxPayload->poPayload +
                           pxData->pxAccess->wOffset,
                           pxData->pxAccess->wLength);
  NETPAYLOAD_UNLOCK(pxData->pxPacket->pxPayload);

  return 0;
}

/* PppCpInstanceActionRestartOption
 *   Implement the Restart option defined in RFC 1661
 *
 *   Args:
 *     hPppCp               instance handle
 *     pxEvent              event which caused the action
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionRestartOption(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPEVENT xEvent = {PPPCPADMINEVENT_DOWN,0};

  ASSERT(hPppCp != 0);

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionRestartOption:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);


  PppCpInstanceEvent(hPppCp,&(xEvent));

  xEvent.eType = PPPCPADMINEVENT_UP;

  PppCpInstanceEvent(hPppCp,&(xEvent));

  return 0;
}

/*
 * PppCpInstanceActionTimerDisable
 *   Disable Timer processing
 *
 *   Args:
 *     hPppCp         instance handle
 *     pxEvent        Event, ignored
 *   Return:
 *     >=0
 */
LONG PppCpInstanceActionTimerDisable(H_NETINSTANCE hPppCp,PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  PPPCP_DBGP(NORMAL,"PppCpInstanceActionTimerDisable:hPppCp=%d,event=%s\n",
             (int)hPppCp,apoPppCpEventString[pxEvent->eType]);
  pxCpState->bTimer = FALSE;


  return 0;
}
