#ifndef ETHDRV_PVT_H
#define ETHDRV_PVT_H
#include "ethdrv_flavor.h"

typedef enum ethDrvState {
    ETH_DRV_STATE_CLOSED,
    ETH_DRV_STATE_OPEN

}EthDrvState;


typedef struct EthDrvCB {
    int index ;
    int iFd;
    EthDrvState iState;
    char iName[32];
    char myMacaddr[ETH_ALEN];
    char intfName[32];

} EthDrvCB;

#define ERR_SOCKET_OPEN -1001
#define ERR_SOCKET_BIND -1002
#define ERR_SOCKET_IOCTL -1003

/*------------------------------------------------------------------*/
/* Max Number of Intf */
MOC_EXTERN int ethDrvNumIntf;
MOC_EXTERN EthDrvCB ethDrvCB[ETHDRV_MAXNUM_IF];

int _EthDrvFns_open(EthDrvCB * ethDrv);
int _EthDrvFns_close(int iFd);
int _EthDrvFns_read(int ifd,char * frame, int nbytes );
int _EthDrvFns_select(int ifd, long secs, long usecs);
int _EthDrvFns_write(int lSockfd, void *buff, size_t nbytes);
#endif
