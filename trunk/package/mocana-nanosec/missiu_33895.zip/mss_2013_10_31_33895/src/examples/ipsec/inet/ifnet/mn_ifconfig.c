/*
 * mn_ifconfig.c
 *
 * INET Interface Configuration example
 *
 * Copyright Mocana Corp 2003-2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include <NNstyle.h>
#include "dllist.h"
#include "ethbridge_flavor.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "ethernet.h"
#include "../include/sockio.h"
#include "../include/if_dl.h"
#include "../include/socket_inet.h"
#include "../common/netdefs.h"

#include "netcfg.h"
#include "mn_ndi.h"
#include "mn_ifconfig.h"

MSTATUS
mn_ifconfig(struct ifreq *pIfReq, int configFlags)
{
    ubyte4 iRv=0;
    ubyte2 deviceInstanceIndex;

    ASSERT(pIfReq);
    ASSERT(pIfReq->ifr_name[0] < xNetWrapper.oIfNumber);

    deviceInstanceIndex = pIfReq->ifr_name[0];
    switch(configFlags)
    {
        case MN_IF_IPADDR:
        {
             iRv = MN_NDI_deviceInstanceParams(deviceInstanceIndex,
                    MO_SIOCSIFIADDR,pIfReq);
             break;
        }
        case MN_IF_NETMASK:
        {
             iRv = MN_NDI_deviceInstanceParams(deviceInstanceIndex,
                    MO_SIOCSIFINETMASK,pIfReq);
             break;
        }
        case MN_IF_GWADDR:
        {
             iRv = MN_NDI_deviceInstanceParams(deviceInstanceIndex,
                    MO_SIOCSIFIGWADDR,pIfReq);
             break;
        }
        case MN_IF_BRDADDR:
        {
             iRv = MN_NDI_deviceInstanceParams(deviceInstanceIndex,
                    MO_SIOCSIFIBRDADDR,pIfReq);
             break;
        }
        case MN_IF_STATE:
        {
             int evtFlags;
             if(pIfReq->ifr_flags == MN_IFF_UP)
                 evtFlags = evtFlags | MN_DEV_INSTANCE_EVENT_IFUP;
             else
                evtFlags = evtFlags | MN_DEV_INSTANCE_EVENT_IFDOWN;

             MN_NDI_postDeviceInstanceEvent(pIfReq->ifr_name[0], evtFlags);
             break;
        }
        default :
           break;
    }
    return OK;
}

