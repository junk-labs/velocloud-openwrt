/*
 * arpdefs.h
 *
 * ARP internal definitions etc
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ARPDEFS_H_
#define _ARPDEFS_H_

#include "NNstyle.h"
#include "arp_flavor.h"
#include "../include/socket.h"
#include "../include/in.h" /* For ntohx etc defintions on Linux*/
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "netutils.h"
#include "nettime.h"
#include "arp.h"
#include "arpdbg.h"
#include "netsnmp.h"
#include "snmp_tcpip_data.h"
#include "ethernet.h"

/*****************************************************************************
 *
 * Constants
 *
 *****************************************************************************/
#define ARPPACKET_MINSIZE  28
/*****************************************************************************
 *
 * structures
 *
 *****************************************************************************/


#ifdef ARP_REQ_ON_TIMEOUT
typedef enum {
  ARPENTRY_REFRESHED,
  ARPENTRY_READ,
  ARPENTRY_REACQUIRE
} ArpUpdateState;
#endif

/*
 * ARP entry structure
 */
typedef struct arp_entry_state {
  struct arp_entry_state *pxNext; /* Must be first */
  DWORD    dwLastUsed;
#ifdef ARP_REQ_ON_TIMEOUT
  ArpUpdateState eState;
#endif
  ARPENTRY xEntry;
} ARPENTRYSTATE;


/*
 * ARP instance main structure
 */
typedef struct {
  /* Basic structure override protection */
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif
  WORD wOffset;
  WORD wTrailer;

  H_NETINSTANCE hLL;
  PFN_NETWRITE  pfnLLWrite;
  H_NETINTERFACE hLLIf;
  H_NETINTERFACE hRarpLLIf;

  /* Eth data */
  OCTET aaoIfEthAddr[ARPMAX_IFNUM][ARP_ETHLEN];
  OCTET aoBcastEthAddr[ARP_ETHLEN];

  OCTET aoArpHeader[ARP_HRDLEN];

  PFN_NETCBK pfnNetCbk;
  H_NETINSTANCE hNetCbk;

  PFN_NETFREE pfnFree;
  PFN_NETMALLOC pfnMalloc;
  RTOS_MUTEX pxMutex;

  DLLIST dllPending;

  /* Arp Cache */
#ifdef ARP_CACHE_32
  OCTET oArpHashSize;
  OCTET oArpTableSize;
  ARPENTRYSTATE *pxArpTable;
  ARPENTRYSTATE *pxFirstFreeArpEntry;
#else
  WORD wArpHashSize;
#endif
  ARPENTRYSTATE **apxArpHashTable;
  /*Arp last refresh time*/
  DWORD dwLastArpRefreshTime;
#ifdef ARP_TIME_RETRY
  /*Arp pendnig list retry time*/
  DWORD dwArpRetryTime;
  /*Last time when Arp retry was tried for*/
  DWORD dwArpLastRetryTime;
#endif
} ARPSTATE;

/*
 * ARP Pending structure.
 * Details of ARP requests sent and are still pending replies
 * - used as a dllPending DLL item
 */
typedef struct {
  ARPREQUEST xRequest;
  DWORD dwOriginalIpAddr;
  DWORD dwTime;
  OCTET oTries;
} ARPPEND;

#ifdef __MOC_CLI__
typedef struct
{
  ubyte *poSbuf;
  ubyte4 dwSbufLen;
} ARPCLIGET;
#endif

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

#define ARPTRIES_MAX          5                    /* Send a maximum of 5 requests */
#define ARPTIME_RETRY         1000                 /* Send an arp request every 1 second */
#define ARPTIME_MAXAGE        180000               /* Delete an entry if its age >= configured time. Value is in seconds
                                                    * and is configured to a high value.*/
#define ARPTIME_REFRESHTABLE  (ARPTIME_MAXAGE)/3   /* Refresh the arp table every 1/3 * (ARPTIME_MAXAGE) value */

#define ARPTIME_MAXPROCESS    1000                 /* Used in the process routine to determin
                                                    * the maximum time between arp process calls */
#define ARPTIME_MINPROCESS    5                    /* Same as above only minimum */

#define ARP_MAX_PENDING_ITEMS 20                   /* Maximum number of pending arp requests
                                                    * awaiting replies */

/*****************************************************************************
 *
 * function prototypes
 *
 *****************************************************************************/

/*

 *  Find an ARP mapping in the cache. If not found, post a REQUEST.
 *
 *  param:  pxArpEntry  - Arp Entry to look for. The aoEthAddr will
 *                        be filled up
 *        bCheckTimeout - include a check for a timed out ARP entry
 *
 *    ret:  0        - address found = sucessful
 *          1        - address not found
 */
INT ArpFind(ARPSTATE *pxArp, ARPENTRY *pxArpEntry, BOOL bCheckTimeout);


/*
 * ArpAdd
 *  Add an entry to the ARP cache.  Check for dupes!
 *
 *  Arg:
 *       pxArp            Arp state pointer
 *       pxArpEntry       Arp entry to add
 *
 *  Return:
 */
void ArpAdd(ARPSTATE *pxArp,ARPENTRY *pxArpEntry);

/***************************************************************************
* ArpEntryMatch
*
* Procedure keeps logic for checking for ARP entry match in one place
*
*       par:    pxArpEntry       entry to be checked for a match
*               dwAddr           IP address to look for
*               oIfIdx           interface index
*               wVlan            Vlan
*
*       ret:    TRUE if match
****************************************************************************/
BOOL ArpEntryMatch(ARPENTRY *pxArpEntry, DWORD dwAddr,OCTET oIfIdx,
                      WORD wVlan);

/***************************************************************************
* ArpLookup
*
*       This will find an entry in the ARP table by looking at the IP address.
*
*       par:    dwAddr           IP address to look for
*               oIfIdx           interface index
*               wVlan            Vlan
*
*       ret:    ptr tor the arp entry
*       Note:   We allow ourselves to be ARPed to allow loopback to work.
****************************************************************************/
ARPENTRYSTATE *ArpLookup(ARPSTATE *pxArp, DWORD dwAddr,OCTET oIfIdx,WORD wVlan);

#ifdef ARP_REQ_ON_TIMEOUT
/***************************************************************************
* ArpDeleteIfExist
*
*  delete an entry from the arp table if it exists
*
*  param:  pxArpEntry  - Arp Entry to be deleted if exists.
*
*  ret: void
****************************************************************************/
void ArpDeleteIfExist(ARPSTATE *pxArp, ARPENTRY *pxArpEntry);
#endif

/*
 * ArpCreate
 *  Create an ARP entry.  The caller should check for duplicates!
 *
 *  Args:
 *   dwIpAddr   IP address
 *   aoEthAddr  MAC addr
 *   oIfIdx     interface index
 *   wVlan      coresponding Vlan
 *   eArpFlag   Indicates the flag i.e: Local, Dynamic, Static OR Broadcast.
 *
 *  Return:
 *   ARPENTRYSSTATE *created
 */
ARPENTRYSTATE *ArpCreate(ARPSTATE *pxArp, DWORD paddr, OCTET *addr,
                         OCTET oIfIdx, WORD wVlan, ARPENTRYFLAG eArpFlag); /*Ajit: Code Changed, defn of func*/

void ArpRefreshTable(ARPSTATE *pxArp);

#ifdef __MOC_CLI__
/*
 * ArpPrintTableforCli
 * Function fills ip all the entires within the arp table into
 * a format understood by the CLI module (fills contents within the buffer)
 * Input:
 * pxArpState : holds the ARPSTATE instance.
 * poCliBuff : buffer passed by the CLI module, into which ARP module fills in the values.
 * Return:
 * returns the number of bytes written within ppoCliBuff
 */
ubyte4 ArpPrintTableforCli(ARPSTATE *pxArpState, ubyte *poCliBuff);
#endif

/* Debug functions */
#ifndef NDEBUG
void dbgArpPrintTable(ARPSTATE *pxArp);
void dbgArpPrintHash(ARPSTATE *pxArp);
#endif

#endif /* #ifndef _ARPDEFS_H_ */
