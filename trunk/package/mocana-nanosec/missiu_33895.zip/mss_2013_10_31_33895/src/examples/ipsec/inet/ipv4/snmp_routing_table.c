/*
 * snmp_routing_table.c
 *
 * SNMP access functions to the routing table
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "router.h"
#include "routing_table_defs.h"
#include "snmp_tcpip_rtn.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/



/***************************************************************************
*    called from by SNMP Agent to retrieve an entire routing table
*
*    par:    void **ppvData - area of memory for placing the table
*            DWORD *pdwNosStructs - dimension of array
*            DWORD *pdwStructSize - size of array element
*
*    ret:    DWORD - nos bytes in pValue
*
*    (see rfc1213)
****************************************************************************/
DWORD TcpipSnmpGetRoutingTable(void **ppvData, DWORD *pdwNosStructs, DWORD *pdwStructSize)
{
  ROUTEENTRY *pxRoute;
  struct IP_ROUTE_TABLE_ENTRY *pxIpRtTblEntry=NULL;
  extern ROUTINGTABLESTATE *pxSnmpRoutingTable;
  ROUTINGTABLESTATE *pxRoutingTable = pxSnmpRoutingTable;
#ifdef _RADIX_ROUTING_ON_
  RADIXNODE *pxRadixNodeRoute = NULL;
#endif

  *ppvData = NULL;
  *pdwNosStructs = 0;

  /* Find the dimension of the array, and the size of each element */
  *pdwStructSize = sizeof(struct IP_ROUTE_TABLE_ENTRY);

  /* Fill the array */
#ifdef _RADIX_ROUTING_ON_
  LIST_FOREACH(pxRadixNodeRoute, &(pxRoutingTable->pxRadixTree->xRadixNodeList), xRadixNodeLink)
#else
  DLLIST_head(&pxRoutingTable->dllRoute);
  while( (pxRoute = DLLIST_read(&pxRoutingTable->dllRoute)) != NULL)
#endif /*end of _RADIX_ROUTING_ON_*/
  {
        {
            void *pvTempData;

            pvTempData = MALLOC((*pdwNosStructs + 1) * (*pdwStructSize));

            ASSERT(pvTempData);

            MOC_MEMCPY((ubyte *)pvTempData, (ubyte *)*ppvData,
                (*pdwNosStructs) * (*pdwStructSize));
            FREE(*ppvData);
            *ppvData = pvTempData;
            ++(*pdwNosStructs);
        }
    /* Point to correct element */
    pxIpRtTblEntry = ((struct IP_ROUTE_TABLE_ENTRY *)(*ppvData))+(*pdwNosStructs)-1;

    /* For default values, see rfc2096 */
#ifdef _RADIX_ROUTING_ON_
    pxRoute = (ROUTEENTRY *)pxRadixNodeRoute;
    pxIpRtTblEntry->dwipRouteDest    = ntohl(pxRoute->xRouteNodes->RadixNodeKey);
#else
    pxIpRtTblEntry->dwipRouteDest    = pxRoute->dwDstAddr;
#endif /*end of _RADIX_ROUTING_ON_*/
    pxIpRtTblEntry->dwipRouteIfIndex = pxRoute->oIfIdx+1;
    pxIpRtTblEntry->dwipRouteMetric1 = pxRoute->wMetric;
    pxIpRtTblEntry->dwipRouteMetric2 = 0xffffffff;
    pxIpRtTblEntry->dwipRouteMetric3 = 0xffffffff;
    pxIpRtTblEntry->dwipRouteMetric4 = 0xffffffff;
    pxIpRtTblEntry->dwipRouteNextHop = 0;
    pxIpRtTblEntry->dwipRouteType    = 1;
    pxIpRtTblEntry->dwipRouteProto   = 1;
    pxIpRtTblEntry->dwipRouteAge     = 0;
#ifdef _RADIX_ROUTING_ON_
    pxIpRtTblEntry->dwipRouteMask    = ntohl(pxRoute->xRouteNodes->RadixNodeMask);
#else
    pxIpRtTblEntry->dwipRouteMask    = pxRoute->dwSubnetMask;
#endif /*end of _RADIX_ROUTING_ON_*/
    pxIpRtTblEntry->dwipRouteMetric5 = 0xffffffff;
    MOC_MEMSET((ubyte *)pxIpRtTblEntry->dwipRouteInfo, 0, 16*sizeof(DWORD));
    pxIpRtTblEntry->dwipRouteInfo[2]=0xffffffff; /* terminator */

    pxIpRtTblEntry++;
#ifndef _RADIX_ROUTING_ON_
    DLLIST_next(&pxRoutingTable->dllRoute);
#endif /*end of _RADIX_ROUTING_ON_*/
  }

  return 0;
}

