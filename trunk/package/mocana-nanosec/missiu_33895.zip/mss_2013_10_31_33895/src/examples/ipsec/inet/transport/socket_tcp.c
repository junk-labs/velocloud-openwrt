/*
 * socket_tcp.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"

#ifdef IPSEC
#include "ipsec.h"
#if 0 /* IPSEC is not configed by us */
#include "ipsec_api.h"
#endif
#endif /* IPSEC */

#ifdef SOCK_RT
  #include "router.h"
  #include "nat.h"
#endif

#ifdef SOCK_BR
  #include "ethernet.h"
#endif

#include "../libsock/libsockserver.h"

      /*
 * SocketTcpCreateConn
 *  Create a TCP connection for this socket, and do specific TCP
 *  configurations.
 *
 *  Arg:
 *   pxSock                           Socket structure
 *
 *  Return:
 *   0 success, -1 failure
 */
LONG SocketTcpCreateConn(SOCKET *pxSock)
{
#ifdef __SOCKET_USE_MEMPOOL__
  MSTATUS status = OK;
#endif

  SOCKET_CHECK_STATE(pxSock);
  SOCKET_ASSERT(pxSock->lType == SOCK_STREAM);

  /* Create the TCP member */
#ifdef __SOCKET_USE_MEMPOOL__
  if(OK > (status = MEM_POOL_getPoolObject(&xSocketRep.tcpSockConnPool, (void **) &pxSock->u.pxTcp)))
  {
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: SocketTcpCreateConn: unable to allocate tcp socket");
    pxSock->u.pxTcp = NULL;
    return -1;
  }
#else
  pxSock->u.pxTcp = (TCPSOCKET *)MALLOC(sizeof(TCPSOCKET));
#endif
  ASSERT(pxSock->u.pxTcp);
  MOC_MEMSET((ubyte *)(pxSock->u.pxTcp), 0, sizeof(TCPSOCKET));

  /* Create the corresponding TCP UL interface */
  if (pxSock->hLL == (H_NETINTERFACE)0) {
    pxSock->hLL =
      TcpInstanceULInterfaceCreate(xSocketRep.axProtocols[TCP_INDEX].hInst);
  }

  /* Configure the interface */
  TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                              pxSock->hLL,
                              TCPULINTERFACEIOCTL_SETMSS,MAX_TCP_SEGMENT_SIZE);
  TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                              pxSock->hLL,
                              TCPULINTERFACEIOCTL_SETWIN,MAX_TCP_WINDOW_SIZE);
  TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                              pxSock->hLL,
                              NETINTERFACEIOCTL_SETOUTPUTPFN,
                              (H_NETDATA)TcpRxCbk);
  TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                              pxSock->hLL,
                              TCPULINTERFACEIOCTL_SETMSGCBK,
                              (H_NETDATA)SocketTcpUlCbk);

  return 0;
}

/*
 * SocketTcpConnectConn
 *  Performs a Connect on a TCP socket. Unless the socket
 *  is not blocking, it will block till either the connection
 *  is established, or has failed.
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxSock                     Socket structure
 *   servaddr_in                server address
 *
 *  Return:
 *   0 if successfull
 */
LONG SocketTcpConnectConn(SOCKET *pxSock, mn_sock_connect_cb_t cb, void *cbarg,void *ipc_req)
{
  LONG lFd;
#ifdef __SOCKET_USE_MEMPOOL__
  MSTATUS status = OK;
#endif

  SOCKET_CHECK_STATE(pxSock);

  lFd = pxSock->lFd;

  /* Early checks */
  if ((pxSock->dwSockState & (SS_ISCONNECTED | SS_NBIO))
      == (SS_ISCONNECTED | SS_NBIO)) {
    return MO_EISCONN;
  }
  if((pxSock->dwSockState & SS_ISCONNECTING) &&
     (pxSock->dwSockState & SS_NBIO)) {
    return MO_EALREADY;
  }
  /* If already connected or connecting, return error */
  if(pxSock->dwSockState & (SS_ISCONNECTED |  SS_ISCONNECTING)) {
    return MO_EISCONN;
  }

  /* if we are in closing state ie: in RST | CANTSENDMORE | CANTRCVMORE, return error
   * RFC 793 s3.9 p55 ANVL 4.28
   */
  if(pxSock->dwSockState & (SS_ISRESET | SS_CANTSENDMORE | SS_CANTRCVMORE)) {
    return MO_EISCONN;
  }

  /* If socket set to accept connections, cannot initiate a
   * connection since listen() was called on this socket before,
   * so return error.  */
  if(pxSock->dwSockOptions & SO_ACCEPTCONN) {
    return MO_EOPNOTSUPP;
  }

  SOCKET_ASSERT((pxSock->u.pxTcp != NULL) &&
                (pxSock->u.pxTcp->u.pxConnect == NULL));

  /* TCP socket is of the connect type:
     allocate the buffer */
#ifdef __SOCKET_USE_MEMPOOL__
  if(OK > (status = MEM_POOL_getPoolObject(&xSocketRep.tcpconnectConnPool, (void **) &pxSock->u.pxTcp->u.pxConnect)))
  {
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: SocketTcpConnectConn: unable to allocate tcpconnect socket from tcpconnectConnPool.");
    return -1; /*Need to put in an appropriate error code.*/
  }
#else
  pxSock->u.pxTcp->u.pxConnect = (TCPCONNECT *) MALLOC(sizeof(TCPCONNECT));
#endif
  ASSERT(pxSock->u.pxTcp->u.pxConnect != NULL);
  MOC_MEMSET((ubyte *)(pxSock->u.pxTcp->u.pxConnect), 0, sizeof(TCPCONNECT));
  pxSock->u.pxTcp->u.pxConnect->pfCb = NULL;
  pxSock->u.pxTcp->u.pxConnect->ipc_req = NULL;

  pxSock->dwSockState |= SS_ISCONNECTING;

  /* Open Up the connection */
  TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                              pxSock->hLL,NETINTERFACEIOCTL_OPEN,
                              (H_NETDATA)0);

  if (pxSock->dwSockState & SS_NBIO) {
    /* If the socket is not blocking */
    return MO_EINPROGRESS;
  }

  if ( cb ){
      pxSock->u.pxTcp->u.pxConnect->pfCb = cb;
      pxSock->u.pxTcp->u.pxConnect->pvCbArg = cbarg;
    return 0;
  }

  if ( ipc_req ){
      pxSock->u.pxTcp->u.pxConnect->ipc_req = ipc_req;
    return 0;
  }

  {
    DWORD dwCurrentId = pxSock->dwSocketId;

    while(!(pxSock->dwSockState & SS_ISCONNECTED)) {
      pthread_cond_wait(&(pxSock->xCond), &(xNetWrapper.xMutex));

      /* Check to see if pPCBPtr is still valid, since even after
       * a successful connect, a RST may be sent by remote end */
      if(((pxSock = RETRIEVE_SOCKET(lFd)) == NULL) ||
         (pxSock->dwSocketId != dwCurrentId) ||
         (pxSock->dwSockState & SS_ISRESET)){
        return MO_ECONNRESET;
      }
    }
  }

  return 0;
}

/*
 * SocketTcpForceTypeToAbortNBIO
 *  Forces the type of the socket to abort and non-blocking
 *  for fast close/shutdown
 *
 *  Args:
 *   pxSock
 *
 *  Return:
 *   NETERR_NOERR
 */
LONG SocketTcpForceTypeToAbortNBIO(SOCKET *pxSock)
{
    mnIoctlArgList_t mnIoctlArgList;
  struct linger xLinger = {1/* Linger */,0 /* Timeout == 0
                               =>ABORT the connection */};

  SOCKET_ASSERT(pxSock->lType == SOCK_STREAM);

    mnIoctlArgList.lFlag = TRUE;
  ioctl(pxSock->lFd, FIONBIO, &mnIoctlArgList);
  setsockopt(pxSock->lFd,SOL_SOCKET,SO_LINGER,(void *)&xLinger,
             sizeof(struct linger));

  return NETERR_NOERR;
}

/*
 * SocketTcpDestroy
 *  TCP specific socket destroy
 *  !!! Does not lock the mutex !!!
 *
 *  Args:
 *   pxSock                         Socket
 *
 *  Return:
 *   >=0 if successfull
 */
LONG SocketTcpDestroy(SOCKET *pxSock)
{
#ifdef __SOCKET_USE_MEMPOOL__
  MSTATUS status = OK;
#endif

  SOCKET_CHECK_STATE(pxSock);

  TcpInstanceULInterfaceIoctl(xSocketRep.axProtocols[TCP_INDEX].hInst,
                              pxSock->hLL,
                              (pxSock->dwSockOptions & SO_LINGER) ?
                              TCPULINTERFACEIOCTL_ABORT :
                              NETINTERFACEIOCTL_CLOSE,
                              (H_NETDATA)pxSock->dwLingerTimeOut);

  if (pxSock->dwSockOptions & SO_ACCEPTCONN) {
    /* Listening socket */
    /* Make all the child socket orphans */
    TCPLISTEN *pxListen = pxSock->u.pxTcp->u.pxListen;
    SOCKET *pxChild;

    /* accepted sockets */
    while (NULL != (pxChild = PeekQueueFront(pxListen->qAccepted))) {
      /* detach this socket from listen socket */
      SOCKET_CHECK_STATE(pxChild);
      pxChild->u.pxTcp->u.pxConnect->pxFather = NULL;
      DiscardQueueFront(pxListen->qAccepted);
    }

    /* Non accepted ones */
    while (NULL != (pxChild = PeekQueueFront(pxListen->qWaitForAccept))) {
      /* detach this socket from listen socket */
      SOCKET_CHECK_STATE(pxChild);
      pxChild->u.pxTcp->u.pxConnect->pxFather = NULL;
      DiscardQueueFront(pxListen->qWaitForAccept);
      /* Close the non-accepted socket too */
#ifndef __RECURSIVE_MUTEX__
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
      SocketTcpForceTypeToAbortNBIO(pxChild);
      close(pxChild->lFd);
#ifndef __RECURSIVE_MUTEX__
      RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif

    }
    FREE(pxListen);
  }
  else {
    /* Connecting socket */
    if (pxSock->u.pxTcp->u.pxConnect != NULL) {
        SOCKET *pxFather = pxSock->u.pxTcp->u.pxConnect->pxFather;
      if (pxFather != NULL) {
        TCPLISTEN *pxListen = pxFather->u.pxTcp->u.pxListen;
        /* The socket has a father: update Link list and
           backlog.
           */
        SOCKET_CHECK_STATE(pxFather);
        /* JJ This shoudl be when the socket gets  acceoted not here */
        /* pxListen->oBackLogLevel --;*/
        pxFather->dwSockState &= ~SS_CANTRCVMORE;

#ifdef SOCKETDBG_HI
        FindQueue(pxListen->qAccepted, pxSock);
        if (WasFoundQueue(pxListen->qAccepted) == FALSE) {
          ASSERT(0);
        } else
#endif
        DeleteQueue(pxListen->qAccepted, pxSock);
      }

#ifdef __SOCKET_USE_MEMPOOL__
    if (OK > (status = MEM_POOL_putPoolObject(&xSocketRep.tcpconnectConnPool, (void **)(&pxSock->u.pxTcp->u.pxConnect))))
    {
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "SocketTcpDestroy: unable to release tcpconnect socket  within tcpconnectConnPool Status = ", status);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
    }
#else
      FREE(pxSock->u.pxTcp->u.pxConnect);
#endif
    }
  }

#ifdef __SOCKET_USE_MEMPOOL__
  if (OK > (status = MEM_POOL_putPoolObject(&xSocketRep.tcpSockConnPool, (void **)(&pxSock->u.pxTcp))))
  {
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "SocketTcpDestroy: unable to release tcp socket  within tcpSockConnPool Status = ", status);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
  }
#else
  FREE(pxSock->u.pxTcp);
#endif

  /* Sleeps till the connection is closed, unless it
     is a non-blocking socket */
  while ((pxSock->dwSockOptions & SO_LINGER) &&
         ((pxSock->dwSockState & SS_ISRESET) == 0)) {
    if (pxSock->dwSockState & SS_NBIO) {
      mn_errno = MO_EWOULDBLOCK;
      return -1;
    }

    pthread_cond_wait(&(pxSock->xCond),&(xNetWrapper.xMutex));

    /* No need to check for validity here, as we know the
       socket won't be unregistered till this calls returns */

  }

  if (pxSock->dwSockState & SS_ISRESET) {
    /* RST has been received: destroy the interface */
    TcpInstanceULInterfaceDestroy(xSocketRep.axProtocols[TCP_INDEX].hInst,
                                  pxSock->hLL);
  }

  return 0;
}

/*
 * SocketTcpUlCbk
 *  Tcp UL interface Msg Cbk
 *
 *  Args:
 *   hUL                         UL instance handle. In fact a SOCKET
 *                               structure pointer
 *   hIf                         hInterface handle
 *   eCbk                        Cbk message
 *   hData                       Data handle
 *
 *  Return:
 *   >=0 if successfull
 */
LONG SocketTcpUlCbk(H_NETINSTANCE hUL,
                    H_NETINTERFACE hIf,
#ifndef __TCP_OPT_ON__
                    LONG  lFd,
#endif
                    E_TCPULINTERFACECBK eCbk,
                    H_NETDATA hData)
{
  SOCKET *pxSock = (SOCKET *)hUL;
  DWORD dwSocketId = (DWORD)hIf;
  LONG lReturn = 0;

  /* Note: this will only be called on the network thread:
     is locking the wrapper necessary */
#if defined (__RECURSIVE_MUTEX__)
  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
#endif
  /* check if the socket is still valid */
#ifndef __TCP_OPT_ON__ /* if the pxSock struct is deleted then accessing
                          pxSock->lFd is not done */
  pxSock = RETRIEVE_SOCKET(lFd);
  if ((pxSock) &&
      (pxSock->dwSocketId == dwSocketId)) {
#else
  if ((pxSock == RETRIEVE_SOCKET(pxSock->lFd)) &&
      (pxSock->dwSocketId == dwSocketId)) {
#endif

    /* Preliminary checks */
    SOCKET_CHECK_STATE(pxSock);
    SOCKET_CHECKFD(pxSock->lFd);
    SOCKET_ASSERT(pxSock->u.pxTcp != NULL);

    switch(eCbk) {
    case TCPULINTERFACECBK_OPENED:
      /* An interface is opened. If it is
         a connect interface, it means the
         connection to the remote end has succeeded */
      if ((pxSock->dwSockOptions & SO_ACCEPTCONN) == 0) {
        /* Only do something if it is a Connect socket */
        SOCKET_ASSERT((pxSock->dwSockState & SS_ISCONNECTING) != 0);
        SOCKET_ASSERT(pxSock->u.pxTcp->u.pxConnect != NULL);

        pxSock->dwSockState &= ~(SS_ISCONNECTING | SS_ISDISCONNECTING);
        pxSock->dwSockState |= SS_ISCONNECTED;
        if (pxSock->u.pxTcp->u.pxConnect->pxFather != NULL) {
          pxSock->dwSockState |= SS_ISACCEPTED;
        }
        if (pxSock->u.pxTcp->u.pxConnect->pxFather == NULL) {
                if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
                {
                    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,
                        "SocketTcpUlCbk lFd ", (LONG) pxSock->lFd);
                    DEBUG_PRINTNL(DEBUG_MOC_IPV4, ", client CONNECTED\n");
                }
          if ( pxSock->u.pxTcp->u.pxConnect->pfCb ){
            struct sockaddr_in servaddr;
            servaddr.sin_len = sizeof(servaddr);
            servaddr.sin_family = AF_INET;
            servaddr.sin_port = pxSock->xTransportId.wDstPort;
            servaddr.sin_addr.s_addr =
                pxSock->xTransportId.xNetId.dwDstIpAddr;
              pxSock->u.pxTcp->u.pxConnect->pfCb(0, pxSock->lFd,
                    (struct sockaddr *)&servaddr,
                    sizeof(servaddr),
                      pxSock->u.pxTcp->u.pxConnect->pvCbArg);
            /* break here. don't signal the condition -
             * wait is not expected along with async */
            break;
        }
#ifdef __MOCANA_IPC_LIBSOCK__
          if ( pxSock->u.pxTcp->u.pxConnect->ipc_req ){
                    SOCKSERVER_connectReply(pxSock->u.pxTcp->u.pxConnect->ipc_req,0);
                  pxSock->u.pxTcp->u.pxConnect->ipc_req  = NULL;
            break;
                }
#endif
    }
        /* signal the condition */
        pthread_cond_signal(&(pxSock->xCond));
#if 0 /* RS: don't wake up the select for this socket yet.
         We just finished connecting, no data rcvd yet */
        /* If there is any select on the socket, wake up the thread */
        SocketWakeSelect(pxSock,SELECT_RD | SELECT_WR);
#endif
      }
      break;

    case TCPULINTERFACECBK_FORKED:
      /* A listen interface has forked. Data is
             the interface handle. To get the IP and
             port of the remote peer, one must query them
             through the Coresponding Ioctl */

      {
        LONG lNewFd;
#ifndef __SELECT_OPT_ON__
        PIDINFO   *pxPid = NULL;
        PIDINFO   *pxPidL = NULL;
        PIDINFO    xPid;
        PIDFDINFO *pxPidFd = NULL;
        PIDFDINFO *pxPidFdTmp = NULL;
        PIDFDINFO xPidFd;

#endif

#ifdef __SOCKET_USE_MEMPOOL__
        MSTATUS status = OK;
#endif

        TCPLISTEN *pxListen = pxSock->u.pxTcp->u.pxListen;
        mnIoctlArgList_t mnIoctlArgList;

        SOCKET_ASSERT((pxSock->dwSockOptions & SO_ACCEPTCONN) != 0);
        SOCKET_ASSERT(pxListen != NULL);
        /* Create the new socket */
        if ((pxListen->oBackLogLevel < pxListen->oBackLogMax) &&
            ((lNewFd = open("/dev/socket/tcp", O_RDWR)) > 0)) {
          /* File descriptor is created */
          SOCKET *pxChild;

        mnIoctlArgList.lFd = lNewFd;
        mnIoctlArgList.lFamily = AF_INET;
        mnIoctlArgList.lType = SOCK_STREAM;
        mnIoctlArgList.lProtocol = 0;
        mnIoctlArgList.hIf = (DWORD) hData;
        if( 0 != ioctl(lNewFd,MO_SIOCACCEPT,&mnIoctlArgList))
        {
          lReturn = TCPERR_FORKEDFAILED;
          goto exit;
        }


          pxChild = RETRIEVE_SOCKET(lNewFd);
          ASSERT(pxChild != NULL);
#ifndef __SELECT_OPT_ON__
          /* For a Child Socket We need to move the PIDFDINFO Struct to the
             Listening Socket PIDINFO */
        xPid.lPid = RTOS_currentThreadId();
        pxPid = (PIDINFO *)rbfind(&xPid, xSocketRep.pidTree);
        if (!pxPid)
        {
          lReturn = TCPERR_FORKEDFAILED;
          goto exit;
        }

        xPid.lPid = pxSock->lPid;
        pxPidL = (PIDINFO *)rbfind(&xPid, xSocketRep.pidTree);
        if (!pxPidL)
        {
          lReturn = TCPERR_FORKEDFAILED;
          goto exit;
        }
        xPidFd.lFd = lNewFd;
        /* Remove  it from the IPStack PID Tree */
        pxPidFd = (PIDFDINFO *)rbdelete(&xPidFd,pxPid->fdTree);
        if (!pxPidFd)
        {
          lReturn = TCPERR_FORKEDFAILED;
          goto exit;

        }
        if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
        {
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "Removing pxPidFd  ",
                (int)pxPidFd);
            DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, " Fd ", pxPidFd->lFd,
                "into Pid ",pxPid->lPid);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");
        }
        /* Insert it in the Listen Sockets PID Tree */
        pxPidFdTmp = (PIDFDINFO *)rbsearch(pxPidFd,pxPidL->fdTree);
        if ((!pxPidFdTmp) || (pxPidFdTmp != pxPidFd))
        {
          lReturn = TCPERR_FORKEDFAILED;
          goto exit;
        }
        pxChild->lPid = pxPidL->lPid;
        if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
        {
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"Moved pxPidFd ",
                (int)pxPidFd);
            DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4," Fd ", pxPidFd->lFd,
                " into Pid ", pxPidL->lPid);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,"\n");

            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,"SocketTcpUlCbk lFd ",
                (LONG)pxSock->lFd);
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4,", FORKED lChildFd [",
                lNewFd);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4,"] Moved \n");
        }
#endif
          /* Update the backlog  only in case of sync*/
          if (!pxListen->pfAcceptCb)
          {
              pxListen->oBackLogLevel ++;
          }
          /* Configure the new socket */
          pxChild->dwSockState =
            (pxSock->dwSockState & (~SO_ACCEPTCONN)) |
            SS_ISCONNECTING;
          pxChild->dwSockOptions = pxSock->dwSockOptions &
            (~SO_ACCEPTCONN);
          SOCKET_ASSERT(pxChild->u.pxTcp != NULL);
#ifdef __SOCKET_USE_MEMPOOL__
          if(OK > (status = MEM_POOL_getPoolObject(&xSocketRep.tcpconnectConnPool, (void **) &pxChild->u.pxTcp->u.pxConnect)))
          {
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: SocketTcpUlCbk: unable to allocate tcpconnect socket from tcpconnectConnPool.");
            lReturn = -1;
            goto exit;
          }
#else
          pxChild->u.pxTcp->u.pxConnect = (TCPCONNECT *)
            MALLOC(sizeof(TCPCONNECT));
#endif
          ASSERT(pxChild->u.pxTcp->u.pxConnect != NULL);
          MOC_MEMSET((ubyte *)(pxChild->u.pxTcp->u.pxConnect), 0,
                sizeof(TCPCONNECT));
          pxChild->u.pxTcp->u.pxConnect->pxFather = pxSock;
          if (pxListen->pfAcceptCb){
        struct sockaddr_in cliaddr;
        socklen_t addrlen = sizeof(cliaddr);
        read_accept_info(pxSock, pxChild, &cliaddr, &addrlen);
        pxListen->pfAcceptCb(pxSock->lFd, pxChild->lFd,
                    (struct sockaddr *)&cliaddr,
                    addrlen, pxListen->pvAcceptCbArg);
                /*pxListen->oBackLogLevel -- ;*/
              Queue(pxListen->qAccepted, pxChild);
          }else
#ifdef __MOCANA_IPC_LIBSOCK__
            if (pxListen->ipc_req){
        struct sockaddr_in cliaddr;
        socklen_t addrlen = sizeof(cliaddr);
        read_accept_info(pxSock, pxChild, &cliaddr, &addrlen);
        SOCKSERVER_acceptReply(pxListen->ipc_req, pxChild->lFd,
                    (struct sockaddr *)&cliaddr,
                    addrlen);

                pxListen->ipc_req = NULL;
              Queue(pxListen->qAccepted, pxChild);

      }else
#endif
          {
              Queue(pxListen->qWaitForAccept, pxChild);
              /* signal the condition */
              pthread_cond_signal(&(pxSock->xCond));
              SocketWakeSelect(pxSock,SELECT_RD);
          }
        }
        else {
          lReturn = TCPERR_FORKEDFAILED;
          /* TODO Return Error to the IPC_MSG */
        }

      }
      break;

    case TCPULINTERFACECBK_PASSIVECLOSE: /* Connection closed for a RST in SYN_RCVD state*/
      if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
      {
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "SocketTcpUlCbk lFd ", (LONG) pxSock->lFd);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, ", PASSIVE-CLOSE RST");
      }
      if (pxSock->u.pxTcp->u.pxConnect->pxFather != NULL)
      {
        SOCKET *pxFather = pxSock->u.pxTcp->u.pxConnect->pxFather;
        TCPLISTEN *pxListen = pxFather->u.pxTcp->u.pxListen;
        MSTATUS status = OK;
        FindQueue(pxListen->qWaitForAccept, pxSock);
        if ((TRUE == WasFoundQueue(pxListen->qWaitForAccept)) &&
            (pxSock->u.pxTcp->u.pxConnect))
        {
          if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
          {
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, "SocketTcpUlCbk, cleaning up the socket layer.");
          }
          DeleteQueue(pxListen->qWaitForAccept, pxSock);
#ifdef __SOCKET_USE_MEMPOOL__
          if (OK > (status = MEM_POOL_putPoolObject(&xSocketRep.tcpconnectConnPool, (void **)(&pxSock->u.pxTcp->u.pxConnect))))
          {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "SocketTcpDestroy: unable to release tcpconnect socket  within tcpconnectConnPool Status = ", status);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
          }
#else
          FREE(pxSock->u.pxTcp->u.pxConnect);
#endif

#ifdef __SOCKET_USE_MEMPOOL__
          if (OK > (status = MEM_POOL_putPoolObject(&xSocketRep.tcpSockConnPool, (void **)(&pxSock->u.pxTcp))))
          {
            DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "SocketTcpDestroy: unable to release tcp socket  within tcpSockConnPool Status = ", status);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, "");
          }
#else
          FREE(pxSock->u.pxTcp);
#endif
          pxListen->oBackLogLevel--; /* Reduce the back log level */
          pxSock->dwSockState |= SS_ISRESET | SS_CANTSENDMORE | SS_CANTRCVMORE;
          pxSock->dwSockState &= ~SS_ISCONNECTED;
          /* NOTE: not destroying socket, re-visit needed */
        }
      }
      break;
    case TCPULINTERFACECBK_RST:        /* Connection has been reset */
    case TCPULINTERFACECBK_TIMEDOUT:   /* Connection has timed out */
    case TCPULINTERFACECBK_CLOSED:     /* result of a CLOSE Ioctl */
      {

        /* signals the rst. The UL interface will either
           be destroyed in the close (if the close had already
           happened and returned, this socket would not be valid. And
           TCP would take care of the freeing) */
        if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
        {
            DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4,
                "SocketTcpUlCbk lFd ", (LONG) pxSock->lFd);
            DEBUG_PRINTNL(DEBUG_MOC_IPV4, ", RST | TIMEDOUT | CLOSED\n");
        }
        pxSock->dwSockState |= SS_ISRESET | SS_CANTSENDMORE | SS_CANTRCVMORE;
        pxSock->dwSockState &= ~SS_ISCONNECTED;
        if (pxSock->dwSockState & SS_ISCONNECTING &&
            pxSock->u.pxTcp->u.pxConnect != NULL &&
          pxSock->u.pxTcp->u.pxConnect->pfCb ){
        struct sockaddr_in servaddr;
        servaddr.sin_len = sizeof(servaddr);
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = pxSock->xTransportId.wDstPort;
        servaddr.sin_addr.s_addr =
                pxSock->xTransportId.xNetId.dwDstIpAddr;
                  pxSock->u.pxTcp->u.pxConnect->pfCb(-1, pxSock->lFd,
                    (struct sockaddr *)&servaddr,
                    sizeof(servaddr),
                      pxSock->u.pxTcp->u.pxConnect->pvCbArg);
        break;
    }

#ifdef __MOCANA_IPC_LIBSOCK__
        if (pxSock->dwSockState & SS_ISCONNECTING &&
            pxSock->u.pxTcp->u.pxConnect != NULL &&
          pxSock->u.pxTcp->u.pxConnect->ipc_req ){

            SOCKSERVER_connectReply(pxSock->u.pxTcp->u.pxConnect->ipc_req,-1);
          pxSock->u.pxTcp->u.pxConnect->ipc_req  = NULL;
        break;
        }
#endif

        pxSock->hLL = NULL; /* setting the UL to NULL */
        /* signal the condition */
        pthread_cond_signal(&(pxSock->xCond));
        /* If the select flag is set, wake the selecting thread */
        SocketWakeSelect(pxSock,SELECT_RD | SELECT_WR);
      }
      break;

    case TCPULINTERFACECBK_HALFCLOSED: /* Remote end has closed its
                                          output pipe: See TCP RFC */
      pxSock->dwSockState |= SS_CANTRCVMORE;
      /* signal the condition */
      pthread_cond_signal(&(pxSock->xCond));
      SocketWakeSelect(pxSock,SELECT_RD | SELECT_WR);

      break;

    case TCPULINTERFACECBK_TXAVAILSPACE:
      /* signal the condition */
      pthread_cond_signal(&(pxSock->xCond));
      SocketWakeSelect(pxSock,SELECT_WR);
      break;

    case TCPULINTERFACECBK_RX_ERRS:
    case TCPULINTERFACECBK_TX_ERRS:
      break;

    default:
      SOCKET_ASSERT(0);
      lReturn = -1;
    }

    if ( pxSock->pfEventCb &&
        /* check if the socket is still valid */
        (pxSock == RETRIEVE_SOCKET(pxSock->lFd)) &&
        (pxSock->dwSocketId == dwSocketId)) {

        /* Preliminary checks */
        SOCKET_CHECK_STATE(pxSock);
        SOCKET_CHECKFD(pxSock->lFd);
        SOCKET_ASSERT(pxSock->u.pxTcp != NULL);

        switch(eCbk) {
           case TCPULINTERFACECBK_RST:        /* Connection has been reset */
          pxSock->pfEventCb(pxSock->lFd, MN_TCP_SOCK_RST,
                    pxSock->pvEventCbArg, NULL);
                break;
           case TCPULINTERFACECBK_TIMEDOUT:   /* Connection has timed out */
          pxSock->pfEventCb(pxSock->lFd, MN_TCP_SOCK_TIMEDOUT,
                    pxSock->pvEventCbArg, NULL);
                break;
           case TCPULINTERFACECBK_HALFCLOSED: /* Remote end has closed its
                                              output pipe: See TCP RFC */
          pxSock->pfEventCb(pxSock->lFd, MN_TCP_SOCK_HALFCLOSED,
                    pxSock->pvEventCbArg, NULL);
              break;
           case TCPULINTERFACECBK_RX_ERRS:
          pxSock->pfEventCb(pxSock->lFd, MN_TCP_SOCK_RX_ERRS,
                    pxSock->pvEventCbArg,(void*)hData);
              break;
           case TCPULINTERFACECBK_TX_ERRS:
          pxSock->pfEventCb(pxSock->lFd, MN_TCP_SOCK_TX_ERRS,
                    pxSock->pvEventCbArg,(void*)hData);
              break;
        }
      }
#ifdef __MOCANA_IPC_LIBSOCK__
      if ((pxSock->ipc_req) &&
        (pxSock == RETRIEVE_SOCKET(pxSock->lFd)) &&
        (pxSock->dwSocketId == dwSocketId))
        {

        /* Preliminary checks */
        SOCKET_CHECK_STATE(pxSock);
        SOCKET_CHECKFD(pxSock->lFd);
        SOCKET_ASSERT(pxSock->u.pxTcp != NULL);
        /* Preliminary checks */
        SOCKET_CHECK_STATE(pxSock);
        SOCKET_CHECKFD(pxSock->lFd);
        SOCKET_ASSERT(pxSock->u.pxTcp != NULL);
        switch(eCbk) {
           case TCPULINTERFACECBK_RST:        /* Connection has been reset */
           case TCPULINTERFACECBK_TIMEDOUT:   /* Connection has timed out */
           case TCPULINTERFACECBK_HALFCLOSED: /* Remote end has closed its side*/
           case TCPULINTERFACECBK_RX_ERRS:
           case TCPULINTERFACECBK_TX_ERRS:

#ifdef __MOCANA_IPC_LIBSOCK__
          /* Send a recvReply with an Error */
                SOCKSERVER_recvReply(pxSock->ipc_req,pxSock->lFd, NULL,-1 ,
                             NULL, 0);
                pxSock->ipc_req = NULL;
#endif
                break;
            default:
                break;
        }
      }
#endif
  }
  else {
    /* Invalid socket. TCP will take care of the freeing */
    if (INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_SOCKET, REPETITIVE))
    {
        DEBUG_PRINTNL(DEBUG_MOC_IPV4,"SocketTcpUlCbk : Invalid Socket\n");
    }
    lReturn = -1;
  }

exit:
#if defined (__RECURSIVE_MUTEX__)
  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
#endif
  return lReturn;
}
