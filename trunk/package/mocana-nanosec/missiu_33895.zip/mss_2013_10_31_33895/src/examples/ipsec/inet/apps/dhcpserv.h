/*
 * dhcpserv.h
 *
 * This file contains the DHCP server application header file
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/**************************************************************************
 * INCLUDES
 **************************************************************************/
#include "NNstyle.h"
#include "pthread.h"
#include "dllist.h"
/*#include "protutil.h" */

/**************************************************************************
 * DEBUG
 **************************************************************************/
#ifdef DEBUG_DHCP
#define CHECKPOINT(X)   (X)= __LINE__;
#define DHCPDEBUG(X)    DEBUG((X))
#else
#define CHECKPOINT(X)
#define DHCPDEBUG(X)
#endif


/**************************************************************************
 * DEFINITIONS / MACROS
 **************************************************************************/
/* Useful macros */
#define SUBNET_ADDRESS       ((pDhcpServ->dwDHCPServerIP) & 0xFFFFFF00)
#define MAC(A)               (A)[0],(A)[1],(A)[2],(A)[3],(A)[4],(A)[5]
#define IP(A)                ((A)>>24)&0xFF, ((A)>>16)&0xFF, ((A)>>8)&0xFF, (A)&0xFF
#define DHCP_PACKET_SIZE     sizeof(DHCP_PACKET)
#define MACFORM              "%02X%02X%02X%02X%02X%02X"
#define IPFORM               "%ld.%ld.%ld.%ld"

/* Lease defs */
#define INFINITE_LEASE                 0xFFFFFFFF
#define DEFAULT_LEASE_TIME             86400 /* 24hours = 86400secs */

/* Message types */
#define BOOTREQUEST                    1
#define BOOTREPLY                      2

#define DHCPDISCOVER                   1
#define DHCPOFFER                      2
#define DHCPREQUEST                    3
#define DHCPDECLINE                    4
#define DHCPACK                        5
#define DHCPNAK                        6
#define DHCPRELEASE                    7
#define DHCPINFORM                     8

/* Network defs */
#define DHCPSERVERPORT                 67
#define DHCPCLIENTPORT                 68
#define ETHERNET_TYPE                  1
#define ETHERNET_TYPELEN               6
#define DEST_BROADCAST                 0xFFFFFFFF

/* Timeout defs */
#define RESPONSE_TIMEOUT               20    /* x100ms = 2 seconds */
#define PING_RESPONSE_TIMEOUT          20    /* x100ms = 2 seconds */

/* IP address assignment rule states */
#define OFFER_TRY_CURRENT              0
#define OFFER_TRY_PREVIOUS             1
#define OFFER_TRY_REQUESTED            2
#define OFFER_SEARCH_POOL_UNASSIGNED   3
#define OFFER_SEARCH_POOL_EXPIRED      4
#define OFFER_STATIC                   5

/* DHCP server defs */
#define DHCPSERV_STATE_DISABLED        0
#define DHCPSERV_STATE_ENABLED         1
#define DHCPSERV_STATE_TERMINATING     2

#define DHCP_SLEEP_PERIOD              100000000    /* nanoseconds */
#define MAX_PROCESS_CLIENTS            4
#define MAX_BOUND_CLIENTS              32           /* link list max size */
#define DHCP_MAX_ADDRESS_RANGE         32           /* Address range maximum */

/* DHCP option fields */
#define DHCP_OPT_SUBNET_MASK                      1
#define DHCP_OPT_UTC_TIME_OFFSET                  2
#define DHCP_OPT_ROUTER                           3
#define DHCP_OPT_TIME_SERVER                      4
#define DHCP_OPT_NAME_SERVER                      5
#define DHCP_OPT_DNS_SERVER                       6
#define DHCP_OPT_HOST_NAME                        12
#define DHCP_OPT_BOOT_FILE_SIZE                   13
#define DHCP_OPT_DOMAIN_NAME                      15
#define DHCP_OPT_IP_FORWARDING_ENABLE_DISABLE     19
#define DHCP_OPT_DEFAULT_IP_TIME_TO_LIVE          23
#define DHCP_OPT_ETHERNET_ENCAPSULATION           36
#define DHCP_OPT_NETWORK_TIME_PROTOCOL_SERVERS    42
#define DHCP_OPT_REQUEST_IP_ADDRESS               50
#define DHCP_OPT_LEASE_TIME                       51
#define DHCP_OPT_DHCP_OPTION_OVERLOAD             52
#define DHCP_OPT_MESSAGE_TYPE                     53
#define DHCP_OPT_SERVER_IDENTIFIER                54
#define DHCP_OPT_PARAMETER_REQUEST_LIST           55
#define DHCP_OPT_ERROR_MESSAGE                    56
#define DHCP_OPT_MAXIMUM_DHCP_MESSAGE_SIZE        57
#define DHCP_OPT_RENEWAL_T1_TIME                  58
#define DHCP_OPT_REBINDING_T2_TIME                59
#define DHCP_OPT_CLASS_IDENTIFIER                 60
#define DHCP_OPT_CLIENT_IDENTIFIER                61
#define DHCP_OPT_END                              255
#define DHCP_OPT_PAD                              0


/**************************************************************************
 * TYPEDEFS
 **************************************************************************/
/* DHCP packet structure */
typedef struct {
  OCTET op;
  OCTET htype;
  OCTET hlen;
  OCTET hops;
  DWORD xid;
  WORD  secs;
  WORD  flags;
  DWORD ciaddr;
  DWORD yiaddr;
  DWORD siaddr;
  DWORD giaddr;
  OCTET chaddr[16];
  OCTET sname[64];
  OCTET file[128];
  OCTET options[312];
} DHCP_PACKET;


/* Structure contain information on clients which are being processed */
typedef struct {
  BOOL  bRequestFromNullIP;   /* Request from client with IP = 0.0.0.0 */
  OCTET *poClientID;          /* Pointer to the clientID */
  OCTET oClientIDLen;         /* ClientID length */
  OCTET oOfferState;          /* Address assign state */
  OCTET oOfferIP;             /* Address we offer to client */
  DWORD dwPingResponseTime;   /* Timeout for client's candidate IP to respond to ping */
  DWORD dwResponseTimer;      /* Timeout for the client to respond */
  DWORD dwLeaseTime;          /* Lease expiration time */
  DWORD dwOriginal_yiaddr;    /* IP address client used to send */
  DHCP_PACKET xDhcpPacket;    /* The client's packet */
} DHCP_PROCESS_CLIENT;


#define CLIENTCID(x)        (OCTET *)(&((x)->pxClientInfo))
#define CLIENTHOSTNAME(x)   ((char *)(&((x)->pxClientInfo)) + ((x)->oClientIDLen))

/* Structure contain information on 'bound' clients */
typedef struct dhcp_bound_client_entry {
  struct dhcp_bound_client_entry *pNext;  /* Next client in the linked list */
  DWORD dwLeaseTimer;         /* Lease expiration timer on current assignment */
  BOOL  bPermanent;           /* Permanent (static) assignment? */
  OCTET oCurrentIPAddress;    /* Last octet of client's current IP address */
  OCTET oPreviousIPAddress;   /* Last octet of client's previous IP address */
  OCTET oClientIDLen;         /* Length of Client ID */
  void  *pxClientInfo;        /* Client information (Client ID + hostname) */
} DHCP_BOUND_CLIENT_ENTRY;


/* DHCP server structure */
typedef struct {
  DWORD dwDHCPServerIP;            /* our DHCP server's IP */
  DWORD dwDNS1;                    /* DHCP provided DNS server 1 */
  DWORD dwDNS2;                    /* DHCP provided DNS server 2 */
  DWORD dwRouter;                  /* default router/gateway */
  DWORD dwSubnetMask;              /* subnet mask */
  char  *pcDomainName;             /* subnet domain name */
  OCTET oPoolMin;                  /* IP address pool min */
  OCTET oPoolMax;                  /* IP address pool max */
  OCTET oServState;                /* server state */

  int   iDhcpSocket;               /* server socket */
#ifdef NETSRV_THREAD
  pthread_t th_tThread;            /* Thread handle */
#else
#ifdef  JJ
  H_PROTOCOL_INSTANCE hInst;       /* Procotol service instance */
#else
  OCTET  hInst;       /* Procotol service instance */
#endif
#endif
  pthread_mutex_t xDHCPMutex;      /* Thread protection */

  WORD  wClientCount;              /* Number of bound clients */
  DHCP_BOUND_CLIENT_ENTRY *pClientLinkListHead;  /* Pointer to head of
                                                  * linked list of bound
                                                  * clients */
  DHCP_BOUND_CLIENT_ENTRY *pCurrentBindQuery;    /* Pointer to current
                                                  * table entry. Used when
                                                  * external app is reading
                                                  * entries out via the
                                                  * DHCPServerGetNextBinding()
                                                  * API */

  DLLIST *pDllProcessingClients;   /* Client's who are being processed
                                    * (aquiring/renewing) lease */
} DHCP_SERVER;



/**************************************************************************/
/*********************** END OF FILE **************************************/
/**************************************************************************/
