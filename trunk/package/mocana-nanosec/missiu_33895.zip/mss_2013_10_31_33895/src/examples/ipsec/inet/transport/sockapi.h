/*
 * sockapi.h
 *
 * socket non POSIX library API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _SOCKAPI_H_
#define _SOCKAPI_H_
/****************************************************************************
 *
 * Defines
 *
 ****************************************************************************/

/*
 * Socket local IOCTLs
 *
 */
#define MO_SIOCLOCAL_START  (MO_SIOCPUBLICIOCTL_END + 1)

#define MO_SIOCOPEN   MO_SIOCLOCAL_START
#define MO_SIOCACCEPT (MO_SIOCLOCAL_START + 1)

/*
 * Maximum number of sockets
 */
#if 0
#define MAX_FD                OPEN_MAX
#else
#define MAX_FD                MN_OPEN_MAX+1
#endif

/*
 * Max number of simultaneous select calls
 */
#define MAX_SELECTS     16

/*
 * SELECT modes
 *  (!!! Exception is not supported !!!)
 */
#define SELECT_RD       0x1
#define SELECT_WR       0x2
#define SELECT_RDWR     (SELECT_RD | SELECT_WR)


/*
 * Maximum backlog on a TCP listen connection
 */
#define SOCK_MAXBACKLOG 1024

/*
 * Maximum buffer size for a TCP socket
 */
#define SOCK_MAXTCPBUFFERSIZE  1400
#define MAX_TCP_SEGMENT_SIZE  1400

/*
 * Maximum buffer size for a UDP socket
 */
#define SOCK_MAXUDPBUFFERSIZE  1472
#define SOCK_MAXUDPPACKETS     1


/*
 * Socket library option
 */
#define SOCKETLIBOPTION_HUDP               0   /* UDP handle */
#define SOCKETLIBOPTION_HTCP               1   /* TCP handle */
#define SOCKETLIBOPTION_HNETWORK           2   /* Network layer entry point
                                                  instance handle */
#define SOCKETLIBOPTION_HICMP              3   /* Icmp handle */
#define SOCKETLIBOPTION_HIGMP              4   /* Igmp handle */
#define SOCKETLIBOPTION_HROUTER            5   /* Router handle */
#define SOCKETLIBOPTION_HNAT               6   /* NAT handle */
#define SOCKETLIBOPTION_HETH               7   /* Ethernet handle */
#define SOCKETLIBOPTION_HIPSEC             8   /* IPSec handle */

/*
 * Socket library Msg
 */
#define SOCKETLIBMSG_CLOSEIF               0   /* Data is oIfIdx */

/****************************************************************************
 *
 * Typedef
 *
 ****************************************************************************/
/* JJ  */
/* use only the 16 bits for each index */
#ifndef __SELECT_OPT_ON__
#define DEVICE_NMBR_MASK 0x0000ffff
#else
#define DEVICE_NMBR_MASK 0x00000fff
#endif
typedef struct {
    void * private_data;

} INODE;

struct file {
    void * private_data;

};

#define DEVICE_MAJOR_SCK 176
#define DEVICE_MAJOR_ETHIF 177

struct file_operations {
    LONG (*ioctl)(INODE* inode, struct file *pxFile, DWORD dwRequest,
          mnIoctlArgList_t *pArgList);
    LONG (*read)(INODE *pxInode, struct file *pxFile, void *pBuf,
         ubyte4 dwCnt);
    LONG (*write)(INODE *pxInode, struct file *pxFile, void *pBuf,
          ubyte4 dwCnt);
    LONG (*open)  (INODE * , struct file *);
    LONG (*close) (INODE *,struct file *);
};

#define MAX_DEVICE_FOPS  10

struct device_fops {
    char device_name[32];
    struct file_operations *fops;
    int occupied;
    struct file *pFile;
    INODE * inode;
    unsigned int fd_mask;
};

MOC_EXTERN struct device_fops fops_demux[MAX_DEVICE_FOPS];

#define IF0   "IF0"
#define IF1   "IF1"
#define IF0INTF_NAME   "eth0"
#define IF1INTF_NAME   "eth1"

#ifndef __SELECT_OPT_ON__
#define DEV_FD_MASK        0x000F0000
#define ETH_DEV_FD_BIT     0x00010000
#define SCK_DEV_FD_BIT     0x00000000
#else
#define DEV_FD_MASK        0x0000F000
#define ETH_DEV_FD_BIT     0x00002000
#define SCK_DEV_FD_BIT     0x00001000

#endif

/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * SocketLibraryInitialize
 *  Initialize TCP-UDP/IP sockets, open tcp and udp pseudo files and
 *  create the socket device
 *
 *  Args:
 *
 *  Return:
 *   success/failure on creating the socket device
 */
LONG SocketLibraryInitialize();

/*
 * SocketLibrarySet
 *  Set socket library wide options.
 *
 *  Args:
 *   oOption           Option code. Defined above as SOCKETLIBOPTION_XXX
 *   hData             Data handle. see option code definition for specifics
 *
 *  Return:
 *   >=0
 */
LONG SocketLibrarySet(OCTET oOption,H_NETDATA hData);

/*
 * SocketLibraryMsg
 *  Send a Msg to the socket library
 *
 *  Args:
 *   oMsg               Msg code
 *   hData              Msg data handle
 *
 *  Return:
 *   >=0 for success
 */
LONG SocketLibraryMsg(OCTET oMsg,H_NETDATA hData);

/*
 * SocketLibraryTerminate
 *  Terminate TCP-UDP/IP sockets. Unregister the devices
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG SocketLibraryTerminate();

/*
 * Transport2NetworkWrite
 *  UDP/TCP LL Write function
 *  Follows PFN_NETWRITE type
 *  !!! Does not lock the mutex !!!
 */
LONG Transport2NetworkWrite(H_NETINSTANCE hLLInst,
                H_NETINTERFACE hIf,
                NETPACKET *pxPacket,
                NETPACKETACCESS *pxAccess,
                H_NETDATA hData);

/*
 * Transport2NetworkRcv
 *  UDP/TCP LL Rcv function
 *  Follows PFN_NETRXCBK type
 *  !!! Does not lock the mutex !!!
 */
LONG Transport2NetworkRcv(H_NETINSTANCE hULInst,
                H_NETINTERFACE hIf,
                NETPACKET *pxPacket,
                NETPACKETACCESS *pxAccess,
                H_NETDATA hData);

#endif /* #ifndef _SOCKAPI_H_ */

