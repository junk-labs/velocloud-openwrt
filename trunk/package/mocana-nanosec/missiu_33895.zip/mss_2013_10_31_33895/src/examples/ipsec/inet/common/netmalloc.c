/*
 * NetMalloc.c
 *
 * Implements NetMalloc function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "netutils.h"

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * NetMalloc
 *  Network Malloc function.
 *  Encapsulates the stdlib malloc
 *
 *  Args:
 *   size                 size to allocate (in byte)
 *
 *  Return:
 *   void *               pointer to the allocated memory
 */
void *NetMalloc(ubyte4 size)
{
#ifdef __INET_USE_PAYLOAD_MEMPOOL__
  ubyte * poPayload;
  MSTATUS status;
  status = NetAllocPayload(&poPayload,size);
  if (OK > status)
      return NULL;
  return poPayload;
#else
  return(MALLOC(size));
#endif
}
