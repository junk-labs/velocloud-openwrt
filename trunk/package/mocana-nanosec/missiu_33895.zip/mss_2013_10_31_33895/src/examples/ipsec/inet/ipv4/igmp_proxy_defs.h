/*
 * igmp_proxy_defs.h
 *
 * Internal header file for IGMP proxy functions.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef __IGMP_PROXY_DEFS_H__
#define __IGMP_PROXY_DEFS_H__

#ifdef STACK_MULTICAST_ROUTER

#include "NNstyle.h"
#include "igmp_flavor.h"
#include "dllist.h"
#include "../include/socket.h"
#include "../include/in.h"
#include "../include/inet.h"
#include "igmp.h"
#include "igmp_proxy_dbg.h"
#include "iptable.h"

/***************************************************************************
 * Constants
 **************************************************************************/

#define ROBUSTNESS_VARIABLE             2
#define QUERY_INTERVAL                  125000        /* 125 seconds */
#define QUERY_RESPONSE_INTERVAL         10000         /* 10 seconds */
#define GROUP_MEMBERSHIP_INTERVAL       ((ROBUSTNESS_VARIABLE * QUERY_INTERVAL) + QUERY_RESPONSE_INTERVAL)
#define STARTUP_QUERY_INTERVAL          (QUERY_INTERVAL >> 2)
#define STARTUP_QUERY_COUNT             ROBUSTNESS_VARIABLE
#define LAST_MEMBER_QUERY_INTERVAL      1000          /* 1 second */
#define LAST_MEMBER_QUERY_COUNT         ROBUSTNESS_VARIABLE
#define OTHER_ROUTER_PRESENT_INTERVAL   ((ROBUSTNESS_VARIABLE * QUERY_INTERVAL) + (QUERY_RESPONSE_INTERVAL >> 1))
#define V1_HOST_TIMER                   GROUP_MEMBERSHIP_INTERVAL
#define STARTUP_INITIALIZATION_DELAY    5000          /* 5 seconds */

#define MAX_HOST_GROUP                  32

/***************************************************************************
 * Externs
 **************************************************************************/

IGMP_PROXY_DBG_VAR(MOC_EXTERN DWORD g_dwIgmpProxyDebugLevel);

/***************************************************************************
 * Typedefs
 **************************************************************************/

/* Multicast message group structure */
typedef struct mcast_group {
  E_IGMP_GROUP_STATE eGroupState;
  DWORD dwGroupTimer;
  DWORD dwV1HostTimer;
  DWORD dwRTXTimer;
  DWORD dwGroupIPAddress;
} MCAST_GROUP;

/***************************************************************************
 * Functions
 **************************************************************************/

void IgmpProxyXmt();
BOOL IgmpProxyCheckMembership(DWORD dwGroupAddress);
void IgmpProxySendQuery(IGMPSTATE *pxIgmp,
                        DWORD dwGroupAddress,
                        OCTET oMaxResponseTime);

#ifdef IGMPPROXYDBG_HI
void _IgmpProxyPrintMcastGroup(IGMPSTATE *pxIgmp);
#endif /* #ifndef IGMPPROXYDBG_HI */

#endif /* #ifdef STACK_MULTICAST_ROUTER */
#endif /* __IGMP_PROXY_DEFS_H__ */
