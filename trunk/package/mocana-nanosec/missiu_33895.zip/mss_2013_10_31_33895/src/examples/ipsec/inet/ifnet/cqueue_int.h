/*
 * cqueue.h
 *
 * Custom Queue common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*
 * Internal defaults
 */

/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

/*
 * Custom Queue Filter structure
 * One or more of the elements can be populated, which leads to logical
 * AND operation when filter is applied.
 */
#if 0
typedef struct {
  /* Data layer filter criteria */
  BOOL  bEthVlanTagged;   /* Select if frame is VLAN tagged */
  WORD  wEthVlanTag;      /* VLAN tag matches */
  BOOL  bEthBroadcast;    /* Broadcast frame */
  BOOL  bEthMulticast;    /* Multicast frame */
  WORD  wEthProtocol;     /* Protocol matches, e.g. ARP, IP */

  /* Network layer filter criteria - used w/ IP packets */
  OCTET oIpPrecedence;    /* TOS precedence matches, 0-7 valid */
  OCTET oIpTos;           /* TOS matches, 0-31 valid */
  OCTET oIpProtocol;      /* Protocol matches, e.g. ICMP, UDP, TCP */
  DWORD dwIpSrcAddress;   /* Source IP address matches */
  DWORD dwIpSrcNetMask;   /* Source IP netmask - used w/ address */
  DWORD dwIpDstAddress;   /* Destination IP address matches */
  DWORD dwIpDstNetMask;   /* Destination IP netmask - used w/ address */

  /* Transport layer filter criteria - used w/ UDP and TCP packets */
  WORD  wTransSrcPort;    /* Source port matches */
  WORD  wTransDstPort;    /* Destination port matches */

  /* Class associated w/ this criteria set */
  OCTET oClass;
} CUSTOM_QUEUE_CRITERIA;
#endif

/*****************************************************************************
 *
 * Functions
 *
 *****************************************************************************/

OCTET _CustomQueueMatchCriteria(CUSTOM_QUEUE_CRITERIA* pxCustomQueueStruct, NETPAYLOAD* pxPayload, NETPACKETACCESS* pxAccess);
DWORD _CustomQueueClearCriteriaStruct(CUSTOM_QUEUE_CRITERIA* pxCustomQueueCriteriaStruct);
void _CustomQueuePrintCriteriaStruct(CUSTOM_QUEUE_CRITERIA* pxCustomQueueCriteriaStruct);


