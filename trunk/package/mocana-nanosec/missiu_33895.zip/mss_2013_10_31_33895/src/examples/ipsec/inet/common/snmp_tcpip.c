/*
 * snmp_tcpip.c
 *
 * main tcp ip SNMP support
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "netmain_flavor.h"
#include "snmp_tcpip_data.h"
#include "snmp_tcpip_rtn.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "../include/socket_inet.h"
#include "netdefs.h"
#include "setupnet.h"


/*****************************************************************************
 *
 * Typedefs
 *
 *****************************************************************************/

typedef struct get_data_element
{
  DWORD dwLookupCode;
  DWORD *pdwData;
} SNMP_GET_DATA_LOOKUP_ELEMENT;

/*****************************************************************************
 *
 * Globals
 *
 *****************************************************************************/
/* Structure holding mib-2 data */
SNMP_TCPIP_DATA xTcpipData;

/* Number of physical interfaces */
/* The numbering of the physical interfaces has been taken from netif.c
   i.e. Default is one ethernet interface, numbered 0.
        mhx adds an ethernet interface -   numbered 1
        dsl adds an atm interface -        numbered 1 (logical 1+) */

OCTET aoEtherDescr[] = "Eth1";
#ifdef MHX
OCTET oNumPhysIfs = 2;
OCTET aoEther2Descr[] = "Eth2";
#else
#ifdef NET_DSL
OCTET oNumPhysIfs = 2;
OCTET aoAtmDescr[] = "ATM";
#else
OCTET oNumPhysIfs = 1;
#endif
#endif

/* !!! SB Can this be done, xTcpIp is not in the same file !!! */
const SNMP_GET_DATA_LOOKUP_ELEMENT GetDataTable[] =
{
  { CONF_ipForwDatagrams, (DWORD *)&xTcpipData.ipForwDatagrams },
  { CONF_ipReasmTimeout, (DWORD *)&xTcpipData.ipReasmTimeout },
  { CONF_ipReasmReqds, (DWORD *)&xTcpipData.ipReasmReqds },
  { CONF_ipReasmOKs, (DWORD *)&xTcpipData.ipReasmOKs },
  { CONF_ipReasmFails, (DWORD *)&xTcpipData.ipReasmFails },
  { CONF_ipFragOKs, (DWORD *)&xTcpipData.ipFragOKs },
  { CONF_ipFragFails, (DWORD *)&xTcpipData.ipFragFails },
  { CONF_ipFragCreates, (DWORD *)&xTcpipData.ipFragCreates },
  { CONF_ipInReceives, (DWORD *)&xTcpipData.ipInReceives },
  { CONF_ipInHdrErrors, (DWORD *)&xTcpipData.ipInHdrErrors },
  { CONF_ipInAddrErrors, (DWORD *)&xTcpipData.ipInAddrErrors },
  { CONF_ipInUnknownProtos, (DWORD *)&xTcpipData.ipInUnknownProtos },
  { CONF_ipInDiscards, (DWORD *)&xTcpipData.ipInDiscards },
  { CONF_ipInDelivers, (DWORD *)&xTcpipData.ipInDelivers },
  { CONF_ipOutRequests, (DWORD *)&xTcpipData.ipOutRequests },
  { CONF_ipOutDiscards, (DWORD *)&xTcpipData.ipOutDiscards },
  { CONF_ipRoutingDiscards, (DWORD *)&xTcpipData.ipRoutingDiscards },
  { CONF_ipForwarding, (DWORD *)&xTcpipData.ipForwarding },
  { CONF_ipDefaultTTL, (DWORD *)&xTcpipData.ipDefaultTTL },
  { CONF_icmpInMsgs, (DWORD *)&xTcpipData.icmpInMsgs },
  { CONF_icmpInErrors, (DWORD *)&xTcpipData.icmpInErrors },
  { CONF_icmpInDestUnreachs, (DWORD *)&xTcpipData.icmpInDestUnreachs },
  { CONF_icmpInTimeExcds, (DWORD *)&xTcpipData.icmpInTimeExcds },
  { CONF_icmpInParmProbs, (DWORD *)&xTcpipData.icmpInParmProbs },
  { CONF_icmpInSrcQuenchs, (DWORD *)&xTcpipData.icmpInSrcQuenchs },
  { CONF_icmpInRedirects, (DWORD *)&xTcpipData.icmpInRedirects },
  { CONF_icmpInEchos, (DWORD *)&xTcpipData.icmpInEchos },
  { CONF_icmpInEchoReps, (DWORD *)&xTcpipData.icmpInEchoReps },
  { CONF_icmpInTimestamps, (DWORD *)&xTcpipData.icmpInTimestamps },
  { CONF_icmpInAddrMasks, (DWORD *)&xTcpipData.icmpInAddrMasks },
  { CONF_icmpOutMsgs, (DWORD *)&xTcpipData.icmpOutMsgs },
  { CONF_icmpOutErrors, (DWORD *)&xTcpipData.icmpOutErrors },
  { CONF_icmpOutDestUnreachs, (DWORD *)&xTcpipData.icmpOutDestUnreachs },
  { CONF_icmpOutEchos, (DWORD *)&xTcpipData.icmpOutEchos },
  { CONF_icmpOutEchoReps, (DWORD *)&xTcpipData.icmpOutEchoReps },
  { CONF_tcpRtoAlgorithm, (DWORD *)&xTcpipData.tcpRtoAlgorithm },
  { CONF_tcpRtoMin, (DWORD *)&xTcpipData.tcpRtoMin },
  { CONF_tcpRtoMax, (DWORD *)&xTcpipData.tcpRtoMax },
  { CONF_tcpMaxConn, (DWORD *)&xTcpipData.tcpMaxConn },
  { CONF_tcpActiveOpens, (DWORD *)&xTcpipData.tcpActiveOpens },
  { CONF_tcpPassiveOpens, (DWORD *)&xTcpipData.tcpPassiveOpens },
  { CONF_tcpAttemptFails, (DWORD *)&xTcpipData.tcpAttemptFails },
  { CONF_tcpEstabResets, (DWORD *)&xTcpipData.tcpEstabResets },
  { CONF_tcpCurrEstab, (DWORD *)&xTcpipData.tcpCurrEstab },
  { CONF_tcpInSegs, (DWORD *)&xTcpipData.tcpInSegs },
  { CONF_tcpOutSegs, (DWORD *)&xTcpipData.tcpOutSegs },
  { CONF_tcpRetransSegs, (DWORD *)&xTcpipData.tcpRetransSegs },
  { CONF_tcpInErrs, (DWORD *)&xTcpipData.tcpInErrs },
  { CONF_tcpOutRsts, (DWORD *)&xTcpipData.tcpOutRsts },
  { CONF_udpInDatagrams, (DWORD *)&xTcpipData.udpInDatagrams },
  { CONF_udpNoPorts, (DWORD *)&xTcpipData.udpNoPorts },
  { CONF_udpInErrors, (DWORD *)&xTcpipData.udpInErrors },
  { CONF_udpOutDatagrams, (DWORD *)&xTcpipData.udpOutDatagrams },
  {0,NULL}  /* IMPORTANT = use NULL pointer to mark end of lookup table */
};


/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/


/***************************************************************************
 *    called from by SNMP Agent to retrieve pertinent data
 *
 *    par:    DWORD dwCode - Enumerated value for data to get
 *            void *pValue - return data
 *
 *    ret:    DWORD - nos bytes in pValue
 ****************************************************************************/
DWORD TcpipSnmpGetData(DWORD dwCode, void *pValue)
{
  int ilen = 0;
  DWORD i=0;


  /* search lookup table */
  *((DWORD *)pValue) = 0;
  while (GetDataTable[i].pdwData != NULL) {
    if (dwCode == GetDataTable[i].dwLookupCode) {
      *((DWORD *)pValue) = *(GetDataTable[i].pdwData);
      ilen = sizeof(DWORD);
      break;
    }
    i++;
  }
  if (dwCode == CONF_ifNumber) {
    *((DWORD *)pValue) = (DWORD)oNumPhysIfs;
    ilen = sizeof(DWORD);
  }
  /* Make sure ipDefaultTTL is in range */
  else if (dwCode == CONF_ipDefaultTTL) {
    if ((*((DWORD *)pValue)<1) || ((*((DWORD *)pValue)>255))) {
      *((DWORD *)pValue) = (DWORD) 64;
      ilen = sizeof(DWORD);
    }
  }

  /* Make sure ipForwarding is in range */
  else if (dwCode == CONF_ipForwarding) {
#ifdef NET_MULTIF
    {
    BOOL bBridgeOnly;

    SetupNetCheckBridgeOnly(&bBridgeOnly, -1);  /* Check whether we are just a bridge */
    if (TRUE == bBridgeOnly)
      *((DWORD *)pValue) = (DWORD) IP_NOT_FORWARDING;
    else
      *((DWORD *)pValue) = (DWORD) IP_FORWARDING;  /* Forwarding */
    ilen = sizeof(DWORD);
    }
#else
      *((DWORD *)pValue) = (DWORD) IP_NOT_FORWARDING;
      ilen = sizeof(DWORD);
#endif
  }


  return ilen;
}

/***************************************************************************
 *    called from by SNMP Agent to set pertinent data
 *
 *    par:    DWORD dwCode - Enumerated value for data to get
 *            void *pValue - data to set
 *
 *    ret:    DWORD - Standard MIB error messages, ususally NO_ERROR,
 *                                                       or READ_ONLY,
 *                                                       or NO_SUCH_NAME
 ****************************************************************************/
DWORD TcpipSnmpSetData(DWORD dwCode, void *pValue)
{
  int ilen = NO_SUCH_NAME; /* assume an error first */
#ifndef NDEBUG
  extern char *in_ntoa(DWORD in);
#endif
  switch (dwCode)
    {
    case CONF_ipForwarding:
      ilen = READ_ONLY;
      break;

    case CONF_ipDefaultTTL:
      /* Should set the default Ttl for the unit */
      break;

    default :
      /* if nothing matches then return error len of NO_SUCH_NAME */
      /*            *((DWORD *)pValue) = 0;*/
      ilen = NO_SUCH_NAME;
      break;
    }
  return ilen;
}


/***************************************************************************
 *    called from by SNMP Agent to retrieve an entire Address Entry table
 *
 *    par:    void **ppvData - area of memory for placing the Address
 *            Entry table
 *            DWORD *pdwNosStructs - dimension of array
 *            DWORD *pdwStructSize - size of array element
 *
 *    ret:    DWORD - nos bytes in pValue
 *
 *    (see rfc1213)
 ****************************************************************************/
DWORD TcpipSnmpGetAdEntTable(void **ppvData, DWORD *pdwNosStructs, DWORD *pdwStructSize)
{
#if 0
//  struct ADD_ENT_TABLE_ENTRY *pxAdEnt;
//  /* Find the dimension of the array, and the size of each element */
//  *pdwStructSize = sizeof(struct ADD_ENT_TABLE_ENTRY);
//  *pdwNosStructs = ;

//  /* Allocate memory for the array (freed by snmp agent) */
//  *ppvData = MALLOC((*pdwNosStructs) * (*pdwStructSize));

//  /* Fill the array */
//  pxAdEnt = (struct ADD_ENT_TABLE_ENTRY *)(*ppvData);
//  ...
//  pxAdEnt++;
#endif
  return TCPIPSNMPGETDATAOK;
}



/***************************************************************************
 *    called from by SNMP Agent to retrieve an entire IfTableEntry table
 *
 *    par:    void **ppvData - area of memory for placing the table
 *            DWORD *pdwNosStructs - dimension of array
 *            DWORD *pdwStructSize - size of array element
 *
 *    ret:    DWORD - nos bytes in pValue
 *
 *    (see rfc1573)
 ****************************************************************************/
DWORD TcpipSnmpGetIfTable(void **ppvData, DWORD *pdwNosStructs, DWORD *pdwStructSize)
{
  struct IF_TABLE_ENTRY *pxIfTable;
  DWORD  dwIndex;
  OCTET oIdx;

  /* Find the dimension of the array, and the size of each element */
  *pdwStructSize = sizeof(struct IF_TABLE_ENTRY);
  *pdwNosStructs = (DWORD)oNumPhysIfs;

  /* Allocate memory for the array (freed by snmp agent) */
  *ppvData = MALLOC((*pdwNosStructs) * (*pdwStructSize));

  /* Defaults - fill out first time only*/
  if (xTcpipData.ifNum[ETH_SNMP_IF_NUM].ifAdminStatus == 0) {
    for (oIdx=0; oIdx <=1; oIdx++) {
      /* Ethernet */
      xTcpipData.ifNum[oIdx].ifLastChange  = 0x0;
      xTcpipData.ifNum[oIdx].ifMtu         = (DWORD)1500;
      xTcpipData.ifNum[oIdx].ifSpecific[0] = 0;
      xTcpipData.ifNum[oIdx].ifSpecific[1] = 0;
      xTcpipData.ifNum[oIdx].ifSpecific[2] = 0xffffffff;
      MOC_MEMCPY((ubyte *)xTcpipData.ifNum[oIdx].ifPhysAddress, (ubyte *)xNetWrapper.pxIfConf[oIdx].aoHWAddr, NET_ADDR_LEN);
    }

    MOC_MEMCPY((ubyte *)xTcpipData.ifNum[ETH_SNMP_IF_NUM].ifDescr,(ubyte *) aoEtherDescr, 4);
    xTcpipData.ifNum[ETH_SNMP_IF_NUM].ifDescr[4] = 0;
    xTcpipData.ifNum[ETH_SNMP_IF_NUM].ifType = (DWORD)6; /*eth */
#ifdef NET_DSL
    MOC_MEMCPY((ubyte *)xTcpipData.ifNum[ATM_SNMP_IF_NUM].ifDescr,(ubyte *) aoAtmDescr, 3);
    xTcpipData.ifNum[ATM_SNMP_IF_NUM].ifDescr[3] = 0;
    xTcpipData.ifNum[ATM_SNMP_IF_NUM].ifType = (DWORD)37; /*atm */
#endif
#ifdef MHX
    MOC_MEMCPY((ubyte *)xTcpipData.ifNum[ETH2_SNMP_IF_NUM].ifDescr,(ubyte *) aoEther2Descr, 4);
    xTcpipData.ifNum[ETH2_SNMP_IF_NUM].ifDescr[4] = 0;
    xTcpipData.ifNum[ETH2_SNMP_IF_NUM].ifType = (DWORD)6; /* eth */
#endif
  }

  /* Fill the array */
  pxIfTable = (struct IF_TABLE_ENTRY *)(*ppvData);
  for (dwIndex = 0; dwIndex < oNumPhysIfs; dwIndex++) {
    pxIfTable->dwIfIndex            = dwIndex+1;
    MOC_MEMCPY(pxIfTable->oIfDescr,       xTcpipData.ifNum[dwIndex].ifDescr, SNMP_IFDESC_LEN);
    pxIfTable->dwIfType             = xTcpipData.ifNum[dwIndex].ifType;
    pxIfTable->dwIfMtu              = xTcpipData.ifNum[dwIndex].ifMtu;
    pxIfTable->dwIfSpeed            = xTcpipData.ifNum[dwIndex].ifSpeed;
    MOC_MEMCPY((ubyte *)pxIfTable->oIfPhysAddress,(ubyte *) xTcpipData.ifNum[dwIndex].ifPhysAddress, NET_ADDR_LEN);
    pxIfTable->dwIfAdminStatus      = xTcpipData.ifNum[dwIndex].ifOperStatus;
    pxIfTable->dwIfOperStatus       = xTcpipData.ifNum[dwIndex].ifOperStatus;
    pxIfTable->dwIfLastChange       = xTcpipData.ifNum[dwIndex].ifLastChange;
    pxIfTable->dwIfInOctets         = xTcpipData.ifNum[dwIndex].ifInOctets;
    pxIfTable->dwIfInUcastPkts      = xTcpipData.ifNum[dwIndex].ifInUcastPkts;
    pxIfTable->dwIfInNUcastPkts     = xTcpipData.ifNum[dwIndex].ifInNUcastPkts;
    pxIfTable->dwIfInDiscards       = xTcpipData.ifNum[dwIndex].ifInDiscards;
    pxIfTable->dwIfInErrors         = xTcpipData.ifNum[dwIndex].ifInErrors;
    pxIfTable->dwIfInUnknownProtos  = xTcpipData.ifNum[dwIndex].ifInUnknownProtos;
    pxIfTable->dwIfOutOctets        = xTcpipData.ifNum[dwIndex].ifOutOctets;
    pxIfTable->dwIfOutUcastPkts     = xTcpipData.ifNum[dwIndex].ifOutUcastPkts;
    pxIfTable->dwIfOutNUcastPkts    = xTcpipData.ifNum[dwIndex].ifOutNUcastPkts;
    pxIfTable->dwIfOutDiscards      = xTcpipData.ifNum[dwIndex].ifOutDiscards;
    pxIfTable->dwIfOutErrors        = xTcpipData.ifNum[dwIndex].ifOutErrors;
    pxIfTable->dwIfOutQLen          = xTcpipData.ifNum[dwIndex].ifOutQLen;
    MOC_MEMCPY((ubyte *)pxIfTable->dwIfSpecific, (ubyte *)  xTcpipData.ifNum[dwIndex].ifSpecific, 15 * sizeof(DWORD));
    pxIfTable++;
  }

  return TCPIPSNMPGETDATAOK;
}

/***************************************************************************
 *    called from by SNMP Agent to retrieve the ifXTable
 *
 *    par: void **ppvData - area of memory for placing the table
 *         DWORD *pdwNosStructs - dimension of array
 *         DWORD *pdwStructSize - size of array element
 *
 *    ret: DWORD - 1 for no error, -1 for an error (SNMP_ACCESS_ERROR)
 *
 *    (see rfc1573)
 ****************************************************************************/
DWORD TcpipSnmpGetifXTable(void **ppvData, DWORD *pdwNosStructs, DWORD *pdwStructSize)
{
  struct IFX_TABLE_ENTRY *pxIfX;
  DWORD dwIndex;

  /* Find the dimension of the array, and the size of each element */
  *pdwStructSize = sizeof(struct IFX_TABLE_ENTRY);
  *pdwNosStructs = (DWORD)oNumPhysIfs;

  /* Allocate memory for the array (freed by snmp agent) */
  *ppvData = MALLOC((*pdwNosStructs) * (*pdwStructSize));
  MOC_MEMSET((ubyte *)*ppvData, 0, (*pdwNosStructs) * (*pdwStructSize));

  /* Fill the array */
  pxIfX = (struct IFX_TABLE_ENTRY *)(*ppvData);
  for (dwIndex = 0; dwIndex < oNumPhysIfs; dwIndex++) {
    pxIfX->dwifIndex = dwIndex+1;
    if (dwIndex == 0) {
      MOC_MEMCPY((ubyte *)pxIfX->oifName,(ubyte *) aoEtherDescr, 5);
    } else {
#ifdef NET_DSL
      MOC_MEMCPY((ubyte *)pxIfX->oifName,(ubyte *) aoAtmDescr, 4);
#endif
#ifdef MHX
      MOC_MEMCPY((ubyte *)pxIfX->oifName, (ubyte *)aoEther2Descr, 5);
#endif
    }
    pxIfX->dwifInMulticastPkts      = xTcpipData.ifNum[dwIndex].dwifInMulticastPkts;
    pxIfX->dwifInBroadcastPkts      = xTcpipData.ifNum[dwIndex].dwifInBroadcastPkts;
    pxIfX->dwifOutMulticastPkts     = xTcpipData.ifNum[dwIndex].dwifOutMulticastPkts;
    pxIfX->dwifOutBroadcastPkts     = xTcpipData.ifNum[dwIndex].dwifOutBroadcastPkts;
    pxIfX->dwifLinkUpDownTrapEnable = xTcpipData.ifNum[dwIndex].dwifLinkUpDownTrapEnable;
    if (pxIfX->dwifLinkUpDownTrapEnable == 0) pxIfX->dwifLinkUpDownTrapEnable = 1;
    pxIfX->dwifHighSpeed            = xTcpipData.ifNum[dwIndex].dwifHighSpeed;
    pxIfX->dwifPromiscuousMode      = xTcpipData.ifNum[dwIndex].dwifPromiscuousMode;
    if (pxIfX->dwifPromiscuousMode == 0) pxIfX->dwifPromiscuousMode = LINKUPDOWNTRAPS_ENABLED;
    pxIfX->dwifConnectorPresent     = xTcpipData.ifNum[dwIndex].dwifConnectorPresent;
    if (pxIfX->dwifConnectorPresent == 0) pxIfX->dwifConnectorPresent = 1;
    pxIfX++;
  }

  return TCPIPSNMPGETDATAOK;
}



/***************************************************************************
 *    called from by SNMP Agent to determine ifOperStatus of an interface
 *
 *    par:    DWORD dwIf - interface number
 *
 *    ret:    DWORD dwIfStatus - 1 active
 *                               2 notInService
 ****************************************************************************/
DWORD TcpipSnmpGetIfOperStatus(DWORD dwIf)
{
  DWORD dwTemp = xTcpipData.ifNum[dwIf].ifOperStatus;
  /* comply with legal values  1==linkup, 2==linkdown */
  if (dwTemp != 1)
    dwTemp = 2;
  return dwTemp;
}
