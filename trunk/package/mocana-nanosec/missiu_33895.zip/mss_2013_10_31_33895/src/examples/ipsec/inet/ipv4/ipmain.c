/*
 * ipmain.c
 *
 * Implements the IP stack
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "ip_flavor.h"
#include "../include/socket_inet.h"
#include "../include/socket.h" /* sockaddr */
#include "../include/in.h" /* sockaddr_in */
#include "../include/if.h"     /* ifreq */
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"   /* NetMalloc; NetFree; */
#include "iptable.h"
#include "routing_table.h"
#include "netnetwork.h"
#include "ip.h"
#include "ipdefs.h"
#include "ipdbg.h"
#include "ecc.h" /* Checksum16 */
#include "netsnmp.h"
#include "snmp_tcpip_data.h"
#include "netdefs.h"
#include "ethernet.h"  /* VLAN priority mask */

#ifdef NEW_ICMP_MSG_ADDED
#include "icmp.h"
#endif

#include "../include/socket.h"
#include "../include/in.h"

#ifndef ROUTER_MAXNUM_IF
#define ROUTER_MAXNUM_IF            NUM_IFS
#endif


#include "router.h"
#include "router_defs.h"
#include "netdefs.h"
#include "meter.h"

#ifndef IP1TON_MAXIF
#define IP1TON_MAXIF            NUM_IFS
#endif

#include "ip1ton_defs.h"

#ifndef IFNUMMAX
#define IFNUMMAX    NUM_IFS
#endif

#include "ipfrag_defs.h"

/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/

IP_DBG_VAR(DWORD g_dwIpDebugLevel = ERROR);
IP_DBG_VAR(DWORD dbg_dwIpInstanceDestroyLine = 0);
IP_DBG_VAR(DWORD dbg_dwIpRxCbkLine = 0);
IP_DBG_VAR(DWORD dbg_dwIPRcvDropped = 0);

/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/
#define N_MCAST_GROUPS_MAX 255

/* store number of 32bit quantities in the packet */
#define N_32BITS_IP_HDR_LEN (IPDEFAULT_HDRSIZE>>2)


/*****************************************************************************
 *
 * Static variables
 *
 *****************************************************************************/
static WORD wIpDatagramId = 0;


/*****************************************************************************
 *
 * Local Function
 *
 *****************************************************************************/

/*
 * IpHeaderFill
 *  Fill IP specific header info -which has not been filled
 *  already by the caller: HdrLen, TotalLen,DatagramId, FragOffset,
 *  Version
 *
 *  Args:
 *   hIp                        Instance handle
 *   pxPacket                   Packet pointer
 *   wOffset                    IP PDU offset
 *   pxNetworkId                   pointer to a net_dst structure
 *   oProtocol                  ID to allow rx side to demultiplex UDP,TCP et al
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
static LONG
_IpHeaderFill(H_NETINSTANCE hIp,
              NETPACKET *pxPacket, NETPACKETACCESS *pxPktAccess,
              NETWORKID *pxNetworkId)
{
  /* dwSrcAddr filled in above
   * dwDstAddr MUST BE SET by caller of IP
   * oIpHdrLen */
  pxNetworkId->oIpHdrLen  = IPDEFAULT_HDRSIZE+pxNetworkId->oIpOptionLen;
  /* wTotalLen */
  pxNetworkId->wTotalLen  = pxPktAccess->wLength + IPDEFAULT_HDRSIZE +
                            pxNetworkId->oIpOptionLen;
  /* wDatagramId */
  pxNetworkId->wDatagramId = wIpDatagramId++;
  /* wFragOffset */
  pxNetworkId->wFragOffset= 0; /* no fragmentation on tx data from stack */

  /* *poIpOption & oIpOptionLen MUST BE SET by caller of IP
   * oProtocol */
  /* oToS & oTtL MUST BE SET */
  /* oVersion */
  pxNetworkId->oVersion   = 4;                   /* IPv4 */
  return 0;
}

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/

/*
 * IpInitialize
 *  Initialize the IP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpInitialize(void)
{

  /* Initialise DEBUG symbol to ERROR */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_ERROR);
  return 0;
}

/*
 * IpTerminate
 *  Terminate the IP Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpTerminate(void)
{

  return 0;
}

/*
 * IpInstanceCreate
 *  Creates a IP Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IpInstanceCreate(void)
{
  IPSTATE *pxIp;

  pxIp = (IPSTATE *)MALLOC(sizeof(IPSTATE));
  ASSERT(pxIp != NULL);
  MOC_MEMSET((ubyte *)pxIp, 0, sizeof(IPSTATE));
  IP_SET_COOKIE(pxIp);

  return (H_NETINSTANCE)pxIp;
}

/*
 * IpInstanceDestroy
 *  Destroy a IP Instance
 *
 *  Args:
 *   hIp                       IP instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpInstanceDestroy(H_NETINSTANCE hIp)
{
  IPSTATE *pxIp = (IPSTATE *)hIp;

  IP_CHECKPOINT(dbg_dwIpInstanceDestroyLine);
  ASSERT(pxIp != NULL);

  IP_CHECKPOINT(dbg_dwIpInstanceDestroyLine);
  if (pxIp->pxUl != NULL) {
    IP_CHECKPOINT(dbg_dwIpInstanceDestroyLine);
    FREE(pxIp->pxUl);
  }

  IP_CHECKPOINT(dbg_dwIpInstanceDestroyLine);

  IP_UNSET_COOKIE(pxIp);

  IP_CHECKPOINT(dbg_dwIpInstanceDestroyLine);

  FREE(pxIp);

  IP_CHECKPOINT(dbg_dwIpInstanceDestroyLine);

  return 0;
}

/*
 * IpInstanceSet
 *  Set a IP Instance Option
 *
 *  Args:
 *   hIp                       IP instance
 *   oOption                   Option
 *   hData                     Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpInstanceSet(H_NETINSTANCE hIp,OCTET oOption,
                   H_NETDATA hData)
{
  return NETERR_NOERR;
}

/*
 * IpInstanceQuery
 *  Query a IP Instance Option
 *
 *  Args:
 *   hIp                       IP instance
 *   oOption                   Option
 *   phData                    Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpInstanceQuery(H_NETINSTANCE hIp,OCTET oOption,
                      H_NETDATA *phData)
{
  return NETERR_NOERR;
}

/*
 * IpInstanceMsg
 *  Send a msg to a IP instance
 *
 *  Args:
 *   hIp                       IP instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG
IpInstanceMsg(H_NETINSTANCE hIp,
              OCTET oMsg,
              H_NETDATA hData)
{
  return NETERR_NOERR;
}

/*
 * IpInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer: UDP,TCP,ICMP,IGMP, etc
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hIp                       IP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IpInstanceULInterfaceCreate(H_NETINSTANCE hIp)
{
  IPSTATE *pxIp = (IPSTATE *)hIp;

  ASSERT(pxIp != NULL);
  IP_CHECK_STATE(pxIp);

  {
     IP_UL *pxTempUl;

     pxTempUl = (IP_UL *)MALLOC((pxIp->oUlNumber+1)*sizeof(IP_UL));

     ASSERT(pxTempUl);
     MOC_MEMCPY((ubyte *)pxTempUl,(ubyte *)(pxIp->pxUl),
                pxIp->oUlNumber*sizeof(IP_UL));
     FREE(pxIp->pxUl);
     pxIp->pxUl = pxTempUl;
     pxIp->oUlNumber++;
  }

  return (H_NETINTERFACE)pxIp->oUlNumber;
}

/*
 * IpInstanceULInterfaceDestroy
 *  Destroy a IP UL interface
 *
 *  Args:
 *   hIp                       IP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successful
 */
LONG IpInstanceULInterfaceDestroy(H_NETINSTANCE hIp,
                                   H_NETINTERFACE hInterface)
{
  IPSTATE *pxIp = (IPSTATE *)hIp;
  IP_UL *pxUl;

  ASSERT(pxIp != NULL);
  IP_CHECK_STATE(pxIp);
  ASSERT((OCTET)hInterface<=pxIp->oUlNumber);

  pxUl = (pxIp->pxUl + ((OCTET)hInterface -1));

  /* Just set the protocol Id in the UL structure to 0.
     We assume this only happens at termination anyway */
  pxUl->wRoutingId = 0;

  return 0;
}

/*
 * IpInstanceULInterfaceIoctl
 *  Ip UL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and nettransport.h
 *  for precisions
 *
 *  Args:
 *   hIp                         IP instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IpInstanceULInterfaceIoctl(H_NETINSTANCE hIp,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData)
{
  IPSTATE *pxIp = (IPSTATE *)hIp;
  IP_UL *pxUl;
  LONG lReturn = 0;

  ASSERT(pxIp != NULL);
  IP_CHECK_STATE(pxIp);
  ASSERT((OCTET)hULInterface <= pxIp->oUlNumber);
  pxUl = (pxIp->pxUl + ((OCTET)hULInterface -1));

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IP_DBGP(REPETITIVE,
          "IpInstanceULInterfaceIoctl: If: %x , oIoctl: %x\n",
          (OCTET)hULInterface,oIoctl);*/
    DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, "IpInstanceULInterfaceIoctl: If: ", (OCTET)hULInterface,
                           ",oIoctl : ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* ignore those */
    break;
  case NETINTERFACEIOCTL_SETHINST:
    pxUl->hUL = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxUl->pfnRxCbk = (PFN_NETRXCBK)hData;
    break;

  case NETINTERFACEIOCTL_SETROUTINGID:
    pxUl->wRoutingId = (WORD)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxUl->hIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = -1;
    ASSERT(0);
  }

  return lReturn;
}



/*
 * IpInstanceWrite
 *  Ip Instance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hIp                        Ip Instance handle
 *   hIf                        Upper Layer interface handle
 *   pxPacket                   Packet pointer
 *   wOffset                    IP PDU offset
 *   hData                      pointer to a net_dst structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG IpInstanceWrite(H_NETINSTANCE    hIp,
                     H_NETINTERFACE   hIf,
                     NETPACKET        *pxPacket,
                     NETPACKETACCESS  *pxPktAccess,
                     H_NETDATA        hData)
{
  IPSTATE    *pxIp = (IPSTATE *)hIp;
  NETPAYLOAD *pxPayload;
  WORD       wGivenLength = pxPktAccess->wLength;
  NETWORKID  *pxNetworkId = (NETWORKID*)hData;

  IP_CHECK_STATE(pxIp);
  NETPACKET_CHECK(pxPacket);
  ASSERT((OCTET)hIf<=pxIp->oUlNumber);

  pxPayload = pxPacket->pxPayload;

  SNMP( xTcpipData.ipOutRequests++ );       /* inc. SNMP count */

  if (pxNetworkId->dwGatewayAddr == 0) {
    /* If the gateway address is not set, then
       try to get it */
    ROUTEENTRY xRoute;

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_NORMAL))
    {
      /*IP_DBGP(NORMAL, "IpInstanceWrite: Gateway address not set - looking it up\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IpInstanceWrite: Gateway address not set - looking it up");
    }

    /* Not our address: Check the route to the remote host */
#ifdef _RADIX_ROUTING_ON_
    xRoute.xRouteNodes->RadixNodeKey = pxNetworkId->dwDstAddr;
    xRoute.xRouteNodes->RadixNodeMask = 0;
#else
    xRoute.dwDstAddr = pxNetworkId->dwDstAddr;
#endif
    xRoute.oIfIdx = pxNetworkId->oIfIdx;
    xRoute.wVlan = pxNetworkId->wVlan;
    xRoute.eDstAddrType = pxNetworkId->eDstAddrType;

    if (RoutingTableMsg(ROUTINGTABLEMSG_FINDROUTE,
                        (H_NETDATA)&(xRoute)) < 0) {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_NORMAL))
      {
        /*IP_DBGP(NORMAL, "IpInstanceWrite: Gateway address not set - looking it up\n");*/
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IpInstanceWrite: Gateway not found deleting packet");
      }
      NETPAYLOAD_DELUSER(pxPayload);
      /* indicate an error occurred & that caller can delete packet */
      SNMP( xTcpipData.ipOutDiscards++ );
      return NETERR_UNSUPPORTED;
    } else {
      pxNetworkId->dwGatewayAddr = xRoute.dwGateway;
      pxNetworkId->oIfIdx = xRoute.oIfIdx;
      pxNetworkId->wVlan = xRoute.wVlan;
      pxNetworkId->eDstAddrType = xRoute.eDstAddrType;
    }
  }

  /*
   * Set the packet priority
   */
  if (pxNetworkId->wVlan != NETVLAN_ANY &&
      (((pxNetworkId->wVlan & ETHPRI_MASK) >> ETHPRI_SHIFT) >
      NETVLAN_PRIORITY_LIMIT)) {
    pxPktAccess->oPriority = (OCTET)HIGH_PRIORITY;
  } else if (pxNetworkId->oToS & NETTOS_PRIORITY_MASK) {
    pxPktAccess->oPriority = (OCTET)HIGH_PRIORITY;
  } else {
    pxPktAccess->oPriority = (OCTET)LOW_PRIORITY;
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_NORMAL))
  {
    /*IP_DBGP(NORMAL,
          "IpInstanceWrite:oIfIdx=%d,Dst=%ld.%ld.%ld.%ld,Src=%ld.%ld.%ld.%ld, "
          "ip len=%d, prot=%s, priority=%d\n",
          pxNetworkId->oIfIdx,
          IPADDRDISPLAY(pxNetworkId->dwDstAddr),
          IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
          wGivenLength,
          IpProtoToString(pxNetworkId->oProtocol),
          pxPktAccess->oPriority);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpInstanceWrite:oIfIdx = ", pxNetworkId->oIfIdx);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Dst = ", pxNetworkId->dwDstAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Src = ", pxNetworkId->dwSrcAddr);
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", ip len = ", wGivenLength);
    DEBUG_PRINT(DEBUG_MOC_IPV4, ", prot = ");
    DEBUG_PRINT(DEBUG_MOC_IPV4, IpProtoToString(pxNetworkId->oProtocol));
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", priority = ",  pxPktAccess->oPriority);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /* IP module fills in any necessary fields in the NETWORKID structure,
   * but no longer writes a header - IP1toN module does this
   */
  if (0 == _IpHeaderFill(hIp, pxPacket, pxPktAccess, (NETWORKID *)hData)) {

    /* If the LL accepts or partially accepts the pkt (i.e. zero or positive
     * return value, then we let the sending UL know we have accepted the packet
     * On partial acceptance or error conditions we free the packet.
     * Send nothing lower layer as hData.
     */
    ASSERT(pxIp->pfnLLWrite != NULL);
    pxIp->pfnLLWrite(pxIp->hLL,pxIp->hIPLLIf,
                     pxPacket,pxPktAccess,
                     (H_NETDATA)pxNetworkId);
    return wGivenLength; /* accept the full packet */
  } else {
    NETPAYLOAD_DELUSER(pxPayload);
    SNMP( xTcpipData.ipOutDiscards++ );
    /* indicate an error occurred & that caller can delete packet */
    return NETERR_UNSUPPORTED;
  }
}


/*
 * IpInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIp                       IP instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IpInstanceLLInterfaceCreate(H_NETINSTANCE hIp)
{
  return 1;
}

/*
 * IpInstanceLLInterfaceDestroy
 *  Destroy a IP LL interface
 *
 *  Args:
 *   hIp                       IP instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG IpInstanceLLInterfaceDestroy(H_NETINSTANCE hIp,
                                  H_NETINTERFACE hInterface)
{
  return 0;
}

/*
 * IpInstanceLLInterfaceIoctl
 *  IP LL Interface (socket) Ioctl function. See the
 *  IOCTL definitions in netcommon.h and netransport.h
 *  for precisions
 *
 *  Args:
 *   hIp                          Ip instance handle
 *   hLLInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IpInstanceLLInterfaceIoctl(H_NETINSTANCE hIp,
                                H_NETINTERFACE hLLInterface,
                                OCTET oIoctl,
                                H_NETDATA hData)
{
  IPSTATE *pxIp = (IPSTATE *)hIp;
  LONG lReturn = 0;

  ASSERT(pxIp != NULL);
  IP_CHECK_STATE(pxIp);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IP_DBGP(REPETITIVE, "IpInstanceLLInterfaceIoctl: oIoctl: %x\n", oIoctl);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpInstanceLLInterfaceIoctl: oIoctl:", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oIoctl) {

  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* Ignore these */
    break;
  case NETINTERFACEIOCTL_SETHINST:
    pxIp->hLL = (H_NETINSTANCE)hData;
    break;
  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIp->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIp->hIPLLIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = -1;
    ASSERT(0);
  }

  return lReturn;
}

/*
 * IpInstanceRcv
 *  Ip Instance Rcv function
 *   Ip Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIp                        Ud Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    wOffset                    IP PDU offset.
 *    hData                      unused
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG IpInstanceRcv(H_NETINSTANCE    hIp,
                   H_NETINTERFACE   hIf,
                   NETPACKET        *pxPacket,
                   NETPACKETACCESS  *pxPktAccess,
                   H_NETDATA        hData)
{
  IPSTATE         *pxIp = (IPSTATE *)hIp;
  IP_UL           *pxUl;
  NETPAYLOAD      *pxPayload;
  WORD            wRxedLen = pxPktAccess->wLength;
  E_ADDRTYPE      eDstAddrType;
  INT             i;
  NETWORKID       *pxNetworkId = (NETWORKID *)hData;
#ifdef NEW_ICMP_MSG_ADDED
  ICMPMSGDATA     xIcmpMsgData;
#endif


  IP_CHECK_STATE(pxIp);
  NETPACKET_CHECK(pxPacket);
  ASSERT(pxNetworkId != NULL);

  pxPayload = pxPacket->pxPayload;

  SNMP(xTcpipData.ipInReceives++);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_NORMAL))
  {
    /*IP_DBGP(NORMAL,
          "IpInstanceRcv:oIfIdx=%d,Dst=%ld.%ld.%ld.%ld,Src=%ld.%ld.%ld.%ld,"
          "eAddrType = %s, ip len=%d, prot=%s, priority=%d\n",
          pxNetworkId->oIfIdx,
          IPADDRDISPLAY(pxNetworkId->dwDstAddr),
          IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
          IpAddressTypeToString(pxNetworkId->eDstAddrType),
          wRxedLen,
          IpProtoToString(pxNetworkId->oProtocol),
          pxPktAccess->oPriority);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IpInstanceRcv:oIfIdx = ", pxNetworkId->oIfIdx);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Dst = ", pxNetworkId->dwDstAddr);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Src = ", pxNetworkId->dwSrcAddr);
    DEBUG_PRINT(DEBUG_MOC_IPV4, "eAddrType = ");
    DEBUG_PRINT(DEBUG_MOC_IPV4, IpAddressTypeToString(pxNetworkId->eDstAddrType));
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", ip len = ", wRxedLen);
    DEBUG_PRINT(DEBUG_MOC_IPV4, ", prot = ");
    DEBUG_PRINT(DEBUG_MOC_IPV4, IpProtoToString(pxNetworkId->oProtocol));
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", priority = ", pxPktAccess->oPriority);
    DEBUG_PRINT(DEBUG_MOC_IPV4, NULL);
  }

  if ((pxNetworkId->oIpHdrLen < IPDEFAULT_HDRSIZE) ||
      (pxNetworkId->oVersion != 4)) {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_ERROR))
    {
      /*IP_DBGP(ERROR,"IP:header size, paylaod size, IP version\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IP:header size, paylaod size, IP version");
    }
    SNMP( xTcpipData.ifNum[(pxNetworkId->oIfIdx == 0) ? 0 : 1].ifInErrors++ );
    SNMP( xTcpipData.ipInHdrErrors++ );

    NETPAYLOAD_DELUSER(pxPayload);
    return NETERR_UNKNOWN;
  }
  IP_CHECKPOINT(dbg_dwIpRxCbkLine);

  /* !! IP Options are supported for IGMP only */
  if ((pxNetworkId->oIpHdrLen > IPDEFAULT_HDRSIZE) &&
      (pxNetworkId->oProtocol != IPPROTO_IGMP)) {
    /* IP Header contains options -> not supported yet ! */
    SNMP( xTcpipData.ifNum[(pxNetworkId->oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    SNMP( xTcpipData.ipInDiscards++ );
    IP_DBG_VAR(dbg_dwIPRcvDropped++;)
      NETPAYLOAD_DELUSER(pxPayload);
      return NETERR_UNSUPPORTED;
  }
  IP_CHECKPOINT(dbg_dwIpRxCbkLine);

  if (pxNetworkId->wFragOffset & 0x3FFF) {
    /* IP datagram carries fragmented data -> not supported at this level ! */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_ERROR))
    {
      /*IP_DBGP(ERROR, "IP:Aha! Received Fragmented IP packet: UNSUPPORTED!!!\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IP:Aha! Received Fragmented IP packet: UNSUPPORTED!!!");
    }
    SNMP( xTcpipData.ifNum[(pxNetworkId->oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    SNMP( xTcpipData.ipInDiscards++ );
    IP_DBG_VAR(dbg_dwIPRcvDropped++;)
    NETPAYLOAD_DELUSER(pxPayload);
    return NETERR_UNSUPPORTED;
  }
  IP_CHECKPOINT(dbg_dwIpRxCbkLine);

  eDstAddrType = pxNetworkId->eDstAddrType;
  /* Should process only MY_ADDR, LOOPBACK, BCAST, MCAST */
  /* IPADDRT_MULTICAST here as we want to block that
   *  - only IPADDRT_MULTICASTJOINED let through
   */
  /* JJ If DHCP is running and we do not have an IP Addree
  * the DstType will come up as OUTSIDE.. Let it continue for now */
  if (((eDstAddrType == IPADDRT_UNKNOWN) ||
   /* JJ    (eDstAddrType == IPADDRT_OUTSIDE) || */
       (eDstAddrType == IPADDRT_PPPPEER) ||
       (eDstAddrType == IPADDRT_MYSUBNET))) {
    /* no address match found, neither broadcast nor our address */
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_ERROR))
    {
      /*IP_DBGP(ERROR, "IP:Packet dropped on no addr match:oIfIdx=%d,Dst=%ld.%ld.%ld.%ld,Src=%ld.%ld.%ld.%ld,Type=%d\n",
                pxNetworkId->oIfIdx,
        IPADDRDISPLAY(pxNetworkId->dwDstAddr),
        IPADDRDISPLAY(pxNetworkId->dwSrcAddr),
        (int) pxNetworkId->eDstAddrType);*/
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IP:Packet dropped on no addr match:oIfIdx = ", pxNetworkId->oIfIdx);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Dst = ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Src = ", pxNetworkId->dwSrcAddr);
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, ", Type = ", (int) pxNetworkId->eDstAddrType);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }

    SNMP( xTcpipData.ifNum[(pxNetworkId->oIfIdx == 0) ? 0 : 1].ifInErrors++ );
    SNMP( xTcpipData.ipInAddrErrors++ );
    IP_DBG_VAR(dbg_dwIPRcvDropped++);
    NETPAYLOAD_DELUSER(pxPayload);
    return wRxedLen;
  }
  IP_CHECKPOINT(dbg_dwIpRxCbkLine);

/*  SNMP(
//      (IPADDRT_MULTICASTJOINED == iPktType || IPADDRT_BROADCAST == iPktType) ?
//      xTcpipData.ifNum[(pxNetworkId->oIfIdx == 0) ? 0 : 1].ifInNUcastPkts++ :
//      xTcpipData.ifNum[(pxNetworkId->oIfIdx == 0) ? 0 : 1].ifInUcastPkts++
//  );
*/
  IP_CHECKPOINT(dbg_dwIpRxCbkLine);

  /* ethernet & arp bits used to be here */

  SNMP( xTcpipData.ipInDelivers++ );

  /* Find match for pxIpHdr->oProtocol in UL wRoutingId entries... */
  for (pxUl=pxIp->pxUl,i=0; i<pxIp->oUlNumber; i++,pxUl++) {
    ASSERT(pxUl != NULL);
    if (pxUl->wRoutingId == (WORD)pxNetworkId->oProtocol)
      break;
  }
  IP_CHECKPOINT(dbg_dwIpRxCbkLine);
  if (i == pxIp->oUlNumber) {
    /* No match for packet being demultiplexed  */
    /* i.e. rx'ed pkt type has no plumbed module to handle rx'ed data */
    SNMP( xTcpipData.ifNum[(pxNetworkId->oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
    SNMP( xTcpipData.ipInDiscards++ );
    SNMP( xTcpipData.ipInUnknownProtos++ );
    IP_DBG_VAR(dbg_dwIPRcvDropped++;)
#ifdef NEW_ICMP_MSG_ADDED
    /*Send in an ICMP packet to destination Unreachable : protocol unreachable.*/
    /*Write it through the network callback*/

    xIcmpMsgData.pxNetPacket = pxPacket;
    xIcmpMsgData.pxNetPacketAccess = pxPktAccess;
    xIcmpMsgData.oIfIdx = pxNetworkId->oIfIdx;
    xIcmpMsgData.wVlan = pxNetworkId->wVlan;
    xIcmpMsgData.dwSrcAddr = pxNetworkId->dwDstAddr;
    xIcmpMsgData.dwDstAddr = pxNetworkId->dwSrcAddr;
    ASSERT(pxIp->pfnNetCbk != NULL);
    pxIp->pfnNetCbk((H_NETINSTANCE)pxIp, IPMSG_PROTOCOLUNREACHABLE, (H_NETDATA) &xIcmpMsgData);
#endif
    NETPAYLOAD_DELUSER(pxPayload);
    IP_CHECKPOINT(dbg_dwIpRxCbkLine);
    return NETERR_UNSUPPORTED;
  } else {
    WORD wBytesReq;
    /* xNetworkId is just here on stack, so callback must be done with
     * hData when it returns.
     */
    pxPktAccess->wOffset += (WORD)pxNetworkId->oIpHdrLen;
    /* This includes length of options */
    pxPktAccess->wLength = pxNetworkId->wTotalLen -
                           (WORD)pxNetworkId->oIpHdrLen;
    /* store copy as could be modified in rx callback */
    wBytesReq = pxPktAccess->wLength;
    /* Write packet to registered UL */
    ASSERT(pxUl->pfnRxCbk);
    if (wBytesReq != pxUl->pfnRxCbk(pxUl->hUL,pxUl->hIf,pxPacket,
                                    pxPktAccess,(H_NETDATA)pxNetworkId)) {
      SNMP( xTcpipData.ifNum[(pxNetworkId->oIfIdx == 0) ? 0 : 1].ifInDiscards++ );
      SNMP( xTcpipData.ipInDiscards++ );
    }
    /* even if layer above returned an error, we have accepted the packet
     * & binned it & therefore we should return the complete pkt size
     * as it was passed to us indicating we accepted it completely.
     */
    return wRxedLen;
  }
}



#ifdef NETDBG_HI /* NOTE: Deliberately NETDBG_HI & NOT IPDBG_HI */

/*
 * IpInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hIp                        Ip Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */

BOOL gbIpTablePrint;

LONG IpInstanceProcess(H_NETINSTANCE hIp)
{
  IP_CHECK_STATE((IPSTATE*) hIp);

  if(gbIpTablePrint == TRUE){
    IpTablePrint();
    gbIpTablePrint = FALSE;
  }

  return 1000;
}

#endif /*#ifdef NETDBG_HI*/

/*
 * IpInstanceWriteFast
 *  Ip Instance Write function. Follows PFN_NETWRITE
 *  typedef.i Called by TCP/UDP Layers.. with  Src Addr = MINE
 *
 *  Args:
 *   hIp                        Ip Instance handle
 *   hIf                        Upper Layer interface handle
 *   pxPacket                   Packet pointer
 *   wOffset                    IP PDU offset
 *   hData                      pointer to a net_dst structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG IpInstanceWriteFast(H_NETINSTANCE    hIp,
                     H_NETINTERFACE   hIf,
                     NETPACKET        *pxPacket,
                     NETPACKETACCESS  *pxPktAccess,
                     H_NETDATA        hData)
{
  NETPAYLOAD *pxPayload;
  OCTET *poPayload;
  ROUTERSTATE *pxRouter ;
  IPFRAGSTATE *pxIpFrag ;
  IP1TONSTATE *pxIp1toN ;
  NETIFID xNetIfId;
  OCTET oLlIdx;
  IP1TON_LL *pxLl;
  IPHDR *pxIpHdr ;
  H_NETINSTANCE hLLInst;
  H_NETINTERFACE hLLIf;
  PFN_NETWRITE  pfnLLWrite;
  E_ADDRTYPE eSrcAddrType ;
  WORD wIpPayloadLength ;
  WORD wIpPayloadMaxLength;
  LONG status;
  IPSTATE    *pxIp = (IPSTATE *)hIp;
  WORD       wGivenLength = pxPktAccess->wLength;
  NETWORKID  *pxNetworkId = (NETWORKID*)hData;

  IP_CHECK_STATE(pxIp);
  NETPACKET_CHECK(pxPacket);
  ASSERT((OCTET)hIf<=pxIp->oUlNumber);

  pxPayload = pxPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  SNMP( xTcpipData.ipOutRequests++ );       /* inc. SNMP count */

  if (pxNetworkId->dwGatewayAddr == 0) {
    /* If the gateway address is not set, then
       try to get it */
    ROUTEENTRY xRoute;

    /* Not our address: Check the route to the remote host */
#ifdef _RADIX_ROUTING_ON_
    xRoute.xRouteNodes->RadixNodeKey = pxNetworkId->dwDstAddr;
    xRoute.xRouteNodes->RadixNodeMask = 0;
#else
    xRoute.dwDstAddr = pxNetworkId->dwDstAddr;
#endif
    xRoute.oIfIdx = pxNetworkId->oIfIdx;
    xRoute.wVlan = pxNetworkId->wVlan;
    xRoute.eDstAddrType = pxNetworkId->eDstAddrType;

    if (RoutingTableMsg(ROUTINGTABLEMSG_FINDROUTE,
                        (H_NETDATA)&(xRoute)) < 0) {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP, INET_DBG_LEVEL_NORMAL))
      {
        /*IP_DBGP(NORMAL, "IpInstanceWrite: Gateway address not set - looking it up\n");*/
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IpInstanceWrite: Gateway not found deleting packet");
      }
      NETPAYLOAD_DELUSER(pxPayload);
      /* indicate an error occurred & that caller can delete packet */
      SNMP( xTcpipData.ipOutDiscards++ );
      return NETERR_UNSUPPORTED;
    } else {
      pxNetworkId->dwGatewayAddr = xRoute.dwGateway;
      pxNetworkId->oIfIdx = xRoute.oIfIdx;
      pxNetworkId->wVlan = xRoute.wVlan;
      pxNetworkId->eDstAddrType = xRoute.eDstAddrType;
    }
  }

  pxPktAccess->oPriority = (OCTET)LOW_PRIORITY;

  /* dwSrcAddr filled in above
   * dwDstAddr MUST BE SET by caller of IP
   * oIpHdrLen */
  pxNetworkId->oIpHdrLen  = IPDEFAULT_HDRSIZE+pxNetworkId->oIpOptionLen;
  /* wTotalLen */
  pxNetworkId->wTotalLen  = pxPktAccess->wLength + IPDEFAULT_HDRSIZE +
                            pxNetworkId->oIpOptionLen;
  /* wDatagramId */
  pxNetworkId->wDatagramId = wIpDatagramId++;
  /* wFragOffset */
  pxNetworkId->wFragOffset= 0; /* no fragmentation on tx data from stack */

  /* *poIpOption & oIpOptionLen MUST BE SET by caller of IP
   * oProtocol */
  /* oToS & oTtL MUST BE SET */
  /* oVersion */
  pxNetworkId->oVersion   = 4;                   /* IPv4 */

  pxRouter = (ROUTERSTATE *) pxIp->hLL;
  if ((pxNetworkId->dwGatewayAddr == INADDR_ANY) ||
      ( (pxNetworkId->oIfIdx != NETIFIDX_ANY) &&
        (pxRouter->abIsLinkUp[pxNetworkId->oIfIdx] != TRUE)) )
  {
    ROUTEENTRY xRouteEntry;

    /*
     * Look up gateway address and interface index to which
     * the packet has to be forwarded.
     */
#ifdef _RADIX_ROUTING_ON_
    xRouteEntry.xRouteNodes->RadixNodeKey  = pxNetworkId->dwDstAddr;
    xRouteEntry.xRouteNodes->RadixNodeMask = 0;
    xRouteEntry.dwGateway = 0;
#else
    xRouteEntry.dwDstAddr = pxNetworkId->dwDstAddr;
#endif
    xRouteEntry.oIfIdx = NETIFIDX_ANY;
    xRouteEntry.wVlan = NETVLAN_ANY;
    xRouteEntry.eDstAddrType = pxNetworkId->eDstAddrType;

    status  =  RoutingTableMsg(ROUTINGTABLEMSG_FINDROUTE,(H_NETDATA)&xRouteEntry);
    if ( 0 > status)
    {
      NETPAYLOAD_DELUSER(pxPayload);
      /* indicate an error occurred & that caller can delete packet */
      SNMP( xTcpipData.ipOutDiscards++ );
      return NETERR_UNSUPPORTED;
    }

    pxNetworkId->dwGatewayAddr = xRouteEntry.dwGateway;
    pxNetworkId->oIfIdx = xRouteEntry.oIfIdx;
    pxNetworkId->wVlan = xRouteEntry.wVlan;
    pxNetworkId->eDstAddrType = xRouteEntry.eDstAddrType;
  }


  if(pxRouter->abIsLinkUp[pxNetworkId->oIfIdx] != TRUE)
    {
      RouterSendIcmpMsg(pxIp->hLL,
                        pxPacket,
                        pxPktAccess,
                        hData,
                        pxNetworkId->oIfIdx,
                        pxNetworkId->wVlan,
                        (OCTET) ROUTERCBK_LINK_DOWN);
      NETPAYLOAD_DELUSER(pxPacket->pxPayload);
      return (LONG)-1;
    }

  /*Find the mtu of the LL interface*/
  pxIpFrag = (IPFRAGSTATE *)pxRouter->hLLInst;
  wIpPayloadLength = pxPktAccess->wLength;
  wIpPayloadMaxLength = pxIpFrag->awMtu[pxNetworkId->oIfIdx] - pxNetworkId->oIpHdrLen;

  if(wIpPayloadLength > wIpPayloadMaxLength){
      /* We need to Fragment  Send Via Slow Path*/
       return  pxRouter->pfnLLWrite(pxRouter->hLLInst,
                                    pxRouter->hLLIf,
                                    pxPacket,
                                    pxPktAccess,
                                    hData);
  }

  pxIp1toN = (IP1TONSTATE *)pxIpFrag->hLLInst;
  oLlIdx = pxIp1toN->aIfIdxToLlMap[pxNetworkId->oIfIdx];
  if (oLlIdx == IP1TONLLIDX_INVALID) {
    /* Dump the packet */
    NETPAYLOAD_DELUSER(pxPayload);
    return pxPktAccess->wLength;
  }
  xNetIfId.oIfIdx    = pxNetworkId->oIfIdx;
  xNetIfId.wVlan     = pxNetworkId->wVlan;
  xNetIfId.dwGatewayAddr = pxNetworkId->dwGatewayAddr;
  xNetIfId.dwSrcIpAddr = pxNetworkId->dwSrcAddr;
  xNetIfId.dwDstIpAddr = pxNetworkId->dwDstAddr;
  xNetIfId.eDstAddrType = pxNetworkId->eDstAddrType;


  /*Modify wOffset and wLength*/
  pxPktAccess->wOffset -=
    (IPDEFAULT_HDRSIZE + pxNetworkId->oIpOptionLen);
  pxPktAccess->wLength +=
    (IPDEFAULT_HDRSIZE + pxNetworkId->oIpOptionLen);

  /*Set the ip header pointer*/
  pxIpHdr = (IPHDR *)(poPayload + pxPktAccess->wOffset);

  pxIpHdr->oVersion   = pxNetworkId->oVersion;
  pxIpHdr->oIpHdrLen  = pxNetworkId->oIpHdrLen >> 2;
  pxIpHdr->dwDstAddr  = htonl(pxNetworkId->dwDstAddr);
  pxIpHdr->dwSrcAddr  = htonl(pxNetworkId->dwSrcAddr);
  pxIpHdr->oToS       = pxNetworkId->oToS;
  pxIpHdr->wTotalLen  = MOC_NTOHS((ubyte *)&pxNetworkId->wTotalLen);
  pxIpHdr->wFragOffset= htons(pxNetworkId->wFragOffset);
  pxIpHdr->oTtL       = pxNetworkId->oTtL;
  pxIpHdr->oProtocol  = pxNetworkId->oProtocol;
  pxIpHdr->wDatagramId= htons(pxNetworkId->wDatagramId);

  /*Set the ip checksum*/
  pxIpHdr->wCheck = 0;
  pxIpHdr->wCheck = Checksum16((OCTET*)pxIpHdr,pxNetworkId->oIpHdrLen);

  /*Set the LL inst, LL if and LL write function*/
  pxLl       = pxIp1toN->pxLl + oLlIdx;
  hLLInst    = pxLl->hLLInst;
  hLLIf      = pxLl->hLLIf;

  if (pxNetworkId->dwDstAddr == pxNetworkId->dwSrcAddr) {
     /* being Sent to Us Itself.. Hairpin Bend */
    IP1TON_DBG_VAR(g_dwIp1toNLoopbackPktCnt++);
    return Ip1toNInstanceRcv(pxIp1toN,hLLIf,pxPacket,pxPktAccess,
                    (H_NETDATA)&xNetIfId);
  }

  pfnLLWrite = pxLl->pfnLLWrite;

  pfnLLWrite(hLLInst,hLLIf,pxPacket,pxPktAccess,
                      (H_NETDATA)&xNetIfId);
  return wGivenLength; /* accept the full packet */
}

