/*
 * accept.c
 *
 * <File description>
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */



/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/sockio.h"
#include "../include/if.h"
#include "../include/if_dl.h"
#include "../include/if_types.h"
#include "../include/route.h"
#include "../include/in.h"
#include "mqueue.h"
#include "../include/ioctl.h"
#include "dllist.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netdefs.h"
#include "netutils.h"
#include "iptable.h"
#include "netconfig.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "icmp.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "routing_table.h"
#include "dnsapi.h"

int mn_accept_func(int sockfd, struct sockaddr *cliaddr, socklen_t *addrlen,
        mn_sock_accept_cb_t pfCb, void *pvCbArg, void * ipc_req);

void read_accept_info(SOCKET *pxSock, SOCKET *pxChildSock,
            struct sockaddr *cliaddr, socklen_t *addrlen);
/*
 * accept
 *  Called by a TCP Server to return a completed connection.
 *  Remarks:
 *   Original sockfd can still be used to accept new connections. *
 * Args:
 *  sockfd                       The socket returned by the socket function.
 *  cliaddr                      On return, has the protocol address of
 *                               the connected client.
 *  addrlen                      Before the call, should be set to the size
 *                               of the structure pointed to by cliaddr. On
 *                               return, this will point to the size of
 *                             the returned structure.
 *
 * Return:
 *  >0 : Success. New socket created
 *   0 : Success. Async mode, no new socket created yet.
 *  -1: Error
 */
#ifndef __MOCANA_ASYNC_API__
int mn_accept(int sockfd, struct sockaddr *cliaddr, socklen_t *addrlen,
        mn_sock_accept_cb_t pfCb, void *pvCbArg)
{

    return(mn_accept_func(sockfd, cliaddr, addrlen,
                  pfCb, pvCbArg,NULL));

}
#else
int mn_accept(int sockfd, struct sockaddr *cliaddr, socklen_t *addrlen);
{

    return(mn_accept_func(sockfd, cliaddr, addrlen,
                  NULL, NULL, NULL));

}
#endif

int mn_accept_func(int sockfd, struct sockaddr *cliaddr, socklen_t *addrlen,
        mn_sock_accept_cb_t pfCb, void *pvCbArg, void * ipc_req)
{
  SOCKET *pxSock;
  SOCKET *pxChildSock;
  struct sockaddr_in *cliaddr_in, cliaddr_sub;
  socklen_t addrlen_sub;
  TCPLISTEN *pxListen;

#ifdef STRICT_POSIX
  /* A non-zero sockaddr structure */
  /* Length should be proper */
  if(cliaddr) {
    if(*addrlen != sizeof(struct sockaddr_in)) {
      mn_errno = MO_EBADARG;
      return -1;
    }
  }
#else
  DEBUG({
    if (cliaddr) {
      ASSERT(*addrlen == sizeof(struct sockaddr_in));
    }
  });
#endif

  cliaddr_in = (struct sockaddr_in *)cliaddr;

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));

  SOCKET_CHECKFD(sockfd);
  pxSock = RETRIEVE_SOCKET(sockfd);

  SOCKET_CHECK_STATE(pxSock);

  if ((pxSock == NULL) || (pxSock->lType != SOCK_STREAM)) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  /* If socket is not enabled to receive connections return error */
  if((pxSock->dwSockOptions & SO_ACCEPTCONN) == 0) {
    mn_errno = EBADREQ;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  pxListen = pxSock->u.pxTcp->u.pxListen;

  /* If socket is non blocking, return EWOULDBLOCK if no new connections
   * are available else return an established connection below in
   * GetEstablishedConn */
  {
    DWORD dwCurrId = pxSock->dwSocketId;

    while ((pxChildSock = PeekQueueFront(pxListen->qWaitForAccept)) == NULL) {

      if (pxSock->dwSockState & SS_CANTRCVMORE) {
        mn_errno = MO_ECONNABORTED;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return -1;
      }
      if (pxSock->dwSockState & SS_NBIO) {
        mn_errno = MO_EWOULDBLOCK;
        /* Non blocking : return here */
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return -1;
      }

      /* if async mode, save cb & arg and return immdly */
#ifndef __MOCANA_ASYNC_API__
      if ( pfCb ){
    pxListen->pfAcceptCb = pfCb;
    pxListen->pvAcceptCbArg = pvCbArg;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return 0;
      }
#endif

      /* libsock, save ipc_req and return immdly */
#ifndef __MOCANA_LIBSOCK__
      if ( ipc_req ){
    pxListen->ipc_req = ipc_req;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return 0;
      }
#endif

      /* Wait for something to happen on the socket * /
      pthread_cond_wait(&(pxSock->xCond), &(xNetWrapper.xMutex));

      /* Check if it is still valid */
      SOCKET_CHECKFD(sockfd);
      if (((pxSock = RETRIEVE_SOCKET(sockfd)) == NULL)  ||
          (pxSock->dwSocketId != dwCurrId)) {
        mn_errno = MO_EBADF;
        RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
        return -1;
      }
    }
  }
  /* If we have reached this point, the socket has forked successfully */

  /* Move the socket from WaitForAccept queue to Accepted Queue */
  DiscardQueueFront(pxListen->qWaitForAccept);
  /* Reduce Backlog JJ */
  pxListen->oBackLogLevel --;
  Queue(pxListen->qAccepted, pxChildSock);

#if 0 /* carved out into a function so that socket_tcp.c can call also */

  /* Refuse any further accept (the socket code itself
     will anyway refuse more connection from TCP when the
     backlog queue is full. But the accept
     needs this flag set) */
  if (pxSock->u.pxTcp->u.pxListen->oBackLogLevel ==
      pxSock->u.pxTcp->u.pxListen->oBackLogMax) {
    pxSock->dwSockState |= SS_CANTRCVMORE;
  }

  {
    H_NETINSTANCE hTcp = xSocketRep.axProtocols[TCP_INDEX].hInst;

    TcpInstanceULInterfaceIoctl(hTcp,pxChildSock->hLL,
                                NETTRANSPORTULINTERFACEIOCTL_QUERYTRANSPORTID,
                                (H_NETDATA) &(pxChildSock->xTransportId));
  }

  if(cliaddr && (*addrlen == sizeof(struct sockaddr_in))) {
    cliaddr_in->sin_addr.s_addr = pxChildSock->xTransportId.xNetId.dwDstIpAddr;
    cliaddr_in->sin_port = pxChildSock->xTransportId.wDstPort;
  }

  pxChildSock->oBoundFlag |= (SOCKETBOUNDFLAG_IF  |
                              SOCKETBOUNDFLAG_IP  |
                              SOCKETBOUNDFLAG_TOS);
#else
#ifndef __MOCANA_ASYNC_API__
  if ( pfCb && (cliaddr == NULL || addrlen == NULL) ){
    /* for async case, we always need to pass cliaddr & addrlen to cb
     * So, if the caller didn't specify his own, use our own
     */
    addrlen_sub = sizeof(cliaddr_sub);
    cliaddr = (struct sockaddr *)&cliaddr_sub;
    addrlen = &addrlen_sub;
  }
#endif
  read_accept_info(pxSock, pxChildSock, cliaddr, addrlen);
#endif

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

#ifndef __MOCANA_ASYNC_API__
  if ( pfCb ){
    pxListen->pfAcceptCb = pfCb;
    pxListen->pvAcceptCbArg = pvCbArg;
    pfCb(pxSock->lFd, pxChildSock->lFd, cliaddr, *addrlen, pvCbArg);
    return 0;
  }else
#endif
#ifdef __MOCANA_LIBSOCK__
  if (ipc_req)
  {
      SOCKSERVER_acceptReply(ipc_req, pxChildSock->lFd,
                     (struct sockaddr *)&cliaddr,
                    *addrlen);
      return 0;
  }
#endif
      return pxChildSock->lFd;
}

void read_accept_info(SOCKET *pxSock, SOCKET *pxChildSock,
            struct sockaddr *cliaddr, socklen_t *addrlen)
{
  TCPLISTEN *pxListen = pxSock->u.pxTcp->u.pxListen;
  struct sockaddr_in *cliaddr_in = (struct sockaddr_in *)cliaddr;

  /* Refuse any further accept (the socket code itself
     will anyway refuse more connection from TCP when the
     backlog queue is full. But the accept
     needs this flag set) */
  if (pxSock->u.pxTcp->u.pxListen->oBackLogLevel ==
      pxSock->u.pxTcp->u.pxListen->oBackLogMax) {
    pxSock->dwSockState |= SS_CANTRCVMORE;
  }

  {
    H_NETINSTANCE hTcp = xSocketRep.axProtocols[TCP_INDEX].hInst;

    TcpInstanceULInterfaceIoctl(hTcp,pxChildSock->hLL,
                                NETTRANSPORTULINTERFACEIOCTL_QUERYTRANSPORTID,
                                (H_NETDATA) &(pxChildSock->xTransportId));
  }

  if(cliaddr && (*addrlen == sizeof(struct sockaddr_in))) {
    cliaddr_in->sin_addr.s_addr = htonl(pxChildSock->xTransportId.xNetId.dwDstIpAddr);
    cliaddr_in->sin_port = htons(pxChildSock->xTransportId.wDstPort);
  }

  pxChildSock->oBoundFlag |= (SOCKETBOUNDFLAG_IF  |
                              SOCKETBOUNDFLAG_IP  |
                              SOCKETBOUNDFLAG_TOS);
}
