#ifndef __ECC_H__
#define __ECC_H__

#include <NNstyle.h>


/***
	CRC
***/
#define ECC_CRC8_INIT	0
#define ECC_CRC8_GOOD	0
OCTET EccCrc8(OCTET oCrc, OCTET *poData, DWORD dwLen);

#define ECC_CRC16_INIT	0xFFFF
#define ECC_CRC16_GOOD	0xF0B8
WORD EccCrc16(WORD wCrc, OCTET *poData, DWORD dwLen);


#define ECC_CRC4_INIT	0
#define ECC_CRC4_GOOD	0
OCTET EccCrc4(OCTET oCrc, OCTET *poData, DWORD dwLen);
#define ECC_CRC10_INIT	0
#define ECC_CRC10_GOOD	0
WORD EccCrc10(WORD wCrc, OCTET *poData, DWORD dwLen);

#define ECC_CRC12_INIT	0
#define ECC_CRC12_GOOD	0
WORD EccCrc12(WORD wCrc, OCTET *poData, DWORD dwLen);

#define ECC_CRC20_INIT	0
#define ECC_CRC20_GOOD	0
DWORD EccCrc20(DWORD dwCrc, OCTET *poData, DWORD dwLen);

#define ECC_CRC28_INIT	0
#define ECC_CRC28_GOOD	0
DWORD EccCrc28(DWORD dwCrc, OCTET *poData, DWORD dwLen);

#define ECC_CRC32_INIT	0
#define ECC_CRC32_GOOD	0
DWORD EccCrc32(DWORD dwCrc, OCTET *poData, DWORD dwLen);


/***
	Straight simple checksums, no polynomials
***/
/*
 * Checksum16
 *  Calculate a checksum (for IP, UDP, TCP etc.)
 *  NOTE: Allows packets on odd or even boundaries to be dealt with
 *        Also deals with odd length packets
 *
 *  Args:
 *   poBuf                      Ptr. to data to calc. checksum on
 *   wLen                       Length of the data in bytes
 *
 *  Return:
 *   16bit Checksum
 */
WORD 
Checksum16(OCTET *poData, WORD wLen);


/***
	Golay encoder/decoder 
***/
DWORD EccGolayEncoder( WORD wD );

/*
  returns  0 if no error, 
           1 if recoverable error, and
		  -1 if unrecoverable error.
*/
int EccGolayDecoder( DWORD *pdwCode );

/***
	H.223 Extended-BCH (16,5,8) coder/decoder
***/
/*
   generates the redundant vector wR for
   the input data vector wD. The final 
   codeword is the concatenation of wD 
   and wR.
*/
WORD EccBCH5Encoder( WORD wD );

/*
  pwCode is the codeword to be corrected.

  returns  0 if no error in the data part, 
           1 if recoverable error, and
		  -1 if unrecoverable error.
*/
int EccBCH5Decoder( WORD *pwCode );


/***
	H.223 Extended-BCH (16,7,6) coder/decoder.
***/
/*
   generates the redundant vector wR for
   the input data vector wD. The final 
   codeword is the concatenation of wD 
   and wR.
*/
WORD EccBCH7Encoder( WORD wD );

/*
  pwCode is the codeword to be corrected.

  returns  0 if no error in the data part, 
           1 if recoverable error, and
		  -1 if unrecoverable error.
*/
int EccBCH7Decoder( WORD *pwCode );

/***
	H.223 rate-compatible, punctured convolutional coder, decoder
***/
/*
  return the HEX value which when added to the data bit stream 
  would result in a zero final state for the convolutional encoder.
*/
OCTET EccConvFinalHex( OCTET *poD, DWORD dwLen );

/*
   Generates the redundant bit streams pointed by 'poR[0 .. oNr-1]' 
   for the data bits 'poD' according to the convolutional encoding 
   rule specified by 'aoConvTableR' and 'aoConvTableS'. 'dwLen' is 
   the number of input bytes. The return value is the final state 
   of the convolutional encoder.
*/
OCTET EccConvEncoder( OCTET *poD, OCTET *poR[], DWORD dwLen, OCTET oNr );

/*
  Convolutional decoder. 
  apoRcvd[0] points to the received DATA byte stream and apoRcvd[i]
  points to the (i)th received REDUNDANT byte stream. The length of
  the data is 'dwLen' bytes. 
  The data rate is 8/(8+oRate), for oRate=0 .. 24. 
  poDecBits points to the decoded bits.
  The output is the final state in the surviving path
*/
OCTET EccConvDecoder( OCTET *apoRcvd[], OCTET *poDecBits,
					  OCTET oRate, DWORD dwLen );


/*
** H.223-M Bit Swapping Routines
** 
*/

/*
  Scrambles/Descrambles the bits in the redundant bit stream 
  of the rate-compatible convoluitonal encoder according to 
  the puncturing rule of H.223M.

  'poDeScrambled' points to the bit stream to be scrambled and 
  'poScrambled' points to the scrambled bits. 'dwLen' is the 
  the size of stream in bytes.

  The reordering is done for bits corresponding to the starting 
  bit rate of (oRateS+1)/8 to ending rate of oRateE/8, where
  0 <= oRateS < oRateE <= 8
  
  when 'oDir' is 0 generates the scrambled bits, otherwise it 
  generates the descrambled bits.
*/
OCTET *H223MPuncture( OCTET *poDeScrambled, OCTET *poScrambled, 
					  DWORD dwLen, OCTET oRateS, OCTET oRateE, OCTET oDir );

/*
  Bit interleaving/de-interleaving as spelled out in H.223M.
  dwLen is the size of data in bytes.

  When oDir=0, it generates the interleaved data poInterleaved
  from non-interleaved data poDeInterleaved. Does the reverse,
  otherwise.

  Limitaion: dwLen<256 !
*/
void H223MInterleave( OCTET *poDeInterleaved, OCTET *poInterleaved, 
					  DWORD dwLen, OCTET oDir );

#endif
