/*
 * pppoeparser.c
 *
 * PPPoE parser functionnality
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "pppoeparser_defs.h"


/*
 * PppoETagTableMove
 *
 *  Args:
 *   axDst                Destination tag table
 *   axSrc                Source tag table
 *
 *  Return:
 *   0
 */
LONG PppoETagTableMove(A_PPPOETAGTABLE axDst,A_PPPOETAGTABLE axSrc)
{
  OCTET o;

  ASSERT(axDst != NULL);
  ASSERT(axSrc != NULL);

  for (o=0;o < PPPOETAGIDX_MAX; o++) {
    axDst[o].wItemNum = axSrc[o].wItemNum;
    axDst[o].pxItemList = axSrc[o].pxItemList;
    axSrc[o].wItemNum= 0;
    axSrc[o].pxItemList = NULL;
  }

  return NETERR_NOERR;
}

/*
 * PppoETagTableClear
 *
 *  Args:
 *   axTable          Table to clear
 *
 *  Return:
 *   0
 */
LONG PppoETagTableClear(A_PPPOETAGTABLE axTable)
{
  int iDx;
  for(iDx = 0; iDx < PPPOETAGIDX_MAX; iDx++){
    PppoETagTableDeleteTag(axTable,(OCTET)iDx);
  }

  return NETERR_NOERR;
}

/*
 * PppoETagMatch
 *
 *  Args:
 *   axTable          Table to search
 *   oTagIdx          Tag index
 *   pxMatch          tag to match. If the poData is NULL, it is
 *                    not used for the comparison
 *
 *  Return:
 *   1st match index or NETERR_UNKNOWN (no match)
 */
LONG PppoETagTableMatch(A_PPPOETAGTABLE axTable,OCTET oTagIdx,
                        PPPOETAGITEM *pxMatch)
{
  PPPOETAG *pxTag = &(axTable[oTagIdx]);
  WORD w;
  LONG lReturn = NETERR_UNKNOWN;

  if (pxMatch != NULL) {
    for (w=0;w<pxTag->wItemNum;w++) {
      PPPOETAGITEM *pxTagItem = pxTag->pxItemList + w;
      if ((pxMatch->poData == NULL) ||
          ((pxTagItem->wLength == pxMatch->wLength) &&
           (memcmp(pxTagItem->poData,pxMatch->poData,pxTagItem->wLength) == 0))
          ) {
        lReturn = (LONG)w;
        break;
      }
    }
  }
  else {
    lReturn = 0;
  }

  return lReturn;
}

/*
 * PppoETagTablePayloadLength
 *  Calculates the necessary length for all the tags in the table
 *
 *  Args:
 *   axTable                 Table
 *
 *  Return:
 *   payload length
 */
LONG PppoETagTablePayloadLength(A_PPPOETAGTABLE axTable)
{
  LONG lLength = 0;
  OCTET o;

  ASSERT(axTable != NULL);

  for (o=0;o < PPPOETAGIDX_MAX; o++) {
    WORD wMax = axTable[o].wItemNum;
    if (wMax != 0) {
      WORD w;
      lLength += PPPOETAG_HDRLEN * wMax;
      for (w=0;w<wMax;w++) {
        lLength += axTable[o].pxItemList[w].wLength;
      }
    }
  }

  return lLength;
}

/*
 * PppoETagTableDeleteTag
 *  Free ressources of a pppoe tag
 *
 *  Args:
 *   axTable                 Table
 *   oTagIdx                 Tag index
 */

void PppoETagTableDeleteTag(A_PPPOETAGTABLE axTable,OCTET oTagIdx)
{
  PPPOETAG *pxTag;
  PPPOETAGITEM *pxItem;
  int iDx;

  ASSERT((axTable != NULL) && (oTagIdx < PPPOETAGIDX_MAX));

  pxTag = &axTable[oTagIdx];
  /* Fix PPPoE allocate memory failed; add check pxTag->pxItemList if NULL  */
  if (pxTag->pxItemList != NULL) {
     for(iDx = 0; iDx < pxTag->wItemNum; iDx++){
         pxItem = &pxTag->pxItemList[iDx];
         if(pxItem->poData != NULL){
           free(pxItem->poData);
           pxItem->poData = NULL;
         }
     }
     free(pxTag->pxItemList);
     pxTag->pxItemList = NULL;
  }
  free(pxTag->pxItemList);
  pxTag->pxItemList = NULL;
  pxTag->wItemNum   = 0;
}

/*
 * PppoETagTableDeleteRedundantTags
 *  Free resources of a pppoe tag
 *   - currently only used for ACNAME to ensure that
 *     only one is sent back to server
 *   - the first tag of the type is chosen, all others are deleted
 *
 *  Args:
 *   axTable                 Table
 *   oTagIdx                 Tag index
 */

void PppoETagTableDeleteRedundantTags(A_PPPOETAGTABLE axTable, OCTET oTagIdx)
{
  PPPOETAG *pxTag;
  PPPOETAGITEM *pxItem;
  int iDx;

  ASSERT((axTable != NULL) && (oTagIdx < PPPOETAGIDX_MAX));

  pxTag = &axTable[oTagIdx];

  if (pxTag->wItemNum > 1) {
    for(iDx = 1; iDx < pxTag->wItemNum; iDx++){
      pxItem = &pxTag->pxItemList[iDx];
      if(pxItem->poData != NULL){
        free(pxItem->poData);
        pxItem->poData = NULL;
      }
    }

    pxTag->wItemNum   = 1;
  }
}


#ifndef NDEBUG

const OCTET *apoPppoETagString[] = {
 "SERVICENAME",
 "ACNAME",
 "HOSTUNIQ",
 "ACCOOKIE",
 "VENDORSPECIFIC",
 "RELAYSESSIONID",
 "SERVICENAMEERROR",
 "ACSYSTEMERROR",
 "GENERICERROR",
 "ENDOFLIST",
 "UNKNOWN",
};

void PppoEPrintTagTable(A_PPPOETAGTABLE axTable)
{
  #define TAG_MAX_LENGTH 64
  int iTagIdx,iItemIdx;

  ASSERT(axTable != NULL);

  for (iTagIdx = 0; iTagIdx < PPPOETAGIDX_MAX; iTagIdx++) {
    PPPOETAG *pxTag = &axTable[iTagIdx];
    if (pxTag->pxItemList != NULL) {
      OCTET aoTmp[64];
      PPPOETAGITEM *pxItem = pxTag->pxItemList;
      printf("%s",apoPppoETagString[iTagIdx]);
      for (iItemIdx = 0; iItemIdx < pxTag->wItemNum; iItemIdx++) {
        if (pxItem->poData != NULL) {
          memcpy(aoTmp,pxItem->poData,TAG_MAX_LENGTH);
          aoTmp[pxItem->wLength < TAG_MAX_LENGTH ? pxItem->wLength:TAG_MAX_LENGTH] = '\0';
          printf("\t %s",aoTmp);
        }
        pxItem++;
      }
       printf("\n");
    }
  }
}


#endif /*#ifndef NDEBUG*/



