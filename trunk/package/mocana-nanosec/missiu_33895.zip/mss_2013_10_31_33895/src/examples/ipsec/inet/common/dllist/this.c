#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

LONG this_item(void *a, void *b)
{
  return(((DWORD) a) - ((DWORD) b));
}



