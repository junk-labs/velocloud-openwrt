#ifndef __COMMON_H__
#define __COMMON_H__

/* Check to be sure the build flavor is valid.
   Assign and internal #defines based on the build flavor.
*/

#if defined(_FLAVOR_gn)

#elif defined(_FLAVOR_gn_d)

#elif defined(_FLAVOR_sc)
#  define SOFTCRC
#elif defined(_FLAVOR_sc_d)
#  define SOFTCRC
#elif defined(_FLAVOR_t2u)
#  define T2UHW
#elif defined(_FLAVOR_t2u_d)
#  define T2UHW
#else
#  error Unknown build flavor
#endif

#endif
