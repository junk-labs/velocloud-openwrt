/*
 * router.h
 *
 * router module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ROUTER_H_
#define _ROUTER_H_

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "../include/socket_inet.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netnetwork.h"
#include "routercfgapi.h"


/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/
/* Router option */

/* Router specific Msg */
#define ROUTERMSG_SETIFIDXLAN   \
  (NETNETWORKMSG_MODULESPECIFICBEGIN)          /* set the interface index
                                                  corresponding to the LAN */

#define ROUTERMSG_SETIFMTU   \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 1)      /* set the MTU of an interface */

#define ROUTERMSG_SETROUTINGSTATUS  \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 2)      /* Set the routing status for
                                                  a particular leg. */

#define ROUTERMSG_SETLINKSTATUS  \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 3)      /* Set the link status for
                                                  a particular leg. */

#define ROUTERMSG_CFGIPFILTERING  \
  (NETNETWORKMSG_MODULESPECIFICBEGIN + 4)      /* Configure a IP filtering
                                                  entry. */



/*
 * Router callback define
 */
#define ROUTERCBK_DEST_UNREACH_NET_UNREACH     (NETCBK_MODULESPECIFICBEGIN)
#define ROUTERCBK_DEST_UNREACH_FRAG_NEEDED     (NETCBK_MODULESPECIFICBEGIN + 1)
#define ROUTERCBK_TIME_EXCEEDED_TTL_EXPIRED    (NETCBK_MODULESPECIFICBEGIN + 2)

#ifdef _RADIX_ROUTING_ON_
#define ROUTERCBK_LINK_DOWN                    (NETCBK_MODULESPECIFICBEGIN + 3)
#endif

/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/
typedef struct {
  OCTET oIfIdx;
  WORD wMtu;
} ROUTERSETIFMTU;

typedef struct {
  OCTET oIfIdx;
  BOOL bDisabled;
} ROUTERSETROUTINGSTATUS;

typedef struct {
  OCTET oIfIdx;
  BOOL bIsLinkUp;
} ROUTERSETLINKSTATUS;


/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * RouterInitialize
 *  Initialize the Router library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG RouterInitialize(void);

/*
 * RouterTerminate
 *  Terminate the Router library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG RouterTerminate(void);

/*
 * RouterInstanceCreate
 *  Creates a Router Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE RouterInstanceCreate(void);

/*
 * RouterInstanceDestroy
 *  Destroy a Router Instance
 *
 *  Args:
 *   hRouter                       Roouter instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG RouterInstanceDestroy(H_NETINSTANCE hRouter);

/*
 * RouterInstanceSet
 *  Set a Router Instance Option
 *
 *  Args:
 *   hRouter                    Router instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG RouterInstanceSet(H_NETINSTANCE hRouter,
                       OCTET oOption,
                       H_NETDATA hData);

/*
 * RouterInstanceQuery
 *  Query a Router Instance Option
 *
 *  Args:
 *   hRouter                    Router instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG RouterInstanceQuery(H_NETINSTANCE hRouter,
                         OCTET oOption,
                         H_NETDATA *phData);

/*
 * RouterInstanceMsg
 *  Send a msg to a Router instance
 *
 *  Args:
 *   hRouter                    Router instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG RouterInstanceMsg(H_NETINSTANCE hRouter,
                       OCTET oMsg,
                       H_NETDATA hData);


/*
 * RouterInstanceULInterfaceCreate
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hRouter                Routerinstance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE RouterInstanceULInterfaceCreate(H_NETINSTANCE hRouter);

/*
 * RouterInstanceULInterfaceDestroy
 *  Destroy a Router UL interface
 *
 *  Args:
 *   hRouter                    Router instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG RouterInstanceULInterfaceDestroy(H_NETINSTANCE hRouter,
                                      H_NETINTERFACE hInterface);

/*
 * RouterInstanceULInterfaceIoctl
 *
 *  Args:
 *   hRouter                      Router instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG RouterInstanceULInterfaceIoctl(H_NETINSTANCE hRouter,
                                    H_NETINTERFACE hULInterface,
                                    OCTET oIoctl,
                                    H_NETDATA hData);

/*
 * RouterInstanceWrite
 *  Router Instance Write function. Follows PFN_NETWORKWRITE
 *  typedef.
 *
 *  Args:
 *   hRouter                    Router Instance handle
 *   hIf                        Interface handle
 *   pxPacket                   Packet pointer
 *   wOffset                    Ip PDU offset
 *   hData                      pointer to a net_dst structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG RouterInstanceWrite(H_NETINSTANCE hRouter,
                         H_NETINTERFACE hIf,
                         NETPACKET *pxPacket,
                         NETPACKETACCESS *pxPktAccess,
                         H_NETDATA hData);

/*
 * RouterInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hRouter                Router instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE RouterInstanceLLInterfaceCreate(H_NETINSTANCE hRouter);

/*
 * RouterInstanceLLInterfaceDestroy
 *  Destroy a Router LL interface
 *
 *  Args:
 *   hRouter                    Router instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG RouterInstanceLLInterfaceDestroy(H_NETINSTANCE hRouter,
                                      H_NETINTERFACE hInterface);

/*
 * RouterInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hRouter                         Router instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG RouterInstanceLLInterfaceIoctl(H_NETINSTANCE hRouter,
                                    H_NETINTERFACE hLLInterface,
                                    OCTET oIoctl,
                                    H_NETDATA hData);


/*
 * RouterInstanceRcv
 *  Router Instance Rcv function
 *   Router Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hRouter                    Router Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    wOffset                    Ip PDU offset.
 *    hData                      unused
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG RouterInstanceRcv(H_NETINSTANCE hRouter,
                       H_NETINTERFACE hIf,
                       NETPACKET *pxPacket,
                       NETPACKETACCESS *pxPktAccess,
                       H_NETDATA hData);

/*
 * RouterInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hRouter                  Router Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG RouterInstanceProcess(H_NETINSTANCE hRouter);

#endif /* #ifndef _ROUTER_H_ */







