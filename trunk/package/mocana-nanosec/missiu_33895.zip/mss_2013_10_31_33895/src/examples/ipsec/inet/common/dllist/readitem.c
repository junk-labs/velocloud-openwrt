#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

DLLIST_ITEM *DLLIST_read_ITEM(DLLIST *dllist)
{
  return dllist->cur;
}

