#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void *DLLIST_prepend_fl(DLLIST *dllist, void *item, char *pFile, int nLine)
{
  DLLIST_ITEM *tmpitem;

  tmpitem = new_DLLIST_ITEM_fl(dllist, pFile, nLine);
  if (tmpitem == NULL) {
    return NULL;
  }
  tmpitem->item = item;

  DLLIST_prepend_ITEM(dllist, tmpitem);
  return(tmpitem->item);
}


