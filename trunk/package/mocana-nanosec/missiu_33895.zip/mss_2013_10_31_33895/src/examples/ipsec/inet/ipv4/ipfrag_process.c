/*
 * ip_frag_process.c
 *
 * Ip frag Rx Process function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/

#include "ipfrag_defs.h"

/*****************************************************************************
 *
 * debug
 *
 *****************************************************************************/
#ifndef NDEBUG
DWORD dwIpFragRxTossOffTooOldCount = 0;
#endif

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * IpFragInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hIpFrag                        Ip fragmentation Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG IpFragInstanceProcess(H_NETINSTANCE hIpFrag)
{
  IPFRAGSTATE *pxIpFrag = (IPFRAGSTATE *)hIpFrag;
  FRAG_DATAGRAM *pxDgram;
  DWORD dwTime;

  IPFRAG_CHECK_STATE(pxIpFrag);

  dwTime = (DWORD)NetGetMsecTime();

  DLLIST_head(&pxIpFrag->dllPending);
  while ((pxDgram = DLLIST_read(&pxIpFrag->dllPending)) != NULL) {
    if (dwTime > pxDgram->dwTimer + pxIpFrag->dwTO) {
      ICMPMSGDATA xIcmpMsgData;
      FRAG_PACKET *pxFragPacket;
      NETPACKETACCESS xNetPacketAccess;

      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPFRAG, INET_DBG_LEVEL_NORMAL))
      {
        /*IPFRAG_DBGP(NORMAL,"IpFragProcess: removing uncomplete datagrams, pxDgram = 0x%p\n",pxDgram);*/
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, "IpFragProcess: removing uncomplete datagrams, pxDgram = 0x", (int)pxDgram);
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
      }

      pxFragPacket = DLLIST_read(&pxDgram->dllPacket);
      ASSERT(pxFragPacket != NULL);

      /*Set NETPACKET*/
      pxDgram->xNetPacket.pxPayload = pxFragPacket->pxNetPayload;
      xIcmpMsgData.pxNetPacket       = &pxDgram->xNetPacket;
      /*Set NETPACKETACCESS*/
      xNetPacketAccess.wOffset = pxFragPacket->wOffset;
      xNetPacketAccess.wLength = pxFragPacket->wFragLength;
      xIcmpMsgData.pxNetPacketAccess = &xNetPacketAccess;
      /*These 2 lines are useless if oIfIdx and wVlan are in NETPACKET, FH 03/2002*/
      xIcmpMsgData.oIfIdx    = pxDgram->xNetworkId.oIfIdx;
      xIcmpMsgData.wVlan     = pxDgram->xNetworkId.wVlan;
      xIcmpMsgData.dwSrcAddr = pxDgram->dwDstIP;
      xIcmpMsgData.dwDstAddr = pxDgram->dwSrcIP;

      NETPAYLOAD_ADDUSER(pxFragPacket->pxNetPayload);
      /* been waiting too long, send icmp message*/
      ASSERT(pxIpFrag->pfnNetCbk != NULL);
      (LONG)pxIpFrag->pfnNetCbk((H_NETINSTANCE)pxIpFrag,IPFRAGCBK_TIME_EXCEEDED_FRAGTIME,(H_NETDATA)&xIcmpMsgData);

      DEBUG(dwIpFragRxTossOffTooOldCount ++;);
      SNMP(xTcpipData.ipReasmFails ++;)
      (void*)DLLIST_remove(&pxIpFrag->dllPending);
      IpFragFreeDgram((void*)pxDgram);
    }
    else {
      DLLIST_next(&pxIpFrag->dllPending);
    }
  }

  /* Nothing to do here - indicate as such */
  return 100;
}

