/*
 * pppoeclientdefs.h
 *
 * PPPoE client internal definitions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPPOECLIENTDEFS_H_
#define _PPPOECLIENTDEFS_H_

#include "NNstyle.h"
#include "flavor.h"
#include "stdlib.h"
#include "strings.h"
#include "pthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"
#include "ethernet.h"
#include "pppoeclientdbg.h"
#include "pppoecommon.h"
#include "pppoeparser.h"
#include "pppoeclient.h"

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

/*
 * State code
 */
typedef enum{
  PPPOECLIENTSTATE_INIT,
  PPPOECLIENTSTATE_DISCOVER,
  PPPOECLIENTSTATE_REQUEST,
  PPPOECLIENTSTATE_SESSION,
  PPPOECLIENTSTATE_TERMINATE,
} E_PPPOESTATE;
/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/

typedef struct {
#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

  E_PPPOESTATE eState; /* state */

  /* session information */
  PPPOEHDR xHdr;
  A_PPPOETAGTABLE axTagTable;
  ETHID xServerEthId;

  /* Options */
  WORD wOffset;
  WORD wTrailer;
  PFN_NETMALLOC pfnNetMalloc;
  PFN_NETFREE pfnNetFree;
  pthread_mutex_t *pxNetMutex;
  PFN_NETCBK pfnNetCbk;
  H_NETINSTANCE hNetCbk;
  DWORD dwRetransmissionTOBase;
  DWORD dwRetranmissionCounterBase;

  DWORD dwReconnectionTOBase;

  /* UL interface */
  OCTET oULNumber;
  PFN_NETRXCBK pfnRxCbk;
  H_NETINSTANCE hUl;
  H_NETINTERFACE hUlIf;

  /* LL interface */
  OCTET oLLNumber;
  PFN_NETWRITE pfnLlWrite;
  H_NETINSTANCE hLl;
  H_NETINTERFACE hLlPppoEIf;
  H_NETINTERFACE hLlSessionIf;

  /* Processing members */
  DWORD dwRetransmissionTO;
  DWORD dwNextRetransmissionT;
  DWORD dwRetranmissionCounter;

} PPPOECLIENTSTATE;

LONG PppoEClientInstanceResetTransmission(PPPOECLIENTSTATE *pxPppoeClient);
LONG PppoEClientCreatePacket(PPPOECLIENTSTATE *pxPppoeClient,
                             NETPACKET *pxNetPacket,
                             NETPACKETACCESS *pxAccess);
#ifdef PPPOECLIENTDBG_HI
CHAR* PppoECodeToString(OCTET oCode);
#endif /*PPPOECLIENTDBG_HI*/


#endif /* #ifndef _PPPOECLIENTDEFS_H_ */
