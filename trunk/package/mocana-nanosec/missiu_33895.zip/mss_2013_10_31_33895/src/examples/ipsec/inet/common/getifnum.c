#include "NNstyle.h"
#include "nettime.h"
#include "netpthread.h"
#include "../include/socket_inet.h"
#include "netcfg.h"
#include "setupnet.h"
/*#include "flavor.h" */

/*
 * SetupNetGetIfNum
 *  Get the number of interfaces
 *
 *  Args:
 *   poIfNum            Number of interfaces (to be filled)
 *
 *  Return
 *   SetupNetReturn
 */
SetupNetReturn SetupNetGetIfNum(OCTET* poIfNum)
{
#ifdef NET_MULTIF
  int iSocket;
  OCTET oIfNum;
  mnIoctlArgList_t mnIoctlArgList;      
  
  if ((iSocket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  mnIoctlArgList.oIfIdx = oIfNum;
  if (0 > ioctl(iSocket,MO_SIOCGIFNUM,&oIfNum)) {
    ASSERT(0);
    return SETUPNET_ERROR;
  }
  close(iSocket);
  
  *poIfNum = oIfNum;
#else
  *poIfNum = 1;
#endif  
  
  return SETUPNET_OK;
}
