/*
 * pppcp_action.c
 *
 * PPPCP action functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "pppcp_defs.h"
/*
 * PppCpInstanceEvent
 *   Send an event to the instance. Puts it on
 *   a message queue and returns.
 *
 *   Args:
 *     hPppCp            instance handle
 *     pxEvent           event
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceEvent(H_NETINSTANCE hPppCp,
                        PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  PPPCPEVENT *pxStoredEvent;

  /* SB. Not very efficient, but at this stage of
     negociation, cycles are less important than memory */
  ASSERT(pxEvent->eType < PPPCPEVENT_ENUMMAX);

  /*PPPCP_DBGP(REPETITIVE,"PppCpEvent:hPppCp=%d,event=%s,%ld event(s) remaining to be processed\n",
             (int)hPppCp,
             apoPppCpEventString[pxEvent->eType],
             DLLIST_count_inline(&(pxCpState->xdllEvent)));*/

  pxStoredEvent = (PPPCPEVENT *)calloc(1,sizeof(PPPCPEVENT));
  ASSERT(pxStoredEvent != NULL);

  memcpy(pxStoredEvent,pxEvent,sizeof(PPPCPEVENT));

  switch(pxEvent->eType) {
  case PPPCPADMINEVENT_UP:
  case PPPCPADMINEVENT_DOWN:
  case PPPCPADMINEVENT_OPEN:
  case PPPCPADMINEVENT_CLOSE:
  case PPPCPADMINEVENT_TOPLUS:
  case PPPCPADMINEVENT_TOMINUS:
  case PPPCPPARSEEVENT_RCA:
  case PPPCPPARSEEVENT_RCN:
  case PPPCPPARSEEVENT_RTR:
  case PPPCPPARSEEVENT_RTA:
    break;

  case PPPCPPARSEEVENT_RCRPLUS:
  case PPPCPPARSEEVENT_RCRMINUS:
    pxStoredEvent->hData = (H_NETDATA)calloc(1,sizeof(PPPCPOPTIONFIELDS));
    ASSERT(pxStoredEvent->hData != (H_NETDATA)NULL);
    memcpy((void *)pxStoredEvent->hData,(void *)pxEvent->hData,
           sizeof(PPPCPOPTIONFIELDS));
    break;

  case PPPCPADMINEVENT_RUC:
    {
      PPPCPPACKET *pxCpPacket = (PPPCPPACKET *)pxEvent->hData;
      PPPCPPACKET *pxStoredPacket;
      OCTET *poRUCPayload;

      NETPACKET_CHECK(pxCpPacket->pxPacket);

      pxStoredEvent->hData = (H_NETDATA) pxStoredPacket =
        malloc(sizeof(PPPCPPACKET));
      ASSERT(pxStoredPacket != NULL);

      pxStoredPacket->pxPacket = (NETPACKET *)calloc(1,sizeof(NETPACKET));
      ASSERT(pxStoredPacket->pxPacket != NULL);

      pxStoredPacket->pxAccess =
        (NETPACKETACCESS *) malloc(sizeof(NETPACKETACCESS));
      ASSERT(pxStoredPacket->pxAccess != NULL);
      pxStoredPacket->pxAccess->wOffset = 0;
      pxStoredPacket->pxAccess->wLength = pxCpPacket->pxAccess->wLength;

      poRUCPayload = (OCTET *)
        malloc(pxStoredPacket->pxAccess->wLength*sizeof(OCTET));
      ASSERT(poRUCPayload != NULL);
      memcpy(poRUCPayload,pxCpPacket->pxPacket->pxPayload->poPayload +
             pxCpPacket->pxAccess->wOffset,pxCpPacket->pxAccess->wLength);

      NETPAYLOAD_CREATE(&(pxStoredPacket->pxPacket->pxPayload),
                        NetFree,pxCpState->pxNetMutex,poRUCPayload,
                        pxStoredPacket->pxAccess->wLength);
    }
  break;

  default:
    //ASSERT(0);/* nothing to do */
    PPPCP_DBGP(ERROR,"PppCpInstanceEvent: No event\n");/* ASSERT(0); */
  break;
  }

  if (DLLIST_count(&(pxCpState->xdllEvent)) < PPPCP_EVENTMAX) {
    DLLIST_append(&(pxCpState->xdllEvent),pxStoredEvent);
  } else {
    PPPCP_DBGP(ERROR,"PppCpInstanceEvent: dll event is full\n");/* ASSERT(0); */
  }

  return 0;
}


/*
 * PppCPInstanceTimerReset
 *   reset the timer to its initial value and
 *   enable it
 *
 *   Args:
 *     hPppCp          instance handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceTimerReset(H_NETINSTANCE hPppCp)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;

  pxCpState->dwTimer = NetGlobalTimerGet() + pxCpState->dwTimerInitial;

  /* Enable Timer processing */
  pxCpState->bTimer = TRUE;

  return 0;
}

/*
 * PppCpSetHeader
 *   Set a PPP CP header
 *
 *   Args:
 *     poPacket          pointer to the start of the header
 *     oCommand          PPP CP command
 *     oId               byte Id of the command
 *     wLength           Total length of the PPP CP packet
 *
 *   Return:
 *     >=0
 */
LONG PppCpSetHeader(OCTET *poPacket,
                    OCTET oCommand,OCTET oId,
                    WORD wLength)
{
  *(poPacket + PPPCPOFFSET_COMMAND) = oCommand;
  *(poPacket + PPPCPOFFSET_ID) = oId;
  *((WORD *)(poPacket + PPPCPOFFSET_LENGTH)) = htons(wLength);

  return 0;
}

/*
 * PppCpInstanceSendCommand
 *   Send a Command for an PPP CP instance
 *
 *   Args:
 *     hPppCp             instance handle
 *     oCommand           command
 *     poData             command associated data
 *     wDataLength        length of poData
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceSendCommand(H_NETINSTANCE hPppCp,OCTET oCommand,
                              OCTET *poData, WORD wDataLength)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  NETPACKETACCESS xAccess;
  NETPACKET xNetPacket;
  NETIFID xNetIfId;
  OCTET *poMsg;
  WORD wSize;

  ASSERT(pxCpState != NULL);
  ASSERT((pxCpState->pfnLlWrite != NULL) &&
         (pxCpState->pfnNetMalloc != NULL) &&
         (pxCpState->pfnNetFree != NULL));

  ASSERT(pxCpState->wOffset != 0);

  xAccess.wOffset = pxCpState->wOffset;
  xAccess.wLength = ((wDataLength + PPPCP_HLEN) < PPPPACKET_MINSIZE) ?
                      PPPPACKET_MINSIZE:(wDataLength + PPPCP_HLEN);

  wSize = xAccess.wLength + xAccess.wOffset + pxCpState->wTrailer;

  /* Build the message */

  poMsg = pxCpState->pfnNetMalloc(wSize * sizeof(OCTET));
  ASSERT(poMsg != NULL);

  PppCpSetHeader(poMsg + xAccess.wOffset,
                 oCommand,
                 pxCpState->aoCurrSndId[oCommand - PPPCPCOMMAND_MIN],
                 wDataLength + PPPCP_HLEN);

  NETPAYLOAD_CREATE(&(xNetPacket.pxPayload),pxCpState->pfnNetFree,
                    pxCpState->pxNetMutex,poMsg,wSize);

  xNetPacket.hMarker = (H_NETDATA)NULL;

  if (oCommand == PPPCPCOMMAND_PROTOCOLREJECT) {
    pxCpState->aoCurrSndId[oCommand - PPPCPCOMMAND_MIN] ++;
  }
  if (wDataLength > 0) {
    memcpy(poMsg + xAccess.wOffset + PPPCP_HLEN,
           poData,wDataLength);
  }

  xNetIfId.oIfIdx = pxCpState->oIfIdx;
  xNetIfId.wVlan = pxCpState->wVlan;

  pxCpState->pfnLlWrite(pxCpState->hLl,pxCpState->hLlIf,
                        &xNetPacket,&xAccess,(H_NETDATA)&xNetIfId);

  return 0;
}

/*
 * PppCpFreeEvent
 *   Clear an event structure
 *
 *   Args:
 *     pxEvent        Event structure to be cleared
 *
 *   Return:
 *     >=0
 */
void PppCpFreeEvent(void *px)
{
  PPPCPEVENT *pxEvent = (PPPCPEVENT *)px;

  switch(pxEvent->eType) {

  case PPPCPPARSEEVENT_RCRPLUS:
  case PPPCPPARSEEVENT_RCRMINUS:
    {
      PPPCPOPTIONFIELDS *pxData = (PPPCPOPTIONFIELDS *)pxEvent->hData;
      ASSERT(pxData != NULL);
      if (pxData->poNak != NULL) {
        free(pxData->poNak);
      }
      if (pxData->poRej != NULL) {
        free(pxData->poRej);
      }
      if (pxData->poReq != NULL) {
        free(pxData->poReq);
      }
      free(pxData);
      break;
    }

  case PPPCPADMINEVENT_RUC:
    {
      PPPCPPACKET *pxPacket = (PPPCPPACKET *)pxEvent->hData;

      NETPAYLOAD_DELUSER(pxPacket->pxPacket->pxPayload);

      free(pxPacket->pxAccess);
      free(pxPacket->pxPacket);
    }
  break;

  default:
    /* Nothing to free */
    PPPCP_DBGP(ERROR,"PppCpFreeEvent: Nothing to Free\n");/* ASSERT(0); */
     break;
  }

  free(pxEvent);

  return;
}

/*
 * PppCpInstanceProcessEvent
 *  Implements state machine transition
 *
 *  Args:
 *   hPppCp                CP instance
 *   pxEvent               Event received
 *
 *  Return:
 *   >=0
 */
LONG PppCpInstanceProcessEvent(H_NETINSTANCE hPppCp,
                               PPPCPEVENT *pxEvent)
{
  PPPCPSTATE *pxCpState = (PPPCPSTATE *)hPppCp;
  const PPPCPSTATETRANSITION *pxTransition;

  ASSERT((pxCpState != NULL) &&
         (pxEvent != NULL) &&
         (pxCpState->eState < PPPCPSTATE_ENUMMAX) &&
         (pxEvent->eType < PPPCPEVENT_ENUMMAX));

  pxTransition = &(aaxStateTransitionTable[pxCpState->eState][pxEvent->eType]);
  ASSERT(pxTransition != NULL);

  PPPCP_DBGP(REPETITIVE,"PppCpProcessEvent:hPppCp=%d,event=%s,state:%s => %s\n",
             (int)hPppCp,
              apoPppCpEventString[pxEvent->eType],
              apoPppCpStateString[pxCpState->eState],
              apoPppCpStateString[pxTransition->oNextState]);

  if (pxTransition->cActionSetIndex != PPPCPACTIONSETINDEX_NONE) {
    OCTET o = 0;
    /* If there is something to do */
    const PPPCPACTIONSET *pxActionSet;

    ASSERT(pxTransition->cActionSetIndex < PPPCPACTIONSETINDEX_MAX);

    pxActionSet = &(axActionSetTable[(OCTET)pxTransition->cActionSetIndex]);

    while (o < pxActionSet->oActionNum) {
      ASSERT((o < PPPCPACTIONSET_MAXSIZE) &&
             (PPPCPACTIONINDEX_NONE < pxActionSet->acActions[o] < PPPCPACTIONINDEX_MAX) &&
             (axpfnActionTable[(OCTET)(pxActionSet->acActions[o])] != NULL));
      axpfnActionTable[(OCTET)(pxActionSet->acActions[o])](hPppCp,pxEvent);
      o++;
    }

  }

  pxCpState->eState = pxTransition->oNextState;

  PppCpFreeEvent(pxEvent);

  return 0;
}
