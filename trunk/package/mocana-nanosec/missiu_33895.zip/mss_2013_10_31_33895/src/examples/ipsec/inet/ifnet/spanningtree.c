/*
 * spanningtree.c
 *
 * Implements the spanning tree algorithm and protocol
 * Mainly code taken from ANSI/IEEE Std 802.1D, 1998 Edition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include <NNstyle.h>
#include "ethbridge_flavor.h"
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <syslog.h>
#include <pthread.h>
#include "sys/socket.h" /* NNOS ntohx, htonx defs */
#include "netcommon.h"
#include "netdefs.h"
#include "ethernet.h"
#include "bridgedefs.h"
#include "spanningtree.h"
#include "bridgedbg.h"

/* Storage of the ethernet instance set during init fn */
static ETHSTATE *pxStpEth = NULL;

/* The spanning tree address */
OCTET aoSpanningTreeAddr[ETHADDRESS_LEN] = {0x01,0x80,0xC2,0x00,0x00,0x00};

/********************************************************
Ethernet packet format:
      +-------------------------------------+
      | 802.3 MAC    | 802.2 LLC    | BPDU  |
      +-------------------------------------+
      |Dest|Src |len |DSAP|SSAP|cntl|       |
Bytes | 6  | 6  | 2  | 1  | 1  | 1  |  35   |
      +-------------------------------------+

BPDU format
+---------------------+ Octet
+ Protocol Identifier + 1,2
+ Protocol Version Id + 3
+ BPDU Type           + 4
+ Flags               + 5
+ Root Identifier     + 6 - 13
+ Root Path Cost      + 14- 17
+ Bridge Identifier   + 18- 25
+ Port Identifier     + 26,27
+ Message Age         + 28,29
+ Max Age             + 30,31
+ Hello Time          + 32,33
+ Forward Delay       + 34,35
+---------------------+
*********************************************************/

#define MAC_LEN_HI_B      12
#define MAC_LEN_LO_B      13
#define LLC_DSAP_B        14
#define LLC_SSAP_B        15
#define LLC_CNTL_B        16

#define BPDU_OFFSET       LLC_CNTL_B
#define BPDU_ID_HI_B      (BPDU_OFFSET + 1)
#define BPDU_ID_LO_B      (BPDU_OFFSET + 2)
#define BPDU_V_ID_B       (BPDU_OFFSET + 3)
#define BPDU_TYPE_B       (BPDU_OFFSET + 4)
#define BPDU_TCN_PKT_LEN  (BPDU_TYPE_B + 1)

#define BPDU_FLAGS_B      (BPDU_OFFSET + 5)
#define TOP_CHANGE_AK_FLG 0x80
#define TOP_CHANGE_FLG    0x01

#define BPDU_RT_ID_HI_DW  (BPDU_OFFSET + 6)
#define BPDU_RT_ID_LO_DW  (BPDU_OFFSET + 10)
#define BPDU_RT_C0ST_DW   (BPDU_OFFSET + 14)
#define BPDU_BR_ID_HI_DW  (BPDU_OFFSET + 18)
#define BPDU_BR_ID_LO_DW  (BPDU_OFFSET + 22)
#define BPDU_PORT_ID_W    (BPDU_OFFSET + 26)
#define BPDU_MSG_AGE_W    (BPDU_OFFSET + 28)
#define BPDU_MAX_AGE_W    (BPDU_OFFSET + 30)
#define BPDU_HELLO_TIM_W  (BPDU_OFFSET + 32)
#define BPDU_FWD_DELAY_W  (BPDU_OFFSET + 34)
#define BPDU_CONF_PKT_LEN (BPDU_FWD_DELAY_W + 2)

/***************************************************************************
* STATIC STORAGE ALLOCATION
**************************************************************************/

Bridge_data   bridge_info;                                /* (8.5.3) */
Port_data     port_info[All_ports];                       /* (8.5.5) */
Config_bpdu   config_bpdu[All_ports];
Tcn_bpdu      tcn_bpdu[All_ports];
Timer         hello_timer;                                /* (8.5.4.1) */
Timer         tcn_timer;                                  /* (8.5.4.2) */
Timer         topology_change_timer;                      /* (8.5.4.3) */
Timer         message_age_timer[All_ports];               /* (8.5.6.1) */
Timer         forward_delay_timer[All_ports];             /* (8.5.6.2) */
Timer         hold_timer[All_ports];                      /* (8.5.6.3) */

Int           No_of_ports;

/* Spanning tree protocol mutex */
pthread_mutex_t xMutex_STP;

/*************************************************************************
 * Function prototypes
 *************************************************************************/
void send_config_bpdu(Int port_no, Config_bpdu *bpdu);
void send_tcn_bpdu(Int port_no, Tcn_bpdu *bpdu);


/***************************************************************************
* CODE
**************************************************************************/

Boolean root_bridge(void)
{
  return(ISEQ_IDWORD(bridge_info.designated_root, bridge_info.bridge_id));
}

void start_hold_timer(port_no)
Int port_no;
{
  hold_timer[port_no].value = Zero;
  hold_timer[port_no].active = True;
}

void stop_hold_timer(port_no)
Int port_no;
{
  hold_timer[port_no].active = False;
}

void start_hello_timer(void)
{
  hello_timer.value = (Time) Zero;
  hello_timer.active = True;
}

void stop_hello_timer(void)
{
  hello_timer.active = False;
}

void start_tcn_timer(void)
{
  tcn_timer.value = (Time) Zero;
  tcn_timer.active = True;
}

void stop_tcn_timer(void)
{
  tcn_timer.active = False;
}

void start_topology_change_timer(void)
{
  topology_change_timer.value = (Time) Zero;
  topology_change_timer.active = True;
}

void stop_topology_change_timer(void)
{
  topology_change_timer.active = False;
}

void start_message_age_timer(port_no, message_age)
Int port_no;
Time message_age;
{
  message_age_timer[port_no].value = message_age;
  message_age_timer[port_no].active = True;
}

void stop_message_age_timer(port_no)
Int port_no;
{
  message_age_timer[port_no].active = False;
}

void start_forward_delay_timer(port_no)
Int port_no;
{
  forward_delay_timer[port_no].value = Zero;
  forward_delay_timer[port_no].active = True;
}

void stop_forward_delay_timer(port_no)
Int port_no;
{
  forward_delay_timer[port_no].active = False;
}


Boolean designated_port(port_no)
Int port_no;
{
  return (
           ( ISEQ_IDWORD(port_info[port_no].designated_bridge,
              bridge_info.bridge_id)
           )
           &&
           ( port_info[port_no].designated_port
             == port_info[port_no].port_id
           )
         );
}

/** Elements of Procedure (8.6) **/

void transmit_config(port_no)                                  /* (8.6.1) */
Int port_no;
{
  if (hold_timer[port_no].active)                         /* (8.6.1.3.1) */
  {
    port_info[port_no].config_pending = True;             /* (8.6.1.3.1) */
  }
  else                                                    /* (8.6.1.3.2) */
  {
    config_bpdu[port_no].type = Config_bpdu_type;
    config_bpdu[port_no].root_id = bridge_info.designated_root;
                                                          /* (8.6.1.3.2(a))*/
    config_bpdu[port_no].root_path_cost = bridge_info.root_path_cost;
                                                          /* (8.6.1.3.2(b))*/
    config_bpdu[port_no].bridge_id = bridge_info.bridge_id;
                                                          /* (8.6.1.3.2(c))*/
    config_bpdu[port_no].port_id = port_info[port_no].port_id;

                                                          /* (8.6.1.3.2(d))*/
    if (root_bridge())
    {
      config_bpdu[port_no].message_age = Zero;            /* (8.6.1.3.2(e))*/
    }
    else
    {
      config_bpdu[port_no].message_age
        = message_age_timer[bridge_info.root_port].value
        + Message_age_increment;                          /* (8.6.1.3.2(f))*/
    }
    config_bpdu[port_no].max_age = bridge_info.max_age;   /* (8.6.1.3.2(g))*/
    config_bpdu[port_no].hello_time = bridge_info.hello_time;
    config_bpdu[port_no].forward_delay = bridge_info.forward_delay;
    config_bpdu[port_no].topology_change_acknowledgment
      = port_info[port_no].topology_change_acknowledge;
                                                          /* (8.6.1.3.2(h)) */
    config_bpdu[port_no].topology_change
      = bridge_info.topology_change;                      /* (8.6.1.3.2(i)) */
    if (config_bpdu[port_no].message_age < bridge_info.max_age)
    {
      port_info[port_no].topology_change_acknowledge = False;
                                                          /* (8.6.1.3.3) */
      port_info[port_no].config_pending = False;          /* (8.6.1.3.3)*/
      send_config_bpdu(port_no, &config_bpdu[port_no]);
      start_hold_timer(port_no);                          /* (8.6.3.3(b))*/
    }
  }
}


Boolean supersedes_port_info(port_no, config)             /* (8.6.2.2) */
Int port_no;
Config_bpdu *config;
{
  return (
    (
      ISLT_IDWORD(config->root_id,
        port_info[port_no].designated_root)                 /* (8.6.2.2 a) */
    )
    ||
    ( (
      ISEQ_IDWORD(config->root_id,
        port_info[port_no].designated_root)
      )
      &&
      ( ( config->root_path_cost
        < port_info[port_no].designated_cost              /* (8.6.2.2 b) */
        )
        ||
        ( ( config->root_path_cost
          == port_info[port_no].designated_cost
          )
          &&
          ( (
            ISLT_IDWORD(config->bridge_id,
              port_info[port_no].designated_bridge)        /* (8.6.2.2 c) */
            )
            ||
            ( (
              ISEQ_IDWORD(config->bridge_id,
                port_info[port_no].designated_bridge)
              )                                           /* (8.6.2.2 d) */
              &&
              ( (
                  !(ISEQ_IDWORD(config->bridge_id, bridge_info.bridge_id))
                )                                         /* (8.6.2.2 d1) */
                ||
                ( config->port_id
                  <= port_info[port_no].designated_port
                )                                         /* (8.6.2.2 d2) */
    ) ) ) ) ) )
         );
}

void record_config_information(port_no, config)                /* (8.6.2) */
Int port_no;
Config_bpdu *config;
{
  port_info[port_no].designated_root = config->root_id;   /* (8.6.2.3.1) */
  port_info[port_no].designated_cost = config->root_path_cost;
  port_info[port_no].designated_bridge = config->bridge_id;
  port_info[port_no].designated_port = config->port_id;
  start_message_age_timer(port_no, config->message_age);  /* (8.6.2.3.2) */
}

void record_config_timeout_values(config)                      /* (8.6.3) */
Config_bpdu *config;
{
  bridge_info.max_age = config->max_age;                  /* (8.6.3.3) */
  bridge_info.hello_time = config->hello_time;
  bridge_info.forward_delay = config->forward_delay;
  bridge_info.topology_change = config->topology_change;
}

void config_bpdu_generation(void)                                  /* (8.6.4) */
{
  Int port_no;
  for (port_no = One; port_no <= No_of_ports; port_no++)  /* (8.6.4.3) */
  {
    if ( designated_port(port_no)                         /* (8.6.4.3) */
         &&
         (port_info[port_no].state != Disabled)
       )
    {
      transmit_config(port_no);                           /* (8.6.4.3) */
    }                                                     /* (8.6.1.2) */
  }
}


void reply(port_no)                                            /* (8.6.5) */
Int port_no;
{
  transmit_config(port_no);                               /* (8.6.5.3) */
}

void transmit_tcn(void)                                            /* (8.6.6) */
{
  Int port_no;
  port_no = bridge_info.root_port;
  tcn_bpdu[port_no].type = Tcn_bpdu_type;
  send_tcn_bpdu(port_no, &tcn_bpdu[bridge_info.root_port]);/* (8.6.6.3) */
}


void root_selection(void)                                          /* (8.6.8) */
{
  Int root_port;
  Int port_no;

  root_port = No_port;

  for (port_no = One; port_no <= No_of_ports; port_no++)  /* (8.6.8.3.1) */
  {
    if  ( ( (!designated_port(port_no))
            &&
            (port_info[port_no].state != Disabled)
            &&
            (
            ISLT_IDWORD(port_info[port_no].designated_root, bridge_info.bridge_id)
            )
          )
          &&
          ( (root_port == No_port)
            ||
            (
              ISLT_IDWORD(port_info[port_no].designated_root,
                port_info[root_port].designated_root)      /* (8.6.8.3.1(a)) */
            )
            ||
            ( (
                ISEQ_IDWORD(port_info[port_no].designated_root,
                  port_info[root_port].designated_root)
              )
              &&
              ( ( ( port_info[port_no].designated_cost
                    + port_info[port_no].path_cost
                  )
                  <
                  ( port_info[root_port].designated_cost
                    + port_info[root_port].path_cost
                  )                                       /* (8.6.8.3.1(b)) */
                )
                ||
                ( ( ( port_info[port_no].designated_cost
                      + port_info[port_no].path_cost
                    )
                    ==
                    ( port_info[root_port].designated_cost
                      + port_info[root_port].path_cost
                    )
                  )
                  &&
                  ( (
                      ISLT_IDWORD(port_info[port_no].designated_bridge,
                        port_info[root_port].designated_bridge)
                    )                                     /* (8.6.8.3.1(c)) */
                    ||
                    ( (
                        ISEQ_IDWORD(port_info[port_no].designated_bridge,
                          port_info[root_port].designated_bridge)
                      )
                      &&
                      ( ( port_info[port_no].designated_port
                          < port_info[root_port].designated_port
                        )                                 /* (8.6.8.3.1(d)) */
                        ||
                        ( ( port_info[port_no].designated_port
                            == port_info[root_port].designated_port
                          )
                          &&
                          ( port_info[port_no].port_id
                            < port_info[root_port].port_id
                          )                               /* (8.6.8.3.1(e)) */
        ) ) ) ) ) ) ) ) )
    {
      root_port = port_no;
    }
  }

  bridge_info.root_port = root_port;                      /* (8.6.8.3.1) */

  if (root_port == No_port)                               /* (8.6.8.3.2) */
  {
    bridge_info.designated_root = bridge_info.bridge_id;
                                                          /* (8.6.8.3.2(a)) */
    bridge_info.root_path_cost = Zero;                    /* (8.6.8.3.2(b)) */
  }
  else                                                    /* (8.6.8.3.3) */
  {
    bridge_info.designated_root = port_info[root_port].designated_root;
                                                          /* (8.6.8.3.3(a)) */
    bridge_info.root_path_cost = ( port_info[root_port].designated_cost
                                   + port_info[root_port].path_cost
                                 );                       /* (8.6.8.3.3(b)) */
  }
}

void become_designated_port(port_no)                           /* (8.6.10) */
Int port_no;
{
  port_info[port_no].designated_root = bridge_info.designated_root;
                                                          /* (8.6.10.3 a) */
  port_info[port_no].designated_cost = bridge_info.root_path_cost;
                                                          /* (8.6.10.3 b) */
  port_info[port_no].designated_bridge = bridge_info.bridge_id;
                                                          /* (8.6.10.3 c) */
  port_info[port_no].designated_port = port_info[port_no].port_id;
                                                          /* (8.6.10.3 d) */
}

void designated_port_selection(void)                               /* (8.6.9) */
{
  Int port_no;
  for (port_no = One; port_no <= No_of_ports; port_no++)  /* (8.6.9.3) */
  {
    if  ( designated_port(port_no)                        /* (8.6.9.3 a) */
          ||
          (
            !ISEQ_IDWORD(port_info[port_no].designated_root,
              bridge_info.designated_root)                /* (8.6.9.3 b) */
          )
          ||
          ( bridge_info.root_path_cost
            < port_info[port_no].designated_cost
          )                                               /* (8.6.9.3 c) */
          ||
          ( ( bridge_info.root_path_cost
              == port_info[port_no].designated_cost
            )
            &&
            ( (
                ISLT_IDWORD(bridge_info.bridge_id,
                  port_info[port_no].designated_bridge)
              )                                           /* (8.6.9.3 d) */
              ||
              ( (
                  ISEQ_IDWORD(bridge_info.bridge_id,
                    port_info[port_no].designated_bridge)
                )
                &&
                ( port_info[port_no].port_id
                  <= port_info[port_no].designated_port
                )                                         /* (8.6.9.3 e) */
        ) ) ) )
    {
      become_designated_port(port_no);                    /* (8.6.10.2 a) */
    }
  }
}

Boolean designated_for_some_port(void)
{
  Int port_no;
  for (port_no = One; port_no <= No_of_ports; port_no++)
  {
    if  (
          ISEQ_IDWORD(port_info[port_no].designated_bridge,
            bridge_info.bridge_id)
        )
    {
      return(True);
    }
  }
  return(False);
}


void configuration_update(void)                                    /* (8.6.7) */
{
  root_selection();                                       /* (8.6.7.3.1) */
                                                          /* (8.6.8.2) */
  designated_port_selection();                            /* (8.6.7.3.2) */
                                                          /* (8.6.9.2) */
}



void set_port_state(port_no, state)
Int port_no;
State state;
{
  int iRv;
  if(!RTOS_mutexWait((RTOS_MUTEX)&(xMutex_STP))){
    port_info[port_no].state = state;
  }
  RTOS_mutexRelease((RTOS_MUTEX)&(xMutex_STP));
  ASSERT(iRv == 0);
}


void make_forwarding(port_no)                                  /* (8.6.12) */
Int port_no;
{
  if (port_info[port_no].state == Blocking)               /* (8.6.12.3) */
  {
    set_port_state(port_no, Listening);                   /* (8.6.12.3 a) */
    start_forward_delay_timer(port_no);                   /* (8.6.12.3 b) */
  }
}

void topology_change_detection(void)                               /* (8.6.14) */
{
  if (root_bridge())                                      /* (8.6.14.3 a) */
  {
    bridge_info.topology_change = True;                   /* (8.6.14.3 a1)*/
    start_topology_change_timer();                        /* (8.6.14.3 a2)*/
  }
  else if (bridge_info.topology_change_detected == False) /* (8.6.14.3 b) */
  {
    transmit_tcn();                                       /* (8.6.14.3 b1)*/
    start_tcn_timer();                                    /* (8.6.14.3 b2)*/
  }
  bridge_info.topology_change_detected = True;            /* (8.6.14.3 c) */
}

void make_blocking(port_no)                                    /* (8.6.13) */
Int port_no;
{
  if  ( (port_info[port_no].state != Disabled)
        &&
        (port_info[port_no].state != Blocking)
        )                                                 /* (8.6.13.3) */
  {
    if  ( (port_info[port_no].state == Forwarding)
          ||
          (port_info[port_no].state == Learning)
        )
    {
      if (port_info[port_no].change_detection_enabled == True)
                                                          /* (8.5.5.10) */
      {
        topology_change_detection();                      /* (8.6.13.3 a) */
       }                                                  /* (8.6.14.2.3) */
    }

    set_port_state(port_no, Blocking);                    /* (8.6.13.3 b) */

    stop_forward_delay_timer(port_no);                    /* (8.6.13.3 c) */
  }
}

void port_state_selection(void)                                    /* (8.6.11) */
{
  Int port_no;
  for (port_no = One; port_no <= No_of_ports; port_no++)
  {
    if (port_no == bridge_info.root_port)                 /* (8.6.11.3 a) */
    {
      port_info[port_no].config_pending = False;          /* (8.6.11.3 a1)*/
      port_info[port_no].topology_change_acknowledge = False;
      make_forwarding(port_no);                           /* (8.6.11.3 a2)*/
    }
    else if (designated_port(port_no))                    /* (8.6.11.3 b) */
    {
      stop_message_age_timer(port_no);                    /* (8.6.11.3 b1)*/
      make_forwarding(port_no);                           /* (8.6.11.3 b2)*/
    }
    else                                                  /* (8.6.11.3 c) */
    {
      port_info[port_no].config_pending = False;          /* (8.6.11.3 c1)*/
      port_info[port_no].topology_change_acknowledge = False;
      make_blocking(port_no);                             /* (8.6.11.3 c2)*/
    }
  }
}



void topology_change_acknowledged(void)                            /* (8.6.15) */
{
  bridge_info.topology_change_detected = False;           /* (8.6.15.3 a) */
  stop_tcn_timer();                                       /* (8.6.15.3 b) */
}


void acknowledge_topology_change(port_no)                      /* (8.6.16) */
Int port_no;
{
  port_info[port_no].topology_change_acknowledge = True;  /* (8.6.16.3 a) */
  transmit_config(port_no);                               /* (8.6.16.3 b) */
}

/** Operation of the Protocol (8.7) **/

void received_config_bpdu(Int port_no, Config_bpdu *config) /* (8.7.1) */
{
  Boolean root;
  root = root_bridge();
  if (port_info[port_no].state != Disabled)
  {
    if (supersedes_port_info(port_no, config))            /* (8.7.1.1) */
    {                                                     /* (8.6.2.2) */
      record_config_information(port_no, config);         /* (8.7.1.1 a) */
                                                          /* (8.6.2.2) */
      configuration_update();                             /* (8.7.1.1 b) */
                                                          /* (8.6.7.2 a) */
      port_state_selection();                             /* (8.7.1.1 c) */
                                                          /* (8.6.11.2 a) */
      if ((!root_bridge()) && root)                       /* (8.7.1.1 d) */
      {
        stop_hello_timer();
        if (bridge_info.topology_change_detected)         /* (8.7.1.1 e) */
        {
          stop_topology_change_timer();
          transmit_tcn();                                 /* (8.6.6.1) */
          start_tcn_timer();
        }
      }
      if (port_no == bridge_info.root_port)
      {
        record_config_timeout_values(config);             /* (8.7.1.1 e) */
                                                          /* (8.6.3.2) */
        config_bpdu_generation();                         /* (8.6.4.2 a) */
        if (config->topology_change_acknowledgment)       /* (8.7.1.1 g) */
        {
          topology_change_acknowledged();                 /* (8.6.15.2) */
        }
      }
    }
    else if (designated_port(port_no))                    /* (8.7.1.2) */
    {
      reply(port_no);                                     /* (8.7.1.2) */
                                                          /* (8.6.5.2) */
    }
  }
}

void received_tcn_bpdu(port_no, tcn)                           /* (8.7.2) */
Int port_no;
Tcn_bpdu *tcn;
{
  if (port_info[port_no].state != Disabled)
  {
    if (designated_port(port_no))
    {
      topology_change_detection();                        /* (8.7.2 a) */
                                                          /* (8.6.14.2.1) */
      acknowledge_topology_change(port_no);               /* (8.7.2 b) */
    }                                                     /* (8.6.16.2) */
  }
}


Boolean hello_timer_expired(void)
{
  if (hello_timer.active &&
      ((hello_timer.value += STP_INCREMENT) >= bridge_info.hello_time))
  {
    hello_timer.active = False;
    return(True);
  }
  return(False);
}

void hello_timer_expiry(void)                                      /* (8.7.3) */
{
  config_bpdu_generation();                               /* (8.6.4.2 b) */
  start_hello_timer();
}

Boolean message_age_timer_expired(port_no)
Int port_no;
{
  if  (message_age_timer[port_no].active &&
      ((message_age_timer[port_no].value += STP_INCREMENT) >= bridge_info.max_age))
  { message_age_timer[port_no].active = False;
    return(True);
  }
  return(False);
}

void message_age_timer_expiry(port_no)                         /* (8.7.4) */
Int port_no;
{
  Boolean root;

  root = root_bridge();

  become_designated_port(port_no);                        /* (8.7.4 a) */
                                                          /* (8.6.10.2 b) */
  configuration_update();                                 /* (8.7.4 b) */
                                                          /* (8.6.7.2 b) */
  port_state_selection();                                 /* (8.7.4 c) */
                                                          /* (8.6.11.2 b) */

  if ((root_bridge()) && (!root))                         /* (8.7.4 d) */
  {
    bridge_info.max_age = bridge_info.bridge_max_age;     /* (8.7.4 d1) */
    bridge_info.hello_time = bridge_info.bridge_hello_time;
    bridge_info.forward_delay = bridge_info.bridge_forward_delay;
    topology_change_detection();                          /* (8.7.4 d2) */
                                                          /* (8.6.14.2.4) */
    stop_tcn_timer();                                     /* (8.7.4 d3) */
    config_bpdu_generation();                             /* (8.7.4 d4) */
    start_hello_timer();
  }
}

Boolean forward_delay_timer_expired(port_no)
Int port_no;
{
  if  (forward_delay_timer[port_no].active &&
      ((forward_delay_timer[port_no].value += STP_INCREMENT) >= bridge_info.forward_delay))
  {
    forward_delay_timer[port_no].active = False;
    return(True);
  }
  return(False);
}

void forward_delay_timer_expiry(port_no)                       /* (8.7.5) */
Int port_no;
{
  if (port_info[port_no].state == Listening)              /* (8.7.5 a) */
  {
    set_port_state(port_no, Learning);                    /* (8.7.5 a1) */
    start_forward_delay_timer(port_no);                   /* (8.7.5 a2) */
  }
  else if (port_info[port_no].state == Learning)          /* (8.7.5 b) */
  {
    set_port_state(port_no, Forwarding);                  /* (8.7.5 b1) */
    if (designated_for_some_port())                       /* (8.7.5 b2) */
    {
      if (port_info[port_no].change_detection_enabled == True)
                                                          /* (8.5.5.10) */
      {
        topology_change_detection();                      /* (8.6.14.2.2) */
      }
    }
  }
}

Boolean tcn_timer_expired(void)
{
  if (tcn_timer.active && ((tcn_timer.value += STP_INCREMENT) >= bridge_info.bridge_hello_time))
  {
    tcn_timer.active = False;
    return(True);
  }
  return(False);
}

void tcn_timer_expiry(void) /* (8.7.6) */
{
    transmit_tcn(); /* (8.7.6 a) */
    start_tcn_timer(); /* (8.7.6 b) */
}

Boolean topology_change_timer_expired(void)
{
  if  ( topology_change_timer.active
        && ( (topology_change_timer.value += STP_INCREMENT)
             >= bridge_info.topology_change_time
           )
      )
  {
    topology_change_timer.active = False;
    return(True);
  }
  return(False);
}

void topology_change_timer_expiry(void) /* (8.7.7) */
{
    bridge_info.topology_change_detected = False; /* (8.7.7 a) */
    bridge_info.topology_change = False; /* (8.7.7 b) */
}

Boolean hold_timer_expired(port_no)
Int port_no;
{
  if  (hold_timer[port_no].active &&
      ((hold_timer[port_no].value += STP_INCREMENT) >= bridge_info.hold_time))
  { hold_timer[port_no].active = False;
    return(True);
  }
  return(False);
}

void hold_timer_expiry(port_no) /* (8.7.8) */
Int port_no;
{
    if (port_info[port_no].config_pending)
    {
        transmit_config(port_no); /* (8.6.1.2) */
    }
}



/** Management of the Bridge Protocol Entity (8.8) **/

/*
*/
void initialize_port(port_no)
Int port_no;
{
  become_designated_port(port_no);                        /* (8.8.1 d1) */
  set_port_state(port_no, Blocking);                      /* (8.8.1 d2) */
  port_info[port_no].topology_change_acknowledge = False;
                                                          /* (8.8.1 d3) */
  port_info[port_no].config_pending = False;              /* (8.8.1 d4) */
  port_info[port_no].change_detection_enabled = True;     /* (8.8.1 d8) */


  stop_message_age_timer(port_no);                        /* (8.8.1 d5) */
  stop_forward_delay_timer(port_no);                      /* (8.8.1 d6) */
  stop_hold_timer(port_no);                               /* (8.8.1 d7) */
}


void set_port_priority(port_no, new_port_id)                   /* (8.8.5) */
Int port_no;
Port_id new_port_id;                                      /* (8.8.5 a) */
{
  if (designated_port(port_no))                           /* (8.8.5 b) */
  {
    port_info[port_no].designated_port = new_port_id;
  }
  port_info[port_no].port_id = new_port_id;               /* (8.8.5 c) */
  if  ( (
          ISEQ_IDWORD(bridge_info.bridge_id,
                      port_info[port_no].designated_bridge)

        )
        &&
        ( port_info[port_no].port_id
          < port_info[port_no].designated_port
        )
      )
  {
    become_designated_port(port_no);                      /* (8.8.5 d1) */
    port_state_selection();                               /* (8.8.5 d2) */
  }
}

/*
*/
void set_path_cost(port_no, path_cost)                         /* (8.8.6) */
Int port_no;
Cost path_cost;
{
  port_info[port_no].path_cost = path_cost;               /* (8.8.6 a) */
  configuration_update();                                 /* (8.8.6 b) */
  port_state_selection();                                 /* (8.8.6 c) */
}


void initialisation(OCTET obStart)                        /* (8.8.1) */
{
  Int port_no;

  bridge_info.designated_root = bridge_info.bridge_id;    /* (8.8.1 a) */
  bridge_info.root_path_cost = Zero;
  bridge_info.root_port = No_port;
  bridge_info.max_age = bridge_info.bridge_max_age;       /* (8.8.1 b) */
  bridge_info.hello_time = bridge_info.bridge_hello_time;
  bridge_info.forward_delay = bridge_info.bridge_forward_delay;
  bridge_info.topology_change_detected = False;           /* (8.8.1 c) */
  bridge_info.topology_change = False;
  stop_tcn_timer();
  stop_topology_change_timer();
  for (port_no = One; port_no <= No_of_ports; port_no++)  /* (8.8.1 d) */
  {
    initialize_port(port_no);
  }
  port_state_selection();                                 /* (8.8.1 e) */

  if (obStart == (OCTET)TRUE) {
    config_bpdu_generation();                             /* (8.8.1 f) */
    start_hello_timer();
  } else {
    stop_hello_timer();
  }
}


/*
 * Unused functions
 */
#if 0
/*
*/
void enable_port(port_no)                                      /* (8.8.2) */
Int port_no;
{
  initialize_port(port_no);
  port_state_selection();                                 /* (8.8.2 g) */
}

/*
*/
void disable_port(port_no)                                     /* (8.8.3) */
Int port_no;
{
  Boolean root;
  root = root_bridge();
  become_designated_port(port_no);                        /* (8.8.3 a) */
  set_port_state(port_no, Disabled);                      /* (8.8.3 b) */
  port_info[port_no].topology_change_acknowledge = False; /* (8.8.3 c) */
  port_info[port_no].config_pending = False;              /* (8.8.3 d) */
  stop_message_age_timer(port_no);                        /* (8.8.3 e) */
  stop_forward_delay_timer(port_no);                      /* (8.8.3 f) */
  configuration_update();                                 /* (8.8.3 g) */
  port_state_selection();                                 /* (8.8.3 h) */
  if ((root_bridge()) && (!root))                         /* (8.8.3 i) */
  {
    bridge_info.max_age = bridge_info.bridge_max_age;     /* (8.8.3 i1) */
    bridge_info.hello_time = bridge_info.bridge_hello_time;
    bridge_info.forward_delay = bridge_info.bridge_forward_delay;
    topology_change_detection();                          /* (8.8.3 i2) */
    stop_tcn_timer();                                     /* (8.8.3 i3) */
    config_bpdu_generation();                             /* (8.8.3 i4) */
    start_hello_timer();
  }
}

void set_bridge_priority(new_bridge_id)                        /* (8.8.4) */
Identifier new_bridge_id;                                 /* (8.8.4 a) */
{
  Boolean root;
  Int port_no;
  root = root_bridge();


  for (port_no = One; port_no <= No_of_ports; port_no++)  /* (8.8.4 b) */
  {
    if (designated_port(port_no))
    {
      port_info[port_no].designated_bridge = new_bridge_id;
    }
  }
  bridge_info.bridge_id = new_bridge_id;                  /* (8.8.4 c) */
  configuration_update();                                 /* (8.8.4 d) */
  port_state_selection();                                 /* (8.8.4 e) */
  if ((root_bridge()) && (!root))                         /* (8.8.4 f) */
  {
    bridge_info.max_age = bridge_info.bridge_max_age;     /* (8.8.4 f1) */
    bridge_info.hello_time = bridge_info.bridge_hello_time;
    bridge_info.forward_delay = bridge_info.bridge_forward_delay;
    topology_change_detection();                          /* (8.8.4 f2) */
    stop_tcn_timer();                                     /* (8.8.4 f3) */
    config_bpdu_generation();                             /* (8.8.4 f4) */
    start_hello_timer();
  }
}

/*
*/
void enable_change_detection(port_no)                          /* (8.8.7) */
Int port_no;
{
  port_info[port_no].change_detection_enabled = True;
}

/*
*/
void disable_change_detection(port_no)                         /* (8.8.8) */
Int port_no;
{
  port_info[port_no].change_detection_enabled = False;
}

#endif /*#if 0 */

/******************************************************************
 * LONG
 * SpanningTreeInit(ETHSTATE *pxEth)
 * Description: Initilizes an instance of the spanning tree.
 *
 * Parameters:  none
 *
 * Return value: >= 0 if success, -1 if error.
 *
 ******************************************************************/
LONG
SpanningTreeInit(ETHSTATE *pxEth)
{
  OCTET aoDefaultID[8] = {0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
  OCTET oIdx;
  ETH_LL *pxLl = NULL;

  ETH_DBGP(NORMAL,"\nSpanning Tree initialisation\n\n");

  ETH_DBG_ASSERT(pxEth->oNumBridgePorts < All_ports);
  No_of_ports = pxEth->oNumBridgePorts;

  MOC_MEMCPY((ubyte *)&aoDefaultID[2],
        (ubyte *) pxEth->aaoIfEthAddr[0], ETHADDRESS_LEN);
  MOC_MEMCPY((ubyte *)(OCTET*)&bridge_info.bridge_id.dwHi,
        (ubyte *) aoDefaultID, sizeof(DWORD));
  MOC_MEMCPY((ubyte *)(OCTET*)&bridge_info.bridge_id.dwLo,
        (ubyte *)&aoDefaultID[4], sizeof(DWORD));

  bridge_info.bridge_max_age        = 0x1400; /* 20 Seconds */
  bridge_info.bridge_hello_time     = 0x0200; /*  2 Seconds */
  bridge_info.bridge_forward_delay  = 0x0F00; /* 15 Seconds */

  /* Set up WAN ports */
  for (oIdx = One; oIdx <= No_of_ports; oIdx++) {
    set_port_priority((Int)oIdx, (Port_id)oIdx + 0x8000);
  }

  /* Find the LL interface that corrisponds with the bridge port */
  for (oIdx = 0; oIdx < (OCTET)ETHBR_MAXNUM_IF; oIdx ++) {
    pxLl = pxEth->apxIfToLlMap[oIdx];
    if (pxLl != NULL && pxLl->obOpen == TRUE &&
        pxLl->obBridged == TRUE) {
      SpanningTreeSetPathCost(pxLl->oPortNo, pxLl->dwBitRate);
    }
  }

  return 0;
}

/******************************************************************
 * void
 * SpanningTreeSetPathCost(OCTET oPortNo, DWORD dwBitRate)
 * Description: Sets the path cost of a spanning tree
 *              bridge port.
 *
 * Parameters:  oPortNo  - bridge port
 *              dwBitRate - bitrate of the port in Kbits/sec
 *
 ******************************************************************/
void SpanningTreeSetPathCost(OCTET oPortNo, DWORD dwBitRate)
{
WORD wCost;

  ASSERT(oPortNo < No_of_ports);

  if (dwBitRate < 1000) { /* If < 1 Mbit/sec */
    wCost = 500;
  } else if (dwBitRate < 10000) { /* If < 10 Mbits/sec */
    wCost = 250; /* 250 is recomended for 4 Mb/s */
  } else if (dwBitRate < 100000) { /* If < 100 Mbits/sec */
    wCost = 100; /* 100 is recomended for 10 Mb/s */
  } else { /* 100 Mbits/sec and above */
    wCost = 19; /* 19 is recomended for 100 Mb/s */
  }

  ETH_DBGP(NORMAL,"Spanning Tree: port %d path cost = %d \n",oPortNo,wCost);

  set_path_cost((Int)oPortNo+1, (Cost)wCost);
}


/******************************************************************
 * LONG
 * SpanningTreeDestroy(SpanningTreeCreate(H_NETINSTANCE hEth)
 * Description: Creates an instance of the spanning tree.
 *
 * Parameters:  none
 *
 * Return value: >= 0 if success, -1 if error.
 *
 ******************************************************************/
LONG SpanningTreeCreate(H_NETINSTANCE hEth){

  /* Save the instance in a static */
  pxStpEth = (ETHSTATE *)hEth;
  ETH_CHECK_STATE(pxStpEth);

  /* Mutex creation */
  if (pthread_mutex_init(&xMutex_STP, NULL) < 0) {
    ASSERT(0);
    return -1;
  }
  return 0;
}


/******************************************************************
 * LONG
 * SpanningTreeDestroy(void)
 * Description: Destroys any items instantiated in
 *              SpanningTreeCreate()
 *
 * Parameters:  none
 *
 * Return value: >= 0 if success, -1 if error.
 *
 ******************************************************************/
LONG SpanningTreeDestroy(void){
  /* Mutex destruction */
  if (pthread_mutex_destroy(&xMutex_STP) < 0) {
    ASSERT(0);
    return -1;
  }
  return 0;
}


/******************************************************************
 * LONG
 * SpanningTreeStart(void)
 * Description: Starts the spanning tree code - Must be called AFTER
 *              the bridge legs have been opened
 *
 * Parameters:  none
 *
 * Return value: >= 0 if success, -1 if error.
 *
 ******************************************************************/
LONG
SpanningTreeStart(void)
{
  OCTET oIdx;
  ETH_LL *pxLl = NULL;

  SYSLOG(LOG_DEBUG,"   **  Spanning tree start  **\n");

  initialisation((OCTET)TRUE);

  /* Change each port state to its configured initial value */
  for (oIdx = 0; oIdx < (OCTET)ETHBR_MAXNUM_IF; oIdx ++) {
    pxLl = pxStpEth->apxIfToLlMap[oIdx];
    if (pxLl != NULL && pxLl->obOpen == TRUE &&
        pxLl->obBridged == TRUE) {
      set_port_state(pxLl->oPortNo+1, pxStpEth->aeInitialPortState[oIdx]);
    }
  }
  port_state_selection();

  return(0);
}


/******************************************************************
 * LONG
 * SpanningTreeStop(void)
 * Description: Stops the spanning tree code
 *
 * Parameters:  none
 *
 * Return value: >= 0 if success, -1 if error.
 *
 ******************************************************************/
LONG
SpanningTreeStop(void)
{
  SYSLOG(LOG_DEBUG,"   **  Spanning tree stop  **\n");
  initialisation((OCTET)FALSE);
  return(0);
}

#define READ_WORD(poX) ( (*((OCTET*)(poX))<<8) | (*((OCTET*)((poX)+1))) )

/******************************************************************
 * LONG
 * SpanningTreeRcv(OCTET oPortNo, OCTET *poPacket)
 * Description: Interfaces between the bridge and spanning tree
 *              protocol.
 *
 * Parameters:  oPortNo  - bridge port
 *              poPacket - pointer to the start of the ethernet
 *                         header in the packet
 *
 * Return value: >= 0 if success, -1 if error.
 *
 ******************************************************************/
LONG
SpanningTreeRcv(OCTET oPortNo, OCTET *poPacket)
{

  ASSERT(oPortNo < No_of_ports && poPacket != NULL);

  /* oPortNo should correspond with spanning tree code ports */
  oPortNo ++;

/*
 * Check that len <= 1500; DSAP == 0x42; SSAP == 0x42; cntl == 0x03
 */
  if (1500 <
      (((WORD)poPacket[MAC_LEN_HI_B]<<8) + (WORD)poPacket[MAC_LEN_LO_B]) ||
      0x42 != poPacket[LLC_DSAP_B] ||
      0x42 != poPacket[LLC_SSAP_B] ||
      0x03 != poPacket[LLC_CNTL_B]) {
    return(-1);
  }

/* Check that Protocol Identifier == 0x0000 and
 * do NOT check the Protocol Version Identifier!           (9.3.3)
 */
  if (poPacket[BPDU_ID_HI_B] ||
      poPacket[BPDU_ID_LO_B]) {
    return(-1);
  }

/*
 * Check the BPDU type:
 * 0x00 == Configuration BPDU
 * 0x80 == Topology Change BPDU
 */
  if (poPacket[BPDU_TYPE_B] == Config_bpdu_type){
    Config_bpdu ConfigBpdu;
    Identifier idTemp;
    Cost cstTemp;


    /* In the Configuration BPDU check the len field >= 38 dec
     * (3 LLC + 35 BPDU)
     */
    if ((((WORD)poPacket[MAC_LEN_HI_B] << 8) +
          (WORD)poPacket[MAC_LEN_LO_B]) < 38) {
      return(-1);
    }

    ETH_DBGP(REPETITIVE,"Rx port %d valid STP Configuration BPDU\n",
             oPortNo-1);
    /*
     * Fill the Config_bpdu structure
     */


    /* Do the age first so it can be checked */
    ConfigBpdu.message_age = READ_WORD(&poPacket[BPDU_MSG_AGE_W]);
    ConfigBpdu.max_age = READ_WORD(&poPacket[BPDU_MAX_AGE_W]);

    /* Check the age of the packet */                    /* (9.3.3) */
    if (ConfigBpdu.message_age >= ConfigBpdu.max_age) {
      ETH_DBGP(REPETITIVE,"Rx STP Configuration BPDU to old!\n");
      return(-1);
    }

    ConfigBpdu.type = (Bpdu_type)poPacket[BPDU_TYPE_B];

    MOC_MEMCPY((ubyte *)(OCTET*)&idTemp.dwHi,
        (ubyte *) &poPacket[BPDU_RT_ID_HI_DW], sizeof(DWORD));
    MOC_MEMCPY((ubyte *)(OCTET*)&idTemp.dwLo,
        (ubyte *)&poPacket[BPDU_RT_ID_LO_DW], sizeof(DWORD));
    ConfigBpdu.root_id = idTemp;

    MOC_MEMCPY((ubyte *)&cstTemp,
        (ubyte *)&poPacket[BPDU_RT_C0ST_DW], sizeof(DWORD));
    ConfigBpdu.root_path_cost = cstTemp;

    MOC_MEMCPY((ubyte *)&idTemp.dwHi,(ubyte *) &poPacket[BPDU_BR_ID_HI_DW],
            sizeof(DWORD));
    MOC_MEMCPY((ubyte *)&idTemp.dwLo, (ubyte *)&poPacket[BPDU_BR_ID_LO_DW],
            sizeof(DWORD));
    ConfigBpdu.bridge_id = idTemp;

    ConfigBpdu.port_id = READ_WORD(&poPacket[BPDU_PORT_ID_W]);
    ConfigBpdu.hello_time = READ_WORD(&poPacket[BPDU_HELLO_TIM_W]);
    ConfigBpdu.forward_delay = READ_WORD(&poPacket[BPDU_FWD_DELAY_W]);
    ConfigBpdu.topology_change_acknowledgment = (Flag)
          (poPacket[BPDU_FLAGS_B] & TOP_CHANGE_AK_FLG);
    ConfigBpdu.topology_change = (Flag)
          (poPacket[BPDU_FLAGS_B] & TOP_CHANGE_FLG);

    /* Call the spanning tree code */
    received_config_bpdu((Int)oPortNo, &ConfigBpdu);

  } else if (poPacket[BPDU_TYPE_B] == Tcn_bpdu_type){
    Tcn_bpdu TcnBpdu;

    /* In the Topology Change BPDU check the len field >= 7 dec
     * (3 LLC + 4 BPDU)
     */
    if ((((WORD)poPacket[MAC_LEN_HI_B] << 8) +
          (WORD)poPacket[MAC_LEN_LO_B]) < 7) {
      return(-1);
    }

    ETH_DBGP(REPETITIVE,"Rx port %d valid STP Topology Change BPDU\n",
             oPortNo-1);

    /* Fill the Tcn_bpdu structure */
    TcnBpdu.type = (Bpdu_type)poPacket[BPDU_TYPE_B];

    /* Call the spanning tree code */
    received_tcn_bpdu((Int)oPortNo, &TcnBpdu);
  }

  /* Return success */
  return(0);
}


/******************************************************************
 * LONG
 * SpanningTreeWrite(OCTET oPortNo, NETPACKET *pxPacket,
 *                      NETPACKETACCESS *pxAccess)
 * Description: Writes a packet to LL Interface that corrisponds
 *              to the spanning tree port (oPortNo)
 *
 * Parameters:  oPortNo  - spanning tree port
 *              pxPacket - pointer to the NETPACKET struct
 *              pxAccess - pointer to the NETPACKETACCESS struct
 *
 * Return value: >= 0 if success, -1 if error.
 *
 ******************************************************************/
void SpanningTreeWrite(OCTET oPortNo, NETPACKET *pxPacket, NETPACKETACCESS *pxAccess)
{
  OCTET oIdx;
  ETH_LL *pxLl = NULL;

  ASSERT(oPortNo > 0 && oPortNo <= No_of_ports &&
         pxPacket != NULL && pxPacket != NULL);

  ETH_DBGP(XREPETITIVE,"SpanningTreeWrite: ST port: %d\n",
         oPortNo-1);

  /* Convert to LL port number - starts at 0 */
  oPortNo --;

  ASSERT(pxStpEth != NULL);

  /* Find the LL interface that corrisponds with the bridge port */
  for (oIdx = 0; oIdx < (OCTET)ETHBR_MAXNUM_IF; oIdx ++) {
    pxLl = pxStpEth->apxIfToLlMap[oIdx];
    if (pxLl != NULL && pxLl->obOpen == TRUE &&
        pxLl->obBridged == TRUE && pxLl->oPortNo == oPortNo) {
      break;
    }
  }

  /* Should always find the port */
  ASSERT(oIdx != (OCTET)ETHBR_MAXNUM_IF);

  /* Call the LL write */
  ASSERT(pxLl->pfnLlWrite != NULL);
  pxLl->pfnLlWrite(pxLl->hLlInst,
                   pxLl->hLlIf,
                   pxPacket,
                   pxAccess,
                   (H_NETDATA)pxLl->oIfIdx);
}


/******************************************************************
 * void
 * SpanningTreeProcess(void)
 * Description: The process function for the spanning tree code.
 *              Contains IEEE 802.1D code.
 *              Must be called every STP_PROCESS_TIME
 *              - see spanningtree.h for definition.
 *
 * Parameters:  NONE
 *
 * Return value: void
 *
 ******************************************************************/
void
SpanningTreeProcess(void)
{
  Int port_no;

  if (hello_timer_expired())
  {
    ETH_DBGP(XREPETITIVE,"STP Hello timer expired\n");
    hello_timer_expiry();
  }
  if (tcn_timer_expired())
  {
    tcn_timer_expiry();
  }
  if (topology_change_timer_expired())
  {
    topology_change_timer_expiry();
  }
  for (port_no = One; port_no <= No_of_ports; port_no++)
  {
    if (message_age_timer_expired(port_no))
    {
      message_age_timer_expiry(port_no);
    }
  }
  for (port_no = One; port_no <= No_of_ports; port_no++)
  {
    if (forward_delay_timer_expired(port_no))
    {
      forward_delay_timer_expiry(port_no);
    }
    if (hold_timer_expired(port_no))
    {
      hold_timer_expiry(port_no);
    }
  }
}



void send_config_bpdu(Int port_no, Config_bpdu *ConfigBpdu)
{
  NETPACKET xPacket;
  NETPACKETACCESS xNetPktAccess;
  OCTET *poPayload;
  WORD wPacketLength;

  Flag flgTemp;
  Identifier idTemp;
  Cost cstTemp;

  ASSERT(port_no <= No_of_ports);
  ASSERT(pxStpEth);
  ASSERT(ConfigBpdu);

  ETH_DBGP(XREPETITIVE,"Spanning Tree config pkt TX, ST port: %d \n",
           port_no-1);

  /*
   *payload creation and allocation
   */
  wPacketLength = (WORD)(pxStpEth->wOffset +
                         (WORD)ETH_MINLEN + /*BPDU_CONF_PKT_LEN + */
                         pxStpEth->wTrailer);

  xNetPktAccess.wOffset = pxStpEth->wOffset;
  xNetPktAccess.wLength = (WORD)BPDU_CONF_PKT_LEN;

  ASSERT(pxStpEth->pfnMalloc && pxStpEth->pfnFree);
  poPayload = (OCTET*) pxStpEth->pfnMalloc(wPacketLength);
  ASSERT(poPayload);

  NETPAYLOAD_CREATE((&(xPacket.pxPayload)),
                    pxStpEth->pfnFree,
                    pxStpEth->pxMutex,
                    poPayload,
                    wPacketLength
                    );

  poPayload += pxStpEth->wOffset;

  /* Fill the packet */
  MOC_MEMCPY((ubyte *)&poPayload[0],
        (ubyte *) aoSpanningTreeAddr, ETHADDRESS_LEN);
  MOC_MEMCPY((ubyte *)&poPayload[6],
        (ubyte *) pxStpEth->aaoIfEthAddr[0], ETHADDRESS_LEN);
  poPayload[MAC_LEN_HI_B]  = 0;
  poPayload[MAC_LEN_LO_B]  = 38;
  poPayload[LLC_DSAP_B]    = 0x42;
  poPayload[LLC_SSAP_B]    = 0x42;
  poPayload[LLC_CNTL_B]    = 0x03;

  poPayload[BPDU_ID_HI_B]  = 0;
  poPayload[BPDU_ID_LO_B]  = 0;
  poPayload[BPDU_V_ID_B]   = 0;
  poPayload[BPDU_TYPE_B] = ConfigBpdu->type;

  flgTemp = 0;
  if (ConfigBpdu->topology_change_acknowledgment) {
    flgTemp |= TOP_CHANGE_AK_FLG;
  }
  if (ConfigBpdu->topology_change) {
    flgTemp |= TOP_CHANGE_FLG;
  }
  poPayload[BPDU_FLAGS_B] = flgTemp;

  idTemp = ConfigBpdu->root_id;
  MOC_MEMCPY((ubyte *)&poPayload[BPDU_RT_ID_HI_DW],
        (ubyte *)&idTemp.dwHi,
          sizeof(DWORD));
  MOC_MEMCPY((ubyte *)&poPayload[BPDU_RT_ID_LO_DW],
        (ubyte *)&idTemp.dwLo, sizeof(DWORD));

  cstTemp = ConfigBpdu->root_path_cost;
  MOC_MEMCPY((ubyte *)&poPayload[BPDU_RT_C0ST_DW],
        (ubyte *)&cstTemp, sizeof(DWORD));

  idTemp = ConfigBpdu->bridge_id ;
  MOC_MEMCPY((ubyte *)&poPayload[BPDU_BR_ID_HI_DW],
        (ubyte *)&idTemp.dwHi, sizeof(DWORD));
  MOC_MEMCPY((ubyte *)&poPayload[BPDU_BR_ID_LO_DW],
        (ubyte *)&idTemp.dwLo, sizeof(DWORD));

  /* The following few lines assume WORD alignment */
  ASSERT(!((int)&poPayload[BPDU_PORT_ID_W] & 0x0001));
  *((Port_id*)&poPayload[BPDU_PORT_ID_W]) = ConfigBpdu->port_id;
  *((Time*)&poPayload[BPDU_MSG_AGE_W]) = ConfigBpdu->message_age;
  *((Time*)&poPayload[BPDU_MAX_AGE_W]) = ConfigBpdu->max_age;
  *((Time*)&poPayload[BPDU_HELLO_TIM_W]) = ConfigBpdu->hello_time;
  *((Time*)&poPayload[BPDU_FWD_DELAY_W]) = ConfigBpdu->forward_delay;

  /* Send the packet to be writern */

  SpanningTreeWrite((OCTET)port_no, &(xPacket), &(xNetPktAccess));
}


void send_tcn_bpdu(Int port_no, Tcn_bpdu *TcnBpdu)
{
  NETPACKET xPacket;
  NETPACKETACCESS xNetPktAccess;
  OCTET *poPayload;
  WORD wPacketLength;

  ASSERT(port_no <= No_of_ports);
  ASSERT(pxStpEth);
  ASSERT(TcnBpdu);

  ETH_DBGP(XREPETITIVE,"Spanning Tree tcn pkt TX, ST port: %d \n",
           port_no-1);

  /*
   *payload creation and allocation
   */
  wPacketLength = (WORD)(pxStpEth->wOffset +
                         (WORD)ETH_MINLEN + /*BPDU_CONF_PKT_LEN + */
                         pxStpEth->wTrailer);

  xNetPktAccess.wOffset = pxStpEth->wOffset;
  xNetPktAccess.wLength = (WORD)BPDU_TCN_PKT_LEN; /*BPDU_CONF_PKT_LEN; */

  ASSERT(pxStpEth->pfnMalloc);
  ASSERT(pxStpEth->pfnFree);
  poPayload = (OCTET*) pxStpEth->pfnMalloc(wPacketLength);
  ASSERT(poPayload);

  /* Takes care of the flags and stuff at the end of the packet */
  MOC_MEMSET((ubyte *)poPayload, 0, (size_t)wPacketLength);

  NETPAYLOAD_CREATE((&(xPacket.pxPayload)),
                    pxStpEth->pfnFree,
                    pxStpEth->pxMutex,
                    poPayload,
                    wPacketLength
                    );

  poPayload += pxStpEth->wOffset;

  /* Fill the packet */
  MOC_MEMCPY((ubyte *)&poPayload[0], (ubyte *)aoSpanningTreeAddr,
        ETHADDRESS_LEN);
  MOC_MEMCPY((ubyte *)&poPayload[6], (ubyte *)pxStpEth->aaoIfEthAddr[0],
        ETHADDRESS_LEN);
  poPayload[MAC_LEN_HI_B]  = 0;
  poPayload[MAC_LEN_LO_B]  = 7;
  poPayload[LLC_DSAP_B]    = 0x42;
  poPayload[LLC_SSAP_B]    = 0x42;
  poPayload[LLC_CNTL_B]    = 0x03;

  poPayload[BPDU_ID_HI_B]  = 0;
  poPayload[BPDU_ID_LO_B]  = 0;
  poPayload[BPDU_V_ID_B]   = 0;
  poPayload[BPDU_TYPE_B] = TcnBpdu->type;

  /* Send the packet to be writern */
  SpanningTreeWrite((OCTET)port_no, &(xPacket), &(xNetPktAccess));
}
