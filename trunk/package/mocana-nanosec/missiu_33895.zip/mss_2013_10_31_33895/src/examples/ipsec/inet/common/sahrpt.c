/*
 * sahrpt.c
 *
 *     implement Self-Adjusting Histograms Reporting
 *    (this keeps printf calls out of NDEBUG makes if
 *     SaHist8Report() not called)
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

#include <stdio.h>

#include "NNstyle.h"
#include "sahist.h"


/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Typedefs
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Global Variables
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Static Variables
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Static Function Declarations
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Static Functions
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Public Functions
 *
 ********************************************************************/


/*
 * SaHist8Report
 *     print histogram contents
 *
 * Arguments:
 *      pHist8        the 8 bucket histogram
 * Returns:
 *      none
 */
void SaHist8Report(SA_HIST8 *pHist8)
{
  register SA_HIST8 *pHist = pHist8;
  register DWORD i;
  DWORD dwRange;

  dwRange = (DWORD) 1 << pHist8->wRangeShift;
  printf("SA_HIST8 at 0x%08lX\n", (long unsigned) pHist);
  printf("range for each bucket = 0x%08lX\n", (long unsigned) dwRange);
  printf("limit for all buckets = 0x%08lX\n", (long unsigned) pHist->dwLimit);
  printf("  (if limit is 0 and range NOT 1 then limit is really 2 ** 32)\n");
  printf(  "          range              count\n");
  for (i = 0; i < 8; i++) {
    printf("0x%08lX - 0x%08lX    0x%08lX\n",
       (long unsigned) (i * dwRange),
       (long unsigned) ((1 + i) * dwRange - 1),
       (long unsigned) (pHist->adwBkt[i]));
  }
}




