/*
 * queue.h
 *
 * Implements Queues and CountQueues in MACROs.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef __QUEUE_H__
#define __QUEUE_H__



#include "NNstyle.h"

#ifndef NO_ENTRY
#  define NO_ENTRY ((void *) 0)
#endif


/***************
 *  TYPEDEFS
 ***************/

#define QUEUE(t)                 \
   struct {                    \
     t *pFront;        /* first out    */    \
     t *pBack;        /* last in    */    \
     t **ppCursor;    /* cursor    */    \
   }

#define CQUEUE(t)                 \
   struct {                    \
     QUEUE(t) q;    /* the queue    */    \
     WORD wCnt;        /* # elements    */    \
   }




/************
 *  MACROs
 ************/

/*
 * Clear a Queue, any contents of the queue are lost!
 *
 * parms:    q    a structure of type QUEUE
 *   or     cq    a structure of type CQUEUE
 */

#define ClearQueue(q) do {                    \
            (q).pFront = NO_ENTRY;            \
            (q).pBack = NO_ENTRY;            \
            (q).ppCursor = NULL;            \
             } while (0)

#define ClearQueueSup(q) do {                    \
            PUT_VCP_REG(riface_irqsupress, 0);    \
            WAIT2;                    \
            (q).pFront = NO_ENTRY;            \
            PUT_VCP_REG(riface_irqsupress, 0);    \
            (q).pBack = NO_ENTRY;            \
             } while (0)

#define ClearCQueue(cq) do {                    \
            ClearQueue((cq).q);            \
            (cq).wCnt = 0;                \
             } while (0)

#define ClearCQueueSup(cq) do {                    \
            ClearQueueSup((cq).q);            \
            PUT_VCP_REG(riface_irqsupress, 0);    \
            (cq).wCnt = 0;                \
             } while (0)


/*
 * add to the back of a Queue
 *
 * parms:    q    a structure of type QUEUE
 *   or     cq    a structure of type CQUEUE
 *        pe    pointer to element to add
 */

#define EnQueue(q, pe) Queue((q), (pe))
#define Queue(q, pe) do {                    \
            /*ASSERT(NO_ENTRY != (pe));*/         \
            if ((q).pFront == NO_ENTRY)         \
              (q).pFront = (pe);            \
            else                     \
              ((q).pBack)->pNext = (pe);        \
            (q).pBack = (pe);            \
            (pe)->pNext = NO_ENTRY;         \
             } while (0)
#define EnQueueSup(q, pe) do {                    \
            /*ASSERT(NO_ENTRY != (pe));*/         \
            PUT_VCP_REG(riface_irqsupress, 0);    \
            WAIT2;                    \
            if ((q).pFront == NO_ENTRY) {         \
              PUT_VCP_REG(riface_irqsupress, 0);    \
              (q).pFront = (pe);            \
            }                    \
            else {                     \
              PUT_VCP_REG(riface_irqsupress, 0);    \
              ((q).pBack)->pNext = (pe);        \
            }                    \
            PUT_VCP_REG(riface_irqsupress, 16-10);    \
            (q).pBack = (pe);            \
            (pe)->pNext = NO_ENTRY;         \
             } while (0)


#define EnCQueue(cq, pe) CQueue((cq), (pe))
#define CQueue(cq, pe) do {                    \
            Queue((cq).q, (pe));            \
            (cq).wCnt++;                \
             } while (0)

#define EnCQueueSup(cq, pe) do {                \
            EnQueueSup((cq).q, (pe));        \
            PUT_VCP_REG(riface_irqsupress, 0);    \
            (cq).wCnt++;                \
             } while (0)


/*
 * add to the front of a Queue
 *
 * parms:    q    a structure of type QUEUE
 *   or     cq    a structure of type CQUEUE
 *        pe    pointer to element to add
 */
#define AddQueueFront(q, pe) do                    \
        {                        \
          /*ASSERT(NO_ENTRY != (pe));*/            \
          if ((q).pFront == NO_ENTRY)            \
            (q).pBack = (pe);                \
          (pe)->pNext = (q).pFront;            \
          (q).pFront = (pe);                \
        } while (0)

#define AddCQueueFront(cq, pe) do                \
        {                        \
          AddQueueFront((cq).q, (pe));            \
          (cq).wCnt++;                    \
        } while (0)



/*
 * peek at the front element of the queue
 *
 * parms:    q    a structure of type QUEUE
 *   or     cq    a structure of type CQUEUE
 *
 */
#define PeekQueueFront(q) ((q).pFront)

#define PeekCQueueFront(cq) PeekQueueFront((cq).q)


/*
 * peek at the back element of the queue
 *
 * parms:    q    a structure of type QUEUE
 *   or     cq    a structure of type CQUEUE
 *
 */
#define PeekQueueBack(q) ((q).pBack)

#define PeekCQueueBack(cq) PeekQueueBack((cq).q)



/*
 * discard the front element of the queue, the element is
 * LOST unless a PeekQueue() is done 1st to get it.
 *
 * parms:    q    a structure of type QUEUE
 *   or     cq    a structure of type CQUEUE
 *
 */

#define DiscardQueueFront(q)                    \
           do {                        \
             if ((q).pFront != NO_ENTRY) {         \
               (q).pFront = ((q).pFront)->pNext;    \
               if ((q).pFront == NO_ENTRY)         \
             (q).pBack = NO_ENTRY;             \
               (q).ppCursor = NULL;            \
             }                        \
           } while (0)

#define DiscardCQueueFront(cq)                    \
           do {                        \
             if ((cq).q.pFront != NO_ENTRY) {         \
               (cq).wCnt--;                \
             }                        \
             DiscardQueueFront((cq).q);            \
           } while (0)



/*
 * remove and return the front element of the queue
 *
 * parms:    q    a structure of type QUEUE
 *   or     cq    a structure of type CQUEUE
 *        ppe    pointer to pointer to element
 *
 */
#define DeQueue(q, ppe)                     \
           do {                        \
             *(ppe) = PeekQueueFront((q));        \
             DiscardQueueFront((q));            \
           } while (0)

#define DeCQueue(cq, ppe)                     \
           do {                        \
             *(ppe) = PeekCQueueFront((cq));        \
             DiscardCQueueFront((cq));            \
           } while (0)



/*
 * return # elements in the queue
 */
#define CQueueCnt(cq) ((cq).wCnt)


/*
 * reset the cursor to top of queue
 */
#define ResetCursorQueue(q) do {                    \
      if (NULL == (q).pFront)                    \
        (q).ppCursor = NULL;                    \
      else                                \
        (q).ppCursor = &((q).pFront);                \
    } while (0)

#define ResetCursorCQueue(cq) do {                    \
      if (NULL == (cq).q.pFront)                    \
        (cq).q.ppCursor = NULL;                    \
      else                                \
        (cq).q.ppCursor = &((cq).q.pFront);                \
    } while (0)


/*
 * find an element somewhere in the queue, set the cursor
 */
#define FindQueue(q, p) do {                        \
      if (NULL == (q).pFront)                    \
        (q).ppCursor = NULL;                    \
      else                                \
        (q).ppCursor = &((q).pFront);                \
      while (NULL != (q).ppCursor) {                \
        if (*((q).ppCursor) == (p))                    \
          break;                            \
        (q).ppCursor = &((*((q).ppCursor))->pNext);            \
      }                                \
    } while (0)

#define FindCQueue(cq, p) do {                        \
      if (NULL == (cq).q.pFront)                    \
        (cq).q.ppCursor = NULL;                    \
      else                                \
        (cq).q.ppCursor = &((cq).q.pFront);                \
      while (NULL != (cq).q.ppCursor) {                \
        if (*((cq).q.ppCursor) == (p))                \
          break;                            \
        (cq).q.ppCursor = &((*((cq).q.ppCursor))->pNext);        \
      }                                \
    } while (0)

#define WasFoundQueue(q) (NULL != (q).ppCursor)

#define WasFoundCQueue(cq) (NULL != (cq).q.ppCursor)


/*
 * delete an element somewhere in the queue, set the cursor to the
 *   following element
 */
#define DeleteQueue(q, p) do {                        \
      FindQueue((q), (p));                        \
      if (NULL == (q).ppCursor)                    \
          break;                            \
      if ((p) == (q).pBack) {                    \
        if ((p) == (q).pFront)                    \
          (q).pBack = NULL;                        \
        else                            \
          (q).pBack = (void *) (((OCTET *) (q).ppCursor) -        \
              ((OCTET *) &((p)->pNext) - (OCTET *) p));    \
      }                                \
      *((q).ppCursor) = (*((q).ppCursor))->pNext;            \
      (q).ppCursor = NULL;                        \
    } while (0)

#define DeleteCQueue(cq, p) do {                    \
      FindCQueue((cq), (p));                    \
      if (NULL == (cq).q.ppCursor)                    \
          break;                            \
      if ((p) == (cq).q.pBack) {                    \
        if ((p) == (cq).q.pFront)                    \
          (cq).q.pBack = NULL;                    \
        else                            \
          (cq).q.pBack = (void *) (((OCTET *) (cq).q.ppCursor) -    \
              ((OCTET *) &((p)->pNext) - (OCTET *) p));    \
      }                                \
      *((cq).q.ppCursor) = (*((cq).q.ppCursor))->pNext;        \
      (cq).q.ppCursor = NULL;                    \
      (cq).wCnt--;                            \
    } while (0)


/*
 * return the current cursor
 */
#define GetCursorQueue(q, ppe) do {                    \
      ASSERT(WasFoundQueue(q));                    \
      *ppe = *((q).ppCursor);                    \
    } while (0)

#define GetCursorCQueue(cq, ppe) do {                    \
      ASSERT(WasFoundCQueue(cq));                    \
      *ppe = *((cq).q.ppCursor);                    \
    } while (0)

#define PeekCursorQueue(q)  (((q).ppCursor==NULL)?NULL:*((q).ppCursor))

#define PeekCursorCQueue(cq) (((cq).q.ppCursor==NULL)?NULL:*((cq).q.ppCursor))



/*
 * advance the cursor to the next element and return a pointer
 *  to that element
 */
#define AdvCursorQueue(q, ppe) do {                    \
      ASSERT(WasFoundQueue(q));                    \
      (q).ppCursor = &((*((q).ppCursor))->pNext);            \
      *ppe = *((q).ppCursor);                    \
    } while (0)

#define AdvCursorCQueue(cq, ppe) do {                    \
      ASSERT(WasFoundCQueue(cq));                    \
      (cq).q.ppCursor = &((*((cq).q.ppCursor))->pNext);        \
      *ppe = *((cq).q.ppCursor);                    \
    } while (0)

#define NextCursorQueue(q) do {                        \
      (q).ppCursor = &((*((q).ppCursor))->pNext);            \
    } while (0)

#define NextCursorCQueue(cq) do {                    \
      (cq).q.ppCursor = &((*((cq).q.ppCursor))->pNext);        \
    } while (0)


#define RemoveCursorQueue(q, p) do {                    \
          ASSERT(*((q).ppCursor) == p);                                 \
      if ((p) == (q).pBack) {                    \
        if ((p) == (q).pFront)                    \
          (q).pBack = NULL;                        \
        else                            \
          (q).pBack = (void *) (((OCTET *) (q).ppCursor) -        \
              ((OCTET *) &((p)->pNext) - (OCTET *) p));    \
      }                                \
      *((q).ppCursor) = (*((q).ppCursor))->pNext;            \
      (q).ppCursor = NULL;                        \
    } while (0)

#define RemoveCursorCQueue(cq, p) do {                    \
          ASSERT(*((cq).q.ppCursor) == p);                              \
      if ((p) == (cq).q.pBack) {                    \
        if ((p) == (cq).q.pFront)                    \
          (cq).q.pBack = NULL;                    \
        else                            \
          (cq).q.pBack = (void *) (((OCTET *) (cq).q.ppCursor) -    \
              ((OCTET *) &((p)->pNext) - (OCTET *) p));    \
      }                                \
      *((cq).q.ppCursor) = (*((cq).q.ppCursor))->pNext;        \
      (cq).q.ppCursor = NULL;                    \
      (cq).wCnt--;                            \
    } while (0)

#endif

