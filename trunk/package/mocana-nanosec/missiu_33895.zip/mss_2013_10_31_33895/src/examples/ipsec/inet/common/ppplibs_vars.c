/*
 * ppplibs_vars.c
 *
 * ppp library variables
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "netmain_flavor.h"
#include "stdlib.h"
#include "pthread.h"
#include "sys/socket.h"
#include "netcommon.h"
#include "netconfig.h"
#include "linkconf.h"
#include "pppoecommon.h"
#include "pppoeclient.h"
#include "ppp.h"
#include "ipcp.h"
#include "cryptcommon.h"
#include "md5.h"
#include "chapclient.h"
#ifdef EAP_TLS
#include "eaptlsclient.h"
#endif
#include "netdefs.h"
#include "pppoeconf.h"
#include "papclient.h"
#include "ppplibs.h"
#include "netmain.h"
#include "pppconf.h"

/****************************************************************************
 *
 * PPP
 *
 ****************************************************************************/
#ifdef PPP
const NETCONFSCALARIOCTL axPppUlIfIpIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)PPPID_IP}
};

const NETCONFSCALARIOCTL axPppUlIfIpcpIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)PPPID_IPCP}
};

const NETCONFSCALARIOCTL axPppUlIfChapIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)PPPID_CHAP}
};

const NETCONFSCALARIOCTL axPppUlIfPapIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)PPPID_PAP}
};

#ifdef EAP_TLS
const NETCONFSCALARIOCTL axPppUlIfEapTlsIoctl[1]= {
  {NETINTERFACEIOCTL_SETROUTINGID,(H_NETDATA)PPPID_EAPTLS}
};
#endif
const NETCONFIFTEMPLATE axPppULIf[5] = {
   { 1,axPppUlIfIpIoctl /* Ioctls */,
    /* Plumbings */{{FALSE,0,0,0}}},
  { 1,axPppUlIfIpcpIoctl/* Ioctls */,
    /* Plumbings */{{TRUE,PPPLIBIDX_IPCP,0,0}}},
  { 1,axPppUlIfChapIoctl /* Ioctls */,
    /* Plumbings */{{TRUE,PPPLIBIDX_CHAP,0,0}}},
  { 1, axPppUlIfPapIoctl/* Ioctls */,
    /* Plumbings */{{TRUE,PPPLIBIDX_PAP,0,0}}},
#ifdef EAP_TLS
  { 1,axPppUlIfEapTlsIoctl /* Ioctls */,
    /* Plumbings */{{TRUE,PPPLIBIDX_EAPTLS,0,0}}},
#endif
};

const NETCONFIFTEMPLATE axPppLLIf[1] = {
  {
    /* Ioctls */ 0,NULL,
    /* Plumbing */ {{FALSE,0,0,0}}
  }
};

const NETCONFINSTANCETEMPLATE axPppInstTemplate[1] =
{
  {
    3,axNetSettings,/* Options settings: */
    4,axPppULIf,/* UL interfaces:*/
    1,axPppLLIf, /* LL interfaces: PppoE or Mpoa*/
    0,NULL /* Msgs, not including Open: none */
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplatePpp = {
   PppInitialize, PppTerminate, PppInstanceCreate,
   PppInstanceDestroy,PppInstanceSet,PppInstanceMsg,
   PppInstanceULInterfaceCreate,PppInstanceLLInterfaceCreate,
   PppInstanceWrite,PppInstanceRcv,
   PppInstanceProcess,
   PppInstanceULInterfaceDestroy,PppInstanceULInterfaceIoctl,
   PppInstanceLLInterfaceDestroy,PppInstanceLLInterfaceIoctl,
   NetAdminPppCbk,
   axPppInstTemplate};

/****************************************************************************
 *
 * IPCP
 *
 ****************************************************************************/

const NETCONFIFTEMPLATE axIpcpLLIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{TRUE,PPPLIBIDX_PPP,0,
                     PPPULIFIDX_IPCP}}}
};

const NETCONFINSTANCETEMPLATE axIpcpInstTemplate[1] =
{
  {
    3, axNetSettings,/* Options settings: */
    0,NULL,/* UL interfaces:*/
    1,axIpcpLLIf, /* LL interfaces: PPP */
    0,NULL /* Msgs, not including Open: none */
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateIpCp = {
   IpcpInitialize, IpcpTerminate, IpcpInstanceCreate,
   IpcpInstanceDestroy,IpcpInstanceSet,IpcpInstanceMsg,
   NULL,IpcpInstanceLLInterfaceCreate,
   NULL,IpcpInstanceRcv,
   IpcpInstanceProcess,
   NULL,NULL,
   IpcpInstanceLLInterfaceDestroy,IpcpInstanceLLInterfaceIoctl,
   NetAdminIpcpCbk,
   axIpcpInstTemplate};

/****************************************************************************
 *
 * CHAP
 *
 ****************************************************************************/

const NETCONFIFTEMPLATE axChapClientLLIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{TRUE,PPPLIBIDX_PPP,0,
                     PPPULIFIDX_CHAP}}}
};

const NETCONFINSTANCETEMPLATE axChapClientInstTemplate[1] =
{
  {
    3, axNetSettings,/* Options settings: */
    0,NULL,/* UL interfaces:*/
    1,axChapClientLLIf, /* LL interfaces: PPP */
    0,NULL /* Msgs, not including Open: none */
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateChap = {
   ChapClientInitialize, ChapClientTerminate, ChapClientInstanceCreate,
   ChapClientInstanceDestroy,ChapClientInstanceSet,ChapClientInstanceMsg,
   NULL,ChapClientInstanceLLInterfaceCreate,
   NULL,ChapClientInstanceRcv,
   ChapClientInstanceProcess,
   NULL,NULL,
   ChapClientInstanceLLInterfaceDestroy,ChapClientInstanceLLInterfaceIoctl,
   NetAdminChapClientCbk,
   axChapClientInstTemplate};

#ifdef EAP_TLS
/****************************************************************************
 *
 *  EAPTLS
 *
 ****************************************************************************/

const NETCONFIFTEMPLATE axEapTlsClientLLIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{TRUE,PPPLIBIDX_PPP,0,
                     PPPULIFIDX_EAPTLS}}}
};

const NETCONFINSTANCETEMPLATE axEapTlsClientInstTemplate[1] =
{
  {
    3, axNetSettings,/* Options settings: */
    0,NULL,/* UL interfaces:*/
    1,axEapTlsClientLLIf, /* LL interfaces: PPP */
    0,NULL /* Msgs, not including Open: none */
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplateEapTls = {
   EapTlsClientInitialize, EapTlsClientTerminate, EapTlsClientInstanceCreate,
   EapTlsClientInstanceDestroy,EapTlsClientInstanceSet,EapTlsClientInstanceMsg,
   NULL,EapTlsClientInstanceLLInterfaceCreate,
   NULL,EapTlsClientInstanceRcv,
   EapTlsClientInstanceProcess,
   NULL,NULL,
   EapTlsClientInstanceLLInterfaceDestroy,EapTlsClientInstanceLLInterfaceIoctl,
   NetAdminEapTlsClientCbk,
   axEapTlsClientInstTemplate};
#endif

/****************************************************************************
 *
 * PAP
 *
 ****************************************************************************/

const NETCONFIFTEMPLATE axPapClientLLIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{TRUE,PPPLIBIDX_PPP,0,
                     PPPULIFIDX_PAP}}}
};

const NETCONFINSTANCETEMPLATE axPapClientInstTemplate[1] =
{
  {
    3, axNetSettings,/* Options settings: */
    0,NULL,/* UL interfaces:*/
    1,axPapClientLLIf, /* LL interfaces: PPP */
    0,NULL /* Msgs, not including Open: none */
  }
};


const NETCONFLIBRARYTEMPLATE gxLibTemplatePap = {
   PapClientInitialize, PapClientTerminate, PapClientInstanceCreate,
   PapClientInstanceDestroy,PapClientInstanceSet,PapClientInstanceMsg,
   NULL,PapClientInstanceLLInterfaceCreate,
   NULL,PapClientInstanceRcv,
   PapClientInstanceProcess,
   NULL,NULL,
   PapClientInstanceLLInterfaceDestroy,PapClientInstanceLLInterfaceIoctl,
   NetAdminPapClientCbk,
   axPapClientInstTemplate};

/****************************************************************************
 *
 * PPPOE
 *
 ****************************************************************************/

const NETCONFIFTEMPLATE axPppoEULIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{FALSE,0,0,0}}},
};

const NETCONFIFTEMPLATE axPppoELLIf[1] = {
  { 0,NULL /* Ioctls */,
    /* Plumbings */{{FALSE,0,0,0}}},
};

const NETCONFINSTANCETEMPLATE axPppoEInstTemplate[1] =
{
  {
    3, axNetSettings,/* Options settings: */
    1,axPppoEULIf,/* UL interfaces:*/
    1,axPppoELLIf, /* LL interfaces: Eth */
    0,NULL /* Msgs, not including Open: none */
  }
};

const NETCONFLIBRARYTEMPLATE gxLibTemplatePppoE = {
   PppoEClientInitialize, PppoEClientTerminate,
   PppoEClientInstanceCreate,
   PppoEClientInstanceDestroy,PppoEClientInstanceSet,PppoEClientInstanceMsg,
   PppoEClientInstanceULInterfaceCreate,PppoEClientInstanceLLInterfaceCreate,
   PppoEClientInstanceWrite,PppoEClientInstanceRcv,
   PppoEClientInstanceProcess,
   PppoEClientInstanceULInterfaceDestroy,PppoEClientInstanceULInterfaceIoctl,
   PppoEClientInstanceLLInterfaceDestroy,PppoEClientInstanceLLInterfaceIoctl,
   NetAdminPppoECbk,
   axPppoEInstTemplate};

/****************************************************************************
 *
 * Array initialization
 *
 ****************************************************************************/

const NETCONFLIBRARYTEMPLATE *apxPppLibTemplate[] = {
  &gxLibTemplatePpp,
  &gxLibTemplateIpCp,
  &gxLibTemplateChap,
  &gxLibTemplatePap
#ifdef EAP_TLS
  ,&gxLibTemplateEapTls
#endif

};

const NETCONFLIBRARYTEMPLATE *apxPppoELibTemplate[] = {
  &gxLibTemplatePppoE};

#endif /*ifdef PPP*/



