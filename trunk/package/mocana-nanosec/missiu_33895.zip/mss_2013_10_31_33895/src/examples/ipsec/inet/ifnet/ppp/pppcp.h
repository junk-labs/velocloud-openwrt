/*
 * pppcp.h
 *
 * PPP Control Protocol API
 *     The Control Protocol consist in a Control Finite State machine
 *     and a Protocol parser which is common to both LCP and IPCP protocols
 *     Each of these protocols uses a PPPCP instanciation, and adds its
 *     specific bits and pieces. Though this module follows the net module API, it should not be
 *     used as a standalone.
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef _PPPCP_H_
#define _PPPCP_H_
/*****************************************************************************
 *
 * defines
 *
 *****************************************************************************/

/*
 * PPP CP default settings
 *  These default settings are defined in the RFC 1661
 */
/* Timer */
#define PPPCPDEFAULT_TIMER      3000 /* msec */
/* Number of Configure-Request Retransmission */
#define PPPCPDEFAULT_MAXCONF   10
/* Number of Terminate-Request retransmission */
#define PPPCPDEFAULT_MAXTERM   2

/*
 * PPP CP specific option
 */
#define PPPCPOPTION_TIMER \
 (NETOPTION_MODULESPECIFICBEGIN)              /* Timer value. Data is DWORD
                                                 (msec) */
#define PPPCPOPTION_MAXCONF \
 (NETOPTION_MODULESPECIFICBEGIN + 1)          /* Max number of ConfReq.
                                                 data is OCTET */
#define PPPCPOPTION_MAXTERM \
 (NETOPTION_MODULESPECIFICBEGIN + 2)          /* Max number of TermReq.
                                                 data is OCTET */
#define PPPCPOPTION_IFIDX \
 (NETOPTION_MODULESPECIFICBEGIN + 3)          /* phy If Idx*/
#define PPPCPOPTION_VLAN \
 (NETOPTION_MODULESPECIFICBEGIN + 4)          /* Vlan*/

#define PPPCPOPTIONMAX 5

/*
 * PPP CP specific messages
 */
#define PPPCPMSG_PROTOCOLREJECT \
 (NETMSG_MODULESPECIFICBEGIN)                 /* Protocol Reject: unsupported
                                                 packet. data is
                                                 PPPCPPACKET **/
#define PPPCPMSG_ECHOREQUEST \
 (NETMSG_MODULESPECIFICBEGIN + 1)             /* Echo Request
                                                 PPPCPPACKET **/

#define PPPCPMSGMAX 2
/*
 * PPP CP specific call backs
 */
#define PPPCPCBK_RXCONFREQ \
 (NETCBK_MODULESPECIFICBEGIN)                 /* Received a CONFREQ. Data
                                                 is PPPCPOPTIONFIELDS *.
                                                 poReq is filled with
                                                 the required option fields.
                                                 poNak and poRej must be
                                                 filled with the Nak or
                                                 Reject option filled, if any.
                                                 (indicated by < 0 return
                                                 value)
                                                 */
#define PPPCPCBK_RXCONFNAK \
 (NETCBK_MODULESPECIFICBEGIN + 1)             /* Received a NAK. Data is
                                                 PPPCPOPTIONFIELDS **/
#define PPPCPCBK_RXCONFREJ \
 (NETCBK_MODULESPECIFICBEGIN + 2)             /* Received a CONF REJ. Data is
                                                 PPPCPOPTIONFIELDS * */
#define PPPCPCBK_RXUNKNOWNCODE \
 (NETCBK_MODULESPECIFICBEGIN + 3)             /* received an unknown code,
                                                 data is PPPCPPACKET *.
                                                 negative return values
                                                 mean the code is really
                                                 unknown. the callee must
                                                 call DELUSER in all
                                                 cases*/
#define PPPCPCBK_OPTIONCODE \
 (NETCBK_MODULESPECIFICBEGIN + 4)             /* Needs option field. Data
                                                 is PPPCPOPTIONFIELDS.
                                                 poReq to be filled up */

#define PPPCPCBKMAX 5

/*****************************************************************************
 *
 * extern
 *
 *****************************************************************************/
#ifndef NDEBUG
MOC_EXTERN const OCTET *apoPppCpCbkString[PPPCPCBKMAX];
#endif
/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/

/*
 * PPPCPOPTIONFIELDS structure
 *  Used for options negociations, outside the scope
 *  of PPPCP. PPPCP will free all the fields at its own
 *  pace, regardless of which module allocated them
 */
typedef struct {
  OCTET *poReq;      /* Required options */
  WORD wReqLength;
  OCTET *poNak;      /* Nak options */
  WORD wNakLength;
  OCTET *poRej;      /* Rejected options */
  WORD wRejLength;
} PPPCPOPTIONFIELDS;

typedef struct {
  NETPACKET *pxPacket;
  NETPACKETACCESS *pxAccess;
  H_NETDATA hData;
} PPPCPPACKET;

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * PppCpInitialize
 *   Initialize the pppcp library
 *
 *   Args:
 *
 *   Returns:
 *    >=0
 */
LONG PppCpInitialize(void);

/*
 * PppCpTerminate
 *   Terminate the pppcp library
 *
 *   Args:
 *
 *   Returns:
 *    >=0
 */
LONG PppCpTerminate(void);

/*
 * PppCpInstanceCreate
 *   Create a PppCpInstance
 *
 *   Args:
 *
 *   Returns:
 *     H_INSTANCE       Instance Handle
 */
H_NETINSTANCE PppCpInstanceCreate(void);

/*
 * PppCpInstanceDestroy
 *   Destroy a pppcp instance
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceDestroy(H_NETINSTANCE hPppCp);

/*
 * PppCpInstanceSet
 *   Set PPPCP options
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     oOption          Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceSet(H_NETINSTANCE hPppCp,OCTET oOption,
                      H_NETDATA hData);

/*
 * PppCpInstanceQuery
 *   Query PPPCP options
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     oMsg             Option code
 *     phData           data handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceQuery(H_NETINSTANCE hPppCp,OCTET oMsg,H_NETDATA * phData);

/*
 * PppCpInstanceMsg
 *   PPPCP msg function
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     oMsg             Option code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceMsg(H_NETINSTANCE hPppCp,OCTET oMsg,H_NETDATA hData);

/*
 * PppCpInstanceLLInterfaceCreate
 *   Create PPPCP LL interface
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *
 *   Return:
 *     H_NETINTERFACE
 */
H_NETINTERFACE PppCpInstanceLLInterfaceCreate(H_NETINSTANCE hPppCp);

/*
 * PppCpInstanceLLInterfaceDestroy
 *   Destroy PPPCP LL interface
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     hIf              interface handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceLLInterfaceDestroy(H_NETINSTANCE hPppCp, H_NETINTERFACE hIf);

/*
 * PppCpInstanceLLInterfaceIoctl
 *   PPPCP LL interface ioctl function
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     hIf              interface handle
 *     oIoctl           ioctl code
 *     hData            data handle
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceLLInterfaceIoctl(H_NETINSTANCE hPppCp, H_NETINTERFACE hIf,
                                    OCTET oIoctl,H_NETDATA hData);

/*
 * PppCpInstanceRcv
 *   PPP CP instance rcv
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *     hIf              interface handle
 *     pxPacket         packet
 *     pxAccess         access data
 *     hData            NETIFID *
 *
 *   Return:
 *     >=0
 */
LONG PppCpInstanceRcv(H_NETINSTANCE hPppCp, H_NETINTERFACE hIf,
                      NETPACKET *pxPacket, NETPACKETACCESS *pxAccess,
                      H_NETDATA hData);

/*
 * PppCpInstanceProcess
 *   PPP CP processing function
 *
 *   Args:
 *     hPppCp           Handle to the instance to destroy
 *
 *   Return:
 *     delay till next call (ms)
 */
LONG PppCpInstanceProcess(H_NETINSTANCE hPppCp);



#endif /* #define _PPPCP_H_ */
