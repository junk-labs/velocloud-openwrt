/*
 * eventmgr.c
 *
 * code and vars for the Event Manager
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/************/
/* includes */
/************/

#if !defined(NDEBUG)
#include <stdio.h>
#endif

#include <stdlib.h>
#include <stdarg.h>
#include <assert.h>
#include "NNstyle.h"
#include "eventmgr.h"

/***********/
/* defines */
/***********/

/************/
/* typedefs */
/************/

#define NO_EVENT_CBK    ((void *) -1)    /* callback not registered    */


/*
 * struct defining a registered event callback
 */
typedef struct CBK {
  struct CBK *pNext;        /* next callback for this event        */
  DWORD fFlags;            /* flags (defined below)        */
  E_EVENTCLASS eClass;        /* this event class            */
  int nNum;            /* this event number            */
  EVENT_CBK Callback;        /* the event callback            */
  void *hUser;            /* private data for the callback    */
  void *hMatchKey;        /* mathc key is used            */
} CBK, *P_CBK, **PP_CBK;

/* fFlags definitions    */
#define CBK_ON_NEXT    0x00000001    /* callback on next qualifying event */
#define CBK_ON_EVERY    0x00000002    /* callback on every qualifying event*/
#define CBK_MATCHANY    0x00000004    /* ignore posting hMatchKey         */


/*
 * an event array
 */
typedef PP_CBK EVENT_ARRAY;


/*
 * struct defining an event class
 */
typedef struct EVENT_CLASS {
  E_EVENTCLASS eClass;        /* this event class            */
  EVENT_ARRAY aEvent;        /* event array                */
  int nNumEvents;        /* number of events in event array    */
} EVENT_CLASS;


/********************/
/* public variables */
/********************/

DWORD gbl_fEventError;


/*********************/
/* private variables */
/*********************/

/*
 * Event Class Array
 *
 * This array (indexed by event class) contains a pointer to the Event Array
 * for each registered class (or NULL if no module has registered that
 * event class). An Event Array is an array of pointers (indexed by event
 * number) to registered callbacks (each such pointer being the top of the
 * callback chain for the event number), if there are no callbacks registered
 * for an event number then that pointer in the Event Array is NULL.
 */
EVENT_CLASS aEventClass[EVENTCLASS_ENUMMAX];


int nCbkMallocs, nEventArrayMallocs;

DWORD dwEventMgrInitialized = 0;

/********************************************************************
 *
 * Private Functions
 *
 ********************************************************************/

/* none */



/********************************************************************
 *
 * Public Functions
 *
 ********************************************************************/



/*************************
 *
 *  init and termination
 *
 *************************/


/*
 * initialize Event Mgr
 *
 * parms:
 *      none
 * returns:
 *      none
 */
void EventInitialize(void)
{
  int i;

  if (!dwEventMgrInitialized) {
    for (i = 0; i < EVENTCLASS_ENUMMAX; i++)
      aEventClass[i].eClass = i;
  }
  dwEventMgrInitialized ++;

  return;
}


/*
 * terminate Event Manager
 *
 * parms:
 *      none
 * returns:
 *      none
 */
void EventTerminate(void)
{
  ASSERT(dwEventMgrInitialized);
  dwEventMgrInitialized --;

  return;
}



/*************************
 *
 *  posting events
 *
 *************************/



/*
 * register to post events
 *
 * parms:
 *    eEventClass    the event class
 *    nNumEvents    number of different events in the class
 *
 * returns:
 *    hEventClass    registered event class handle
 *
 * (aborts on error)
 */
H_EVENT_CLASS EventRegisterClass(E_EVENTCLASS eEventClass, int nNumEvents)
{
  PP_CBK ppCbk;
  int i;

  ASSERT(dwEventMgrInitialized);

  /* check that class is in range    */
  if ((DWORD) eEventClass >= EVENTCLASS_ENUMMAX) {
    gbl_fEventError |= EVENT_ERR_CLASS;
    ASSERT((DWORD) eEventClass < EVENTCLASS_ENUMMAX);
    return (H_EVENT_CLASS) NULL;
  }

  /* check that class is not yet registered    */
  if (NULL != aEventClass[eEventClass].aEvent) {
    gbl_fEventError |= EVENT_ERR_DUPL;
    ASSERT(NULL == aEventClass[eEventClass].aEvent);
    return (H_EVENT_CLASS) NULL;
  }

  /* allocate an event array for the event class    */
  ppCbk = MALLOC(nNumEvents * sizeof(P_CBK));
  if (NULL == ppCbk) {
    gbl_fEventError |= EVENT_ERR_MEM;
    ASSERT(NULL != ppCbk);
    return (H_EVENT_CLASS) NULL;
  }
  nEventArrayMallocs++;
  ASSERT(nEventArrayMallocs > 0);

  /* initialize the event array to all NULL (i.e. no callbacks yet)    */
  for (i = 0; i < nNumEvents; i++)
    ppCbk[i] = (P_CBK) NULL;

  /* register the class and return the pointer into the event    */
  /*  class array as the handle                    */
  aEventClass[eEventClass].aEvent = ppCbk;
  aEventClass[eEventClass].nNumEvents = nNumEvents;
  return (H_EVENT_CLASS) &(aEventClass[eEventClass]);

}


/*
 * post an event
 *
 * this will result in each callback registered for this event class and
 * number being called if it is a qualifying event, i.e.
 *   - the posted event class and number match the callback event
 *      class and number
 *   and
 *   - the post hMatchKey equals the callback hMatchKey
 *   - or post specifies EVENT_MATCH_ANY
 *   - or callback registration specifies EVENT_MATCH_ANY
 * and if
 *   - the callback is set for every qualifying event (the default)
 *   - or a qualifying event has not occured since the callback was set for
 *      the next qualifying event
 *
 * parms:
 *    hEventClass    registered event class handle
 *    eEventNum    the event number
 *    pData        pointer to event data
 *    eUseMatchKey    whether or not to use a match key
 *    hMatchKey    the callback match key (if used), type: void *
 *
 */
void EventPost(H_EVENT_CLASS hEventClass, int eEventNum, void *pData,
                      E_EVENT_MATCHKEY eUseMatchKey, ...)
{
  va_list ap;
  EVENT_CLASS *pEventClass;
  P_CBK pCbk;
  void *hMatchKey = NULL;

  ASSERT(dwEventMgrInitialized);

  /* get the match key if specified */
  va_start(ap, eUseMatchKey);    /* initialize the variable arg list    */
  if (EVENT_MATCH_KEY == eUseMatchKey)
    hMatchKey = va_arg(ap, void*);

  /* sanity checks on handle and event number    */
  pEventClass = (EVENT_CLASS *) hEventClass;
  ASSERT(pEventClass >= &(aEventClass[0]));
  ASSERT(pEventClass < &(aEventClass[EVENTCLASS_ENUMMAX]));
  if (pEventClass != &(aEventClass[pEventClass->eClass])) {
    gbl_fEventError |= EVENT_ERR_POSTHANDLE;
    ASSERT(pEventClass == &(aEventClass[pEventClass->eClass]));
    return;
  }
  if ((DWORD) eEventNum >= pEventClass->nNumEvents) {
    gbl_fEventError |= EVENT_ERR_POSTNUM;
    ASSERT((DWORD) eEventNum < pEventClass->nNumEvents);
    return;
  }

  /* call all callbacks listed for this event    */
  pCbk = pEventClass->aEvent[eEventNum];
  while (pCbk != NULL) {
    ASSERT(eEventNum == pCbk->nNum);
    ASSERT(pEventClass->eClass == pCbk->eClass);
    ASSERT(NULL != pCbk->Callback);

    /* check if this is a qualifying event */
    if ((pCbk->fFlags & CBK_MATCHANY) ||
    (EVENT_MATCH_ANY == eUseMatchKey) ||
    (pCbk->hMatchKey == hMatchKey)) {

      /* check if the event passes the every/next test */
      if ((pCbk->fFlags & CBK_ON_EVERY) || (pCbk->fFlags & CBK_ON_NEXT)) {
    pCbk->fFlags &= ~CBK_ON_NEXT;
    (pCbk->Callback)(pCbk->eClass, pCbk->nNum, pData, pCbk->hUser);
      }
    }
    pCbk = pCbk->pNext;
  }

  va_end(ap);
}



/*
 * unregister an event class
 *
 * parm:
 *    hEventClass    event class handle
 */
void EventUnregisterClass(H_EVENT_CLASS hEventClass)
{
  EVENT_CLASS *pEventClass;
  int i;

  ASSERT(dwEventMgrInitialized);

  /* sanity checks on handle    */
  pEventClass = (EVENT_CLASS *) hEventClass;
  ASSERT(pEventClass >= &(aEventClass[0]));
  ASSERT(pEventClass < &(aEventClass[EVENTCLASS_ENUMMAX]));
  if (pEventClass != &(aEventClass[pEventClass->eClass])) {
    gbl_fEventError |= EVENT_ERR_POSTHANDLE;
    ASSERT(pEventClass == &(aEventClass[pEventClass->eClass]));
    return;
  }

  /* check if any callbacks still registered for this event class    */
  for (i = 0; i < pEventClass->nNumEvents; i++) {
    if (NULL != pEventClass->aEvent[i]) {
      gbl_fEventError |= EVENT_ERR_CLASS_ACTIVE;
      ASSERT(NULL == pEventClass->aEvent[i]);
      return;
    }
  }

  /* free the event array   */
  ASSERT(nEventArrayMallocs > 0);
  FREE(pEventClass->aEvent);
  nEventArrayMallocs--;

  /* unregister the event class    */
  pEventClass->aEvent = NULL;
  pEventClass->nNumEvents = 0;

  return;
}




/*****************************
*
*  callback registration
*
*****************************/

/*
 * register an event callback for the given event class and event number
 *
 * when an event occurs, the callback will be called if it
 * is a qualifying event, i.e.
 *   - the posted event class and number match the callback event
 *      class and number
 *   and
 *   - the post hMatchKey equals the callback hMatchKey
 *   - or post specifies EVENT_MATCH_ANY
 *   - or callback registration specifies EVENT_MATCH_ANY
 * and if
 *   - the callback is set for every qualifying event (the default)
 *   - or a qualifying event has not occured since the callback was set for
 *      the next qualifying event
 *
 * parms:
 *    eEventClass    the event class
 *    eEventNum    the event number
 *    hUser        handle to be passed to the event handler
 *    EventCallback    addr of the event callback
 *    eUseMatchKey    whether or not to use a match key
 *    hMatchKey    the callback match key (if used), type: void *
 *
 * returns:
 *    hEventCallback    registration handle to be used to unregister
 *
 * (asserts on error)
 *
 * NOTE: this is setup to return NO_EVENT_CLASS, i.e -1,
 *     if no event module registered the class
 *     (just remove the appropriate ASSERTs)
 */
H_EVENT_CBK EventRegisterCallback(E_EVENTCLASS eEventClass,
                  int eEventNum,
                  void *hUser,
                  EVENT_CBK EventCallback,
                  E_EVENT_MATCHKEY eUseMatchKey, ...)
{
  va_list ap;
  P_CBK pCbk;

  ASSERT(dwEventMgrInitialized);

  va_start(ap, eUseMatchKey);    /* initialize the variable arg list    */

  /* check if the event class is registered    */
  if ((DWORD) eEventClass >= EVENTCLASS_ENUMMAX) {    /* bad class    */
    gbl_fEventError |= EVENT_ERR_CLASS;
    ASSERT((DWORD) eEventClass < EVENTCLASS_ENUMMAX);
    return (H_EVENT_CBK) NO_EVENT_CBK;
  }
  if (NULL == aEventClass[eEventClass].aEvent) {    /* not registered */
    gbl_fEventError |= EVENT_ERR_UNREG_CLASS;
    ASSERT(NULL != aEventClass[eEventClass].aEvent);
    return (H_EVENT_CBK) NO_EVENT_CBK;
  }

  /* other sanity checks    */
  ASSERT(eEventClass == aEventClass[eEventClass].eClass);
  if ((DWORD) eEventNum >= aEventClass[eEventClass].nNumEvents) {
    gbl_fEventError |= EVENT_ERR_NUM;
    ASSERT((DWORD) eEventNum < aEventClass[eEventClass].nNumEvents);
    return (H_EVENT_CBK) NO_EVENT_CBK;
  }

  /* allocate a CBK structure    */
  pCbk = (P_CBK) MALLOC(sizeof(CBK));
  if (NULL == pCbk) {
    gbl_fEventError |= EVENT_ERR_MEM;
    ASSERT(NULL != pCbk);
    return (H_EVENT_CBK) NO_EVENT_CBK;
  }
  nCbkMallocs++;
  ASSERT(nCbkMallocs > 0);

  /* fill the CBK and link it into the callback chain for that event num */
  pCbk->eClass = eEventClass;
  pCbk->nNum = eEventNum;
  pCbk->Callback = EventCallback;
  pCbk->hUser = hUser;
  pCbk->fFlags = 0;
  if (EVENT_MATCH_KEY == eUseMatchKey) {
    pCbk->hMatchKey = va_arg(ap, void*);
    pCbk->fFlags &= CBK_MATCHANY;
  } else {
    pCbk->fFlags |= CBK_MATCHANY;
  }
  pCbk->fFlags |= CBK_ON_EVERY;
  pCbk->pNext = aEventClass[eEventClass].aEvent[eEventNum];
  aEventClass[eEventClass].aEvent[eEventNum] = pCbk;

  va_end(ap);
  return (H_EVENT_CBK) pCbk;
}

/*
 * set a register event callback to be called ONLY on the
 * NEXT qualifying event (subject to matching keys if hMatchKeys
 * have been specified)
 *
 * parms:
 *    hEventCallback        registration handle
 */
void EventCallbackOnNextOnly(H_EVENT_CBK hEventCallback)
{
  P_CBK pCbk;
  E_EVENTCLASS eClass;
  int nEventNum;

  ASSERT(dwEventMgrInitialized);

  /* just return if NO_EVENT_CBK */
  pCbk = hEventCallback;
  ASSERT(NULL != pCbk);
  if (NO_EVENT_CBK == pCbk)
    return;
  eClass = pCbk->eClass;
  nEventNum = pCbk->nNum;

  /* check that event class is registered and event num is valid     */
  if ((DWORD) eClass >= EVENTCLASS_ENUMMAX) {
    gbl_fEventError |= EVENT_ERR_UNREG_CLASS;
    ASSERT(NULL != aEventClass[eClass].aEvent);
    return;
  }
  if (NULL == aEventClass[eClass].aEvent) {
    gbl_fEventError |= EVENT_ERR_UNREG_CLASS;
    ASSERT(NULL != aEventClass[eClass].aEvent);
    return;
  }
  if ((DWORD) nEventNum > aEventClass[eClass].nNumEvents) {
    gbl_fEventError |= EVENT_ERR_UNREG_CBK;
    ASSERT((DWORD) nEventNum <= aEventClass[eClass].nNumEvents);
    return;
  }

  pCbk->fFlags &= ~CBK_ON_EVERY;
  pCbk->fFlags |= CBK_ON_NEXT;

  return;
}


/*
 * set a register event callback to be calledon EVERY
 * qualifying event (subject to matching keys if hMatchKeys
 * have been specified), this is the default setting when
 * the callback is registered
 *
 * parms:
 *    hEventCallback        registration handle
 */
void EventCallbackOnEvery(H_EVENT_CBK hEventCallback)
{
  P_CBK pCbk;
  E_EVENTCLASS eClass;
  int nEventNum;

  ASSERT(dwEventMgrInitialized);

  /* just return if NO_EVENT_CBK */
  pCbk = hEventCallback;
  ASSERT(NULL != pCbk);
  if (NO_EVENT_CBK == pCbk)
    return;
  eClass = pCbk->eClass;
  nEventNum = pCbk->nNum;

  /* check that event class is registered and event num is valid     */
  if ((DWORD) eClass >= EVENTCLASS_ENUMMAX) {
    gbl_fEventError |= EVENT_ERR_UNREG_CLASS;
    ASSERT(NULL != aEventClass[eClass].aEvent);
    return;
  }
  if (NULL == aEventClass[eClass].aEvent) {
    gbl_fEventError |= EVENT_ERR_UNREG_CLASS;
    ASSERT(NULL != aEventClass[eClass].aEvent);
    return;
  }
  if ((DWORD) nEventNum > aEventClass[eClass].nNumEvents) {
    gbl_fEventError |= EVENT_ERR_UNREG_CBK;
    ASSERT((DWORD) nEventNum <= aEventClass[eClass].nNumEvents);
    return;
  }

  pCbk->fFlags |= CBK_ON_EVERY;

  return;
}


/*
 * unregister an event callback
 *
 * parms:
 *    hEventCallback        registration handle to unregister
 */
void EventUnregisterCallback(H_EVENT_CBK hEventCallback)
{
  P_CBK pCbk, *ppCbk;
  E_EVENTCLASS eClass;
  int nEventNum;

  ASSERT(dwEventMgrInitialized);

  /* just return if NO_EVENT_CBK */
  pCbk = hEventCallback;
  if (NO_EVENT_CBK == pCbk)
    return;
  eClass = pCbk->eClass;
  nEventNum = pCbk->nNum;

  /* check that event class is registered and event num is valid     */
  if ((DWORD) eClass >= EVENTCLASS_ENUMMAX) {
    gbl_fEventError |= EVENT_ERR_UNREG_CLASS;
    ASSERT((DWORD) eClass < EVENTCLASS_ENUMMAX);
    return;
  }
  if (NULL == aEventClass[eClass].aEvent) {
    gbl_fEventError |= EVENT_ERR_UNREG_CLASS;
    ASSERT(NULL != aEventClass[eClass].aEvent);
    return;
  }
  if ((DWORD) nEventNum >= aEventClass[eClass].nNumEvents) {
    gbl_fEventError |= EVENT_ERR_UNREG_CBK;
    ASSERT((DWORD) nEventNum < aEventClass[eClass].nNumEvents);
    return;
  }

  /* find the callback in the callback chain    */
  ppCbk = &(aEventClass[eClass].aEvent[nEventNum]);
  while (1) {

    /* if enc of chain, then callback not found    */
    if (NULL == *ppCbk) {
      gbl_fEventError |= EVENT_ERR_UNREG_CBK;
      ASSERT(NULL != *ppCbk);
      return;
    }

    /* if match then done looking */
    if (pCbk == *ppCbk) {
      break;
    }

    /* next callback in the chain */
    ppCbk = &((*ppCbk)->pNext);

  }

  /* remove the callback in the callback chain and free it    */
  *ppCbk = pCbk->pNext;
  ASSERT(nCbkMallocs > 0);
  FREE(pCbk);
  nCbkMallocs--;
  return;
}












#if !defined(NDEBUG)
/*
 * (DEBUG only)
 *
 * Debug Event Callback, prints the event parms on stdout
 *
 * parms:
 *    eEventClass    the event class
 *    eEventNum    the event number
 *    pData        pointer to event data
 *    hUser        handle from the Register call
 */
void DbgEventCallback(E_EVENTCLASS eEventClass,
              int eEventNum,
              void *pData,
              void *hUser)
{

  ASSERT(dwEventMgrInitialized);

  printf("\nDbg EventCbk: EventClass %d, EventNum %d\n",
     eEventClass, eEventNum);
  printf("              hUser 0x%08lX, pData 0x%08lX, *pData 0x",
     (long unsigned) hUser, (long unsigned) pData);
  printf("%02X", *(0 + (OCTET *) pData));
  printf("%02X", *(1 + (OCTET *) pData));
  printf("%02X", *(2 + (OCTET *) pData));
  printf("%02X\n", *(3 + (OCTET *) pData));

}
#endif
