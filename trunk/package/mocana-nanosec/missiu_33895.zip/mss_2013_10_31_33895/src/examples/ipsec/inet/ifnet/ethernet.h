/*
 * ethernet.h
 *
 * ethernet module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ETHERNET_H_
#define _ETHERNET_H_

/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

#define ETHADDRESS_LEN            6    /* Ethernet address length in bytes */
#define ETHTYPE_LEN               2    /* Ethernet type length in bytes    */
#define ETHTYPE_OFFSET (ETHADDRESS_LEN*2) /* Offset of type in ethernet pkt */

/* Ethernet header size in bytes */
#define ETHHEADER_LEN ((ETHADDRESS_LEN*2)+ETHTYPE_LEN)
#define ETHDATA_LEN      1500 /* Maximum payload length in bytes excluding CRC */
#define ETHTOTAL_LEN     ETHDATA_LEN + ETHHEADER_LEN
#define ETH_MINLEN    60
#define ETH_MINLENCRC 64
#define ETH_CRCLEN     4
/*
 * VLAN protocol
 */
#define ETHVLAN_LEN     4                 /* 4 bytes for the VLAN tag */
#define ETHVLAN_OFFSET (ETHADDRESS_LEN*2) /* Offset of vlan field in ethernet pkt */
#define ETHVLAN_TYPE    0x8100            /* VLAN protocol ID */
#define ETHVID_MASK    ((WORD)0x0FFF)     /* Use to mask the VID */
#define ETHPRI_MASK    ((WORD)0xE000)     /* Use to mask the user priority */
#define ETHPRI_SHIFT   13                 /* Used to shift the user priority */
#define ETHPRI_LOW     3                  /* 0-3 == low, 4-7 == high (802.1Q)*/
/*
 * Ethernet UL Id
 */
#define ETHID_MIN              ETHID_IP
#define ETHID_IP               0x0800
#define ETHID_ARP              0x0806
#define ETHID_RARP             0x8035
#define ETHID_VLAN             0x8100
#define ETHID_PPPOEDISCOVERY   0x8863
#define ETHID_PPPOESESSION     0x8864
#define ETHID_MAX              ETHID_PPPOESESSION
#define ETHID_IP6              0x86DD

/*
 * Ethernet Option defaults
 */
#define ETHDEFAULT_OFFSET          0
#define ETHDEFAULT_PAD             0

/*
 * Ethernet UL Ioctls
 *  All are covered in netcommon.h (LIBNETCOMMON)
 */
#define ETHULINTERFACEIOCTL_SETIFIDX \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN) /* Set the phy if index to which
                                             this UL interface coresponds */
#define ETHULINTERFACEIOCTL_MAX \
  (NETINTERFACEIOCTL_MODULESPECIFICBEGIN + 1)
/*
 * Ethernet LL Ioctls
 *  o All Ioctls are covered in netcommon.h
 *  o The PFN_NETWRITE provided with
 *    NETINTERFACEIOCTL_OUTPUTPFN will be given as hDstId a ETHID *
 */

/*
 * Ethernet Instance Options
 */
#define ETHOPTION_MACADDR \
  (NETOPTION_MODULESPECIFICBEGIN) /* Device MAC address.
                                     Data is OCTET[6] */
#define ETHOPTION_IFTOLLMAP \
  (NETOPTION_MODULESPECIFICBEGIN + 1) /* Must be set before setting
                                         ETHMSG_SETLLDEFAULTVLAN
                                         Data is ETHIFTOLL */
#define ETHOPTION_MAX \
  (NETOPTION_MODULESPECIFICBEGIN + 2)

/*
 * Ethernet specific msgs
 */
#define ETHMSG_LOCALLOOPBACK \
  (NETMSG_MODULESPECIFICBEGIN) /* local loopback switch at the ethernet level
                                  data is boolean */
#define ETHMSG_SETLLDEFAULTVLAN \
  (NETMSG_MODULESPECIFICBEGIN + 1) /* Set the default VLAN for the LL interface.
                                      Overwrites the existing value.
                                      Data is ETHID with oIfIdx and wVlan specified.
                                      wVlan default: NETVLAN_DEFAULT == no vlan
                                      ETHOPTION_IFTOLLMAP must have been used
                                      to map the oIfIdx to the LL interface */
#define ETHMSG_ADDSPECIFICVLAN \
  (NETMSG_MODULESPECIFICBEGIN + 2) /* Adds a specific vlan for filtering.
                                      Data is DWORD, NETVLAN_DEFAULT == no vlan */
#define ETHMSG_REMOVESPECIFICVLAN \
  (NETMSG_MODULESPECIFICBEGIN + 3) /* Removes a specific vlan that has been added
                                      by ETHMSG_ADDSPECIFICVLAN
                                      Data is DWORD, NETVLAN_DEFAULT == no vlan */
#define ETHMSG_ENABLEBRIDGE \
  (NETMSG_MODULESPECIFICBEGIN + 4) /* Enables bridging on a specific index.
                                      Data is OCTET, Interface index */
#define ETHMSG_DISABLEBRIDGE \
  (NETMSG_MODULESPECIFICBEGIN + 5) /* Disables bridging on a specific index.
                                      Data is OCTET, Interface index */
#define ETHMSG_SETLANIF \
  (NETMSG_MODULESPECIFICBEGIN + 6) /* Specify the if that corresponds to the
                                      LAN physical connection.
                                      Data is OCTET, Interface index */
#define ETHMSG_SETIFBITRATE \
  (NETMSG_MODULESPECIFICBEGIN + 7) /* Specify the bitrate available on an interface
                                      Data is ETHBITRATE,
                                      dwBitRate is in Kbits/s - range 1 to 100000
                                      oIfIdx is the interface index */
#define ETHMSG_SETIFBCASTLIMIT \
  (NETMSG_MODULESPECIFICBEGIN + 8) /* Specify the broadcast limit on an interface
                                      Data is ETHIFLIMIT,
                                      oLimit is in percent - range 1% to 100%
                                      oIfIdx is the interface index */
#define ETHMSG_SETIFMCASTLIMIT \
  (NETMSG_MODULESPECIFICBEGIN + 9) /* Specify the Multicast limit on an interface
                                      Data is same as ETHMSG_SETIFBCASTLIMIT */
#define ETHMSG_GETIFSTATE \
  (NETMSG_MODULESPECIFICBEGIN + 10)/* Get the Spanning tree protocol state of
                                      a bridged interface
                                      Data is (ETHIFSTATE *),
                                      oState is filled with the state
                                      oIfIdx specifies the interface index
                                      returns NETERR_NOERR or
                                      NETERR_BADVALUE if the oIfIdx does not
                                      correspond with a bridged interface */
#define ETHMSG_FORWARDPPPOEONLY \
  (NETMSG_MODULESPECIFICBEGIN + 11)/* If set, the bridge will only forward PPPoE
                                      packets.
                                      Data is TRUE or FALSE
                                      returns NETERR_NOERR */
#define ETHMSG_SETINITIALIFSTATE \
  (NETMSG_MODULESPECIFICBEGIN + 12)/* Set the initial Spanning tree protocol
                                      state of a bridged interface
                                      Data is (ETHIFSTATE *),
                                      oState is the initial state
                                      oIfIdx specifies the interface index */
#define ETHMSG_MAX \
  (NETMSG_MODULESPECIFICBEGIN + 13)

/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/

typedef struct {
  OCTET aoDstAddr[ETHADDRESS_LEN];
  OCTET aoSrcAddr[ETHADDRESS_LEN];
  WORD  wType;
} ETH_HEADER;

typedef struct {
  OCTET aoDstAddr[ETHADDRESS_LEN];
  OCTET aoSrcAddr[ETHADDRESS_LEN];
  WORD  wVlanType;
  WORD  wVlan;
  WORD  wType;
} ETH_VLAN_HEADER;

/*
 * ETHID
 *  ethernet Id. Used for ethernet UL & LL interface traffic
 */
typedef struct {
  OCTET aoAddr[ETHADDRESS_LEN];
  OCTET oIfIdx; /* Interface index.
                   Default value 0xFF == undefined
                   Tx path: if it is defined,
                            the packet must go to this interface, and this
                            interface alone.
                   Rx path: indicates on which interface the
                            packet has been received */
  WORD wVlan;  /* VLAN field.
                   Default value: NETVLAN_DEFAULT == no vlan
                   Tx path: if != NETVLAN_DEFAULT the packet is built with this VLAN
                            but only if it is one of the VLANs added
                            specified by ETHMSG_ADDSPECIFICVLAN.
                            if == NETVLAN_DEFAULT the packet is built with
                            the LL interface default VLAN, specified
                            ETHMSG_SETLLDEFAULTVLAN, if this is != NETVLAN_DEFAULT,
                            or no VLAN is used if the default == NETVLAN_DEFAULT.
                   Rx path: indicates the VLAN on which the packet
                            was received.
                            NETVLAN_DEFAULT indicates no vlan */
} ETHID;

/*
 * ETHIFTOLL
 *  Used to map if indexes to LL interfaces.
 */
typedef struct {
  OCTET oIfIdx;                    /* Interface index */
  H_NETINTERFACE hLlIf;            /* Ethernet LL interface handle */
} ETHIFTOLL;

/*
 * ETHIFADDRESS
 *  Used to specify an ethernet address on an interface.
 */
typedef struct {
  OCTET aoEthAddr[ETHADDRESS_LEN]; /* Ethernet HW address */
  OCTET oIfIdx;                    /* Interface index */
} ETHIFADDRESS;

/*
 * ETHIFBITRATE
 *  Used to specify the connection bitrate on an interface.
 */
typedef struct {
  DWORD dwBitRate;                 /* Bitrate in Kbits/s */
  OCTET oIfIdx;                    /* Interface index */
} ETHIFBITRATE;

/*
 * ETHIFLIMIT
 *  Used to set the broadcast and multicast limits on an interface.
 */
typedef struct {
  OCTET oPercent;                  /* Limit in % */
  OCTET oIfIdx;                    /* Interface index */
} ETHIFLIMIT;

/*
 * Type used with ETHIFSTATE below.
 */
typedef enum {
  DISABLED = 0,
  LISTENING,
  LEARNING,
  FORWARDING,
  BLOCKING
} E_ETHIFSTAT;

/*
 * ETHIFSTATE
 *  Used to return the spanning tree state of a bridged interface.
 */
typedef struct {
  E_ETHIFSTAT eState;              /* State of the bridge interface
                                    * corresponding to the if idx */
  OCTET oIfIdx;                    /* Interface index */
} ETHIFSTATE;


/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * EthInitialize
 *  Initialize the ETH Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG EthInitialize(void);

/*
 * EthTerminate
 *  Terminate the ETH Library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG EthTerminate(void);

/*
 * EthInstanceCreate
 *  Creates a ETH Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE EthInstanceCreate(void);

/*
 * EthInstanceDestroy
 *  Destroy a ETH Instance
 *
 *  Args:
 *   hEth                       ETH instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceDestroy(H_NETINSTANCE hEth);

/*
 * EthInstanceSet
 *  Set a ETH Instance Option
 *
 *  Args:
 *   hEth                       ETH instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceSet(H_NETINSTANCE hEth,OCTET oOption,
                    H_NETDATA hData);

/*
 * EthInstanceQuery
 *  Query a ETH Instance Option
 *
 *  Args:
 *   hEth                       ETH instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceQuery(H_NETINSTANCE hEth,OCTET oOption,
                      H_NETDATA *phData);

/*
 * EthInstanceMsg
 *  Send a msg to a ETH instance
 *
 *  Args:
 *   hEth                       ETH instance
 *   oMsg                       Msg. See netcommon.h and above for definition
 *   hData                      Option data. See netcommon.h and above for data types
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG EthInstanceMsg(H_NETINSTANCE hEth,OCTET oMsg,
                    H_NETDATA hData);


/*
 * EthInstanceULInterfaceCreate
 *  Create an Interface to the Upper layer :
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hEth                       ETH instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE EthInstanceULInterfaceCreate(H_NETINSTANCE hEth);

/*
 * EthInstanceULInterfaceDestroy
 *  Destroy a ETH UL interface
 *
 *  Args:
 *   hEth                       ETH instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG EthInstanceULInterfaceDestroy(H_NETINSTANCE hEth,
                                   H_NETINTERFACE hInterface);

/*
 * EthInstanceULInterfaceIoctl
 *  Eth UL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h
 *  for precisions
 *
 *  Args:
 *   hEth                         ETH instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG EthInstanceULInterfaceIoctl(H_NETINSTANCE hEth,
                                 H_NETINTERFACE hULInterface,
                                 OCTET oIoctl,
                                 H_NETDATA hData);

/*
 * EthInstanceWrite
 *  Eth Instance Write function. Follows PFN_NETWRITE
 *  typedef.
 *
 *  Args:
 *   hEth                        Eth Instance handle
 *   hIf                         Interface handle
 *   pxPacket                    Packet pointer
 *   pxAccess                    NETPACKETACCESS pointer
 *   hData                       OCTET * interface index
 *
 *  Return:
 *  Number of bytes written or a <0 error code
 */
LONG EthInstanceWrite(H_NETINSTANCE hEth,
                      H_NETINTERFACE hIf,
                      NETPACKET *pxPacket,
                      NETPACKETACCESS *pxAccess,
                      H_NETDATA hData);

/*
 * EthInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hEth                       ETH instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE EthInstanceLLInterfaceCreate(H_NETINSTANCE hEth);

/*
 * EthInstanceLLInterfaceDestroy
 *  Destroy a ETH LL interface
 *
 *  Args:
 *   hEth                       ETH instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG EthInstanceLLInterfaceDestroy(H_NETINSTANCE hEth,
                                   H_NETINTERFACE hInterface);


/*
 * EthInstanceLLInterfaceIoctl
 *  ETH LL Interface Ioctl function. See the
 *  IOCTL definitions in netcommon.h
 *  for precisions
 *
 *  Args:
 *   hEth                         Eth instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG EthInstanceLLInterfaceIoctl(H_NETINSTANCE hEth,
                                H_NETINTERFACE hLLInterface,
                                OCTET oIoctl,
                                H_NETDATA hData);


/*
 * EthInstanceRcv
 *  Eth Instance Rcv function
 *   Eth Instance Rcv function. Follows PFN_NETRXCBK
 *   def.
 *
 *   Args:
 *    hEth                       Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    pxAccess                   NETPACKETACCESS pointer
 *    hData                      OCTET * interface index
 *
 *   Return:
 *    Number of byte received or a <0 error code
 */
LONG EthInstanceRcv(H_NETINSTANCE hEth,
                    H_NETINTERFACE hIf,
                    NETPACKET *pxPacket,
                    NETPACKETACCESS *pxAccess,
                    H_NETDATA hData);

/*
 * EthInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hEth                        Eth Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG EthInstanceProcess(H_NETINSTANCE hEth);

#endif /* #ifndef _ETHERNET_H_ */







