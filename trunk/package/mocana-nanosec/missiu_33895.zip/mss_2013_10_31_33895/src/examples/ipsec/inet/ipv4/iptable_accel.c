/*
 * iptable_accel.c
 *
 * iptable speed critical routines
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "iptable_flavor.h"
#include "../include/in.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "iptable.h"
#include "iptabledefs.h"
#include "iptabledbg.h"


/*****************************************************************************
 *
 * API
 *
 *****************************************************************************/

/*
 * IpTableMatch
 *  returns TRUE if the entries match, FALSE otherwise
 *
 *  Args:
 *   pxEntry1                 1st entry
 *   pxEntry2                 2nd entry
 *
 *  Return:
 *   TRUE==match. FALSE==don't match
 */
BOOL IpTableMatch(IPTABLEENTRY *pxEntry1,IPTABLEENTRY *pxEntry2)
{
  return ((/* Ip address check */
           (pxEntry1->eAddrType == IPADDRT_ANY) ||
           (pxEntry2->eAddrType == IPADDRT_ANY) ||
           (pxEntry1->dwAddr == pxEntry2->dwAddr))
          &&
          (/* oIfIdx check */
           (pxEntry1->oIfIdx == NETIFIDX_ANY) ||
           (pxEntry2->oIfIdx == NETIFIDX_ANY) ||
           (pxEntry1->oIfIdx == pxEntry2->oIfIdx))
          &&
          ( /* Default Vlan check */
           (pxEntry1->wDefaultVlan == NETVLAN_ANY) ||
           (pxEntry2->wDefaultVlan == NETVLAN_ANY) ||
           ((pxEntry1->wDefaultVlan & NETVLAN_VIDMASK) ==
              (pxEntry2->wDefaultVlan & NETVLAN_VIDMASK)))
          );
}

/*
 * IpTableMatchOnAddr
 *
 *  Args:
 *   pxEntry1                 1st entry
 *   pxEntry2                 2nd entry
 *
 *  Return:
 *   TRUE==match. FALSE==don't match
 */
BOOL IpTableMatchOnAddr(IPTABLEENTRY *pxEntry1,IPTABLEENTRY *pxEntry2)
{
#if 1
  int result = 0;
  result =  (/* Ip address check */
           (pxEntry1->dwAddr && pxEntry1->eAddrType == IPADDRT_ANY) ||
           (pxEntry2->dwAddr && pxEntry2->eAddrType == IPADDRT_ANY) ||
           (pxEntry1->dwAddr == pxEntry2->dwAddr))
          &&
          ( /* Default Vlan check */
           (pxEntry1->wDefaultVlan == NETVLAN_ANY) ||
           (pxEntry2->wDefaultVlan == NETVLAN_ANY) ||
           ((pxEntry1->wDefaultVlan & NETVLAN_VIDMASK) ==
              (pxEntry2->wDefaultVlan & NETVLAN_VIDMASK)));
   return result;

#else
  return ((/* Ip address check */
           (pxEntry1->dwAddr && pxEntry1->eAddrType == IPADDRT_ANY) ||
           (pxEntry2->dwAddr && pxEntry2->eAddrType == IPADDRT_ANY) ||
           (pxEntry1->dwAddr == pxEntry2->dwAddr))
          &&
          ( /* Default Vlan check */
           (pxEntry1->wDefaultVlan == NETVLAN_ANY) ||
           (pxEntry2->wDefaultVlan == NETVLAN_ANY) ||
           ((pxEntry1->wDefaultVlan & NETVLAN_VIDMASK) ==
              (pxEntry2->wDefaultVlan & NETVLAN_VIDMASK)))
          );
#endif
}

/*
 * IpTableRepositoryFindDefault
 *
 *  Args:
 *   pxRepository           repositort
 *   pxTemplate             entry template
 *
 *  Return:
 *   pointer to the entry in the table
 */
IPTABLEENTRY * IpTableRepositoryFindDefault(IPTABLEREPOSITORY *pxRepository,
                                            IPTABLEENTRY *pxTemplate)
{
  IPTABLEENTRY *pxEntry, *pxEntryEnd;
  pxEntry = pxRepository->pxEntryTable;
  pxEntryEnd = pxEntry + pxRepository->dwTableSize;

  while (pxEntry < pxEntryEnd) {
    if (IpTableMatch(pxEntry,pxTemplate)) {
      return pxEntry;
    }
    pxEntry++;
  }

  return NULL;
}

/*
 * IpTableOurIpAddr
 *  Find
 *
 *  Args:
 *   pxRepository           repositort
 *   pxTemplate             entry template
 *
 *  Return:
 *   pointer to the entry in the table
 */
IPTABLEENTRY * IpTableOurIpAddr(IPTABLEREPOSITORY *pxRepository,
                                IPTABLEENTRY *pxTemplate)
{
  IPTABLEENTRY *pxEntry, *pxEntryEnd;
  pxEntry = pxRepository->pxEntryTable;
  pxEntryEnd = pxEntry + pxRepository->dwTableSize;

  while (pxEntry < pxEntryEnd) {
    if (IpTableMatchOnAddr(pxEntry,pxTemplate)) {
      return pxEntry;
    }
    pxEntry++;
  }

  return NULL;
}

/*
 * IpTableGetAddrType
 *  Returns the entry addr type as defined in IPADDRT_
 *
 *  Args:
 *   pxEntry                  entry
 *
 *  Return:
 *   IPADDRT_ type
 */
LONG IpTableGetAddrType(IPTABLEENTRY *pxEntry)
{
  DWORD dwAddr,dwMask;
#ifdef IPTABLE_MCAST
  IPTABLEENTRY *pxMatch;
#endif /* #ifdef IPTABLE_MCAST */
  ASSERT(pxEntry != NULL);

  dwAddr = pxEntry->dwAddr;

  /* Accept both `all ones' and `all zeros' as BROADCAST. */
  if ((dwAddr == INADDR_ANY) || (dwAddr == INADDR_BROADCAST)) {
    return IPADDRT_BROADCAST;
  }

  dwMask = IpAddrGetMask(dwAddr);

  /* Accept all of the `loopback' class A net. */
  if ((dwAddr & dwMask) == 0x7F000000L)
  {
    return IPADDRT_LOOPBACK;
  }

  /* Check for class D: MULTICAST address */
  if IN_MULTICAST(dwAddr)
  {
#ifdef IPTABLE_MCAST
    if ((pxMatch =
         IpTableRepositoryFindDefault(&(xIpTable.xMcastRepository),pxEntry))
        != NULL) {
      return (pxMatch->eAddrType);
    }
#endif
    return IPADDRT_MULTICAST;
  }


  /* Matches one of our local IP addresses?  */

  if (IpTableOurIpAddr(&(xIpTable.xIpRepository),pxEntry) != NULL) {
    return IPADDRT_MYADDR;
  }

#ifdef IPTABLE_PPP
  /* Check now for the PPP: it could be anything */
  if (IpTableRepositoryFindDefault(&(xIpTable.xPppRepository),pxEntry)) {
    return IPADDRT_PPPPEER;
  }
#endif

  /* Forcing addr type "any", as exact matches have failed
     (Note: it will be set to the found value in iptable.c) */
  pxEntry->eAddrType = IPADDRT_ANY;

  /*
   * Check for (local) network broadcast, (local) subnetwork broadcast
   * and subnet address matches
   */
  {
    IPTABLEENTRY *pxTable, *pxTableEnd;
    DWORD dwDest;
    DWORD dwNetMask;

    pxTable = xIpTable.xIpRepository.pxEntryTable;
    pxTableEnd = pxTable + xIpTable.xIpRepository.dwTableSize;

    while (pxTable < pxTableEnd) {

      if (IpTableMatch(pxEntry, pxTable)) {

        /*
         * Check for (local) network broadcast.
         */
        if (((dwAddr ^ (pxTable->dwAddr)) & dwMask) == 0) {
          dwDest = dwAddr & ~dwMask;

          if ((dwDest == 0x0) || (dwDest == ~dwMask)) {
            return IPADDRT_BROADCAST;
          }
        }

        /*
         * Check for (local) subnet broadcast.
         */
        dwNetMask = pxTable->u.dwIpNetMask;
        if (((dwAddr ^ (pxTable->dwAddr)) & dwNetMask) == 0) {
          dwDest = dwAddr & ~dwNetMask;

          if ((dwDest == 0x0) || (dwDest == ~dwNetMask)) {
            return IPADDRT_BROADCAST;
          } else {
            return IPADDRT_MYSUBNET;
          }
        }
      }

      pxTable ++;
    }
  }

  return IPADDRT_OUTSIDE;
}


#ifndef IPTABLE_SINGLEIF
/*
 * IpTableGetIfIdx
 *  Returns the interface index corresponding to the given
 *  address.
 *
 *  Args:
 *   pxEntry                  entry
 *
 *  Return:
 *   Interface index.
 */
LONG IpTableGetIfIdx(IPTABLEENTRY *pxEntry)
{
  LONG lReturn = (LONG) NETIFIDX_ANY;
  IPTABLEENTRY *pxMatch;
  IPTABLEREPOSITORY* pxRepository;

  switch (pxEntry->eAddrType) {

    case IPADDRT_MYADDR:
#ifdef IPTABLE_PPP
    case IPADDRT_PPPPEER:
      pxRepository = (pxEntry->eAddrType == IPADDRT_MYADDR) ?
                     (&(xIpTable.xIpRepository)) :
                     (&(xIpTable.xPppRepository));
#else
      pxRepository = &(xIpTable.xIpRepository);
#endif

      if ((pxMatch = IpTableRepositoryFindDefault(pxRepository,
                                                  pxEntry)) != NULL) {
        lReturn = (LONG) pxMatch->oIfIdx;
      }
      break;

    case IPADDRT_MYSUBNET:
    case IPADDRT_BROADCAST:
      if (pxEntry->oIfIdx == NETIFIDX_ANY) {
        IPTABLEENTRY *pxMatchEnd;

        pxMatch = xIpTable.xIpRepository.pxEntryTable;
        pxMatchEnd = pxMatch + xIpTable.xIpRepository.dwTableSize;

        while (pxMatch < pxMatchEnd) {
          if ((pxEntry->dwAddr & pxMatch->u.dwIpNetMask) == (pxMatch->dwAddr & pxMatch->u.dwIpNetMask)) {
             lReturn = (LONG) pxMatch->oIfIdx;
            break;
          }
          pxMatch ++;
        }
      }
#ifndef NDEBUG
      else {
        /*
         * Make sure that the given index is correct.
         */
        pxMatch = xIpTable.xIpRepository.pxEntryTable + pxEntry->oIfIdx;
        ASSERT((pxEntry->dwAddr & pxMatch->u.dwIpNetMask) ==
               (pxMatch->dwAddr & pxMatch->u.dwIpNetMask));
      }
#endif
      break;

    default:
      ASSERT(0);
  }

  return lReturn;
}
#endif /* #ifndef IPTABLE_SINGLEIF */
