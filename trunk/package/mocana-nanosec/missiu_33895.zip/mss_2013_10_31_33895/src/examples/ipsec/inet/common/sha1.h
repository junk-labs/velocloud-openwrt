/*
 * sha1.h
 *
 * sha1 algorithm API.
 *    derived from the RSA Data Security, Inc. Message-Digest
 *    Algorithm
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _SHA1_H_
#define _SHA1_H_


/*****************************************************************************
 *
 * Defines
 *
 *****************************************************************************/

#define SHA1_HASH_SIZE 20

/* ROTATE_LEFT rotates x left n bits.
 */
#define ROL(value, bits) (((value) << (bits)) | ((value) >> (32-(bits))))

#define blk(i) (adwX[i&0x0f] = ROL(adwX[(i+13)&0x0f]^adwX[(i+8)&0x0f] \
    ^adwX[(i+2)&0x0f]^adwX[i&0x0f],1))

/* (R0+R1), R2, R3, R4 are the different operations used in SHA1 */
#define R0(v,w,x,y,z,i) z+=((w&(x^y))^y)+adwX[i]+0x5A827999+ROL(v,5);w=ROL(w,30);
#define R1(v,w,x,y,z,i) z+=((w&(x^y))^y)+blk(i)+0x5A827999+ROL(v,5);w=ROL(w,30);
#define R2(v,w,x,y,z,i) z+=(w^x^y)+blk(i)+0x6ED9EBA1+ROL(v,5);w=ROL(w,30);
#define R3(v,w,x,y,z,i) z+=(((w|x)&y)|(w&x))+blk(i)+0x8F1BBCDC+ROL(v,5);w=ROL(w,30);
#define R4(v,w,x,y,z,i) z+=(w^x^y)+blk(i)+0xCA62C1D6+ROL(v,5);w=ROL(w,30);

/*****************************************************************************
 *
 * Local function prototype
 *
 *****************************************************************************/
void SHA1TransformFast(DWORD adwState[5], DWORD adwX[16]);

/*****************************************************************************
 *
 * Globals
 *
 *****************************************************************************/



/*****************************************************************************
 *
 * Typedef
 *
 *****************************************************************************/

/*
 * SHA1 context
 */
typedef struct
{
  DWORD adwState[5];    /* state (ABCDE) */
  DWORD adwCount[2];    /* number of bits, modulo 2^64 (lsb first) */
  OCTET aoBuffer[64];    /* input buffer */
} SHA1_CTX;

/*****************************************************************************
 *
 * Function prototypes
 *
 *****************************************************************************/

/*
 * SHA1Init
 *  SHA1 initialization. Begins an SHA1 operation, creating a new context
 *
 *  Args:
 *
 *  Return:
 *    H_CRYPT          Context handle
 */
H_CRYPT SHA1Init(void);

/*
 * SHA1Update
 *  SHA1 block update operation. Continues an SHA1 message-digest
 *  operation, processing another message block, and updating the
 *  context.
 *
 *  Args:
 *    hCrypt                Context handle
 *    poInput               input block
 *    dwInputLen            length of input block
 *
 *  Return:
 */
void SHA1Update(H_CRYPT hCrypt, OCTET* poInput, DWORD dwInputLen);

/*
 * SHA1Final
 *  SHA1 finalization. Ends an SHA1 message-digest operation, writing the
 *  the message digest and zeroizing the context.
 *
 *  Args:
 *   hCrypt               Context handle
 *   pOutput              Must be allocated and of length SHA1_HASH_SIZE(20)
 *
 *  Return:
 */
void SHA1Final(H_CRYPT hCrypt, OCTET* poDigest);

void SHA1Fast(H_CRYPT hCrypt, DWORD dwInputLen, DWORD* pdwInput);

#endif /* _SHA1_H_ */

