/*
 * alg_rtsp_audio.c
 *
 * RTSP Audio ALG (RFC2326), used for ReadAudio
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#include "alg_rtsp_audio.h"

typedef struct {
  int iPort;
  WORD wOffset;
} PORTSTORE;

#define MAX_PORTS_PER_PACKET 6

/* additional # bytes allowed for each port translation */
#define ALLOWANCE_PER_PORT 5


/*****************************************************************************
Function:
        _FindStrInPacket()

Description:
        Searches through the a packet for the next occurance of poFindString
        from the initial wOffset.
Arguments:
        OCTET*        poPktStart      pointer to start of packet
        WORD          wStartOffset    offset into packet at which to start search
        OCTET*        poFindString    pointer to null terminated string to find
        DWORD         dwPktLen        length of packet

Returns:
        WORD          >0              offset into packet of poFindString
                      0               string not found
Revisions:
        1-Nov-2001                    Initial
*****************************************************************************/
WORD _FindStrInPacket(const OCTET *poPktStart,
                      WORD wStartOffset,
                      const OCTET *poFindString,
                      DWORD dwPktLen)
{
  WORD wOffset = wStartOffset;
  OCTET oFirst = poFindString[0];
  WORD wLen = strlen(poFindString);
  sbyte4 cmpResult;

  ASSERT(wLen && dwPktLen>wLen && poFindString && poPktStart);

  MOC_MEMCMP(&poPktStart[wOffset],poFindString,wLen, &cmpResult);
  while (wOffset<(dwPktLen-wLen+1)) {
    if ((poPktStart[wOffset] == oFirst) && (0 == cmpResult))
      return wOffset;
    wOffset++;
  }

  return 0;
}


/*****************************************************************************
Function:
        ProcessRTSPPacket()
Description:
        Searches through the payload of an RTSP packet for 'SETUP' commands.
        Replaces the port strings with relevent translations.
Arguments:
        NATSTATE*               pxNat                   NAT instance handle
        NETPACKET*              pxNetPacket             Packet pointer
        NETPACKETACCESS*        pxNetPacketAccess       Packet info
        H_NETDATA               hData                   NETWORKID*
        DWORD                   dwPayloadOffset         Offset to start of payload
        DWORD                   dwLanAddr               LAN IP Addr
        DWORD                   dwTransAddr             Translated IP Addr
        SHORT*                  psDelta                 Change in the packet size,
                                                        this is an output
Outputs:
        NETPACKET*              pxNetPacket             Modified packet (if necessary)
        NETPACKETACCESS*        pxNetPacketAccess       Modified packet info (if necessary)
        H_NEDATA                hData                   Modified NETWORKID (if necessary)
        SHORT*                  psDelta                 Change in the packet size
Returns:
        LONG                    1                       Packet payload was altered
                            0                       Packet payload was not altered
                                -1                      Error
Revisions:
        30-Oct-2001                                     Initial
        26-Mar-2002                                     API change
*****************************************************************************/
LONG ProcessRTSPPacket(NATSTATE* pxNat,
                       NETPACKET *pxNetPacket,
                       NETPACKETACCESS *pxNetPacketAccess,
                       H_NETDATA hData,
                       DWORD dwPayloadOffset,
                       DWORD dwLanAddr,
                       DWORD dwTransAddr,
                       SHORT *psDelta)
{
  BOOL bSuccess = TRUE;
  WORD wTotalPorts = 0;
  PORTSTORE asPortStore[MAX_PORTS_PER_PACKET];
  WORD wOffset;
  NETWORKID* pxNetworkId = (NETWORKID*) hData;
  NETPAYLOAD* pxNetPayload = pxNetPacket->pxPayload;
  OCTET *poPayload = pxNetPayload->poPayload;

  /* Look for and replace 'SETUP' command parameters */
  if (!strncasecmp(&poPayload[dwPayloadOffset],"SETUP",5)) {

    NAT_DBGP(DBGLVL_REPETITIVE, "Detected SETUP command\n");

    /* find "Transport:" information */
    wOffset = dwPayloadOffset+5;  /* SETUP=5 */
    wOffset = _FindStrInPacket(poPayload, wOffset, "Transport:", pxNetPayload->wSize);

    if (wOffset) {

      while(0 != (wOffset = _FindStrInPacket(poPayload, wOffset, "client_port", pxNetPayload->wSize))) {
        wOffset+=11;   /*client_port*/
        if (poPayload[wOffset] == '=') {
          OCTET oNumPorts;
          int iPort1, iPort2;
          wOffset++;
          oNumPorts = sscanf(&poPayload[wOffset],"%d-%d",&iPort1,&iPort2);
          if (oNumPorts) {
            asPortStore[wTotalPorts].iPort = iPort1;
            asPortStore[wTotalPorts].wOffset = wOffset;
            wTotalPorts++;
            if (2 == oNumPorts) {
              wOffset = _FindStrInPacket(poPayload, wOffset, "-", pxNetPayload->wSize);
              wOffset++;
              asPortStore[wTotalPorts].iPort = iPort2;
              asPortStore[wTotalPorts].wOffset = wOffset;
              wTotalPorts++;
            }
          } else {
            NAT_DBGP(DBGLVL_REPETITIVE, "Unexpected port format\n");
            bSuccess = FALSE;
            break;
          }

        } else {
          NAT_DBGP(DBGLVL_REPETITIVE, "Unexpected client_port format\n");
          bSuccess = FALSE;
          break;
        }
      }

      if (wTotalPorts && bSuccess) {

        OCTET * poOldPacket;
        OCTET * poNewPacket;
        OCTET * poNewPacketStart;
        WORD i;
        WORD wCopyLen;
        WORD wTransPort;
        NAT_ENTRY* pxNatEntry;

        /* for simplicity always create a new packet, it is only a one off */
        poOldPacket = poPayload;
        poNewPacketStart = MALLOC((pxNetPayload->wSize + wTotalPorts*ALLOWANCE_PER_PORT) * sizeof(CHAR));
        MOC_MEMSET((ubyte *)poNetPacketStart, 0,
            (pxNetPayload->wSize + wTotalPorts*ALLOWANCE_PER_PORT)
                   * sizeof(CHAR));

        /* copy old to new packet */
        i=0;
        wOffset=0;
        poNewPacket = poNewPacketStart;
        while ((i<wTotalPorts) && (wOffset != pxNetPayload->wSize)) {
          wCopyLen = asPortStore[i].wOffset - wOffset;
          MOC_MEMCPY((ubyte *)poNewPacket,(ubyte *)&poOldPacket[wOffset],wCopyLen);

          /* insert new port number */
          poNewPacket += wCopyLen;

      if ((wTransPort = NatPortForwardAlg(pxNat,
                                              dwLanAddr, asPortStore[i].iPort,
                                              dwTransAddr, pxNetworkId->oIfIdx,
                                              IPPROTO_UDP)) == 0) {
            /* Cannot create a port binding */
            FREE(poNewPacketStart);
            return (-1);
          }

          /* binding WAN IP and port must be cleared in case binding reused (WAN IP and port can change) */
          pxNatEntry = NatFindTUBindingTx(pxNat, dwLanAddr, asPortStore[i].iPort, 0, 0, IPPROTO_UDP);
          if (pxNatEntry) {
            pxNatEntry->wFlags |= (NAT_WAN_PORT_EMPTY | NAT_WAN_IP_EMPTY);
            pxNatEntry->dwWanAddr = 0;
            pxNatEntry->u.xTUMapping.wWanPort = 0;
          }

          poNewPacket += sprintf(poNewPacket,"%d", wTransPort);
          /* move up old packet index */
          wOffset += wCopyLen;
          while(wOffset<pxNetPayload->wSize) {
            if(poOldPacket[wOffset] == ';' || poOldPacket[wOffset] == '-') {
              break;
            }
            wOffset++;
          }
          i++;
        }

        if (wOffset != pxNetPayload->wSize) {

          DWORD dwNewLen;

          /* copy the rest */
          wCopyLen = pxNetPayload->wSize - wOffset;
          MOC_MEMCPY((ubyte *)poNewPacket,(ubyte *)&poOldPacket[wOffset],wCopyLen);
          poNewPacket += wCopyLen;

          /* update packet length */
          dwNewLen = poNewPacket - poNewPacketStart;

          *psDelta = (SHORT)(dwNewLen - pxNetPayload->wSize);
          pxNetPacketAccess->wLength += *psDelta;
          pxNetworkId->wTotalLen += *psDelta;

          /* free old packet */
          NETPAYLOAD_DELUSER(pxNetPayload);

          /* create new packet */
          NETPAYLOAD_CREATE(&pxNetPacket->pxPayload,
                            NetFree,
                            NULL,         /* TODO use the proper Mutex */
                            poNewPacketStart,
                            dwNewLen);

          return (1);

        } else {
          FREE(poNewPacketStart);
          NAT_DBGP(DBGLVL_REPETITIVE, "New packet creation failure\n");
        }
      } else {
        NAT_DBGP(DBGLVL_REPETITIVE, "No client_ports found\n");
      } /* "client_port" */
    } else {
      NAT_DBGP(DBGLVL_REPETITIVE, "Transport information not found\n");
    } /* "Transport" */
  }  /* "SETUP" */


  /* Payload was not changed */
  *psDelta = 0;
  return (0);
}



/*****************************************************************************
Function:
        AlgRTSPAudio()
Description:
        Searches through the payload of an RTSP Real Audio TCP transport packet
        for 'SETUP' command.  Replaces the port strings with relevent
        translations. Also updates the TCP sequence and acknowledement numbers
        based on the cumulative deltas in the packet size.
Arguments:
        NATSTATE*               pxNat                   NAT instance handle.
        NETPACKET*              pxNetPacket             Packet pointer
        NETPACKETACCESS*        pxNetPacketAccess       Packet info
        H_NETDATA               hData                   NETWORKID*
        NAT_ENTRY*              pxNatEntry              Pointer to the NAT binding entry
        WORD                    wLanPort                The LAN port
        E_NAT_DIRECTION         eDirection              Packet flow direction
Outputs:
        NETPACKET*              pxNetPacket             Modified packet (if necessary)
        NETPACKETACCESS*        pxNetPacketAccess       Modified packet info (if necessary)
        H_NEDATA                hData                   Modified NETWORKID (if necessary)
Returns:
        LONG                    1                       Packet payload was altered
                                0                       Packet payload was not altered
                                -1                      Error
Revisions:
        30-Oct-2001                                     Initial
        26-Mar-2002                                     API change
*****************************************************************************/
LONG AlgRTSPAudio(NATSTATE *pxNat,
                  NETPACKET *pxNetPacket,
                  NETPACKETACCESS *pxNetPacketAccess,
                  H_NETDATA hData,
                  void *pvProtocolHdr,
                  NAT_ENTRY *pxNatEntry,
                  WORD wLANPort,
                  E_NAT_DIRECTION eDirection)
{
  SHORT sDeltaLength = 0;
  LONG lReturn = 0;
  TCPHDR* pxTcpHdr = (TCPHDR*) pvProtocolHdr;
#ifdef NATDBG_HI
  NETWORKID* pxNetworkId = (NETWORKID*) hData;
#endif

  /* WAN -> LAN (Downstream) */
  if (eDirection == NAT_DIR_W2L) {

    /* Only need to modify the acknowledgement number */
    if (pxNatEntry->u.xTUMapping.lUpstreamSeqDelta) {

      NAT_DBGP(DBGLVL_REPETITIVE, "W2L - TCP Acknowledgement number changed from %lu to ", TCP_GET_ACK_NUM(pxTcpHdr));

      TCP_SET_ACK_NUM(pxTcpHdr, (TCP_GET_ACK_NUM(pxTcpHdr) - pxNatEntry->u.xTUMapping.lUpstreamSeqDelta));

      if ((TCP_GET_ACK_NUM(pxTcpHdr) <= pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum) ||
          ((TCP_GET_ACK_NUM(pxTcpHdr) - pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum) > (1<<16)) /* Assume wraparound */) {
        /* This is an acknowledgement of a packet that occurred before the
         * last packet which required a payload modification */
        TCP_SET_ACK_NUM(pxTcpHdr, (TCP_GET_ACK_NUM(pxTcpHdr) + pxNatEntry->u.xTUMapping.sLastPayloadModifiedDelta));
        NAT_DBGP(DBGLVL_REPETITIVE, "(retransmission) ");
      }

      NAT_DBGP(DBGLVL_REPETITIVE, "%lu, Sequence Number = %lu\n", TCP_GET_ACK_NUM(pxTcpHdr),
                      TCP_GET_SEQ_NUM(pxTcpHdr));

      lReturn = 1;
    }

  } else {  /* LAN -> WAN (Upstream) */

    DWORD dwOriginalSeqNum = TCP_GET_SEQ_NUM(pxTcpHdr);
    DWORD dwPayloadOffset = pxNetPacketAccess->wOffset + TCP_GET_HEADER_LEN(pxTcpHdr);

    /* Perform substitution and get change in payload size (if any) */
    lReturn = ProcessRTSPPacket(pxNat,
                                pxNetPacket,
                                pxNetPacketAccess,
                                hData,
                                dwPayloadOffset,
                                pxNatEntry->dwLanAddr,
                                pxNatEntry->dwTransAddr,
                                &sDeltaLength);
    if (lReturn < 0) {
      return (lReturn);
    }

    /* Update upstream TCP sequence numbers */
    if (pxNatEntry->u.xTUMapping.lUpstreamSeqDelta || sDeltaLength) {
      pxTcpHdr = (TCPHDR*) (pxNetPacket->pxPayload->poPayload + pxNetPacketAccess->wOffset);
      ASSERT(((DWORD) pxTcpHdr & 0x3) == 0);


      NAT_DBGP(DBGLVL_REPETITIVE, "L2W - TCP Sequence number changed from %lu to ", TCP_GET_SEQ_NUM(pxTcpHdr));

      TCP_SET_SEQ_NUM(pxTcpHdr, (TCP_GET_SEQ_NUM(pxTcpHdr) + pxNatEntry->u.xTUMapping.lUpstreamSeqDelta));

      if ((dwOriginalSeqNum <= pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum) ||
          (pxNatEntry->u.xTUMapping.lUpstreamSeqDelta &&
           ((dwOriginalSeqNum -
             pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum) > (1<<16)) /* Assume wraparound */)) {

        /* This looks like a retransmission of a packet that occurred before
         * the last packet that required a payload modification. Therefore
         * use the previous delta value. This should also catch retransmissions
         * of the packet which required payload mods */
        TCP_SET_SEQ_NUM(pxTcpHdr, (TCP_GET_SEQ_NUM(pxTcpHdr) - pxNatEntry->u.xTUMapping.sLastPayloadModifiedDelta));
        NAT_DBGP(DBGLVL_REPETITIVE, "(retransmission) ");

      } else {

        if (lReturn && sDeltaLength) {
          /* The payload was modified and the length changed */
          pxNatEntry->u.xTUMapping.dwLastPayloadModifiedSeqNum = dwOriginalSeqNum;
          pxNatEntry->u.xTUMapping.sLastPayloadModifiedDelta = sDeltaLength;
          pxNatEntry->u.xTUMapping.lUpstreamSeqDelta += sDeltaLength;
        }

      }

      NAT_DBGP(DBGLVL_REPETITIVE, "%lu, New payload size = %d\n", TCP_GET_SEQ_NUM(pxTcpHdr),
                      (pxNetworkId->wTotalLen - pxNetworkId->oIpHdrLen - TCP_GET_HEADER_LEN(pxTcpHdr)));


      lReturn = 1;
    }
  }

  return (lReturn);
}
