/*
 * setupnet_limiter.c
 *
 * Functions to setup the limiter
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "netcfg.h"
#include "setupnet.h"
#include "configapi.h"
#include "net/if_dl.h"
#include "netstack.h"
#include "netdefs.h"

#if 0

const VAR_IOCTL gpxLimiterVarIoctlTableSet[] = {
  {"LIMITER_VLAN_ENABLE", SIOCLIMITER_VLAN_ENABLE},
  {"LIMITER_VLAN_VALUE",  SIOCLIMITER_VLAN_VALUE},
  {"LIMITER_TOS_ENABLE",  SIOCLIMITER_TOS_ENABLE},
  {"LIMITER_TOS_MASK",    SIOCLIMITER_TOS_MASK},
  {NULL,                  0}  /* End marker */
};


/*
 * SetupNetLimiterByConfigParam
 *   Function to configure the limiter, called by SetupNet and WebPostCallback
 *
 *   Args:
 *    int iSocketFd
 *    CONFIG_PARAM axConfigParam[]
 *
 *   Return:
 *     > 0
 */
LONG SetupNetLimiterByConfigParam(int iSocketFd,CONFIG_PARAM axConfigParam[])
{
  ioctl(iSocketFd,SIOCLIMITER_VLAN_ENABLE,
        memcmp(axConfigParam[0].acVarValue,"YES",3) ? FALSE : TRUE);
  ioctl(iSocketFd,SIOCLIMITER_VLAN_VALUE,
        atoi(axConfigParam[1].acVarValue));
  ioctl(iSocketFd,SIOCLIMITER_TOS_ENABLE,
        memcmp(axConfigParam[2].acVarValue,"YES",3) ? FALSE : TRUE);
  ioctl(iSocketFd,SIOCLIMITER_TOS_MASK,
        atoi(axConfigParam[3].acVarValue));

  return 0;
}

#endif
/*
 * SetupNetLimiter
 *   Function to configure the limiter
 *
 *   Args:
 *    None
 *
 *   Return:
 *    SetupNetReturn           error code (see setupnet.h for def)
 */
SetupNetReturn SetupNetLimiter(int iSocketFd)
{
#if 0
  CONFIG_PARAM axConfigParam[sizeof(*gpxLimiterVarIoctlTableSet)/sizeof(VAR_IOCTL)];
  int iRv,i = 0;
  PORT_RANGE xPortRange = {9000,9010};

  MOC_MEMSET((ubyte *)axConfigParam,0,sizeof(axConfigParam));

  while(gpxLimiterVarIoctlTableSet[i].pcVarName != NULL){
    if(ConfigGetParam(gpxLimiterVarIoctlTableSet[i].pcVarName,
                      axConfigParam[i].acVarValue,
                      CONFIG_MAXPARAMLENGTH) == CONFIG_OK) {
      axConfigParam[i].pcVarName = gpxLimiterVarIoctlTableSet[i].pcVarName;
      SETUPNET_DBGP(NORMAL,"SetupNetLimiter: %s = %s\n",
                    axConfigParam[i].pcVarName,
                    axConfigParam[i].acVarValue);
    }
    i++;
  }

  SetupNetLimiterByConfigParam(iSocketFd,axConfigParam);

  iRv = ioctl(iSocketFd,SIOCLIMITER_PORT_ADD,&xPortRange);
  ASSERT(iRv == 0);

#endif

  return SETUPNET_OK;
}

