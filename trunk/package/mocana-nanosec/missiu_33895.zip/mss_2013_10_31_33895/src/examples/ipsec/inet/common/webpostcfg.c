/*
 * webpostcfg.c
 *
 * Functions to process web posted network configuration variables
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/
#include "netcfg.h"
#include "setupnet.h"
#if JJ
#include "httpapi.h"
#endif
#include "configapi.h"
#include "net/if_dl.h"
#include "routercfgapi.h"

/****************************************************************************
 *
 * Globals
 *
 ****************************************************************************/
extern VAR_IOCTL pxIfVarIoctlTableSet[];
#ifdef NET_DSL
extern VAR_IOCTL pxAtmIfVarIoctlTableSet[];
#endif

/****************************************************************************
 *
 * Local private functions
 *
 ****************************************************************************/

/*
 * _PostGetParam
 *  Find a parameter in the list of HTTP posted configuration variables
 *
 *  Args:
 *   pp                  Pointer to the list of HTTP posted parameters
 *   pchParamName        Parameter to search for
 *   pchParamValue       Parameter value to fill
 *
 *  Return
 *   0  - Parameter found
 *   -1 - Parameter not found
 */

#if JJ
LONG _PostGetParam(PostParam* pp, char *pchParamName, char **pchParamValue)
{
  int i;
  *pchParamValue = NULL;

  for (i=0; i<pp->iNumParams; i++) {
    if (!strcmp(pchParamName, pp->stParams[i].pchParamName)) {
      *pchParamValue = pp->stParams[i].pchParamValue;
      return 0;
    }
  }

  return -1;
}

#endif
/*
 * _WaitForInterfaceToClose
 *  Wait for an interface to close
 *
 *  Args:
 *   iSock               Socket handle to use for ioctl calls
 *   oIfIdx              Interface index to check
 *
 *  Return
 */
void _WaitForInterfaceToClose(int iSock, OCTET oIfIdx)
{
  struct timespec stTime;
  struct ifreq xIfReq;

  xIfReq.ifr_name[0] = oIfIdx;

  /* set loop time */
  stTime.tv_sec=0;
  stTime.tv_nsec=200*1000000; /* 200ms */
  while(1) {
    ioctl(iSock, SIOCGIFIFLAG, &xIfReq);
    if ((xIfReq.ifr_flags & IFF_UP) == 0) {
      break;
    }

    /* give net stack time to execute */
    nanosleep(&stTime,NULL);
  }
}


/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/

/*
 * SetupNetWebPostCallback
 *  Processes a list of HTTP posted web parameters pertaining to (re)configuration
 *  of network interfaces
 *
 *  Args:
 *   hWebdata            Pointer to the list of HTTP posted parameters
 *
 *  Return
 *    1
 */

#if JJ
int SetupNetWebPostCallback(H_WEBDATA hWebdata)
{
  PostParam *pp = (PostParam *)hWebdata;
  int iSock;
  OCTET oIfIdx;
  OCTET oIfNum = 1;   /* Default */
  char cTmpString[30];
  char *pchParamValue;
  int iRv;
  struct ifreq xIfReq;

#ifdef NET_MULTIF
  OCTET aoSpoofMac[6];
  BOOL bMacSpoofChange = FALSE;
#endif

  /* Open a socket */
  if ((iSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    ASSERT(0);
    return -1;
  }

#ifdef NET_MULTIF
  /* Get the number of interfaces */
  ioctl(iSock, SIOCGIFNUM, &oIfNum);
  ASSERT(oIfNum > 0);

  if (_PostGetParam(pp, "WANMACSPOOF", &pchParamValue) == 0) {
    OCTET aoMac[6];
    SetupNetGetMacAddress(aoMac);
    bzero(aoSpoofMac,6);
    _ConvertToMac(aoSpoofMac, pchParamValue);
    if (memcmp(aoMac,aoSpoofMac,6)) {
      bMacSpoofChange = TRUE;
    }
    if (strlen(pchParamValue) == 0) {
      memcpy(aoSpoofMac,aoMac,6);
    }
  }
#endif

  /*
   * Interface reconfiguration
   */
  for (oIfIdx=0; oIfIdx<oIfNum; oIfIdx++) {
    int i = 0;
    OCTET oIfFlags = 0;
    BOOL bEnable = FALSE;
    BOOL bDisable = FALSE;
    BOOL bDhcp = TRUE;
    BOOL bCloseToChange = FALSE;
    BOOL bUpdateVlan = FALSE;
    struct ifconf xIfConf;

    xIfReq.ifr_name[0] = oIfIdx;

    /* First, determine current interface status */
    iRv = ioctl(iSock, SIOCGIFIFLAG, &xIfReq);
    ASSERT(iRv == 0);
    oIfFlags = xIfReq.ifr_flags;

    /* Has the interface been enabled/disabled? */
    sprintf(cTmpString,"IF%dENABLED", oIfIdx);
    if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
      if (strcmp(pchParamValue,"YES") == 0) {
        bEnable = TRUE;
      } else {
        bDisable = TRUE;
      }
    }

    /* Has DHCP been requested? */
    sprintf(cTmpString,"IF%dDHCP",oIfIdx);
    if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
      if (!strcmp(pchParamValue,"FIXED")) {
        bDhcp = FALSE;
        xIfReq.ifr_flags = 0;
      } else {
        xIfReq.ifr_flags = IFF_DYNAMIC;
      }
      ioctl(iSock,SIOCSIFIFLAG,&xIfReq);
    }

    if (oIfFlags & IFF_UP) {

      /*
       * Determine if we need to close an interface to
       * reconfigure it. For now, the following modifications
       * require the interface to be closed before changes are
       * made:
       *
       *   Changing the interface type (layer 3 protocol)
       *   Changing the IP address
       *   Changing from static assignment to DHCP or vice-versa
       *   Changing the VPI/VCI of an ATM link
       *   Changing the interface VLAN/Priority settings
       *   Changing interface routing <-> bridging
       *   Changing the PPP Username/Password/AC Name/Service Name
       */

      /* Change interface type? */
#if defined (PPP) || defined (NET_DSL)
      sprintf(cTmpString,"IF%dL3PROT",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFITYPE, &xIfReq);
        if (!strcmp(pchParamValue,"ETH") &&
            xIfReq.ifr_type != IFT_ETHER) bCloseToChange = TRUE;
        else if (!strcmp(pchParamValue,"NULL") &&
                 xIfReq.ifr_type != IFT_NULL) bCloseToChange = TRUE;
        else if (!strcmp(pchParamValue,"PPPOE") &&
                 xIfReq.ifr_type != IFT_PPPOE) bCloseToChange = TRUE;
        else if (!strcmp(pchParamValue,"PPP") &&
                 xIfReq.ifr_type != IFT_PPP) bCloseToChange = TRUE;
      }
#endif

#if defined (PPP)
      sprintf(cTmpString,"IF%dPPP_IDLETO",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIPPPIDLETO,&xIfReq);
        if (atol(pchParamValue) != xIfReq.ifr_value) {
          bCloseToChange = TRUE;
        }
      }

      sprintf(cTmpString,"IF%dPPP_ECHOTO",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIPPPECHOTO,&xIfReq);
        if (atol(pchParamValue) != xIfReq.ifr_value) {
          bCloseToChange = TRUE;
        }
      }

      sprintf(cTmpString,"IF%dPPP_ECHOCOUNT",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIPPPECHOCOUNT,&xIfReq);
        if (atol(pchParamValue) != xIfReq.ifr_value) {
          bCloseToChange = TRUE;
        }
      }

      /* Handle PPPoE specific settings */
      sprintf(cTmpString,"IF%dPPPOE_SRV",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIPPPSRV, oIfIdx, &xIfConf);
        if (!((xIfConf.ifc_len == strlen(pchParamValue)) &&
              (!memcmp(pchParamValue, xIfConf.ifc_buf, xIfConf.ifc_len)))) {
          bCloseToChange = TRUE;
        }
      }
      sprintf(cTmpString,"IF%dPPPOE_AC",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIPPPAC, oIfIdx, &xIfConf);
        if (!((xIfConf.ifc_len == strlen(pchParamValue)) &&
              (!memcmp(pchParamValue, xIfConf.ifc_buf, xIfConf.ifc_len)))) {
          bCloseToChange = TRUE;
        }
      }
      /* Common PPP settings */
      sprintf(cTmpString,"IF%dPPP_USERNAME",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIPPPNAME, oIfIdx, &xIfConf);
        if (!((xIfConf.ifc_len == strlen(pchParamValue)) &&
              (!memcmp(pchParamValue, xIfConf.ifc_buf, xIfConf.ifc_len)))) {
          bCloseToChange = TRUE;
        }
      }
      sprintf(cTmpString,"IF%dPPP_PASSWORD",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIPPPPW, oIfIdx, &xIfConf);
        if (!((xIfConf.ifc_len == strlen(pchParamValue)) &&
              (!memcmp(pchParamValue, xIfConf.ifc_buf, xIfConf.ifc_len)))) {
          bCloseToChange = TRUE;
        }
      }
#endif

      /* Change from DHCP to static, or vice-versa? */
      sprintf(cTmpString,"IF%dDHCP",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (((oIfFlags & IFF_DYNAMIC) > 0) != bDhcp) {
          bCloseToChange = TRUE;
        }
      }

      /* Change IP address? (non-dynamic modes only) */
      sprintf(cTmpString,"IF%dIPADDRESS",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (!bDhcp) {
          ioctl(iSock, SIOCGIFIADDR, &xIfReq);
          if (inet_addr(pchParamValue) !=
              ((struct sockaddr_in *)&(xIfReq.ifr_addr))->sin_addr.s_addr) {
            bCloseToChange = TRUE;
          }
        }
      }

#ifdef NET_DSL
      sprintf(cTmpString,"VC%dVPI",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIATMVPI, &xIfReq);
        if (atol(pchParamValue) != xIfReq.ifr_value) {
          bCloseToChange = TRUE;
        }
      }

      sprintf(cTmpString,"VC%dVCI",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIATMVCI, &xIfReq);
        if (atol(pchParamValue) != xIfReq.ifr_value) {
          bCloseToChange = TRUE;
        }
      }

      sprintf(cTmpString,"VC%dMODE",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIATMMODE, &xIfReq);
        if ((!strcmp(pchParamValue, "VCMUX") &&
             xIfReq.ifr_value != IF_ATM_MODE_VCMUX) ||
            (!strcmp(pchParamValue, "LLCSNAP") &&
             xIfReq.ifr_value != IF_ATM_MODE_LLCSNAP)) {
          bCloseToChange = TRUE;
        }
      }

      sprintf(cTmpString,"VC%dCHANNELMODE",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIATMLATENCY, &xIfReq);
        if ((!strcmp(pchParamValue, "INTERLEAVED") &&
             xIfReq.ifr_value != IF_ATM_LATENCY_INTERLEAVED) ||
            (!strcmp(pchParamValue, "FAST") &&
             xIfReq.ifr_value != IF_ATM_LATENCY_FAST)) {
          bCloseToChange = TRUE;
        }
      }
#endif

#ifdef NET_BR
      sprintf(cTmpString,"IF%dMCAST",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIBRMCASTLIMIT, &xIfReq);
        if (atol(pchParamValue) != xIfReq.ifr_value) {
          bCloseToChange = TRUE;
        }
      }

      sprintf(cTmpString,"IF%dBCAST",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ioctl(iSock, SIOCGIFIBRBCASTLIMIT, &xIfReq);
        if (atol(pchParamValue) != xIfReq.ifr_value) {
          bCloseToChange = TRUE;
        }
      }
#endif

#ifdef NET_MULTIF
      /* Has the MAC spoofing address changed? */
      if (oIfIdx > 0 && bMacSpoofChange) {
        bCloseToChange = TRUE;
      }
#endif
    }

#ifdef NET_MULTIF
    sprintf(cTmpString,"IF%dNETCONF",oIfIdx);
    if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
      BOOL bBridgeEnabled;
      OCTET oBridgedIfs = 0, oRoutedIfs = 0;

      ioctl(iSock, SIOCGIFIBRENABLE, &xIfReq);
      bBridgeEnabled = xIfReq.ifr_value;

      /* Check in config for other set legs except this one
       * DONT check config on this one because it's settings have changed
       * in the post only BUT not in config yet.
       */
      SetupNetCheckIfNetCfg(&oBridgedIfs, &oRoutedIfs, oIfIdx);

      if (!strcmp(pchParamValue,"BRIDGED")){
        if (bEnable) {
          oBridgedIfs ++;
        }
         /* If this has changed since last time, need to close */
        if (TRUE != bBridgeEnabled) {
          bCloseToChange = TRUE;
        }
      }
      else if (!strcmp(pchParamValue,"ROUTED")) {
        if (bEnable) {
          oRoutedIfs ++;
        }

        if (TRUE == bBridgeEnabled) {
          bCloseToChange = TRUE;
        }
      }

      if (oBridgedIfs && oRoutedIfs) {
        xIfReq.ifr_value = TRUE;
      } else {
        xIfReq.ifr_value = FALSE;
      }
      iRv = ioctl(iSock,SIOCIFIBRPPPOE,&xIfReq);
      ASSERT(iRv == 0);
    }
#endif

    /* Change the DHCP client identifier */
    sprintf(cTmpString,"IF%dSTANDARDCLIENTID",oIfIdx);
    if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
      struct ifconf xCompareIfConf;
      char acCID[32];

      xIfConf.ifc_len = 0;
      xIfConf.ifc_buf = NULL;

      if (!strcmp(pchParamValue,"CUSTOM")) {
        /* DHCP custom client id */
        sprintf(cTmpString,"IF%dCICUSTOM",oIfIdx);
        if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
          xIfConf.ifc_len = strlen(pchParamValue);
          xIfConf.ifc_buf = pchParamValue;
        }
      }

      bzero(&xCompareIfConf, sizeof(struct ifconf));
      xCompareIfConf.ifc_buf = &acCID[0];
      xCompareIfConf.ifc_len = 32;
      ioctl(iSock, SIOCGIFICLIENTID, oIfIdx, &xCompareIfConf);
      ASSERT(xCompareIfConf.ifc_len <= 32);

      /* Has the client ID value changed? */
      if ((xCompareIfConf.ifc_len != xIfConf.ifc_len) ||
          (memcmp(xCompareIfConf.ifc_buf, xIfConf.ifc_buf, xIfConf.ifc_len) != 0)) {
        bCloseToChange = TRUE;
      }

      ioctl(iSock, SIOCSIFICLIENTID, oIfIdx, &xIfConf);
    }


    /* Change VLAN settings?
     * IMPORTANT NOTE: This assumes both VLAN ID and Priority values will be
     *                 posted together! */
    sprintf(cTmpString,"IF%dVLANTAG",oIfIdx);
    if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
      ConfigSetParam(cTmpString, pchParamValue);

      sprintf(cTmpString,"IF%dPRIORITYTAG",oIfIdx);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        ConfigSetParam(cTmpString, pchParamValue);
      }

      ioctl(iSock, SIOCGIFIVLAN, &xIfReq);

      if (_ComputeVlanValue(oIfIdx) != xIfReq.ifr_value) {
        bCloseToChange = TRUE;
        bUpdateVlan = TRUE;
      }
    }


    /* Close the interface if required */
    if (bDisable == TRUE || bCloseToChange == TRUE) {
      /* Close the interface, if it is open */
      if (oIfFlags & IFF_UP) {
        _SetNetIfParameter(iSock, oIfIdx, SIOCIFICLOSE, NULL);
        _WaitForInterfaceToClose(iSock, oIfIdx);
      }
    }

    i=0;
    while (pxIfVarIoctlTableSet[i].pcVarName != NULL) {
      DWORD dwIoctlCode = pxIfVarIoctlTableSet[i].dwIoctlCode;

      sprintf(cTmpString,"IF%d%s", oIfIdx, pxIfVarIoctlTableSet[i].pcVarName);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {

        if (dwIoctlCode == SIOCSIFIADDR ||
            dwIoctlCode == SIOCSIFINETMASK ||
            dwIoctlCode == SIOCSIFIGWADDR ||
            dwIoctlCode == SIOCSIFIDNS ||
            dwIoctlCode == SIOCSIFIDN ||
            dwIoctlCode == SIOCSIFIHN) {
          if (bDhcp) {
            if (bCloseToChange || !(oIfFlags & IFF_UP)) {
              if (dwIoctlCode == SIOCSIFIADDR ||
                  dwIoctlCode == SIOCSIFINETMASK ||
                  dwIoctlCode == SIOCSIFIGWADDR) {
                /* Clear away original values - DHCP client will set new ones */
                _SetNetIfParameter(iSock, oIfIdx, dwIoctlCode, "0.0.0.0");
              } else {
                _SetNetIfParameter(iSock, oIfIdx, dwIoctlCode, pchParamValue);
              }
            }
          } else {
            _SetNetIfParameter(iSock, oIfIdx, dwIoctlCode, pchParamValue);
          }
        } else {
          _SetNetIfParameter(iSock, oIfIdx, dwIoctlCode, pchParamValue);
        }
      }

      i++;
    }

#ifdef NET_DSL
    i=0;
    while (pxAtmIfVarIoctlTableSet[i].pcVarName != NULL) {
      DWORD dwIoctlCode = pxAtmIfVarIoctlTableSet[i].dwIoctlCode;

      sprintf(cTmpString,"VC%d%s", oIfIdx, pxAtmIfVarIoctlTableSet[i].pcVarName);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        _SetNetIfParameter(iSock, oIfIdx,
                           dwIoctlCode, pchParamValue);
      }

      i++;
    }
#endif

    if (bUpdateVlan) {
      sprintf(cTmpString, "%d", _ComputeVlanValue(oIfIdx));
      _SetNetIfParameter(iSock, oIfIdx, SIOCSIFIVLAN, cTmpString);
    }

#ifdef NET_MULTIF
    /* Update MAC spoofing address on WAN interfaces (if changed) */
    if (oIfIdx > 0 && bMacSpoofChange) {
      /* WAN interfaces inherit 'spoofed' MAC address */
      memcpy(((struct sockaddr_dl *)&(xIfReq.ifr_addr))->sdl_data,
             &aoSpoofMac[0], 6);
      ((struct sockaddr_dl *)&(xIfReq.ifr_addr))->sdl_alen = 6;
      xIfReq.ifr_addr.sa_len = sizeof(struct sockaddr_dl);
      ioctl(iSock,SIOCSIFIDLADDR,&xIfReq);
    }
#endif

    /* Disable the interface if requested to
     * This will free up all the resources and clear all internal values */
    if (bDisable) {
      ioctl(iSock,SIOCIFIDISABLE,&xIfReq);
    }

    /*
     * Open the interface if
     *   - it was closed before and has now been opened
     *   - we closed it to reconfigure it
     */
    if ((bEnable == TRUE &&
         (!(oIfFlags & IFF_UP) || (bCloseToChange == TRUE))) ||
        (bEnable == FALSE && bDisable == FALSE && bCloseToChange == TRUE)) {
      _SetNetIfParameter(iSock, oIfIdx, SIOCIFIOPEN, NULL);
    }

#ifdef PPP
    /*
     * PPP 'CONNECT' / 'DISCONNECT' actions ("CONNection ACTION")
     */
    sprintf(cTmpString,"CONNACTION");
    if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
      ioctl(iSock, SIOCGIFIFLAG, &xIfReq);
      oIfFlags = xIfReq.ifr_flags;

      sprintf(cTmpString, "CONNECT%d",oIfIdx);
      if (!strcmp(pchParamValue, cTmpString)) {
        /* Open the interface */
        if (!(oIfFlags & IFF_UP)) {
          _SetNetIfParameter(iSock, oIfIdx, SIOCIFICLOSE, NULL);
          _WaitForInterfaceToClose(iSock, oIfIdx);
          _SetNetIfParameter(iSock, oIfIdx, SIOCIFIOPEN, NULL);
        }
      }

      sprintf(cTmpString, "DISCONNECT%d",oIfIdx);
      if (!strcmp(pchParamValue, cTmpString)) {
        /* Close the interface */
        if (oIfFlags & IFF_UP) {
          _SetNetIfParameter(iSock, oIfIdx, SIOCIFICLOSE, NULL);
          _WaitForInterfaceToClose(iSock, oIfIdx);
        }
      }
    }
#endif

  }


#ifdef NAT
  /*
   * NAT Port Forwarding Configuration
   *   IMPORTANT!!! This callback processing assumes that ALL OF THE NAT PORT
   *                FORWARDING ENTRIES AND VARIABLES WILL BE POSTED TOGETHER
   *                (i.e. are on the same web page!!)
   *
   *   Look for PORTFWDMIN1 (will tell us if it's the NAT port forwarding page)
   */
  if (_PostGetParam(pp, "PORTFWDMIN1", &pchParamValue) == 0) {
    int j;

    for (j=1; j<=8; j++) {
      struct nat_portfwd_lan xNat;
      BOOL bNullifyEntry = FALSE;

      bzero(&xNat, sizeof(struct nat_portfwd_lan));

      sprintf(cTmpString, "PORTFWDMIN%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (strcmp(pchParamValue,"")) xNat.wPortBeg = atol(pchParamValue);
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "PORTFWDMAX%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (strcmp(pchParamValue,"")) xNat.wPortEnd = atol(pchParamValue);
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "PORTFWDIP%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (strcmp(pchParamValue,"")) xNat.dwIp = atol(pchParamValue);
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "PORTFWDPROT%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (!strcmp(pchParamValue, "UDP")) {
          xNat.wFlags |= NAT_PORT_FORWARD_PROT_UDP;
        } else if (!strcmp(pchParamValue, "TCP")) {
          xNat.wFlags |= NAT_PORT_FORWARD_PROT_TCP;
        } else if (!strcmp(pchParamValue, "BOTH")) {
          xNat.wFlags |= NAT_PORT_FORWARD_PROT_BOTH;
        } else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      xNat.bNullifyEntry = bNullifyEntry;
      xNat.dwIndex = j-1;

      ioctl(iSock, SIOCNATREGFWDWAN2LAN, &xNat);
    }
  }

#endif /*#ifdef NAT*/


#ifdef ROUTER
  /*
   * Dynamic Routing
   */
  if ((_PostGetParam(pp, "ROUTERX", &pchParamValue) == 0) ||
      (_PostGetParam(pp, "ROUTETX", &pchParamValue) == 0)) {
    RIPConfig();
  }

  /*
   * Static Routing Configuration
   *   IMPORTANT!!! This callback processing assumes that ALL OF THE STATIC
   *                ROUTE ENTRIES AND VARIABLES WILL BE POSTED TOGETHER
   *                (i.e. are on the same web page!!)
   *
   *   Look for ROUTEDESTIP1 (will tell us if it's the static route page)
   */
  if (_PostGetParam(pp, "ROUTEDESTIP1", &pchParamValue) == 0) {
    int j;

    for (j=1; j<=8; j++) {
      struct rtentry xRt;
      int bNullifyEntry = FALSE;

      sprintf(cTmpString, "ROUTEDESTIP%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (strcmp(pchParamValue,"")) {
          ((struct sockaddr_in *)&(xRt.rt_dst))->sin_addr.s_addr = inet_addr(pchParamValue);
        }
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "ROUTESUBNETMASK%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (strcmp(pchParamValue,"")) {
          ((struct sockaddr_in *)&(xRt.rt_genmask))->sin_addr.s_addr = inet_addr(pchParamValue);
        }
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "ROUTEGATEWAYIP%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (strcmp(pchParamValue,"")) {
          ((struct sockaddr_in *)&(xRt.rt_gateway))->sin_addr.s_addr = inet_addr(pchParamValue);
        }
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "ROUTEMETRIC%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (strcmp(pchParamValue,"")) {
          xRt.rt_metric = atol(pchParamValue);
        }
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "ROUTEINT%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        int k;
        for (k=0; k<oIfNum; k++) {
          sprintf(cTmpString, "IF%d", k);
          if (!strcmp(pchParamValue, cTmpString)) {
            xRt.rt_ifindex = k;
            break;
          }
        }

        if (k==oIfNum) bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      ioctl(iSock, SIOCRTABLESETSTATICRT, j-1, bNullifyEntry, &xRt);
    }
  }

  /*
   * Address Filtering Configuration
   *   IMPORTANT!!! This callback processing assumes that ALL OF THE FILTERING
   *                ENTRIES AND VARIABLES WILL BE POSTED TOGETHER
   *                (i.e. are on the same web page!!)
   *
   *   Look for FILTADDR1 (will tell us if it's the filtering page)
   */
  if (_PostGetParam(pp, "FILTADDR1", &pchParamValue) == 0) {
    int j;

    for (j=1; j<=30; j++) {
      ROUTERCFG_IPFILTERING xFilter;
      BOOL bNullifyEntry = FALSE;

      bzero(&xFilter, sizeof(ROUTERCFG_IPFILTERING));

      sprintf(cTmpString, "FILTADDR%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (strcmp(pchParamValue,"")) xFilter.dwIp = atol(pchParamValue);
        else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      sprintf(cTmpString, "FILTPROT%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        if (!strcmp(pchParamValue, "UDP")) {
          xFilter.wFlags |= IP_FILTERING_PROT_UDP;
        } else if (!strcmp(pchParamValue, "TCP")) {
          xFilter.wFlags |= IP_FILTERING_PROT_TCP;
        } else if (!strcmp(pchParamValue, "BOTH")) {
          xFilter.wFlags |= IP_FILTERING_PROT_BOTH;
        } else bNullifyEntry = TRUE;
      }
      else bNullifyEntry = TRUE;

      xFilter.bNullifyEntry = bNullifyEntry;
      xFilter.dwIndex = j-1;

      ioctl(iSock, SIOCIPFILTERINGCFG, &xFilter);
    }
  }
#endif /*ifdef ROUTER*/


#ifdef IPSEC
  {
    int j;
    for (j=1;j<=8;j++) {
      sprintf(cTmpString, "POLICY%d", j);
      if (_PostGetParam(pp, cTmpString, &pchParamValue) == 0) {
        /* Reconfigure IPSec settings */
        SetupNetIPSec();
        break;
      }
    }
  }
#endif /*ifdef IPSEC*/

  close(iSock);

  return 1;
}

#endif /* JJ */
