/*
 * tcpquery.c
 *
 * TCP module query
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Include
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "tcp_flavor.h"
#include "dllist.h"
#include "../include/in.h"
#include "../include/socket.h"
#include "ecc.h"
#include "macros.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"
#include "iptable.h"
#include "routing_table.h"
#include "nettransport.h"
#include "netnetwork.h"
#include "netsnmp.h"
#include "snmp_tcpip_data.h"
#include "tcp.h"
#include "tcpdefs.h"
#include "tcp_dbg.h"

/*
 * TcpInstanceQuery
 *  Query a TCP Instance Option
 *
 *  Args:
 *   hTcp                       TCP instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG TcpInstanceQuery(H_NETINSTANCE hTcp,OCTET oOption,
                      H_NETDATA *phData)
{
  TCPSTATE *pxTcp = (TCPSTATE *)hTcp;
  LONG lReturn = NETERR_NOERR;

  ASSERT(oOption < TCPOPTION_MAX);

  if (oOption < TCPOPTION_NAGLE) {
    /* All options are WORD-wide, and are stored in the enum order */
    *phData = (H_NETDATA) *((WORD *)((&pxTcp->wOffset) + oOption));
  }
  else if (oOption < TCPOPTION_MAX) {
    *phData = (H_NETDATA) FALSE;
  }
  else {
    lReturn = NETERR_UNKNOWN;
  }

  return lReturn;
}

