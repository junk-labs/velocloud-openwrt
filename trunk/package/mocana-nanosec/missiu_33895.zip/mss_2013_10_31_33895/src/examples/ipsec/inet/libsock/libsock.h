#ifndef __LIBSOCK_H__
#define __LIBSOCK_H__


#define LIBSOCK_CODE_CMD      0

typedef enum libsockcmd 
{
    MN_SOCKET = 0,
    MN_SOCKET_REPLY ,
    MN_BIND ,
    MN_BIND_REPLY ,
    MN_LISTEN ,
    MN_LISTEN_REPLY ,
    MN_CLOSE ,
    MN_IOCTL ,
    MN_SEND ,
    MN_SEND_REPLY ,
    MN_SENDTO ,
    MN_SENDTO_REPLY ,
    MN_GETSOCKOPT ,
    MN_GETSOCKOPT_REPLY ,
    MN_READ ,
    MN_RECV ,
    MN_RECV_REPLY ,
    MN_RECVFROM ,
    MN_RECVFROM_REPLY ,
    MN_ACCEPT ,
    MN_ACCEPT_REPLY ,
    MN_SELECT ,
    MN_SELECT_REPLY ,
    MN_CONNECT ,
    MN_CONNECT_REPLY ,
    MN_GETHOSTBYNAME ,
    MN_GETPEERBYNAME ,
    MN_GETSOCKNAME ,
    MN_SHUTDOWN ,
    MN_SHUTDOWN_REPLY ,
    MN_PLAIN_REPLY ,

} libSockCmd;


struct timeval
  {
    long int tv_sec;            /* Seconds.  */
    long int tv_usec;      /* Microseconds.  */
  }; 

typedef struct socketcmd
{
    sbyte4 family;
    sbyte4 type;
    sbyte4 protocol;
} socketCmd;

typedef struct socketcmdreply
{
    sbyte4 sockfd;
} socketCmdReply;

typedef struct listencmd
{
    ubyte4 sockfd;
    ubyte4 backlog;
} listenCmd;

typedef struct bindcmd
{
    ubyte4 sockfd;
    struct sockaddr_in  sockAddr;
    ubyte4 szSockAddr;
} bindCmd;

typedef struct connectcmd
{
    ubyte4 sockfd;
    struct sockaddr_in  sockAddr;
    ubyte4 szSockAddr;
} connectCmd;

typedef struct sendcmd
{
    ubyte4 sockfd;
    ubyte4 bufSize;
    sbyte4 flags;
    ubyte buff[0];
} sendCmd;

typedef struct recvcmd
{
    ubyte4 sockfd;
    ubyte4 bufSize;
    sbyte4 flags;
    ubyte buff[0];
} recvCmd;

typedef struct sendtocmd
{
    ubyte4 sockfd;
    ubyte4 bufSize;
    sbyte4 flags;
    struct sockaddr_in  sockAddr;
    ubyte4 szSockAddr;
    ubyte buff[0];
} sendtoCmd;

typedef struct recvfromcmd
{
    ubyte4 sockfd;
    ubyte4 bufSize;
    sbyte4 flags;
    struct sockaddr_in  sockAddr;
    ubyte4 szSockAddr;
    ubyte buff[0];
} recvfromCmd;

typedef struct getsockoptcmd
{
    ubyte4 sockfd;
    sbyte4 level;
    sbyte4 optname;
    ubyte4 optlen;
    ubyte buff[0];
} getsockoptCmd;

typedef struct acceptcmd
{
    ubyte4 sockfd;
    struct sockaddr_in  sockAddr;
    ubyte4 szSockAddr;
} acceptCmd;

typedef struct acceptreplycmd
{
    ubyte4 childfd;
    struct sockaddr_in  sockAddr;
    ubyte4 addrLen;
} acceptreplyCmd;

#define READ_SET_SET   0x1
#define WRITE_SET_SET  0x2
#define EXCEPT_SET_SET 0x4
#define TIMEVAL_SET    0x8

typedef struct selectcmd
{
    sbyte4 maxSet;
    ubyte  setMask;
    fd_set read_set;
    fd_set write_set;
    fd_set except_set;
    struct timeval timeVal;
} selectCmd;

typedef struct selectreplycmd
{
    sbyte4 numSet;
    ubyte  setMask;
    fd_set read_set;
    fd_set write_set;
    fd_set except_set;
} selectreplyCmd;

typedef struct shutdowncmd
{
    ubyte4 sockfd;
    ubyte4 howto;
} shutdownCmd;

/* Message Sent between Lib sock Client and Server */

typedef struct sockmsg
{
    libSockCmd libsockcmd;
    MSTATUS    errno;
    union
    {
        socketCmd          socketcmd;
        socketCmdReply     socketcmdreply;
        listenCmd          listencmd;
        bindCmd            bindcmd;
        connectCmd         connectcmd;
        sendCmd            sendcmd;
        sendtoCmd          sendtocmd;
        getsockoptCmd      getsockoptcmd;
        acceptCmd          acceptcmd;
        acceptreplyCmd     acceptreplycmd;
        recvfromCmd        recvfromcmd;
        recvCmd            recvcmd;
        selectCmd          selectcmd;
        selectreplyCmd     selectreplycmd;
        shutdownCmd        shutdowncmd;
    } msg;

} sockMsg_t; 


#endif /* __LIBSOCK_H__*/
