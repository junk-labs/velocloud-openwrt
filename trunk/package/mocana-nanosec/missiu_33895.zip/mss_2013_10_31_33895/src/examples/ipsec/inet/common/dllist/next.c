#include "NNstyle.h"
#include "dllist.h"
#include "../misccommon.h"
#include "dllcommon.h"

void DLLIST_next(DLLIST *dllist)
{
  if (dllist->cur != NULL) dllist->cur = dllist->cur->next;
}

