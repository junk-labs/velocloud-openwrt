/*
 * dbg.h
 *
 * debug macros, see sdev/src/misc/doc/dbg.api for details
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef __DBG_H__
#define __DBG_H__

#include "NNstyle.h"


/********************************************************************
 *
 * enum name maps and DBG_MARK are available for DEBUG or NDEBUG
 *
 ********************************************************************/


/*
 * typdef defining an enum name map
 *
 * NOTE: use of this and the FILL_ENUM_NAME_MAP macro calls must be
 *     surrounded by #ifndef NDEBUG
 */
typedef struct {
  char *szName;
  DWORD dwLen;
} ENUM_NAME_MAP;



/*
 * macro to fill in an enum name map
 *
 * NOTE: use of this and the ENUM_NAME_MAP declarations must be
 *     surrounded by #ifndef NDEBUG
 */
#define FILL_ENUM_NAME_MAP(e, map) do {                    \
      map[e].szName = #e;                        \
      map[e].dwLen = strlen(#e);                    \
    } while (0)



/*
 * Save the current line # in dbg_nMarkLine, this macro helps in
 * locating a piece of code in the .dmp file. Locating code in the
 * .dmp file is needed when chasing compiler or code trashing bugs
 * to compare the C code with the resulting executable or to compare
 * the unassembled runtime code with the virgin executable.
 *
 * Proceedure:
 * 1. place this macro near the suspect C code in the src
 * 2. do a make and edit the resulting .dmp file (in same directory
 *     as the executable
 * 3. search for dbg_nMarkLine in the symbol table and get its addr
 * 4. search for the ASM statement that references that addr
 * 5a. for compiler bugs, you are now in the region of the suspected
 *      problem so compare the C code with the resulting ASM
 * 5b. for code trashing, you are now in the region of the suspected
 *      code so unassemble the suspected code at runtime using the
 *      VCPI "u" cmd and compare it with the ASM from the .dmp file.
 *
 * NOTE: This macro looses effectiveness if it is used more than
 * a couple of times in an executable because it becomes harder to
 * match the DBG_MACRO invocation with the resulting dbg_nMarkLine
 * references in the .dmp file. Thus I recommend removing the invocation
 * as soon as you are done tracking down a particular problem.
 *
 * parms: none
 */
MOC_EXTERN int dbg_nMarkLine;
#define DBG_MARK do {                            \
      dbg_nMarkLine = __LINE__;                    \
    } while (0)



/*
 * Various flavors of ASSERT
 */

#if defined(NDEBUG)

#  include <assert.h>

# if defined(NDEBUG_ASSERT_ALIGNEXC)
#   define ASSERT(p) assert(p)
# else
#   define ASSERT(p)
# endif
#else /* if defined(NDEBUG) */

#if 0
#  include <assert.h>
#endif /* TBD */

#    if !defined(ASSERT_EXTENSION)
#      define ASSERT_EXTENSION(p)
#    endif

#    if !defined(ASSERT_REPORT)
#      define ASSERT_REPORT(p) do                    \
          {                                \
        printf("ASSERT (" #p ") failed\n");            \
        printf("  at line %d in file %s\n", __LINE__, __FILE__);\
          } while (0)
#    endif

#    if defined(ASSERT_CRASH_ISR)
#      include "vcpdefs.h"
#      define CRASH_ISR do {                        \
        register temp;                        \
        temp = PSW_DISABLE_IRQ;                    \
        asm volatile("movtos %0,psw" :  :"r" (temp) );        \
        WAIT2;                            \
      } while (1)
#    else /* if defined(ASSERT_CRASH_ISR) */
#      define CRASH_ISR
#    endif /* if defined(ASSERT_CRASH_ISR) else */

#if 0
#    define ASSERT(p) do                        \
          {                                \
        if (!(p)) {                        \
          ASSERT_EXTENSION(p);                    \
          CRASH_ISR;                        \
          assert(p);                        \
        }                            \
          } while (0)
#else

/*removed assert(p) */

#    define ASSERT(p) do                        \
          {                                \
        if (!(p)) {                        \
          ASSERT_EXTENSION(p);                    \
          CRASH_ISR;                        \
        }                            \
          } while (0)
#endif

#endif /* if defined(NDEBUG) else */




#if defined(NDEBUG) && !defined(NDEBUG_DBG)

/*
 * no DBG
 */
#define DBG_CHKPT
#define DBG_PAUSE
#define DEBUG(x)
#define DEBUG_VAR(x)
#define DBG_CHK_DWTAG(t, dwt)


/*
 * use the ISO C 9x extensions allowing variable # parms for macros
 * (if the compiler does not support these extensions then all
 * DBG_(F)PRINTF() calls must be changed to DBG(F)PRINTFn()
 * and the section below which defines them restored)
 *
 * Note: NO_MACRO_VARARG allows applications to still use the vararg
 *       versions as long as the functions dbg_{printf,fprintf} are
 *       implemented.
 */
#ifndef NO_MACRO_VARARG
#define DBG_PRINTF(fmt, args...)
#define DBG_FPRINTF(fp, fmt, args...)
#else
#define DBG_PRINTF dbg_printf
#define DBG_FPRINTF dbg_fprintf
#endif

/* NOTE: if the fmt string has comma in it, then the string MUST    */
/*   be enclosed in parens, e.g. DBG_PRINTF(("look, %d dogs!"), nDogs);    */
#if 0
#define DBG_PRINTF(fmt)
#define DBG_FPRINTF(fp, fmt)
#endif
#define DBG_PRINTF1(fmt, a1)
#define DBG_FPRINTF1(fp, fmt, a1)
#define DBG_PRINTF2(fmt, a1, a2)
#define DBG_FPRINTF2(fp, fmt, a1, a2)
#define DBG_PRINTF3(fmt, a1, a2, a3)
#define DBG_FPRINTF3(fp, fmt, a1, a2, a3)
#define DBG_PRINTF4(fmt, a1, a2, a3, a4)
#define DBG_FPRINTF4(fp, fmt, a1, a2, a3, a4)




#else /* if defined(NDEBUG) && !defined(NDEBUG_DBG) */


/*
 * DBG enabled
 */
#if 0

/*MK: Comments this out */
#include <string.h>
#include <stdarg.h>
#endif

/********************************************************************
 *
 * Includes
 *
 ********************************************************************/

#include "NNstyle.h"
/*MK: Comments this out */
#if 0
#include <string.h>
#include <stdio.h>
#endif

#define HOST_TASK()

/********************************************************************
 *
 * Constants
 *
 ********************************************************************/

/* none */


/********************************************************************
 *
 * Macros
 *
 ********************************************************************/

#define DEBUG(x) do {x;} while (0)
#define DEBUG_VAR(x) x


#define DBG_CHKPT do {                            \
      dbg_nChkPtLine = __LINE__;                    \
      dbg_pChkPtFile = __FILE__;                    \
    } while (0)


#define DBG_PAUSE do {                            \
      dbg_nPauseLine = __LINE__;                    \
      dbg_pPauseFile = __FILE__;                    \
      if (dbg_bPausePrint)                        \
        printf("DBG_PAUSE: line %d in %s\n",            \
           dbg_nPauseLine, dbg_pPauseFile);            \
      if (dbg_bPauseHold) {                        \
        dbg_bPausing = TRUE;                    \
        while (0 == dbg_nPauseGo) HOST_TASK();            \
      }                                \
      dbg_bPausing = FALSE;                        \
      if (dbg_nPauseGo > 0) dbg_nPauseGo--;                \
    } while (0)

/*
 * use the ISO C 9x extensions allowing variable # parms for macros
 * (if the compiler does not support these extensions then all
 * DBG_(F)PRINTF() calls must be changed to DBG(F)PRINTFn()
 * and the section below which defines them restored)
 *
 * Note: NO_MACRO_VARARG allows applications to still use the vararg
 *       versions as long as the functions dbg_{printf,fprintf} are
 *       implemented.
 */
#ifndef NO_MACRO_VARARG
#if defined (__VXWORKS_RTOS__)
#define DBG_PRINTF
#define DBG_FPRINTF
#else
#define DBG_PRINTF(fmt, args...) printf(fmt, ## args)
#define DBG_FPRINTF(fp, fmt, args...) fprintf(fp, fmt, ## args)
#endif
#else
#define DBG_PRINTF dbg_printf
#define DBG_FPRINTF dbg_fprintf
#endif


/* NOTE: if the fmt string has comma in it, then the string MUST    */
/*   be enclosed in parens, e.g. DBG_PRINTF(("look, %d dogs!"), nDogs);    */
#if 0
#define DBG_PRINTF(fmt) printf(fmt)
#define DBG_FPRINTF(fp, fmt) fprintf(fp, fmt)
#endif
#define DBG_PRINTF1(fmt, a1) printf(fmt, a1)
#define DBG_FPRINTF1(fp, fmt, a1) fprintf(fp, fmt, a1)
#define DBG_PRINTF2(fmt, a1, a2) printf(fmt, a1, a2)
#define DBG_FPRINTF2(fp, fmt, a1, a2) fprintf(fp, fmt, a1, a2)
#define DBG_PRINTF3(fmt, a1, a2, a3) printf(fmt, a1, a2, a3)
#define DBG_FPRINTF3(fp, fmt, a1, a2, a3) fprintf(fp, fmt, a1, a2, a3)
#define DBG_PRINTF4(fmt, a1, a2, a3, a4) printf(fmt, a1, a2, a3, a4)
#define DBG_FPRINTF4(fp, fmt, a1, a2, a3, a4) fprintf(fp, fmt, a1, a2, a3, a4)


/*
 * check a DWORD tag without dereferencing the tag field as a DWORD,
 * this way if the tag field is NOT DWORD aligned we will
 * hit an assert (assuming the struct pointer is bad, thus
 * the tag data will be wrong as well as misaligned) rather
 * than crashing.
 */
#define DBG_CHK_DWTAG(t, dwt) do {                    \
      OCTET *poTag;                            \
      DWORD dwEndianTest = 1;                    \
      poTag = (OCTET *) &(dwEndianTest);                \
      if (1 == *poTag) {                        \
        poTag = (OCTET *) &(dwt);                    \
        ASSERT((((t) >>  0) & 0xFF) == *(poTag + 0));        \
        ASSERT((((t) >>  8) & 0xFF) == *(poTag + 1));        \
        ASSERT((((t) >> 16) & 0xFF) == *(poTag + 2));        \
        ASSERT((((t) >> 24) & 0xFF) == *(poTag + 3));        \
      } else {                            \
        ASSERT(1 == *(poTag + 3));                    \
        poTag = (OCTET *) &(dwt);                    \
        ASSERT((((t) >>  0) & 0xFF) == *(poTag + 3));        \
        ASSERT((((t) >>  8) & 0xFF) == *(poTag + 2));        \
        ASSERT((((t) >> 16) & 0xFF) == *(poTag + 1));        \
        ASSERT((((t) >> 24) & 0xFF) == *(poTag + 0));        \
      }                                \
    } while (0)



/********************************************************************
 *
 * Global Variables
 *
 ********************************************************************/

MOC_EXTERN int   dbg_nChkPtLine;
MOC_EXTERN char  *dbg_pChkPtFile;
MOC_EXTERN int   dbg_nPauseLine;
MOC_EXTERN char  *dbg_pPauseFile;
MOC_EXTERN int   dbg_bPausePrint;
MOC_EXTERN int   dbg_bPauseHold;
MOC_EXTERN volatile int   dbg_nPauseGo;
MOC_EXTERN int   dbg_bPausing;



/********************************************************************
 *
 * Functional API
 *
 ********************************************************************/

/* none */

#define INET_DBG_LEVEL_SET(module, level)\
    do { int id;g_aInetModDbg[module]=0;g_aInetModDbgDflt[module]=0;\
        for(id=level; id>=0 ; id--) \
                { g_aInetModDbg[module] |= 1 << id; g_aInetModDbgDflt[module] |= 1 << id;}\
    }while(0)

#define INET_DBG_CLI_LEVEL_SET(module, level)\
    do { int id;g_aInetModDbg[module]=0;\
        for(id=level; id>=0 ; id--) g_aInetModDbg[module] |= 1 << id;\
    }while(0)

#define INET_DBG_IS_LEVEL_SET(module, level) \
    ((g_aInetModDbg[module] & (1 << level))? 1 : 0)

#define INET_DBG_LEVEL_DEFAULT(module) \
    g_aInetModDbg[module]=g_aInetModDbgDflt[module]

/*
 * Debug Module indexes
 */
#define INET_DBG_LEVEL_NONE 0 /* bit 0 */
#define INET_DBG_LEVEL_ERROR 1/* bit 1 */
#define INET_DBG_LEVEL_NORMAL 2 /* bit 2 */
#define INET_DBG_LEVEL_REPETITIVE 3 /* bit 3 */
#define INET_DBG_LEVEL_DETAIL 4 /* bit 4 */

#define INET_DBG_LEVEL_MAX 5 /* Max 16 levels */

enum _inet_dbg_module
{
    INET_DBG_MOD_UDP = 0,
    INET_DBG_MOD_TCP,
    INET_DBG_MOD_ICMP,
    INET_DBG_MOD_IGMP,
    INET_DBG_MOD_IP,
    INET_DBG_MOD_ETH,
    INET_DBG_MOD_ARP,
    INET_DBG_MOD_IP2ETH,
    INET_DBG_MOD_IP1TON,
    INET_DBG_MOD_ROUTER,
    INET_DBG_MOD_NAT,
    INET_DBG_MOD_IPSEC,
    INET_DBG_MOD_IPFRAG,
    INET_DBG_MOD_IPTABLE,
    INET_DBG_MOD_PPP,
    INET_DBG_MOD_PPPCP,
    INET_DBG_MOD_IPCP,
    INET_DBG_MOD_CHAP,
    INET_DBG_MOD_DNS,
    INET_DBG_MOD_SOCKET,
    INET_DBG_MOD_ROUTINGTABLE,
    INET_DBG_MOD_NETMAIN,
    INET_DBG_MOD_METER,

    INET_DBG_MOD_MAX
};

MOC_EXTERN ubyte2 g_aInetModDbg[INET_DBG_MOD_MAX];
MOC_EXTERN ubyte2 g_aInetModDbgDflt[INET_DBG_MOD_MAX];
MOC_EXTERN ubyte *g_aInetModDbgStr[INET_DBG_MOD_MAX];
MOC_EXTERN ubyte *g_aInetLevelDbgStr[INET_DBG_LEVEL_MAX];

#endif /* ifdef NDEBUG else */


#endif    /* __DBG_H__ */



