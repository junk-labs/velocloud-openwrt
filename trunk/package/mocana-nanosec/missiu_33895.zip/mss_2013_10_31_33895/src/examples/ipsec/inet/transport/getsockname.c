/*
 * getsockname.c
 *
 * implement the getsockname function
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/****************************************************************************
 *
 * Includes
 *
 ****************************************************************************/

#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "../include/in.h"
#include "mqueue.h"
#include "dllist.h"
#include "../include/ioctl.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "iptable.h"
#include "nettransport.h"
#include "udp.h"
#include "tcp.h"
#include "netnetwork.h"
#include "ip.h"
#include "igmp.h"
#include "netdefs.h"
#include "netutils.h"
#include "sockapi.h"
#include "sockdefs.h"
#include "sockdbg.h"
#include "ethernet.h"


/****************************************************************************
 *
 * API functions
 *
 ****************************************************************************/
/*
 * getsockname
 *  Gets local protocol address associated with a socket
 *
 *  Args:
 *   lsockfd                       The socket returned by the socket function.
 *   localaddr                     Pointer to structure into which the local
 *                                 address information is stored.
 *   addrlen                       On return, pointer to the length of the
 *                                 structure 'localaddr' points to.
 *
 *  Return:
 *   0 : Success.
 *   -1: Error
 */
int
mn_getsockname(int lSockfd, struct sockaddr *localaddr, socklen_t *addrlen)
{
  SOCKET *pxSock;
  struct sockaddr_in *localaddr_in=NULL;

#ifdef STRICT_POSIX
  if(localaddr == 0 || addrlen == 0) {
    mn_errno = EFAULT;
    return -1;
  }
#else
  ASSERT((localaddr != 0) && (addrlen != 0));
#endif

  SOCKET_CHECKFD(lSockfd);

  RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
  if ((pxSock = RETRIEVE_SOCKET(lSockfd)) == NULL) {
    mn_errno = MO_EBADF;
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    return -1;
  }

  localaddr_in = (struct sockaddr_in *) localaddr;

  localaddr_in->sin_family = pxSock->lFamily;

  {
    OCTET oProt;
    H_NETINSTANCE hInst;
    PFN_NETIOCTL pfnIoctl;

    oProt = SOCKTYPE2PROTINDEX(pxSock->lType);
    hInst = xSocketRep.axProtocols[oProt].hInst;
    pfnIoctl = xSocketRep.axProtocols[oProt].pfnIoctl;

    pfnIoctl(hInst,pxSock->hLL,
             NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALIP,
             (H_NETDATA) (&localaddr_in->sin_addr.s_addr));
    pfnIoctl(hInst,pxSock->hLL,
             NETTRANSPORTULINTERFACEIOCTL_QUERYLOCALPORT,
             (H_NETDATA) (&localaddr_in->sin_port));
  }
  *addrlen = sizeof(struct sockaddr_in);

  RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));

  return 0;
}
