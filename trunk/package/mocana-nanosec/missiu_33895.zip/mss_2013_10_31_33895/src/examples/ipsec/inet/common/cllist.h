/*
 * cllist.h
 *
 * Implements circular linked lists in MACROs
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*
 * File:    cllist.h
 *
 * Description:
 *  Implements circular linked lists in MACROs.
 *
 *  The CLL operations are:
 *
 *    CLLIST(t) lst;                 declare lst as a CLL of type t
 *    CllClear(lst);             initialize CLL to empty
 *  * CllInsertPostAnchor(lst, pe)   insert element *p after the anchor
 *    CllInsertPreAnchor(lst, pe)    insert element *p before the anchor
 *  * CllInsertPostCurr(lst, pe)     insert element *p after the current
 *  * CllInsertPreCurr(lst, pe)      insert element *p before the current
 *    pe = CllGetAnchor(lst)         get pointer to anchor element in CLL
 *    pe = CllGetCurr(lst)           get pointer to current element in CLL
 *    CllSetCurr(lst, pe)            set pointer to current element in CLL
 *  * CllSetAnchorToCurr(lst)        set the anchor to the current element
 *  * CllSetCurrToAnchor(lst)        set the current to the anchor element
 *    CllNext(lst)                   move current to the next element
 *    CllPrev(lst)                   move current to the previous element
 *    CllDel(lst)                    delete current and advance to next
 *    CllFind(lst, pe)               make element with addr p the current
 *    b = CllWasFound(lst)           TRUE if find succeeded, else FALSE
 *    dw = CllGetCount(lst)          get the # elements in the CLL
 *
 *  * NOTE: not yet implemented
 *
 *  (pe == NULL) after CllGetCurr() or CllGetAnchor()
 *  implies the CLL was empty.
 *
 *  See comments before each MACRO definition for a more complete
 *  description of each one.
 *
 *  In order for a typed structure to be eligible for use in
 *  a CLL, it MUST include the pointers pNext and pPrev defined as
 *  pointers to the structure they belongs to.
 *
 *
 *
 */
#ifndef __CLLIST_H__
#define __CLLIST_H__



#include "NNstyle.h"


/***************
 *  TYPEDEFS
 ***************/

#define CLLIST(t)                     \
   struct {                        \
     t *pAnchor;    /* anchor element    */    \
     t *pCurr;        /* current element    */    \
     DWORD dwCount;    /* # elements in CLL    */    \
     DWORD fFlags;    /* flags        */    \
   }

#define CLL_FLAG_WAS_FOUND    0x00000001    /* prev CllFind() successful */



/************
 *  MACROs
 ************/

/*
 * Clear a CLL, any contents of the CLL are lost!
 *
 * parms:    lst    a structure of type CLLIST
 */
#define CllClear(lst) do {            \
      (lst).pAnchor = NULL;            \
      (lst).pCurr = NULL;            \
      (lst).dwCount = 0;            \
      (lst).fFlags = 0;            \
    } while (0)

#define CllClearSup(lst) do {            \
      PUT_VCP_REG(riface_irqsupress, 0);    \
      WAIT2;                \
      PUT_VCP_REG(riface_irqsupress, 0);    \
      (lst).pAnchor = NULL;            \
      (lst).pCurr = NULL;            \
      (lst).dwCount = 0;            \
      (lst).fFlags = 0;            \
    } while (0)


/*
 * insert an element into the list, either before or after the
 * anchor or before or after the current element
 *
 * parms:    lst    a structure of type CLLIST
 *        pe    pointer to element to add
 */
#define CllInsertPreAnchor(lst, pe) do {                \
      if (NULL == (lst).pAnchor) {                    \
        (lst).pAnchor = (pe);                    \
        (lst).pCurr = (pe);                        \
        (pe)->pNext = (pe);                        \
        (pe)->pPrev = (pe);                        \
      }                                \
      else {                            \
        (pe)->pNext = (lst).pAnchor;                \
        (pe)->pPrev = (lst).pAnchor->pPrev;                \
        (lst).pAnchor->pPrev->pNext = (pe);                \
        (lst).pAnchor->pPrev = (pe);                \
      }                                \
      (lst).dwCount++;                        \
      ASSERT(0 != (lst).dwCount);                    \
    } while (0)

#define CllInsertPreAnchorSup(lst, pe) do {                \
      PUT_VCP_REG(riface_irqsupress, 0);                \
      WAIT2;                            \
      PUT_VCP_REG(riface_irqsupress, 0);                \
      if (NULL == (lst).pAnchor) {                    \
        (lst).pAnchor = (pe);                    \
        PUT_VCP_REG(riface_irqsupress, 0);                \
        (lst).pCurr = (pe);                        \
        (pe)->pNext = (pe);                        \
        PUT_VCP_REG(riface_irqsupress, 0);                \
        (pe)->pPrev = (pe);                        \
      }                                \
      else {                            \
        (pe)->pNext = (lst).pAnchor;                \
        PUT_VCP_REG(riface_irqsupress, 0);                \
        (pe)->pPrev = (lst).pAnchor->pPrev;                \
        (lst).pAnchor->pPrev->pNext = (pe);                \
        PUT_VCP_REG(riface_irqsupress, 0);                \
        (lst).pAnchor->pPrev = (pe);                \
      }                                \
      (lst).dwCount++;                        \
    } while (0)


/*
 * get the current or anchor element
 *
 * parms:    lst    a structure of type CLLIST
 *
 * returns:    pointer to current element or NULL of empty list
 */
#define CllGetCurr(lst) ((lst).pCurr)

#define CllGetAnchor(lst) ((lst).pAnchor)




/*
 * set the current element
 *
 * parms:    lst    a structure of type CLLIST
 *        pe    pointer to element, MUST already be in the list
 */
#define CllSetCurr(lst, pe) do {(lst).pCurr = (pe);} while (0)



/*
 * move current to the next or prev element
 *
 * parms:    lst    a structure of type CLLIST
 */
#define CllNext(lst) do {                        \
      if (NULL != (lst).pCurr) {                    \
        (lst).pCurr = (lst).pCurr->pNext;                \
      }                                \
    } while (0)

#define CllNextSup(lst) do {                        \
      PUT_VCP_REG(riface_irqsupress, 0);                \
      WAIT2;                            \
      PUT_VCP_REG(riface_irqsupress, 0);                \
      if (NULL != (lst).pCurr) {                    \
        (lst).pCurr = (lst).pCurr->pNext;                \
      }                                \
    } while (0)

#define CllPrev(lst) do {                        \
      if (NULL != (lst).pCurr) {                    \
        (lst).pCurr = (lst).pCurr->pPrev;                \
      }                                \
    } while (0)

#define CllPrevSup(lst) do {                        \
      PUT_VCP_REG(riface_irqsupress, 0);                \
      WAIT2;                            \
      PUT_VCP_REG(riface_irqsupress, 0);                \
      if (NULL != (lst).pCurr) {                    \
        (lst).pCurr = (lst).pCurr->pPrev;                \
      }                                \
    } while (0)



/*
 * delete the current element, the next becomes the new current
 *
 * parms:    lst    a structure of type CLLIST
 */
#define CllDel(lst) do {                        \
      if (NULL != (lst).pCurr) {                    \
        ASSERT(0 != (lst).dwCount);                    \
        if (1 == (lst).dwCount) {                    \
          (lst).pCurr = NULL;                    \
          (lst).pAnchor = NULL;                    \
        } else {                            \
          (lst).pCurr->pPrev->pNext = (lst).pCurr->pNext;        \
          (lst).pCurr->pNext->pPrev = (lst).pCurr->pPrev;        \
          if ((lst).pCurr == (lst).pAnchor)                \
            (lst).pAnchor = (lst).pCurr->pNext;            \
          (lst).pCurr = (lst).pCurr->pNext;                \
         }                                \
        (lst).dwCount--;                        \
      }                                \
    } while (0)

#define CllDelSup(lst) do {                        \
      PUT_VCP_REG(riface_irqsupress, 0);                \
      WAIT2;                            \
      PUT_VCP_REG(riface_irqsupress, 0);                \
      if (NULL != (lst).pCurr) {                    \
        if (1 == (lst).dwCount) {                    \
          PUT_VCP_REG(riface_irqsupress, 0);            \
          (lst).pCurr = NULL;                    \
          (lst).pAnchor = NULL;                    \
        } else {                            \
          PUT_VCP_REG(riface_irqsupress, 0);            \
          (lst).pCurr->pPrev->pNext = (lst).pCurr->pNext;        \
          (lst).pCurr->pNext->pPrev = (lst).pCurr->pPrev;        \
          PUT_VCP_REG(riface_irqsupress, 0);            \
          if ((lst).pCurr == (lst).pAnchor)                \
            (lst).pAnchor = (lst).pCurr->pNext;            \
          PUT_VCP_REG(riface_irqsupress, 0);            \
          (lst).pCurr = (lst).pCurr->pNext;                \
         }                                \
        PUT_VCP_REG(riface_irqsupress, 0);                \
        (lst).dwCount--;                        \
      }                                \
    } while (0)




/*
 * find the given element, it becomes the new current
 *
 * NOTE: CllWasFound() must be called to determine if the CllFind()
 *     was successful or not (if not then current set to anchor)
 *
 * parms:    lst    a structure of type CLLIST
 *        pe    pointer to element to find
 */
#define CllFind(lst, pe) do {                        \
      (lst).fFlags &= ~CLL_FLAG_WAS_FOUND;                \
      if (NULL != (lst).pAnchor) {                    \
        (lst).pCurr = (lst).pAnchor;                \
        do {                            \
          if ((pe) == (lst).pCurr) {                \
            (lst).fFlags |= CLL_FLAG_WAS_FOUND;            \
        break;                            \
          }                                \
          (lst).pCurr = (lst).pCurr->pNext;                \
        } while ((lst).pCurr != (lst).pAnchor);            \
      }                                \
    } while (0)


/*
 * check if previous CllFind() was successful
 *
 * parms:    lst    a structure of type CLLIST
 *
 * returns:
 *    zero        find was not successful
 *    non-zero    find was successful
 */
#define CllWasFound(lst) ((lst).fFlags & CLL_FLAG_WAS_FOUND)


/*
 * get the # elements in the CLL
 *
 * parms:    lst    a structure of type CLLIST
 *
 * returns:    # elements in the CLL
 */
#define CllGetCount(lst) ((lst).dwCount)





#endif

