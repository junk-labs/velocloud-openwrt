/*
 * ppp_dbg.h
 *
 * ppp module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _PPP_DBG_H_
#define _PPP_DBG_H_

#ifndef NDEBUG

  #ifdef NETDBG_HI
    #ifndef PPPDBG_HI
      #define PPPDBG_HI
    #endif
  #endif

#else

  #ifdef PPPDBG_HI
    #undef PPPDBG_HI
  #endif

#endif

#include "netdbg.h"


/*
 * Constants
 */
#define PPP_MAGIC_COOKIE 0x70707000 /*"ppp" = 0x70707000*/


/*
 * Debug macros
 */
/*#ifdef PPPDBG_HI*/
#if defined(PPPDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define PPP_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == PPP_MAGIC_COOKIE));

  #define PPP_SET_COOKIE(x) (x)->dwMagicCookie = PPP_MAGIC_COOKIE
  #define PPP_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define PPP_DBGP(level, fmt, args...) do { \
    if (level <= g_dwPppDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define PPP_DBG(level, x) do {  \
    if (level <= g_dwPppDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define PPP_DBG_VAR(x)  x
#else
  #define PPP_CHECK_STATE(x)
  #define PPP_SET_COOKIE(x)
  #define PPP_UNSET_COOKIE(x)
  #define PPP_DBGP(level, fmt, args...)
  #define PPP_DBG(level, x)
  #define PPP_DBG_VAR(x)
#endif

PPP_DBG_VAR(MOC_EXTERN DWORD g_dwPppDebugLevel);

/*
 * Debug levels
 */
#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#ifdef PPCPDBG_HI
#define DBG_CHECKPOINT(A)

#define DBG_PPPINSTANCE_PRINTMSG(pInst,poMsg,wLength)  \
          do {if (dbg_bPrintPPPMsg == TRUE) {NetPrintPayload(poMsg,wLength);}} while(0)

#define DBG_PPPINSTANCE_PRINTTXMSG(pInst,poMsg,wLength)\
          do {if (dbg_bPrintPPPTxMsg == TRUE) {NetPrintPayload(poMsg,wLength);}} while(0)

#define DBG_PPPINSTANCE_PRINTSTATETRANSITION(pxCpState)\
          do {if (dbg_bPrintPPPStateTransition == TRUE) {printf("== PPP inst %ld ,jumps to state : %s\n",(DWORD) pxCpState,apoPppCpStateString[pxCpState->eState]);}} while(0)

#define DBG_PPPINSTANCE_PRINTEVENT(pxCpState) \
          do {if (dbg_bPrintPPPEvent == TRUE) { printf("== PPP inst %ld ,received event: %s\n",(DWORD) pxCpState,apoPppCpEventString[pxEvent->eType]); } } while(0)

#else
#define DBG_CHECKPOINT(A)
#define DBG_PPPINSTANCE_PRINTMSG(pInst,poMsg,wLength)
#define DBG_PPPINSTANCE_PRINTSTATETRANSITION(pxCpState)
#define DBG_PPPINSTANCE_PRINTEVENT(pxCpState)
#define DBG_PPPINSTANCE_PRINTTXMSG(pInst,poMsg,wLength)
#endif
#endif /* #ifndef _PPP_DBG_H_ */
