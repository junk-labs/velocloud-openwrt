/*
 * netpacket.c
 *
 * Implements netpacket related functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"
#include "socket_flavor.h"
#include "../include/in.h"
#include "netdb.h"
#include "../include/inet.h"
#include "../include/socket_inet.h"
#include "../include/socket.h"
#include "../include/if.h"
#include "mqueue.h"
#include "nettime.h"
#include "netmain.h"
#include "netpacket_flavor.h"
#include "nettime.h"
#include "netpthread.h"
#include "netcommon.h"
#include "netutils.h"
#include "../include/netsegment.h"
#include "netdbg.h"


/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/


/*
 * NETPAYLOAD_CREATE
 *  Creates a Netpayload. Number of users is set to 1.
 *
 *  Args:
 *   pfnFree                Free function of the payload
 *   pxMutex                Mutex of the payload
 *   ppxPayload             payload pointer to be filled up
 *
 *  Returns:
 */
void NetPayloadCreate(NETPAYLOAD **ppxPayload,
                      PFN_NETFREE pfnFreeF,
                      RTOS_MUTEX pxMutexX,
                      OCTET *poPayloadD,
                      WORD wSizeE)
{
#ifdef __INET_USE_MEMPOOL__
   MSTATUS status;
   NETWRAPPERSTATE *pxWrapperState;
   pxWrapperState = NETGETWRAPPERSTATE(&xNetWrapper);

   if( OK > (status = MEM_POOL_getPoolObject(&pxWrapperState->netPayloadPool, (void **)ppxPayload)))
   {
      *ppxPayload=NULL;
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: NetPayLoadCreate - Unable to allocate Buffer");
      return;
   }
   pxWrapperState->netPayloadPoolUsed++;
   /* printf("Alloc from Pool: pointer -> %x - NumUsed = %d\n", *ppxPayload,
           pxWrapperState->netPayloadPoolUsed); */
#else
  *(ppxPayload) = (NETPAYLOAD *)MALLOC(sizeof(NETPAYLOAD));
#endif /* __INET_USE_MEMPOOL__ */

  /*MOC_MEMSET((ubyte *)(*ppxPayload), 0, sizeof(NETPAYLOAD));*/
  DEBUG({
    (*(ppxPayload))->dwMagicCookie = 0xdeadbeef;
  });
  (*(ppxPayload))->pfnFree = pfnFreeF;
#ifdef NET_ASYNC
  (*(ppxPayload))->pxMutex = pxMutexX;
#endif
  (*(ppxPayload))->poPayload = poPayloadD;
  (*(ppxPayload))->wSize = wSizeE;
  (*(ppxPayload))->oUserCount = (1);
#ifdef __TCP_SEND_SEGMENT__
  (*(ppxPayload))->pTxSegment = NULL;
#endif
}

void NetPayloadCreateDrv(NETPAYLOAD **ppxPayload,
                      PFN_NETFREE pfnFreeF,
                      RTOS_MUTEX pxMutexX,
                      OCTET *poPayloadD,
                      WORD wSizeE)
{
   MSTATUS status;

   if( OK > (status = MEM_POOL_getPoolObject(&netPayloadPool, (void **)ppxPayload)))
   {
      *ppxPayload=NULL;
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Error: NetPayLoadCreate - Unable to allocate Buffer");
      return;
   }
   netPayloadPoolUsed++;

#if 0
  *(ppxPayload) = (NETPAYLOAD *)MALLOC(sizeof(NETPAYLOAD));
#endif

  /*MOC_MEMSET((ubyte *)(*ppxPayload), 0, sizeof(NETPAYLOAD));*/
  DEBUG({
    (*(ppxPayload))->dwMagicCookie = 0xdeadbeef;
  });
  (*(ppxPayload))->pfnFree = pfnFreeF;
#ifdef NET_ASYNC
  (*(ppxPayload))->pxMutex = pxMutexX;
#endif
  (*(ppxPayload))->poPayload = poPayloadD;
  (*(ppxPayload))->wSize = wSizeE;
  (*(ppxPayload))->oUserCount = (1);
#ifdef __TCP_SEND_SEGMENT__
  (*(ppxPayload))->pTxSegment = NULL;
#endif
}

/*
 * NETPAYLOAD_DELUSER
 *  Remove a user from a NetPayload.
 *  Will free the pxNetPayload and its content if the number
 *  if users reach 0.
 *
 *  Args
 *   pxNetPayload
 *
 */
void NetPayloadDelUser(NETPAYLOAD *pxNetPayload)
{
#ifdef NET_ASYNC
  int iRvPML;
#endif
#ifdef __TCP_SEND_SEGMENT__
  txSegmentStructure *pTxSegment;
  NETWRAPPER *pxNetWrapper;
#endif

#ifdef __INET_USE_MEMPOOL__
   NETWRAPPERSTATE *pxNetWrapperState = NETGETWRAPPERSTATE(&xNetWrapper);
#endif


  ASSERT((pxNetPayload != NULL) &&
         (pxNetPayload->dwMagicCookie == 0xdeadbeef));

#ifdef NET_ASYNC
  iRvPML = RTOS_recursiveMutexWait((pxNetPayload->pxMutex));
  ASSERT(iRvPML ==0);
#endif
  ASSERT(pxNetPayload->oUserCount != 0);

  if ((--(pxNetPayload->oUserCount)) == 0) {
#ifdef __TCP_SEND_SEGMENT__
   if (pxNetPayload->pTxSegment)
   {
       /* Call the Application Back */
      pTxSegment = (txSegmentStructure *) pxNetPayload->pTxSegment;
      pTxSegment->pNextSegment = NULL;
      /* TODO  JJ Need to Unlock the Mutex */
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Returning  Buffer to User Unlock Mutex.");

      pxNetWrapper = NETGETWRAPPER;
      RTOS_recursiveMutexRelease(&(pxNetWrapper->xMutex));
      pTxSegment->pfCb(pxNetPayload->pTxSegment,pTxSegment->pvCbArg); /* Callback to the app */
      RTOS_recursiveMutexWait(&(pxNetWrapper->xMutex));


   }
   else
   {
       pxNetPayload->pfnFree(pxNetPayload->poPayload);
   }

#else
   pxNetPayload->pfnFree(pxNetPayload->poPayload);
#endif
   DEBUG({pxNetPayload->dwMagicCookie = 0;});

#ifdef __INET_USE_MEMPOOL__
   pxNetWrapperState->netPayloadPoolUsed--;
   /* printf("Release to Pool : pointer -> %x - NumUsed = %d\n", pxNetPayload,
          pxNetWrapperState->netPayloadPoolUsed); */
   MEM_POOL_putPoolObject(&pxNetWrapperState->netPayloadPool, (void **)(&pxNetPayload));
#else
   FREE(pxNetPayload);
#endif

  }

#ifdef NET_ASYNC
  RTOS_recursiveMutexRelease((pxNetPayload->pxMutex));
#endif
}

void NetPayloadDelUserDrv(NETPAYLOAD *pxNetPayload)
{
#ifdef NET_ASYNC
  int iRvPML;
#endif
#ifdef __TCP_SEND_SEGMENT__
  txSegmentStructure *pTxSegment;
  NETWRAPPER *pxNetWrapper;
#endif



  ASSERT((pxNetPayload != NULL) &&
         (pxNetPayload->dwMagicCookie == 0xdeadbeef));

#ifdef NET_ASYNC
  iRvPML = RTOS_recursiveMutexWait((pxNetPayload->pxMutex));
  ASSERT(iRvPML ==0);
#endif
  ASSERT(pxNetPayload->oUserCount != 0);

  if ((--(pxNetPayload->oUserCount)) == 0) {
#ifdef __TCP_SEND_SEGMENT__
   if (pxNetPayload->pTxSegment)
   {
       /* Call the Application Back */
      pTxSegment = (txSegmentStructure *) pxNetPayload->pTxSegment;
      pTxSegment->pNextSegment = NULL;
      /* TODO  JJ Need to Unlock the Mutex */
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Returning  Buffer to User Unlock Mutex.");

      pxNetWrapper = NETGETWRAPPER;
      RTOS_recursiveMutexRelease(&(pxNetWrapper->xMutex));
      pTxSegment->pfCb(pxNetPayload->pTxSegment,pTxSegment->pvCbArg); /* Callback to the app */
      RTOS_recursiveMutexWait(&(pxNetWrapper->xMutex));


   }
   else
   {
       pxNetPayload->pfnFree(pxNetPayload->poPayload);
   }

#else
   pxNetPayload->pfnFree(pxNetPayload->poPayload);
#endif
   DEBUG({pxNetPayload->dwMagicCookie = 0;});

#if 0
   FREE(pxNetPayload);
#endif
   netPayloadPoolUsed--;
   MEM_POOL_putPoolObject(&netPayloadPool, (void **)(&pxNetPayload));

  }

#ifdef NET_ASYNC
  RTOS_recursiveMutexRelease((pxNetPayload->pxMutex));
#endif
}
/*
 * NetPacketDuplicate
 *  Duplicate a Net packet. Creates a new NETPAYLOAD in
 *  which the original data is copied
 *
 *  Args:
 *   pxDst                Destination
 *   pxSrc                Src
 *   pxMutex              mutex to be used on the new NETPAYLOAD
 *
 *  Return:
 */
void NetPacketDuplicate(NETPACKET *pxDst,NETPACKET *pxSrc,
                        RTOS_MUTEX pxMutex)
{
  OCTET *poNewPayload;
  NETPAYLOAD *pxOrigPayload;
  WORD wSize;
  MSTATUS status;
  ASSERT(pxDst != NULL);
  ASSERT(pxSrc != NULL);

  MOC_MEMCPY((ubyte *)pxDst,(ubyte *)pxSrc,sizeof(NETPACKET));

  NETPAYLOAD_LOCK(pxOrigPayload);
  pxOrigPayload = pxSrc->pxPayload;
  ASSERT(pxOrigPayload != NULL);

  wSize = pxOrigPayload->wSize;

#ifdef __INET_USE_PAYLOAD_MEMPOOL__
  status = NetAllocPayload(&poNewPayload,wSize * sizeof(OCTET));
#else
  poNewPayload = (OCTET *) MALLOC(wSize * sizeof(OCTET));
#endif
  if (poNewPayload == NULL)
      return;

  ASSERT(poNewPayload != NULL);

  MOC_MEMCPY((ubyte *)poNewPayload,(ubyte *)pxOrigPayload->poPayload, wSize);

  NETPAYLOAD_UNLOCK(pxOrigPayload);

  NETPAYLOAD_CREATE(&(pxDst->pxPayload), NetFree,pxMutex,poNewPayload,
                    wSize);

  return;
}

#ifdef NETDBG_HI
void NetPacketPrint(char *pcExtrastr,NETPACKET *pxNetPacket)
{
  printf("%s poPayload = %p,wOffset = %d, wLength = %d, wSize = %d,oIfIdx = %d \n",
         pcExtrastr,
         pxNetPacket->pxPayload->poPayload,
         pxNetPacket->wOffset,
         pxNetPacket->wLength,
         pxNetPacket->pxPayload->wSize,
         pxNetPacket->oIfIdx);
}
#endif /*#ifdef NETDBG_HI*/

#ifdef __INET_USE_PAYLOAD_MEMPOOL__
extern MSTATUS
NetAllocPayload(OCTET ** ppxPoPayload,WORD wSize)
{
    MSTATUS status;
    ubyte  *pxPoPayload;

    if (wSize <=512)
    {

        RTOS_mutexWait(poPayloadMutex_512);
        status = MEM_POOL_getPoolObject(&netPoPayloadPool_512, (void **)&pxPoPayload);
        RTOS_mutexRelease(poPayloadMutex_512);
        if (OK > status)
            goto exit;
        pxPoPayload[0] = 5;
        pxPoPayload[1] = 12;
        *ppxPoPayload = pxPoPayload;
    }
    else if (wSize <=1536)
    {

        RTOS_mutexWait(poPayloadMutex_1536);
        status = MEM_POOL_getPoolObject(&netPoPayloadPool_1536, (void **)&pxPoPayload);
        RTOS_mutexRelease(poPayloadMutex_1536);
        if (OK > status)
            goto exit;
        pxPoPayload[0] = 15;
        pxPoPayload[1] = 36;
        *ppxPoPayload = pxPoPayload;
    }
    else
    {
        pxPoPayload = MALLOC(wSize);
        if ( NULL == *ppxPoPayload)
        {
            status = ERR_MEM_ALLOC_FAIL;
            goto exit;
        }
        pxPoPayload[0] = 0xAA;
        pxPoPayload[1] = 0xBB;
        *ppxPoPayload = pxPoPayload;
    }

exit:
    return status;
}

extern MSTATUS
NetFreePayload(OCTET * pxPoPayload)
{
    MSTATUS status;

    if ((pxPoPayload[0] == 5) &&
        (pxPoPayload[1] == 12))
    {

        RTOS_mutexWait(poPayloadMutex_512);
        status = MEM_POOL_putPoolObject(&netPoPayloadPool_512, (void **)&pxPoPayload);
        RTOS_mutexRelease(poPayloadMutex_512);
        if (OK > status)
            goto exit;
    }
    else if ((pxPoPayload[0] == 15) &&
             (pxPoPayload[1] == 36))
    {

        RTOS_mutexWait(poPayloadMutex_1536);
        status = MEM_POOL_putPoolObject(&netPoPayloadPool_1536, (void **)&pxPoPayload);
        RTOS_mutexRelease(poPayloadMutex_1536);
    }
    else if ((pxPoPayload[0] == 0xAA) &&
             (pxPoPayload[1] == 0xBB))
    {
        FREE(pxPoPayload);
    }
    else
    {
        printf("NetFreePayload:, INitial Value not set\n");
        FREE(pxPoPayload);
    }

exit:
    return status;
}

#endif /* __INET_USE_PAYLOAD_MEMPOOL__*/
