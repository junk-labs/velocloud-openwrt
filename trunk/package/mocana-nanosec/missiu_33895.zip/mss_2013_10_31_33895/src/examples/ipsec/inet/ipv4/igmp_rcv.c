/*
 * igmp_rcv.c
 *
 * IGMP module receive functions
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "igmp_defs.h"
#include "igmp_proxy_defs.h"


/*****************************************************************************
 *
 * Prototypes
 *
 *****************************************************************************/
#ifdef STACK_MULTICAST_ROUTER
static LONG _IgmpProxyRcv(IGMPSTATE *pxIgmp,
                          H_NETINSTANCE hIf,
                          NETPACKET *pxNetPacket,
                          NETPACKETACCESS *pxNetPktAccess,
                          H_NETDATA hData);

static LONG _IgmpProxyRcvReport(IGMPSTATE *pxIgmp,
                                IGMP_PKT *pxIgmpPkt,
                                MCAST_GROUP **ppxMcastGroup,
                                OCTET oReportType);
#endif /* #ifdef STACK_MULTICAST_ROUTER */


/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/

/*
 * IgmpInstanceRcv
 *   Igmp Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIgmp                      Ud Instance Handle
 *    hIf                        Interface handle
 *    pxNetPacket                packet
 *    wOffset                    Igmp PDU offset.
 *    hData                      unused(could be used for VLAN)
 *
 *   Return:
 *    Number of bytes received or -1 (error)
 */
LONG IgmpInstanceRcv(H_NETINSTANCE hIgmp,
                     H_NETINTERFACE hIf,
                     NETPACKET *pxNetPacket,
                     NETPACKETACCESS *pxNetPktAccess,
                     H_NETDATA hData)
{
  IGMPSTATE *pxIgmp = (IGMPSTATE *)hIgmp;
  IGMP_PKT *pxIgmpPkt;
  IP_MCAST *pxIpMcast;
  LONG lReturn;
  NETWORKID *pxNetworkId = (NETWORKID*)hData;

  IGMP_CHECK_STATE(pxIgmp);
  ASSERT((pxNetPacket != NULL) && (pxNetPktAccess != NULL) && (pxNetworkId != NULL));

#ifndef STACK_MULTICAST_ROUTER
  if(pxNetworkId->oIfIdx != 0){
    ASSERT(0);
    return -1;
  }
#endif

  lReturn = pxNetPktAccess->wLength;

  pxIgmpPkt = (IGMP_PKT*)(pxNetPacket->pxPayload->poPayload +
                          pxNetPktAccess->wOffset);
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IGMP_DBGP(REPETITIVE,"IgmpInstanceRcv:oIfIdx=%d,type %s, RespTime 0x%x, Group: %ld.%ld.%ld.%ld\n",
            pxNetworkId->oIfIdx,
            IgmpTypeToString(pxIgmpPkt->oType),
            pxIgmpPkt->oMaxRespTime,
            IPADDRDISPLAY(pxIgmpPkt->dwGroupAddr));*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IgmpInstanceRcv:oIfIdx=", pxNetworkId->oIfIdx);
    DEBUG_PRINT2(DEBUG_MOC_IPV4, ",type ", IgmpTypeToString(pxIgmpPkt->oType));
    DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4, ", RespTime 0x", pxIgmpPkt->oMaxRespTime);
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, ", Group: ", pxIgmpPkt->dwGroupAddr);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_DETAIL))
  {
    /*IGMP_DBG(XREPETITIVE,IgmpPrintMcastGroup(pxIgmp));*/
    IgmpPrintMcastGroup(pxIgmp); /* Invoke the method, put the MOC specific stmnts in this function */
  }

  /* Verify Checksum */
  if (Checksum16((OCTET*)pxIgmpPkt, sizeof(IGMP_PKT)) == 0) {

#ifdef STACK_MULTICAST_ROUTER
    /* TODO!!!! igmp proxy rcv is called only in routed mode */
    if((pxNetworkId->oIfIdx == pxIgmp->oProxyIfIndex) && (0 == 0)){
      lReturn = _IgmpProxyRcv(pxIgmp,hIf,pxNetPacket,pxNetPktAccess,hData);
    } else
#endif /*#ifdef STACK_MULTICAST_ROUTER*/

    {
      /* check if an IGMP V1 query */
      if ((pxIgmpPkt->oType == IGMP_MEMBERSHIP_QUERY) && (pxIgmpPkt->oMaxRespTime == 0)) {
        /* received IGMPv1 query */
        pxIgmp->oReportVersion = IGMP_V1_MEMBERSHIP_REPORT;
        pxIgmp->dwTimeIgmpV1 = (DWORD)NetGetMsecTime();
        pxIgmpPkt->oMaxRespTime = IGMP_MAX_RESPONSE_TIME;
      }

      DLLIST_head(&pxIgmp->dllIpMcast);
      while ((pxIpMcast = (IP_MCAST*)DLLIST_read(&pxIgmp->dllIpMcast)) != NULL) {
        pxIpMcast->fpIgmpRcv(pxIpMcast, pxIgmpPkt);
        DLLIST_next(&pxIgmp->dllIpMcast);
      }
    }
  }

  NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);

  return lReturn;
}

/*****************************************************************************
Function:
        IgmpRcvStateIdle()
Description:
        Process an incoming IGMP packet while in the idle state
Arguments:
        pxIpMcast         Pointer to multicast group structure
        pxIgmpPkt         IGMP packet structure
Outputs:
        None
Returns:
        None
*****************************************************************************/
void IgmpRcvStateIdle(IP_MCAST *pxIpMcast,IGMP_PKT *pxIgmpPkt)
{
  switch (pxIgmpPkt->oType) {

  case IGMP_MEMBERSHIP_QUERY:
    if (pxIgmpPkt->dwGroupAddr != 0 && /* Specific Query */
        pxIgmpPkt->dwGroupAddr != pxIpMcast->xIpMreq.dwMulticastAddr)
      return;

    pxIpMcast->dwTimeResponse = NetGetMsecTime() + RAND(0,(pxIgmpPkt->oMaxRespTime*100));
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IGMP_DBGP(REPETITIVE,"IgmpRcvStateIdle:query recvd grp %ld.%ld.%ld.%ld resp due @ time %ld (cur %ld max %ld) state:idle->delay\n",
              IPADDRDISPLAY(pxIpMcast->xIpMreq.dwMulticastAddr),
              pxIpMcast->dwTimeResponse,
              NetGetMsecTime(),
              NetGetMsecTime()+pxIgmpPkt->oMaxRespTime*100);*/
      DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IgmpRcvStateIdle:query recvd grp ", pxIpMcast->xIpMreq.dwMulticastAddr);
      DEBUG_PRINT(DEBUG_MOC_IPV4, " resp due @ time ");
      DEBUG_UINT(DEBUG_MOC_IPV4, pxIpMcast->dwTimeResponse);
      DEBUG_PRINT(DEBUG_MOC_IPV4, " (cur ");
      DEBUG_UINT(DEBUG_MOC_IPV4, NetGetMsecTime());
      DEBUG_PRINT(DEBUG_MOC_IPV4, " max ");
      DEBUG_UINT(DEBUG_MOC_IPV4, (NetGetMsecTime()+pxIgmpPkt->oMaxRespTime*100));
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, ") state:idle->delay");
    }
    pxIpMcast->fpIgmpRcv = IgmpRcvStateDelay;
    break;

  case IGMP_V2_MEMBERSHIP_REPORT:
  case IGMP_V1_MEMBERSHIP_REPORT:
  case IGMP_LEAVE_MEMBERSHIP:
    break;

  default:
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_ERROR))
    {
      /*IGMP_DBGP(ERROR,"IgmpRcvStateIdle: Wrong IGMP type\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IgmpRcvStateIdle: Wrong IGMP type");
    }
    break;
  }
}

/*****************************************************************************
Function:
        IgmpRcvStateDelay()
Description:
        Process an incoming IGMP packet while in the delay state
Arguments:
        pxIpMcast         Pointer to multicast group structure
        pxIgmpPkt         IGMP packet structure
Outputs:
        None
Returns:
        None
*****************************************************************************/
void IgmpRcvStateDelay(IP_MCAST *pxIpMcast,IGMP_PKT *pxIgmpPkt)
{
  switch (pxIgmpPkt->oType) {

  case IGMP_MEMBERSHIP_QUERY: /* Membership query */
    {
      LONG lMaxRespTime = (LONG)pxIgmpPkt->oMaxRespTime * 100;
      LONG lRemainingTime;
      /* this field specifies the maximum allowed time in units of 1/10 second */
      if (pxIgmpPkt->dwGroupAddr != 0 && /* Specific Query */
          pxIgmpPkt->dwGroupAddr != pxIpMcast->xIpMreq.dwMulticastAddr)
        return;

      lRemainingTime=(LONG)pxIpMcast->dwTimeResponse - (LONG)NetGetMsecTime();

      if (lMaxRespTime < lRemainingTime) {
        /* If a timer for the group is already running, it is reset to the
           random value only if the requested Max Response Time is less
           than the remaining value of the running timer */
        pxIpMcast->dwTimeResponse = NetGetMsecTime() + RAND(0,lMaxRespTime);
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
        {
          /*IGMP_DBGP(REPETITIVE,"IgmpRcvStateDelay: recvd query grp %ld.%ld.%ld.%ld resp due @ %ld (max %ld), Reset Timer\n",
                  IPADDRDISPLAY(pxIgmpPkt->dwGroupAddr),
                  pxIpMcast->dwTimeResponse,
                  NetGetMsecTime()+lMaxRespTime);*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IgmpRcvStateDelay: recvd query grp ", pxIgmpPkt->dwGroupAddr);
          DEBUG_PRINT(DEBUG_MOC_IPV4, " resp due @ ");
          DEBUG_UINT(DEBUG_MOC_IPV4, pxIpMcast->dwTimeResponse);
          DEBUG_PRINT(DEBUG_MOC_IPV4, " (max ");
          DEBUG_UINT(DEBUG_MOC_IPV4, (NetGetMsecTime() + lMaxRespTime));
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, "), Reset Timer");
        }
      }
    }
    break;

  case IGMP_V2_MEMBERSHIP_REPORT:
  case IGMP_V1_MEMBERSHIP_REPORT:
  case IGMP_LEAVE_MEMBERSHIP:
    /* If the host receives another host's report while it has a timer
       running, it stops its timer for the specified group and does not
       send a report, in order to suppress duplicate reports */
    if (pxIgmpPkt->dwGroupAddr == pxIpMcast->xIpMreq.dwMulticastAddr) {
      pxIpMcast->fpIgmpRcv = IgmpRcvStateIdle;
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
      {
        /*IGMP_DBGP(REPETITIVE,"IgmpRcvStateDelay: delay: state change to idle (another host reported)\n");*/
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IgmpRcvStateDelay: delay: state change to idle (another host reported)");
      }
    }
    break;

  default:
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_ERROR))
    {
      /*IGMP_DBGP(ERROR,"IgmpRcvStateDelay: Wrong IGMP type\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IgmpRcvStateDelay: Wrong IGMP type");
    }
    break;
  }
}


#ifdef STACK_MULTICAST_ROUTER
/*****************************************************************************
Function:
        _IgmpProxyRcv()
Description:
        Process an incoming IGMP for the IGMP proxy
        Follows PFN_NETWORRXCBK def.
Arguments:
        pxIgmp                     Instance Handle
        hIf                        Interface handle
        pxNetPacket                packet
        wOffset                    Igmp PDU offset.
        hData                      unused(could be used for VLAN)
Outputs:
        None
Returns:
        None
*****************************************************************************/
static LONG _IgmpProxyRcv(IGMPSTATE *pxIgmp,
                          H_NETINTERFACE hIf,
                          NETPACKET *pxNetPacket,
                          NETPACKETACCESS *pxNetPktAccess,
                          H_NETDATA hData)
{
  IGMP_PKT *pxIgmpPkt;
  MCAST_GROUP *pxMcastGroup = NULL;
  LONG lRv = 0;
  DWORD dwCurrentTime = (DWORD)NetGetMsecTime();
  NETWORKID *pxNetworkId = (NETWORKID*)hData;

  pxIgmpPkt = (IGMP_PKT*)(pxNetPacket->pxPayload->poPayload + pxNetPktAccess->wOffset);

  /* Is the IP address really a multicast address? */
  if(!IN_MULTICAST(pxIgmpPkt->dwGroupAddr) &&
     (pxIgmpPkt->oType != IGMP_MEMBERSHIP_QUERY)){
    return -1;
  }

  /* Find the multicast group */
  DLLIST_head(&pxIgmp->dllMcastGroups);
  while ((pxMcastGroup = DLLIST_read(&pxIgmp->dllMcastGroups)) != NULL) {
    if (pxMcastGroup->dwGroupIPAddress == pxIgmpPkt->dwGroupAddr) {
      break;
    }
    DLLIST_next(&pxIgmp->dllMcastGroups);
  }

  IGMP_DBG(REPETITIVE,
           if(pxMcastGroup == NULL) {
             printf("IgmpProxyRcv:new group received %ld.%ld.%ld.%ld \n",
                    IPADDRDISPLAY(pxIgmpPkt->dwGroupAddr));
           } else {
             printf("IgmpProxyRcv:group already exist %ld.%ld.%ld.%ld \n",
                    IPADDRDISPLAY(pxIgmpPkt->dwGroupAddr));
           });


  /* Act on the IGMP message type */
  switch (pxIgmpPkt->oType) {

  /*
   * IGMP Membership query
   */
  case IGMP_MEMBERSHIP_QUERY:
    /*
     * We have been queried on the LAN interface. This means
     * that another IGMP proxy resides on the downstream
     * interface. If it's IP address is lower than ours,
     * we MUST become a non-querier, otherwise do nothing
     * with this packet.
     */
    {
      IPTABLEENTRY xIpEntry;

      xIpEntry.oIfIdx = pxIgmp->oProxyIfIndex;
      xIpEntry.wDefaultVlan = NETVLAN_DEFAULT;
      xIpEntry.eAddrType = IPADDRT_ANY;
      xIpEntry.dwAddr = (DWORD)0;
      lRv = IpTableMsg(IPTABLEMSG_GETDEFAULT,(H_NETDATA)&xIpEntry);
      ASSERT(lRv == 0);

      if (xIpEntry.dwAddr > pxNetworkId->dwSrcAddr) {
        pxIgmp->eProxyState = IGMP_PROXY_STATE_NON_QUERIER;
        pxIgmp->dwProxyNonQuerierTimer = dwCurrentTime + OTHER_ROUTER_PRESENT_INTERVAL;
      }
    }
    break;


  /*
   * IGMP V2 membership report
   */
  case IGMP_V2_MEMBERSHIP_REPORT:
    lRv = _IgmpProxyRcvReport(pxIgmp,pxIgmpPkt,&pxMcastGroup,
                              IGMP_V2_MEMBERSHIP_REPORT);

    if (lRv < 0) {
      return lRv;
    }

    pxMcastGroup->eGroupState = IGMP_GROUP_STATE_MEMBERS_PRESENT;
    /* Reset [Group Membership Interval] timer */
    pxMcastGroup->dwGroupTimer = dwCurrentTime + GROUP_MEMBERSHIP_INTERVAL;

    break;


  /*
   * IGMP V1 membership report
   */
  case IGMP_V1_MEMBERSHIP_REPORT:
    lRv = _IgmpProxyRcvReport(pxIgmp,pxIgmpPkt,&pxMcastGroup,
                              IGMP_V1_MEMBERSHIP_REPORT);

    if (lRv < 0) {
      return lRv;
    }

    /* Always overrides MEMBERS_PRESENT state */
    pxMcastGroup->eGroupState = IGMP_GROUP_STATE_V1_MEMBERS_PRESENT;

    /* Reset [Group Membership Interval] timer */
    pxMcastGroup->dwGroupTimer = dwCurrentTime + GROUP_MEMBERSHIP_INTERVAL;

    /* Reset [V1 Host] timer */     /* See RFC2236 (section 5) */
    pxMcastGroup->dwV1HostTimer = dwCurrentTime + V1_HOST_TIMER;

    break;


  /*
   * Leave group
   */
  case IGMP_LEAVE_MEMBERSHIP:
    lRv = _IgmpProxyRcvReport(pxIgmp,pxIgmpPkt,&pxMcastGroup,
                              IGMP_LEAVE_MEMBERSHIP);

    if (lRv < 0) {
      return lRv;
    }

    pxMcastGroup->eGroupState = IGMP_GROUP_STATE_CHECKING_MEMBERSHIP;

    /* Set group timer */
    if (pxIgmp->eProxyState == IGMP_PROXY_STATE_QUERIER) {
      pxMcastGroup->dwGroupTimer = dwCurrentTime +
                                   (LAST_MEMBER_QUERY_INTERVAL * LAST_MEMBER_QUERY_COUNT);
    }
    else {
      DWORD dwMaxResponseTime = (DWORD)pxIgmpPkt->oMaxRespTime;
      pxMcastGroup->dwGroupTimer = dwCurrentTime +
                                   (dwMaxResponseTime * LAST_MEMBER_QUERY_COUNT);
    }

    /* Start retransmit timer [Last Member Query Interval] */
    pxMcastGroup->dwRTXTimer = dwCurrentTime + LAST_MEMBER_QUERY_INTERVAL;

    /* Send group-specific query */
    IgmpProxySendQuery(pxIgmp,pxMcastGroup->dwGroupIPAddress,
                       (OCTET)LAST_MEMBER_QUERY_INTERVAL/100);

    break;

  default:
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_ERROR))
    {
      /*IGMP_DBGP(ERROR,"_IgmpProxyRcv: Wrong IGMP type\n");*/
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, "_IgmpProxyRcv: Wrong IGMP type");
    }
    ASSERT(0);
  }

  return 1;
}

/*****************************************************************************
Function:
        _IgmpProxyRcvReport()
Description:
        Process an incoming IGMP report on the LAN interface
Arguments:
        pxIgmp                     Instance Handle
        pxIgmpPkt                  IGMP packet structure
        ppxMcastGroup              multicast group associated with packet
        oReportType                type of IGMP report
Outputs:
        None
Returns:
        0 - no errors
       -1 - error
*****************************************************************************/
static LONG _IgmpProxyRcvReport(IGMPSTATE *pxIgmp,
                                IGMP_PKT *pxIgmpPkt,
                                MCAST_GROUP **ppxMcastGroup,
                                OCTET oReportType)
{
  IPMCASTREQ xIpMreq;

  xIpMreq.dwMulticastAddr = pxIgmpPkt->dwGroupAddr;
  xIpMreq.oPhyIf = NETIFIDX_ANY;

  if (*ppxMcastGroup == NULL) {
    if (DLLIST_count_inline(&pxIgmp->dllMcastGroups) <= MAX_HOST_GROUP) {
      *ppxMcastGroup = MALLOC(sizeof(MCAST_GROUP));
      if (*ppxMcastGroup == NULL) {
        return -1;
      }
      MOC_MEMSET((ubyte *)*ppxMcastGroup, 0, sizeof(MCAST_GROUP));


      (*ppxMcastGroup)->dwGroupIPAddress = pxIgmpPkt->dwGroupAddr;
      if (DLLIST_append(&pxIgmp->dllMcastGroups, *ppxMcastGroup) == NULL) {
        return -1;
      }

      if (IgmpMsgJoin(pxIgmp,&xIpMreq,FALSE) >= 0) {

#ifdef IGMP_IPTABLEMCAST
        /*
         * Add multicast address to the repository.
         */
        IPTABLEENTRY xEntry;
        ROUTEENTRY xRouteEntry;

        xEntry.oIfIdx = xIpMreq.oPhyIf;
        xEntry.dwAddr = xIpMreq.dwMulticastAddr;
        xEntry.wDefaultVlan = NETVLAN_ANY;
        xEntry.eAddrType = IPADDRT_MULTICASTJOINEDPROXY;

        IpTableMsg(IPTABLEMSG_ADDENTRY, (H_NETDATA)&xEntry);

        xRouteEntry.dwGateway    = xIpMreq.dwMulticastAddr;
        xRouteEntry.dwSubnetMask = 0xffffffff;
        xRouteEntry.dwDstAddr    = xIpMreq.dwMulticastAddr;
        xRouteEntry.wMetric      = 1;
        xRouteEntry.wTOS         = 0;
        xRouteEntry.oIfIdx       = pxIgmp->oProxyIfIndex;
        xRouteEntry.wVlan        = NETVLAN_ANY;

        RoutingTableMsg(ROUTINGTABLEMSG_ADDROUTE,(H_NETDATA)&xRouteEntry);
#endif

        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
        {
          /*IGMP_PROXY_DBGP(REPETITIVE,"IgmpProxyRcv: Adding group %ld.%ld.%ld.%ld (%s)\n",
                        IPADDRDISPLAY((*ppxMcastGroup)->dwGroupIPAddress),
                        IgmpTypeToString(oReportType));*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IgmpProxyRcv: Adding group ", (*ppxMcastGroup)->dwGroupIPAddress);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, IgmpTypeToString(oReportType));
        }
      } else {
        if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_REPETITIVE))
        {
          /*IGMP_PROXY_DBGP(REPETITIVE,"IgmpProxyRcv: cannot join the group %ld.%ld.%ld.%ld (%s)\n",
                        IPADDRDISPLAY((*ppxMcastGroup)->dwGroupIPAddress),
                        IgmpTypeToString(oReportType));*/
          DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "IgmpProxyRcv: cannot join the group ", (*ppxMcastGroup)->dwGroupIPAddress);
          DEBUG_PRINTNL(DEBUG_MOC_IPV4, IgmpTypeToString(oReportType));
        }
      }
    } else {
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IGMP, INET_DBG_LEVEL_ERROR))
      {
        /*IGMP_PROXY_DBGP(ERROR,"IgmpProxyRcv: too many groups, discard report\n");*/
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IgmpProxyRcv: too many groups, discard report");
      }
      return -1;
    }
  }
  return 0;
}

#endif /*#ifdef STACK_MULTICAST_ROUTER*/
