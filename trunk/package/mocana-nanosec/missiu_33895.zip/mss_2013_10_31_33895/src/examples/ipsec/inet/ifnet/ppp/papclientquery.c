/*
 * papclient.c
 *
 * PAP (Challenge Handshake Authentification Protocol) client
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include "NNstyle.h"

#include "papclient_flavor.h"
#include "string.h"
#include "stdlib.h"
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h> /* ntoh macros */
#include <netinet/in.h> /* ntoh macros on Linux/Solaris */
#include <pthread.h>
/* #include <mqueue.h> */
#include <stdio.h>
#include "netcommon.h"
#include "netutils.h"
#include "nettime.h"
#include "papclient.h"

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * PapInstanceQuery
 *   Query PAP options
 *
 *   Args:
 *     hPap           Handle to the instance to destroy
 *     oOptio          Option code
 *     phData          data handle
 *
 *   Return:
 *     >=0
 */
LONG PapInstanceQuery(H_NETINSTANCE hPap,OCTET oOption,H_NETDATA * phData)
{
  /* Nothing for now */
  return NETERR_NOERR;
}

