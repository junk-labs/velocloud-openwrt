/*
 * ethdbg.h
 *
 * Ethernet module common debug macros
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _ETHDRVDBG_H_
#define _ETHDRVDBG_H_

#ifndef NDEBUG

 #ifdef NETDBG_HI

  #ifndef ETHERDRVNETDBG_HI
   #define ETHERDRVNETDBG_HI
  #endif
 #endif

#else
 #ifdef ETHERDRVNETDBG_HI
  #undef ETHERDRVNETDBG_HI
 #endif
#endif

#include "netdbg.h"

#define ETHDRV_MAGIC_COOKIE 0x65746863 /*"ethd" = 0x69746863*/

/*#ifdef ETHERDRVNETDBG_HI*/
#if defined(ETHERDRVNETDBG_HI) && defined(__ENABLE_MOCANA_DEBUG_CONSOLE__)

  #define ETHDRV_CHECK_STATE(x) \
            ASSERT(((x) != NULL) && ((x)->dwMagicCookie == ETHDRV_MAGIC_COOKIE));

  #define ETHDRV_SET_COOKIE(x) (x)->dwMagicCookie = ETHDRV_MAGIC_COOKIE
  #define ETHDRV_UNSET_COOKIE(x) (x)->dwMagicCookie = 0

  #define ETHDRV_DBGP(level, fmt, args...) do { \
    if (level <= g_dwEthDrvDebugLevel) {  \
      printf(fmt, ##args);    \
    }       \
  } while (0)

  #define ETHDRV_DBG(level, x) do {  \
    if (level <= g_dwEthDrvDebugLevel) {  \
      x;      \
    }       \
  } while (0)

  #define ETHDRV_DBG_VAR(x)  x

  #define ETHDRV_CHECKPOINT(x) (x = __LINE__)

  #define ETHDRV_ASSERT(x) ASSERT(x)

#else
  #define ETHDRV_CHECK_STATE(x)
  #define ETHDRV_SET_COOKIE(x)
  #define ETHDRV_UNSET_COOKIE(x)
  #define ETHDRV_DBGP(level, fmt, args...)
  #define ETHDRV_DBG(level, x)
  #define ETHDRV_DBG_VAR(x)
  #define ETHDRV_CHECKPOINT(x)
  #define ETHDRV_ASSERT(x)
#endif

ETHDRV_DBG_VAR(MOC_EXTERN int g_dwEthDrvDebugLevel);

#define ERROR      1
#define NORMAL     2
#define REPETITIVE 3

#endif /* #ifndef _ETHDRVDBG_H_ */
