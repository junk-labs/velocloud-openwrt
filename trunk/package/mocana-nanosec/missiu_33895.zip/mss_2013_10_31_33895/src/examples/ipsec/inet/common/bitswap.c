/*
** Compute the H.223-M Bit Swapping Lib
**
**
** Hossein Sedarat   Jan 99
*/
#include <NNstyle.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "ecc.h"

static OCTET aoBitPos[8] = {0x1, 0x2, 0x4, 0x8, 0x10, 0x20, 0x40, 0x80};

/*      Puncturing Tables		*/
static OCTET aoPuncTable[8] = {
/*
        0x80, 0x08, 0x20, 0x02, 0x40, 0x04, 0x10, 0x01
*/
        0x01, 0x10, 0x04, 0x40, 0x02, 0x20, 0x08, 0x80
 };

static OCTET aoIntlvDelta[256] = {
  0,   4,   4,   6,   8,   8,   8,   8,   8,   9,  10,  11,  12,  13,  14,  12, 
 16,  17,  12,  19,  16,  14,  16,  23,  16,  20,  16,  18,  16,  29,  16,  31, 
 16,  22,  17,  20,  18,  37,  19,  24,  20,  41,  21,  43,  22,  20,  23,  47, 
 24,  28,  20,  24,  26,  53,  24,  22,  28,  24,  29,  59,  24,  61,  31,  24, 
 32,  26,  24,  67,  32,  24,  28,  71,  24,  73,  37,  25,  32,  28,  26,  79, 
 32,  27,  41,  83,  28,  34,  43,  29,  32,  89,  30,  28,  32,  31,  47,  38, 
 32,  97,  28,  33,  32, 101,  34, 103,  32,  30,  53, 107,  32, 109,  40,  37, 
 32, 113,  38,  40,  32,  36,  59,  34,  32,  44,  61,  41,  32,  40,  36, 127, 
 32,  43,  40, 131,  33,  38,  67,  36,  34, 137,  46, 139,  35,  47,  71,  44, 
 36,  40,  73,  42,  37, 149,  40, 151,  38,  36,  44,  40,  39, 157,  79,  53, 
 40,  46,  36, 163,  41,  40,  83, 167,  42,  52,  40,  38,  43, 173,  48,  40, 
 44,  59,  89, 179,  40, 181,  52,  61,  46,  40,  48,  44,  47,  42,  40, 191, 
 48, 193,  97,  40,  49, 197,  44, 199,  40,  67, 101,  56,  48,  41, 103,  46, 
 52,  44,  42, 211,  53,  71, 107,  43,  48,  56, 109,  73,  44,  52,  48, 223, 
 56,  45, 113, 227,  48, 229,  46,  44,  58, 233,  48,  47,  59,  79,  56, 239, 
 48, 241,  44,  54,  61,  49,  48,  52,  62,  83,  50, 251,  48,  46, 127,  51
};

/*
  Scrambles/Descrambles the bits in the redundant bit stream 
  of the rate-compatible convoluitonal encoder according to 
  the puncturing rule of H.223M.

  'poDeScrambled' points to the bit stream to be scrambled and 
  'poScrambled' points to the scrambled bits. 'dwLen' is the 
  the size of stream in bytes.

  The reordering is done for bits corresponding to the starting 
  bit rate of (oRateS+1)/8 to ending rate of oRateE/8, where
  0 <= oRateS < oRateE <= 8
  
  when 'oDir' is 0 generates the scrambled bits, otherwise it 
  generates the descrambled bits.
*/
OCTET *H223MPuncture( OCTET *poDeScrambled, OCTET *poScrambled, 
					  DWORD dwLen, OCTET oRateS, OCTET oRateE, OCTET oDir )
{
  OCTET o, oMask;
  DWORD dw1, dw2, dw3;

  /* size of scrambled stream in bytes */
  dw3 = (dwLen*(oRateE-oRateS)) >> 3; 
  if (((dwLen*(oRateE-oRateS)) & 0x7) > 0) dw3++;

  if (0 == oDir) {
	for (dw1=0; dw1<dw3; dw1++) poScrambled[dw1] = 0;
	for (dw1=0; dw1<dwLen; dw1++) {
	  for (o=oRateS, dw2=dw1; o<oRateE; o++, dw2 += dwLen) 
		if ((poDeScrambled[dw1] & aoPuncTable[o]) > 0)
		  poScrambled[dw2 >> 3] |= aoBitPos[dw2 & 0x7];
	}
  } else {
	oMask = 0xFF;
	for (o=oRateS; o<oRateE; o++) oMask ^= aoPuncTable[o];
	for (dw1=0; dw1<dwLen; dw1++) {
	  poDeScrambled[dw1] &= oMask;
	  for (o=oRateS, dw2=dw1; o<oRateE; o++, dw2 += dwLen) 
		if ((poScrambled[dw2 >> 3] & aoBitPos[dw2 & 0x7]) > 0)
		  poDeScrambled[dw1] |= aoPuncTable[o];
	}
  }

  return &poScrambled[dw3];
}



/*
  Bit interleaving/de-interleaving as spelled out in H.223M.
  dwLen is the size of data in bytes.

  When oDir=0, it generates the interleaved data poInterleaved
  from non-interleaved data poDeInterleaved. Does the reverse,
  otherwise.

  Limitaion: dwLen<256 !
*/
void H223MInterleave( OCTET *poDeInterleaved, OCTET *poInterleaved, 
					  DWORD dwLen, OCTET oDir )
{
  DWORD dw1, dw2, dwBitLen, dwDelta;

  assert( dwLen < 256 );
  dwDelta = (DWORD)aoIntlvDelta[dwLen];

  dwBitLen = dwLen << 3;

  if (0 == oDir) { 
	for (dw1=0; dw1<dwLen; dw1++) poInterleaved[dw1] = 0;
	for (dw1=0, dw2=0; dw1<dwBitLen; dw1++, dw2+=dwDelta) {
	  if (dw2 >= dwBitLen) dw2 -= (dwBitLen-1);
	  if( (poDeInterleaved[dw1 >> 3] & aoBitPos[dw1 & 0x7]) > 0 ) 
		poInterleaved[dw2 >> 3] |= aoBitPos[dw2 & 0x7];
	}
  } else {
	for (dw1=0; dw1<dwLen; dw1++) poDeInterleaved[dw1] = 0;
	for (dw1=0, dw2=0; dw1<dwBitLen; dw1++, dw2+=dwDelta) {
	  if (dw2 >= dwBitLen) dw2 -= (dwBitLen-1);
	  if( (poInterleaved[dw2 >> 3] & aoBitPos[dw2 & 0x7]) > 0 )
		poDeInterleaved[dw1 >> 3] |= aoBitPos[dw1 & 0x7];
	}
  }

}

