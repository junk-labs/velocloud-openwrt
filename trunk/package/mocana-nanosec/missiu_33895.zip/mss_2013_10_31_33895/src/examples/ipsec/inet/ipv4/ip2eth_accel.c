/*
 * ip2eth.c
 *
 * IP to Ethernet module (using ARP)
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/

#include "ip2eth_defs.h"

/*****************************************************************************
 *
 * debug
 *
 *****************************************************************************/

#ifndef NDEBUG
  DWORD dbg_dwIp2EthArpResolving = 0;
#endif /*#ifndef NDEBUG*/

/*****************************************************************************
 *
 * local funcion
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * API
 *
 *****************************************************************************/

/*
 * Ip2EthInstanceRcv
 *  Ip2Eth Instance Rcv function
 *   Ip2Eth Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIp2Eth                    Instance Handle
 *    hIf                        Interface handle
 *    pxNetPacket                   packet
 *    wOffset                    IP PDU offset.
 *    hData                      unused
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG Ip2EthInstanceRcv(H_NETINSTANCE hIp2Eth,
                       H_NETINTERFACE hIf,
                       NETPACKET *pxNetPacket,
                       NETPACKETACCESS* pxNetPacketAccess,
                       H_NETDATA hData)
{
  IP2ETHSTATE *pxIp2Eth;
  ARPENTRY xArpEntry;
  OCTET *poSrcIpAddr;

  NETIFID xNetIfId;
  ETHID *pxEthId = (ETHID*)hData;

  pxIp2Eth = (IP2ETHSTATE *)hIp2Eth;
  IP2ETH_CHECK_STATE(pxIp2Eth);
  NETPACKET_CHECK(pxNetPacket);
  IP2ETH_ASSERT(pxEthId != NULL);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP2ETH, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IP2ETH_DBGP(REPETITIVE,"Ip2EthInstanceRcv\n");*/
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "Ip2EthInstanceRcv");
  }

  xNetIfId.oIfIdx = pxEthId->oIfIdx;
  xNetIfId.wVlan = pxEthId->wVlan;

#if 1
  xArpEntry.oIfIdx = pxEthId->oIfIdx;
  xArpEntry.wVlan = pxEthId->wVlan;
  xArpEntry.eArpFlag = E_ARPDYNAMIC;

  /*copy the source hw address*/
  MOC_MEMCPY((ubyte *)xArpEntry.aoEthAddr,(ubyte *)pxEthId->aoAddr,
                (ubyte4)ETHADDRESS_LEN);

  /*Find out the source ip address*/
  poSrcIpAddr = (pxNetPacket->pxPayload->poPayload +
                 pxNetPacketAccess->wOffset+
                 IPHDR_SOURCE_IPADDRESS_OFFSET);


  MOC_MEMCPY((ubyte *)&(xArpEntry.dwIpAddr),
                (ubyte *)poSrcIpAddr,
                sizeof(DWORD));

  /*convert the address from network to host bytes ordering*/
  xArpEntry.dwIpAddr = ntohl(xArpEntry.dwIpAddr);

  /*Add the arp request to the arp table*/
  (LONG)ArpInstanceMsg(pxIp2Eth->hArp,(OCTET)ARPMSG_ADD,
                       (H_NETDATA)&xArpEntry);


#endif
  return(pxIp2Eth->pfnRxCbk(pxIp2Eth->hIpInst,
                            hIf,
                            pxNetPacket,
                            pxNetPacketAccess,
                            (H_NETDATA)&xNetIfId));
}

/*
 * Ip2EthInstanceWrite
 *  Ip2Eth Instance Write function. Follows PFN_NETWORKWRITE
 *  typedef.
 *
 *  Args:
 *   hIp2Eth                     Ip2Eth Instance handle
 *   hIf                         interface handle
 *   pxNetPacket                    Packet pointer
 *   wOffset                     Link protocol PDU Offset
 *   hData                       Dest IP address (DWORD)
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */

LONG Ip2EthInstanceWrite(H_NETINSTANCE hIp2Eth,
                         H_NETINTERFACE hIf,
                         NETPACKET *pxNetPacket,
                         NETPACKETACCESS* pxNetPacketAccess,
                         H_NETDATA hData)
{

  IP2ETHSTATE *pxIp2Eth = (IP2ETHSTATE *)hIp2Eth;
  ARPREQUEST xArpRequest;
  NETPAYLOAD *pxPayload;
  OCTET *poPayload;
  NETIFID *pxNetIfId;
  ETHID xEthId;
  LONG lRv;

  IP2ETH_CHECK_STATE(pxIp2Eth);
  NETPACKET_CHECK(pxNetPacket);
  IP2ETH_ASSERT(pxNetPacketAccess != NULL);

  pxPayload = pxNetPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  pxNetIfId = (NETIFID*)hData;
  ASSERT(hData != 0);

  xEthId.oIfIdx   = pxNetIfId->oIfIdx;
  xEthId.wVlan = pxNetIfId->wVlan;

  xArpRequest.xEntry.oIfIdx   = pxNetIfId->oIfIdx;
  xArpRequest.xEntry.wVlan    = pxNetIfId->wVlan;
  xArpRequest.dwGatewayAddr = pxNetIfId->dwGatewayAddr;
  xArpRequest.eAddrType = pxNetIfId->eDstAddrType;

  /*Find out the destination ip address*/
  xArpRequest.xEntry.dwIpAddr = pxNetIfId->dwDstIpAddr;

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IP2ETH, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IP2ETH_DBGP(REPETITIVE,
              "Ip2EthInstanceWrite:resolving  %ld.%ld.%ld.%ld \n",
              IPADDRDISPLAY(xArpRequest.xEntry.dwIpAddr));*/
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, "Ip2EthInstanceWrite:resolving ", xArpRequest.xEntry.dwIpAddr);
    DEBUG_PRINT(DEBUG_MOC_IPV4, " Dst Addr Type ");
    DEBUG_INT(DEBUG_MOC_IPV4, xArpRequest.eAddrType );
    DEBUG_PRINTSTR1ASCIPADDR1(DEBUG_MOC_IPV4, " gateway Addr ", xArpRequest.dwGatewayAddr);
    DEBUG_PRINT(DEBUG_MOC_IPV4, " IfIdx ");
    DEBUG_INT(DEBUG_MOC_IPV4, xArpRequest.xEntry.oIfIdx);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /*Send ARPMSG_RESOLVE to the arp module*/
  lRv = ArpInstanceMsg(pxIp2Eth->hArp,ARPMSG_RESOLVE,(H_NETDATA)&xArpRequest);

  if( lRv == NETERR_NOERR){
    MOC_MEMCPY((ubyte *)xEthId.aoAddr,
                  (ubyte *)xArpRequest.xEntry.aoEthAddr,
                  ETHADDRESS_LEN);

    /*The destination ethernet address is in the cache*/
    IP2ETH_ASSERT(pxIp2Eth->pfnLLWrite != NULL);

    return pxIp2Eth->pfnLLWrite(pxIp2Eth->hEthInst,
                                pxIp2Eth->hEthIf,
                                pxNetPacket,
                                pxNetPacketAccess,
                                (H_NETDATA)&xEthId);

  }
  else if( lRv == ARPRCODE_RESOLVING ){
    /*The destination ethernet address is NOT in the cache*/
    /*packet and packet information need to be stored in pxPendingArp*/
    DEBUG(dbg_dwIp2EthArpResolving++);
    if(DLLIST_count_inline(&pxIp2Eth->dllPendingArp) < ARP_PENDING_PACKET_MAX ){
      ARPPENDING *pxPendingArp = (ARPPENDING*)MALLOC(sizeof(ARPPENDING));
      ASSERT(pxPendingArp != NULL);
      /*copy the destination ip address*/
      pxPendingArp->dwDstIpAddr = xArpRequest.xEntry.dwIpAddr;

      /*copy the netpacket access*/
      MOC_MEMCPY((ubyte *)&pxPendingArp->xNetPacket,
                    (ubyte *)pxNetPacket,
                    sizeof(NETPACKET));

      /*copy the netpacket access*/
      MOC_MEMCPY((ubyte *)&pxPendingArp->xNetPacketAccess,
                    (ubyte *)pxNetPacketAccess,
                    sizeof(NETPACKETACCESS));

      /*copy the netifid*/
      MOC_MEMCPY((ubyte *)&pxPendingArp->xNetIfId,
                    (ubyte *)pxNetIfId,
                    sizeof(NETIFID));

      /*Add pxPendingArp to the pending arp dll*/
      (void*)DLLIST_append(&pxIp2Eth->dllPendingArp,(void*)pxPendingArp);

      return NETERR_NOERR;

    } else {
      /*The dll is full*/
      lRv = -1;
    }
  }
  else {
    /*ArpInstanceMsg return an error*/
    lRv =  NETERR_BADVALUE;
  }

  NETPAYLOAD_DELUSER(pxNetPacket->pxPayload);

  return lRv;
}

