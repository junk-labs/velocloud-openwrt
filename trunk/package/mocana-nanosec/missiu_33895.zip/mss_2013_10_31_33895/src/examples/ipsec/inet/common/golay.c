/*
** Compute the H.223 eGolay (24, 12, 8) coder/decoder.
**
**
** Hossein Sedarat   Nov 98
*/

#include <NNstyle.h>
#include <stdlib.h>
#include <stdio.h>

#include "ecc.h"

#include "weight.h"

#define DIM 12
#define CODLEN 24
#define REDND (CODLEN-DIM)



/* the parity check matrices */
static DWORD adwH1[CODLEN] = { 0x800000,  0x400000,  0x200000,  0x100000, 
							   0x080000,  0x040000,  0x020000,  0x010000, 
							   0x008000,  0x004000,  0x002000,  0x001000, 
							   0xE3A000,  0xB1D000,  0x7B4000,  0x3DA000, 
							   0x1ED000,  0xECC000,  0xB66000,  0x9B3000, 
							   0x6E3000,  0xD4B000,  0x49F000,  0xC75000 };

static DWORD adwH2[CODLEN] = { 0x000C75,  0x000A4F,  0x000F68,  0x0007B4, 
							   0x0003DA,  0x0001ED,  0x000AB9,  0x000F13, 
							   0x000DC6,  0x0006E3,  0x00093E,  0x00049F, 
							   0x000800,  0x000400,  0x000200,  0x000100, 
							   0x000080,  0x000040,  0x000020,  0x000010, 
							   0x000008,  0x000004,  0x000002,  0x000001 };

static DWORD eye[CODLEN]  = { 0x800000,  0x400000,  0x200000,  0x100000, 
							  0x080000,  0x040000,  0x020000,  0x010000, 
							  0x008000,  0x004000,  0x002000,  0x001000, 
							  0x000800,  0x000400,  0x000200,  0x000100, 
							  0x000080,  0x000040,  0x000020,  0x000010, 
							  0x000008,  0x000004,  0x000002,  0x000001 };

/*
   generates the redundant vector wR for
   the input data vector wD. The final 
   codeword is the concatenation of wD 
   and wR.
*/
DWORD EccGolayEncoder( WORD wD )
{
  DWORD dwR;
  int i;
  
  dwR = 0;
  for (i=REDND; i<CODLEN; i++)
	if (0 != (wD & eye[i])) dwR ^= adwH1[i];

  return dwR;
}


/*
  pdwCode is the codeword to be corrected.

  returns  0 if no error in the data part, 
           1 if recoverable error, and
		  -1 if unrecoverable error.
*/
int EccGolayDecoder( DWORD *pdwCode )
{
  int i, j, iW;
  DWORD dwSyndrom1, dwSyndrom2;
  DWORD dwCode;

  dwCode = *pdwCode;

  dwSyndrom1 = 0;
  dwSyndrom2 = 0;
  for (i=0; i<CODLEN; i++) {
	if (0 != (dwCode & eye[i])) dwSyndrom1 ^= adwH1[i];
	if (0 != (dwCode & eye[i])) dwSyndrom2 ^= adwH2[i];
  }

  iW = WEIGHT32( dwSyndrom1 );
/*
if( iW!=0 )	printf("input = %x    output = %x   syndrom1 = %x   weight = %d\n",(int)(dwCode&0x7f), (int)dwCode, (int)dwSyndrom1, iW);
iW = WEIGHT32( dwSyndrom2 );
if( iW!=0 )	printf("input = %x    output = %x   syndrom2 = %x   weight = %d\n",(int)(dwCode&0x7f), (int)dwCode, (int)dwSyndrom2, iW);
return 0;
*/

  if (iW <= 3) {
	*pdwCode ^= dwSyndrom1;
	return 0;
  }

  iW = WEIGHT32( dwSyndrom2 );
  if (iW <= 3) {
	*pdwCode ^= dwSyndrom2;
	return 1;
  }

  for (i=0, j=REDND; i<DIM; i++, j++) {
	if (WEIGHT32(dwSyndrom1 ^ adwH1[j]) <= 2) {
	  *pdwCode ^= (dwSyndrom1 ^ adwH1[j]);
	  *pdwCode ^= eye[j];
	  return 1;
	}
	if (WEIGHT32(dwSyndrom2 ^ adwH2[i]) <= 2) {
	  *pdwCode ^= (dwSyndrom2 ^ adwH2[i]);
	  *pdwCode ^= eye[i];
	  return 1;
	}
  }

  return -1;
}
