/*
 * ipsec_accel.c
 *
 * IPSec interface to network stack
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "ipsec_defs.h"

IPSEC_DBG_VAR(DWORD dwIPSecDropped = 0);


/*
 * _IPSecNetworkIdFill
 *  Fill Network Id info.
 *
 *  Args:
 *   hIp                        Instance handle
 *   pxPacket                   Packet pointer
 *   pxIpHdr                    pointer to IP header
 *   pxNetworkId                pointer to a net_dst structure
 *
 */
static void _IPSecNetworkIdFill(H_NETINSTANCE hInst,
                                IPHDR *pxIpHdr,
                                NETWORKID *pxNetworkId)
{
  /* should update NetworkID data from transformed IP header */
  pxNetworkId->oIpHdrLen = (pxIpHdr->oIpHdrLen&0x0F) << 2;
  pxNetworkId->dwDstAddr = (pxIpHdr->dwDstAddr);
  pxNetworkId->dwSrcAddr = (pxIpHdr->dwSrcAddr);
  pxNetworkId->oToS = pxIpHdr->oToS;
  pxNetworkId->wTotalLen = ntohs(pxIpHdr->wTotalLen);
  pxNetworkId->wFragOffset = ntohs(pxIpHdr->wFragOffset);
  pxNetworkId->oTtL = ntohs(pxIpHdr->oTtL);
  pxNetworkId->oProtocol = pxIpHdr->oProtocol;
  pxNetworkId->wDatagramId = ntohs(pxIpHdr->wDatagramId);

  /*The options start here. */
  if( pxNetworkId->oIpHdrLen > (OCTET)IPDEFAULT_HDRSIZE){
    pxNetworkId->poIpOption = (OCTET*)pxIpHdr + IPDEFAULT_HDRSIZE;
    pxNetworkId->oIpOptionLen = pxNetworkId->oIpHdrLen - IPDEFAULT_HDRSIZE;
  } else {
    pxNetworkId->poIpOption = NULL;
    pxNetworkId->oIpOptionLen = 0;
  }

  pxNetworkId->bTunnelled = TRUE;
}

/*
 * IPSecInstanceRcv
 *   Decode IPSec headers and do necessary processing for AH and/or ESP,
 *     - Follows PFN_NETWORRXCBK def.
 *     - reconstruct packet with the decoded results and call right pfnRxCbk.
 *
 *       hInst     : IPSec instance handle
 *       hLLIf     : Interface on which the data is received,
 *                   in the receiving module.
 *       pxPacket  : packet pointer
 *       pxAccess  : NETPACKETACCESS pointer
 *       hData     : Out-of-Band data associated with the
 *                   received packet. SHOULD NOT BE USED
 *                   for signaling. Each layer will defined
 *                   what it is
 *  ret:
 *       Number of effectively received bytes (including the offset) or <0
 *       (error. see NETERR_XXX definitions and/or module APIs)
 */
LONG IPSecInstanceRcv(H_NETINSTANCE hInst,
                      H_NETINTERFACE hLLIf,
                      NETPACKET *pxPacket,
                      NETPACKETACCESS *pxAccess,
                      H_NETDATA hData)
{
  IPSECSTATE *pxIPSec     = (IPSECSTATE *)hInst;
  NETPAYLOAD *pxPayload;
  NETWORKID  *pxNetworkId = (NETWORKID *)hData;
  OCTET      *poPayload;
  WORD       wOffset;
  IPHDR      *pxIpHdr;
  WORD         wOrgIPLen=0;
  DWORD         status;

  IPSEC_CHECK_STATE(pxIPSec);

  IPSEC_ASSERT(pxPacket != NULL);
  IPSEC_ASSERT(pxAccess != NULL);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IPSEC_DBGP(REPETITIVE, "IPSec: IPSecInstanceRcv()\n");*/
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, "IPSec: IPSecInstanceRcv()");
  }

  /*Check if the offset is DWORD aligned*/
  IPSEC_ASSERT( (pxAccess->wOffset % sizeof(DWORD)) == 0);

  /* bypass if LAN leg */
  if (pxNetworkId->oIfIdx==pxIPSec->oIfIdxLan) {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IPSEC_DBGP(REPETITIVE,">>> From LAN: %lx->%lx\n",
        pxNetworkId->dwSrcAddr, pxNetworkId->dwDstAddr);*/
      DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ">>> From LAN: ", pxNetworkId->dwSrcAddr,
                             " -> ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
    return pxIPSec->pfnRxCbk(pxIPSec->hULInst,
                             pxIPSec->hULIf,
                             pxPacket,
                             pxAccess,
                             hData);
  }

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IPSEC_DBGP(REPETITIVE,">>> From WAN: %lx->%lx\n",
      pxNetworkId->dwSrcAddr, pxNetworkId->dwDstAddr);*/
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ">>> From WAN: ", pxNetworkId->dwSrcAddr,
                           " -> ", pxNetworkId->dwDstAddr);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  /*Set the NetPayload and the Payload*/
  pxPayload = pxPacket->pxPayload;
  IPSEC_ASSERT(pxPayload);
  poPayload = pxPayload->poPayload;
  IPSEC_ASSERT(poPayload);

  /*Set the offset*/
  wOffset = pxAccess->wOffset;

  /*Set the pointer to the ip header*/
  pxIpHdr = (IPHDR*)(poPayload + wOffset);
  /* save original ip packet length for later calculating */
  /* octets removed by IPSec processing */
  wOrgIPLen=ntohs(pxIpHdr->wTotalLen);

  status = IPSEC_permit(pxIpHdr, pxAccess->wLength, &wOffset);
  if ( status != OK && status != STATUS_IPSEC_BYPASS){
    /* discard according to security policy */
    IPSEC_DBG_VAR(dwIPSecDropped++;)
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IPSEC_DBGP(REPETITIVE,">>> Dropping: %lx->%lx\n",
        pxNetworkId->dwSrcAddr, pxNetworkId->dwDstAddr);*/
      DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ">>> Dropping: ", pxNetworkId->dwSrcAddr,
                             " -> ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
/*    SNMP( xTcpipData.ifNum[ETH_SNMP_IF_NUM].ifInSecurityFail++ ); */
    NETPAYLOAD_DELUSER(pxPayload);
    return NETERR_UNKNOWN;    /* << NETERR_SECURITYFAIL */
  }

  /* update NetworkId data from transformed IP header */
  _IPSecNetworkIdFill(hInst, pxIpHdr, pxNetworkId);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IPSEC_DBGP(REPETITIVE,">>> From WAN SECU: %lx->%lx\n",
      pxNetworkId->dwSrcAddr, pxNetworkId->dwDstAddr);*/
      DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ">>> From WAN SECU: ", pxNetworkId->dwSrcAddr,
                             " -> ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);

  }
  /* update address type field */
  {
      IPTABLEENTRY xIpEntry;

      xIpEntry.dwAddr = pxNetworkId->dwDstAddr;
      xIpEntry.oIfIdx = NETIFIDX_ANY;
      xIpEntry.wDefaultVlan = NETVLAN_ANY;

      pxNetworkId->eDstAddrType =
        IpTableMsg(IPTABLEMSG_GETTYPE,(H_NETDATA)&xIpEntry);
  }

  /* update offset to point correct location for ip header */
  pxAccess->wOffset = ((OCTET*)pxIpHdr - poPayload);

  /* update length */
  pxAccess->wLength -= (wOrgIPLen - ntohs(pxIpHdr->wTotalLen));



  IPSEC_ASSERT(pxIPSec->pfnRxCbk != NULL);

  return pxIPSec->pfnRxCbk(pxIPSec->hULInst,
                           pxIPSec->hULIf,
                           pxPacket,
                           pxAccess,
                           hData);
}

/*
 * IPSecInstanceWrite
 *   Construct packets by adding authentication header and ESP
 *   based on the SA found from destination IP address.
 *
 *      hInst       IPSec instance handle
 *      hULIf       Interface to which the packet is given.
 *      pxPacket    packet pointer
 *      pxAccess    NETPACKETACCESS pointer
 *      hData       Destination identification,
 *                  as understood by the written-to
 *                  protocol
 *
 * ret: -1: if fail
 *       n: updated IP payload length(not include outer most IP header length)
 */
LONG IPSecInstanceWrite(H_NETINSTANCE hInst,
                        H_NETINTERFACE hULIf,
                        NETPACKET *pxPacket,
                        NETPACKETACCESS *pxAccess,
                        H_NETDATA hData)
{
  LONG lReturn=0;
  IPSECSTATE *pxIPSec = (IPSECSTATE *)hInst;
  NETWORKID *pxNetworkId = (NETWORKID*)hData;
  /* pxNetworkId is being used to keep connection in the upper layer */
  /* therefore, the newly generated IP information should be stored into */
  /* new network id structure and sent down to lower layer */
  NETWORKID *pxNetworkIdMod = NULL;
  IPHDR *pxIpHdr=NULL;
  struct spdb* pxSP=NULL;
  NETPAYLOAD *pxPayload;
  OCTET* poPayload;
  OCTET* poIpPayload=NULL;
  WORD wLength=0;
  DWORD status;

  IPSEC_CHECK_STATE(pxIPSec);
  NETPACKET_CHECK(pxPacket);
  pxPayload = pxPacket->pxPayload;
  poPayload = pxPayload->poPayload;

  /* bypass if LAN leg */
  if (pxNetworkId->oIfIdx==pxIPSec->oIfIdxLan) {
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IPSEC_DBGP(REPETITIVE,">>> To LAN: %lx->%lx\n",
        pxNetworkId->dwSrcAddr, pxNetworkId->dwDstAddr);*/
      DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ">>> To LAN: ", pxNetworkId->dwSrcAddr,
                             " -> ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }

    return pxIPSec->pfnLLWrite(pxIPSec->hLLInst,
                               pxIPSec->hLLIf,
                               pxPacket,
                               pxAccess,
                               hData);
  }

  /* set the pointer to the start of IP payload */
  poIpPayload = (OCTET *)(poPayload + pxAccess->wOffset);

  /* Recover the Security Policy data structure and other info */
  /* transferred inband from upper layer:sendto() */
  pxSP = IPSecGetSP(pxNetworkId->dwDstAddr,
                    TRANSPORT_GET_DST_PORT((void*)poIpPayload),
                    pxNetworkId->dwSrcAddr,
                    TRANSPORT_GET_SRC_PORT((void*)poIpPayload),
                    pxNetworkId->oProtocol, 0);

  if (pxSP) {
    /* Do we have enough room to write the additional(maybe ipsec) headers ? */
    IPSEC_ASSERT(pxAccess->wOffset >= IPSecGetHdrLen(pxSP) + IPDEFAULT_HDRSIZE
                                      + ETHHEADER_LEN);

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IPSEC_DBGP(REPETITIVE,
               ">>> To WAN: %lx->%lx (%lx) Offset [%d > %d + headers]\n",
               pxNetworkId->dwSrcAddr, pxNetworkId->dwDstAddr,
               (DWORD)pxSP, pxAccess->wOffset, (WORD)IPSecGetHdrLen(pxSP));*/
      DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ">>> To WAN: ", pxNetworkId->dwSrcAddr,
                             " -> ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," ( 0x", (DWORD)pxSP );
      DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ") Offset [", pxAccess->wOffset, " > ", (WORD)IPSecGetHdrLen(pxSP));
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, " + headers]");
    }

    /* Check the DWORD alignment */
    IPSEC_ASSERT( (pxAccess->wOffset % sizeof(DWORD)) == 0);

    /* Set the ip header pointer */
    /* pxNetworkId->oIpHdrLen is OCTET count, not DWORD count */
    pxIpHdr = (IPHDR *)(poIpPayload - pxNetworkId->oIpHdrLen);

    status = IPSEC_apply(pxIpHdr, pxAccess->wLength + pxNetworkId->oIpHdrLen,
                            &wLength);
    if ( status != OK ){
      if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
      {
        /*IPSEC_DBGP(REPETITIVE,
               ">>> Dropping: %lx->%lx (%lx) Offset [%d > %d + headers]\n",
               pxNetworkId->dwSrcAddr, pxNetworkId->dwDstAddr,
               (DWORD)pxSP, pxAccess->wOffset, (WORD)IPSecGetHdrLen(pxSP));*/

        DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ">>> Dropping: ", pxNetworkId->dwSrcAddr,
                               " -> ", pxNetworkId->dwDstAddr);
        DEBUG_PRINTSTR1HEXINT1(DEBUG_MOC_IPV4," ( 0x", (DWORD)pxSP );
        DEBUG_PRINTSTR2INT2(DEBUG_MOC_IPV4, ") Offset [", pxAccess->wOffset, " > ", (WORD)IPSecGetHdrLen(pxSP));
        DEBUG_PRINTNL(DEBUG_MOC_IPV4, " + headers]");
      }

       NETPAYLOAD_DELUSER(pxPacket->pxPayload);
       return NETERR_UNKNOWN;    /* << NETERR_SECURITYFAIL */
    }

    pxNetworkIdMod= (NETWORKID*)MALLOC(sizeof(NETWORKID));
    /* copy contents of NETWORKID */
    MOC_MEMCPY((ubyte *)pxNetworkIdMod, (ubyte *)pxNetworkId, sizeof(NETWORKID));
    /* update NetworkId data from transformed IP header */
    _IPSecNetworkIdFill(hInst, pxIpHdr, pxNetworkIdMod);
    hData = (H_NETDATA)pxNetworkIdMod;

    /* update offset to the start of IP Payload */
    pxAccess->wOffset = poIpPayload - poPayload;

    /* update length (of IP payload) */
    pxAccess->wLength = wLength;

    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IPSEC_DBGP(REPETITIVE,">>> To WAN SECU: %lx->%lx\n",
                          pxNetworkIdMod->dwSrcAddr,
                          pxNetworkIdMod->dwDstAddr);*/
      DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, ">>> To WAN SECU: ", pxNetworkId->dwSrcAddr,
                             " -> ", pxNetworkId->dwDstAddr);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
  }

  IPSEC_ASSERT(pxIPSec->pfnLLWrite != NULL);

  lReturn = pxIPSec->pfnLLWrite(pxIPSec->hLLInst,
                                pxIPSec->hLLIf,
                                pxPacket,
                                pxAccess,
                                hData);

  /* free up temporally used network ID structure */
  /* no memcpy was used for transfering OCTET strings */
  /* so we can safely free() this, since the OCTET strings are used */
  /* by the original network id structure */
  if (pxNetworkIdMod) {
    FREE (pxNetworkIdMod);
  }

  return lReturn;
}
