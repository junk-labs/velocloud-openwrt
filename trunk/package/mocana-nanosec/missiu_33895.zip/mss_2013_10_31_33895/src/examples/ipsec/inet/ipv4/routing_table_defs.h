/*
 * routing_table_defs.h
 *
 * routing table module common definition
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


#ifndef __ROUTINGTABLEDEFS_H__
#define __ROUTINGTABLEDEFS_H__

/*****************************************************************************
 *
 * include
 *
 *****************************************************************************/

#include "NNstyle.h"
#include "routing_table_flavor.h"
#include "dllist.h"
#include "netcommon.h"
#include "netutils.h"
#include "netnetwork.h"
#include "iptable.h"
#include "routing_table.h"
#include "routing_table_dbg.h"
#include "netsnmp.h"
#include "ip.h"
#include "../include/socket.h"
#include "../include/in.h"
#include "../include/route.h"
#include "../include/inet.h"
#include "snmp_tcpip_data.h"

/*****************************************************************************
 *
 * define
 *
 *****************************************************************************/

/* RS added +ROUTINGTABLE_MAXNUM_IF to max num routes
 * - original 8 plus one default route for each interface
 */
#define ROUTINGTABLE_MAX_NUM_ROUTES  (8+ROUTINGTABLE_MAXNUM_IF)
#define    ROUTINGTABLE_MAX_NUM_STATIC_ROUTES  (8+ROUTINGTABLE_MAXNUM_IF)

#define ROUTINGTABLE_DEFAULT_DESTINATION 0x0
#define ROUTINGTABLE_DEFAULT_SUBNETMASK  0x0

/*****************************************************************************
 *
 * Structures & Typedefs
 *
 *****************************************************************************/

/*
 * Router instance structure
 */
typedef struct {

#ifndef NDEBUG
  DWORD dwMagicCookie;
#endif

#ifdef _RADIX_ROUTING_ON_
  RADIXNODEHEAD *pxRadixTree;
#else
  DLLIST dllRoute;
#endif

  ROUTEENTRY* pxBestDefaultGw;

  ROUTEENTRY* apxStaticRoutes[ROUTINGTABLE_MAX_NUM_STATIC_ROUTES];

  /* Flags - bit set indicates that corrisponding idx is bridged */
  DWORD dwfBridgedIdx;

  BOOL abIsLinkUp[ROUTINGTABLE_MAXNUM_IF];
} ROUTINGTABLESTATE;

/*****************************************************************************
 *
 * extern
 *
 *****************************************************************************/


ROUTINGTABLE_DBG_VAR(MOC_EXTERN BOOL g_bIPRouterDisplayRoutingTable;)

/*****************************************************************************
 *
 * Local functions
 *
 *****************************************************************************/


#endif /* #ifndef __ROUTINGTABLE_DEFS_H__ */
