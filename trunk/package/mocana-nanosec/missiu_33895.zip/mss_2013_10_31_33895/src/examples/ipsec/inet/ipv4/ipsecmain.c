/*
 * ipsecmain.c
 *
 * IPSec interface to network stack
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#include "ipsec_defs.h"

/*****************************************************************************
 *
 * Debug declarations
 *
 *****************************************************************************/

IPSEC_DBG_VAR(DWORD g_dwIPSecDebugLevel = REPETITIVE);

#ifdef SNMP
#undef SNMP
#endif
#define SNMP(x) /* get rid of SNMP bits */

/*****************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/

/*****************************************************************************
 *
 * Implementation
 *
 *****************************************************************************/
/*
 * IPSecInitialize
 *  Initialize the IPSec library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IPSecInitialize(void)
{
  /* Initialise the DEBUG symbol to ERROR */
  INET_DBG_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_ERROR);
  return NETERR_NOERR;
}

/*
 * IPSecTerminate
 *  Terminate the IPSec library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IPSecTerminate(void)
{
  return NETERR_NOERR;
}


/*
 * IPSecInstanceCreate
 *  Creates a IPSec Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IPSecInstanceCreate(void)
{
  IPSECSTATE *pxIPSec;

  /*Allocate memory for the the ip sec state*/
  pxIPSec = (IPSECSTATE *)MALLOC(sizeof(IPSECSTATE));
  if(pxIPSec == NULL){
    ASSERT(0);
    return (H_NETINSTANCE)NULL;
  }
  MOC_MEMSET((ubyte *)pxIPSec, 0, sizeof(IPSECSTATE));

  /*set the magic cookie*/
  IPSEC_SET_COOKIE(pxIPSec);

  return (H_NETINSTANCE)pxIPSec;
}

/*
 * IPSecInstanceDestroy
 *  Destroy a IPSec Instance
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IPSecInstanceDestroy(H_NETINSTANCE hIPSec)
{
  IPSECSTATE *pxIPSec = (IPSECSTATE *)hIPSec;
  IPSEC_CHECK_STATE(pxIPSec);


  IPSEC_UNSET_COOKIE(pxIPSec);

  FREE(pxIPSec);

  return 0;
}

/*
 * IPSecInstanceSet
 *  Set a IPSec Instance Option
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */

LONG IPSecInstanceSet(H_NETINSTANCE hIPSec,
                      OCTET oOption,
                      H_NETDATA hData)
{
  return NETERR_NOERR;
}

/*
 * IPSecInstanceQuery
 *  Query a IPSec Instance Option
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IPSecInstanceQuery(H_NETINSTANCE hIPSec,
                        OCTET oOption,
                        H_NETDATA *phData)
{
  return NETERR_NOERR;
}

/*
 * IPSecInstanceMsg
 *  Send a msg to a IPSec instance
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */

LONG IPSecInstanceMsg(H_NETINSTANCE hIPSec,
                      OCTET oMsg,
                      H_NETDATA hData)
{
  IPSECSTATE *pxIPSec = (IPSECSTATE *)hIPSec;

  LONG lReturn = NETERR_NOERR;

  IPSEC_CHECK_STATE(pxIPSec);
  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IPSEC_DBGP(REPETITIVE, "IPSecInstanceMsg: oMsg: %x\n", oMsg);*/
    DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "IPSecInstanceMsg: oMsg: ", oMsg);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oMsg) {
  case NETMSG_OPEN:
  case NETMSG_CLOSE:
  case NETMSG_LOWERLAYERUP:
  case NETMSG_LOWERLAYERDOWN:
    if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
    {
      /*IPSEC_DBGP(REPETITIVE, "Nothing to do in IPSec for msg: %x\n", oMsg);*/
      DEBUG_PRINTSTR1INT1(DEBUG_MOC_IPV4, "Nothing to do in IPSec for msg: ", oMsg);
      DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
    }
    break;
  case IPSECMSG_SETIFIDXLAN:
    pxIPSec->oIfIdxLan = (OCTET) hData;
    break;
  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
    break;
  }

  return lReturn;
}


/*
 * IPSecInstanceULInterfaceCreate
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hIPSec                       IPSec instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */

H_NETINTERFACE IPSecInstanceULInterfaceCreate(H_NETINSTANCE hIPSec)
{
  return (H_NETINTERFACE)1;
}

/*
 * IPSecInstanceULInterfaceDestroy
 *  Destroy a IPSec UL interface
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   hULIf                      Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */

LONG IPSecInstanceULInterfaceDestroy(H_NETINSTANCE hIPSec,
                                     H_NETINTERFACE hULIf)
{

  ASSERT(hULIf == (H_NETINTERFACE) 1);

  return NETERR_NOERR;
}

/*
 * IPSecInstanceULInterfaceIoctl
 *
 *  Args:
 *   hIPSec                      IPSec instance handle
 *   hULIf                        Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */

LONG IPSecInstanceULInterfaceIoctl(H_NETINSTANCE hIPSec,
                                   H_NETINTERFACE hULIf,
                                   OCTET oIoctl,
                                   H_NETDATA hData)
{
  IPSECSTATE *pxIPSec = (IPSECSTATE *)hIPSec;
  LONG lReturn = NETERR_NOERR;

  IPSEC_CHECK_STATE(pxIPSec);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IPSEC_DBGP(REPETITIVE, "IPSecInstanceULInterfaceIoctl: If: %x oIoctl: %x\n",(int)hULIf,oIoctl);*/
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "IPSecInstanceULInterfaceIoctl: If: ", (int)hULIf,
                           " oIoctl : ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch (oIoctl) {
  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* ignore those */
    break;
  case NETINTERFACEIOCTL_SETHINST:
    pxIPSec->hULInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIPSec->pfnRxCbk = (PFN_NETRXCBK)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIPSec->hULIf = (H_NETINTERFACE)hData;
    break;

  default:
    lReturn = NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lReturn;
}


/*
 * IPSecInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIPSec                IPSec instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */

H_NETINTERFACE IPSecInstanceLLInterfaceCreate(H_NETINSTANCE hIPSec)
{
  return (H_NETINTERFACE)1;
}

/*
 * IPSecInstanceLLInterfaceDestroy
 *  Destroy a IPSec LL interface
 *
 *  Args:
 *   hIPSec                    IPSec instance
 *   hLLIf                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */

LONG IPSecInstanceLLInterfaceDestroy(H_NETINSTANCE hIPSec,
                                     H_NETINTERFACE hLLIf)
{
  return NETERR_NOERR;
}

/*
 * IPSecInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hIPSec                      IPSec instance handle
 *   hULIf                        Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IPSecInstanceLLInterfaceIoctl(H_NETINSTANCE hIPSec,
                                   H_NETINTERFACE hLLIf,
                                   OCTET oIoctl,
                                   H_NETDATA hData)
{
  IPSECSTATE *pxIPSec = (IPSECSTATE *)hIPSec;
  LONG lRv = NETERR_NOERR;

  IPSEC_CHECK_STATE(pxIPSec);

  if(INET_DBG_IS_LEVEL_SET(INET_DBG_MOD_IPSEC, INET_DBG_LEVEL_REPETITIVE))
  {
    /*IPSEC_DBGP(REPETITIVE,
              "IPSecInstanceLLInterfaceIoctl: If:%x oIoctl: %x\n",
              (int)hLLIf,oIoctl);*/
    DEBUG_PRINTSTR2HEXINT2(DEBUG_MOC_IPV4, "IPSecInstanceLLInterfaceIoctl: If: ", (int)hULIf,
                           " oIoctl : ", oIoctl);
    DEBUG_PRINTNL(DEBUG_MOC_IPV4, NULL);
  }

  switch(oIoctl) {

  case NETINTERFACEIOCTL_OPEN:
  case NETINTERFACEIOCTL_CLOSE:
    /* Ignore these */
    break;

  case NETINTERFACEIOCTL_SETHINST:
    pxIPSec->hLLInst = (H_NETINSTANCE)hData;
    break;

  case NETINTERFACEIOCTL_SETOUTPUTPFN:
    pxIPSec->pfnLLWrite = (PFN_NETWRITE)hData;
    break;

  case NETINTERFACEIOCTL_SETIF:
    pxIPSec->hLLIf = (H_NETINTERFACE)hData;
    break;

  default:
    lRv = NETERR_UNKNOWN;
    ASSERT(0);
  }

  return lRv;
}




/*
 * IPSecInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hIPSec                        IPSec Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG IPSecInstanceProcess(H_NETINSTANCE hIPSec)
{
  /* Nothing to do here */
  return 0x7FFFFF;
}

/*
 * IPSecGetSP
 *   Find security policy from destination IP:port, source IP:port and
 *   protocol types
 *
 *      dwDestIP  : destination IP address
 *      wDestPort : destination port number
 *      dwSrcIP   : source IP address
 *      wSrcPort  : source port number
 *      oProto    : protocol type
 *
 * ret: pointer to security policy data structure
 *      0 if no SP found
 */
void* IPSecGetSP(DWORD dwDestIP, WORD wDestPort,
                 DWORD dwSrcIP, WORD wSrcPort, OCTET oProto, WORD inBound)
{
  return IPSEC_getSp(dwDestIP, dwSrcIP, 0, 0, oProto, 1, wDestPort, wSrcPort,
                     inBound);
}

/*
 * IPSecGetHdrLen
 *   Find corresponding SA from destination IP address, and
 *   calculate required header space
 *
 *      pxSP   : pointer to security policy data structure
 *
 * ret: 0 if no SA found
 *      n (total length of IPSec headers to be added) if SA found
 */
int IPSecGetHdrLen(void* pxSP)
{
  if (pxSP) {
    /*return ((struct spdb*)pxSP)->wIPSecHdrLen; */
    /* TBD!! need a corresponding API from IPSEC. For now return MAX */
    return 12 + /* max of AH hdr(12) and ESP hdr(8) */
           12; /* ICV len */
  }
  return 0;
}

/*
 * IPSecGetTrailLen
 *   Find corresponding SA from destination IP address, and
 *   calculate space for padding and authentication data
 *
 *      pxSP    : pointer to security policy data structure
 *      wLength : length of payload(including transport layer header)
 *
 * ret: 0 if no SA found
 *      n (total length of padding and auth data to be added) if SA found
 */
int IPSecGetTrailLen(void* pxSP, WORD wLength)
{
  /*SPDB *pxSpDb = (SPDB*)pxSP; */
  /*IPSEC_ASSERT(((int)pxSP & 0x3) == 0); */

  if (pxSP) {
    /*return (wLength % (pxSpDb->wIPSecEspMod) + pxSpDb->wIPSecTrailLen) ; */
    /* TBD!! need a corresponding API from IPSEC. For now return MAX */
    return 12; /* ICV len */

  }
  return 0;
}

/*
 * IPSecGetIfIdx
 *   Get Interface Index to use for this IPSec tunnel
 *
 *      pxSP   : pointer to security policy data structure
 *      oIfIdx : original ifIdx
 *
 * ret: 0 if error
 *      n interface index
 */
OCTET IPSecGetIfIdx(void* pxSP, OCTET oIfIdx)
{
  if (pxSP) {
    /*return ((struct spdb*)pxSP)->oIfIdx;
    // TBD: need corresponding API from IPSEC,
    // for now use ifIdx chosen by routing
    */
    return oIfIdx;
  }
  return 0;
}

/*
 * IPSecGetGateway
 *   Get gateway info to use for this IPSec tunnel
 *
 *      pxSP   : pointer to security policy data structure
 *      dwGateway : original gateway
 *
 * ret: 0 if error
 *      n gateway ip address
 */
DWORD IPSecGetGateway(void* pxSP, DWORD dwGateway)
{
  if (pxSP) {
    /*return ((struct spdb*)pxSP)->dwGateway;
    // TBD: need corresponding API from IPSEC,
    // for now use dwGateway chosen by routing
    */
    return dwGateway;
  }
  return 0;
}
