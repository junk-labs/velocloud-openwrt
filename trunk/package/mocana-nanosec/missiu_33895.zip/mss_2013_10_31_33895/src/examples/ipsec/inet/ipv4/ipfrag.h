/*
 * ipfrag.h
 *
 * IP fragmentation module API
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */

#ifndef _IPFRAG_H_
#define _IPFRAG_H_


/*
 * IpFrag option
 */

#define IPFRAGOPTION_MD  \
          NETOPTION_MODULESPECIFICBEGIN    /* Maximum Datagram Size. a Datagram is an
                                              unfragmented IP datagram. Datagram exceeding
                                              this limit will be tossed on the Rx size */
#define IPFRAGOPTION_TO  \
          NETOPTION_MODULESPECIFICBEGIN + 1
                                           /* Reassembly Time out. Any pending datagram
                                            which has not received a new packet in the
                                            Time out will be tossed */

#define IPFRAGOPTION_MTU  \
          (NETOPTION_MODULESPECIFICBEGIN + 2)  /*type parameter is MTUREQUEST*/


/*
 * IpFrag callback define
 */
#define IPFRAGCBK_TIME_EXCEEDED_FRAGTIME \
          (NETCBK_MODULESPECIFICBEGIN)

#define IPFRAGCBK_FRAG_NEEDED \
          (NETCBK_MODULESPECIFICBEGIN + 1)


/*****************************************************************************
 *
 * Constants
 *
 *****************************************************************************/
/*
 * IP Frag masking
 */
#define IPFRAGMASK_MF        0x2000
#define IPFRAGMASK_DF        0x4000
#define IPFRAGMASK_OFFSET    0x1FFF



/*****************************************************************************
 *
 * Structure & Typedefs
 *
 *****************************************************************************/

typedef struct{
  OCTET oIfIndex;
  WORD wMtu;
} MTUREQUEST;

/*****************************************************************************
 *
 * API functions
 *
 *****************************************************************************/

/*
 * IpFragInitialize
 *  Initialize the IP fragmentation library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpFragInitialize(void);

/*
 * IpFragTerminate
 *  Terminate the IP fragmentation library
 *
 *  Args:
 *
 *  Return:
 *   >=0
 */
LONG IpFragTerminate(void);

/*
 * IpFragInstanceCreate
 *  Creates a IP fragmentation Instance
 *
 *  Args:
 *
 *  Return:
 *   H_NETINSTANCE          Handle to the instance
 */
H_NETINSTANCE IpFragInstanceCreate(void);

/*
 * IpFragInstanceDestroy
 *  Destroy a IP fragmentation Instance
 *
 *  Args:
 *   hIp                       IP fragmentation instance
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpFragInstanceDestroy(H_NETINSTANCE hIp);

/*
 * IpFragInstanceSet
 *  Set a IP fragmentation Instance Option
 *
 *  Args:
 *   hIp                       IP fragmentation instance
 *   oOption                    Option
 *   hData                      Option data
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpFragInstanceSet(H_NETINSTANCE hIp,
                       OCTET oOption,
                       H_NETDATA hData);

/*
 * IpFragInstanceQuery
 *  Query a IP fragmentation Instance Option
 *
 *  Args:
 *   hIp                       IP fragmentation instance
 *   oOption                    Option
 *   phData                     Option data pointer (to fill up)
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpFragInstanceQuery(H_NETINSTANCE hIp,
                         OCTET oOption,
                         H_NETDATA *phData);

/*
 * IpFragInstanceMsg
 *  Send a msg to a IP fragmentation instance
 *
 *  Args:
 *   hIp                       IP fragmentation instance
 *   oMsg                       Msg. See netcommon.h and ip.hfor definition
 *   hData                      Option data. None is defined at this stage
 *
 *  Return:
 *   >=0 success
 *   <-1 error
 */
LONG IpFragInstanceMsg(H_NETINSTANCE hIp,
                   OCTET oMsg,
                   H_NETDATA hData);


/*
 * IpFragInstanceULInterfaceCreate
 *  See Interface Ioctl discussion for more detail
 *
 *  Args:
 *   hIp                       IP fragmentationinstance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IpFragInstanceULInterfaceCreate(H_NETINSTANCE hIp);

/*
 * IpFragInstanceULInterfaceDestroy
 *  Destroy a IP fragmentation UL interface
 *
 *  Args:
 *   hIp                       IP fragmentation instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG IpFragInstanceULInterfaceDestroy(H_NETINSTANCE hIp,
                                      H_NETINTERFACE hInterface);

/*
 * IpFragInstanceULInterfaceIoctl
 *
 *  Args:
 *   hIp                         IP fragmentation instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IpFragInstanceULInterfaceIoctl(H_NETINSTANCE hIp,
                                    H_NETINTERFACE hULInterface,
                                    OCTET oIoctl,
                                    H_NETDATA hData);

/*
 * IpFragInstanceWrite
 *  Ip fragmentation Instance Write function. Follows PFN_NETWORKWRITE
 *  typedef.
 *
 *  Args:
 *   hIp                        Ip fragmentation Instance handle
 *   hIf                        Interface handle
 *   pxPacket                   Packet pointer
 *   wOffset                    Ip PDU offset
 *   hData                      pointer to a net_dst structure
 *
 *  Return:
 *   Number of bytes written or -1 (error)
 */
LONG IpFragInstanceWrite(H_NETINSTANCE hIp,
                         H_NETINTERFACE hIf,
                         NETPACKET *pxPacket,
                         NETPACKETACCESS *pxPktAccess,
                         H_NETDATA hData);

/*
 * IpFragInstanceLLInterfaceCreate
 *  Create an Interface to the Lower layer. Only one
 *  interface is supported
 *
 *  Args:
 *   hIp                       IP fragmentation instance
 *
 *  Return:
 *   H_NETINTERFACE         Interface handle
 */
H_NETINTERFACE IpFragInstanceLLInterfaceCreate(H_NETINSTANCE hIp);

/*
 * IpFragInstanceLLInterfaceDestroy
 *  Destroy a IP fragmentation LL interface
 *
 *  Args:
 *   hIp                       IP fragmentation instance
 *   hInterface                 Interface handle
 *
 *  Return:
 *   >= 0 if successfull
 */
LONG IpFragInstanceLLInterfaceDestroy(H_NETINSTANCE hIp,
                                      H_NETINTERFACE hInterface);

/*
 * IpFragInstanceLLInterfaceIoctl
 *
 *  Args:
 *   hIp                         Ip fragmentation instance handle
 *   hULInterface                 Interface handle
 *   oIoctl                       Ioctl msg
 *   hData                        data associated with the ioctl
 *
 *  Return:
 *   >=0 if successfull
 */
LONG IpFragInstanceLLInterfaceIoctl(H_NETINSTANCE hIp,
                                    H_NETINTERFACE hLLInterface,
                                    OCTET oIoctl,
                                    H_NETDATA hData);


/*
 * IpFragInstanceRcv
 *  Ip fragmentation Instance Rcv function
 *   Ip fragmentation Instance Rcv function. Follows PFN_NETWORRXCBK
 *   def.
 *
 *   Args:
 *    hIp                        Ip fragmentation Instance Handle
 *    hIf                        Interface handle
 *    pxPacket                   packet
 *    wOffset                    Ip PDU offset.
 *    hData                      unused
 *
 *   Return:
 *    Number of byte received or -1(error)
 */
LONG IpFragInstanceRcv(H_NETINSTANCE hIp,
                       H_NETINTERFACE hIf,
                       NETPACKET *pxPacket,
                       NETPACKETACCESS *pxPktAccess,
                       H_NETDATA hData);

/*
 * IpFragInstanceProcess
 *  Do the instance necessary processing
 *
 *  Args:
 *   hIp                        Ip fragmentation Instance Handle
 *
 *  Return:
 *   Time till next needed call (in multiple of 1 ms)
 */
LONG IpFragInstanceProcess(H_NETINSTANCE hIp);

#endif /* #ifndef _IPFRAG_H_ */







