/*
 * cqueue.c
 *
 * Implementation of the custom queue module
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * Includes
 *
 *****************************************************************************/
#include <NNstyle.h>
#include "ethbridge_flavor.h"
#include <stdlib.h>
#include <string.h>
#include "sys/socket.h" /* NNOS ntohx, htonx defs */
#include <netinet/in.h> /* Linux ntohx, htonx defs */
#include <pthread.h>
#include "netcommon.h"
#include "netutils.h"
#include "netdefs.h"
#include "nettime.h"
#include "ethernet.h"
#include "bridgedbg.h"
#include "bridgedefs.h"
#include "netsnmp.h"
#include "snmp_tcpip_data.h"
#include "spanningtree.h"
#include "macfilter.h"
#include "limiter.h"
#include "cqueue.h"
#include "cqueue_int.h"
#include "meter.h"


#ifdef CUSTOM_QUEUE
CUSTOM_QUEUE_CRITERIA CustomQueueTable[MAX_CUSTOM_QUEUE_CRITERIA];
OCTET aoCustomQueueClass[MAX_CUSTOM_QUEUE_CRITERIA];


/*****************************************************************************
 * Set the packet class (used in ATM transmission) based upon criteria defined
 * by user.
 *
 *****************************************************************************/
OCTET _CustomQueueMatchCriteria(CUSTOM_QUEUE_CRITERIA* pxCustomQueueStruct, NETPAYLOAD* pxPayload, NETPACKETACCESS* pxAccess)
{
  /* Just do something dummy for now */
OCTET *poQueueEthHdr;  /* Points to start of data layer packet  */
OCTET *poQueueSrcAddr;  /* Points to start of data layer packet */
/*WORD wQueueVlan = NETVLAN_DEFAULT;
//BOOL bEthVlanTagged = FALSE;
//BOOL bEthBroadcast = FALSE;
//BOOL bEthMulticast = FALSE;
//WORD wEthProtocol;
*/

OCTET *poQueueIpHdr;   /* Points to start of network layer packet */
/*WORD oIpPrecedence;
//WORD oIpTos;
//WORD oIpProtocol;
*/

OCTET *poQueueTransportHdr;   /* Points to start of transport layer packet */
/*WORD wTransportSrcPort = 0;
//WORD wTransportDstPort = 0;
*/

WORD wQueueOffset = pxAccess->wOffset;
WORD wQueueLength = pxAccess->wLength;
WORD wTemp;

int i;
OCTET oReturn = CUSTOM_QUEUE_NO_MATCH;
sbyte4 cmpResult;

CUSTOM_QUEUE_CRITERIA PacketCriteria;  /* Holds the info gleaned from the current packet */


  _CustomQueueClearCriteriaStruct(&PacketCriteria);

  /* Set the pointer to the start of the Ethernet header */
  poQueueEthHdr = pxPayload->poPayload + wQueueOffset;
  poQueueSrcAddr = poQueueEthHdr + 6;
  /* Set the pointer to the start of the IP header */
  poQueueIpHdr = poQueueEthHdr + 14;

  /* Get the network layer protocol */
  if (pxCustomQueueStruct->wEthProtocol) {
    MOC_MEMCPY((ubyte *)&PacketCriteria.wEthProtocol,
    (ubyte *)(poQueueEthHdr+ETHTYPE_OFFSET), (size_t)ETHTYPE_LEN);
    PacketCriteria.wEthProtocol = ntohs(PacketCriteria.wEthProtocol);
  }

  wQueueOffset += ETHHEADER_LEN;
  wQueueLength -= ETHHEADER_LEN;

  if (PacketCriteria.wEthProtocol == ETHVLAN_TYPE) {
    /* Get the vlan tag */
    if (pxCustomQueueStruct->wEthVlanTag) {
        MOC_MEMCPY((ubyte *)&PacketCriteria.wEthVlanTag,
            (ubyte *)(poQueueEthHdr+ETHTYPE_OFFSET+ETHTYPE_LEN),
            sizeof(WORD));
        PacketCriteria.wEthVlanTag = ntohs(PacketCriteria.wEthVlanTag);
    }
    if (pxCustomQueueStruct->bEthVlanTagged)
      PacketCriteria.bEthVlanTagged = TRUE;

    /* Get the real protocol */
    if (pxCustomQueueStruct->wEthProtocol) {
        MOC_MEMCPY((ubyte *)&PacketCriteria.wEthProtocol,
            (ubyte *)(poQueueEthHdr+ETHTYPE_OFFSET+ETHVLAN_LEN),
            (size_t)ETHTYPE_LEN);
      PacketCriteria.wEthProtocol = ntohs(PacketCriteria.wEthProtocol);
    }

    wQueueOffset += ETHVLAN_LEN;
    wQueueLength -= ETHVLAN_LEN;
    poQueueIpHdr += 4;
  }

  /* Get the network layer protocol */
  if (pxCustomQueueStruct->oIpProtocol) {
    MOC_MEMCPY((ubyte *)&wTemp, (ubyte *)(poQueueIpHdr+8), 2);
    wTemp = ntohs(wTemp);
    PacketCriteria.oIpProtocol =  (OCTET) (wTemp & 0x00FF);
  }

  /* Get the network layer TOS */
  if (pxCustomQueueStruct->oIpPrecedence) {
    MOC_MEMCPY((ubyte *)&wTemp, (ubyte *)poQueueIpHdr, 2);
    wTemp = ntohs(wTemp);
    PacketCriteria.oIpPrecedence = (OCTET) ((wTemp & 0x00FF) >> 5);
  }

  if (pxCustomQueueStruct->oIpTos) {
    MOC_MEMCPY((ubyte *)&wTemp,(ubyte *) poQueueIpHdr, 2);
    wTemp = ntohs(wTemp);
    PacketCriteria.oIpTos = (OCTET) (wTemp & 0x1F);
  }

  /* Get IP addresses */
  if (pxCustomQueueStruct->dwIpSrcAddress) {
    MOC_MEMCPY((ubyte *)&PacketCriteria.dwIpSrcAddress,
        (ubyte *)(poQueueIpHdr + 12), 4);
    PacketCriteria.dwIpSrcAddress = ntohs(PacketCriteria.dwIpSrcAddress);
  }

  if (pxCustomQueueStruct->dwIpDstAddress) {
    MOC_MEMCPY((ubyte *)&PacketCriteria.dwIpDstAddress,
        (ubyte *)(poQueueIpHdr + 16), 4);
    PacketCriteria.dwIpDstAddress = ntohs(PacketCriteria.dwIpDstAddress);
  }

  /* Set the pointer to the start of the transport layer header */
  poQueueTransportHdr = poQueueIpHdr + 8;

  if (pxCustomQueueStruct->wTransSrcPort) {
    MOC_MEMCPY((ubyte *)&PacketCriteria.wTransSrcPort,
    (ubyte *) poQueueTransportHdr, 2);
    PacketCriteria.wTransSrcPort = ntohs(PacketCriteria.wTransSrcPort);
  }

  if (pxCustomQueueStruct->wTransDstPort) {
    MOC_MEMCPY((ubyte *)&PacketCriteria.wTransDstPort,
        (ubyte *)(poQueueTransportHdr + 2), 2);
    PacketCriteria.wTransDstPort = ntohs(PacketCriteria.wTransDstPort);
  }

    ETH_DBGP(REPETITIVE,
         "CustomQueueMatchCriteria:Dst=%02x:%02x:%02x:%02x:%02x:%02x,Src=%02x:%02x:%02x:%02x:%02x:%02x,Proto=%s, Vlan=%d, Priority=%d\n",
         HWADDRDISPLAY(poQueueEthHdr),
         HWADDRDISPLAY(poQueueSrcAddr),
         EthProtoToString(PacketCriteria.wEthProtocol),
         PacketCriteria.wEthVlanTag,
         pxAccess->oPriority);

    ETH_DBGP(REPETITIVE,
         "CustomQueueMatchCriteria: IP layer:oIpPrecedence =%d, oIpTos=%d, oIpProtocol=%d\n", PacketCriteria.oIpPrecedence, PacketCriteria.oIpTos, PacketCriteria.oIpProtocol);

    ETH_DBGP(REPETITIVE,
         "CustomQueueMatchCriteria: TCP/UDP layer:wTransportSrcPort =%d, wTransportDstPort=%d\n", PacketCriteria.wTransSrcPort, PacketCriteria.wTransDstPort);

    /* Process the Criteria Table to see if anything fits */
    i = 0;

    while (i<MAX_CUSTOM_QUEUE_CRITERIA) {
#if 1
        MOC_MEMCMP((ubyte *)&PacketCriteria, (ubyte *)pxCustomQueueStruct,
            sizeof(CUSTOM_QUEUE_CRITERIA), &cmpResult);
        if (0 == cmpResult) {
     oReturn = (OCTET) i;
     break;
      }
#else
      if (0 == memcmp(&PacketCriteria, pxCustomQueueStruct, sizeof(CUSTOM_QUEUE_CRITERIA))) {
     oReturn = (OCTET) i;
     break;
      }
#endif
      i++;
      pxCustomQueueStruct++;
    }

    return oReturn;
}

/*****************************************************************************
 * Set the class table structure referenced.
 *
 *****************************************************************************/
DWORD CustomQueueSetClass(OCTET* poClass, OCTET val)
{
  ASSERT ((val>0) && (val<MAX_CUSTOM_QUEUE));

  *poClass = val;
  return 0;
}

/*****************************************************************************
 * Set the criteria table structure referenced.
 *
 *****************************************************************************/
DWORD CustomQueueSetCriteriaStruct(CUSTOM_QUEUE_CRITERIA* pxCustomQueueCriteriaStruct, CUSTOM_QUEUE_CRITERIA* pxLocalStruct)
{
  MOC_MEMCPY((ubyte *)pxCustomQueueCriteriaStruct,(ubyte *) pxLocalStruct,
        sizeof(CUSTOM_QUEUE_CRITERIA));
  return 0;
}

/*****************************************************************************
 * Clear the criteria table structure referenced.
 *
 *****************************************************************************/
DWORD _CustomQueueClearCriteriaStruct(CUSTOM_QUEUE_CRITERIA* pxCustomQueueCriteriaStruct)
{
  MOC_MEMSET((ubyte *)pxCustomQueueCriteriaStruct, 0x00, sizeof(CUSTOM_QUEUE_CRITERIA));

  return 0;
}

/*****************************************************************************
 * Initialise all the criteria table structure referenced.
 *
 *****************************************************************************/
DWORD CustomQueueCriteriaInit(CUSTOM_QUEUE_CRITERIA* pxCustomQueueCriteriaStruct)
{
  MOC_MEMSET((ubyte *)pxCustomQueueCriteriaStruct, 0x00, sizeof(CUSTOM_QUEUE_CRITERIA_TABLE));

  return 0;
}

#ifdef BRIDGEDBG_HI
/*****************************************************************************
 * Print the criteria table structure referenced.
 *
 *****************************************************************************/
void _CustomQueuePrintCriteriaStruct(CUSTOM_QUEUE_CRITERIA* pxCustomQueueCriteriaStruct)
{
/*  printf("Associated Class = %d\n", pxCustomQueueCriteriaStruct->oClass); */
  printf("Layer 2: VLAN Tagged? %d  VLAN Tag=%d  Broadcast? %d  Multicast? %d  Protocol=0x%x\n",
          pxCustomQueueCriteriaStruct->bEthVlanTagged,
          pxCustomQueueCriteriaStruct->wEthVlanTag,
          pxCustomQueueCriteriaStruct->bEthBroadcast,
          pxCustomQueueCriteriaStruct->bEthMulticast,
          pxCustomQueueCriteriaStruct->wEthProtocol);
  printf("Layer 3: Precedence=%d  TOS=%d  Protocol=%d  Source=0x%lx  Dest=0x%lx\n",
          pxCustomQueueCriteriaStruct->oIpPrecedence,
          pxCustomQueueCriteriaStruct->oIpTos,
          pxCustomQueueCriteriaStruct->oIpProtocol,
          pxCustomQueueCriteriaStruct->dwIpSrcAddress,
          pxCustomQueueCriteriaStruct->dwIpDstAddress);
  printf("Layer 4: Source Port=%d  Dest Port=%d\n",
          pxCustomQueueCriteriaStruct->wTransSrcPort,
          pxCustomQueueCriteriaStruct->wTransDstPort);
}
#endif

#endif  /* CUSTOM_QUEUE */

