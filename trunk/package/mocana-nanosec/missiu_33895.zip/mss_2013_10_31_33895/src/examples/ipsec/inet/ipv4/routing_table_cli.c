/*
 * routing_table_cli.c
 *
 * Implements the routing table
 *
 * Copyright Mocana Corp 2005. All Rights Reserved.
 * Proprietary and Confidential Material.
 *
 */


/*****************************************************************************
 *
 * includes
 *
 *****************************************************************************/
#ifdef __MOC_CLI__
#include "router.h"
#include "routing_table_defs.h"
#include "routing_table_cli.h"
#include "../common/netdefs.h"

/*Hash defines*/
#define MAX_ROUTE_CLI_PARAMS 10
#define MAX_ROUTE_CLI_PARAM_VALUE_LEN 30

/*
 * _ParseCmndRouteParameters
 * Parses the command line parameters from the CLI module.
 * NOTE : This can be done within the CLI module, something to think about.
 * Input Parameters:
 * ubyte: number of parameters of a particular command
 * ubyte * : Array having all the parameters and its values
 * struct rtentry * : out parameter, which this function fills up with the ip, mask, gw & if index values
 * Return value:
 * 0 indicates sucess , -1 indicates failure.
 */
sbyte2 _ParseCmndRouteParameters(ubyte params, ubyte* paramTable[], struct rtentry *pxRtEntry);

/*
 * RouteCliShow
 */
ubyte4 RouteCliShow(ubyte *cmdRx, ubyte *uSbuf, ubyte4 *uSbufLen)
{
  if(!MOC_STRNICMP(cmdRx, "all", 3))
  {
    ROUTINGTABLECLIGET xRouteTableCliGet;
    xRouteTableCliGet.poSbuf = uSbuf;
    xRouteTableCliGet.dwSbufLen = *uSbufLen;
    RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
    RoutingTableMsg(ROUTINGTABLEMSG_CLI_GETALLROUTES, (H_NETDATA)&xRouteTableCliGet);
    RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    *uSbufLen = xRouteTableCliGet.dwSbufLen;
  }
  else
    printf("----\nUSAGE : show route all\n----\n");
  return(0);
}

/*
 * RouteCliConfig
 */
ubyte4 RouteCliConfig(ubyte *cmdRx)
{
  ubyte* pCmd = cmdRx;
  ubyte buf[255], bufLen=0;
  ubyte param[33], paramLen = 0, strLen;
  ubyte paramArgc =0;

  ubyte *paramArgv[MAX_ROUTE_CLI_PARAMS * 2];
  ubyte *ptrArgv;
  ubyte **paramPtr;

  struct rtentry xRtEntry;

  while(*pCmd !=NULL)
  {
     paramLen = 0;
     MOC_MEMSET(param, 0, (sizeof(ubyte)*(MAX_ROUTE_CLI_PARAM_VALUE_LEN + 1)));
     /*get the parameters  and values */
     while(*pCmd != ' ')
     {
       if(*pCmd != NULL)
       {
         param[paramLen] = *(pCmd++);
         paramLen++;
       }
       else
       {
         pCmd--;
         break;
       }
     }
     pCmd++;
     paramArgv[paramArgc]=(char*)malloc((sizeof(ubyte)*(MAX_ROUTE_CLI_PARAM_VALUE_LEN + 1)));
     MOC_MEMSET(paramArgv[paramArgc],0,(sizeof(ubyte)*(MAX_ROUTE_CLI_PARAM_VALUE_LEN + 1)));
     MOC_MEMCPY(paramArgv[paramArgc], param, paramLen);
     paramArgc++;
  }
  if(paramArgc == 0)
  {
    printf("\n USAGE: Type help command for correct command syntax\n\n");
    return 0;
  }
  MOC_MEMSET((ubyte*) &xRtEntry, 0, sizeof (struct rtentry));
  if(!MOC_STRNICMP(paramArgv[0], "add", 3))
  {
    STATICROUTEENTRY xStaticRouteEntry;
    xStaticRouteEntry.pxRtEntry = &xRtEntry;
    if(0 == _ParseCmndRouteParameters(paramArgc, (ubyte **) &paramArgv, &xRtEntry))
    {
      RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
      if(NETERR_NOERR != (RoutingTableMsg(ROUTINGTABLEMSG_SETSTATICROUTE, (H_NETDATA) &xStaticRouteEntry)))
        printf("Config Failed: unable to add entry into the routing table \n");
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    }
  }
  else if(!MOC_STRNICMP(paramArgv[0], "del", 3))
  {
    ROUTEENTRY xDelRouteEntry;
    if( 0 == _ParseCmndRouteParameters(paramArgc, (ubyte **) &paramArgv, &xRtEntry))
    {
      xDelRouteEntry.xRouteNodes->RadixNodeKey = ((struct sockaddr_in*) &xRtEntry.rt_dst)->sin_addr.s_addr;
      xDelRouteEntry.xRouteNodes->RadixNodeMask = ((struct sockaddr_in*) &xRtEntry.rt_genmask)->sin_addr.s_addr;
      xDelRouteEntry.dwGateway = ((struct sockaddr_in*) &xRtEntry.rt_gateway)->sin_addr.s_addr;
      xDelRouteEntry.wMetric = xRtEntry.rt_metric;
      xDelRouteEntry.oIfIdx = xRtEntry.rt_ifindex;
      xDelRouteEntry.wVlan = NETVLAN_ANY;
      xDelRouteEntry.wTOS = 0;
      RTOS_recursiveMutexWait(&(xNetWrapper.xMutex));
      if( NETERR_NOERR != RoutingTableMsg(ROUTINGTABLEMSG_DELROUTE, (H_NETDATA) &xDelRouteEntry))
        printf("Config Failed: unable to delete entry from routing table. \n");
      RTOS_recursiveMutexRelease(&(xNetWrapper.xMutex));
    }
  }
  else
  {
    printf("\n unsupported command : %s : check help for supported commands \n", paramArgv[1]);
  }
  return 0;
}

/*
 * _ParseCmndRouteParameters
 */
sbyte2 _ParseCmndRouteParameters(ubyte params, ubyte* paramTable[], struct rtentry *pxRtEntry)
{
  sbyte oMandatoryParam = 0;
  ubyte4 dwIpAddress = 0;
  ubyte *poEndPtr;
  ubyte2 dwLoopCnt = 1;

  for(; dwLoopCnt < params; dwLoopCnt++)
  {
    if(!MOC_STRNICMP(paramTable[dwLoopCnt], "ip", 2))
    {
      /* Configure the IP Address */
#ifdef __RTOS_VXWORKS__
      if( ((inet_aton(paramTable[++dwLoopCnt],(struct in_addr *)&dwIpAddress)) != 0) || dwIpAddress == 0)
#else
      if( ((inet_aton(paramTable[++dwLoopCnt],(struct in_addr *)&dwIpAddress)) == 0 )|| dwIpAddress == 0)
#endif
      {
        printf("Config Failed : invalid IP address.\n");
        goto config_err_exit;
      }
      oMandatoryParam = 1;
      ((struct sockaddr_in *) &(pxRtEntry->rt_dst))->sin_addr.s_addr = ntohl(dwIpAddress);
    }
    else if(!MOC_STRNICMP(paramTable[dwLoopCnt], "mask", 4))
    {
      /* Configure the Subnet mask */
#ifdef __RTOS_VXWORKS__
      if( ((inet_aton(paramTable[++dwLoopCnt],(struct in_addr *)&dwIpAddress)) != 0))
#else
      if( ((inet_aton(paramTable[++dwLoopCnt],(struct in_addr *)&dwIpAddress)) == 0))
#endif
      {
        printf("Config Failed : invalid mask address.\n");
        goto config_err_exit;
      }
      oMandatoryParam = 1;
      ((struct sockaddr_in *) &(pxRtEntry->rt_genmask))->sin_addr.s_addr = ntohl(dwIpAddress);
    }
    else if(!MOC_STRNICMP(paramTable[dwLoopCnt], "gw", 2))
    {
      /* Configure the Gateway IP Address */
#ifdef __RTOS_VXWORKS__
      if( ((inet_aton(paramTable[++dwLoopCnt],(struct in_addr *)&dwIpAddress)) != 0) || dwIpAddress == 0)
#else
      if( ((inet_aton(paramTable[++dwLoopCnt],(struct in_addr *)&dwIpAddress)) == 0 )|| dwIpAddress == 0)
#endif
      {
        printf("Config Failed : invalid gateway ip address.\n");
        goto config_err_exit;
      }
      ((struct sockaddr_in *) &(pxRtEntry->rt_gateway))->sin_addr.s_addr = ntohl(dwIpAddress);
    }
    else if(!MOC_STRNICMP(paramTable[dwLoopCnt], "if", 2))
    {
      pxRtEntry->rt_ifindex = strtol(paramTable[++dwLoopCnt], &poEndPtr, 0);
    }
    else
    {
      printf("Config Failed: invalid option %s", paramTable[dwLoopCnt]);
      goto config_err_exit;
    }
  }

  if(!oMandatoryParam)
  {
    printf("ipaddress OR mask values not provided. \n");
    goto config_err_exit;
  }
  return 0;

  config_err_exit:
    return -1;
}
#endif
